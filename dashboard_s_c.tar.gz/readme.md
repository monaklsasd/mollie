
# Mollie Dashboard

Mollie Dashboard is a single page JavaScript application written in React. It’s based on [Create React App](https://github.com/facebook/create-react-app), which was used as a boilerplate.

## Table of contents

* [Getting started](#getting-started)
* [Integration with Mollie Platform](#integration-with-mollie-platform)
* [File structure](#file-structure)
* [Data handling](#data-handling)
* [Routing](#routing)
* [Forms](#forms)
* [Internationalization (i18n)](#internationalization-i18n)
* [Styling](#styling)
* [Code style](#code-style)
* [Testing](#testing)
* [Webpack](#webpack)

# Getting started

**Before you start:** while commands such as `make install` are run inside the virtual machine for most Mollie repositories, all Dashboard related commands should be run on your local machine unless otherwise noted.

## 1. Perform basic setup

Follow the instructions in: [Setting up Mollie Platform, Dashboard, MBS, and Ledger](https://mollie.atlassian.net/wiki/spaces/DEV/pages/1245238/Setting+up+Mollie+platform+Dashboard+MBS+and+Ledger).

> In normal cases, Mollie Office IT will have preinstalled the Mollie Root CA on relevant systems on provisioning so you can run over HTTPS locally. If this appears to not be the case, follow the instructions in [this Confluence article](https://mollie.atlassian.net/wiki/spaces/Sysops/pages/36540619/Install+the+Mollie+Root+CA+on+a+workstation).

## 2. Install Node using the Node Version Manager (NVM)

Mollie has multiple projects using Node. Some projects use different Node versions. The correct Node version for Dashboard is stored in the file `.nvmrc` in the root of the repository. If you don't have nvm installed yet, make sure to following [the installation instructions](https://github.com/creationix/nvm#install-script).

To install the correct Node version, run the following commands:

```bash
cd ~/Sites/merchant-dashboard
nvm install
```

This will take care of installing the correct Node + NPM version for you.

## 3. Installing dependencies using Yarn

Dashboard uses Yarn as a package manager. If you don't have Yarn installed, make sure you follow the [installation instructions](https://yarnpkg.com/lang/en/docs/install/#mac-stable) on the Yarn website.

To install the dependencies, run the following command:

```bash
make install
```

## 4. Starting your development environment

Run:

```bash
make start
```

You can now access your development environment by visiting https://mollie.dev/dashboard.

# Simulating the production environment

Sometimes it's important to test some features on the production environment. Therefore, you need to generate a production build:

```bash
make build # May take a few minutes
```

Before you can actually see your production build in action on your workstation, you need to set a special header. If you use the [Chrome extension ModHeader,](https://chrome.google.com/webstore/detail/modheader/idgpnmonknjnojddfkpgkljpfnnfcklj?hl=en) you can send additional headers for your local requests.

Make sure you’ve set the header `X-Dashboard-Mode` to `production` before visiting https://mollie.dev/dashboard. Alternatively, you can also add `?mode=production` to any url to load the production build.

![](./src/assets/images/modheaders.png)

# Integration with Mollie Platform

Dashboard lives as an application within the public folder of Mollie Platform. Therefore, Platform and Dashboard are tightly coupled. You cannot run Dashboard without running Mollie Platform as well. Before accessing Dashboard, make sure you've got your Vagrant VM's up and running:

```bash
cd ~/Sites/tools/virtualmachines/development-ubuntu-xenial-xerus
vagrant up mollie mollie-lb
```

## Elasticsearch and reindexing

Payments and Orders are stored in Elasticsearch (which allows us to filter them). This means payments and orders won't show up in Dashboard by themselves, even though they're already in the database.

**Note:** the following commands have to be run from the root of the mollie directory in your virtual machine (`/var/www/mollie`).

**Indexing payments**

```bash
php scripts/elasticsearch/reindex_all_payments.php --dryrun=false && php scripts/elasticsearch/process_reindex.php
```

**Indexing orders**

```bash
php scripts/elasticsearch/reindex_all_orders.php --dryrun=false && php scripts/elasticsearch/process_reindex.php
```

## Platform migrations

Since Mollie Platform is constantly being updated, chances are you might miss out on some database migrations. This will likely result in a PHP error. To upgrade your database to the latest version, run the following commands **inside your VM**.

```bash
cd /var/www/mollie
make migrations-development
```

This will install the latest Composer dependencies and run all pending database migrations.

## Deploying Dashboard

The latest version of Dashboard (which is the latest successful build of the `master` branch) will automatically be deployed whenever Mollie Platform is deployed. Instructions on how to deploy Dashboard / Mollie Platform can be found in the "Deployments" section.

# File structure

For day-to-day development, the most interesting folder inside merchant-dashboard is `src`:

```bash
merchant-dashboard/src
.
├── assets
|   # Fonts, icons, and images
|
├── components
|   # Plain components that are shared between pages.
|
├── constants
|   # Global constants such as countries and document formats.
|
├── containers
|   # Stateful components, usually entire screens like "Account". These
|   # containers will often also contain their own page specific components.
|
├── intl
|   # Translations
|
├── reduxState
|   # Data stores, factories, middlewares, and Sagas not related to a container.
|
├── services
|   # Interfaces with third party services, for example as our API client
|   # and analytics.
|
├── styles
|   # Global styles, variables, mixins, and functions
|
├── utils
    # Helper functions
```

## Components

In Mollie Dashboard components are presentational, meaning they are concerned with how things look. They have no knowledge of where data comes from, or how it’s mutated. Examples of components are:

* List of payments
* Button
* Graph with statistics

If components are specific to a page—for example a graph on the statistics page—these components are best colocated with the container. So you might find them in `src/containers/Statistics/Graph`.

The dashboard still contains a lot of code where this is not yet the case though, so you will often find code in `src/components` which should actually be colocated.

## Containers

As opposed to components, containers are the responsible for loading the correct data. They also response to changes in the UI, for instance by firing a Redux action after a button is clicked.

Note that containers having their own UI is permitted, we do not adhere to a strict separation between presentation and state. That being said, it’s often better to split out the UI to a separate component.

A folder for a container might look like this:

```bash
Orders/Detail/
|
├── actions.ts
|   # Redux actions.
|
├── constants.ts
|   # Action types plus any other constants.
|
├── index.ts
|   # The actual React component.
|
├── messages.ts
|   # Any strings that should be translated.
|
├── reducer.ts
|   # Reducer for the UI store of the container
|
├── sagas.ts
|   # Sagas for data fetching, form submission, etc.
|
├── selectors.ts
|   # Helper functions to supply the container with the required data.
|
├── styles.scss
|   # Styling for the container (if applicable).
|
├── types.ts
    # TypeScript types.
```

## Should I use a container or component?

If you need to connect to the state by using React Redux’s connect function, you’re writing a container. If you need to display a UI which is has no knowledge of it’s surrounding components, it’s a component.

See [this article](https://medium.com/@dan_abramov/smart-and-dumb-components-7ca2f9a7c7d0) by Dan Abramov for more info.

# Data handling

[Redux](https://redux.js.org/) is our state container of choice and handles all our data. On top of this we use a few packages to make our lives easier.

Our state is mostly stored fully normalized [TODO: link to Normalizr], and we make a distinction between two types of stores: **data stores** and **UI stores**.

## Data stores

As the name suggests, a data store contains data, for example payments. Our data stores aim to be fully normalized, meaning a store of payments looks like this:

```js
payments: {
  tr_abc123: { ... },
  tr_def456: { ... },
}
```

This data can be shared between the entire dashboard, for example to:

* Show an overview of payments.
* Show a payment detail page.
* Show payments related to an order.

## UI stores

A UI store holds the current state of a certain UI element. Take for example a list of payments, we probably want to know whether we have already loaded the data, or maybe there was an error while loading the data. Once the data is loaded we want to be able to easily get the right payments from the data store. Also, we probably don’t load all payments at once since there might be a lot of them. We should probably keep track of how we can load additional payments.

Our resulting UI store might look like this:

```js
paymentsList: {
  ids: ['tr_abc123', 'tr_def456'],
  isLoading: false,
  isLoaded: true,
  error: null,
  pagination: {
    next: 'tr_ghi789',
    isLoadingMore: false,
    error: null,
  },
}
```

Note that this store does not contain any data. It just knows which payments should be displayed, not what’s in the payments themselves. By storing the payments seperately they can be re-used throughout the dashboard.

## Fetching data

Action in Redux are always synchronous, meaning they can’t contain side effects like API requests. [Redux Saga](https://redux-saga.js.org/) is used to handle side effects. We chose it over similar libraries because it handle complex scenario’s and is easily tested. See the [order detail Saga](https://bitbucket.org/molops/merchant-dashboard/src/master/src/containers/Orders/Detail/sagas.js) for an example of how Sagas are structured.

A Saga will end up calling the [API Saga](https://bitbucket.org/molops/merchant-dashboard/src/master/src/reduxState/sagas/api.js) which in turn calls our [API client](https://bitbucket.org/molops/merchant-dashboard/src/master/src/services/api/). The API Saga handles things like translating errors on a higher level so you don’t have to rewrite this every time.

## Factory functions

One of the biggest downsides to using Redux is the amount of boilerplate you have to write. Therefore we have some factories to help you get started:

**createApiActions.js**
Creates an execute, success, and optional failure action for your API calls. You will likely use this one very often.

**createListReducer / createListSagas / createListSelectors**

Useful when you need a list of a resource, for example payments, refunds, or orders. These factories are highly specific and won’t work for anything else but a list.

## Normalizing state

A standard API response looks something like this:

```js
{
  orders: [
    { ... },
    { ... },
    { ... },
  ]
}
```

Finding a specific order in this structure means looping through all orders until you find the correct one. That’s why we use [Normalizr](https://github.com/paularmstrong/normalizr) to turn the response into this:

```js
{
  entities: {
    orders: {
      ord_abc123: { ... },
      ord_def456: { ... },
      ord_ghi789: { ... },
    },
  },
  result: ["ord_abc123", "ord_def456", "ord_ghi789"],
}
```

We store the actual orders in de data store for easy consumption. The array of ids is stored with the container so the sorting of orders remains intact.

If all this seems confusing at first, [watch this video](https://egghead.io/lessons/javascript-redux-normalizing-the-state-shape) in which Dan Abramov goes further into normalizing state.

## Getting data from Redux stores

We use the [selectors pattern](https://redux.js.org/recipes/computingderiveddata) for getting data from our stores. A simple selector looks like this:

```js
const getPayment = (state, id) => state.payments[id];
```

It could be however, that you need to do something more complex, like this:

```js
const getSettledPayments = (state, id) => state.payments.filter(payment => payment.settlemendId);
```

Selectors are executed on each render. Obviously this can get expensive when you have lots of payments and/or lots of renders. To help with this you can use [reselect](https://github.com/reduxjs/reselect), to memoize the selector:

```js
const getSettledPayments = createSelector(state.payments.filter(payment => payment.settlemendId));
```

This will store the results in memory, and will return previously computed results if the input is the same. Since this increases the amount of memory used, only use createSelector for expensive computations. Usually these are operations on a list, for example map, filter, or reduce.

# Routing

Dashboard uses the [React Router](https://reacttraining.com/react-router/web/guides/philosophy) v4 library for routing. It also includes [qhistory](https://github.com/pshrmn/qhistory) with [qs](https://github.com/ljharb/qs). This simplifies dealing with query strings throughout the application. Top level routes are defined in `src/routes.js.` Because of the declarative nature of React Router, every container is responsible for its sub-routes. The example below is a common pattern.

```js
// Incomming request: dashboard/someURL/add

// Routes.js
<Switch>
  // all the other routes
  <Route exact path="/someURL" component={SomeComponent} />
</Switch>

// SomeComponent/index.js and be re-route
<React.Fragment>
  <h1>This Header is visible on all the sub routes</h1>
  <Switch>
    <Route exact path=`${match.path}` component={mainComponent} />
    <Route exact path=`${match.path}/add` component={addComponent} />
    <Route exact path=`${match.path}/:id` component={detailComponent} />
  </Switch>
</React.Fragment>
```

## React Loadable

To facilitate code splitting we use [React Loadable](https://github.com/jamiebuilds/react-loadable). This library handles dynamic imports and can show a loading component. Take a look at `src/routes.js` for code examples.

You should consider code splitting whenever you make a new top-level component that is linked to a specific route. Code split could also be considered in specific situations like a sub-route that won't be requested a lot for example `terminate account` in `account settings`.

**Note:** Whenever you use react-loadable you should use the hot module reloading (HMR) higher order component to make sure HMR works.

## Routing from Sagas (React Router Redux)

Sometimes you need to navigate after an Action picked up by a Saga. We use `React-router-redux` to do this you may yield one of the actions supplied by the library.

```js
// Pick the action you need to perform
import { push, replace, go, goBack, goForward } from 'connected-react-router';

export function* MySaga(action) {
  yield push({
    pathname: '/newPath',
  });
}
```

# Forms

[Formik](https://jaredpalmer.com/formik) is used to develop forms in dashboard. There are several (custom) components and containers that will help with writing forms. Underneath this paragraph are the most important patterns described for building forms in the Dashboard.

## withFormik Hoc

In the Dashboard app withFormik HOC is used for connecting Formik with the component. As demonstrated in this example:

```js
import { withFormik } from 'formik';

// mapPropsToValues is needed to register the fields to the form
// These are also the initial values
const mapPropsToValues = props => ({ someFieldName: props.something || '' });

const handleSubmit = (values, formikBag) => {
  console.log({ values });
  formikBag.setSubmitting(false);
};

// This is Form Validation. There is something called field validation too!
const validate = (values, props) => {
  const errors = {};

  if (!value.someFieldName) {
    errors.someFieldName = 'required';
  }

  return errors;
};

// Use the redux connect HOC to get props in your mapPropsToValues if you need store values as initial values
withFormik({
  mapPropsToValues,
  handleSubmit,
  validate,
})(Container);
```

This a minimum setup example with in a for a form in dashboard. For more info, see the
[docs for withFormik](https://jaredpalmer.com/formik/docs/api/withFormik).

## FormikForm form wrapper

An optional, but highly advised, form wrapper. The wrapper will do a couple of things, namely:

* It will bind **handleSubmit** to the form.
* Give a **prompt** when leaving a dirty form. (opt-out with `promptOnDirtyLeave={false}`)
* Show a global form-error. A global form error is set by `setStatus({error:message})` (opt-out with `showStatusError={false}`)
* Scroll to an error whenever the form has a global or field error.

```js
import FormikForm from 'containers/forms/FormikForm';

export MyForm () => {
  return (
    <FormikForm>
      // form fields
      // form button (type submit)
    </FormikForm>
  )
}

withFormik({
  // See code above
})(MyForm);
```

## FormikGroup field wrapper

Most of the time you will use formikGroup wrapper. It is a custom (input)field wrapper which is responsible for a several things:

* Connect the field to the formik form
* Show an optional error, optional help and optional label

```js
import FormikGroup from 'components/forms/FormikGroup';

// Mandatory is the name prop, this is the unique identifier for the form.values.someField.
// Also note that <FormikGroup> only accepts a function as child.
<FormikGroup name="someField">
  {field => <input type="text" {...field} />}
</FormikGroup>;
```

## Submitting a Form via Redux and Sagas

Whenever you submit a form it's important that you send the form values and the so called [formikBag](https://jaredpalmer.com/formik/docs/api/withFormik#handlesubmit-values-values-formikbag-formikbag-void). The saga is responsible to set the state of the form `setSbmitting(false)` for example and `setStatus({error: 'message'});`

## Putting it all together

A minimal form is shown in this example. The easiest way to read this is to start reading at `withFormik`

```JavaScript
    import FormikForm from 'containers/forms/FormikForm';
    import FormikGroup from 'components/forms/FormikGroup';

    export MyForm = () => {
    	const { isSubmitting } = this.props;

      return (
    		// This is will wrap <form onSubmit={props.handleSubmit}>
        <FormikForm>
    			<FormikGroup name="myForm" label="Optional Label" help="Optional Help">
    	      <input
    					type="input"
             />
          </FormikGroup>
    			<button type="submit" disabled={isSubmitting}>Submit myForm</button>
        </FormikForm>
      )
    }

    // These are the initial props and it will register the fields
    // <MyForm someInitial='myForm initial value'>
    const mapPropsToValues = (props) => ({ myField: props.someInitial || '' })

    // Validation of the form.
    // Be aware that fields should be registerd via initialValues or mapPropsToValues!
    const validate = (values, props) =>{
    	const errors ={};

    	// You could use props in validation <MyForm customerName='Vernon'>
    	if(props.customerName !== 'Vernon'){
    		errors.myField = 'Only Vernon may enter this field'
    	} else if(!values.myField) {
    		errors.myField = 'This Field is required';
    	}

    	return errors;
    }

    const handleSubmit: (values, formikBag) => {
    	// Make sure form isn't submit more then once including enter key
    	if (formikBag.isSubmitting) {
        return;
      }
    	// Most of the time you want to submit the from via a redux action.
    	formikBag.props.submitFormAction(values, formikBag)
    }

    withFormik({
    	mapPropsToValues,
      validate,
    	handleSubmit,
    })(MyForm);
```

# Tracking (Mixpanel and Google Analytics)

## Tracking a new action

We use two platforms to collect the tracking data from the dashboard, [Google Analytics](https://analytics.google.com/analytics/web/) and [Mixpanel](https://mixpanel.com/).

To track a new Action, just import the `track()` function from `services\analytics` and call it like this:
```
track({
    category: CATEGORY_1,
    event: EVENT_1
    link_destination: e.target.href,
    link_text: e.target.innerText,
    link_placement: 'user_menu',
    pathname: window.location.pathname,
});
```
In this example, the two first elements passed are required, the next 4 are just extra properties that only Mixpanel will be able to parse.

To understand how to name your events, there are naming conventions.

## Naming conventions

The data collected from the tracking is used by different parties at Mollie, so we need a convention to keep tracking events organized.
You can find the current tracked elements and how they are named in [this sheet](https://docs.google.com/spreadsheets/d/1Zq0ZXooWFwWnHrRA8auxmaFvjKsRk7AmLWnj2ZNoib0/edit#gid=0)

# Internationalization (i18n)

## React Intl

Mollie uses the `react-intl` module to display localized messages, dates and numbers in React. React Intl allows us to write English messages in our codebase, these are written using the [ICU message syntax](https://formatjs.io/guides/message-syntax/).

## Defining translations

Keep the translatable messages separated from React components. Therefore, place the translatable messages in a separate file called `messages.js`.

```js
# messages.js
import { defineMessages } from 'react-intl';

export default defineMessages({
  fixedTransactionsFee: {
    id: 'administration-fixed-transactions-fee',
    defaultMessage: 'fixed transactions fee',
    description: 'Do not capitalize, the payment method will be prepended to this.',
  }
};
```

## Rendering translations

Use the `FormattedMessage` component to render translations, which usually looks like this:

```
import { FormattedMessage } from 'react-intl';
import messages from './messages';

export default () => (
  <button>
    <FormattedMessage {...messages.submit} />
  </button>
);
```

Please note that the `FormatttedMessage` component always renders an extra `<span />` around your string.

If you’d like to avoid that (for example if you need to translate the text within a `<option />` tag, you use a function as the child:

```js
<FormattedMessage id="title" defaultMessage="Select an option">
  {txt => <option>{txt}</option>}
</FormattedMessage>
```

## Crowdin

Translations are managed using Crowdin in the "Dashboard" project. Our International Expansion team takes care of translating the strings once they end up in Crowdin (check out the Slack channel #translations if you have any questions for them).

Once you're happy with your changes and you've updated some translatable strings, you should jump into the next step, `Generating and Uploading`

## Generating and Uploading the translation source file

To add the translations to Crowdin, you should run the `yarn run translations:upload` command.

The translation messages are extracted from our source code using `babel-plugin-react-intl` and placed in the folder `build/messages`. The upload script first runs a production build, and then generates the file `intl/english.source.json` with the proper structure.
The script then uploads the generated file to Crowdin with your branch as a directory.

The translators will need to translate that branch for you. You should create a [Task](https://crowdin.com/project/mollie-dashboard/tasks) with the request for translations. The translators will be notified by email that they need to complete that task.

Whenever you merge your feature branch back to master, the translations will be synced, and if they were translated, they will be present in master.

## Downloading translations from Crowdin

You will probably want to test how translations affect your new feature.
You can download the latest translations from Crowdin by calling the following command:

```bash
yarn translations:download
```

The downloaded files will be placed in `src/intl`. You can (should) test the translations, making sure that string length doesn't have any negative effects, for example.

Whenever your branch is merged to master, the latest translations will be added automatically.

## Moment

Use `moment.js` whenever the helper component that come with React Intl are not enough.

## Currencies

If you need to display monetary amounts, use the helper component in `src/components/UI/Currency/index.js`

# Styling

Styling is written in [BEM](https://en.bem.info/methodology/quick-start/) with [Sass](https://sass-lang.com/) as a preprocessor, while sticking as closely to native CSS as possible. This means no nesting except for breakpoint, no `@extends`, and minimal amount of functions and mixins.

## Code style

CSS is written according to a specific code style, which you can [find on the Mollie Wiki](https://mollie.atlassian.net/wiki/spaces/DEV/pages/7897093/Mollie+CSS+code+style).

## Basics

**Naming convention**

Classes are named after components. If your component is <PaymentScreen> your root CSS class will be `.payment-screen`.

You will also encounter globally used layout classes that start with `.l-` and utility classes that start with `.u-`. Refer to the [code style](https://mollie.atlassian.net/wiki/spaces/DEV/pages/7897093/Mollie+CSS+code+style) for more info on how these are used.

**Breakpoints**

We use an array of breakpoints, which can be found in `src/styles/_variables.scss`. They are used together with the breakpoint function:

```scss
.selector {
  @media {
    color: red;
  }

  @media {
    color: blue;
  }
}
```

When using max-width, use the smaller than sign to prevent overlapping breakpoints. For example:

```scss
// Incorrent:
// This selector would be bold and blue when the window is exactly the size of 'small'
.selector {
  @media (max-width: breakpoint('small')) {
    color: blue;
  }

  @media (min-width: breakpoint('small')) {
    font-weight: bold;
  }
}

// Correct:
// This selector is either blue or bold, but never both
.selector {
  @media (max-width: breakpoint('<small')) {
    color: blue;
  }

  @media (min-width: breakpoint('small')) {
    font-weight: bold;
  }
}
```

Feel free to define breakpoints in a component if this better suits the UI.

**z-index**

Stacking of elements is handled globally in `src/styles/_variables.scss` to prevent hacks like `z-index: 9999` and friends.

```scss
// _variables.scss
// Re-ordering these will change the z-index
$z-indexes: (
  base: (),
  modal: ()
);

// _base.scss
.base {
  z-index: z(base);
  position: relative;
}

// _modal.scss
.modal {
  z-index: z(modal);
  position: fixed;
}
```

**Functions**

Functions can be found in `src/styles/functions/`. You will likely only ever need breakpoint, share, tint, and z:

```scss
.selector {
  @media (min-width: breakpoint('small')) {
    // Use breakpoint in media query
    z-index: z(selector); // Set z-index
    background: lighten($brand-primary, 50%); // Lighten color by adding white
    color: shade($brand-primary, 50%); // Darken color by adding black
  }
}
```

**Mixins**

Similar to functions, these can be found in `src/styles/mixins/`. It’s likely you will have no need to use these, they add a layer of abstraction and it’s usually just as easy to write out the CSS itself.

# Code style

To improve the quality and consistent code style there are a couple of tools implemented to check and/or format the code. Every-time you commit a pre-commit-hook will execute all the `lint-staged` commands before added. You can bypass this by adding `—no-verify` But be aware this will be checked once again by the CI tool on every deploy and therefore the build **WILL** fail.

## Linting ESlint & Stylelint

All the ESlint rules you find in `.eslintrc`. If there is a rule that you need to disable you may use a disable line comment.

```
✗ DON'T:
/* eslint-disable */

✔ DO:
// eslint-disable-next-line

✔✔ DO EVEN BETTER:
// eslint-disable-next-line no-param-reassign no-console
```

## Stylelint

To check SCSS/CSS stylelint rules will be applied on those files. In `.stylelintrc` are the rules that the dashboard uses. Files that needs to be ignored are listed in `.stylelintignore`

## Prettier

Prettier will format every file that is JSX, JS and JSON. the rules are defined in the `package.json` file. The `.prettierignore` file will indicate which will ignore prettier on specific files and directories.

## Coding Standards

Most of the coding standards will be covered by the linters, formatters and type checker. But a couple exceptions are listed here. Be aware these rules apply 99% of the time.

* Prefer the use of native functions over lodash.
* ES6 (use `const` , `let` , arrow functions etc.)
* Functional programming, stateless functions, immutability, are all desirable.
* Import partial modules—for example `import { foo } from 'baz'`—so tree shaking will be applied
* Obey the [directory structure](#directory-structure).
* Readability goes above minor performance gains
* Document the code
* Check the Definition of Done.

# Testing

## Setup

Mollie uses [Jest](https://jestjs.io/), [Enzyme](https://airbnb.io/enzyme/), and [Redux Saga Test Plan](http://redux-saga-test-plan.jeremyfairbank.com/) as testing tools. There are several types of tests Mollie currently uses:

* Integration tests (using Enzyme or Redux Saga Test Plan)
* Unit tests
* Snapshot tests

## Writing tests

Tests are isolated in their own folder. The convention is to use `__tests__` as a folder name. Also, make sure the filename ends with `.tests.ts(x)`

## Running tests

Running all tests can be done by executing the command below. This command is also set up as a Git pre-push hook.

```bash
make test
```

It's also possible to run Jest in watch mode. This will trigger a certain test again once it has changed, which increases testing velocity:

```bash
yarn test:watch
```

## Unit tests vs. integration tests

There's a difference between unit tests and integration tests:

* _Integration tests_ can be used to test interactions with a certain component. This is usually done using Enzyme. For example: test whether the `onChange` method is called when you trigger the `onKeyDown` event on a certain DOM element within a component. To test interaction with a component, you need to shallow render the component before making assertions. You can find an example in [this Medium post](https://medium.com/homeaway-tech-blog/integration-testing-in-react-21f92a55a894).
* _Unit tests_ can be used to check whether certain units (usually methods) match with your assertions. These are really useful when testing helper methods. For example: assert that the outcome of `toUpperCase("my string")` equals `"My string"`.

## Snapshot testing

Snapshot can be really powerful for capturing complex object or components. That being said, snapshot testing comes with a bunch of drawbacks. So it should only be used in specific cases.

**Cons of snapshot testing:**
* Hard to read, especially for UI trees.
* Unclear exactly what part of the snapshot is relevant or what the intention of the developer was.
* Incorrect coverage reporting. A snapshot test "covers" all lifecycle methods, but in reality won’t cover side effects like logging or API requests.

As a result of the above, developers are very likely to just update the snapshot, without understanding the "why".

**When to use snapshot testing:**
* Asserting deeply nested state (do you really need to test the whole state?).
* Asserting complex return values (are you testing the right thing?).
* Asserting component rendering in combination with Enzyme’s shallow method.

If you want to test simple values, objects, or arrays, use the matchers built into Jest, as `toBe`, `toEqual`, etc.

If you want to test UI, use Enzyme’s selectors. Sure your selectors might break at some point, but it will be crystal clear what exactly you‘re testing.

### Updating snapshots

Snapshot tests are a very useful tool whenever you want to make sure your UI does not change unexpectedly. However, if something changes in the output of a component, you'll need to update your snapshot. This can be done by running the following command:

```bash
yarn run test -u
```

## Redux Saga Test Plan

The `redux-saga-test-plan` can be used to test whether a certain side-effect is called after you `put` a certain action. It also allows you to add assertions about the final state of the Redux store, based on your initial state and the side-effects that have been called.

* [More information on integration tests using Redux Saga Test Plan](https://github.com/jfairbank/redux-saga-test-plan#simple-example)

## BrowserStack

If you'd like to test how what your changes look like in different browsers, you can use the tool Browserstack. Mollie has a paid account there, that you can use to test your Dashboard locally. Make sure you have the option ["Resolve all URLs through my local network"](https://www.browserstack.com/local-testing) checked.

Make sure you test your changes against the [list of supported browsers](https://mollie.atlassian.net/wiki/spaces/DEV/pages/431030292/Browser+support).

**Note:** If you're browsing Dashboard using Browserstack, SSL certificates won’t work. Visit [https://mollie.dev](https://mollie.dev) and trust the certificate manually. You should do the same for [https://cdn.mollie.dev:3000/static/js/bundle.js](https://cdn.mollie.dev:3000/static/js/bundle.js) since it’s hosted on the CDN subdomain.

> Contact Mattijs Bliek if you need the BrowserStack credentials.

![](./src/assets/images/browserstack.png)

# Webpack

To bundle the application the dashboard uses Webpack. All the config related to Webpack you can find in `config` and `scripts` directories. It's based upon the Create React App boilerplate. There are some minor modifications. Few highlights:

* Self Signed Certificates
* Extra translation babel plugin
* Vendor bundle (blacklisted vendor modules)
* SVGO plugin
* And couple of other tweaks

## Hot Module Reloading

Webpack is configured for hot module reloading. This will auto-patch the app whenever a file is changed. Most of the time this works but if you touch something big like saga's or redux it will perform a refresh. It isn't perfect but it will help.

Whenever you split code via react-loadable you should use the HOC from react-hot-loader.

```js
import { hot } from 'react-hot-loader';

const someAsyncComp() => (<div>A component</div>)

export default hot(module)(someAsyncComp);
```

# Deploying Dashboard

## When to deploy

Changes can be deployed when:

* The pull request has been approved by at least one Mollie developer;
* The changes comply with the [Definition of Done Front-end](https://mollie.atlassian.net/wiki/spaces/DEV/pages/776667137/Definition+of+Done+DoD+Front-end);
* The deployment is initiated within the deployment window;
* Or, if the deployment takes place outside of the deployment window and you have an official approval from your Team Lead;

## How deployments work

Once a PR has been merged to `master`, a new Pipeline will be started within Bitbucket. This pipeline takes care of the following tasks:

* Installing dependencies
* Running tests
* Cleaning assets
* Starting a production build
* Commit & push a new artifact to a repository on Bitbucket

Once the pipeline has succeeded, you can deploy your changes by deploying Mollie Platform. The dashboard build will be checked out in the public folder of Mollie Platform.

[How does deploying with Capistrano work?](https://mollie.atlassian.net/wiki/spaces/DEV/pages/14549026/How+does+deploying+with+Capistrano+work)
