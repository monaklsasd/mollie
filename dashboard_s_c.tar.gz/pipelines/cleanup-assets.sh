#!/bin/bash
set -euo pipefail

# Configuration Variables
INTERVAL=$((30*24*60*60))
MIN_FILE_COUNT=2

# Prepare Global variables
FILE_PREFIX="./${TARGET_DIR}/"
NOW=$(date +%s)
CURRENT=""

# Helper functions
getSource() {
  parts=(${1//./ })
  printf "%s" "${parts[0]}"
}

getTimestamp() {
  printf "%d" "$(git -C ${TARGET_DIR} log --format=%at ${1} | head -1)"
}

getTimeFromRevision() {
  printf "%s" "$(git -C ${TARGET_DIR} show --pretty=format:%ad --date=format:%Y%m%d%H%M.%S --abbrev-commit ${1} | head -n 1)"
}

getRevision() {
  printf "%s" "$(git -C ${TARGET_DIR} rev-list -n 1 HEAD ${1})"
}

convertTimestampToReadableFormat() {
  printf "%s" "$(date -d @${1}  '+%Y-%m-%d %H:%M:%S')"
}

# Action functions
fixFileTimestamp() {
  revision=$(getRevision ${1})
  time=$(getTimeFromRevision ${revision})
  touch -mt"${time}" "./${TARGET_DIR}/${1}"
}

removeFile() {
  file="${1#$FILE_PREFIX}"
  git -C ${TARGET_DIR} rm -f --quiet "./${file}";
}

prepareFile() {
  file="${1#$FILE_PREFIX}"
  fixFileTimestamp "${file}"
  source=$(getSource ${file})
  if [ "${CURRENT}" != "${source}" ]; then
    CURRENT="${source}"
    LIST+=("${source}")
  fi
}

searchFiles() {
  # Strip source file into filename and path
  parts=(${1//\// })
  file="${parts[${#parts[@]}-1]}"
  unset 'parts[${#parts[@]}-1]'
  path="./${TARGET_DIR}$(printf /%s ${parts[@]})"

  # Find files based on the source file, oldest first
  found=$(find ${path} -type f \( -iname ${file}.*.* \) | xargs ls -1tr)

  # Store files in an array while removing the target dir from the location
  results=()
  while read -r file;
  do
    file="${file#$FILE_PREFIX}"
    results+=("${file}");
  done <<< "${found}"

  # Reverse the order to have the newest first
  for (( i = ${#results[@]}-1; i >= 0; i-- ))
  do
    printf " %s" "${results[i]}"
  done
}

# Main function
processFiles() {
  # Find all files we need to process
  files="$(find ./${TARGET_DIR}/build/static -type f | sort)"
  LIST=()

  # Set modified time for the files to correspond to the commit, and add every unique source file (file without the hash + extension) to the LIST array
  printf "Prepare files\n"
  while read -r file; do prepareFile ${file} ; done <<< "${files}"

  printf "Handle files\n"
  for sourcefile in "${LIST[@]}"
  do
    printf "\n[ %s ]\n" "${sourcefile}";
    # Find all files based on source file
    results=($(searchFiles ${sourcefile}))
    printf "Search found %d results:\n" "${#results[@]}";
    for index in "${!results[@]}"
    do
      file="${results[${index}]}"
      status="Ok"
      # Retrieve file info
      timestamp=$(getTimestamp ${file})
      readableTimestamp=$(convertTimestampToReadableFormat ${timestamp})
      revision=$(getRevision ${file})

      # Calculate the difference between now and timestamp
      diff=$((NOW-timestamp))

      # If the difference exceeds the interval
      if [ "${diff}" -gt "${INTERVAL}" ]; then

        # If the index is greater than ${MIN_FILE_COUNT}, delete this file, since we already have ${MIN_FILE_COUNT} newer files
        if [ "$((index+1))" -gt "${MIN_FILE_COUNT}" ]; then
          removeFile "${file}";
          status="Removed"
        fi
      fi

      # Log file info
      printf " [ %s ] - %s (%s - %s)\n" "${status}" "${file}" "${readableTimestamp}" "${revision}";
    done
  done
}

# Triggers
printf "Process source files\n"
processFiles
