#!/bin/sh

# Creates .env file for live environments

mv .env.prod.example .env

# Replaces the empty ENV= on the example with ENV="variable from bitbucket env"
sed -i "s/^CROWDIN_DASHBOARD_KEY=.*/CROWDIN_DASHBOARD_KEY=$CROWDIN_DASHBOARD_KEY/" .env
