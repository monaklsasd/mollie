'use strict';

if (process.env.npm_execpath.indexOf('yarn') === -1) {
  console.log('================================================\n');
  console.log('\tError! You must use Yarn not NPM\n');
  console.log('\t- yarn add <package> -E');
  console.log('\t- yarn build');
  console.log('\t- yarn start');
  console.log('================================================\n');
  process.exit(1);
}
