#!/bin/bash

# Uploads/updates current english.source.json to Crowdin


# For running it locally
source .env
BRANCH=$(git rev-parse --abbrev-ref HEAD | tr / -)

# Creates branch (a directory for Crowdin) if needed
curl https://api.crowdin.com/api/project/mollie-dashboard/add-directory\?key\=$CROWDIN_DASHBOARD_KEY\&name\="$BRANCH"\&is_branch=1\&json

# Creates the source file for that branch, if needed
curl -F "files[source.json]=@./intl/english.source.json" https://api.crowdin.com/api/project/mollie-dashboard/add-file\?key\=$CROWDIN_DASHBOARD_KEY\&branch\="$BRANCH"\&json\&type=chrome

# Updates the source file for that branch, if needed
curl -F "files[source.json]=@./intl/english.source.json" https://api.crowdin.com/api/project/mollie-dashboard/update-file\?key\=$CROWDIN_DASHBOARD_KEY\&branch\="$BRANCH"\&json

