#!/bin/bash

# Gets the current branch translations from Crowdin
# and saves them in a tmp folder for Nodejs to handle


# For running it locally
source .env

# Crowdin URLs use the LANGUAGES format, but we want the LOCALES one.
LOCALES=("de-DE" "es-ES" "fr-FR" "nl-NL" "fr-BE" "nl-BE" "en-US" "it-IT")
LANGUAGES=("de" "es-ES" "fr" "nl" "fr-BE" "nl-BE" "en-US" "it")

BRANCH=$(eval "git branch | grep \* | cut -d ' ' -f2" | tr / -)

# Syncs source file to prevent branching issues.
curl -F "files[source.json]=@./intl/english.source.json" https://api.crowdin.com/api/project/mollie-dashboard/update-file\?key\=$CROWDIN_DASHBOARD_KEY\&branch\="$BRANCH"\&json

# Makes directory for storing temporarily the language files.
mkdir tmp
cd tmp
mkdir ${LOCALES[*]}

# Gets individual files in a parallel loop (note the &) and stores it in the locale folder
# Saves all the HTTP Codes from the Curl (STATUS will be a string like '200200200200200' if succesful)
STATUS=$(for i in ${!LOCALES[@]}; do
  curl -fo ${LOCALES[i]}/source.json --write-out "%{http_code}" https://api.crowdin.com/api/project/mollie-dashboard/export-file\?file=source.json\&language=${LANGUAGES[i]}\&key\=$CROWDIN_DASHBOARD_KEY\&branch=$BRANCH &
done)

# Wait for all cURLS to finish.
wait

# Parse codes, if they are 200 they will be part of the array (due to the " ")
RESULTS=(${STATUS//"200"/"200 "})

# Return something when curls didn't fail so that Node knows it's successful.
# The length of the array containing 200 http codes needs to be equal to the number of requests (which is based on number of languages)
if [ "${#RESULTS[@]}" -eq "${#LOCALES[@]}" ]
    then echo Success
fi
