/* eslint no-console: 0, func-names: 0, no-param-reassign: 0, no-return-assign: 0 */
const { sync: globSync } = require('glob');
const { sync: mkdirpSync } = require('mkdirp');
const fs = require('fs');
const exec = require('child_process').spawnSync;

// Load .env
require('dotenv').config();

const sortObjectByKey = o => {
  return Object.keys(o)
    .sort()
    .reduce((r, k) => {
      r[k] = o[k];

      return r;
    }, {});
};

// Executes command and keeps quiet about it unless there's an error.
const executeCommand = (cmd, args) => {
  try {
    const command = exec(cmd, [...args], { stdio: ['pipe', 'pipe', 'ignore'] });

    // Sometimes yarn errors out without a message, so we also check the exit code
    if (command.status !== 0 || command.error) {
      return {
        success: false,
        error: `Command "${cmd} ${args.join(' ')}" errored`
      }
    }

    return {
      success: true
    };
  } catch (error) {
    return {
      success: false,
      error
    };
  }
};

const MESSAGES_PATTERN = './intl/messages/**/*.json';
const LANG_DIR = './intl/';
const SOURCE_FILE = `${LANG_DIR}english.source.json`;

// Break if Crowdin Key is not present
if (!process.env.CROWDIN_DASHBOARD_KEY) {
  console.log('You do not have the Crowdin API key (https://crowdin.com/project/mollie-dashboard/settings#api), please update your .env file');
  process.exit(1);
}

// Build production
process.stdout.write('Generating production build...');
const yarnResult = executeCommand('yarn', ['run', 'build']);

if (!yarnResult.success) {
  console.log(`❌ ${yarnResult.error}`);
  process.exit(1);
}

process.stdout.write(' done ✅ \n');

// Make sure the language directory exists
mkdirpSync(LANG_DIR);

/*
 * Aggregates the default messages that were extracted from the example app's
 * React components via the React Intl Babel plugin. An error will be thrown if
 * there are different messages that use the same `id`. The result
 * is a flat collection of `id: message` pairs for the app's default locale.
 */
const messages = globSync(MESSAGES_PATTERN)
  .map(filename => fs.readFileSync(filename, 'utf8'))
  .map(file => JSON.parse(file))
  .reduce((collection, descriptors) => {
    try {
      descriptors.forEach(({ id, defaultMessage, description }) => {
        if (collection[id] && collection[id].message !== defaultMessage) {
          throw new Error(`Duplicate message id: ${id}, Clearning the cache (intl/messages) might solve this.`);
        }

        // Chrome JSON format
        collection[id] = { message: defaultMessage, description };
      });
    } catch (error) {
      console.log(error);
      process.exit(1);
    }
    return collection;
  }, {});

// Sort messages by object key
const sortedMessages = sortObjectByKey(messages);

// Info
console.log(`\n${Object.keys(sortedMessages).length} translations found.`);

// Read existing source file
const existingSourceContents = fs.readFileSync(SOURCE_FILE, 'utf8');

// Contents of new source file
const newSourceContents = JSON.stringify(sortedMessages, null, 2);

// Write generated file
process.stdout.write('Writing translations source file...');
fs.writeFileSync(SOURCE_FILE, newSourceContents);
process.stdout.write(' done ✅ \n');

// Check if generated file has changed
if (!existingSourceContents || existingSourceContents !== newSourceContents) {
  console.log('\nGenerated translation file has changed.\n');
  process.stdout.write(`Uploading ${SOURCE_FILE} to Crowdin...`);

  // Run upload script
  const runUploadResult = executeCommand('sh', ['scripts/translation/uploadSource.sh']);
  if (runUploadResult) {
    process.stdout.write(' done ✅ \n');
  }
} else {
  console.log(`\n❌ Generated source file ${SOURCE_FILE} did NOT change.\n`);
}
