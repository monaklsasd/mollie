/* eslint no-console: 0, func-names: 0, no-param-reassign: 0 */
const fs = require('fs');
const sanitizeHtml = require('sanitize-html');
const exec = require('child_process').execSync;

// Load .env
require('dotenv').config();

const MESSAGES_DIR = './src/intl/';

// Convert Chrome JSON format object to key value object
const convertToKeyValueObject = data => {
  const convertedData = JSON.parse(data);
  const collection = {};

  Object.keys(convertedData)
    .sort()
    .forEach(key => {
      collection[key] = sanitizeHtml(convertedData[key].message, {
        allowedTags: [
          'b',
          'i',
          'em',
          'strong',
          'a',
          'p',
          'ul',
          'ol',
          'li',
          'h1',
          'h2',
          'h3',
          'h4',
          'br',
        ],
        allowedAttributes: {
          a: ['href', 'rel', 'target'],
        },
        allowedSchemes: sanitizeHtml.defaults.allowedSchemes.concat(['tel']),
        textFilter: text => text.replace('&amp;', '&'),
      });
    });

  return collection;
};

// Executes command and keeps quiet about it unless there's an error.
// Runs the command in bash shell, as we need to use arrays.
const executeCommand = cmd => {
  try {
    return exec(cmd, { stdio: ['pipe', 'pipe', 'ignore'], shell: '/bin/bash', encoding: 'utf8' });
  } catch (error) {
    return false;
  }
};

// Returns the emoji for a country given a locale
const emojiCountryFlagFromLocale = locale => {
  // Gets the last two chars and their hex UTF-16 code
  let firstChar = locale.toLowerCase().charCodeAt(locale.length - 2);
  let secondChar = locale.toLowerCase().charCodeAt(locale.length - 1);

  // Add 133 to match it to Emoji lettering definition
  firstChar += 133;
  secondChar += 133;

  // Turn those chars into Emojis in UTF Hex
  const firstPartEmoji = `0x1F1${firstChar.toString(16)}`;
  const secondPartEmoji = `0x1F1${secondChar.toString(16)}`;

  // Return the concatenated UTF codes that create the flag Emoji
  return `${String.fromCodePoint(firstPartEmoji)}${String.fromCodePoint(secondPartEmoji)}`;
};

// Break if Crowdin Key is not present
if (!process.env.CROWDIN_DASHBOARD_KEY) {
  console.log(
    'You do not have the Crowdin API key (https://crowdin.com/project/mollie-dashboard/settings#api), please update your .env file',
  );
  process.exit(1);
}

process.stdout.write('\nDownloading translation files from Crowdin...');

// Executes bash script that downloads the latest translations for the current branch
const runDownloadResult = executeCommand('. scripts/translation/downloadTranslations.bash');

// runDownloadResult will be 'Success' if cURL doesn't fail
if (runDownloadResult) {
  process.stdout.write(' done ✅ \n\n');
  fs.readdir('tmp/', (err, files) => {
    if (err || !files || files.length <= 0) {
      console.log('❌ Translation files folder from Crowdin is empty');
      return;
    }
    const writeResult = files.every(locale => {
      const origin = `tmp/${locale}/source.json`;
      // We need to handle problems with the downloaded folder.
      try {
        const file = fs.readFileSync(origin);

        const destination = `${MESSAGES_DIR}${locale}.ts`;
        const flag = emojiCountryFlagFromLocale(locale);
        process.stdout.write(`\n${flag}  > Writing translations to ${destination} `);

        // We convert the received format into the one we use.
        const keyValueObject = convertToKeyValueObject(file);
        const keyValueJson = JSON.stringify(keyValueObject, null, 4);

        // Write a Javascript file that exports the messages.
        const jsData = `// Auto generated file. Do no change. Go to Crowdin to update the translations and run 'yarn run translations:download' to update this file.\nexport default ${keyValueJson};`;

        fs.writeFileSync(destination, jsData);
        // Delete original file after it's been used
        fs.unlinkSync(origin);
        fs.rmdirSync(`tmp/${locale}/`);
        return true;
      } catch (error) {
        console.log(`❌ Could not read/write files: ${error.message}`);
        // We don't want to continue the loop if there's an error.
        return false;
      }
    });
    // Delete tmp folder after all is done
    if (writeResult) {
      fs.rmdirSync('tmp/');
      console.log(`\n\nWrote ${files.length} files.\n`);
    }
  });
} else {
  // cURL failed, check downloadTranslations.bash
  process.stdout.write(
    ' failed ❌ \n\nSomething went wrong downloading the translations, make sure your branch is present in Crowdin. \n\n',
  );
}
