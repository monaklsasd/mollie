module.exports = {
  overrides: [
    {
      files: ['./src/**/*.ts', './src/**/*.tsx'],
      plugins: ['import'],

      extends: [
        '@mollie/eslint-config-react',
        '@mollie/eslint-config-typescript',
        'prettier/@typescript-eslint',
      ],
      rules: {
        'import/named': 'off',
        'react-hooks/exhaustive-deps': 'warn',
        '@typescript-eslint/no-unused-vars': [
          'error',
          {
            argsIgnorePattern: '^_',
            ignoreRestSiblings: true,
          },
        ],
      },
    },
    {
      files: ['./src/**/*.test.ts', './src/**/*.test.tsx'],
      extends: [
        '@mollie/eslint-config-react',
        '@mollie/eslint-config-typescript',
        'prettier/@typescript-eslint',
      ],
      rules: {
        '@typescript-eslint/explicit-function-return-type': ['off'],
        '@typescript-eslint/no-empty-function': ['off'],
        '@typescript-eslint/ban-ts-ignore': ['off'],
        '@typescript-eslint/no-unused-vars': [
          'error',
          {
            argsIgnorePattern: '^_',
          },
        ],
      },
    },
  ],
};
