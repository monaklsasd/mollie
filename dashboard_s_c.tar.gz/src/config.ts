export const BING_ID = '5707763';
export const FACEBOOK_ID = '1706907912915336';
export const LINKEDIN_ID = '181898';
export const MIXPANEL_ID = '5bcebe52ff1334a77e826755c8902ae6';
