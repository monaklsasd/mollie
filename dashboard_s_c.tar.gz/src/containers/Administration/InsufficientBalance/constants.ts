export const MAXIMUM_ALLOWED_TOPUP_AMOUNT_REACHED = 'MaximumTopupAmountReached';
