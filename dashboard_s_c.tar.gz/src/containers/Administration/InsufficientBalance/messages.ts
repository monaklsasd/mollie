import { defineMessages } from 'react-intl';

const messages = defineMessages({
  topupLabel: {
    id: 'administration-balance-top-up-link',
    defaultMessage: 'top up your balance directly',
    description:
      'Note that this link is used in three scenarios: you have queued refunds, you have a negative balance, or both. Please check your translation matches for all scenarios.',
  },
  topupRemainingAmountLabel: {
    id: 'administration-balance-top-up-remaining-amount-link',
    defaultMessage: 'Top up your balance',
    description:
      'Note that this link is used in three scenarios: you have queued refunds, you have a negative balance, or both. Please check your translation matches for all scenarios.',
  },
  queuedRefunds: {
    id: 'administration-balance-queued-refunds',
    defaultMessage:
      'There {count, plural, one {is} other {are}} {count} queued {count, plural, one {refund} other {refunds}} with a total value of {amount} that cannot be processed due to insufficient balance. You can {topupLink} or {helpCenterLink} about queued refunds.',
    description: 'There are queued refunds.',
  },
  queuedRefundsAndNegativeBalance: {
    id: 'administration-balance-insufficient-funds',
    defaultMessage:
      'There {count, plural, one {is} other {are}} {count} queued {count, plural, one {refund} other {refunds}} and a negative balance, totalling {amount}. This amount will be settled when you receive new payments. You can also {topupLink}.',
    description: 'There are queued refunds and the balance is below 0.00.',
  },
  negativeBalance: {
    id: 'administration-balance-negative-balance',
    defaultMessage:
      'You have a negative balance of {amount}. This amount will be settled when you receive new payments. You can also {topupLink}.',
    description: 'There is a negative balance.',
  },
  queuedRefundsNoTopup: {
    id: 'administration-balance-queued-refunds-no-topup',
    defaultMessage:
      'There {count, plural, one {is} other {are}} {count} queued {count, plural, one {refund} other {refunds}} with a total value of {amount} that cannot be processed due to insufficient balance. You can {helpCenterLink} about queued refunds.',
    description:
      'There are queued refunds, but none of the enabled payment methods can be used for topup.',
  },
  queuedRefundsAndNegativeBalanceNoTopup: {
    id: 'administration-balance-insufficient-funds-no-topup',
    defaultMessage:
      'There {count, plural, one {is} other {are}} {count} queued refunds and a negative balance, totalling {amount}. This amount will be settled when you receive new payments.',
    description:
      'There are queued refunds and a negative balance, but none of the enabled payment methods can be used for topup.',
  },
  negativeBalanceNoTopup: {
    id: 'administration-balance-negative-balance-no-topup',
    defaultMessage:
      'You have a negative balance of {amount}. This amount will be settled when you receive new payments.',
    description:
      'There is a negative balance, but none of the enabled payment methods can be used for topup.',
  },
  queuedRefundsHelpLink: {
    id: 'administration-balance-queued-refunds-link',
    defaultMessage:
      "<a href='https://help.mollie.com/hc/en-us/articles/115002074973-Queued-refunds' target='_blank' rel='noopener'>read more information</a>",
  },
  partiallyToppedUpWithQueuedRefundsAndNegativeBalance: {
    id: 'administration-balance-partially-topped-up-queued-refunds-and-negative-balance',
    defaultMessage:
      'The payment method you used to top up your balance could not cover the total outstanding amount. {topupLink} with the remaining {amount} to process {count} queued {count, plural, one {refund} other {refunds}} and settle your negative balance.',
  },
  partiallyToppedUpWithQueuedRefunds: {
    id: 'administration-balance-partially-topped-up-queued-refunds',
    defaultMessage:
      'The payment method you used to top up your balance could not cover the total outstanding amount. {topupLink} with the remaining {amount} to process {count} queued {count, plural, one {refund} other {refunds}}.',
  },
  partiallyToppedUpWithNegativeBalance: {
    id: 'administration-balance-partially-topped-up-negative-balance',
    defaultMessage:
      'The payment method you used to top up your balance could not cover the total outstanding amount. {topupLink} with the remaining {amount} to settle your negative balance.',
  },
  topupFailed: {
    id: 'administration-balance-topup-failed',
    defaultMessage: 'Failed to top up your balance. Please reach out to our support team for help.',
  },
});

export default messages;
