/* eslint-disable @typescript-eslint/no-empty-function */
import React from 'react';
import createComponentWithIntl from 'helpers/createComponentWithIntl';

import { AdministrationInsufficientBalance } from '../index';
import { Permissions } from 'containers/RequirePermissions';

describe('<CurrentBalanceLedger>', () => {
  let props;

  beforeEach(() => {
    props = {
      grantedPermissions: [Permissions.SETTLEMENTS_READ, Permissions.BALANCES_READ],
      balance: { value: -20, currency: 'EUR' },
      showPartialTopupNotice: true,
      queuedRefunds: {
        quantity: 1,
        totalAmount: { value: 20 },
      },
      methods: [],
      location: {
        query: {},
      },
      showTopupModal: (): void => {},
    };
  });

  it('renders message for no payment methods, queued refunds and negative balance', () => {
    const tree = createComponentWithIntl(<AdministrationInsufficientBalance {...props} />).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('renders message for no payment methods and queued refunds', () => {
    const changedProps = {
      balance: { value: 20 },
    };
    const tree = createComponentWithIntl(
      <AdministrationInsufficientBalance {...props} {...changedProps} />,
    ).toJSON();

    expect(tree).toMatchSnapshot();
  });

  it('renders message for no payment methods and negative balance', () => {
    const changedProps = {
      queuedRefunds: {},
    };
    const tree = createComponentWithIntl(
      <AdministrationInsufficientBalance {...props} {...changedProps} />,
    ).toJSON();

    expect(tree).toMatchSnapshot();
  });

  it('renders message for queued refunds and negative balance', () => {
    const changedProps = {
      methods: ['dummy'],
    };
    const tree = createComponentWithIntl(
      <AdministrationInsufficientBalance {...props} {...changedProps} />,
    ).toJSON();

    expect(tree).toMatchSnapshot();
  });

  it('renders message for negative balance', () => {
    const changedProps = {
      balance: { value: 20 },
      methods: ['dummy'],
    };
    const tree = createComponentWithIntl(
      <AdministrationInsufficientBalance {...props} {...changedProps} />,
    ).toJSON();

    expect(tree).toMatchSnapshot();
  });

  it('renders null if no permissions', () => {
    const changedProps = {
      grantedPermissions: [],
    };
    const tree = createComponentWithIntl(
      <AdministrationInsufficientBalance {...props} {...changedProps} />,
    ).toJSON();

    expect(tree).toMatchSnapshot();
  });

  it('renders null if ledger and not enough permissions', () => {
    const changedProps = {
      usesLedgerFeeSystem: true,
      grantedPermissions: [Permissions.SETTLEMENTS_READ],
    };
    const tree = createComponentWithIntl(
      <AdministrationInsufficientBalance {...props} {...changedProps} />,
    ).toJSON();

    expect(tree).toMatchSnapshot();
  });
});
