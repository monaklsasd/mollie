import * as React from 'react';
import { connect } from 'react-redux';
import { FormattedMessage, FormattedHTMLMessage, FormattedNumber } from 'react-intl';
import { withRouter } from 'react-router-dom';
import { get } from 'lodash';

import Currency from 'components/UI/Currency';
import FlashMessage from 'components/UI/FlashMessage';
import Link from 'components/UI/Link';

// Permissions
import { hasPermissions, Permissions } from 'containers/RequirePermissions';

// Redux
import { getPaymentMethodsForTopup } from 'reduxState/modules/profiles/selectors';
import { setVisible } from 'containers/TopupModal/actions';
import { grantedPermissionsSelector } from 'reduxState/modules/permissions';
import { getHasFeatureToggles } from 'reduxState/modules/application/selectors';

// Types
import { Amount } from 'reduxState/types';
import { Location } from 'history';
import { AvailablePermissions } from 'helpers/permissions';

// Internals
import messages from './messages';
import { MAXIMUM_ALLOWED_TOPUP_AMOUNT_REACHED } from './constants';

// Constants
import { LEDGER_FEE_SYSTEM } from 'reduxState/modules/application/constants';

type Props = {
  balance: Amount;
  grantedPermissions: AvailablePermissions[];
  showPartialTopupNotice: boolean;
  queuedRefunds: {
    quantity: number;
    totalAmount: Amount;
  };
  methods: {
    [id: string]: string;
  }[];
  location: Location & {
    query: Record<string, any>;
  };
  showTopupModal: React.MouseEventHandler;
  usesLedgerFeeSystem: boolean;
};

type State = {
  message: React.ReactNode;
  topupFailed: boolean;
};

export class AdministrationInsufficientBalance extends React.Component<Props, State> {
  state = {
    message: '',
    topupFailed: false,
  };

  componentDidMount(): void {
    if (!this.canRender()) {
      return;
    }
    this.setTopupMessage();
  }

  canRender = (): boolean => {
    const { usesLedgerFeeSystem, grantedPermissions } = this.props;

    if (usesLedgerFeeSystem) {
      return hasPermissions(grantedPermissions, [Permissions.BALANCES_READ]);
    }
    return hasPermissions(grantedPermissions, [Permissions.SETTLEMENTS_READ]);
  };

  setTopupMessage(): void {
    const { showTopupModal, methods, queuedRefunds, balance, location } = this.props;
    /*
     * Merchant topped up their balance directly, but the total outstanding balance could not be covered by the selected
     * payment method.
     */
    const balanceWasPartiallyToppedUp =
      get(location, 'query.partial_topup_notification') === MAXIMUM_ALLOWED_TOPUP_AMOUNT_REACHED;

    this.setState({
      topupFailed: get(location, 'query.topup') === 'failed',
    });

    const topupLink = (
      <Link onClick={showTopupModal}>
        <FormattedMessage
          {...(balanceWasPartiallyToppedUp
            ? messages.topupRemainingAmountLabel
            : messages.topupLabel)}
        />
      </Link>
    );

    // Queued refunds and negative balance, but no valid topup methods enabled
    if (!methods.length && queuedRefunds.quantity > 0 && Number(balance.value) < 0) {
      return this.setState({
        message: (
          <FormattedMessage
            {...messages.queuedRefundsAndNegativeBalanceNoTopup}
            values={{
              count: queuedRefunds.quantity,
              amount: (
                <Currency
                  currency={balance.currency}
                  value={Math.abs(Number(balance.value)) + Number(queuedRefunds.totalAmount.value)}
                />
              ),
            }}
          />
        ),
      });
    }

    // Queued refunds but no valid topup methods enabled
    if (!methods.length && queuedRefunds.quantity > 0) {
      return this.setState({
        message: (
          <FormattedMessage
            {...messages.queuedRefundsNoTopup}
            values={{
              count: queuedRefunds.quantity,
              amount: <Currency {...queuedRefunds.totalAmount} />,
              helpCenterLink: <FormattedHTMLMessage {...messages.queuedRefundsHelpLink} />,
            }}
          />
        ),
      });
    }

    // Negative balance but no valid topup methods enabled
    if (!methods.length && Number(balance.value) < 0) {
      return this.setState({
        message: (
          <FormattedMessage
            {...messages.negativeBalanceNoTopup}
            values={{
              amount: (
                <FormattedNumber
                  format={balance.currency || undefined}
                  value={Number(balance.value)}
                />
              ),
            }}
          />
        ),
      });
    }

    // Queued refunds and negative balance
    if (queuedRefunds.quantity > 0 && Number(balance.value) < 0) {
      return this.setState({
        message: (
          <FormattedMessage
            {...(balanceWasPartiallyToppedUp
              ? messages.partiallyToppedUpWithQueuedRefundsAndNegativeBalance
              : messages.queuedRefundsAndNegativeBalance)}
            values={{
              count: queuedRefunds.quantity,
              amount: (
                <Currency
                  currency={balance.currency}
                  value={Math.abs(Number(balance.value)) + Number(queuedRefunds.totalAmount.value)}
                />
              ),
              topupLink,
            }}
          />
        ),
      });
    }

    // Queued refunds
    if (queuedRefunds.quantity > 0) {
      return this.setState({
        message: (
          <FormattedMessage
            {...(balanceWasPartiallyToppedUp
              ? messages.partiallyToppedUpWithQueuedRefunds
              : messages.queuedRefunds)}
            values={{
              count: queuedRefunds.quantity,
              amount: <Currency {...queuedRefunds.totalAmount} />,
              helpCenterLink: <FormattedHTMLMessage {...messages.queuedRefundsHelpLink} />,
              topupLink,
            }}
          />
        ),
      });
    }

    // Negative balance
    return this.setState({
      message: (
        <FormattedMessage
          {...(balanceWasPartiallyToppedUp
            ? messages.partiallyToppedUpWithNegativeBalance
            : messages.negativeBalance)}
          values={{
            amount: <Currency {...balance} />,
            topupLink,
          }}
        />
      ),
    });
  }

  render(): React.ReactNode {
    if (!this.canRender()) {
      return null;
    }

    if (this.state.topupFailed) {
      return (
        <FlashMessage state="error">
          <FormattedMessage {...messages.topupFailed} />
        </FlashMessage>
      );
    }
    return <FlashMessage state="warning">{this.state.message}</FlashMessage>;
  }
}
const mapDispatchToProps = {
  showTopupModal: setVisible,
};
const mapStateToProps = (state, props) => ({
  methods: getPaymentMethodsForTopup(state, props),
  grantedPermissions: grantedPermissionsSelector(state),
  usesLedgerFeeSystem: getHasFeatureToggles([LEDGER_FEE_SYSTEM])(state),
});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(AdministrationInsufficientBalance),
);
