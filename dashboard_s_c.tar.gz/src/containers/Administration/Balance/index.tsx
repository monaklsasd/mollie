import React, { Component } from 'react';
import { connect } from 'react-redux';
import Helmet from 'react-helmet';
import { FormattedMessage, injectIntl } from 'react-intl';

// Containers
import InsufficientBalance from 'containers/Administration/InsufficientBalance';
import PageWrapper from 'containers/PageWrapper';
import StatementDownloads from 'components/StatementDownloads';
import RequirePermissions, { Permissions } from 'containers/RequirePermissions';

// Components
import AdministrationCostsTable from 'components/Administration/AdministrationCostsTable';
import AdministrationTable from 'components/Administration/AdministrationTable';
import Empty from 'components/UI/Empty';
import FlashMessage from 'components/UI/FlashMessage';
import Layout from 'components/UI/Layout';
import LoadingState from 'components/UI/LoadingState';
import ButtonGroup from 'components/UI/ButtonGroup';
import AdministrationYearOverviewDownload from 'components/Administration/AdministrationYearOverviewDownload';
import Wrapper from 'components/UI/Wrapper';

// Redux
import { getSettlementById } from 'reduxState/modules/settlements/selectors';
import { SETTLEMENT_ID_NEXT, SETTLEMENT_ID_OPEN } from 'reduxState/modules/settlements/constants';
import {
  fetchBalance,
  getCurrentBalance,
  getDiscountCampaign,
  getQueuedRefunds,
} from 'reduxState/modules/balance';

// Utils
import groupSettlementByType from 'containers/Administration/groupSettlementByType';
import hasInsufficientBalance from 'utils/hasInsufficientBalance';

// Types
import { IntlShape } from 'react-intl';
import { SettlementType } from 'reduxState/modules/settlements/types';
import { Amount } from 'reduxState/types';
import { DiscountCampaignType } from 'reduxState/modules/balance';
import { ReduxState } from 'types/state';

// Internals
import Sidebar from './Sidebar';
import { fetchSettlement } from './actions';
import * as selectors from './selectors';
import messages from './messages';

type Props = {
  openSettlement: Nullable<SettlementType>;
  nextSettlement: Nullable<SettlementType>;
  queuedRefunds: {
    totalAmount: Amount;
    quantity: number | null;
  };
  balance: Nullable<Amount>;
  fetchBalance: typeof fetchBalance;
  fetchSettlement: typeof fetchSettlement;
  isLoadingNext?: Nullable<boolean>;
  isLoadingOpen?: Nullable<boolean>;
  isLoadedOpen?: Nullable<boolean>;
  error?: Nullable<string>;
  intl: IntlShape;
  discountCampaign: Nullable<DiscountCampaignType>;
};

export class AdministrationBalance extends Component<Props> {
  componentDidMount(): void {
    const { fetchBalance, fetchSettlement } = this.props;

    fetchBalance();
    fetchSettlement({
      id: SETTLEMENT_ID_NEXT,
    });
    fetchSettlement({
      id: SETTLEMENT_ID_OPEN,
    });
  }

  renderBalance(): React.ReactElement {
    const { openSettlement, error, isLoadingOpen, isLoadingNext } = this.props;

    // Error view
    if (error) {
      return <FlashMessage state="error">{error}</FlashMessage>;
    }

    if (!openSettlement || isLoadingOpen || isLoadingNext) {
      return <LoadingState isLoading />;
    }

    // Empty view
    if (!openSettlement || !openSettlement.periods || !Object.keys(openSettlement.periods).length) {
      return <Empty title={<FormattedMessage {...messages.noOpenFound} />} />;
    }

    const { costs, deductions, revenue } = groupSettlementByType(openSettlement.periods);

    return (
      <React.Fragment>
        <AdministrationTable rows={revenue} type="revenue" />
        <AdministrationTable rows={deductions} type="deductions" />
        <AdministrationCostsTable rows={costs} />
      </React.Fragment>
    );
  }

  render(): React.ReactElement {
    const {
      intl,
      nextSettlement,
      openSettlement,
      balance,
      queuedRefunds,
      isLoadedOpen,
      discountCampaign,
    } = this.props;

    return (
      <PageWrapper
        title={<FormattedMessage {...messages.pageTitle} />}
        actions={
          <ButtonGroup>
            <RequirePermissions permissions={[Permissions.SETTLEMENTS_READ]}>
              <AdministrationYearOverviewDownload />
            </RequirePermissions>
            <StatementDownloads />
          </ButtonGroup>
        }>
        <Wrapper isLast>
          {hasInsufficientBalance(balance, queuedRefunds) && (
            <InsufficientBalance queuedRefunds={queuedRefunds} balance={balance} />
          )}

          <Layout
            sidebar={
              <Sidebar
                isLoaded={isLoadedOpen || null}
                nextSettlement={nextSettlement as SettlementType}
                openSettlement={openSettlement as SettlementType}
                discountCampaign={discountCampaign}
              />
            }>
            <Helmet title={intl.formatMessage(messages.pageTitle)} />
            {this.renderBalance()}
          </Layout>
        </Wrapper>
      </PageWrapper>
    );
  }
}

const mapStateToProps = (state: ReduxState) => ({
  isLoadedOpen: selectors.isLoaded(state, SETTLEMENT_ID_OPEN),
  isLoadingNext: selectors.isLoading(state, SETTLEMENT_ID_NEXT),
  isLoadingOpen: selectors.isLoading(state, SETTLEMENT_ID_OPEN),
  error: selectors.getError(state, SETTLEMENT_ID_OPEN),
  openSettlement: getSettlementById(state, SETTLEMENT_ID_OPEN),
  nextSettlement: getSettlementById(state, SETTLEMENT_ID_NEXT),
  balance: getCurrentBalance(state),
  queuedRefunds: getQueuedRefunds(state),
  discountCampaign: getDiscountCampaign(state) || null,
});

const mapDispatchToProps = {
  fetchBalance,
  fetchSettlement,
};

export default connect(mapStateToProps, mapDispatchToProps)(injectIntl(AdministrationBalance));
