export interface ItemType {
  isLoading?: Nullable<boolean>;
  isLoaded?: Nullable<boolean>;
  error?: Nullable<string>;
  statusCode?: Nullable<number>;
}

export interface AdministrationBalanceState {
  [key: string]: ItemType;
}
