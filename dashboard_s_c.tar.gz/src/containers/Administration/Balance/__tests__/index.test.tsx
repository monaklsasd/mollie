import { expectSaga } from 'redux-saga-test-plan';

import { SETTLEMENT_ID_OPEN, SETTLEMENT_ID_NEXT } from 'reduxState/modules/settlements/constants';
import * as sagas from '../sagas';
import * as actions from '../actions';
import reducer, { initialState } from '../reducer';

// Mock Date.now() function so it always returns 01-01-2017 00:00:00
Date.now = jest.fn().mockReturnValue(1483228800000);

describe('Administration/AdministrationBalance', () => {
  it('should successfully fetch open settlement', () => {
    const response = {
      data: [
        {
          resource: 'settlement',
          id: SETTLEMENT_ID_OPEN,
          createdDatetime: '2017-01-10T14:06:21.0Z',
          settledDatetime: '2017-01-11T14:06:21.0Z',
          reference: '0002.1701.01',
          status: 'paidout',
        },
      ],
    };

    return (
      expectSaga(sagas.watchFetchSettlement)
        // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
        // @ts-ignore
        .withReducer(reducer, initialState)
        .provide({
          call(_effect, _next) {
            return { response };
          },
        })
        .put(actions.fetchSettlementSuccess(response, SETTLEMENT_ID_OPEN))
        .dispatch(
          actions.fetchSettlement({
            id: SETTLEMENT_ID_OPEN,
          }),
        )
        .hasFinalState({
          [SETTLEMENT_ID_OPEN]: {
            isLoading: false,
            isLoaded: true,
            error: null,
            statusCode: null,
          },
          [SETTLEMENT_ID_NEXT]: initialState[SETTLEMENT_ID_NEXT],
        })
        .run({ silenceTimeout: true })
    );
  });

  it('state contains an error when fetching of open settlement fails', () => {
    const errorResponse = {
      error: {
        message: 'Oh no, you failed!',
      },
    };

    const status = 500;

    return (
      expectSaga(sagas.watchFetchSettlement)
        // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
        // @ts-ignore
        .withReducer(reducer, initialState)
        .provide({
          call(_effect, _next) {
            return { errorResponse, status };
          },
        })
        .put(
          actions.fetchSettlementFailure({
            error: errorResponse.error.message,
            id: SETTLEMENT_ID_OPEN,
            status,
          }),
        )
        .dispatch(
          actions.fetchSettlement({
            id: SETTLEMENT_ID_OPEN,
          }),
        )
        .hasFinalState({
          [SETTLEMENT_ID_OPEN]: {
            isLoaded: false,
            isLoading: false,
            error: errorResponse.error.message,
            statusCode: 500,
          },
          [SETTLEMENT_ID_NEXT]: initialState[SETTLEMENT_ID_NEXT],
        })
        .run({ silenceTimeout: true })
    );
  });
});
