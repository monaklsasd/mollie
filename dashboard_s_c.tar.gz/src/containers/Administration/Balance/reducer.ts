import * as constants from './constants';
import { SETTLEMENT_ID_NEXT, SETTLEMENT_ID_OPEN } from 'reduxState/modules/settlements/constants';
import { AdministrationBalanceState, ItemType } from './types';
import { ActionType } from 'reduxState/types';
import { Reducer } from 'redux';

export const initialState = {
  [SETTLEMENT_ID_OPEN]: {
    isLoading: false,
    isLoaded: false,
    error: null,
    statusCode: null,
  },
  [SETTLEMENT_ID_NEXT]: {
    isLoading: false,
    isLoaded: false,
    error: null,
    statusCode: null,
  },
};

type GenericPayload = {
  id: string;
  error?: string;
  status: number;
};

const itemReducer: Reducer<ItemType, ActionType<any, GenericPayload>> = (state = {}, action) => {
  switch (action.type) {
    case constants.FETCH_SETTLEMENT:
      return {
        ...state,
        isLoading: true,
      };

    case constants.FETCH_SETTLEMENT_FAILURE:
      return {
        ...state,
        error: action.payload.error || null,
        statusCode: action.payload.status,
        isLoading: false,
      };

    case constants.FETCH_SETTLEMENT_SUCCESS:
      return {
        ...state,
        isLoaded: true,
        isLoading: false,
      };

    default:
      return state;
  }
};

const reducer: Reducer<AdministrationBalanceState, ActionType<any, GenericPayload>> = (
  state = initialState,
  action,
) => {
  switch (action.type) {
    case constants.FETCH_SETTLEMENT:
    case constants.FETCH_SETTLEMENT_FAILURE:
    case constants.FETCH_SETTLEMENT_SUCCESS:
      return {
        ...state,
        [action.payload.id]: itemReducer(state[action.payload.id], action),
      };

    default:
      return state;
  }
};

export default reducer;
