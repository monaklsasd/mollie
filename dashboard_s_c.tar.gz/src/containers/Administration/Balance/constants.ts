export const FETCH_SETTLEMENT = 'AdministrationBalance/FETCH_SETTLEMENT';
export const FETCH_SETTLEMENT_SUCCESS = 'AdministrationBalance/FETCH_SETTLEMENT_SUCCESS';
export const FETCH_SETTLEMENT_FAILURE = 'AdministrationBalance/FETCH_SETTLEMENT_FAILURE';
