import createApiActions from 'reduxState/factories/createApiActions';
import { FETCH_SETTLEMENT, FETCH_SETTLEMENT_FAILURE, FETCH_SETTLEMENT_SUCCESS } from './constants';

export const {
  execute: fetchSettlement,
  success: fetchSettlementSuccess,
  failure: fetchSettlementFailure,
} = createApiActions({
  types: {
    execute: FETCH_SETTLEMENT,
    success: FETCH_SETTLEMENT_SUCCESS,
    failure: FETCH_SETTLEMENT_FAILURE,
  },
});
