import { takeEvery, put, call } from 'redux-saga/effects';

import { fetchSettlement } from 'services/api';
import { callApi } from 'reduxState/sagas/api';

import * as actions from './actions';
import * as constants from './constants';

export function* fetchSettlementRoutine({ payload: { id } }): Generator<any, any, any> {
  const { response, errorResponse, status } = yield call(callApi, fetchSettlement, id);

  if (response) {
    yield put(actions.fetchSettlementSuccess(response, id));
  } else if (errorResponse && errorResponse.error) {
    yield put(
      actions.fetchSettlementFailure({
        error: errorResponse.error.message,
        id,
        status,
      }),
    );
  }
}

export function* watchFetchSettlement(): Generator<any, any, any> {
  // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
  // @ts-ignore
  yield takeEvery(constants.FETCH_SETTLEMENT, fetchSettlementRoutine);
}
