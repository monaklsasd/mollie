import { defineMessages } from 'react-intl';
import { IntlMessages } from 'types/intl';

const messages: IntlMessages = defineMessages({
  pageTitle: {
    id: 'balance-page-title',
    defaultMessage: 'Current balance',
  },
  notFound: {
    id: 'balance-no-open-balance-found',
    defaultMessage: 'No open balance found',
  },
  noOpenFound: {
    id: 'balance-no-open-balance-found',
    defaultMessage: 'No open balance found',
  },
  currentBalance: {
    id: 'balance-current-balance',
    defaultMessage: 'Current balance',
  },
  revenue: {
    id: 'balance-revenue',
    defaultMessage: 'Revenue',
  },
  deductions: {
    id: 'balance-deductions',
    defaultMessage: 'Deductions',
  },
  costs: {
    id: 'balance-costs',
    defaultMessage: 'Costs',
  },
  total: {
    id: 'balance-total',
    defaultMessage: 'Total',
  },
  nextSettlement: {
    id: 'balance-next-settlement',
    defaultMessage: 'Next settlement',
  },
  pendingSettlement: {
    id: 'balance-pending-settlement',
    defaultMessage: 'Pending settlement',
  },
  explanation: {
    id: 'balance-pending-settlement-explanation',
    defaultMessage:
      'We received this amount, but can’t pay it out yet, either because your account isn’t fully verified yet, or because the payments have been made by credit card, SOFORT Banking, or SEPA Direct Debit. More information is available in our {link}.',
  },
  explanationLink: {
    id: 'balance-pending-settlement-explanation-hc-link',
    defaultMessage:
      "<a href='https://help.mollie.com/hc/en-us/articles/115003151689' target='_blank' rel='noopener'>Help Center</a>",
  },
  noTestmodeSupport: {
    id: 'balance-no-testmode-support',
    defaultMessage: 'Current balance does not support test mode yet.',
  },
  freeProcessingVolume: {
    id: 'balance-free-processing-volume',
    defaultMessage: 'Free processing volume',
  },
  remainingBudget: {
    id: 'balance-remaining-budget',
    defaultMessage: 'Remaining budget',
  },
  usedBudget: {
    id: 'balance-used-budget',
    defaultMessage: 'Used',
  },
  totalBudget: {
    id: 'balance-total-budget',
    defaultMessage: 'Budget',
  },
});

export default messages;
