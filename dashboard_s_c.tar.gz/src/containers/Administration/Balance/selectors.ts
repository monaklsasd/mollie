import { AdministrationBalanceState } from 'containers/Administration/Balance/types';
import { State } from 'reduxState/types';

const getState = (state: State): AdministrationBalanceState => state.administrationBalance;

export const isLoading = (
  state: State,
  id: string,
): AdministrationBalanceState[any]['isLoading'] => {
  const balance = getState(state);

  return balance[id].isLoading;
};

export const isLoaded = (state: State, id: string): AdministrationBalanceState[any]['isLoaded'] => {
  const balance = getState(state);

  return balance[id].isLoaded;
};

export const getError = (state: State, id: string): AdministrationBalanceState[any]['error'] => {
  const balance = getState(state);

  return balance[id].error;
};
