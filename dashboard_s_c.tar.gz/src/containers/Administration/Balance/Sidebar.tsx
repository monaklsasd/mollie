import React from 'react';
import { FormattedMessage, FormattedHTMLMessage, FormattedDate } from 'react-intl';

// Components
import { SidebarList, SidebarTerm, SidebarTermWrapper } from 'components/UI/SidebarList';
import LoadingState from 'components/UI/LoadingState';

import messages from './messages';

// Helper functions.
import calculateSettlementAmounts from 'utils/calculateSettlementAmounts';
import { SettlementType } from 'reduxState/modules/settlements/types';

const getNextSettlementDate = (
  nextSettlement: SettlementType | {},
): React.ReactElement<typeof FormattedDate> | null => {
  if ((nextSettlement as SettlementType).settledDatetime) {
    return <FormattedDate value={new Date((nextSettlement as SettlementType).settledDatetime)} />;
  }

  if ((nextSettlement as SettlementType).createdDatetime) {
    return <FormattedDate value={new Date((nextSettlement as SettlementType).createdDatetime)} />;
  }

  return null;
};

type Props = {
  openSettlement: SettlementType;
  nextSettlement?: SettlementType;
  isLoaded: Nullable<boolean>;
  discountCampaign: Nullable<Record<string, any>>;
};

const Sidebar: React.FC<Props> = ({
  openSettlement,
  isLoaded,
  nextSettlement = {},
  discountCampaign,
}) => {
  if (!isLoaded) {
    return <LoadingState isLoading={!isLoaded} compact delay={0} />;
  }

  const { totalRevenue, totalDeductions, totalCosts } = calculateSettlementAmounts(openSettlement);
  const currentBalance = totalRevenue - totalDeductions - totalCosts;
  const nextSettlementAmount = nextSettlement.amount ? parseFloat(nextSettlement.amount) : 0.0;
  const pendingSettlement = totalRevenue - totalDeductions - totalCosts - nextSettlementAmount;

  const pendingSettlementAmount = pendingSettlement > 0 ? pendingSettlement : 0;
  const nextSettlementDate = getNextSettlementDate(nextSettlement);
  const nextSettlementBalance = currentBalance - pendingSettlementAmount;

  return (
    <React.Fragment>
      {discountCampaign && (
        <SidebarList title={<FormattedMessage {...messages.freeProcessingVolume} />}>
          <SidebarTermWrapper>
            <SidebarTerm
              label={<FormattedMessage {...messages.totalBudget} />}
              {...discountCampaign.budgetVolume}
            />
            <SidebarTerm
              label={<FormattedMessage {...messages.usedBudget} />}
              {...discountCampaign.usedBudget}
            />
            <SidebarTerm
              isFooter
              label={<FormattedMessage {...messages.remainingBudget} />}
              {...discountCampaign.remainingBudget}
            />
          </SidebarTermWrapper>
        </SidebarList>
      )}
      <SidebarList title={<FormattedMessage {...messages.currentBalance} />}>
        <SidebarTermWrapper>
          <SidebarTerm
            currency="EUR"
            label={<FormattedMessage {...messages.revenue} />}
            value={totalRevenue}
          />
          <SidebarTerm
            currency="EUR"
            label={<FormattedMessage {...messages.deductions} />}
            value={totalDeductions}
          />
          <SidebarTerm
            currency="EUR"
            label={<FormattedMessage {...messages.costs} />}
            value={totalCosts}
          />

          <SidebarTerm
            isFooter
            currency="EUR"
            label={<FormattedMessage {...messages.total} />}
            value={currentBalance}
          />
        </SidebarTermWrapper>
      </SidebarList>
      <SidebarList
        title={<FormattedMessage {...messages.nextSettlement} />}
        subtitle={nextSettlementDate}>
        <SidebarTermWrapper>
          <SidebarTerm
            currency="EUR"
            label={<FormattedMessage {...messages.currentBalance} />}
            value={currentBalance}
          />
          <SidebarTerm
            currency="EUR"
            value={pendingSettlementAmount}
            label={<FormattedMessage {...messages.pendingSettlement} />}
            additionalInfo={
              <FormattedMessage
                {...messages.explanation}
                values={{
                  link: <FormattedHTMLMessage {...messages.explanationLink} />,
                }}
              />
            }
          />
          <SidebarTerm
            isFooter
            currency="EUR"
            label={<FormattedMessage {...messages.total} />}
            value={nextSettlementBalance}
          />
        </SidebarTermWrapper>
      </SidebarList>
    </React.Fragment>
  );
};

export default Sidebar;
