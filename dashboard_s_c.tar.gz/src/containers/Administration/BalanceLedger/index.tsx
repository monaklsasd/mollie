import React from 'react';
import Helmet from 'react-helmet';
import { useIntl } from 'react-intl';

// Containers
import PageWrapper from 'containers/PageWrapper';

// Components
import Wrapper from 'components/UI/Wrapper';
import Layout from 'components/UI/Layout';

// Internals
import messages from './messages';
import BalanceTransactions from './BalanceTransactions';
import Sidebar from './Sidebar';

const EventsPage: React.FC = () => {
  const intl = useIntl();
  return (
    <PageWrapper title={intl.formatMessage(messages.title)}>
      <Helmet title={intl.formatMessage(messages.title)} />

      <Wrapper isLast>
        <Layout sidebar={<Sidebar />}>
          <BalanceTransactions />
        </Layout>
      </Wrapper>
    </PageWrapper>
  );
};

export default EventsPage;
