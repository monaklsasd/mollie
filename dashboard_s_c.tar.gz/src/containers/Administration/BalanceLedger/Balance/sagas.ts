import { takeLatest, take, put, call, fork, delay } from 'redux-saga/effects';
import { fetchBalanceLedger } from 'services/api';
import { callApi } from 'reduxState/sagas/api';

import * as actions from './actions';
import * as constants from './constants';

export function* fetchBalanceRoutine({
  payload,
}: {
  payload: { id: string };
}): Generator<any, any, any> {
  const { response, errorResponse, status } = yield call(callApi, fetchBalanceLedger, payload.id);
  if (response) {
    yield put(actions.fetchBalanceSuccess(response, payload.id));
  } else if (errorResponse && errorResponse.error) {
    yield put(
      actions.fetchBalanceFailure({
        error: errorResponse.error.message,
        status,
      }),
    );
  }
}

export function* watchFetchBalancesEventsBalance(): Generator<any, any, any> {
  // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
  // @ts-ignore
  yield takeLatest(constants.FETCH_BALANCE, fetchBalanceRoutine);
}

export function* watchRefreshBalanceLedger(): Generator<any, any, any> {
  yield take(constants.FETCH_BALANCE);

  while (true) {
    // We want to fetch the balance every x seconds, this delay prevents the next
    // request from firing immediately.
    yield delay(constants.REFRESH_TIMEOUT);
    yield fork(fetchBalanceRoutine, { payload: { id: 'default' } });
  }
}
