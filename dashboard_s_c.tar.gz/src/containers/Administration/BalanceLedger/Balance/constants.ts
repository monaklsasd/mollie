export const FETCH_BALANCE = 'BalancesEventsBalance/FETCH_BALANCE';
export const FETCH_BALANCE_SUCCESS = 'BalancesEventsBalance/FETCH_BALANCE_SUCCESS';
export const FETCH_BALANCE_FAILURE = 'BalancesEventsBalance/FETCH_BALANCE_FAILURE';

export const REFRESH_TIMEOUT = 120000; // 2 minutes in ms
