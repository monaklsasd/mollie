import { BalancesEventBalanceState } from './types';
import { State } from 'reduxState/types';

const getStateById = (state: State, id: string): BalancesEventBalanceState[any] =>
  state.balancesEventBalance[id];

export const isLoading = (
  state: State,
  id: string,
): BalancesEventBalanceState[any]['isLoading'] => {
  const balance = getStateById(state, id);

  return balance ? balance.isLoading : false;
};

export const isLoaded = (state: State, id: string): BalancesEventBalanceState[any]['isLoaded'] => {
  const balance = getStateById(state, id);

  return balance ? balance.isLoaded : false;
};

export const getError = (state: State, id: string): BalancesEventBalanceState[any]['error'] => {
  const balance = getStateById(state, id);

  return balance ? balance.error : null;
};
