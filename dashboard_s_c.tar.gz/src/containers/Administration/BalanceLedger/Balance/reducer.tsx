import { combineReducers } from 'redux';

// Internal
import * as constants from './constants';

// Types
import { ActionType } from 'reduxState/types';
import { Reducer } from 'redux';
import { BalancesEventBalanceState, BalancesEventBalanceType } from './types';

const initialState: BalancesEventBalanceState = {};

const initialBalancesEventBalanceState: BalancesEventBalanceType = {
  error: null,
  isLoaded: false,
  isLoading: false,
  balanceId: null,
};

const error: Reducer<BalancesEventBalanceType['error'], ActionType<any, { error: string }>> = (
  state = initialBalancesEventBalanceState.error,
  action,
) => {
  switch (action.type) {
    case constants.FETCH_BALANCE_FAILURE:
      return action.payload.error;
    case constants.FETCH_BALANCE_SUCCESS:
      return null;
    default:
      return state;
  }
};

const isLoaded: Reducer<BalancesEventBalanceType['isLoaded'], ActionType> = (
  state = initialBalancesEventBalanceState.isLoaded,
  action,
) => {
  switch (action.type) {
    case constants.FETCH_BALANCE_SUCCESS:
      return true;
    default:
      return state;
  }
};

const isLoading: Reducer<BalancesEventBalanceType['isLoading'], ActionType> = (
  state = initialBalancesEventBalanceState.isLoading,
  action,
) => {
  switch (action.type) {
    case constants.FETCH_BALANCE:
      return true;
    case constants.FETCH_BALANCE_SUCCESS:
    case constants.FETCH_BALANCE_FAILURE:
      return false;
    default:
      return state;
  }
};

const balanceId: Reducer<BalancesEventBalanceType['balanceId'], ActionType<any, { id: string }>> = (
  state = initialBalancesEventBalanceState.balanceId,
  action,
) => {
  switch (action.type) {
    case constants.FETCH_BALANCE:
      return action.payload.id;
    default:
      return state;
  }
};

const balancesBalanceReducers = combineReducers({
  isLoading,
  isLoaded,
  error,
  balanceId,
});

const balancesBalanceReducer: Reducer<
  BalancesEventBalanceState,
  ActionType<any, { id: string }>
> = (state = initialState, action) => {
  switch (action.type) {
    case constants.FETCH_BALANCE:
    case constants.FETCH_BALANCE_SUCCESS:
    case constants.FETCH_BALANCE_FAILURE:
      return {
        ...state,
        [action.payload.id]: balancesBalanceReducers(state[action.payload.id], action),
      };
    default:
      return state;
  }
};

export default balancesBalanceReducer;
