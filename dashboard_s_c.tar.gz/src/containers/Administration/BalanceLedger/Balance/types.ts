export interface BalancesEventBalanceType {
  isLoading: boolean;
  isLoaded: boolean;
  error: Nullable<string>;
  balanceId: Nullable<string>;
}

export interface BalancesEventBalanceState {
  [key: string]: BalancesEventBalanceType;
}
