import createApiActions from 'reduxState/factories/createApiActions';
import * as constants from './constants';

export const {
  execute: fetchBalance,
  success: fetchBalanceSuccess,
  failure: fetchBalanceFailure,
} = createApiActions({
  types: {
    execute: constants.FETCH_BALANCE,
    success: constants.FETCH_BALANCE_SUCCESS,
    failure: constants.FETCH_BALANCE_FAILURE,
  },
});
