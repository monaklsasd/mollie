import { defineMessages } from 'react-intl';
import { IntlMessages } from 'types/intl';

const messages: IntlMessages = defineMessages({
  title: {
    id: 'balance-ledger-title',
    defaultMessage: 'Balance',
  },
  sidebarBalance: {
    id: 'balance-ledger-sidebar-balance',
    defaultMessage: 'Balance',
  },
  sidebarBalanceOnHold: {
    id: 'balance-ledger-sidebar-balance-on-hold',
    defaultMessage: 'On hold',
  },
  sidebarBalanceAvailable: {
    id: 'balance-ledger-sidebar-balance-available',
    defaultMessage: 'Available',
  },
  sidebarBalanceToBank: {
    id: 'balance-ledger-sidebar-balance-to-bank',
    defaultMessage: 'Sent to bank',
  },
  sidebarDiscount: {
    id: 'balance-ledger-sidebar-discount',
    defaultMessage: 'Volume discount',
  },
  sidebarDiscountBudget: {
    id: 'balance-ledger-sidebar-discount-budget',
    defaultMessage: 'Budget',
  },
  sidebarDiscountUsed: {
    id: 'balance-ledger-sidebar-discount-used',
    defaultMessage: 'Used',
  },
  sidebarDiscountRemaining: {
    id: 'balance-ledger-sidebar-discount-remaining',
    defaultMessage: 'Remaining budget',
  },
});

export default messages;
