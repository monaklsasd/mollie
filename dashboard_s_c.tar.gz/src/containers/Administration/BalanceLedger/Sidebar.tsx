import React, { Fragment } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { FormattedMessage } from 'react-intl';

// Redux
import { getBalanceById } from 'reduxState/modules/balanceLedger/selectors';
import { getDiscountCampaign } from 'reduxState/modules/balanceLedger/selectors';

// Internals
import { fetchBalance } from './Balance/actions';
import messages from './messages';
import * as selectors from './Balance/selectors';

// Components
import { SidebarList, SidebarTerm, SidebarTermWrapper } from 'components/UI/SidebarList';
import LoadingState from 'components/UI/LoadingState';
import FlashMessage from 'components/UI/FlashMessage';

// Types
import { BalanceLedgerType } from 'reduxState/modules/balanceLedger/types';
import { DiscountCampaignType } from 'reduxState/modules/balance';

type Props = {
  balance: BalanceLedgerType;
  discountCampaign: Nullable<DiscountCampaignType>;
  fetchBalance: typeof fetchBalance;
  balanceId: string;
  isLoading: boolean;
  isLoaded: boolean;
  error: Nullable<string>;
};

class Sidebar extends React.Component<Props> {
  componentDidMount(): void {
    const { fetchBalance, balanceId } = this.props;

    fetchBalance({ id: balanceId });
  }

  render(): React.ReactElement {
    const { balance, isLoaded, isLoading, error, discountCampaign } = this.props;

    return (
      <LoadingState isLoading={isLoading} compact delay={0}>
        {error && <FlashMessage state="error">{error}</FlashMessage>}
        {isLoaded && (
          <Fragment>
            {balance && (
              <SidebarList title={<FormattedMessage {...messages.sidebarBalance} />}>
                <SidebarTermWrapper>
                  <SidebarTerm
                    label={<FormattedMessage {...messages.sidebarBalanceOnHold} />}
                    {...balance.incomingAmount}
                  />
                  <SidebarTerm
                    label={<FormattedMessage {...messages.sidebarBalanceAvailable} />}
                    {...balance.availableAmount}
                  />
                  <SidebarTerm
                    label={<FormattedMessage {...messages.sidebarBalanceToBank} />}
                    {...balance.outgoingAmount}
                  />
                </SidebarTermWrapper>
              </SidebarList>
            )}
            {discountCampaign && (
              <SidebarList title={<FormattedMessage {...messages.sidebarDiscount} />}>
                <SidebarTermWrapper>
                  <SidebarTerm
                    label={<FormattedMessage {...messages.sidebarDiscountBudget} />}
                    {...discountCampaign.budgetVolume}
                  />
                  <SidebarTerm
                    label={<FormattedMessage {...messages.sidebarDiscountUsed} />}
                    {...discountCampaign.usedBudget}
                  />
                  <SidebarTerm
                    label={<FormattedMessage {...messages.sidebarDiscountRemaining} />}
                    {...discountCampaign.remainingBudget}
                    isFooter
                  />
                </SidebarTermWrapper>
              </SidebarList>
            )}
          </Fragment>
        )}
      </LoadingState>
    );
  }
}

const mapStateToProps = (state, props) => {
  const balanceId = props.match.params.id || 'default';

  return {
    balanceId,
    balance: getBalanceById(state, balanceId),
    isLoading: selectors.isLoading(state, balanceId),
    isLoaded: selectors.isLoaded(state, balanceId),
    error: selectors.getError(state, balanceId),
    discountCampaign: getDiscountCampaign(state),
  };
};

const mapDispatchToProps = {
  fetchBalance,
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Sidebar));
