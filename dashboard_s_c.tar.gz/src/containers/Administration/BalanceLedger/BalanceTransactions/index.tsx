import React from 'react';
import { connect } from 'react-redux';
import InfiniteScroll from 'react-infinite-scroller';
import { withRouter } from 'react-router-dom';
import { FormattedMessage } from 'react-intl';

// Internals
import { fetchBalanceTransactions, fetchMoreBalanceTransactions } from './actions';
import * as selectors from './selectors';
import BalanceTransactionsTable from './BalanceTransactionsTable';
import messages from './messages';

// Components
import FlashMessage from 'components/UI/FlashMessage';
import EmptyList from 'components/EmptyList';
import LoadingState from 'components/UI/LoadingState';

//Types
import { ChunkedBalanceTransactions } from 'containers/Administration/BalanceLedger/BalanceTransactions/types';
import { Location } from 'history';

type Props = {
  fetchBalanceTransactions: typeof fetchBalanceTransactions;
  fetchMoreBalanceTransactions: typeof fetchMoreBalanceTransactions;
  balanceId: string;
  isLoaded: boolean;
  isLoading: boolean;
  error: string;
  chunkedBalanceTransactions: ChunkedBalanceTransactions[];
  location: Location;
  pagination: {
    next: string;
    isLoadingMore: boolean;
  };
};

export class BalanceTransactions extends React.Component<Props> {
  componentDidMount(): void {
    const { fetchBalanceTransactions, balanceId } = this.props;

    fetchBalanceTransactions({ id: balanceId });
  }

  handleLoadMore = (): void => {
    // Use RaF (debounce) to make sure isLoadMore is update when scrolling
    // Fixes making duplicate xhr requests
    requestAnimationFrame(() => {
      const { pagination, fetchMoreBalanceTransactions, balanceId } = this.props;

      if (pagination.isLoadingMore) {
        return;
      }

      fetchMoreBalanceTransactions({ id: balanceId, from: pagination.next });
    });
  };

  render(): React.ReactElement {
    const { isLoading, error, chunkedBalanceTransactions, pagination, location } = this.props;

    if (error) {
      return <FlashMessage>{error}</FlashMessage>;
    }

    if (isLoading || !chunkedBalanceTransactions.length) {
      return (
        <EmptyList
          title={<FormattedMessage {...messages.EmptyList} />}
          location={location}
          isLoading={isLoading}
          resetFiltersLink={'administration'}
        />
      );
    }

    return (
      <InfiniteScroll
        key="list"
        pageStart={0}
        loadMore={this.handleLoadMore}
        hasMore={!!pagination.next}
        loader={<LoadingState key="loadMore" isLoading compact noBorder delay={2000} />}
        threshold={600}>
        {chunkedBalanceTransactions.map((transactions, index) => (
          <BalanceTransactionsTable
            key={`balance-transactions-table-${index}`}
            transactions={transactions}
          />
        ))}
      </InfiniteScroll>
    );
  }
}

const makeMapStateToProps = (state, props): Record<string, any> => {
  const balanceId = props.match.params.id || 'default';
  const getChunkedBalanceTransactions = selectors.makeChunkedBalanceTransactions();

  return state => ({
    balanceId,
    isLoaded: selectors.getIsLoaded(state, balanceId),
    isLoading: selectors.getIsLoading(state, balanceId),
    pagination: selectors.getPagination(state, balanceId),
    error: selectors.getError(state, balanceId),
    chunkedBalanceTransactions: getChunkedBalanceTransactions(state, balanceId),
  });
};

const mapDispatchToProps = {
  fetchBalanceTransactions,
  fetchMoreBalanceTransactions,
};

export default withRouter(connect(makeMapStateToProps, mapDispatchToProps)(BalanceTransactions));
