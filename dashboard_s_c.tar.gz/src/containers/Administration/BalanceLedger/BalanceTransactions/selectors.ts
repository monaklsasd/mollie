import { BalanceTransactionType } from 'reduxState/modules/balanceTransactions/types';
import createListSelectors from 'reduxState/factories/createListSelectors';
import { getBalanceTransactionsType } from 'reduxState/modules/balanceTransactions/selectors';
import { groupBy } from 'lodash';

import { createSelector } from 'reselect';
import moment from 'moment';

export const {
  makeGetEntities,
  getIsLoading,
  getIsLoaded,
  getError,
  getUpdatedAt,
  getPagination,
} = createListSelectors({
  key: 'balanceTransactionsList',
  entitiesSelector: getBalanceTransactionsType,
  paginationType: 'cursor',
});

/**
 * make chunked entities.
 */
export const makeChunkedBalanceTransactions = (): any => {
  // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
  // @ts-ignore
  const entitiesMaker = makeGetEntities();

  return createSelector(entitiesMaker, (BalanceTransactions: BalanceTransactionType[]) => {
    const transactionsSorted = BalanceTransactions.sort((transactionA, transactionB) =>
      moment.utc(transactionB.createdAt).diff(moment.utc(transactionA.createdAt)),
    );

    return Object.values(
      groupBy(transactionsSorted, BalanceTransaction =>
        moment.utc(BalanceTransaction.createdAt).format('YYYY-MM-DD'),
      ),
    );
  });
};
