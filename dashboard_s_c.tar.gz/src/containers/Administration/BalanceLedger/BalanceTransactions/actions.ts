import createApiActions from 'reduxState/factories/createApiActions';
import * as constants from './constants';
import { balanceTransactionsSchema } from 'reduxState/schemas';

export const [
  fetchBalanceTransactions,
  fetchBalanceTransactionsSuccess,
  fetchBalanceTransactionsFailure,
] = createApiActions({
  types: [
    constants.FETCH_BALANCE_TRANSACTIONS,
    constants.FETCH_BALANCE_TRANSACTIONS_SUCCESS,
    constants.FETCH_BALANCE_TRANSACTIONS_FAILURE,
  ],
  schema: [balanceTransactionsSchema],
});

export const [
  fetchMoreBalanceTransactions,
  fetchMoreBalanceTransactionsSuccess,
  fetchMoreBalanceTransactionsFailure,
] = createApiActions({
  types: [
    constants.FETCH_MORE_BALANCE_TRANSACTIONS,
    constants.FETCH_MORE_BALANCE_TRANSACTIONS_SUCCESS,
    constants.FETCH_MORE_BALANCE_TRANSACTIONS_FAILURE,
  ],
  schema: [balanceTransactionsSchema],
});
