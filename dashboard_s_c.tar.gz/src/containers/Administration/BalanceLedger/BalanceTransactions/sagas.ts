import createListSagas from 'reduxState/factories/createListSagas';
import * as constants from './constants';
import * as actions from './actions';

export const {
  watchFetch: watchFetchBalanceTransactions,
  watchFetchMore: watchFetchMoreBalanceTransactions,
} = createListSagas({
  constants: {
    fetch: constants.FETCH_BALANCE_TRANSACTIONS,
    fetchMore: constants.FETCH_MORE_BALANCE_TRANSACTIONS,
  },
  actions: {
    fetchSuccess: actions.fetchBalanceTransactionsSuccess,
    fetchFailure: actions.fetchBalanceTransactionsFailure,
    fetchMoreSuccess: actions.fetchMoreBalanceTransactionsSuccess,
    fetchMoreFailure: actions.fetchMoreBalanceTransactionsFailure,
  },
  apiRequest: (apiClient, { id, limit = 50, from }) => {
    const query = {
      limit,
      ...(from ? { from } : {}),
      from,
    };

    return apiClient.get(`v2/balances/${id}/transactions`, { query });
  },
});
