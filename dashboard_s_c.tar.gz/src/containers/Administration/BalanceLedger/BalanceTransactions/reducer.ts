import createListReducer from 'reduxState/factories/createListReducer';
import * as constants from './constants';

// Types
import { BalanceTransactionsListState } from './types';

const balanceTransactionsReducerByBalance = createListReducer({
  actions: {
    fetch: constants.FETCH_BALANCE_TRANSACTIONS,
    success: constants.FETCH_BALANCE_TRANSACTIONS_SUCCESS,
    failure: constants.FETCH_BALANCE_TRANSACTIONS_FAILURE,
  },
  paginationActions: {
    fetch: constants.FETCH_MORE_BALANCE_TRANSACTIONS,
    success: constants.FETCH_MORE_BALANCE_TRANSACTIONS_SUCCESS,
    failure: constants.FETCH_MORE_BALANCE_TRANSACTIONS_FAILURE,
  },
  paginationType: 'cursor',
});

type Reducer = typeof balanceTransactionsReducerByBalance;
type Action = Parameters<Reducer>[1];

export default (
  state: BalanceTransactionsListState = {},
  action: Action,
): BalanceTransactionsListState => {
  switch (action.type) {
    case constants.FETCH_BALANCE_TRANSACTIONS:
    case constants.FETCH_BALANCE_TRANSACTIONS_SUCCESS:
    case constants.FETCH_BALANCE_TRANSACTIONS_FAILURE:
    case constants.FETCH_MORE_BALANCE_TRANSACTIONS:
    case constants.FETCH_MORE_BALANCE_TRANSACTIONS_SUCCESS:
    case constants.FETCH_MORE_BALANCE_TRANSACTIONS_FAILURE:
      return {
        ...state,
        [action.payload.id]: balanceTransactionsReducerByBalance(state[action.payload.id], action),
      };
    default:
      return state;
  }
};
