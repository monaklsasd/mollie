import { IntlMessages } from 'types/intl';
import { defineMessages } from 'react-intl';

const messages: IntlMessages = defineMessages({
  EmptyList: {
    id: 'balance-events-transactions-empty-list',
    defaultMessage: 'No balance transactions found',
  },
});

export default messages;
