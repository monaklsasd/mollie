import { BalanceTransactionType } from 'reduxState/modules/balanceTransactions/types';
import { ListState } from 'reduxState/types';

export type ChunkedBalanceTransactions = Array<BalanceTransactionType>;

export type BalanceTransactionsListState = {
  readonly [key: string]: ListState;
};
