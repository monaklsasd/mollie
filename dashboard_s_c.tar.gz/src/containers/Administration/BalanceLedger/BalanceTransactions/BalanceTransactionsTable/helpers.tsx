import React from 'react';
import { FormattedMessage } from 'react-intl';
import Link from 'components/UI/Link';
import messages from './messages';
import * as constants from './constants';
import Currency from 'components/UI/Currency';
import { convertTransferIdToSettlementId } from 'utils/transferSettlementTokenConverter';

export const Bold: React.FC = ({ children }) => <span className="u-bold">{children}</span>;

export const getContextText = ({ type, context }): React.ReactNode => {
  switch (type) {
    case constants.TYPES_PAYMENT:
      return (
        <FormattedMessage
          {...messages.paymentContextDescription}
          values={{
            transactionLink: (
              <Bold>
                <Link to={`/payments/${context.payment.id}`}>
                  {context.payment.description || context.payment.id}
                </Link>
              </Bold>
            ),
            paid: (
              <Bold>
                <FormattedMessage {...messages.paid} />
              </Bold>
            ),
          }}
        />
      );
    case constants.TYPES_FAILED_PAYMENT:
      return (
        <FormattedMessage
          {...messages.failedPaymentContextDescription}
          values={{
            transactionLink: (
              <Bold>
                <Link to={`/payments/${context.payment.id}`}>
                  {context.payment.description || context.payment.id}
                </Link>
              </Bold>
            ),
            failed: (
              <Bold>
                <FormattedMessage {...messages.failed} />
              </Bold>
            ),
          }}
        />
      );
    case constants.TYPES_CAPTURE:
      return (
        <FormattedMessage
          {...messages.captureContextDescription}
          values={{
            captureLink: (
              <Bold>
                <Link to={`/payments/${context.payment.id}`}>
                  {context.payment.description || context.capture.description || context.capture.id}
                </Link>
              </Bold>
            ),
            paid: (
              <Bold>
                <FormattedMessage {...messages.paid} />
              </Bold>
            ),
          }}
        />
      );
    case constants.TYPES_APPLICATION_FEE:
      return (
        <FormattedMessage
          {...messages.applicationFeeContextDescription}
          values={{
            transactionLink: (
              <Bold>
                <Link to={`/payments/${context.payment.id}`}>
                  {context.payment.description || context.payment.id}
                </Link>
              </Bold>
            ),
            organization: <Bold>{context.organization.name}</Bold>,
            paid: <FormattedMessage {...messages.paid} />,
          }}
        />
      );
    case constants.TYPES_PAYMENT_FEE:
      return (
        <FormattedMessage
          {...messages.paymentFeeContextDescription}
          values={{
            transactionLink: (
              <Bold>
                <Link to={`/payments/${context.payment.id}`}>
                  {context.payment.description || context.payment.id}
                </Link>
              </Bold>
            ),
            paid: (
              <Bold>
                <FormattedMessage {...messages.paid} />
              </Bold>
            ),
          }}
        />
      );
    case constants.TYPES_FAILED_PAYMENT_FEE:
      return (
        <FormattedMessage
          {...messages.paymentFailureFeeContextDescription}
          values={{
            transactionLink: (
              <Bold>
                <Link to={`/payments/${context.payment.id}`}>
                  {context.payment.description || context.payment.id}
                </Link>
              </Bold>
            ),
            failed: (
              <Bold>
                <FormattedMessage {...messages.failed} />
              </Bold>
            ),
          }}
        />
      );
    case constants.TYPES_REFUND:
      return (
        <FormattedMessage
          {...messages.refundContextDescription}
          values={{
            transactionLink: (
              <Bold>
                <Link to={`/payments/${context.payment.id}`}>
                  {context.payment.description || context.payment.id}
                </Link>
              </Bold>
            ),
            refundLink: (
              <Bold>
                <Link to={`/payments/${context.payment.id}`}>
                  {context.refund.description || context.payment.description || context.refund.id}
                </Link>
              </Bold>
            ),
          }}
        />
      );
    case constants.TYPES_RETURNED_REFUND:
      return (
        <FormattedMessage
          {...messages.returnedRefundContextDescription}
          values={{
            transactionLink: (
              <Bold>
                <Link to={`/payments/${context.payment.id}`}>
                  {context.payment.description || context.payment.id}
                </Link>
              </Bold>
            ),
            refundLink: (
              <Bold>
                <Link to={`/payments/${context.payment.id}`}>
                  {context.refund.description || context.payment.description || context.refund.id}
                </Link>
              </Bold>
            ),
            returned: (
              <Bold>
                <FormattedMessage {...messages.returned} />
              </Bold>
            ),
          }}
        />
      );
    case constants.TYPES_CHARGEBACK:
      return (
        <FormattedMessage
          {...messages.chargebackContextDescription}
          values={{
            transactionLink: (
              <Bold>
                <Link to={`/payments/${context.payment.id}`}>
                  {context.payment.description || context.payment.id}
                </Link>
              </Bold>
            ),
            paid: (
              <Bold>
                <FormattedMessage {...messages.paid} />
              </Bold>
            ),
          }}
        />
      );
    case constants.TYPES_CHARGEBACK_REVERSAL:
      return (
        <FormattedMessage
          {...messages.chargebackReversalContextDescription}
          values={{
            transactionLink: (
              <Bold>
                <Link to={`/payments/${context.payment.id}`}>
                  {context.payment.description || context.payment.id}
                </Link>
              </Bold>
            ),
            reversed: (
              <Bold>
                <FormattedMessage {...messages.reversed} />
              </Bold>
            ),
          }}
        />
      );
    case constants.TYPES_OUTGOING_TRANSFER:
      return (
        <FormattedMessage
          {...messages.outgoingTransferContextDescription}
          values={{
            transferId: (
              <Bold>
                <Link
                  to={`/administration/settlements/${convertTransferIdToSettlementId(
                    context.transfer.id,
                  )}`}>
                  {context.transfer.reference}
                </Link>
              </Bold>
            ),
            beneficiaryName: <Bold>{context.transfer.beneficiary_name}</Bold>,
          }}
        />
      );
    case constants.TYPES_CANCELED_OUTGOING_TRANSFER:
      return (
        <FormattedMessage
          {...messages.canceledOutgoingTransferContextDescription}
          values={{
            transferId: (
              <Bold>
                <Link
                  to={`/administration/settlements/${convertTransferIdToSettlementId(
                    context.transfer.id,
                  )}`}>
                  {context.transfer.reference}
                </Link>
              </Bold>
            ),
          }}
        />
      );
    case constants.TYPES_RETURNED_TRANSFER:
      return (
        <FormattedMessage
          {...messages.returnedTransferContextDescription}
          values={{
            transferId: (
              <Bold>
                <Link
                  to={`/administration/settlements/${convertTransferIdToSettlementId(
                    context.transfer.id,
                  )}`}>
                  {context.transfer.reference}
                </Link>
              </Bold>
            ),
            beneficiaryName: <Bold>{context.transfer.beneficiary_name}</Bold>,
          }}
        />
      );
    case constants.TYPES_INCOMING_TRANSFER:
      return (
        <FormattedMessage
          {...messages.incomingTransfer}
          values={{
            sourceBalanceId: (
              <Bold>
                {context.transfer.source_balance_description || context.transfer.source_balance_id}
              </Bold>
            ),
            destinationBalanceId: (
              <Bold>
                {context.transfer.destination_balance_description ||
                  context.transfer.destination_balance_id}
              </Bold>
            ),
          }}
        />
      );
    case constants.TYPES_INVOICE_COMPENSATION:
      return (
        <FormattedMessage
          {...messages.invoiceCompensationContextDescription}
          values={{
            invoiceLink: (
              <Bold>
                <Link to={`/administration/invoices?year=${context.invoice.year}`}>
                  {context.invoice.invoice_number}
                </Link>
              </Bold>
            ),
            compensated: (
              <Bold>
                <FormattedMessage {...messages.compensated} />
              </Bold>
            ),
          }}
        />
      );
    case constants.TYPES_SPLIT_PAYMENT:
      return (
        <FormattedMessage
          {...messages.splitPaymentContextDescription}
          values={{
            transactionLink: (
              <Bold>
                <Link to={`/payments/${context.payment.id}`}>
                  {context.payment.description || context.payment.id}
                </Link>
              </Bold>
            ),
            split: (
              <Bold>
                <FormattedMessage {...messages.split} />
              </Bold>
            ),
            splitAmount: <Currency {...context.payment.amount} />,
          }}
        />
      );
    case constants.TYPES_CAPTURE_COMMISSION:
      return (
        <FormattedMessage
          {...messages.capturePartnerCommissionContextDescription}
          values={{
            transactionLink: (
              <Bold>
                <Link to={`/payments/${context.payment.id}`}>
                  {context.payment.description || context.payment.id}
                </Link>
              </Bold>
            ),
            organization: <Bold>{context.organization.name}</Bold>,
            paid: <FormattedMessage {...messages.paid} />,
          }}
        />
      );
    case constants.TYPES_PAYMENT_COMMISSION:
      return (
        <FormattedMessage
          {...messages.paymentPartnerCommissionContextDescription}
          values={{
            organization: <Bold>{context.organization.name}</Bold>,
          }}
        />
      );
    case constants.TYPES_ROLLING_RESERVE_RELEASE:
      return (
        <FormattedMessage
          {...messages.rollingReserveReleaseContextDescription}
          values={{
            transactionLink: (
              <Bold>
                <Link to={`/payments/${context.payment.id}`}>
                  {context.payment.description || context.payment.id}
                </Link>
              </Bold>
            ),
            paid: (
              <Bold>
                <FormattedMessage {...messages.paid} />
              </Bold>
            ),
          }}
        />
      );

    case constants.TYPES_BALANCE_CORRECTION:
      return context.balanceCorrection.description;

    case constants.TYPES_UNAUTHORIZED_DIRECT_DEBIT:
      return (
        <FormattedMessage
          {...messages.unauthorizedDirectDebitDescription}
          values={{
            transactionLink: (
              <Bold>
                <Link to={`/payments/${context.payment.id}`}>
                  {context.payment.description || context.payment.id}
                </Link>
              </Bold>
            ),
          }}
        />
      );

    case constants.TYPES_BANK_CHARGED_FAILURE_FEE:
      return (
        <FormattedMessage
          {...messages.bankChargedFailureFeeDescription}
          values={{
            transactionLink: (
              <Bold>
                <Link to={`/payments/${context.payment.id}`}>
                  {context.payment.description || context.payment.id}
                </Link>
              </Bold>
            ),
          }}
        />
      );

    default:
      return;
  }
};

export const getStatusText = (type: string): React.ReactNode => {
  switch (type) {
    case constants.TYPES_PAYMENT:
    case constants.TYPES_FAILED_PAYMENT:
    case constants.TYPES_SPLIT_PAYMENT:
      return <FormattedMessage {...messages.paymentStatus} />;

    case constants.TYPES_PAYMENT_FEE:
    case constants.TYPES_FAILED_PAYMENT_FEE:
      return <FormattedMessage {...messages.feeStatus} />;

    case constants.TYPES_CAPTURE:
      return <FormattedMessage {...messages.captureStatus} />;

    case constants.TYPES_CAPTURE_COMMISSION:
    case constants.TYPES_PAYMENT_COMMISSION:
    case constants.TYPES_APPLICATION_FEE:
      return <FormattedMessage {...messages.commissionStatus} />;

    case constants.TYPES_REFUND:
    case constants.TYPES_RETURNED_REFUND:
      return <FormattedMessage {...messages.refundStatus} />;

    case constants.TYPES_CHARGEBACK:
    case constants.TYPES_CHARGEBACK_REVERSAL:
      return <FormattedMessage {...messages.chargebackStatus} />;

    case constants.TYPES_OUTGOING_TRANSFER:
    case constants.TYPES_CANCELED_OUTGOING_TRANSFER:
    case constants.TYPES_RETURNED_TRANSFER:
    case constants.TYPES_INCOMING_TRANSFER:
      return <FormattedMessage {...messages.transferStatus} />;

    case constants.TYPES_INVOICE_COMPENSATION:
      return <FormattedMessage {...messages.invoiceStatus} />;

    case constants.TYPES_ROLLING_RESERVE_RELEASE:
      return <FormattedMessage {...messages.rollingReserveReleaseStatus} />;

    case constants.TYPES_BALANCE_CORRECTION:
      return <FormattedMessage {...messages.balanceCorrectionStatus} />;

    case constants.TYPES_UNAUTHORIZED_DIRECT_DEBIT:
      return <FormattedMessage {...messages.unauthorizedDirectDebit} />;

    case constants.TYPES_BANK_CHARGED_FAILURE_FEE:
      return <FormattedMessage {...messages.bankChargedFailureFee} />;

    default:
      return;
  }
};
