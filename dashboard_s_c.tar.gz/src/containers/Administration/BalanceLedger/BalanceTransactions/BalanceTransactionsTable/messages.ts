import { defineMessages } from 'react-intl';
import { IntlMessages } from 'types/intl';

const messages: IntlMessages = defineMessages({
  columnHeadingType: {
    id: 'balance-events-mutation-column-heading-type',
    defaultMessage: 'Type',
  },
  columnHeadingDescription: {
    id: 'balance-events-mutation-column-heading-description',
    defaultMessage: 'Description',
  },
  columnHeadingAmount: {
    id: 'balance-events-mutation-column-heading-amount',
    defaultMessage: 'Amount',
  },
  columnHeadingFee: {
    id: 'balance-events-mutation-column-heading-fee',
    defaultMessage: 'Fee',
  },
  columnHeadingSettled: {
    id: 'balance-events-mutation-column-heading-settled',
    defaultMessage: 'Settled',
  },
  notApplicable: {
    id: 'balance-events-mutation-not-applicable',
    defaultMessage: 'N/A',
  },

  // Payment status with types: payment failed-payment split-payment
  paymentStatus: {
    id: 'balance-events-mutation-status-payment',
    defaultMessage: 'payment',
  },
  paymentContextDescription: {
    id: 'balance-events-mutation-type-payment-context-description',
    defaultMessage: 'Payment {transactionLink} has been {paid}',
  },
  failedPaymentContextDescription: {
    id: 'balance-events-mutation-type-failed-payment-context-description',
    defaultMessage: 'Payment {transactionLink} has {failed} after it was paid',
  },
  splitPaymentContextDescription: {
    id: 'balance-events-mutation-type-split-payment',
    defaultMessage: 'Payment {transactionLink} has been paid and {split} from {splitAmount}',
  },

  // Fee status with types: payment-failure
  feeStatus: {
    id: 'balance-events-mutation-status-fee',
    defaultMessage: 'fee',
  },
  paymentFailureFeeContextDescription: {
    id: 'balance-events-mutation-type-context-description-payment-failure-fee',
    defaultMessage: 'Payment {transactionLink} has {failed}',
  },
  paymentFeeContextDescription: {
    id: 'balance-events-mutation-type-context-description-payment-fee',
    defaultMessage: 'Payment {transactionLink} has been {paid}',
  },

  // Capture status with types: Capture
  captureStatus: {
    id: 'balance-events-mutation-status-capture',
    defaultMessage: 'capture',
  },
  captureContextDescription: {
    id: 'balance-events-mutation-type-capture-context-description',
    defaultMessage: 'Capture {captureLink} has been {paid}',
  },

  // Commission status with types: partner-commission application-fee
  commissionStatus: {
    id: 'balance-events-mutation-status-commission',
    defaultMessage: 'commission',
  },
  paymentPartnerCommissionContextDescription: {
    id: 'balance-events-mutation-context-description-type-payment-partner-commission',
    defaultMessage: 'Partner commission for payment from {organization} received',
  },
  capturePartnerCommissionContextDescription: {
    id: 'balance-events-mutation-context-description-type-capture-partner-commission',
    defaultMessage: 'Capture {transactionLink} from organization {organizationLink} became {paid}',
  },
  applicationFeeContextDescription: {
    id: 'balance-events-mutation-context-description-type-application-fee',
    defaultMessage: 'Application Fee from {organization} received',
  },

  // Refund status with types: refund, returned-refund
  refundStatus: {
    id: 'balance-events-mutation-status-refund',
    defaultMessage: 'refund',
  },
  refundContextDescription: {
    id: 'balance-events-mutation-type-refund-context-description',
    defaultMessage: 'Refund {refundLink} linked to payment {transactionLink}',
  },
  returnedRefundContextDescription: {
    id: 'balance-events-mutation-context-description-type-returned-refund',
    defaultMessage: 'Refund {refundLink} linked to payment {transactionLink} has been {returned}',
  },

  // Chargeback status with types: chargeback chargeback-reversal
  chargebackStatus: {
    id: 'balance-events-mutation-status-chargeback',
    defaultMessage: 'chargeback',
  },
  chargebackContextDescription: {
    id: 'balance-events-mutation-type-chargeback-context-description',
    defaultMessage: 'Chargeback of payment {transactionLink} has been {paid}',
  },
  chargebackReversalContextDescription: {
    id: 'balance-events-mutation-context-description-type-chargeback-reversal',
    defaultMessage: 'Chargeback of payment {transactionLink} has been {reversed}',
  },

  // Transfer status with types: outgoing-transfer returned-transfer
  transferStatus: {
    id: 'balance-events-mutation-status-transfer',
    defaultMessage: 'transfer',
  },
  outgoingTransferContextDescription: {
    id: 'balance-events-mutation-context-description-type-outgoing-transfer',
    defaultMessage: 'Transfer {transferId} has been sent to {beneficiaryName}',
  },
  canceledOutgoingTransferContextDescription: {
    id: 'balance-events-mutation-context-description-type-canceled-outgoing-transfer',
    defaultMessage: 'Transfer {transferId} has been canceled',
  },
  returnedTransferContextDescription: {
    id: 'balance-events-mutation-context-description-type-returned-transfer',
    defaultMessage: 'Transfer {transferId} has been returned from {beneficiaryName}',
  },
  incomingTransfer: {
    id: 'balance-events-mutation-context-description-type-incoming-transfer',
    defaultMessage:
      'Transfer has been sent from {sourceBalanceId} to balance {destinationBalanceId}',
  },

  // Invoice status with types: invoice-compensation
  invoiceStatus: {
    id: 'balance-events-mutation-status-invoice',
    defaultMessage: 'invoice',
  },
  invoiceCompensationContextDescription: {
    id: 'balance-events-mutation-context-description-type-invoice-compensation',
    defaultMessage: 'Invoice {invoiceLink} has been {compensated}',
  },

  // Rolling Reserve status with types: rolling-reserve-release
  rollingReserveReleaseStatus: {
    id: 'balance-events-mutation-status-rolling-reserve-release-status',
    defaultMessage: 'rolling reserve',
  },
  rollingReserveReleaseContextDescription: {
    id: 'balance-events-mutation-type-rolling-reserve-release-context-description',
    defaultMessage: 'Rolling reserve linked to payment {transactionLink} was {paid}',
  },

  // Balance Corrections
  balanceCorrectionStatus: {
    id: 'balance-events-mutation-status-balance-correction',
    defaultMessage: 'correction',
  },

  // Unauthorized Direct Debit Fee
  unauthorizedDirectDebit: {
    id: 'balance-events-mutation-status-unauthorized-direct-debit',
    defaultMessage: 'fee',
  },
  unauthorizedDirectDebitDescription: {
    id: 'balance-events-mutation-context-description-type-unauthorized-direct-debit',
    defaultMessage: 'Unauthorized SEPA Direct Debit fee linked to payment {transactionLink}',
  },

  // Bank Charged Direct Debit Failure Fee
  bankChargedFailureFee: {
    id: 'balance-events-mutation-status-bank-charged-failure-fee',
    defaultMessage: 'fee',
  },
  bankChargedFailureFeeDescription: {
    id: 'balance-events-mutation-context-description-type-bank-charged-failure-fee',
    defaultMessage: 'Bank Charged Failure Fee for Direct Debit linked to payment {transactionLink}',
  },

  // Status
  paid: {
    id: 'balance-events-mutation-paid',
    defaultMessage: 'paid',
  },
  failed: {
    id: 'balance-events-mutation-failed',
    defaultMessage: 'failed',
  },
  returned: {
    id: 'balance-events-mutation-returned',
    defaultMessage: 'returned',
  },
  reversed: {
    id: 'balance-events-mutation-reversed',
    defaultMessage: 'reversed',
  },
  compensated: {
    id: 'balance-events-mutation-compensated',
    defaultMessage: 'compensated',
  },
  split: {
    id: 'balance-events-mutation-split',
    defaultMessage: 'split',
  },
});

export default messages;
