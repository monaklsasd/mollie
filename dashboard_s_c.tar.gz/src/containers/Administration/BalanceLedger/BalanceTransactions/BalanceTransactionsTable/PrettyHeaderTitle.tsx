import React from 'react';
import { FormattedRelativeTime, FormattedDate } from 'react-intl';
import moment from 'moment';

type Props = {
  date: Date;
};

type State = {
  pretty: boolean;
  showYear: boolean;
  canChangeFormat: boolean;
};

export class PrettyHeaderTitle extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    const momentDate = this.getDateWithoutTime();
    // 7 days is the max
    const pretty = momentDate.isSameOrAfter(moment().subtract(8, 'days'));

    this.state = {
      canChangeFormat: pretty,
      pretty,
      showYear: momentDate.isBefore(moment().subtract(1, 'years')),
    };
  }

  changeFormat = (): void => {
    this.setState({ pretty: !this.state.pretty });
  };

  getDateWithoutTime = (): moment.Moment => {
    const { date } = this.props;
    const momentDate = moment.utc(date);
    return momentDate.startOf('day');
  };

  renderPrettyDate(): React.ReactElement {
    const { pretty, showYear } = this.state;

    const date = this.getDateWithoutTime();
    const now = moment();

    if (pretty && !showYear) {
      return <FormattedRelativeTime value={date.diff(now, 'day')} unit="day" />;
    }

    if (showYear) {
      return <FormattedDate value={date.toDate()} day="numeric" month="long" year="numeric" />;
    }

    return <FormattedDate value={date.toDate()} day="numeric" month="long" />;
  }

  render(): React.ReactElement {
    if (this.state.canChangeFormat) {
      return (
        <button className="balances-transactions-table__button" onClick={this.changeFormat}>
          {this.renderPrettyDate()}
        </button>
      );
    }

    return this.renderPrettyDate();
  }
}

export default PrettyHeaderTitle;
