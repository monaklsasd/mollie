import React from 'react';
import { FormattedMessage } from 'react-intl';

// Components
import Chip from 'components/UI/Chip';
import GridTable from 'components/UI/GridTable';
import GridTableRow from 'components/UI/GridTable/Row';
import GridTableCell from 'components/UI/GridTable/Cell';
import Currency from 'components/UI/Currency';

// Internals
import './styles.scss';
import { getContextText, getStatusText } from './helpers';
import messages from './messages';
import PrettyHeaderTitle from './PrettyHeaderTitle';

// Types
import { BalanceTransactionType } from 'reduxState/modules/balanceTransactions/types';

type Props = {
  transactions: BalanceTransactionType[];
};

const BalanceEventsBalanceTransactionsTable: React.FC<Props> = ({ transactions }) => {
  return (
    <GridTable
      title={<PrettyHeaderTitle date={transactions[0].createdAt} />}
      columnRow={[
        <GridTableCell name="type">
          <FormattedMessage {...messages.columnHeadingType} />
        </GridTableCell>,
        <GridTableCell name="description">
          <FormattedMessage {...messages.columnHeadingDescription} />
        </GridTableCell>,
        <GridTableCell name="amount" numeric>
          <FormattedMessage {...messages.columnHeadingAmount} />
        </GridTableCell>,
        <GridTableCell name="fees" numeric>
          <FormattedMessage {...messages.columnHeadingFee} />
        </GridTableCell>,
        <GridTableCell name="settled" numeric>
          <FormattedMessage {...messages.columnHeadingSettled} />
        </GridTableCell>,
      ]}
      fixedHeader
      className="balances-transactions-table">
      {transactions.map(transaction => (
        <GridTableRow key={`grid-row-${transaction.id}`}>
          <GridTableCell name="type">
            <Chip>{getStatusText(transaction.type)}</Chip>
          </GridTableCell>
          <GridTableCell name="description">
            {getContextText({ type: transaction.type, context: transaction.context })}
          </GridTableCell>
          <GridTableCell name="amount" numeric>
            <Currency {...transaction.initialAmount} />
          </GridTableCell>
          <GridTableCell name="fees" numeric>
            {transaction.fees ? (
              <Currency {...transaction.fees} />
            ) : (
              <span className="balances-transactions-table__not-applicable">
                <FormattedMessage {...messages.notApplicable} />
              </span>
            )}
          </GridTableCell>
          <GridTableCell name="settled" numeric>
            <Currency {...transaction.resultAmount} />
          </GridTableCell>
        </GridTableRow>
      ))}
    </GridTable>
  );
};

export default BalanceEventsBalanceTransactionsTable;
