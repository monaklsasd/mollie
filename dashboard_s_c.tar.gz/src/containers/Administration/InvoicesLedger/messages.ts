import { defineMessages } from 'react-intl';
import { IntlMessages } from 'types/intl';

const messages: IntlMessages = defineMessages({
  title: {
    id: 'invoices-title',
    defaultMessage: 'Invoices {year}',
  },
  emptyTitle: {
    id: 'invoices-list-no-payments-found',
    defaultMessage: 'No invoices found for this period',
  },
  emptyExplanation: {
    id: 'invoices-list-no-payments-found-explanation',
    defaultMessage: 'Invoices for a selected period will be displayed here.',
  },
  sidebarYearFilter: {
    id: 'invoices-list-year-filter-title',
    defaultMessage: 'Filter a specific year:',
  },
  noTestmodeSupport: {
    id: 'invoices-no-testmode-support',
    defaultMessage: 'Invoices are not supported in test mode.',
  },
  invoiceNumber: {
    id: 'invoices-list-invoice-number',
    defaultMessage: 'Invoice number',
  },
});

export default messages;
