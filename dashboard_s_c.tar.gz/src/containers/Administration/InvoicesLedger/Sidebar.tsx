import React from 'react';
import { FormattedMessage } from 'react-intl';

// Components
import Heading from 'components/UI/Heading';
import { SelectYear } from 'components/forms';

// Internals
import messages from './messages';

type Props = {
  filters: Record<string, any>;
  onUpdateYearQuery: (arg: number) => void;
  minYear: number;
};

const Sidebar: React.FC<Props> = ({ filters, minYear, onUpdateYearQuery }) => {
  return (
    <React.Fragment>
      <Heading type="h3">
        <FormattedMessage {...messages.sidebarYearFilter} />
      </Heading>

      <SelectYear
        className="c-administration__filter"
        value={filters.year}
        from={minYear}
        placeholder={String(filters.year)}
        onChange={year => onUpdateYearQuery(Number(year))}
      />
    </React.Fragment>
  );
};

export default Sidebar;
