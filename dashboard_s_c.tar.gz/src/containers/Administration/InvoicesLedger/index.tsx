import React from 'react';
import { connect } from 'react-redux';
import { FormattedMessage, FormattedNumber, FormattedDate, injectIntl } from 'react-intl';
import Helmet from 'react-helmet';
import { createSelector } from 'reselect';

// Containers
import PageWrapper from 'containers/PageWrapper';
import RequirePermissions, { Permissions } from 'containers/RequirePermissions';

// Components
import Link from 'components/UI/Link';
import Layout from 'components/UI/Layout';
import Empty from 'components/UI/Empty';
import FlashMessage from 'components/UI/FlashMessage';
import LoadingState from 'components/UI/LoadingState';
import StatusBlock from 'components/UI/StatusBlock';
import Wrapper from 'components/UI/Wrapper';
import GridTable from 'components/UI/GridTable';
import GridTableRow from 'components/UI/GridTable/Row';
import GridTableCell from 'components/UI/GridTable/Cell';

// Internals
import Sidebar from './Sidebar';
import messages from './messages';
import getQueryStringFilters from 'helpers/getQueryStringFilters';
import { tables } from 'messages';

// Redux
import { getApiBaseUrl } from 'reduxState/modules/application/selectors';
import {
  getFirstPaymentDateWithFallback,
  getOrganization,
} from 'reduxState/modules/organization/selectors';
import * as actions from 'reduxState/modules/invoices';

// Utils
import MollieURL from 'utils/MollieURL';
import shallowEqual from 'utils/shallowEqual';

// Types
import { IntlShape } from 'react-intl';
import { Location, History } from 'history';

import './styles.scss';

const TABLE_COLUMNS = {
  DATE: 'date',
  INVOICE_NUMBER: 'invoice-number',
  AMOUNT_EXCL: 'amount-excl',
  VAT_AMOUNT: 'vat-amount',
  AMOUNT_INCL: 'amount-incl',
  LABEL_AMOUNT_EXCL: 'label-amount-excl',
  LABEL_VAT_AMOUNT: 'label-vat-amount',
  LABEL_AMOUNT_INCL: 'label-amount-incl',
};

type Props = {
  apiBaseUrl: string;
  filters: { year: number };
  firstPaymentDate: Date;
  invoices: Record<string, any>;
  location: Location<{}, { highlight: boolean }>;
  history: History;
  defaultFilters: Record<string, any>;
  loadInvoices: Function;
  intl: IntlShape;
};

type State = {
  currentInvoiceId: Nullable<string>;
};

class BalancesInvoices extends React.Component<Props, State> {
  constructor(props) {
    super(props);

    this.state = {
      currentInvoiceId: null,
    };
  }

  componentDidMount(): void {
    const { filters, loadInvoices } = this.props;

    loadInvoices(filters);
  }

  componentDidUpdate(prevProps): void {
    const { filters, loadInvoices } = this.props;

    if (!shallowEqual(prevProps.filters, filters)) {
      loadInvoices(filters);
    }
  }

  handleDownload(id): void {
    this.setState({
      currentInvoiceId: id,
    });

    /*
     * Wrap in rAF because we have to wait for the invisible download link to
     * be rendered with the new url.
     */
    requestAnimationFrame(() => {
      if (this.downloadLink) {
        this.downloadLink.click();
      }
    });
  }

  downloadLink: Nullable<HTMLAnchorElement> = null;

  onUpdateYearQuery = (value): void => {
    const { filters, defaultFilters, location, history } = this.props;
    const query = getQueryStringFilters({ ...filters, year: parseInt(value, 10) }, defaultFilters);

    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    history.replace({
      pathname: location.pathname,
      query,
    });
  };

  renderInvoices(): React.ReactNode {
    const { invoices, intl, location } = this.props;
    const highlightedId = location.query.highlight;

    if (invoices.error) {
      return <FlashMessage state="error">{invoices.error}</FlashMessage>;
    }

    if (!invoices.isLoading && invoices.totalCount === 0) {
      return (
        <Empty
          title={intl.formatMessage(messages.emptyTitle)}
          explanation={intl.formatMessage(messages.emptyExplanation)}
          className="invoices__empty-state"
        />
      );
    }

    return (
      <GridTable
        columnRow={[
          <GridTableCell name={TABLE_COLUMNS.DATE}>
            <FormattedMessage {...tables.date} />
          </GridTableCell>,
          <GridTableCell name={TABLE_COLUMNS.INVOICE_NUMBER}>
            <FormattedMessage {...messages.invoiceNumber} />
          </GridTableCell>,
          <GridTableCell name={TABLE_COLUMNS.AMOUNT_EXCL} numeric>
            <FormattedMessage {...tables.exclVat} />
          </GridTableCell>,
          <GridTableCell name={TABLE_COLUMNS.VAT_AMOUNT} numeric>
            <FormattedMessage {...tables.vat} />
          </GridTableCell>,
          <GridTableCell name={TABLE_COLUMNS.AMOUNT_INCL} numeric>
            <FormattedMessage {...tables.total} />
          </GridTableCell>,
        ]}
        className="invoices-table">
        {invoices.data.map(item => (
          <GridTableRow key={item.id} isHighlighted={highlightedId && highlightedId === item.id}>
            <GridTableCell name={TABLE_COLUMNS.DATE}>
              <FormattedDate
                value={new Date(item.issueDate)}
                day="numeric"
                month="long"
                year="numeric"
              />
            </GridTableCell>
            <GridTableCell name={TABLE_COLUMNS.INVOICE_NUMBER}>
              <RequirePermissions
                permissions={[Permissions.PAYMENTS_READ, Permissions.SETTLEMENTS_READ]}>
                {(hasPermission): React.ReactNode =>
                  hasPermission ? (
                    <Link
                      noUnderline
                      onClick={(): void => {
                        this.handleDownload(item.id);
                      }}>
                      {item.reference}&nbsp;
                      <StatusBlock status="neutral">PDF</StatusBlock>
                    </Link>
                  ) : (
                    <StatusBlock status="neutral">PDF</StatusBlock>
                  )
                }
              </RequirePermissions>
            </GridTableCell>
            <GridTableCell name={TABLE_COLUMNS.AMOUNT_EXCL} numeric>
              <FormattedNumber value={item.amount.net} format="EUR" />
            </GridTableCell>
            <GridTableCell name={TABLE_COLUMNS.VAT_AMOUNT} numeric>
              <FormattedNumber value={item.amount.vat} format="EUR" />
            </GridTableCell>
            <GridTableCell name={TABLE_COLUMNS.AMOUNT_INCL} numeric>
              <FormattedNumber value={item.amount.gross} format="EUR" />
            </GridTableCell>
            <GridTableCell name={TABLE_COLUMNS.LABEL_AMOUNT_EXCL}>
              <FormattedMessage {...tables.exclVat} />
            </GridTableCell>
            <GridTableCell name={TABLE_COLUMNS.LABEL_VAT_AMOUNT}>
              <FormattedMessage {...tables.vat} />
            </GridTableCell>
            <GridTableCell name={TABLE_COLUMNS.LABEL_AMOUNT_INCL}>
              <FormattedMessage {...tables.total} />
            </GridTableCell>
          </GridTableRow>
        ))}
      </GridTable>
    );
  }

  render(): React.ReactElement {
    const { apiBaseUrl, invoices, filters, firstPaymentDate, intl } = this.props;

    return (
      <PageWrapper title={<FormattedMessage {...messages.title} values={{ year: filters.year }} />}>
        <Wrapper isLast>
          <Layout
            sidebar={
              <Sidebar
                filters={filters}
                onUpdateYearQuery={this.onUpdateYearQuery}
                minYear={firstPaymentDate.getFullYear()}
              />
            }>
            <Helmet title={intl.formatMessage(messages.title, { year: filters.year })} />

            <LoadingState isLoading={invoices.isLoading}>{this.renderInvoices()}</LoadingState>
            <RequirePermissions
              permissions={[Permissions.PAYMENTS_READ, Permissions.SETTLEMENTS_READ]}>
              {/* eslint-disable jsx-a11y/anchor-has-content */}
              <a
                aria-hidden
                href={MollieURL.createStatementsDownload(
                  apiBaseUrl,
                  'invoices',
                  this.state.currentInvoiceId,
                )}
                ref={(c): void => {
                  this.downloadLink = c;
                }}
              />
              {/* eslint-enable jsx-a11y/anchor-has-content */}
            </RequirePermissions>
          </Layout>
        </Wrapper>
      </PageWrapper>
    );
  }
}

// Export for testing purposes
export const defaultFilters = {
  month: 0,
  year: new Date().getFullYear(),
};

const mapStateToProps = createSelector(
  // Filters
  (state, props) => props.location.query,
  // Organization
  state => state,
  // Result is memoized by Reselect to prevent re-renders
  (filters, state) => {
    const month = filters.month && !isNaN(filters.month) ? filters.month : defaultFilters.month;
    const year = filters.year && !isNaN(filters.year) ? filters.year : defaultFilters.year;

    return {
      defaultFilters,
      filters: {
        month: parseInt(month, 10),
        year: parseInt(year, 10),
      },
      organization: getOrganization(state),
      apiBaseUrl: getApiBaseUrl(state),
      firstPaymentDate: new Date(getFirstPaymentDateWithFallback(state)),
      invoices: state.invoices,
    };
  },
);

export default connect(mapStateToProps, actions)(injectIntl(BalancesInvoices));
