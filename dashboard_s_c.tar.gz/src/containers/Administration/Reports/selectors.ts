import moment from 'moment';

import { DATE_FORMAT } from './constants';

// Types
import { State } from 'reduxState/types';
import { BalanceReportItemType, DateRangeType } from './types';
import { TransformedBalanceReportType } from 'reduxState/modules/balanceReports/types';

// Selectors
import { getById as getBalanceReportById } from 'reduxState/modules/balanceReports/selectors';

const getState = (state: State) => state.balanceReport;

export const getById = (state: State, id: string): BalanceReportItemType => {
  const balanceReportState = getState(state);
  return balanceReportState[id];
};

export const getTransformedBalanceById = (
  state: State,
  props: Record<string, any>,
): Nullable<TransformedBalanceReportType> => {
  const balanceReport = getBalanceReportById(state, props);

  if (!balanceReport) {
    return null;
  }

  return balanceReport;
};

export const getError = (state: State, id: string): Nullable<string> => {
  const balanceReport = getById(state, id);
  return balanceReport ? balanceReport.error : null;
};

export const getLoadedState = (state: State, id: string): Nullable<boolean> => {
  const balanceReport = getById(state, id);
  return balanceReport ? balanceReport.isLoaded : null;
};

export const getLoadingState = (state: State, id: string): Nullable<boolean> => {
  const balanceReport = getById(state, id);
  return balanceReport ? balanceReport.isLoading : null;
};

export const getDateRange = (state: State, id: string): DateRangeType => {
  const balanceReport = getById(state, id);

  return {
    startDate: balanceReport
      ? moment(balanceReport.dateRange.startDate || undefined).format(DATE_FORMAT)
      : null,
    endDate: balanceReport
      ? moment(balanceReport.dateRange.endDate || undefined).format(DATE_FORMAT)
      : null,
  };
};
