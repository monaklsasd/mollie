import { takeLatest, put, call } from 'redux-saga/effects';
import moment from 'moment';

// Internals
import * as constants from './constants';
import * as actions from './actions';
import { callApi } from 'reduxState/sagas/api';
import { fetchBalanceReport } from 'services/api';

// Types
import { ActionPayload } from './types';

/* **************************************************************************** */
/* ****************************** ROUTINES ************************************ */
/* **************************************************************************** */

export function* fetchBalanceReportRoutine({
  payload: { id, from, until },
}: ActionPayload): Generator<any, any, any> {
  const fromDate = from || constants.DEFAULT_FROM_DATE;

  // until date should be exclusive
  const untilDate = moment(until || constants.DEFAULT_END_DATE)
    .add(1, 'd')
    .format('YYYY-MM-DD');

  const { response, errorResponse, status } = yield call(callApi, fetchBalanceReport, id, {
    from: fromDate,
    until: untilDate,
    grouping: 'transaction-categories',
  });

  if (response) {
    yield put(actions.fetchBalanceReportSuccess(response, id));
  }

  if (errorResponse && errorResponse.detail) {
    yield put(
      actions.fetchBalanceReportFailure({
        error: errorResponse.detail,
        id,
        status,
      }),
    );
  }
}

/* **************************************************************************** */
/* ****************************** WATCHERS ************************************ */
/* **************************************************************************** */

export function* watchFetchBalanceReport(): Generator<any, any, any> {
  // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
  // @ts-ignore
  yield takeLatest(constants.FETCH_BALANCE_REPORT, fetchBalanceReportRoutine);
}
