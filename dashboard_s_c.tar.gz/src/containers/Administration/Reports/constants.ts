import moment from 'moment';

export const FETCH_BALANCE_REPORT = 'BalanceReport/FETCH_BALANCE_REPORT';
export const FETCH_BALANCE_REPORT_SUCCESS = 'BalanceReport/FETCH_BALANCE_REPORT_SUCCESS';
export const FETCH_BALANCE_REPORT_FAILURE = 'BalanceReport/FETCH_BALANCE_REPORT_FAILURE';
export const UPDATE_DATE_RANGE = 'BalanceReport/UPDATE_DATE_RANGE';

export const DATE_FORMAT = 'YYYY-MM-DD';
export const TOP_ROW_LEVEL = 1;
export const DEFAULT_FROM_DATE = moment()
  .subtract(2, 'days')
  .format(DATE_FORMAT);
export const DEFAULT_END_DATE = moment()
  .clone()
  .subtract(1, 'days')
  .format(DATE_FORMAT);
