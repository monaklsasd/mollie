import React from 'react';
import { FormattedMessage, IntlShape, injectIntl } from 'react-intl';
import { connect } from 'react-redux';
import moment from 'moment';
import { isEmpty } from 'lodash';
import Helmet from 'react-helmet';

// Containers
import PageWrapper from 'containers/PageWrapper';
import Wrapper from 'components/UI/Wrapper';
import ResourceError from 'containers/ResourceError';
import StatementDownloads from 'components/StatementDownloads';

// Components
import BalanceReportRow from './BalanceReportRow';
import BalanceReportHeadings from './BalanceReportHeadings';
import LoadingState from 'components/UI/LoadingState';
import DateRangePicker from 'components/UI/DateRangePicker';
import ButtonGroup from 'components/UI/ButtonGroup';
import IconPaymentMethods from 'components/IconPaymentMethods';
import FlashMessage from 'components/UI/FlashMessage';

// Messages
import messages from './messages';

// Redux
import * as selectors from './selectors';
import * as actions from './actions';
import { DATE_FORMAT, TOP_ROW_LEVEL } from './constants';
import { getOrganizationLedgerBoardingDate } from 'reduxState/modules/organization/selectors';

// Types
import { TransformedBalanceReportType } from 'reduxState/modules/balanceReports/types';
import { State } from 'reduxState/types';
import { Location, History } from 'history';
import { DateRangeType } from './types';

// Utils
import shallowEqual from 'utils/shallowEqual';

// Helpers
import PAYMENT_METHODS from 'helpers/paymentMethods';

// Stylesheets
import './styles.scss';

type Props = {
  fetchBalanceReport: typeof actions.fetchBalanceReport;
  updateDateRange: typeof actions.updateDateRange;
  isLoading: Nullable<boolean>;
  isLoaded: Nullable<boolean>;
  balanceReport: Nullable<TransformedBalanceReportType>;
  balanceId: string;
  error: Nullable<string>;
  dateRange: DateRangeType;
  history: History;
  location: Location<
    {},
    {
      from?: string;
      to?: string;
    }
  >;
  ledgerBoardingDate: ReturnType<typeof getOrganizationLedgerBoardingDate>;
  intl: IntlShape;
};

class BalanceReport extends React.Component<Props> {
  componentDidMount(): void {
    const { balanceId } = this.props;

    this.updateDates(this.getDateRange());

    if (balanceId) {
      this.fetchBalanceReport();
    }
  }

  componentDidUpdate(prevProps: Props): void {
    // Update balance report using updated date range.
    if (
      !isEmpty(prevProps.location.query) &&
      !shallowEqual(prevProps.location.query, this.props.location.query)
    ) {
      // Internal Method
      this.fetchBalanceReport();
    }
  }

  // Cache yesterdays date to prevent duplicate calculations.
  YESTERDAY_DATE = moment()
    .startOf('day')
    .clone()
    .subtract(1, 'days');

  getDateRange(): DateRangeType {
    const { dateRange, location } = this.props;

    if (
      location?.query?.from &&
      location?.query?.to &&
      moment(location.query.from).isValid() &&
      moment(location.query.to).isValid()
    ) {
      return { startDate: location.query.from, endDate: location.query.to };
    }

    return dateRange;
  }

  fetchBalanceReport(): void {
    const { balanceId } = this.props;
    const { startDate, endDate } = this.getDateRange();

    this.props.fetchBalanceReport({
      id: balanceId,
      from: startDate,
      until: endDate,
    });
  }

  formatDate(date: moment.Moment | Nullable<string>): Nullable<Date | string> {
    if (!date) {
      return null;
    }

    if (typeof date === 'string') {
      return date;
    }

    return date.clone().format(DATE_FORMAT);
  }

  formatDateRangeLabel(date): string {
    return moment(date)
      .clone()
      .format('MMM DD');
  }

  updateDates = (dateRange: DateRangeType): void => {
    const { balanceId, history } = this.props;
    const startDate = dateRange.startDate ? this.formatDate(dateRange.startDate) : null;
    const endDate = dateRange.endDate ? this.formatDate(dateRange.endDate) : null;

    this.props.updateDateRange({
      dateRange: {
        startDate,
        endDate,
      },
      id: balanceId,
    });

    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    history.push({
      pathname: '/administration/report',
      query: {
        ...(startDate ? { from: startDate } : null),
        ...(endDate ? { to: endDate } : null),
      },
    });
  };

  renderContent(): React.ReactElement {
    const { balanceReport, error, ledgerBoardingDate, intl } = this.props;
    const dateRange = this.getDateRange();
    const momentLedgerBoardingDate = moment(ledgerBoardingDate || undefined);
    const isStartDateBeforeLedgerBoardingDate = moment(dateRange.startDate || undefined).isBefore(
      momentLedgerBoardingDate,
    );

    if (error) {
      const errorMessage = isStartDateBeforeLedgerBoardingDate
        ? intl.formatMessage(messages.invalidDateMessage, {
            availableDate: momentLedgerBoardingDate.format('DD/MM/Y'),
          })
        : error;

      return <ResourceError error={errorMessage} resourceName={messages.title} />;
    }

    const startDateLabel = this.formatDateRangeLabel(dateRange.startDate);
    const endDateLabel = this.formatDateRangeLabel(dateRange.endDate);

    return (
      <div className="balance-report">
        {isStartDateBeforeLedgerBoardingDate && (
          <FlashMessage state="error">
            <FormattedMessage
              {...messages.invalidDateMessage}
              values={{
                availableDate: momentLedgerBoardingDate.format('DD/MM/Y'),
              }}
            />
          </FlashMessage>
        )}
        <BalanceReportHeadings className="balance-report__row-container" />
        {balanceReport?.rows &&
          balanceReport.rows.map(row => (
            <BalanceReportRow
              {...row}
              rowClassName="balance-report__row-container"
              className="balance-report__row"
              level={TOP_ROW_LEVEL}
              key={`row-1-${row.name}`}
              startDateLabel={startDateLabel}
              endDateLabel={endDateLabel}
            />
          ))}
      </div>
    );
  }

  renderReferenceSVGs(): React.ReactElement[] {
    /*
     Because some of our svg's contain unique id's, the id's on the page are no longer unique.
     When the first svg on the page is hidden, this will break the other svg's, referencing the first id.
     to combat this, we place 0x0 versions of all payment icons in the page
     */
    return Object.keys(PAYMENT_METHODS).map(key => (
      <IconPaymentMethods method={PAYMENT_METHODS[key]} width={0} height={0} />
    ));
  }

  render(): React.ReactElement {
    const { isLoading, isLoaded, balanceReport, error, ledgerBoardingDate } = this.props;
    const dateRange = this.getDateRange();

    // Show full-page loading indicator when we're loading this report for the very first time.
    if ((!error && !balanceReport) || (isLoading && !isLoaded)) {
      return <LoadingState fullHeight isLoading />;
    }

    return (
      <PageWrapper
        title={<FormattedMessage {...messages.title} />}
        actions={
          <ButtonGroup>
            <StatementDownloads />
            <DateRangePicker
              onDatesChange={this.updateDates}
              firstDate={moment(ledgerBoardingDate || undefined)}
              startDate={moment(dateRange.startDate || undefined)}
              endDate={moment(dateRange.endDate || undefined)}
              startDateId="report-date-start"
              endDateId="report-date-end"
              readOnly
            />
          </ButtonGroup>
        }>
        <FormattedMessage {...messages.title}>
          {(msg): React.ReactNode => typeof msg === 'string' && <Helmet title={msg} />}
        </FormattedMessage>
        <LoadingState isLoading={isLoading || false} fullHeight noBorder>
          <Wrapper isLast>
            {this.renderReferenceSVGs()}
            {this.renderContent()}
          </Wrapper>
        </LoadingState>
      </PageWrapper>
    );
  }
}

const mapDispatchToProps = {
  fetchBalanceReport: actions.fetchBalanceReport,
  updateDateRange: actions.updateDateRange,
};

const mapStateToProps = (state: State, props: Props) => {
  const balanceId = 'default';

  return {
    balanceId,
    isLoading: selectors.getLoadingState(state, balanceId),
    isLoaded: selectors.getLoadedState(state, balanceId),
    error: selectors.getError(state, balanceId),
    balanceReport: selectors.getTransformedBalanceById(state, props),
    dateRange: selectors.getDateRange(state, balanceId),
    ledgerBoardingDate: getOrganizationLedgerBoardingDate(state),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(injectIntl(BalanceReport));
