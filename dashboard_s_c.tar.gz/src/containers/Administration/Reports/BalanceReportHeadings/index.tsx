import React from 'react';
import { FormattedMessage } from 'react-intl';
import classNames from 'classnames';

// Messages
import messages from '../messages';

// Stylesheets
import './styles.scss';

// Types
import { ClassnamesFunction } from 'types/helpers';

const getClass: ClassnamesFunction<Props> = ({ className }) =>
  classNames('balance-report-headings', className);

type Props = {
  className: string;
};

const BalanceReportHeadings: React.FC<Props> = ({ className }: Props) => (
  <div className={getClass({ className })}>
    <div className="balance-report-headings__item balance-report-headings__item--on-hold">
      <FormattedMessage {...messages.onHold} />
    </div>
    <div className="balance-report-headings__item balance-report-headings__item--available">
      <FormattedMessage {...messages.available} />
    </div>
  </div>
);

export default BalanceReportHeadings;
