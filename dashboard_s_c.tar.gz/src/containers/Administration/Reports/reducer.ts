import { combineReducers } from 'redux';

// Internal
import * as constants from './constants';

// Types
import { Reducer } from 'redux';
import {
  BalanceReportStateType,
  BalanceReportItemType,
} from 'containers/Administration/Reports/types';
import { ActionType } from 'reduxState/types';

const initialState: BalanceReportStateType = {};

const initialBalanceReportItemStateState: BalanceReportItemType = {
  error: null,
  isLoaded: false,
  isLoading: false,
  report: null,
  balanceId: null,
  dateRange: {
    startDate: constants.DEFAULT_FROM_DATE,
    endDate: constants.DEFAULT_END_DATE,
  },
};

const error: Reducer<BalanceReportItemType['error'], ActionType<any, { error: string }>> = (
  state = initialBalanceReportItemStateState.error,
  action,
) => {
  switch (action.type) {
    case constants.FETCH_BALANCE_REPORT_FAILURE:
      return action.payload.error;
    case constants.FETCH_BALANCE_REPORT_SUCCESS:
      return null;
    default:
      return state;
  }
};

const isLoaded: Reducer<BalanceReportItemType['isLoaded'], ActionType> = (
  state = initialBalanceReportItemStateState.isLoaded,
  action,
) => {
  switch (action.type) {
    case constants.FETCH_BALANCE_REPORT_SUCCESS:
      return true;
    default:
      return state;
  }
};

const isLoading: Reducer<BalanceReportItemType['isLoading'], ActionType> = (
  state = initialBalanceReportItemStateState.isLoading,
  action,
) => {
  switch (action.type) {
    case constants.FETCH_BALANCE_REPORT:
      return true;
    case constants.FETCH_BALANCE_REPORT_SUCCESS:
    case constants.FETCH_BALANCE_REPORT_FAILURE:
      return false;
    default:
      return state;
  }
};

const balanceId: Reducer<BalanceReportItemType['balanceId'], ActionType<any, { id: string }>> = (
  state = initialBalanceReportItemStateState.balanceId,
  action,
) => {
  switch (action.type) {
    case constants.FETCH_BALANCE_REPORT:
      return action.payload.id;
    default:
      return state;
  }
};

const dateRange: Reducer<
  BalanceReportItemType['dateRange'],
  ActionType<any, { dateRange: BalanceReportItemType['dateRange'] }>
> = (state = initialBalanceReportItemStateState.dateRange, action) => {
  switch (action.type) {
    case constants.UPDATE_DATE_RANGE:
      return {
        startDate: action.payload.dateRange.startDate || state.startDate,
        endDate: action.payload.dateRange.endDate || state.endDate,
      };
    default:
      return state;
  }
};

const balanceReportReducers = combineReducers({
  isLoading,
  isLoaded,
  error,
  balanceId,
  dateRange,
});

const balanceReportReducer: Reducer<BalanceReportStateType, ActionType<any, { id: string }>> = (
  state = initialState,
  action,
): BalanceReportStateType => {
  switch (action.type) {
    case constants.UPDATE_DATE_RANGE:
    case constants.FETCH_BALANCE_REPORT:
    case constants.FETCH_BALANCE_REPORT_SUCCESS:
    case constants.FETCH_BALANCE_REPORT_FAILURE:
      return {
        ...state,
        [action.payload.id]: balanceReportReducers(state[action.payload.id], action),
      };
    default:
      return state;
  }
};

export default balanceReportReducer;
