import { Moment } from 'moment';

export type DateRangeType = {
  startDate: Nullable<string | Moment>;
  endDate: Nullable<string | Moment>;
};

export type BalanceReportItemType = {
  error: Nullable<string>;
  balanceId: Nullable<string>;
  isLoading: boolean;
  isLoaded: boolean;
  dateRange: DateRangeType;
  report?: any;
};

export type BalanceReportStateType = {
  [key: string]: BalanceReportItemType;
};

export type ActionPayload = {
  payload: {
    id: string;
    until: string;
    from: string;
  };
};
