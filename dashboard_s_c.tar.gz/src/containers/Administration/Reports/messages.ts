import { defineMessages } from 'react-intl';
import { IntlMessages } from 'types/intl';

const messages: IntlMessages = defineMessages({
  title: {
    id: 'balance-report-title',
    defaultMessage: 'Report',
  },
  invalidDateMessage: {
    id: 'balance-report-invalid-date-message',
    defaultMessage: 'The balance report is available after {availableDate}.',
  },
  openBalance: {
    id: 'balance-report-open-balance',
    defaultMessage: 'Open balance',
  },
  netResult: {
    id: 'balance-report-net-result',
    defaultMessage: 'Net result',
  },
  onHold: {
    id: 'balance-report-on-hold',
    defaultMessage: 'On hold',
  },
  available: {
    id: 'balance-report-available',
    defaultMessage: 'Available',
  },
});

export default messages;
