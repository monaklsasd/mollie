import { ActionType } from 'reduxState/types';
import createApiActions from 'reduxState/factories/createApiActions';
import * as constants from './constants';

// Fetch balance report
export const [
  fetchBalanceReport,
  fetchBalanceReportSuccess,
  fetchBalanceReportFailure,
] = createApiActions({
  types: [
    constants.FETCH_BALANCE_REPORT,
    constants.FETCH_BALANCE_REPORT_SUCCESS,
    constants.FETCH_BALANCE_REPORT_FAILURE,
  ],
});

// Update date filter
export const updateDateRange = ({
  dateRange,
  id,
}: {
  dateRange: Record<string, any>;
  id: string;
}): ActionType<typeof constants.UPDATE_DATE_RANGE, Record<string, any>> => ({
  type: constants.UPDATE_DATE_RANGE,
  payload: {
    dateRange,
    id,
  },
});
