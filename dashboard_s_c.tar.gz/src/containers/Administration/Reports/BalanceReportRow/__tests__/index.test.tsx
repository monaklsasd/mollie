import React from 'react';

import createComponentWithIntl from 'helpers/createComponentWithIntl';
import BalanceReportRow from 'containers/Administration/Reports/BalanceReportRow/index';

describe('Balance Report > Balance Report Row', () => {
  const subtotalProps = {
    name: 'fee-prepayment',
    onHold: {
      count: 3,
      total: {
        value: '10.002',
        currency: 'EUR',
      },
    },
    available: {
      count: 3,
      total: {
        value: '10.000003',
        currency: 'EUR',
      },
    },
    subtotals: [
      {
        name: 'fee',
        onHold: {
          count: 1,
          total: {
            value: '0.2518999902', // <= This is the longest available on hold amount
            currency: 'EUR',
          },
        },
        available: {
          count: 1,
          total: {
            value: '-0.2518',
            currency: 'EUR',
          },
        },
        subtotals: [
          {
            name: 'ideal',
            onHold: {
              count: 2,
              total: {
                value: '0.3',
                currency: 'EUR',
              },
            },
            available: {
              count: 2,
              total: {
                value: '0.2',
                currency: 'EUR',
              },
            },
          },
        ],
      },
      {
        name: 'fee-vat',
        onHold: {
          count: 1,
          total: {
            value: '0.2518',
            currency: 'EUR',
          },
        },
        available: {
          count: 1,
          total: {
            value: '-0.052878',
            currency: 'EUR',
          },
        },
      },
      {
        name: 'fee-rounding-compensation',
        onHold: {
          count: 1,
          total: {
            value: '0.2518',
            currency: 'EUR',
          },
        },
        available: {
          count: 1,
          total: {
            value: '-0.05287832', // <= This is the longest available amount
            currency: 'EUR',
          },
        },
      },
    ],
  };

  const props = {
    className: 'custom-class',
    rowClassName: 'row-class-name',
    ...subtotalProps,
  };

  it('should render amounts with 2 fraction digits for top-level row and all fraction digits for child rows', () => {
    const tree = createComponentWithIntl(<BalanceReportRow level={1} {...props} />).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should render amounts with all fraction digits for all rows', () => {
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    const tree = createComponentWithIntl(<BalanceReportRow level={2} {...props} />).toJSON();
    expect(tree).toMatchSnapshot();
  });
});
