import React from 'react';
import classNames from 'classnames';
import { kebabCase } from 'lodash';
import { FormattedMessage } from 'react-intl';
import { max } from 'lodash';

// Components
import Currency from 'components/UI/Currency';
import IconPaymentMethods, { AcceptedMethods } from 'components/IconPaymentMethods';

// Icons
import { ReactComponent as ChevronDownIcon } from 'assets/icons/chevron-down.svg';

// Helpers
import { isPaymentMethod, PaymentMethod } from 'helpers/paymentMethods';

import messages, { rowNames } from './messages';
import getLocalizedMethodName from 'utils/getLocalizedMethodName';
import { TOP_ROW_LEVEL } from '../constants';

// Stylesheets
import './styles.scss';

// Types
import { BalanceReportSubtotalType } from 'reduxState/modules/balanceReports/types';
import { ClassnamesFunction } from 'types/helpers';

type Props = BalanceReportSubtotalType & {
  className: string;
  collapsedClassName?: string;
  level: number;
  rowClassName: string;
  startDateLabel?: string;
  endDateLabel?: string;
  maxFractionDigitLengthInOnHoldColumn?: Nullable<number>;
  maxFractionDigitLengthInAvailableColumn?: Nullable<number>;
};

type State = {
  isOpen: boolean;
};

const getClass: ClassnamesFunction<Props & { isCollapsable: boolean; isOpen: boolean }> = ({
  className,
  isCollapsable,
  isOpen,
  level,
}) =>
  classNames('balance-report-row', className, `balance-report-row--level-${level}`, {
    'balance-report__row--collapsable': isCollapsable,
    'is-open': isOpen,
    [`${className}--collapsed`]: isOpen,
  });

export default class BalanceReportRow extends React.Component<Props, State> {
  state = {
    isOpen: false,
  };

  containerEl: { current: null | HTMLDivElement } = React.createRef();

  toggleBreakdownCallback = (): void => {
    if (!this.containerEl || !this.containerEl.current) {
      return;
    }

    const currentEl = this.containerEl.current;
    const { isOpen } = this.state;
    const { className } = this.props;

    if (currentEl.previousElementSibling) {
      currentEl.previousElementSibling.classList.toggle(`${className}--above-collapsed`, isOpen);
    }

    if (currentEl.nextElementSibling) {
      currentEl.nextElementSibling.classList.toggle(`${className}--below-collapsed`, isOpen);
    }

    // Make sure there's always a border-bottom on the current element when it closes itself but
    // next sibling is open.
    if (
      !isOpen &&
      currentEl.nextElementSibling &&
      currentEl.nextElementSibling.classList.contains(`${className}--collapsed`)
    ) {
      currentEl.classList.add(`${className}--above-collapsed`);
    }
  };

  toggleBreakdown = (e: React.MouseEvent<any>): void => {
    e.preventDefault();

    if (!this.props.subtotals || this.props.subtotals.length === 0) {
      return;
    }

    this.setState(
      {
        isOpen: !this.state.isOpen,
      },
      this.toggleBreakdownCallback,
    );
  };

  getFractionDigitsLength(value: number | string): number {
    return String(value).split('.')[1].length;
  }

  /**
   * Sometimes amounts (e.g. VAT) have more than 2 fraction digits. We need to take the number with
   * the highest amount of fraction digits, and make sure the other totals in this column have the
   * same amount of fraction digits.
   *
   * Example:
   *
   * fee-prepayment              € 9,83 < clicking this will 'expand' it into the three rows below
   * ----------------------------------
   * - fees                  € 8,120400 < note the two extra zeroes
   * - VAT                   € 1,705284
   * - diff                  € 0,004316
   *
   * @ticket: DASH-1632
   */
  calculateMaxFractionDigitsForSubtotals(): Record<string, any> {
    const {
      subtotals,
      name,
      maxFractionDigitLengthInOnHoldColumn,
      maxFractionDigitLengthInAvailableColumn,
    } = this.props;

    if (!name.includes('fee-prepayment') || !subtotals || (subtotals && subtotals.length === 0)) {
      return {
        maxFractionDigitLengthInOnHoldColumn,
        maxFractionDigitLengthInAvailableColumn,
      };
    }

    const maxFractionDigitsForOnHoldSubtotals = max(
      subtotals.map(total =>
        total.onHold.total ? this.getFractionDigitsLength(total.onHold.total.value) : null,
      ),
    );
    const maxFractionDigitsForAvailableSubtotals = max(
      subtotals.map(total =>
        total.available.total ? this.getFractionDigitsLength(total.available.total.value) : null,
      ),
    );

    return {
      maxFractionDigitLengthInOnHoldColumn: maxFractionDigitsForOnHoldSubtotals,
      maxFractionDigitLengthInAvailableColumn: maxFractionDigitsForAvailableSubtotals,
    };
  }

  renderDateRange(): React.ReactNode {
    const { startDateLabel, endDateLabel, level, name } = this.props;

    if (level === TOP_ROW_LEVEL && startDateLabel && name === 'opening-balance') {
      return <span className="balance-report-row__date">({startDateLabel})</span>;
    }

    if (level === TOP_ROW_LEVEL && startDateLabel && name === 'closing-balance') {
      return <span className="balance-report-row__date">({endDateLabel})</span>;
    }
  }

  render(): React.ReactElement {
    const {
      name,
      available,
      className,
      subtotals,
      level,
      onHold,
      rowClassName,
      maxFractionDigitLengthInOnHoldColumn,
      maxFractionDigitLengthInAvailableColumn,
    } = this.props;
    const { isOpen } = this.state;
    const hasSubtotals = subtotals && subtotals.length > 0;
    const dateRange = this.renderDateRange();
    const fractionDigitProps = this.calculateMaxFractionDigitsForSubtotals();
    const rowCount = available.count || onHold.count || null;

    return (
      <div
        className={getClass({
          className,
          isCollapsable: hasSubtotals,
          isOpen,
          level,
        })}
        ref={this.containerEl}>
        <div className={classNames('balance-report-row__container', rowClassName)}>
          {hasSubtotals && (
            <FormattedMessage {...messages.showDetails}>
              {(labelMessage: string): React.ReactNode => (
                <button
                  aria-controls={`transaction-detail-${kebabCase(name)}`}
                  className="balance-report-row__collapse-button"
                  aria-label={labelMessage}
                  onClick={this.toggleBreakdown}
                />
              )}
            </FormattedMessage>
          )}
          <span className="balance-report-row__name">
            {hasSubtotals && <ChevronDownIcon className="balance-report-row__collapse-icon" />}
            {isPaymentMethod(name as PaymentMethod) && (
              <span className="balance-report-row__payment-icon">
                <IconPaymentMethods method={name as AcceptedMethods} width={25} height={25} />
              </span>
            )}
            {rowNames[name] ? (
              <FormattedMessage {...rowNames[name]} />
            ) : (
              getLocalizedMethodName(name)
            )}{' '}
            {dateRange}
          </span>
          <span className="balance-report-row__quantity">
            {!!rowCount && (
              <span className="balance-report-row__onhold-quantity">{`${rowCount} ×`}&nbsp;</span>
            )}
          </span>
          <span className="balance-report-row__on-hold-total balance-report-row__total">
            {onHold.total && (
              <Currency
                {...onHold.total}
                {...(maxFractionDigitLengthInOnHoldColumn
                  ? { minimumFractionDigits: maxFractionDigitLengthInOnHoldColumn }
                  : null)}
              />
            )}
          </span>
          <span className="balance-report-row__available-total balance-report-row__total">
            {available.total && (
              <Currency
                {...available.total}
                {...(maxFractionDigitLengthInAvailableColumn
                  ? { minimumFractionDigits: maxFractionDigitLengthInAvailableColumn }
                  : null)}
              />
            )}
          </span>
        </div>
        <div
          className="balance-report-row__breakdown-items"
          aria-expanded={this.state.isOpen}
          id={`transaction-detail-${kebabCase(name)}`}>
          {subtotals &&
            subtotals.map(subtotal => (
              <BalanceReportRow
                className="balance-report-row__breakdown-item"
                level={level + 1}
                key={`row-${level + 1}-${subtotal.name}`}
                rowClassName={rowClassName}
                {...subtotal}
                {...fractionDigitProps}
              />
            ))}
        </div>
      </div>
    );
  }
}
