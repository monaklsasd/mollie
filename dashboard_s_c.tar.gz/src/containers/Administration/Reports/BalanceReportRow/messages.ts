import { defineMessages } from 'react-intl';
import { IntlMessages } from 'types/intl';

const messages: IntlMessages = defineMessages({
  showDetails: {
    id: 'balance-report-row-show-details',
    defaultMessage: 'Show details',
  },
});

export const rowNames = defineMessages({
  'fee-discount': {
    id: 'balance-report-row-fee-discount',
    defaultMessage: 'Discounts',
  },
  'payments-released': {
    id: 'balance-report-row-payments-released',
    defaultMessage: 'Payments released',
  },
  'new-incoming-payments': {
    id: 'balance-report-row-new-incoming-payments',
    defaultMessage: 'New incoming payments',
  },
  'refunds-chargebacks': {
    id: 'balance-report-row-refunds-chargebacks',
    defaultMessage: 'Deductions',
  },
  payment: {
    id: 'balance-report-row-payment',
    defaultMessage: 'Payments',
  },
  'split-payment': {
    id: 'balance-report-row-split-payment',
    defaultMessage: 'Split payments',
  },
  'fee-prepayment': {
    id: 'balance-report-row-fee-prepayments',
    defaultMessage: 'Withheld transaction fees',
  },
  'chargeback-reversal': {
    id: 'balance-report-row-chargeback-reversal',
    defaultMessage: 'Reversed chargebacks',
  },
  fee: {
    id: 'balance-report-row-fee',
    defaultMessage: 'Fees',
  },
  'payment-fee': {
    id: 'balance-report-row-payment-fee',
    defaultMessage: 'Payment method fees',
  },
  'fee-vat': {
    id: 'balance-report-row-fee-vat',
    defaultMessage: 'VAT',
  },
  'application-fee': {
    id: 'balance-report-row-application-fee',
    defaultMessage: 'Application fees',
  },
  'fee-rounding-compensation': {
    id: 'balance-report-row-fee-rounding-compensation',
    defaultMessage: 'Rounding differences',
  },
  refund: {
    id: 'balance-report-row-refund',
    defaultMessage: 'Refunds',
  },
  'returned-refund': {
    id: 'balance-report-row-returned-refund',
    defaultMessage: 'Returned refunds',
  },
  chargeback: {
    id: 'balance-report-row-chargeback',
    defaultMessage: 'Chargebacks',
  },
  'outgoing-transfer': {
    id: 'balance-report-row-outgoing-transfer',
    defaultMessage: 'Outgoing transfers',
  },
  'incoming-transfer': {
    id: 'balance-report-row-incoming-transfer',
    defaultMessage: 'Incoming transfers',
  },
  'canceled-transfer': {
    id: 'balance-report-row-canceled-transfer',
    defaultMessage: 'Canceled transfers',
  },
  'returned-transfer': {
    id: 'balance-report-row-returned-transfer',
    defaultMessage: 'Returned transfers',
  },
  'deductions-reimbursements': {
    id: 'balance-report-row-deductions-reimbursements',
    defaultMessage: 'Deductions and reimbursements',
  },
  'fee-reimbursement': {
    id: 'balance-report-row-fee-reimbursement',
    defaultMessage: 'Reimbursements',
  },
  'rolling-reservation': {
    id: 'balance-report-row-rolling-reservation',
    defaultMessage: 'Rolling Reserve Reservation',
  },
  'rolling-release': {
    id: 'balance-report-row-rolling-release',
    defaultMessage: 'Rolling Reserve Release',
  },
  'refund-fee': {
    id: 'balance-report-row-refund-fee',
    defaultMessage: 'Refund Fee',
  },
  'payment-notification-fee': {
    id: 'balance-report-row-payment-notification-fee',
    defaultMessage: 'Payment Notification',
  },
  'transfer-notification-fee': {
    id: 'balance-report-row-transfer-notification-fee',
    defaultMessage: 'Transfer Notification',
  },
  'failed-payment': {
    id: 'balance-report-row-failed-payment',
    defaultMessage: 'Payment Failure',
  },
  'direct-debit-failure-fee': {
    id: 'balance-report-row-direct-debit-failure-fee',
    defaultMessage: 'Failure Fees',
  },
  'chargeback-fee': {
    id: 'balance-report-row-chargeback-fee',
    defaultMessage: 'Chargeback Fees',
  },
  'invoice-rounding-compensation': {
    id: 'balance-report-row-invoice-rounding-compensation',
    defaultMessage: 'Invoice Payment',
  },

  // transaction-categories
  'opening-balance': {
    id: 'balance-report-row-opening-balance',
    defaultMessage: 'Opening balance',
  },
  'opening-balance-incoming-payment': {
    id: 'balance-report-row-opening-balance-incoming-payment',
    defaultMessage: 'Payments still pending',
  },
  'opening-balance-incoming-fee-prepayment': {
    id: 'balance-report-row-opening-balance-incoming-fee-prepayment',
    defaultMessage: 'Fees still pending',
  },
  'opening-balance-incoming-fee': {
    id: 'balance-report-row-opening-balance-incoming-fee',
    defaultMessage: 'Fees',
  },
  'opening-balance-incoming-payment-fee': {
    id: 'balance-report-row-opening-balance-incoming-payment-fee',
    defaultMessage: 'Payment method fees',
  },
  'opening-balance-incoming-fee-vat': {
    id: 'balance-report-row-opening-balance-incoming-fee-vat',
    defaultMessage: 'Fee VAT',
  },
  'opening-balance-incoming-fee-rounding-compensation': {
    id: 'balance-report-row-opening-balance-incoming-fee-rounding-compensation',
    defaultMessage: 'Fee rounding differences',
  },
  payments: {
    id: 'balance-report-row-payments',
    defaultMessage: 'Payments',
  },
  'payment-incoming-payment': {
    id: 'balance-report-row-payment-incoming-payment',
    defaultMessage: 'Pending payments',
  },
  'payment-incoming-rolling-reserve-hold': {
    id: 'balance-report-row-payment-incoming-rolling-reserve-hold',
    defaultMessage: 'Pending rolling reserve hold',
  },
  'payment-incoming-rolling-reserve-release': {
    id: 'balance-report-row-payment-incoming-rolling-reserve-release',
    defaultMessage: 'Pending rolling reserve release',
  },
  'payment-moved-to-available-payment': {
    id: 'balance-report-row-payment-moved-to-available-payment',
    defaultMessage: 'Payments released',
  },
  'payment-moved-to-available-rolling-reserve-hold': {
    id: 'balance-report-row-payment-moved-to-available-rolling-reserve-hold',
    defaultMessage: 'Rolling reserve withheld',
  },
  'payment-moved-to-available-rolling-reserve-release': {
    id: 'balance-report-row-payment-moved-to-available-rolling-reserve-release',
    defaultMessage: 'Rolling reserve released',
  },
  'payment-immediately-available-payment': {
    id: 'balance-report-row-payment-immediately-available-payment',
    defaultMessage: 'Payments released directly',
  },
  'payment-immediately-available-failed-payment': {
    id: 'balance-report-row-payment-immediately-available-failed-payment',
    defaultMessage: 'Failed payments',
  },
  deductions: {
    id: 'balance-report-row-deductions',
    defaultMessage: 'Deductions',
  },
  'deductions-immediately-available-refund': {
    id: 'balance-report-row-deductions-immediately-available-refund',
    defaultMessage: 'Refunds',
  },
  'deductions-immediately-available-chargeback': {
    id: 'balance-report-row-deductions-immediately-available-chargeback',
    defaultMessage: 'Chargebacks',
  },
  transfers: {
    id: 'balance-report-row-transfers',
    defaultMessage: 'Transfers',
  },
  'transfers-immediately-available-outgoing-transfer': {
    id: 'balance-report-row-transfers-immediately-available-outgoing-transfer',
    defaultMessage: 'Outgoing transfers',
  },
  corrections: {
    id: 'balance-report-row-corrections',
    defaultMessage: 'Corrections',
  },
  'corrections-immediately-available-balance-correction': {
    id: 'balance-report-row-corrections-immediately-available-balance-correction',
    defaultMessage: 'Corrections',
  },
  prepayments: {
    id: 'balance-report-row-prepayments',
    defaultMessage: 'Fees charged',
  },
  'prepayments-incoming-fee-prepayment': {
    id: 'balance-report-row-prepayments-incoming-fee-prepayment',
    defaultMessage: 'Pending fees',
  },
  'prepayments-incoming-fee': {
    id: 'balance-report-row-prepayments-incoming-fee',
    defaultMessage: 'Fees',
  },
  'prepayments-incoming-payment-fee': {
    id: 'balance-report-row-prepayments-incoming-payment-fee',
    defaultMessage: 'Payment method fees',
  },
  'prepayments-incoming-application-fee': {
    id: 'balance-report-row-prepayments-incoming-application-fee',
    defaultMessage: 'Application fees',
  },
  'prepayments-incoming-fee-discount': {
    id: 'balance-report-row-prepayments-incoming-fee-discount',
    defaultMessage: 'Payment method fee discounts',
  },
  'prepayments-incoming-fee-vat': {
    id: 'balance-report-row-prepayments-incoming-fee-vat',
    defaultMessage: 'Fee VAT',
  },
  'prepayments-incoming-fee-rounding-compensation': {
    id: 'balance-report-row-prepayments-incoming-fee-rounding-compensation',
    defaultMessage: 'Fee rounding differences',
  },
  'prepayments-moved-to-available-fee-prepayment': {
    id: 'balance-report-row-prepayments-moved-to-available-fee-prepayment',
    defaultMessage: 'Pending fees charged',
  },
  'prepayments-moved-to-available-fee': {
    id: 'balance-report-row-prepayments-moved-to-available-fee',
    defaultMessage: 'Fees',
  },
  'prepayments-moved-to-available-payment-fee': {
    id: 'balance-report-row-prepayments-moved-to-available-payment-fee',
    defaultMessage: 'Payment method fees',
  },
  'prepayments-moved-to-available-application-fee': {
    id: 'balance-report-row-prepayments-moved-to-available-application-fee',
    defaultMessage: 'Application fees',
  },
  'prepayments-moved-to-available-fee-discount': {
    id: 'balance-report-row-prepayments-moved-to-available-fee-discount',
    defaultMessage: 'Payment method fee discounts',
  },
  'prepayments-moved-to-available-fee-vat': {
    id: 'balance-report-row-prepayments-moved-to-available-fee-vat',
    defaultMessage: 'Fee VAT',
  },
  'prepayments-moved-to-available-fee-rounding-compensation': {
    id: 'balance-report-row-prepayments-moved-to-available-fee-rounding-compensation',
    defaultMessage: 'Fee rounding differences',
  },
  'prepayments-immediately-available-fee-prepayment': {
    id: 'balance-report-row-prepayments-immediately-available-fee-prepayment',
    defaultMessage: 'Fees charged directly',
  },
  'prepayments-immediately-available-fee': {
    id: 'balance-report-row-prepayments-immediately-available-fee',
    defaultMessage: 'Fees',
  },
  'prepayments-immediately-available-payment-fee': {
    id: 'balance-report-row-prepayments-immediately-available-payment-fee',
    defaultMessage: 'Payment method fees',
  },
  'prepayments-immediately-available-direct-debit-failure-fee': {
    id: 'balance-report-row-prepayments-immediately-available-direct-debit-failure-fee',
    defaultMessage: 'SEPA Direct Debit failure fees',
  },
  'prepayments-immediately-available-unauthorized-direct-debit-fee': {
    id: 'balance-report-row-prepayments-immediately-available-unauthorized-direct-debit-fee',
    defaultMessage: 'Unauthorized SEPA Direct Debit fees',
  },
  'prepayments-immediately-available-bank-charged-direct-debit-failure-fee': {
    id:
      'balance-report-row-prepayments-immediately-available-bank-charged-direct-debit-failure-fee',
    defaultMessage: 'SEPA Direct Debit bank charged failure fees',
  },
  'prepayments-immediately-available-refund-fee': {
    id: 'balance-report-row-prepayments-immediately-available-refund-fee',
    defaultMessage: 'Refund fees',
  },
  'prepayments-immediately-available-chargeback-fee': {
    id: 'balance-report-row-prepayments-immediately-available-chargeback-fee',
    defaultMessage: 'Chargeback fees',
  },
  'prepayments-immediately-available-fee-discount': {
    id: 'balance-report-row-prepayments-immediately-available-fee-discount',
    defaultMessage: 'Payment method fee discounts',
  },
  'prepayments-immediately-available-fee-vat': {
    id: 'balance-report-row-prepayments-immediately-available-fee-vat',
    defaultMessage: 'Fee VAT',
  },
  'prepayments-immediately-available-fee-rounding-compensation': {
    id: 'balance-report-row-prepayments-immediately-available-fee-rounding-compensation',
    defaultMessage: 'Fee rounding differences',
  },
  'prepayments-immediately-available-invoice-rounding-compensation': {
    id: 'balance-report-row-prepayments-immediately-available-invoice-rounding-compensation',
    defaultMessage: 'Invoice rounding compensations',
  },
  'closing-balance': {
    id: 'balance-report-row-closing-balance',
    defaultMessage: 'Closing balance',
  },
  'closing-balance-incoming-payment': {
    id: 'balance-report-row-closing-balance-incoming-payment',
    defaultMessage: 'Payments still pending',
  },
  'closing-balance-incoming-fee-prepayment': {
    id: 'balance-report-row-closing-balance-incoming-fee-prepayment',
    defaultMessage: 'Fees still pending',
  },
  'closing-balance-incoming-fee': {
    id: 'balance-report-row-closing-balance-incoming-fee',
    defaultMessage: 'Fees',
  },
  'closing-balance-incoming-payment-fee': {
    id: 'balance-report-row-closing-balance-incoming-payment-fee',
    defaultMessage: 'Payment method fees',
  },
  'closing-balance-incoming-fee-discount': {
    id: 'balance-report-row-closing-balance-incoming-fee-discount',
    defaultMessage: 'Payment method fee discounts',
  },
  'closing-balance-incoming-rolling-reserve-hold': {
    id: 'balance-report-row-closing-balance-incoming-rolling-reserve-hold',
    defaultMessage: 'Rolling reserve hold still pending',
  },
  'closing-balance-incoming-rolling-reserve-release': {
    id: 'balance-report-row-closing-balance-incoming-rolling-reserve-release',
    defaultMessage: 'Rolling reserve release still pending',
  },
});

export default messages;
