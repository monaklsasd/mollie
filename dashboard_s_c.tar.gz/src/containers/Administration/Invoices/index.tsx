import * as React from 'react';
import { connect } from 'react-redux';
import { FormattedMessage, FormattedNumber, FormattedDate, injectIntl } from 'react-intl';
import Helmet from 'react-helmet';

// Containers
import PageWrapper from 'containers/PageWrapper';
import RequirePermissions, { Permissions } from 'containers/RequirePermissions';

// Components
import Link from 'components/UI/Link';
import Layout from 'components/UI/Layout';
import Empty from 'components/UI/Empty';
import FlashMessage from 'components/UI/FlashMessage';
import LoadingState from 'components/UI/LoadingState';
import StatusBlock from 'components/UI/StatusBlock';
import Wrapper from 'components/UI/Wrapper';
import GridTable from 'components/UI/GridTable';
import GridTableRow from 'components/UI/GridTable/Row';
import GridTableCell from 'components/UI/GridTable/Cell';

// Internals
import Sidebar from './Sidebar';
import messages from './messages';
import getQueryStringFilters from 'helpers/getQueryStringFilters';

// Redux
import { getApiBaseUrl } from 'reduxState/modules/application/selectors';
import { getFirstPaymentDateWithFallback } from 'reduxState/modules/organization/selectors';
import * as actions from 'reduxState/modules/invoices';

// Utils
import MollieURL from 'utils/MollieURL';
import shallowEqual from 'utils/shallowEqual';

// messages
import { tables } from 'messages';

// Types
import { IntlShape } from 'react-intl';
import { Location, History } from 'history';
import { State as ReduxState } from 'reduxState/types';
import { Filters } from 'containers/Administration';
import { ProtectedRouteComponentProps } from 'components/ProtectedRouter/ProtectedRoute';

import './styles.scss';

type OwnProps = ProtectedRouteComponentProps & {
  filters: Filters;
  defaultFilters: Filters;
  location: Location<{}, { highlight: string }>;
  history: History;
};

type ReduxStateProps = {
  invoices: ReduxState['invoices'];
  apiBaseUrl: string;
  firstPaymentDate: Date;
};

type ReduxDispatchProps = {
  loadInvoices: typeof actions.loadInvoices;
};

type Props = OwnProps & ReduxStateProps & ReduxDispatchProps & { intl: IntlShape };

type State = {
  currentInvoiceId: Nullable<string>;
};

class AdministrationInvoices extends React.Component<Props, State> {
  constructor(props) {
    super(props);

    this.state = {
      currentInvoiceId: null,
    };
  }

  componentDidMount(): void {
    const { filters, loadInvoices } = this.props;

    loadInvoices(filters);
  }

  componentDidUpdate(prevProps): void {
    const { filters, loadInvoices } = this.props;

    if (!shallowEqual(prevProps.filters, filters)) {
      loadInvoices(filters);
    }
  }

  handleDownload(id: string): void {
    this.setState({
      currentInvoiceId: id,
    });

    /*
     * Wrap in rAF because we have to wait for the invisible download link to
     * be rendered with the new url.
     */
    requestAnimationFrame(() => {
      if (this.downloadLink) {
        this.downloadLink.click();
      }
    });
  }

  onUpdateYearQuery = (value): void => {
    const { filters, defaultFilters, location, history } = this.props;
    const query = getQueryStringFilters({ ...filters, year: parseInt(value, 10) }, defaultFilters);

    history.replace({
      pathname: location.pathname,
      query,
    });
  };

  renderInvoices(): React.ReactElement {
    const { invoices, intl, location } = this.props;
    const highlightedId = location.query.highlight;

    if (invoices.error) {
      return <FlashMessage state="error">{invoices.error}</FlashMessage>;
    }

    if (!invoices.isLoading && invoices.totalCount === 0) {
      return (
        <Empty
          title={intl.formatMessage(messages.emptyTitle)}
          explanation={intl.formatMessage(messages.emptyExplanation)}
        />
      );
    }

    return (
      <GridTable
        className="administration-invoices-table"
        columnRow={[
          <GridTableCell name="date">
            <FormattedMessage {...tables.date} />
          </GridTableCell>,
          <GridTableCell name="invoice-number">
            <FormattedMessage id="invoices-list-invoice-number" defaultMessage="Invoice number" />
          </GridTableCell>,
          <GridTableCell name="excl-vat" numeric>
            <FormattedMessage {...tables.exclVat} />
          </GridTableCell>,
          <GridTableCell name="incl-vat" numeric>
            <FormattedMessage {...tables.vat} />
          </GridTableCell>,
          <GridTableCell name="total" numeric>
            <FormattedMessage {...tables.total} />
          </GridTableCell>,
        ]}>
        {invoices.data.map(item => (
          <GridTableRow
            key={item.id}
            isHighlighted={!!(highlightedId && highlightedId === item.id)}>
            <GridTableCell name="date">
              <FormattedDate
                value={new Date(item.issueDate)}
                day="numeric"
                month="long"
                year="numeric"
              />
            </GridTableCell>
            <GridTableCell name="invoice-number">
              <RequirePermissions
                permissions={[Permissions.PAYMENTS_READ, Permissions.SETTLEMENTS_READ]}>
                {(hasPermission): React.ReactNode =>
                  hasPermission ? (
                    <Link
                      linkStyle="blue"
                      noUnderline
                      onClick={(): void => {
                        this.handleDownload(item.id);
                      }}>
                      {item.reference}&nbsp;
                      <StatusBlock status="neutral">PDF</StatusBlock>
                    </Link>
                  ) : (
                    <StatusBlock status="neutral">PDF</StatusBlock>
                  )
                }
              </RequirePermissions>
            </GridTableCell>
            <GridTableCell name="excl-vat" numeric>
              <FormattedNumber value={item.amount.net} format="EUR" />
            </GridTableCell>
            <GridTableCell name="incl-vat" numeric>
              <FormattedNumber value={item.amount.vat} format="EUR" />
            </GridTableCell>
            <GridTableCell name="total" numeric>
              <FormattedNumber value={item.amount.gross} format="EUR" />
            </GridTableCell>
          </GridTableRow>
        ))}
      </GridTable>
    );
  }

  downloadLink: Nullable<HTMLAnchorElement> = null;

  render(): React.ReactElement {
    const { apiBaseUrl, invoices, filters, firstPaymentDate, intl } = this.props;

    return (
      <PageWrapper title={<FormattedMessage {...messages.title} values={{ year: filters.year }} />}>
        <Helmet title={intl.formatMessage(messages.title, { year: filters.year })} />
        <Wrapper isLast>
          <Layout
            sidebar={
              <Sidebar
                filters={filters}
                onUpdateYearQuery={this.onUpdateYearQuery}
                minYear={firstPaymentDate.getFullYear()}
              />
            }>
            <LoadingState isLoading={invoices.isLoading}>{this.renderInvoices()}</LoadingState>
            <RequirePermissions
              permissions={[Permissions.PAYMENTS_READ, Permissions.SETTLEMENTS_READ]}>
              {/* eslint-disable jsx-a11y/anchor-has-content */}
              <a
                aria-hidden
                href={MollieURL.createStatementsDownload(
                  apiBaseUrl,
                  'invoices',
                  this.state.currentInvoiceId,
                )}
                ref={(c): void => {
                  this.downloadLink = c;
                }}
              />
              {/* eslint-enable jsx-a11y/anchor-has-content */}
            </RequirePermissions>
          </Layout>
        </Wrapper>
      </PageWrapper>
    );
  }
}

const mapStateToProps = (state: ReduxState) => ({
  apiBaseUrl: getApiBaseUrl(state),
  firstPaymentDate: new Date(getFirstPaymentDateWithFallback(state)),
  invoices: state.invoices,
});

export default connect(mapStateToProps, actions)(injectIntl(AdministrationInvoices));
