import createApiActions from 'reduxState/factories/createApiActions';
import { paymentSchema, refundSchema, chargebackSchema } from 'reduxState/schemas';
import * as constants from './constants';

/*
 * Settlement
 */
export const {
  execute: fetchSettlement,
  success: fetchSettlementSuccess,
  failure: fetchSettlementFailure,
} = createApiActions({
  types: {
    execute: constants.FETCH_SETTLEMENT,
    success: constants.FETCH_SETTLEMENT_SUCCESS,
    failure: constants.FETCH_SETTLEMENT_FAILURE,
  },
});

/*
 * Export
 */
export const createSettlementExport = payload => ({
  type: constants.CREATE_SETTLEMENT_EXPORT,
  payload,
});

/*
 * Payments
 */
const fetchPaymentsActions = createApiActions({
  types: {
    execute: constants.FETCH_SETTLEMENT_PAYMENTS,
    success: constants.FETCH_SETTLEMENT_PAYMENTS_SUCCESS,
    failure: constants.FETCH_SETTLEMENT_PAYMENTS_FAILURE,
  },
  schema: [paymentSchema],
  schemaType: 'array',
});

export const fetchPayments = fetchPaymentsActions.execute;
export const fetchPaymentsSuccess = fetchPaymentsActions.success;
export const fetchPaymentsFailure = fetchPaymentsActions.failure;

const fetchMorePaymentsActions = createApiActions({
  types: {
    execute: constants.FETCH_MORE_SETTLEMENT_PAYMENTS,
    success: constants.FETCH_MORE_SETTLEMENT_PAYMENTS_SUCCESS,
    failure: constants.FETCH_MORE_SETTLEMENT_PAYMENTS_FAILURE,
  },
  schema: [paymentSchema],
  schemaType: 'array',
});

export const fetchMorePayments = fetchMorePaymentsActions.execute;
export const fetchMorePaymentsSuccess = fetchMorePaymentsActions.success;
export const fetchMorePaymentsFailure = fetchMorePaymentsActions.failure;

/*
 * Refunds
 */
const fetchRefundsActions = createApiActions({
  types: {
    execute: constants.FETCH_SETTLEMENT_REFUNDS,
    success: constants.FETCH_SETTLEMENT_REFUNDS_SUCCESS,
    failure: constants.FETCH_SETTLEMENT_REFUNDS_FAILURE,
  },
  schema: [refundSchema],
  schemaType: 'array',
});

export const fetchRefunds = fetchRefundsActions.execute;
export const fetchRefundsSuccess = fetchRefundsActions.success;
export const fetchRefundsFailure = fetchRefundsActions.failure;

const fetchMoreRefundsActions = createApiActions({
  types: {
    execute: constants.FETCH_MORE_SETTLEMENT_REFUNDS,
    success: constants.FETCH_MORE_SETTLEMENT_REFUNDS_SUCCESS,
    failure: constants.FETCH_MORE_SETTLEMENT_REFUNDS_FAILURE,
  },
  schema: [refundSchema],
  schemaType: 'array',
});

export const fetchMoreRefunds = fetchMoreRefundsActions.execute;
export const fetchMoreRefundsSuccess = fetchMoreRefundsActions.success;
export const fetchMoreRefundsFailure = fetchMoreRefundsActions.failure;

/*
 * Chargebacks
 */
const fetchChargebacksActions = createApiActions({
  types: {
    execute: constants.FETCH_SETTLEMENT_CHARGEBACKS,
    success: constants.FETCH_SETTLEMENT_CHARGEBACKS_SUCCESS,
    failure: constants.FETCH_SETTLEMENT_CHARGEBACKS_FAILURE,
  },
  schema: [chargebackSchema],
  schemaType: 'array',
});

export const fetchChargebacks = fetchChargebacksActions.execute;
export const fetchChargebacksSuccess = fetchChargebacksActions.success;
export const fetchChargebacksFailure = fetchChargebacksActions.failure;

const fetchMoreChargebacksActions = createApiActions({
  types: {
    execute: constants.FETCH_MORE_SETTLEMENT_CHARGEBACKS,
    success: constants.FETCH_MORE_SETTLEMENT_CHARGEBACKS_SUCCESS,
    failure: constants.FETCH_MORE_SETTLEMENT_CHARGEBACKS_FAILURE,
  },
  schema: [chargebackSchema],
  schemaType: 'array',
});

export const fetchMoreChargebacks = fetchMoreChargebacksActions.execute;
export const fetchMoreChargebacksSuccess = fetchMoreChargebacksActions.success;
export const fetchMoreChargebacksFailure = fetchMoreChargebacksActions.failure;
