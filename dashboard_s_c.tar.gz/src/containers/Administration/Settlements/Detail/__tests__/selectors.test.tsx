/* eslint-disable @typescript-eslint/camelcase */
import * as selectors from '../selectors';
import { State as ReduxState } from 'reduxState/types';

describe('SettlementDetail:selectors', () => {
  const id = 'stl_abc';

  const state: ReduxState = ({
    payments: {},
    settlements: {
      byId: {},
    },
    settlementDetail: {},
  } as unknown) as ReduxState;

  const stateWithSettlement = ({
    ...state,
    settlements: {
      byId: {
        [id]: {
          data: {
            id,
          },
          error: null,
          isLoading: false,
          updatedAt: 0,
        },
      },
    },
    settlementDetail: {
      [id]: {
        payments: {
          ids: [],
          isLoading: false,
          isLoaded: true,
          error: null,
          pagination: {
            totalCount: 0,
            offset: 0,
            count: 0,
            isLoading: false,
            error: null,
          },
        },
        refunds: {
          ids: [],
          isLoading: false,
          isLoaded: true,
          error: null,
          pagination: {
            totalCount: 0,
            offset: 0,
            count: 0,
            isLoading: false,
            error: null,
          },
        },
        chargebacks: {
          ids: [],
          isLoading: false,
          isLoaded: true,
          error: null,
          pagination: {
            totalCount: 0,
            offset: 0,
            count: 0,
            isLoading: false,
            error: null,
          },
        },
      },
    },
  } as unknown) as ReduxState;

  const stateWithPayments = ({
    ...stateWithSettlement,
    payments: {
      tr_abc: {
        id: 'tr_abc',
      },
    },
    settlementDetail: {
      [id]: {
        ...stateWithSettlement.settlementDetail[id],
        payments: {
          ids: ['tr_abc'],
          isLoading: false,
          isLoaded: true,
          error: null,
        },
      },
    },
  } as unknown) as ReduxState;

  const stateWithRefunds = ({
    ...stateWithSettlement,
    refunds: {
      re_abc: {
        id: 're_abc',
      },
    },
    settlementDetail: {
      [id]: {
        ...stateWithSettlement.settlementDetail[id],
        refunds: {
          ids: ['re_abc'],
          isLoading: false,
          isLoaded: true,
          error: null,
        },
      },
    },
  } as unknown) as ReduxState;

  const stateWithChargebacks = ({
    ...stateWithSettlement,
    chargebacks: {
      ch_abc: {
        id: 'ch_abc',
      },
    },
    settlementDetail: {
      [id]: {
        ...stateWithSettlement.settlementDetail[id],
        chargebacks: {
          ids: ['ch_abc'],
          isLoading: false,
          isLoaded: true,
          error: null,
        },
      },
    },
  } as unknown) as ReduxState;

  describe('payments selectors', function() {
    it('should return the payments when found in state', () => {
      const actual = selectors.getSettlementPayments(stateWithPayments, id);
      expect(actual).toEqual([
        {
          ...stateWithPayments.payments.tr_abc,
        },
      ]);
    });

    it('should return empty array when there are no payments found in state', () => {
      const actual = selectors.getSettlementPayments(stateWithSettlement, id);
      expect(actual).toEqual([]);
    });

    it('should memoized correctly when selector getSettlementPayments is called twice ', () => {
      const memoizeId = 'mem_abc';
      // reset Recomputations to 0
      selectors.getSettlementPayments.resetRecomputations();
      // to be sure recomputations is 0
      expect(selectors.getSettlementPayments.recomputations()).toEqual(0);

      // Call the selector twice but  once
      selectors.getSettlementPayments(stateWithPayments, memoizeId);
      selectors.getSettlementPayments(stateWithPayments, memoizeId);
      expect(selectors.getSettlementPayments.recomputations()).toEqual(1);
    });

    it('should return the payments pagination', () => {
      const actual = selectors.getPaymentsPagination(stateWithSettlement, id);
      expect(actual).toEqual(stateWithSettlement.settlementDetail[id].refunds.pagination);
    });

    it('should memoized correctly when selector getPaymentsPagination is called twice ', () => {
      const memoizeId = 'mem_abc';
      // reset Recomputations to 0
      selectors.getPaymentsPagination.resetRecomputations();

      // to be sure recomputations is 0
      expect(selectors.getPaymentsPagination.recomputations()).toEqual(0);

      // Call the selector twice but is memoized so recomputations is one
      selectors.getPaymentsPagination(stateWithSettlement, memoizeId);
      selectors.getPaymentsPagination(stateWithSettlement, memoizeId);
      expect(selectors.getPaymentsPagination.recomputations()).toEqual(1);
    });

    it('should return true the payments loading state', () => {
      const actual = selectors.getPaymentsLoadingState(stateWithPayments, id);
      expect(actual).toEqual(false);
    });

    it('should memoized correctly when selector getPaymentsLoadingState is called twice ', () => {
      const memoizeId = 'mem_abc';
      // reset Recomputations to 0
      selectors.getPaymentsLoadingState.resetRecomputations();

      // to be sure recomputations is 0
      expect(selectors.getPaymentsLoadingState.recomputations()).toEqual(0);

      // Call the selector twice but is memoized so recomputations is one
      selectors.getPaymentsLoadingState(stateWithPayments, memoizeId);
      selectors.getPaymentsLoadingState(stateWithPayments, memoizeId);
      expect(selectors.getPaymentsLoadingState.recomputations()).toEqual(1);

      selectors.getPaymentsLoadingState(stateWithPayments, id);
      expect(selectors.getPaymentsLoadingState.recomputations()).toEqual(2);
    });

    it('should return true the payments loaded state', () => {
      const actual = selectors.getPaymentsLoadedState(stateWithSettlement, id);
      expect(actual).toEqual(true);
    });

    it('should memoized correctly when selector getPaymentsLoadedState is called twice ', () => {
      const memoizeId = 'mem_abca';
      // reset Recomputations to 0
      selectors.getPaymentsLoadedState.resetRecomputations();

      // to be sure recomputations is 0
      expect(selectors.getPaymentsLoadedState.recomputations()).toEqual(0);

      // Call the selector twice but is memoized so recomputations is one
      selectors.getPaymentsLoadedState(state, memoizeId);
      selectors.getPaymentsLoadedState(state, memoizeId);
      expect(selectors.getPaymentsLoadedState.recomputations()).toEqual(1);

      selectors.getPaymentsLoadedState(stateWithPayments, id);
      expect(selectors.getPaymentsLoadedState.recomputations()).toEqual(2);
    });
  });

  describe('refunds selectors', function() {
    it('should return the refunds when found in state', () => {
      const actual = selectors.getSettlementRefunds(stateWithRefunds, id);
      expect(actual).toEqual([stateWithRefunds.refunds.re_abc]);
    });

    it('should memoized correctly when selector getSettlementRefunds is called twice ', () => {
      const memoizeId = 'mem_abca';
      // reset Recomputations
      selectors.getSettlementRefunds.resetRecomputations();
      // to be sure recomputations is 0
      expect(selectors.getSettlementRefunds.recomputations()).toBe(0);

      // Call the selector twice but  once
      selectors.getSettlementRefunds(stateWithRefunds, memoizeId);

      selectors.getSettlementRefunds(stateWithRefunds, memoizeId);
      expect(selectors.getSettlementRefunds.recomputations()).toBe(1);

      selectors.getSettlementRefunds(stateWithPayments, id);
      expect(selectors.getSettlementRefunds.recomputations()).toEqual(2);
    });

    it('should return empty array when there are no refunds found in state', () => {
      const actual = selectors.getSettlementRefunds(stateWithSettlement, id);
      expect(actual).toEqual([]);
    });

    it('should return the refunds pagination', () => {
      const actual = selectors.getRefundsPagination(stateWithSettlement, id);
      expect(actual).toEqual(stateWithSettlement.settlementDetail[id].refunds.pagination);
    });

    it('should memoized correctly when selector getSettlementRefunds is called twice ', () => {
      const memoizeId = 'mem_abca';
      // reset Recomputations
      selectors.getRefundsPagination.resetRecomputations();
      // to be sure recomputations is 0
      expect(selectors.getRefundsPagination.recomputations()).toBe(0);

      // Call the selector twice but  once
      selectors.getRefundsPagination(stateWithRefunds, memoizeId);

      selectors.getRefundsPagination(stateWithRefunds, memoizeId);
      expect(selectors.getRefundsPagination.recomputations()).toBe(1);

      selectors.getRefundsPagination(stateWithRefunds, id);
      expect(selectors.getRefundsPagination.recomputations()).toBe(2);
    });
  });
  describe('chargebacks selectors', function() {
    it('should return the chargebacks when found in state', () => {
      const actual = selectors.getSettlementChargebacks(stateWithChargebacks, id);
      expect(actual).toEqual([stateWithChargebacks.chargebacks.ch_abc]);
    });
    it('should memoized correctly when selector getSettlementChargebacks is called twice ', () => {
      const memoizeId = 'mem_abca';
      // reset Recomputations
      selectors.getSettlementChargebacks.resetRecomputations();
      // to be sure recomputations is 0
      expect(selectors.getSettlementChargebacks.recomputations()).toBe(0);

      // Call the selector twice but  once
      selectors.getSettlementChargebacks(stateWithChargebacks, memoizeId);
      selectors.getSettlementChargebacks(stateWithChargebacks, memoizeId);
      expect(selectors.getSettlementChargebacks.recomputations()).toBe(1);

      selectors.getSettlementChargebacks(stateWithChargebacks, id);
      expect(selectors.getSettlementChargebacks.recomputations()).toBe(2);
    });

    it('should return empty array when there are no chargebacks found in state', () => {
      const actual = selectors.getSettlementChargebacks(stateWithSettlement, id);
      expect(actual).toEqual([]);
    });

    it('should return the chargebacks pagination', () => {
      const actual = selectors.getChargebacksPagination(stateWithSettlement, id);
      expect(actual).toEqual(stateWithSettlement.settlementDetail[id].chargebacks.pagination);
    });

    it('should memoized correctly when selector getChargebacksPagination is called twice ', () => {
      const memoizeId = 'mem_abca';
      // reset Recomputations
      selectors.getChargebacksPagination.resetRecomputations();
      // to be sure recomputations is 0
      expect(selectors.getChargebacksPagination.recomputations()).toBe(0);

      // Call the selector twice but  once
      selectors.getChargebacksPagination(stateWithChargebacks, memoizeId);
      selectors.getChargebacksPagination(stateWithChargebacks, memoizeId);
      expect(selectors.getChargebacksPagination.recomputations()).toBe(1);

      selectors.getChargebacksPagination(stateWithChargebacks, id);
      expect(selectors.getRefundsPagination.recomputations()).toBe(2);
    });
  });
});
