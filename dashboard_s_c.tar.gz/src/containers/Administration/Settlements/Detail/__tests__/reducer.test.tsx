import reducer, { paymentsReducer, refundsReducer, chargebacksReducer } from '../reducer';
import * as actions from '../actions';

Date.now = jest.fn().mockReturnValue(0);

describe('SettlementDetail:reducer', () => {
  const settlementId = 'stl_abc';
  const initialState = {};

  it('should return initial state', () => {
    expect(reducer(undefined, { type: 'FOO_ACTION' })).toEqual(initialState);
  });

  it('should respond to fetchPayments action', () => {
    const action = actions.fetchPayments({ id: settlementId });
    const actual = reducer(initialState, action);
    const expected = {
      [settlementId]: {
        isLoading: false,
        isLoaded: false,
        error: null,
        statusCode: null,
        // @ts-ignore
        refunds: refundsReducer(undefined, action),
        // @ts-ignore
        chargebacks: chargebacksReducer(undefined, action),
        payments: paymentsReducer(undefined, action),
      },
    };
    expect(actual).toEqual(expected);
  });

  it('should respond to fetchPaymentsSuccess action', () => {
    const response = {
      totalCount: 3,
      offset: 0,
      count: 3,
      updatedAt: 0,
      data: [
        {
          id: 'tr_C9mKQmsJby',
        },
      ],
    };

    const action = actions.fetchPaymentsSuccess(response, settlementId);
    const actual = reducer(initialState, action);
    const expected = {
      [settlementId]: {
        isLoading: false,
        isLoaded: false,
        error: null,
        statusCode: null,
        // @ts-ignore
        refunds: refundsReducer(undefined, action),
        // @ts-ignore
        chargebacks: chargebacksReducer(undefined, action),
        payments: paymentsReducer(undefined, action),
      },
    };

    expect(actual).toEqual(expected);
  });

  it('should respond to fetchPaymentsFailure action', () => {
    const action = actions.fetchPaymentsFailure({
      error: 'Something went severily wrong',
      id: settlementId,
      status: 500,
    });
    const actual = reducer(initialState, action);
    const expected = {
      [settlementId]: {
        isLoading: false,
        isLoaded: false,
        error: null,
        statusCode: null,
        // @ts-ignore
        refunds: refundsReducer(undefined, action),
        // @ts-ignore
        chargebacks: chargebacksReducer(undefined, action),
        payments: paymentsReducer(undefined, action),
      },
    };

    expect(actual).toEqual(expected);
  });

  it('should respond to fetchMorePayments action', () => {
    const action = actions.fetchMorePayments({ id: settlementId });
    const actual = reducer(initialState, action);
    const expected = {
      [settlementId]: {
        isLoading: false,
        isLoaded: false,
        error: null,
        statusCode: null,
        // @ts-ignore
        refunds: refundsReducer(undefined, action),
        // @ts-ignore
        chargebacks: chargebacksReducer(undefined, action),
        payments: paymentsReducer(undefined, action),
      },
    };

    expect(actual).toEqual(expected);
  });

  it('should respond to fetchMorePaymentsSuccess action', () => {
    const response = {
      totalCount: 6,
      offset: 3,
      count: 3,
      data: [
        {
          id: 'tr_C9mKQmsJby',
        },
      ],
    };

    const action = actions.fetchMorePaymentsSuccess(response, settlementId);
    const actual = reducer(initialState, action);
    const expected = {
      [settlementId]: {
        isLoading: false,
        isLoaded: false,
        error: null,
        statusCode: null,
        // @ts-ignore
        refunds: refundsReducer(undefined, action),
        // @ts-ignore
        chargebacks: chargebacksReducer(undefined, action),
        payments: paymentsReducer(undefined, action),
      },
    };

    expect(actual).toEqual(expected);
  });

  it('should respond to fetchMorePaymentsFailure action', () => {
    const action = actions.fetchMorePaymentsFailure({
      error: 'Something went severily wrong',
      id: settlementId,
      status: 500,
    });
    const actual = reducer(initialState, action);
    const expected = {
      [settlementId]: {
        isLoading: false,
        isLoaded: false,
        error: null,
        statusCode: null,
        // @ts-ignore
        refunds: refundsReducer(undefined, action),
        // @ts-ignore
        chargebacks: chargebacksReducer(undefined, action),
        payments: paymentsReducer(undefined, action),
      },
    };

    expect(actual).toEqual(expected);
  });

  it('should respond to fetchRefunds action', () => {
    const action = actions.fetchRefunds({ id: settlementId });
    const actual = reducer(initialState, action);
    const expected = {
      [settlementId]: {
        isLoading: false,
        isLoaded: false,
        error: null,
        statusCode: null,
        refunds: refundsReducer(undefined, action),
        // @ts-ignore
        chargebacks: chargebacksReducer(undefined, action),
        // @ts-ignore
        payments: paymentsReducer(undefined, action),
      },
    };

    expect(actual).toEqual(expected);
  });

  it('should respond to fetchRefundsSuccess action', () => {
    const response = {
      totalCount: 3,
      offset: 0,
      count: 3,
      data: [
        {
          id: 'tr_C9mKQmsJby',
        },
      ],
    };

    const action = actions.fetchRefundsSuccess(response, settlementId);
    const actual = reducer(initialState, action);
    const expected = {
      [settlementId]: {
        isLoading: false,
        isLoaded: false,
        error: null,
        statusCode: null,
        refunds: refundsReducer(undefined, action),
        // @ts-ignore
        chargebacks: chargebacksReducer(undefined, action),
        // @ts-ignore
        payments: paymentsReducer(undefined, action),
      },
    };

    expect(actual).toEqual(expected);
  });

  it('should respond to fetchRefundsFailure action', () => {
    const action = actions.fetchRefundsFailure({
      error: 'Something went severily wrong',
      id: settlementId,
      status: 500,
    });
    const actual = reducer(initialState, action);
    const expected = {
      [settlementId]: {
        isLoading: false,
        isLoaded: false,
        error: null,
        statusCode: null,
        refunds: refundsReducer(undefined, action),
        // @ts-ignore
        chargebacks: chargebacksReducer(undefined, action),
        // @ts-ignore
        payments: paymentsReducer(undefined, action),
      },
    };

    expect(actual).toEqual(expected);
  });

  it('should respond to fetchMoreRefunds action', () => {
    const action = actions.fetchRefunds({ id: settlementId });
    const actual = reducer(initialState, action);
    const expected = {
      [settlementId]: {
        isLoading: false,
        isLoaded: false,
        error: null,
        statusCode: null,
        refunds: refundsReducer(undefined, action),
        // @ts-ignore
        chargebacks: chargebacksReducer(undefined, action),
        // @ts-ignore
        payments: paymentsReducer(undefined, action),
      },
    };

    expect(actual).toEqual(expected);
  });

  it('should respond to fetchMoreRefundsSuccess action', () => {
    const response = {
      totalCount: 3,
      offset: 0,
      count: 3,
      data: [
        {
          id: 'tr_C9mKQmsJby',
        },
      ],
    };

    const action = actions.fetchMoreRefundsSuccess(response, settlementId);
    const actual = reducer(initialState, action);
    const expected = {
      [settlementId]: {
        isLoading: false,
        isLoaded: false,
        error: null,
        statusCode: null,
        refunds: refundsReducer(undefined, action),
        // @ts-ignore
        chargebacks: chargebacksReducer(undefined, action),
        // @ts-ignore
        payments: paymentsReducer(undefined, action),
      },
    };

    expect(actual).toEqual(expected);
  });

  it('should respond to fetchMoreRefundsFailure action', () => {
    const action = actions.fetchMoreRefundsFailure({
      error: 'Something went severily wrong',
      id: settlementId,
      status: 500,
    });
    const actual = reducer(initialState, action);
    const expected = {
      [settlementId]: {
        isLoading: false,
        isLoaded: false,
        error: null,
        statusCode: null,
        refunds: refundsReducer(undefined, action),
        // @ts-ignore
        chargebacks: chargebacksReducer(undefined, action),
        // @ts-ignore
        payments: paymentsReducer(undefined, action),
      },
    };

    expect(actual).toEqual(expected);
  });

  // chargebacks
  it('should respond to fetchChargebacks action', () => {
    const action = actions.fetchChargebacks({ id: settlementId });
    const actual = reducer(initialState, action);
    const expected = {
      [settlementId]: {
        isLoading: false,
        isLoaded: false,
        error: null,
        statusCode: null,
        // @ts-ignore
        refunds: refundsReducer(undefined, action),
        chargebacks: chargebacksReducer(undefined, action),
        // @ts-ignore
        payments: paymentsReducer(undefined, action),
      },
    };

    expect(actual).toEqual(expected);
  });

  it('should respond to fetchChargebacksSuccess action', () => {
    const response = {
      totalCount: 3,
      offset: 0,
      count: 3,
      data: [
        {
          id: 'tr_C9mKQmsJby',
        },
      ],
    };

    const action = actions.fetchChargebacksSuccess(response, settlementId);
    const actual = reducer(initialState, action);
    const expected = {
      [settlementId]: {
        isLoading: false,
        isLoaded: false,
        error: null,
        statusCode: null,
        // @ts-ignore
        refunds: refundsReducer(undefined, action),
        chargebacks: chargebacksReducer(undefined, action),
        // @ts-ignore
        payments: paymentsReducer(undefined, action),
      },
    };

    expect(actual).toEqual(expected);
  });

  it('should respond to fetchChargebacksFailure action', () => {
    const action = actions.fetchChargebacksFailure({
      error: 'Something went severily wrong',
      id: settlementId,
      status: 500,
    });
    const actual = reducer(initialState, action);
    const expected = {
      [settlementId]: {
        isLoading: false,
        isLoaded: false,
        error: null,
        statusCode: null,
        // @ts-ignore
        refunds: refundsReducer(undefined, action),
        chargebacks: chargebacksReducer(undefined, action),
        // @ts-ignore
        payments: paymentsReducer(undefined, action),
      },
    };

    expect(actual).toEqual(expected);
  });

  it('should respond to fetchMoreChargebacks action', () => {
    const action = actions.fetchMoreChargebacks({ id: settlementId });
    const actual = reducer(initialState, action);
    const expected = {
      [settlementId]: {
        isLoading: false,
        isLoaded: false,
        error: null,
        statusCode: null,
        // @ts-ignore
        refunds: refundsReducer(undefined, action),
        chargebacks: chargebacksReducer(undefined, action),
        // @ts-ignore
        payments: paymentsReducer(undefined, action),
      },
    };

    expect(actual).toEqual(expected);
  });

  it('should respond to fetchMoreChargebacksSuccess action', () => {
    const response = {
      totalCount: 3,
      offset: 0,
      count: 3,
      data: [
        {
          id: 'tr_C9mKQmsJby',
        },
      ],
    };

    const action = actions.fetchMoreChargebacksSuccess(response, settlementId);
    const actual = reducer(initialState, action);
    const expected = {
      [settlementId]: {
        isLoading: false,
        isLoaded: false,
        error: null,
        statusCode: null,
        // @ts-ignore
        refunds: refundsReducer(undefined, action),
        chargebacks: chargebacksReducer(undefined, action),
        // @ts-ignore
        payments: paymentsReducer(undefined, action),
      },
    };

    expect(actual).toEqual(expected);
  });

  it('should respond to fetchMoreChargebacksFailure action', () => {
    const action = actions.fetchMoreChargebacksFailure({
      error: 'Something went severily wrong',
      id: settlementId,
      status: 500,
    });
    const actual = reducer(initialState, action);
    const expected = {
      [settlementId]: {
        isLoading: false,
        isLoaded: false,
        error: null,
        statusCode: null,
        // @ts-ignore
        refunds: refundsReducer(undefined, action),
        chargebacks: chargebacksReducer(undefined, action),
        // @ts-ignore
        payments: paymentsReducer(undefined, action),
      },
    };

    expect(actual).toEqual(expected);
  });
});
