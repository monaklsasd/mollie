import { call, put, fork, take } from 'redux-saga/effects';

import { callApi } from 'reduxState/sagas/api';
import * as api from 'services/api';
import * as actions from '../actions';
import * as constants from '../constants';
import * as sagas from '../sagas';

describe('SettlementDetail:sagas', () => {
  const id = 'stl_abc';
  const offset = 3;

  const settlementPayments = {
    totalCount: 5,
    count: 1,
    offset,
    data: [
      {
        id: 'tr_abc',
        amount: 2.0,
      },
      {
        id: 'tr_bcd',
        amount: 3.45,
      },
    ],
  };

  const settlementRefunds = {
    totalCount: 5,
    count: 1,
    offset,
    data: [
      {
        id: 're_abc',
        amount: 2.0,
      },
      {
        id: 're_bcd',
        amount: 4.0,
      },
    ],
  };

  const settlementChargebacks = {
    totalCount: 5,
    count: 1,
    offset,
    data: [
      {
        id: 'ch_abc',
        amount: 6.0,
      },
      {
        id: 'ch_bcd',
        amount: 7.0,
      },
    ],
  };

  const status = 500;

  const apiResponse = {
    errorResponse: {
      error: {
        message: 'This is not ok',
      },
    },
    status,
  };

  it('watchFetchSettlementPayments should call fetchSettlementPayments when FETCH_SETTLEMENT_PAYMENTS is dispatched', () => {
    const generator = sagas.watchFetchSettlementPayments();

    // Start listening for FETCH_SETTLEMENT_PAYMENTS action
    expect(generator.next().value).toEqual(take(constants.FETCH_SETTLEMENT_PAYMENTS));

    // Fork subroutine fetchPaymentStatisticsRoutine
    expect(generator.next(actions.fetchPayments({ id })).value).toEqual(
      fork(sagas.fetchSettlementPaymentsRoutine, id),
    );
  });

  it('watchFetchMoreSettlementPayments should call fetchMoreSettlementPayments when FETCH_MORE_SETTLEMENT_PAYMENTS is dispatched', () => {
    const generator = sagas.watchFetchMoreSettlementPayments();

    // Start listening for FETCH_SETTLEMENT_PAYMENTS action
    expect(generator.next().value).toEqual(take(constants.FETCH_MORE_SETTLEMENT_PAYMENTS));

    // Fork subroutine fetchPaymentStatisticsRoutine
    expect(generator.next(actions.fetchMorePayments({ id, offset })).value).toEqual(
      fork(sagas.fetchMoreSettlementPaymentsRoutine, id, offset),
    );
  });

  it('watchFetchSettlementRefunds should call fetchSettlementRefunds when FETCH_SETTLEMENT_REFUNDS is dispatched', () => {
    const generator = sagas.watchFetchSettlementRefunds();

    // Start listening for FETCH_SETTLEMENT_PAYMENTS action
    expect(generator.next().value).toEqual(take(constants.FETCH_SETTLEMENT_REFUNDS));

    // Fork subroutine fetchPaymentStatisticsRoutine
    expect(generator.next(actions.fetchRefunds({ id })).value).toEqual(
      fork(sagas.fetchSettlementRefundsRoutine, id),
    );
  });

  it('watchFetchMoreSettlementRefunds should call fetchMoreSettlementRefunds when FETCH_MORE_SETTLEMENT_REFUNDS is dispatched', () => {
    const generator = sagas.watchFetchMoreSettlementRefunds();

    // Start listening for FETCH_SETTLEMENT_REFUNDS action
    expect(generator.next().value).toEqual(take(constants.FETCH_MORE_SETTLEMENT_REFUNDS));

    // Fork subroutine fetchPaymentStatisticsRoutine
    expect(generator.next(actions.fetchMoreRefunds({ id, offset })).value).toEqual(
      fork(sagas.fetchMoreSettlementRefundsRoutine, id, offset),
    );
  });

  describe('fetchSettlementPaymentsRoutine', () => {
    it('should call fetchPaymentsSuccess when success response is returned', () => {
      const generator = sagas.fetchSettlementPaymentsRoutine(id);

      expect(generator.next().value).toEqual(call(callApi, api.fetchSettlementPayments, id));

      // Response is successful
      const response = settlementPayments;

      expect(generator.next({ response }).value).toEqual(
        put(actions.fetchPaymentsSuccess(response, id)),
      );
    });

    it('should call fetchPaymentsError when error response is returned', () => {
      const generator = sagas.fetchSettlementPaymentsRoutine(id);

      expect(generator.next().value).toEqual(call(callApi, api.fetchSettlementPayments, id));

      expect(generator.next(apiResponse).value).toEqual(
        put(
          actions.fetchPaymentsFailure({
            error: apiResponse.errorResponse.error.message,
            id,
            status,
          }),
        ),
      );
    });
  });

  describe('fetchMoreSettlementPaymentsRoutine', () => {
    it('should call fetchMorePaymentsSuccess when success response is returned', () => {
      const generator = sagas.fetchMoreSettlementPaymentsRoutine(id, offset);

      expect(generator.next().value).toEqual(
        call(callApi, api.fetchSettlementPayments, id, offset),
      );

      // Response is successful
      const response = settlementPayments;

      expect(generator.next({ response }).value).toEqual(
        put(actions.fetchMorePaymentsSuccess(response, id)),
      );
    });

    it('should call fetchMorePaymentsError when error response is returned', () => {
      const generator = sagas.fetchMoreSettlementPaymentsRoutine(id, offset);

      expect(generator.next().value).toEqual(
        call(callApi, api.fetchSettlementPayments, id, offset),
      );

      expect(generator.next(apiResponse).value).toEqual(
        put(
          actions.fetchMorePaymentsFailure({
            error: apiResponse.errorResponse.error.message,
            id,
            status,
          }),
        ),
      );
    });
  });

  describe('fetchSettlementRefundsRoutine', () => {
    it('should call fetchRefundsSuccess when success response is returned', () => {
      const generator = sagas.fetchSettlementRefundsRoutine(id);

      expect(generator.next().value).toEqual(call(callApi, api.fetchSettlementRefunds, id));

      // Response is successful
      const response = settlementRefunds;

      expect(generator.next({ response }).value).toEqual(
        put(actions.fetchRefundsSuccess(response, id)),
      );
    });

    it('should call fetchRefundsError when error response is returned', () => {
      const generator = sagas.fetchSettlementRefundsRoutine(id);

      expect(generator.next().value).toEqual(call(callApi, api.fetchSettlementRefunds, id));

      expect(generator.next(apiResponse).value).toEqual(
        put(
          actions.fetchRefundsFailure({
            error: apiResponse.errorResponse.error.message,
            id,
            status,
          }),
        ),
      );
    });
  });

  describe('fetchMoreSettlementRefundsRoutine', () => {
    it('should call fetchMoreRefundsSuccess when success response is returned', () => {
      const generator = sagas.fetchMoreSettlementRefundsRoutine(id, offset);

      expect(generator.next().value).toEqual(call(callApi, api.fetchSettlementRefunds, id, offset));

      // Response is successful
      const response = settlementRefunds;

      expect(generator.next({ response }).value).toEqual(
        put(actions.fetchMoreRefundsSuccess(response, id)),
      );
    });

    it('should call fetchMoreRefundsError when error response is returned', () => {
      const generator = sagas.fetchMoreSettlementRefundsRoutine(id, offset);

      expect(generator.next().value).toEqual(call(callApi, api.fetchSettlementRefunds, id, offset));

      expect(generator.next(apiResponse).value).toEqual(
        put(
          actions.fetchMoreRefundsFailure({
            error: apiResponse.errorResponse.error.message,
            id,
            status,
          }),
        ),
      );
    });
  });

  describe('fetchSettlementChargebacksRoutine', () => {
    it('should call fetchChargebacksSuccess when success response is returned', () => {
      const generator = sagas.fetchSettlementChargebacksRoutine(id);

      expect(generator.next().value).toEqual(call(callApi, api.fetchSettlementChargebacks, id));

      // Response is successful
      const response = settlementRefunds;

      expect(generator.next({ response }).value).toEqual(
        put(actions.fetchChargebacksSuccess(response, id)),
      );
    });

    it('should call fetchSettlementChargebacksError when error response is returned', () => {
      const generator = sagas.fetchSettlementChargebacksRoutine(id);

      expect(generator.next().value).toEqual(call(callApi, api.fetchSettlementChargebacks, id));

      expect(generator.next(apiResponse).value).toEqual(
        put(
          actions.fetchChargebacksFailure({
            error: apiResponse.errorResponse.error.message,
            id,
            status,
          }),
        ),
      );
    });
  });

  describe('fetchMoreSettlementChargebacksRoutine', () => {
    it('should call fetchMoreSettlementChargebacksSuccess when success response is returned', () => {
      const generator = sagas.fetchMoreSettlementChargebacksRoutine(id, offset);

      expect(generator.next().value).toEqual(
        call(callApi, api.fetchSettlementChargebacks, id, offset),
      );

      // Response is successful
      const response = settlementChargebacks;

      expect(generator.next({ response }).value).toEqual(
        put(actions.fetchMoreChargebacksSuccess(response, id)),
      );
    });

    it('should call fetchMoreChargebacksFailure when error response is returned', () => {
      const generator = sagas.fetchMoreSettlementChargebacksRoutine(id, offset);

      expect(generator.next().value).toEqual(
        call(callApi, api.fetchSettlementChargebacks, id, offset),
      );

      expect(generator.next(apiResponse).value).toEqual(
        put(
          actions.fetchMoreChargebacksFailure({
            error: apiResponse.errorResponse.error.message,
            id,
            status,
          }),
        ),
      );
    });
  });
});
