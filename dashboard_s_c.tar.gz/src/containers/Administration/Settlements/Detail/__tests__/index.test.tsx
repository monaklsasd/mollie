import { expectSaga } from 'redux-saga-test-plan';

import * as sagas from '../sagas';
import * as actions from '../actions';
import reducer from '../reducer';

// Mock Date.now() function so it always returns 01-01-2017 00:00:00
Date.now = jest.fn().mockReturnValue(1483228800000);

describe('Administration/SettlementDetail', () => {
  const id = 'stl_abc123';
  const subresourceState = {
    ids: [],
    isLoading: false,
    isLoaded: false,
    error: null,
    statusCode: null,
    updatedAt: null,
    pagination: {},
  };

  it('should successfully fetch settlement', () => {
    const response = {
      data: [
        {
          resource: 'settlement',
          id,
          createdDatetime: '2017-01-10T14:06:21.0Z',
          settledDatetime: '2017-01-11T14:06:21.0Z',
          reference: '0002.1701.01',
          status: 'paidout',
        },
      ],
    };

    return expectSaga(sagas.watchFetchSettlement)
      .withReducer(reducer)
      .provide({
        call(_effect, _next) {
          return { response };
        },
      })
      .put(actions.fetchSettlementSuccess(response, id))
      .dispatch(
        actions.fetchSettlement({
          id,
        }),
      )
      .hasFinalState({
        [id]: {
          isLoading: false,
          isLoaded: true,
          error: null,
          statusCode: null,
          payments: subresourceState,
          refunds: subresourceState,
          chargebacks: subresourceState,
        },
      })
      .run({ silenceTimeout: true });
  });

  it('state contains an error when fetching of settlements', () => {
    const errorResponse = {
      error: {
        message: 'Oh no, you failed!',
      },
    };

    const status = 500;

    return expectSaga(sagas.watchFetchSettlement)
      .withReducer(reducer)
      .provide({
        call(_effect, _next) {
          return { errorResponse, status };
        },
      })
      .put(actions.fetchSettlementFailure({ error: errorResponse.error.message, id, status }))
      .dispatch(
        actions.fetchSettlement({
          id,
        }),
      )
      .hasFinalState({
        [id]: {
          isLoaded: false,
          isLoading: false,
          error: errorResponse.error.message,
          statusCode: status,
          payments: subresourceState,
          refunds: subresourceState,
          chargebacks: subresourceState,
        },
      })
      .run({ silenceTimeout: true });
  });
});
