import React from 'react';
import { Route, Switch } from 'react-router-dom';
import loadable from 'react-loadable';
import { hot } from 'react-hot-loader';

// Components
import LoadingState from 'components/UI/LoadingState';
import NotFound from 'containers/NotFound';

// Types
import { match } from 'react-router-dom';

// Internals
import Detail from './Detail';

const Delete = loadable({
  loader: () => import('./Delete' /* webpackChunkName: 'AccountDelete' */),
  loading: () => <LoadingState fullHeight noBorder isLoading />,
});

type Props = {
  match: match;
};

const account: React.FC<Props> = ({ match }) => (
  <Switch>
    <Route exact path={`${match.path}`} component={Detail} />
    <Route exact path={`${match.path}/delete`} component={Delete} />
    <Route component={NotFound} />
  </Switch>
);

export default hot(module)(account);
