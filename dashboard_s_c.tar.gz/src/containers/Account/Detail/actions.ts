import * as constants from './constants';
import * as types from './types';
import { UserState } from 'reduxState/modules/user/types';
import { ActionType } from 'reduxState/types';

export const updateUser = (
  payload: types.UpdateUserPayload,
): ActionType<typeof constants.UPDATE_USER, types.UpdateUserPayload> => ({
  type: constants.UPDATE_USER,
  payload,
});

export const updateUserSuccess = (
  payload: UserState,
): ActionType<typeof constants.UPDATE_USER_SUCCESS, UserState> => ({
  type: constants.UPDATE_USER_SUCCESS,
  payload,
});
