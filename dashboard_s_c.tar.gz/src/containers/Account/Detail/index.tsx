import React from 'react';
import { withFormik, FormikErrors } from 'formik';
import { connect } from 'react-redux';
import { injectIntl, FormattedMessage } from 'react-intl';

// Containers
import FormikForm from 'containers/forms/FormikForm';
import PageWrapper from 'containers/PageWrapper';

// Components
import Fieldset from 'components/forms/Fieldset';
import FormikGroup from 'components/forms/FormikGroup';
import Phone from 'components/forms/Phone';
import SelectLocale from 'components/forms/SelectLocale';
import Wrapper from 'components/UI/Wrapper';
import Link from 'components/UI/Link';
import Button from 'components/UI/Button';
import ButtonGroup from 'components/UI/ButtonGroup';

// Redux
import { updateUser } from './actions';
import { getCurrentUser } from 'reduxState/modules/user/selectors';

// Utils
import isEmail from 'utils/isEmail';
import isValidPhoneNumber from 'utils/isPhoneNumber';
import getValidPhoneNumber from 'utils/getValidPhoneNumber';
import Helmet from 'react-helmet';

// Messages
import formMessages from 'messages/forms';
import messages from './messages';

// Types
import { FormikProps } from 'formik';
import { match } from 'react-router-dom';
import { IntlShape } from 'react-intl';
import { OrganizationState } from 'reduxState/modules/organization/types';
import { UserState } from 'reduxState/modules/user/types';
import { State } from 'reduxState/types';

type Props = {
  match: match;
  user: UserState;
  intl: IntlShape;
  organization: OrganizationState;
} & FormikProps<any>;

class AccountDetail extends React.Component<Props> {
  shouldComponentUpdate(nextProps): boolean {
    return nextProps.isSubmitting !== this.props.isSubmitting;
  }

  render(): React.ReactElement {
    const { intl, user, isSubmitting } = this.props;

    return (
      <PageWrapper title={`${user.firstName} ${user.lastName || ''}`}>
        <Helmet title={intl.formatMessage(messages.settingsHeading)} />
        <Wrapper narrow isLast>
          <FormikForm>
            <Fieldset heading={<FormattedMessage {...messages.settingsHeading} />} splitColumns>
              <FormikGroup
                label={<FormattedMessage {...messages.firstNameLabel} />}
                name="firstName">
                {(field): React.ReactElement => (
                  <input
                    className="l-form-control l-form-control--on-grey-bg"
                    type="text"
                    {...field}
                  />
                )}
              </FormikGroup>

              <FormikGroup label={<FormattedMessage {...messages.lastNameLabel} />} name="lastName">
                {(field): React.ReactElement => (
                  <input
                    className="l-form-control l-form-control--on-grey-bg"
                    type="text"
                    {...field}
                  />
                )}
              </FormikGroup>

              <FormikGroup label={<FormattedMessage {...messages.phoneLabel} />} name="phone">
                {(field): React.ReactElement => <Phone onGrey {...field} />}
              </FormikGroup>

              <FormikGroup label={<FormattedMessage {...messages.localeLabel} />} name="locale">
                {(field): React.ReactElement => (
                  <SelectLocale
                    onGrey
                    inFormikForm
                    {...field}
                    onChange={(e): void => field.onChange(e as any)}
                  />
                )}
              </FormikGroup>
            </Fieldset>

            <Fieldset
              heading={<FormattedMessage {...messages.loginHeading} />}
              description={<FormattedMessage {...messages.loginDescription} />}
              splitColumns>
              <FormikGroup label={<FormattedMessage {...messages.loginLabel} />} name="email">
                {(field): React.ReactElement => (
                  <input
                    className="l-form-control l-form-control--on-grey-bg"
                    type="email"
                    {...field}
                  />
                )}
              </FormikGroup>
              <FormikGroup
                label={<FormattedMessage {...messages.passwordLabel} />}
                name="password"
                help={<FormattedMessage {...messages.passwordHint} />}>
                {(field): React.ReactElement => (
                  <input
                    autoComplete="new-password"
                    className="l-form-control l-form-control--on-grey-bg"
                    type="password"
                    {...field}
                  />
                )}
              </FormikGroup>
              <FormikGroup
                label={<FormattedMessage {...messages.currentPassword} />}
                name="passwordOld">
                {(field): React.ReactElement => (
                  <input
                    autoComplete="current-password"
                    className="l-form-control l-form-control--on-grey-bg"
                    type="password"
                    {...field}
                  />
                )}
              </FormikGroup>
            </Fieldset>
            <ButtonGroup>
              <Button primary size="large" isLoading={isSubmitting}>
                <FormattedMessage {...formMessages.formBtnSave} />
              </Button>
              <Link linkStyle="danger" to="/account/delete">
                <FormattedMessage {...messages.accountDelete} />
              </Link>
            </ButtonGroup>
          </FormikForm>
        </Wrapper>
      </PageWrapper>
    );
  }
}

const mapStateToProps = (
  state: State,
): { user: Props['user']; organization: Props['organization'] } => ({
  user: getCurrentUser(state),
  organization: state.organization,
});

const mapDispatchToProps = {
  updateUser,
};

export const validate = (values): FormikErrors<any> => {
  const errors: FormikErrors<any> = {};

  if (!values.firstName) {
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    errors.firstName = formMessages.required;
  }

  if (!values.lastName) {
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    errors.lastName = formMessages.required;
  }

  if (!values.phone) {
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    errors.phone = formMessages.required;
  } else if (!isValidPhoneNumber(values.phone)) {
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    errors.phone = formMessages.invalidPhoneNumber;
  }

  if (!values.locale) {
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    errors.locale = formMessages.required;
  }

  if (!values.email) {
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    errors.email = formMessages.required;
  } else if (!isEmail(values.email)) {
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    errors.email = formMessages.invalidEmailAddress;
  }

  if (values.password && !values.passwordOld) {
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    errors.passwordOld = formMessages.required;
  } else if (values.password && values.password === values.passwordOld) {
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    errors.passwordOld = formMessages.shouldNotBeSameAsCurrentPassword;
  }

  return errors;
};

const mapPropsToValues = ({ user, organization }): Record<string, any> => {
  const countryCode = organization ? organization.countryCode : null;
  const validPhoneNumber = getValidPhoneNumber(user.phone, countryCode);

  return {
    firstName: user.firstName || '',
    lastName: user.lastName || '',
    phone: validPhoneNumber || '',
    locale: user.locale,
    email: user.email || '',
    password: '',
    passwordOld: '',
  };
};

const handleSubmit = (values, formikBag): void => {
  formikBag.props.updateUser({
    userId: formikBag.props.user.id,
    formikContainer: { values, formikBag },
  });
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(
  withFormik<Props, any>({
    mapPropsToValues,
    handleSubmit,
    validate,
  })(injectIntl(AccountDetail)),
);
