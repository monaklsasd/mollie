import { takeLatest, put, call, delay } from 'redux-saga/effects';

// Api
import { updateUser } from 'services/api';

// Redux
import { fetchIntlMessages } from 'reduxState/modules/intl/actions';
import toast from 'helpers/toast';
import { UPDATE_USER } from './constants';
import { updateUserSuccess } from './actions';
import { callApi } from 'reduxState/sagas/api';

// Messages
import messages from './messages';

// Types
import { UpdateUserAction } from './types';

/* **************************************************************************** */
/* ****************************** SUBROUTINES ********************************* */
/* **************************************************************************** */

export function* updateUserRoutine({
  payload: { userId, formikContainer },
}: UpdateUserAction): Generator<any, any, any> {
  const { values, formikBag } = formikContainer;
  const { response, errorResponse } = yield call(callApi, updateUser, userId, values);

  if (response) {
    yield put(updateUserSuccess(response));

    if (values.locale) {
      yield put(fetchIntlMessages(values.locale));
      // Add delay so it will give the app/Toast container time to unmount and mount and accepts new toasts
      yield delay(250);
    }

    yield call(toast.success, messages.flashUserUpdatedSuccess);

    yield call(formikBag.setStatus, { error: undefined });
  } else if (errorResponse && errorResponse.errors) {
    // One Of the fields has an error
    yield call(formikBag.setErrors, errorResponse.errors);
  } else if (errorResponse && errorResponse.error) {
    // Global message (back-end won't return error and errors)
    yield call(formikBag.setStatus, { error: errorResponse.error.message });
  }

  // Always set submitting to false at the end of this loop to allow resubmitting this form.
  yield call(formikBag.setSubmitting, false);
}

/* **************************************************************************** */
/* ****************************** WATCHERS ************************************ */
/* **************************************************************************** */

export function* watchUpdateUser(): Generator<any, any, any> {
  yield takeLatest(UPDATE_USER, updateUserRoutine);
}
