import { ActionType } from 'reduxState/types';

export type UpdateUserPayload = {
  userId: string;
  formikContainer: {
    values: {
      [key: string]: string;
    };
    formikBag: Record<string, any>;
  };
};

export type UpdateUserAction = ActionType<'AccountDetail/UPDATE_USER', UpdateUserPayload>;
