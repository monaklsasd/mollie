export const UPDATE_USER = 'AccountDetail/UPDATE_USER';
export const UPDATE_USER_SUCCESS = 'AccountDetail/UPDATE_USER_SUCCESS';
