/* eslint-disable @typescript-eslint/camelcase */
import { expectSaga } from 'redux-saga-test-plan';
import * as matchers from 'redux-saga-test-plan/matchers';
import delayP from '@redux-saga/delay-p';

import toast from 'helpers/toast';
import { callApi } from 'reduxState/sagas/api';
import * as actions from '../actions';
import * as sagas from '../sagas';
import { fetchIntlMessages } from 'reduxState/modules/intl/actions';
import messages from '../messages';
import reducer from 'reduxState/modules/user/reducer';

describe('Account/Detail::sagas', () => {
  const userId = '2095863';

  const values = {
    firstName: 'Johannes',
    lastName: 'Sanders',
    phone: '06-29162884',
    locale: 'fr-FR',
  };

  it('watchUpdateUser should call updateUser when UPDATE_USER is dispatched', async () => {
    const formikContainer = {
      values,
      formikBag: {
        setErrors: jest.fn(),
        setStatus: jest.fn(),
        setSubmitting: jest.fn(),
      },
    };

    const response = {
      resource: 'user',
      id: '2',
      firstName: 'klant',
      lastName: 'Test',
      email: 'dev@mollie.com',
      phone: '31222222222',
      avatar: 'https://secure.gravatar.com/avatar/bb9ed9f4e6c777a9093de4141c9a8209?s=200&d=404',
      role: 'Beheerder',
      authorizedToSign: true,
      memberSince: '2017-01-11 16:06:18',
      auth: true,
      locale: 'en_US',
      organizations: {
        org_2: {
          resource: 'organization',
          id: 'org_2',
          name: 'Klant B.V.',
          email: 'dev@mollie.com',
          address: 'Keizersgracht 313',
          postalCode: '1234BA',
          city: 'Amsterdam',
          country: 'Netherlands',
          countryCode: 'NL',
          registrationType: 'bv',
          registrationNumber: '12345679',
          registrationDatetime: '2017-01-10T23:00:00.0Z',
          verifiedDatetime: '2018-02-12T15:30:18.0Z',
          avatar: '/api-internal/logos/org_2',
        },
      },
      login: 'klant',
    };

    await expectSaga(sagas.watchUpdateUser)
      // @ts-ignore
      .withReducer(reducer)
      .provide({
        call(effect, next) {
          if (effect.fn === callApi) {
            return { response };
          }

          if (effect.fn === delayP) {
            return 0;
          }

          return next();
        },
      })
      // @ts-ignore
      .put(actions.updateUserSuccess(response))
      .put(fetchIntlMessages(formikContainer.values.locale))
      .call(toast.success, messages.flashUserUpdatedSuccess)
      .dispatch(actions.updateUser({ userId, formikContainer }))
      .hasFinalState(response)
      .silentRun();

    expect(formikContainer.formikBag.setSubmitting).toHaveBeenCalledTimes(1);
    expect(formikContainer.formikBag.setSubmitting).toHaveBeenCalledWith(false);
  });

  it('watchUpdateUser should add an error status when response has an error', async () => {
    const formikContainer = {
      values,
      formikBag: {
        setErrors: jest.fn(),
        setStatus: jest.fn(),
        setSubmitting: jest.fn(),
      },
    };

    const errorResponse = {
      error: {
        message: 'error',
      },
    };

    await expectSaga(sagas.watchUpdateUser)
      .provide([[matchers.call.fn(callApi), { errorResponse }]])
      .dispatch(actions.updateUser({ userId, formikContainer }))
      .run({ silenceTimeout: true });

    expect(formikContainer.formikBag.setStatus).toHaveBeenCalledTimes(1);
    expect(formikContainer.formikBag.setStatus).toHaveBeenCalledWith({
      error: errorResponse.error.message,
    });
  });

  it('watchUpdateUser should add errors when response has an errors per field', async () => {
    const formikContainer = {
      values,
      formikBag: {
        setErrors: jest.fn(),
        setStatus: jest.fn(),
        setSubmitting: jest.fn(),
      },
    };

    const errorResponse = {
      errors: {
        errorField: 'error',
      },
    };

    await expectSaga(sagas.watchUpdateUser)
      .provide([[matchers.call.fn(callApi), { errorResponse }]])
      .dispatch(actions.updateUser({ userId, formikContainer }))
      .run({ silenceTimeout: true });

    expect(formikContainer.formikBag.setErrors).toHaveBeenCalledTimes(1);
    expect(formikContainer.formikBag.setErrors).toHaveBeenCalledWith(errorResponse.errors);
  });
});
