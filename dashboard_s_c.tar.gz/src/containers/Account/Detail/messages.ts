import { defineMessages } from 'react-intl';
import { IntlMessages } from 'types/intl';

const messages: IntlMessages = defineMessages({
  settingsHeading: {
    id: 'account-settings-heading',
    defaultMessage: 'Account',
  },
  loginHeading: {
    id: 'account-login-heading',
    defaultMessage: 'Login credentials',
  },
  loginDescription: {
    id: 'account-login-heading-description',
    defaultMessage: 'If you change your login credentials we will notify your old email address.',
  },
  firstNameLabel: {
    id: 'account-settings-form-first-name-label',
    defaultMessage: 'First name',
  },
  lastNameLabel: {
    id: 'account-settings-form-last-name-label',
    defaultMessage: 'Last name',
  },
  phoneLabel: {
    id: 'account-settings-form-phone-label',
    defaultMessage: 'Phone number',
  },
  localeLabel: {
    id: 'account-settings-form-locale-label',
    defaultMessage: 'Language',
  },
  loginLabel: {
    id: 'account-settings-form-login-email-label',
    defaultMessage: 'Email',
  },
  currentPasswordLabel: {
    id: 'account-settings-form-new-password-label',
    defaultMessage: 'New password',
  },
  passwordLabel: {
    id: 'account-settings-form-new-password-label',
    defaultMessage: 'New password',
  },
  passwordHint: {
    id: 'account-settings-form-new-password-hint',
    defaultMessage: 'Min. 10 characters, no common passwords like ‘123456’',
  },
  passwordPlaceholder: {
    id: 'account-settings-form-new-password-placeholder',
    defaultMessage: 'Enter a new password',
  },
  currentPassword: {
    id: 'account-settings-current-password-label',
    defaultMessage: 'Current password',
  },
  accountDelete: {
    id: 'account-settings-terminate-button',
    defaultMessage: 'Terminate account',
  },
  flashUserUpdatedSuccess: {
    id: 'account-settings-update-success',
    defaultMessage: 'Your account settings have been updated!',
  },
});

export default messages;
