import { ActionType } from 'reduxState/types';

export type DeleteUserPayload = {
  userId: string;
  formikContainer: {
    values: {
      [key: string]: string;
    };
    formikBag: Record<string, any>;
  };
  redirectPath: string;
};

export type DeleteUserAction = ActionType<'AccountDelete/DELETE_USER', DeleteUserPayload>;

export type DeleteUserSuccessPayload = {
  userId: string;
};

export type DeleteUserSuccessAction = ActionType<
  'AccountDelete/DELETE_USER_SUCCESS',
  DeleteUserSuccessPayload
>;
