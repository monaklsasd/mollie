import { defineMessages } from 'react-intl';
import { IntlMessages } from 'types/intl';

const messages: IntlMessages = defineMessages({
  description: {
    id: 'account-settings-delete-account-warning-description',
    defaultMessage:
      'If you don’t want to use the services of Mollie anymore, you can terminate your account. Note that this cannot be undone.',
  },
  descriptionLabel: {
    id: 'account-settings-delete-description-label',
    defaultMessage: 'Reason',
  },
  currentPassword: {
    id: 'account-settings-delete-current-password-label',
    defaultMessage: 'Current password',
  },
  currentPasswordPlaceholder: {
    id: 'account-settings-delete-current-password-placeholder',
    defaultMessage: 'Enter your current password',
  },
  accountDelete: {
    id: 'account-settings-delete-header',
    defaultMessage: 'Terminate account',
  },
  flashMessageWarning: {
    id: 'account-settings-delete-flash-message-warning',
    defaultMessage:
      'You won’t be able to log in again afterwards. Export all required data and invoices before you terminate your account.',
  },
  flashUserDeleteSuccess: {
    id: 'account-settings-delete-success',
    defaultMessage: 'Your request to terminate the account will be processed.',
    description:
      'The account will not actually be deleted as of yet, see also the message with key `account-settings-delete-description`',
  },
});

export default messages;
