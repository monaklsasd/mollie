export const DELETE_USER = 'AccountDelete/DELETE_USER';
export const DELETE_USER_SUCCESS = 'AccountDelete/DELETE_USER_SUCCESS';
