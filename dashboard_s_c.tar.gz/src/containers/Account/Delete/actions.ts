import * as constants from './constants';
import * as types from './types';

export const deleteUser = (payload: types.DeleteUserPayload): types.DeleteUserAction => ({
  type: constants.DELETE_USER,
  payload,
});

export const deleteUserSuccess = (
  payload: types.DeleteUserSuccessPayload,
): types.DeleteUserSuccessAction => ({
  type: constants.DELETE_USER_SUCCESS,
  payload,
});
