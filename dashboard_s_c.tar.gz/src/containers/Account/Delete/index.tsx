import React from 'react';

import { FormattedMessage, injectIntl } from 'react-intl';
import { hot } from 'react-hot-loader';
import { withFormik, FormikErrors } from 'formik';
import { connect } from 'react-redux';
import Helmet from 'react-helmet';

// Containers
import FormikForm from 'containers/forms/FormikForm';

// Redux
import { deleteUser } from './actions';
import { getCurrentUser } from 'reduxState/modules/user/selectors';

// Components
import FormikGroup from 'components/forms/FormikGroup';
import Fieldset from 'components/forms/Fieldset';
import Button from 'components/UI/Button';
import ButtonGroup from 'components/UI/ButtonGroup';
import FlashMessage from 'components/UI/FlashMessage';
import PageWrapper from 'containers/PageWrapper';
import Wrapper from 'components/UI/Wrapper';

// Messages
import formMessages from 'messages/forms';
import messages from './messages';

// Types
import { FormikProps } from 'formik';
import { History } from 'history';
import { IntlShape } from 'react-intl';
import { UserState } from 'reduxState/modules/user/types';
import { State } from 'reduxState/types';

type Values = {
  description: string;
  password: string;
};

type Props = {
  history: History;
  user: UserState;
  intl: IntlShape;
  deleteUser: typeof deleteUser;
} & FormikProps<Values>;

const AccountDelete: React.FC<Props> = ({ isSubmitting, user, intl, history }) => {
  const onCancel = (event: React.MouseEvent<any>): void => {
    event.preventDefault();
    history.push('/account');
  };

  return (
    <PageWrapper title={`${user.firstName} ${user.lastName || ''}`}>
      <Wrapper narrow isLast>
        <Helmet title={intl.formatMessage(messages.accountDelete)} />
        <FormikForm>
          <Fieldset
            heading={<FormattedMessage {...messages.accountDelete} />}
            description={<FormattedMessage {...messages.description} />}>
            <FormikGroup
              label={<FormattedMessage {...messages.descriptionLabel} />}
              name="description">
              {(field): React.ReactElement => (
                <textarea
                  className="l-form-control l-form-control--on-grey-bg"
                  rows={3}
                  {...field}
                />
              )}
            </FormikGroup>
            <FormikGroup label={<FormattedMessage {...messages.currentPassword} />} name="password">
              {(field): React.ReactElement => (
                <input
                  autoComplete="current-password"
                  className="l-form-control l-form-control--on-grey-bg"
                  type="password"
                  placeholder={intl.formatMessage(messages.currentPasswordPlaceholder)}
                  {...field}
                />
              )}
            </FormikGroup>
            <FlashMessage state="warning" textAlign="left">
              <FormattedMessage {...messages.flashMessageWarning} />
            </FlashMessage>
          </Fieldset>
          <ButtonGroup>
            <Button primary size="large" isLoading={isSubmitting}>
              <FormattedMessage {...formMessages.formBtnTerminate} />
            </Button>
            <Button type="button" onClick={onCancel} size="large" disabled={isSubmitting}>
              <FormattedMessage {...formMessages.formBtnGoBack} />
            </Button>
          </ButtonGroup>
        </FormikForm>
      </Wrapper>
    </PageWrapper>
  );
};

const mapStateToProps = (state: State): { user: UserState } => ({
  user: getCurrentUser(state),
});

const mapDispatchToProps = {
  deleteUser,
};

const validate = (values): FormikErrors<Values> => {
  const errors: FormikErrors<Values> = {};

  if (!values.password) {
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    errors.password = formMessages.required;
  }

  if (!values.description) {
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    errors.description = formMessages.required;
  }

  return errors;
};

const handleSubmit = (values, formikBag): void => {
  formikBag.props.deleteUser({
    userId: formikBag.props.user.id,
    formikContainer: { values, formikBag },
    redirectPath: '/account',
  });
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(
  withFormik<Props, Values>({
    mapPropsToValues: () => ({ description: '', password: '' }),
    handleSubmit,
    validate,
  })(injectIntl(hot(module)(AccountDelete))),
);
