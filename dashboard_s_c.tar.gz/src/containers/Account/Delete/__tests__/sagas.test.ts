import { expectSaga } from 'redux-saga-test-plan';
import * as matchers from 'redux-saga-test-plan/matchers';

import toast from 'helpers/toast';
import { callApi } from 'reduxState/sagas/api';
import * as actions from '../actions';
import messages from '../messages';
import * as sagas from '../sagas';

describe('Account/Delete::sagas', () => {
  const userId = '2095863';

  it('watchDeleteUser should call deleteUserRoutine when DELETE_USER is dispatched', async () => {
    const formikContainer = {
      formikBag: {
        setErrors: jest.fn(),
        setStatus: jest.fn(),
        setSubmitting: jest.fn(),
      },
    };

    await expectSaga(sagas.watchDeleteUser)
      .provide({
        call(effect, next) {
          if (effect.fn === callApi) {
            return { response: { userId } };
          }

          return next();
        },
      })
      .put(actions.deleteUserSuccess({ userId }))
      .call(toast.success, messages.flashUserDeleteSuccess)
      // @ts-ignore
      .dispatch(actions.deleteUser({ userId, formikContainer }))
      .run({ silenceTimeout: true });

    expect(formikContainer.formikBag.setSubmitting).toHaveBeenCalledTimes(1);
    expect(formikContainer.formikBag.setSubmitting).toHaveBeenCalledWith(false);
  });

  it('watchDeleteUser should add an error status when response has an error', async () => {
    const formikContainer = {
      formikBag: {
        setErrors: jest.fn(),
        setStatus: jest.fn(),
        setSubmitting: jest.fn(),
      },
    };

    const errorResponse = {
      error: {
        message: 'error',
      },
    };

    await expectSaga(sagas.watchDeleteUser)
      .provide([[matchers.call.fn(callApi), { errorResponse }]])
      // @ts-ignore
      .dispatch(actions.deleteUser({ userId, formikContainer }))
      .run({ silenceTimeout: true });

    expect(formikContainer.formikBag.setStatus).toHaveBeenCalledTimes(1);
    expect(formikContainer.formikBag.setStatus).toHaveBeenCalledWith({
      error: errorResponse.error.message,
    });
  });

  it('watchDeleteUser should add errors when response has an errors per field', async () => {
    const formikContainer = {
      formikBag: {
        setErrors: jest.fn(),
        setStatus: jest.fn(),
        setSubmitting: jest.fn(),
      },
    };

    const errorResponse = {
      errors: {
        errorField: 'error',
      },
    };

    await expectSaga(sagas.watchDeleteUser)
      .provide([[matchers.call.fn(callApi), { errorResponse }]])
      // @ts-ignore
      .dispatch(actions.deleteUser({ userId, formikContainer }))
      .run({ silenceTimeout: true });

    expect(formikContainer.formikBag.setErrors).toHaveBeenCalledTimes(1);
    expect(formikContainer.formikBag.setErrors).toHaveBeenCalledWith(errorResponse.errors);
  });
});
