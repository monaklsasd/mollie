import { takeLatest, put, call } from 'redux-saga/effects';
import { replace } from 'connected-react-router';

// Api
import { deleteUser } from 'services/api';

// Redux
import { callApi } from 'reduxState/sagas/api';
import toast from 'helpers/toast';
import { deleteUserSuccess } from './actions';
import { DELETE_USER } from './constants';
import messages from './messages';

// Types
import { DeleteUserAction } from './types';

export function* deleteUserRoutine({
  payload: { userId, formikContainer, redirectPath },
}: DeleteUserAction): Generator<any, any, any> {
  const { values, formikBag } = formikContainer;

  const { response, errorResponse } = yield call(callApi, deleteUser, userId, values);

  if (response) {
    yield put(deleteUserSuccess({ userId }));

    yield call(toast.success, messages.flashUserDeleteSuccess);

    yield call(formikBag.setStatus, { error: undefined });

    if (redirectPath) {
      yield call(formikBag.setSubmitting, false);
      yield put(
        replace({
          pathname: redirectPath,
        }),
      );
    }
  } else if (errorResponse && errorResponse.errors) {
    // One Of the fields has an error
    yield call(formikBag.setErrors, errorResponse.errors);
  } else if (errorResponse && errorResponse.error) {
    // Global message (back-end won't return error and errors)
    yield call(formikBag.setStatus, { error: errorResponse.error.message });
  }

  // Always set submitting to false at the end of this loop to allow resubmitting this form.
  yield call(formikBag.setSubmitting, false);
}

/* **************************************************************************** */
/* ****************************** WATCHERS ************************************ */
/* **************************************************************************** */

export function* watchDeleteUser(): Generator<any, any, any> {
  yield takeLatest(DELETE_USER, deleteUserRoutine);
}
