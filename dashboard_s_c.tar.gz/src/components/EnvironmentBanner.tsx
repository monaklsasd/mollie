import React from 'react';

import developmentBanner from 'assets/images/environment-banners/development.gif';

type Props = {
  environment?: 'production' | 'development';
};

type State = {
  visible: boolean;
};

const EnvironmentBanner: React.FC<Props> = ({ environment = 'production' }) => {
  const [visible, setVisible] = React.useState<boolean>(environment !== 'production');

  if (!visible) {
    return null;
  }

  const style: React.CSSProperties = {
    position: 'fixed',
    top: 0,
    right: 0,
    width: 100,
    height: 100,
    zIndex: 1337,
    opacity: 0.33,
    transform: 'rotate(90deg)',
  };

  return (
    <div role="button" style={style} onMouseEnter={(): void => setVisible(false)}>
      <img
        alt={`File name: ${developmentBanner}`}
        src={developmentBanner}
        style={{ padding: 0, margin: 0, border: 0 }}
      />
    </div>
  );
};

export default EnvironmentBanner;
