export const FILTERS = {
  DATE: 'date',
  METHOD: 'method',
  SEARCH: 'search',
  STATUS: 'status',
  REFUND_STATUS: 'refundStatus',
  CURRENCY: 'currency',
};
