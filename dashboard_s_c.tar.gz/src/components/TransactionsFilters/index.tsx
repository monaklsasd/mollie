import React from 'react';
import { FormattedMessage, FormattedHTMLMessage, useIntl } from 'react-intl';
import classNames from 'classnames';

// Components
import DatePresets, { PresetType } from 'components/UI/DatePresets';
import HelpTooltip from 'components/UI/HelpTooltip';
import NavigationList from 'components/UI/NavigationList';
import Heading from 'components/UI/Heading';
import CurrencyMessage from 'components/UI/CurrencyMessage';
import { InputSearch } from 'components/forms';
import SidebarFilters from 'components/SidebarFilters';

// Messages
import { messages as statusMessages } from 'helpers/paymentStatus';
import { messages as refundStatusMessages } from 'components/Payment/PaymentRefundStatus';
import METHODS from 'helpers/paymentMethods';

// Internals
import messages from './messages';
import { FILTERS } from './constants';

// Utilties
import { locationContainsQuery } from 'utils/filters';

// Stylesheets
import './styles.scss';
import { ClassnamesFunction } from 'types/helpers';
import { Location } from 'history';

// Types
type NavigationListProps = React.ComponentProps<typeof NavigationList>;
type ReturnType = NavigationListProps['items'];

const getSectionClass: ClassnamesFunction<SectionProps> = ({ className }) =>
  classNames('c-transactions-filters__section', className);

/*
 * Transform payment methods so they can
 * be consumed by <NavigationList>
 */
const transformMethods = (methods: any[], location): ReturnType =>
  methods.map(method => ({
    key: method.id,
    label: method.description,
    hasResults: method.hasResults,
    isActive: locationContainsQuery(method.id, 'methods', location),
  }));

/*
 * Transform status items and payment methods so they can
 * be consumed by <NavigationList>
 */
const transformStatusItems = (statuses, location): ReturnType =>
  statuses.map(status => ({
    key: status.id,
    hasResults: status.hasResults,
    label: <FormattedMessage {...statusMessages[status.id]} />,
    isActive: locationContainsQuery(status.id, 'status', location),
  }));

/*
 * Transform refund status items and payment methods so they can
 * be consumed by <NavigationList>
 */
const transformRefundStatusItems = (statuses, location): ReturnType =>
  statuses.map(status => ({
    key: status.id,
    hasResults: status.hasResults,
    label: <FormattedMessage {...refundStatusMessages[status.id]} />,
    isActive: locationContainsQuery(status.id, 'status', location),
  }));

/*
 * Transform Currencies  so they can
 * be consumed by <NavigationList>
 */
const transformCurrencies = (currencies, location): ReturnType =>
  currencies.map(currency => ({
    key: currency.id,
    hasResults: currency.hasResults,
    label: <CurrencyMessage currency={currency.id} />,
    isActive: locationContainsQuery(currency.id, 'currency', location),
  }));

/**
 * Hide Apple Pay from the payment method filters, as it's a wallet instead of a payment method (but can be activated,
 * just like the regular payment methods).
 *
 * @ticket CS-3208
 */
const filterWallets = (methods): any[] => methods.filter(({ id }) => id !== METHODS.APPLEPAY);

type SectionProps = {
  key: string;
  isHidden?: boolean;
  heading: React.ReactNode;
  items: React.ReactNode;
  className?: string;
};

const renderSection: React.FC<SectionProps> = ({ key, heading, items, isHidden, className }) => {
  if (isHidden) {
    return null;
  }

  return (
    <div key={key} className={getSectionClass({ className })}>
      <Heading type="h2" as="h3">
        {heading}
      </Heading>
      {items}
    </div>
  );
};

type DatePresetsTypes = React.ComponentProps<typeof DatePresets>;
type SidebarFiltersProps = React.ComponentProps<typeof SidebarFilters>;

type Props = {
  className: string;
  methods: any[];
  statuses: any[];
  currencies: any[];
  closeFilters: React.MouseEventHandler;
  location: Location<
    {},
    {
      period: Maybe<PresetType>;
      q: Maybe<string>;
    }
  >;
  onQueryChange: (arg: string) => void;
  onDatesChange: <T>(arg: T) => void;
  onStatusChange: (arg1: string) => () => void;
  onMethodChange: (arg1: string) => () => void;
  datePresets: DatePresetsTypes['datePresets'];
  selectedDates: DatePresetsTypes['selectedDates'];
  onPresetChange: (arg1: PresetType) => void;
  showResetButton: boolean;
  resetRoute: SidebarFiltersProps['resetRoute'];
  options: string[];
  onCurrencyChange: (arg1: string) => () => void;
  filtersAreVisible: boolean;
};

const TransactionsFilters: React.FC<Props> = ({
  closeFilters,
  methods,
  statuses,
  currencies,
  location,
  className,
  selectedDates,
  datePresets,
  onQueryChange,
  onDatesChange,
  onPresetChange,
  onStatusChange,
  onMethodChange,
  onCurrencyChange,
  resetRoute,
  showResetButton,
  filtersAreVisible,
  options = Object.values(FILTERS),
}) => {
  const intl = useIntl();
  const selectedPreset = location.query.period as DatePresetsTypes['selectedPreset'];
  const filters: Record<string, any> = [];

  if (options.includes(FILTERS.SEARCH)) {
    filters.push({
      key: 'search',
      heading: (
        <FormattedMessage id="transactions-filters-search-heading" defaultMessage="Search" />
      ),
      items: (
        <InputSearch
          value={location.query.q}
          onChange={onQueryChange}
          placeholder={intl.formatMessage(messages.searchPlaceholder)}
        />
      ),
    });
  }

  if (options.includes(FILTERS.DATE)) {
    filters.push({
      key: 'date',
      heading: (
        <FormattedMessage id="transactions-filters-date-presets-heading" defaultMessage="Period" />
      ),
      items: (
        <DatePresets
          onPresetChange={onPresetChange}
          onDatesChange={onDatesChange}
          selectedDates={selectedDates}
          datePresets={datePresets}
          selectedPreset={selectedPreset}
        />
      ),
    });
  }

  if (options.includes(FILTERS.STATUS) && statuses.length > 1) {
    filters.push({
      key: 'status',
      heading: (
        <span>
          <FormattedMessage
            id="transactions-filters-payment-status-heading"
            defaultMessage="Status"
          />
          <HelpTooltip
            showOnHover={false}
            ariaLabel={intl.formatMessage(messages.filterAriaLabel)}
            content={
              <FormattedMessage
                id="transactions-filters-filter-explanation"
                defaultMessage="The meaning of the these statuses can be found in our {link}."
                values={{
                  link: (
                    <FormattedHTMLMessage
                      id="transactions-filters-filter-explanation-hc-link"
                      defaultMessage="<a href='https://help.mollie.com/hc/en-us/articles/115001488025' target='_blank' rel='noopener'>Help Center</a>"
                    />
                  ),
                }}
              />
            }
            width={280}
          />
        </span>
      ),
      items: (
        <NavigationList
          items={transformStatusItems(statuses, location)}
          onChange={onStatusChange}
        />
      ),
    });
  } else if (options.includes(FILTERS.REFUND_STATUS) && statuses.length > 1) {
    filters.push({
      key: 'status',
      heading: (
        <FormattedMessage
          id="transactions-filters-payment-status-heading"
          defaultMessage="Status"
        />
      ),
      items: (
        <NavigationList
          items={transformRefundStatusItems(statuses, location)}
          onChange={onStatusChange}
        />
      ),
    });
  }

  if (options.includes(FILTERS.METHOD) && methods.length > 1) {
    filters.push({
      key: 'method',
      heading: (
        <FormattedMessage
          id="transactions-filters-payment-method-heading"
          defaultMessage="Method"
        />
      ),
      items: (
        <NavigationList
          items={transformMethods(filterWallets(methods), location)}
          onChange={onMethodChange}
        />
      ),
    });
  }

  if (options.includes(FILTERS.CURRENCY) && currencies.length > 1) {
    filters.push({
      key: 'currency',
      heading: (
        <FormattedMessage
          id="payments-filters-payment-currency-heading"
          defaultMessage="Currency"
        />
      ),
      items: (
        <NavigationList
          items={transformCurrencies(currencies, location)}
          onChange={onCurrencyChange}
        />
      ),
    });
  }

  return (
    <SidebarFilters
      closeFilters={closeFilters}
      filtersAreVisible={filtersAreVisible}
      className={className}
      showResetButton={showResetButton}
      resetRoute={resetRoute}>
      {filters.map(renderSection)}
    </SidebarFilters>
  );
};

export default TransactionsFilters;
