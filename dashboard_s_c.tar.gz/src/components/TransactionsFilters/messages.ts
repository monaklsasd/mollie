import { defineMessages } from 'react-intl';
import { IntlMessages } from 'types/intl';

const messages: IntlMessages = defineMessages({
  searchPlaceholder: {
    id: 'transactions-filters-search-placeholder',
    defaultMessage: 'Keyword...',
  },
  cancelled: {
    id: 'transactions-filters-status-cancelled',
    defaultMessage: 'Cancelled',
  },
  filterAriaLabel: {
    id: 'transactions-filters-filter-label-explanation',
    defaultMessage: 'Go to help center for more info about statuses',
  },
});

export default messages;
