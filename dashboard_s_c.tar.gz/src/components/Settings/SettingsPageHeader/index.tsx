import React from 'react';

// Components
import Heading from 'components/UI/Heading';

import './styles.scss';

type Props = {
  heading?: React.ReactNode;
  actions?: React.ReactNode;
  children: React.ReactNode;
  icon?: React.ReactNode;
};

const SettingsPageHeader: React.FC<Props> = props => {
  const { heading, children, actions, icon } = props;

  return (
    <header className="c-settings-page-header">
      {icon && <figure className="c-settings-page-header__icon">{icon}</figure>}
      {heading && <Heading>{heading}</Heading>}
      {children && <div className="c-settings-page-header__intro">{children}</div>}
      {actions && <div className="c-settings-page-header__actions">{actions}</div>}
    </header>
  );
};

export default SettingsPageHeader;
