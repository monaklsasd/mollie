import React, { Component } from 'react';
import {
  FormattedMessage,
  FormattedHTMLMessage,
  injectIntl,
  defineMessages,
  IntlShape,
} from 'react-intl';
import commonMessages from 'messages';
import { connect } from 'react-redux';

// Components
import Link from 'components/UI/Link';
import ButtonGroup from 'components/UI/ButtonGroup';
import Tooltip from 'components/UI/Tooltip';
import SummaryCard from 'components/UI/SummaryCard';
import SummaryCardItem from 'components/UI/SummaryCard/Item';
import BankAccountStatus from 'components/BankAccountStatus';
import RequirePermissions, { Permissions } from 'containers/RequirePermissions';

// Preloadable components
import { preloadUpdateComponent } from 'containers/Settings/BankAccounts';

// Reducers
import { deleteBankAccount } from 'containers/Settings/BankAccounts/actions';
import { History } from 'history';
import { BankAccount } from 'reduxState/modules/bankAccounts/types';

const messages = defineMessages({
  deletePopUp: {
    id: 'bank-account-delete-confirm',
    defaultMessage: 'Are you sure you want to delete this bank account?',
    description: 'When the user wants to remove a bank account this confirmation message is shown.',
  },
});

interface Props {
  bankAccount: BankAccount;
  intl: IntlShape;
  deleteBankAccount: (...args) => {};
  isUsedForPayouts: boolean;
  history: History;
}

class SettingsBankAccountListItem extends Component<Props> {
  shouldComponentUpdate(nextProps): boolean {
    return nextProps.bankAccount !== this.props.bankAccount;
  }

  handleDeleteBankAccount = (): void => {
    const { deleteBankAccount, bankAccount, intl } = this.props;

    // eslint-disable-next-line no-alert
    if (bankAccount.id && window.confirm(intl.formatMessage(messages.deletePopUp))) {
      deleteBankAccount({ bankAccountId: bankAccount.id });
    }
  };

  handleVerifyBankAccount = (): void => {
    const {
      bankAccount: { id },
      history,
    } = this.props;

    history.push(`/settings/bank-accounts/${id}/verify`);
  };

  wrapTooltip(child): JSX.Element {
    const { isUsedForPayouts } = this.props;

    if (!isUsedForPayouts) {
      return child;
    }

    return (
      <Tooltip
        content={
          <FormattedHTMLMessage
            id="bank-account-delete-disabled-tooltip-text"
            defaultMessage="<p>This bank account is selected as the current settlement account. Therefore it can’t be deleted.</p>"
          />
        }>
        {child}
      </Tooltip>
    );
  }

  render(): JSX.Element {
    const {
      bankAccount: {
        accountNumber,
        accountHolder,
        bankIdentifier,
        status,
        createdDatetime,
        requiresVerification,
      },
      isUsedForPayouts,
    } = this.props;

    return (
      <SummaryCard
        controls={
          <RequirePermissions permissions={[Permissions.BANKACCOUNTS_WRITE]}>
            <ButtonGroup hasSeparator={requiresVerification}>
              {requiresVerification && (
                <Link
                  noUnderline
                  linkStyle="blue"
                  onClick={this.handleVerifyBankAccount}
                  onMouseOver={preloadUpdateComponent}>
                  <FormattedMessage
                    id="settings-bank-account-list-button-retry-verification"
                    defaultMessage="Retry verification"
                  />
                </Link>
              )}
              {this.wrapTooltip(
                <Link
                  linkStyle="danger"
                  onClick={this.handleDeleteBankAccount}
                  disabled={isUsedForPayouts}>
                  <FormattedMessage
                    id="settings-bank-account-list-button-delete"
                    defaultMessage="Delete"
                  />
                </Link>,
              )}
            </ButtonGroup>
          </RequirePermissions>
        }
        heading={accountNumber}
        byline={
          isUsedForPayouts && (
            <FormattedMessage
              id="settings-bank-account-list-used-for-payouts"
              defaultMessage="used for payouts"
            />
          )
        }>
        <SummaryCardItem>
          <span>
            <FormattedMessage
              id="settings-bank-account-list-account-holder"
              defaultMessage="Account holder"
              description="The name of the owner of this bank account"
            />
            :
          </span>
          {accountHolder}
        </SummaryCardItem>
        <SummaryCardItem>
          <span>
            <FormattedMessage
              id="settings-bank-account-list-bank"
              defaultMessage="Bank"
              description="The name of the bank"
            />
            :
          </span>
          {bankIdentifier}
        </SummaryCardItem>
        <SummaryCardItem>
          <span>
            <FormattedMessage
              id="settings-bank-account-list-status"
              defaultMessage="Status"
              description="Indicated whether or not the bank account is verified"
            />
            :
          </span>
          <BankAccountStatus status={status} />
        </SummaryCardItem>
        <SummaryCardItem>
          <span>
            <FormattedMessage
              id="settings-bank-account-list-date-added"
              defaultMessage="Added on"
              description="The date on which the bank account was added"
            />
            :
          </span>
          <FormattedMessage
            {...commonMessages.dateTime}
            values={{ date: new Date(createdDatetime) }}
          />
        </SummaryCardItem>
      </SummaryCard>
    );
  }
}

const mapDispatchToProps = {
  deleteBankAccount: deleteBankAccount,
};

export default connect(undefined, mapDispatchToProps)(injectIntl(SettingsBankAccountListItem));
