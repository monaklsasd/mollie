import React, { Component } from 'react';
import { connect } from 'react-redux';
import { FormattedMessage, injectIntl, defineMessages, IntlShape } from 'react-intl';
import autobind from 'utils/autobind';
import moment from 'moment';

// Containers
import RequirePermissions, { Permissions } from 'containers/RequirePermissions';

// Components
import Avatar from 'components/Avatar';
import Heading from 'components/UI/Heading';
import Link from 'components/UI/Link';

// Redux
import * as AuthorizedApplications from 'reduxState/modules/authorizedApplications';

// Types
import { IntlMessages } from 'types/intl';

import './styles.scss';

const getPermissionsList = (permissions: { description: string }[]): string =>
  permissions.map(x => x.description.toLowerCase()).join(', ');

const messages: IntlMessages = defineMessages({
  deletePopUp: {
    id: 'settings-authorized-applications-confirm',
    defaultMessage:
      'Are you sure you want to revoke the authorization to access your Mollie account for this application?',
    description:
      'When the user wants to remove an authorized application this confirmation message is shown.',
  },
  lastAccessedUnknown: {
    id: 'settings-authorized-applications-last-accessed-unknown',
    defaultMessage: 'unknown',
  },
});

type Props = {
  application: AuthorizedApplications.AuthorizedApplication;
  handleRevokeAuthorizedApplication: (...args: any[]) => void;
  intl: IntlShape;
};

class AuthorizedApplicationItem extends Component<Props> {
  constructor(props: Props) {
    super(props);

    autobind(this);
  }

  shouldComponentUpdate(nextProps): boolean {
    return nextProps.application !== this.props.application;
  }

  handleRevokeAuthorizedApplication(): void {
    const { application, handleRevokeAuthorizedApplication, intl } = this.props;

    if (application.id && window.confirm(intl.formatMessage(messages.deletePopUp))) {
      // eslint-disable-line no-alert
      handleRevokeAuthorizedApplication(application, '/settings/applications');
    }
  }

  render(): React.ReactElement {
    const {
      intl,
      application: { name, description, iconUrl, permissions, lastAccessedDatetime },
    } = this.props;

    const lastAccessed = lastAccessedDatetime
      ? moment(lastAccessedDatetime).fromNow()
      : intl.formatMessage(messages.lastAccessedUnknown);

    return (
      <div className="c-authorized-application">
        <header className="c-authorized-application__header">
          <figure className="c-authorized-application__icon">
            <Avatar seed={name} size="small">
              <img src={iconUrl} alt="" />
            </Avatar>
          </figure>
          <div className="c-authorized-application__hgroup">
            <Heading type="h3" className="c-authorized-application__heading">
              {name}
            </Heading>
            <p className="c-authorized-application__byline">{description}</p>
          </div>
          <RequirePermissions permissions={[Permissions.ORGANIZATIONS_WRITE]}>
            <Link
              className="c-authorized-application__revoke"
              noUnderline
              linkStyle="danger"
              onClick={this.handleRevokeAuthorizedApplication}>
              <FormattedMessage
                id="settings-authorized-applications-button-revoke"
                defaultMessage="Revoke"
              />
            </Link>
          </RequirePermissions>
        </header>
        <ul className="c-authorized-application__body">
          <li>
            <strong>
              <FormattedMessage
                id="settings-authorized-applications-permissions"
                defaultMessage="Permissions"
              />
              :
            </strong>{' '}
            {getPermissionsList(permissions)}
          </li>
          <li>
            <strong>
              <FormattedMessage
                id="settings-authorized-applications-last-accessed"
                defaultMessage="Last access"
              />
              :
            </strong>{' '}
            {lastAccessed}
          </li>
        </ul>
      </div>
    );
  }
}

const mapDispatchToProps = {
  handleRevokeAuthorizedApplication: AuthorizedApplications.revokeAuthorization,
};

export default connect(undefined, mapDispatchToProps)(injectIntl(AuthorizedApplicationItem));
