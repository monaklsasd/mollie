import { call, put, takeLatest } from 'redux-saga/effects';

import { callApi } from 'reduxState/sagas/api';
import { fetchStatementDownloadsAvailability } from 'services/api';
import * as actions from './actions';
import * as constants from './constants';

/* **************************************************************************** */
/* ****************************** SUBROUTINES ********************************* */
/* **************************************************************************** */

export function* fetchAvailabilityRoutine({
  payload: { format, month, year },
}): Generator<any, any, any> {
  const apiResult = yield call(callApi, fetchStatementDownloadsAvailability, format, year, month);
  const { response, errorResponse } = apiResult;

  if (response) {
    if (response.error) {
      yield put(actions.fetchAvailabilityFailure(response.error.message, { format, year, month }));
    } else {
      yield put(actions.fetchAvailabilitySuccess(response, { format, year, month }));
    }
  } else if (errorResponse && errorResponse.error && errorResponse.error.message) {
    yield put(
      actions.fetchAvailabilityFailure(errorResponse.error.message, { format, year, month }),
    );
  }

  return apiResult;
}

/* **************************************************************************** */
/* ****************************** WATCHERS ************************************ */
/* **************************************************************************** */

export function* watchFetchAvailability(): Generator<any, any, any> {
  // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
  // @ts-ignore
  yield takeLatest(constants.FETCH_AVAILABILITY, fetchAvailabilityRoutine);
}
