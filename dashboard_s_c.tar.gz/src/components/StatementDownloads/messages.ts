import { IntlMessages } from './../../types/intl';
import { defineMessages } from 'react-intl';

const messages: IntlMessages = defineMessages({
  entireMonth: {
    id: 'statement-downloads-entire-month',
    defaultMessage: 'Entire month (single file)',
  },
  noDownloadsAvailable: {
    id: 'statement-downloads-unavailable-in-period',
    defaultMessage: 'No downloads available in the selected period.',
  },
  downloadRetry: {
    id: 'statement-downloads-submit-retry-fetch-availability',
    defaultMessage: 'Retry',
  },
  downloadClose: {
    id: 'statement-downloads-close-tooltip',
    defaultMessage: 'Cancel',
  },
});

export default messages;
