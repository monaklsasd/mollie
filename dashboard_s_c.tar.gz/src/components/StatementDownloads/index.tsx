import React, { Component } from 'react';
import { connect } from 'react-redux';
import moment from 'moment';
import { FormattedDate, FormattedMessage, injectIntl, IntlShape } from 'react-intl';

import MollieURL from 'utils/MollieURL';

// Utils
import shallowEqual from 'utils/shallowEqual';
import { getCurrentMonthNumber, getCurrentYearNumber } from 'utils/getCurrentDateNumbers';
import apiClient from 'services/api/client';

// Components
import SelectMonth from 'components/forms/SelectMonth';
import SelectYear from 'components/forms/SelectYear';
import Button from 'components/UI/Button';
import Link from 'components/UI/Link';
import LoadingState from 'components/UI/LoadingState';
import Modal from 'components/UI/Modal';
import TabGroup from 'components/UI/TabGroup';
import Tab from 'components/UI/Tab';
import { ReactComponent as IconDownload } from 'assets/icons/download.svg';
import { ReactComponent as IconExport } from 'assets/icons/export.svg';
import { ReactComponent as IconCloseCircle } from 'assets/icons/close-circle.svg';

// Redux
import {
  getFirstPaymentDateWithFallback,
  getOrganization,
} from 'reduxState/modules/organization/selectors';
import { getApiBaseUrl } from 'reduxState/modules/application/selectors';

// Internals
import * as actions from './actions';
import * as selectors from './selectors';
import { FORMATS } from './constants';
import messages from './messages';
import './styles.scss';

const isCurrentMonth = (year: number, month: number): boolean =>
  Number(year) === getCurrentYearNumber() && month === getCurrentMonthNumber();

const isCurrentYear = (year: number): boolean => Number(year) === getCurrentYearNumber();

const isFutureMonth = (month: number, year: number): boolean =>
  month > getCurrentMonthNumber() && isCurrentYear(year);

const getMonthRange = ({ selectedDates: { year }, firstPaymentDate }): State['monthRange'] => {
  let from = 1;
  let to = 12;

  // Limit first month if firstPaymentDate is in the selected year
  if (Number(year) === firstPaymentDate.getFullYear()) {
    from = firstPaymentDate.getMonth() + 1;
  }

  if (isCurrentYear(year)) {
    to = getCurrentMonthNumber();
  }

  return {
    from,
    to,
  };
};

type FormatMonthYearFunction = (args: {
  format: Props['format'];
  month: number;
  year: number;
}) => void;

type Props = {
  intl: IntlShape;
  selectedDates: {
    month: number;
    year: number;
  };
  error: Record<string, any> | string;
  apiBaseUrl: string;
  isLoading: boolean;
  updateSelectedRange: FormatMonthYearFunction;
  format: string;
  availableDownloads: {
    daysAvailable: any[];
    monthAvailable: any[];
  };
  firstPaymentDate: Date;
  fetchAvailability: FormatMonthYearFunction;
  updateFormat: (arg: string) => void;
  organization: {
    id: string;
  };
};

type State = {
  id: Nullable<string>;
  firstYear: number;
  monthRange: {
    from: number;
    to: number;
  };
  day: Nullable<number>;
  modalIsOpen: boolean;
};

class StatementDownloads extends Component<Props, State> {
  constructor(props) {
    super(props);

    this.state = {
      id: null,
      day: null,
      firstYear: props.firstPaymentDate.getFullYear(),
      monthRange: getMonthRange(props),
      modalIsOpen: false,
    };
  }

  /**
   * Always fetch availability for the current month as it may have changed,
   * (previous month data never changes; the downloads are static).
   * Also fetch availability if no data is available (on remount).
   */
  componentDidMount(): void {
    const { format, availableDownloads, fetchAvailability } = this.props;

    // Initialise selectedDates for current period
    const year = getCurrentYearNumber();
    const month = getCurrentMonthNumber();

    if (isCurrentMonth(year, month) || !availableDownloads) {
      fetchAvailability({ format, year, month });
    }
  }

  componentWillReceiveProps(nextProps): void {
    const {
      format,
      availableDownloads,
      selectedDates: { month, year },
    } = nextProps;
    const {
      fetchAvailability,
      selectedDates: { month: prevMonth, year: prevYear },
    } = this.props;
    const monthRange = getMonthRange(nextProps);
    const currentMonth = isCurrentMonth(year, month);
    const monthOrYearHasChanged = year !== prevYear || month !== prevMonth;

    // Update monthRange if year changed
    if (year !== prevYear && !shallowEqual(this.state.monthRange, monthRange)) {
      this.setState({
        monthRange,
      });
    }

    /*
     * Fetch new data when:
     * - Month/year has changed and it is the current month
     * - Month/year has changed and there is no data
     */
    if ((monthOrYearHasChanged && !availableDownloads) || (monthOrYearHasChanged && currentMonth)) {
      fetchAvailability({ format, year, month });
    }
  }

  closeModal = (): void => {
    this.setState({
      modalIsOpen: false,
    });
  };

  openModal = (): void => {
    this.setState({
      modalIsOpen: true,
    });
  };

  onUpdateFormat = (element): void => this.props.updateFormat(element.getAttribute('value'));

  onUpdateMonth = (month: number): void => {
    const {
      format,
      selectedDates: { year },
      updateSelectedRange,
    } = this.props;
    updateSelectedRange({ format, year, month: parseInt(`${month}`, 10) });
  };

  onUpdateYear = (year): void => {
    const {
      format,
      selectedDates: { month },
      updateSelectedRange,
    } = this.props;

    updateSelectedRange({
      format,
      year,
      // If the selected month is in the future, fall back to the current month
      month: isFutureMonth(month, year) ? getCurrentMonthNumber() : month,
    });
  };

  handleDownloadStatement = (dayNumber: Nullable<number>): void => {
    this.setState({
      day: dayNumber,
      id: dayNumber ? 'day' : 'month' /** Semantics for GET request @issue INT-586 **/,
    });

    // Submit downloadForm after state is updated
    requestAnimationFrame(() => {
      this.downloadForm && this.downloadForm.submit();
    });
  };

  downloadForm: Nullable<HTMLFormElement> = null;

  handleRetryFetchAvailability = (): void => {
    const {
      format,
      fetchAvailability,
      selectedDates: { month, year },
    } = this.props;

    /**
     * Hacky workaround to prevent the Tooltip from tripping & closing.
     * Can be removed once the issue below is resolved.
     * @issue INT-565
     */
    requestAnimationFrame(() => {
      fetchAvailability({ format, year, month });
    });
  };

  renderContent(): React.ReactElement {
    const {
      apiBaseUrl,
      availableDownloads,
      error,
      isLoading,
      selectedDates: { month, year },
      format,
    } = this.props;
    const { firstYear, id, monthRange } = this.state;

    return (
      <div className="c-statement-downloads">
        {/**
         * The iframe and form below allow us to trigger file downloads served by the API,
         * but without using the apiClient and having to deal with blobs.
         * By setting the form target to the iframe name, the GET response is rendered in the iframe
         * thus triggering a download. This should be refactored when we have a better setup.
         *
         * A GET response is specifically required over a POST due to IE / Edge (see: INT-586).
         *
         * @issue INT-520
         * @issue INT-586
         */}
        <iframe
          title="statementDownloadsFrame"
          aria-hidden
          hidden
          name="statementDownloadsFrame"
          style={{ display: 'none' }}
        />
        <form
          action={MollieURL.createStatementsDownload(apiBaseUrl, format, id)}
          className="c-statement-downloads"
          method="GET"
          ref={(c): void => {
            this.downloadForm = c;
          }}
          target="statementDownloadsFrame"
          style={{ display: 'none' }}>
          <input type="text" value={year} name="year" readOnly />
          <input type="text" value={month} name="month" readOnly />
          <input type="hidden" value={this.props.organization.id} name="organizationId" />
          {this.state.day && <input type="text" value={this.state.day} name="day" readOnly />}
          <input type="text" value={apiClient.csrfToken} name="_formtoken" readOnly />
          <button type="submit" />
        </form>

        <div className="c-statement-downloads__format-settings">
          <TabGroup className="c-statement-downloads__tabs">
            <Tab
              onClick={this.onUpdateFormat}
              value={FORMATS.MT940}
              isActive={format === FORMATS.MT940}>
              {FORMATS.MT940.toUpperCase()}
            </Tab>
            <Tab
              onClick={this.onUpdateFormat}
              value={FORMATS.CODA}
              isActive={format === FORMATS.CODA}>
              {FORMATS.CODA.toUpperCase()}
            </Tab>
          </TabGroup>
        </div>

        <div className="c-statement-downloads__date-settings">
          <SelectYear
            className="year-select"
            from={firstYear}
            onChange={this.onUpdateYear}
            value={year || getCurrentYearNumber()}
          />
          <SelectMonth
            className="month-select"
            onChange={(e): void => this.onUpdateMonth(e as any)}
            value={month || getCurrentMonthNumber()}
            {...monthRange}
          />
        </div>

        <div className="c-statement-downloads__content">
          <LoadingState
            compact
            delay={0}
            isLoading={isLoading || !availableDownloads}
            noMargin
            noBorder>
            <div>
              {error && (
                <div className="c-statement-downloads__error">
                  <IconCloseCircle height={42} width={42} />
                  <div className="c-statement-downloads__message c-statement-downloads__message--error">
                    {error}
                  </div>

                  <Link onClick={this.handleRetryFetchAvailability}>
                    <FormattedMessage {...messages.downloadRetry} />
                  </Link>
                </div>
              )}

              {availableDownloads && availableDownloads.daysAvailable.length === 0 && (
                <div className="c-statement-downloads__message">
                  <FormattedMessage {...messages.noDownloadsAvailable} />
                </div>
              )}

              {availableDownloads && availableDownloads.daysAvailable.length > 0 && (
                <ul className="c-statement-downloads__list l-list-ui l-list-ui--has-borders l-list-ui--no-spacing">
                  {availableDownloads.monthAvailable && (
                    <li key="entireMonth">
                      <Link
                        noUnderline
                        fullWidth
                        className="c-statement-downloads__download-button"
                        onClick={(): void => {
                          this.handleDownloadStatement(null);
                        }}>
                        <span className="c-statement-downloads__action-wrapper">
                          <IconDownload className="c-statement-downloads__download-icon" />
                          <span className="u-bold">
                            <FormattedMessage {...messages.entireMonth} />
                          </span>
                        </span>
                      </Link>
                    </li>
                  )}

                  {availableDownloads.daysAvailable.map(day => {
                    const date = moment(`${year}-${month}-${day}`, 'YYYY-MM-D');
                    return (
                      <li key={day}>
                        <Link
                          noUnderline
                          fullWidth
                          className="c-statement-downloads__download-button"
                          onClick={(): void => {
                            this.handleDownloadStatement(day);
                          }}>
                          <span className="c-statement-downloads__action-wrapper">
                            <IconDownload className="c-statement-downloads__download-icon" />
                            <FormattedDate
                              value={date.toDate()}
                              weekday="long"
                              day="numeric"
                              month="long"
                              year="numeric"
                            />
                          </span>
                        </Link>
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>
          </LoadingState>
        </div>
      </div>
    );
  }

  render(): React.ReactElement {
    return (
      <React.Fragment>
        <Button onClick={this.openModal}>
          <IconExport width={9} height={12} />
          <FormattedMessage id="administration-navigation-export" defaultMessage="Export" />
        </Button>
        <Modal isOpen={this.state.modalIsOpen} onRequestClose={this.closeModal}>
          {this.renderContent()}
        </Modal>
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => {
  const organization = getOrganization(state);
  const format = selectors.getSelectedFormat(state);

  return {
    apiBaseUrl: getApiBaseUrl(state),
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    availableDownloads: selectors.getAvailableDownloads(state, format),
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    error: selectors.getErrorMessage(state, format),
    firstPaymentDate: new Date(getFirstPaymentDateWithFallback(state)),
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    isLoading: selectors.getLoadingState(state, format),
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    selectedDates: selectors.getSelectedDates(state, format),
    organization,
    format,
  };
};

const mapDispatchToProps = {
  fetchAvailability: actions.fetchAvailability,
  updateSelectedRange: actions.updateSelectedRange,
  updateFormat: actions.updateFormat,
};

export default connect(mapStateToProps, mapDispatchToProps)(injectIntl(StatementDownloads));
