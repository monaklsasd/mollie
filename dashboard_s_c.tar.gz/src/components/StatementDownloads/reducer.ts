import { combineReducers } from 'redux';

import { getCurrentMonthNumber, getCurrentYearNumber } from 'utils/getCurrentDateNumbers';
import * as constants from './constants';

const initialSelectedDatesState = {
  month: getCurrentMonthNumber(),
  year: getCurrentYearNumber(),
};

// No initial state by design. Used by container to determine whether data is at all available.
const availabilityData = (state, action) => {
  switch (action.type) {
    // Make sure we have empty data when switching dates
    case constants.UPDATE_MONTH_YEAR:
      if (!state) {
        return null;
      }
      return state;

    // Reset availability before fetching
    case constants.FETCH_AVAILABILITY:
      return null;

    case constants.FETCH_AVAILABILITY_SUCCESS:
      return {
        ...state,
        ...action.payload.response.data,
      };

    default:
      return state;
  }
};

const data = (state = {}, action) => {
  switch (action.type) {
    case constants.UPDATE_MONTH_YEAR:
    case constants.FETCH_AVAILABILITY:
    case constants.FETCH_AVAILABILITY_SUCCESS:
    case constants.FETCH_AVAILABILITY_FAILURE:
      return {
        ...state,
        [`${action.payload.year}-${action.payload.month}`]: availabilityData(
          state[`${action.payload.year}-${action.payload.month}`],
          action,
        ),
      };

    default:
      return state;
  }
};

const selectedFormat = (state = null, action): Nullable<Record<string, any>> => {
  switch (action.type) {
    case constants.UPDATE_FORMAT:
      return action.payload;
    default:
      return state;
  }
};

const selectedDates = (state = initialSelectedDatesState, action): Record<string, any> => {
  switch (action.type) {
    case constants.UPDATE_MONTH_YEAR:
      return {
        month: action.payload.month,
        year: action.payload.year,
      };
    default:
      return state;
  }
};

const isLoading = (state = false, action): boolean => {
  switch (action.type) {
    case constants.FETCH_AVAILABILITY:
      return true;
    case constants.FETCH_AVAILABILITY_SUCCESS:
    case constants.FETCH_AVAILABILITY_FAILURE:
      return false;
    default:
      return state;
  }
};

const error = (state = null, action): Nullable<Record<string, any>> => {
  switch (action.type) {
    case constants.FETCH_AVAILABILITY:
    case constants.FETCH_AVAILABILITY_SUCCESS:
      return null;
    case constants.FETCH_AVAILABILITY_FAILURE:
      return action.payload.error;
    default:
      return state;
  }
};

export default combineReducers({
  data,
  selectedFormat,
  selectedDates,
  isLoading,
  error,
});
