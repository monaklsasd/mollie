import { MT940, CODA } from 'helpers/documentFormats';

const MODULE_NAME = 'administrationStatementDownloads';

export const FETCH_AVAILABILITY = `${MODULE_NAME}/FETCH_AVAILABILITY`;
export const FETCH_AVAILABILITY_FAILURE = `${MODULE_NAME}/FETCH_AVAILABILITY_FAILURE`;
export const FETCH_AVAILABILITY_SUCCESS = `${MODULE_NAME}/FETCH_AVAILABILITY_SUCCESS`;

export const UPDATE_MONTH_YEAR = `${MODULE_NAME}/UPDATE_MONTH_YEAR`;
export const UPDATE_FORMAT = `${MODULE_NAME}/UPDATE_FORMAT`;

// Values are intentionally lowercase as they're used to determine the api endpoint.
export const FORMATS = {
  MT940,
  CODA,
};
