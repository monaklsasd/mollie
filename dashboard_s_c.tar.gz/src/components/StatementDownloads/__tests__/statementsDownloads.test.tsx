import { call, put, takeLatest } from 'redux-saga/effects';
import * as api from 'services/api';
import { callApi } from 'reduxState/sagas/api';
import rootReducer from 'reduxState/reducers';
import { getCurrentMonthNumber, getCurrentYearNumber } from 'utils/getCurrentDateNumbers';
import reducer from '../reducer';
import * as actions from '../actions';
import * as selectors from '../selectors';
import * as sagas from '../sagas';
import * as constants from '../constants';

jest.mock('utils/getCurrentDateNumbers');

describe('StatementDownloads', () => {
  // Mocked defaults
  const month = 9;
  const year = 2017;
  const { MT940, CODA } = constants.FORMATS;
  const defaultPayload = { format: MT940, month, year };
  const mockErrorMessage = 'Some error';
  const successResponse = {
    data: {
      monthAvailable: false,
      daysAvailable: [1, 2, 3, 5, 8, 13],
    },
  };
  const errorResponse = {
    error: {
      message: mockErrorMessage,
    },
  };

  // State defaults
  // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
  // @ts-ignore
  const globalState = rootReducer({})(undefined, {});

  const initialState = {
    data: {},
    selectedFormat: null,
    selectedDates: {
      month: getCurrentMonthNumber(), // Mocked by jest
      year: getCurrentYearNumber(), // Mocked by jest
    },
    isLoading: false,
    error: null,
  };

  it('should return initialState', () => {
    const state = reducer(undefined, {});
    expect(state).toEqual(initialState);
  });

  it('should return the correct selected format', () => {
    // Expecting the default value from getPreferredExportFormat
    expect(selectors.getSelectedFormat(globalState)).toBe(MT940);

    // After selecting a different format
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    const state = rootReducer({})(globalState, actions.updateFormat(CODA));
    expect(selectors.getSelectedFormat(state)).toBe(CODA);
  });

  it('should return the correct availability data', () => {
    // Preset the selectedDates corresponding to defaultPayload
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    const state = rootReducer({})(globalState, actions.updateSelectedRange(defaultPayload));
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    const finalState = rootReducer({})(
      state,
      actions.fetchAvailabilitySuccess(successResponse, defaultPayload),
    );
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    expect(selectors.getAvailableDownloads(finalState, MT940)).toEqual(successResponse.data);
  });

  it('should return the correct error state', () => {
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    const state = rootReducer({})(
      globalState,
      actions.fetchAvailabilityFailure(mockErrorMessage, defaultPayload),
    );
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    expect(selectors.getErrorMessage(state, MT940)).toBe(mockErrorMessage);
  });

  it('should reset error state after a successful fetch', () => {
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    const state = rootReducer({})(
      globalState,
      actions.fetchAvailabilityFailure(mockErrorMessage, defaultPayload),
    );
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    const finalState = rootReducer({})(
      state,
      actions.fetchAvailabilitySuccess(successResponse, defaultPayload),
    );
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    expect(selectors.getErrorMessage(finalState, MT940)).toBe(null);
  });

  it('should return the correct dates', () => {
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    const state = rootReducer({})(globalState, actions.updateSelectedRange(defaultPayload));
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    expect(selectors.getSelectedDates(state, MT940)).toEqual({ year, month });
  });

  it('should return correct loading state', () => {
    // During loading
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    const stateWhileLoading = rootReducer({})(
      globalState,
      actions.fetchAvailability(defaultPayload),
    );
    expect(selectors.getLoadingState(stateWhileLoading)).toBe(true);

    // After loaded
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    const stateAfterLoading = rootReducer({})(
      globalState,
      actions.fetchAvailabilitySuccess(successResponse, defaultPayload),
    );
    expect(selectors.getLoadingState(stateAfterLoading)).toBe(false);
  });

  describe('sagas', () => {
    describe('watchFetchAvailability', () => {
      it('should call fetchAvailabilityRoutine when FETCH_AVAILABILITY is dispatched', () => {
        const generator = sagas.watchFetchAvailability();

        expect(generator.next().value).toEqual(
          // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
          // @ts-ignore
          takeLatest(constants.FETCH_AVAILABILITY, sagas.fetchAvailabilityRoutine),
        );
        expect(generator.next().done).toBe(true);
      });
    });

    describe('fetchAvailabilityRoutine', () => {
      it('should call fetchAvailabilitySuccess when success response is returned', () => {
        const response = successResponse;
        const generator = sagas.fetchAvailabilityRoutine({
          // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
          // @ts-ignore
          type: constants.FETCH_AVAILABILITY,
          payload: defaultPayload,
        });

        // Get response
        expect(generator.next().value).toEqual(
          call(callApi, api.fetchStatementDownloadsAvailability, MT940, year, month),
        );

        expect(generator.next({ response, ...defaultPayload }).value).toEqual(
          put(actions.fetchAvailabilitySuccess(response, defaultPayload)),
        );
      });

      it('should call fetchAvailabilityFailure when error response is returned', () => {
        const generator = sagas.fetchAvailabilityRoutine({
          // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
          // @ts-ignore
          type: constants.FETCH_AVAILABILITY,
          payload: defaultPayload,
        });

        // Get response
        expect(generator.next().value).toEqual(
          call(callApi, api.fetchStatementDownloadsAvailability, MT940, year, month),
        );

        // Error response
        expect(generator.next({ response: errorResponse, ...defaultPayload }).value).toEqual(
          put(actions.fetchAvailabilityFailure(mockErrorMessage, defaultPayload)),
        );
      });
    });
  });
});
