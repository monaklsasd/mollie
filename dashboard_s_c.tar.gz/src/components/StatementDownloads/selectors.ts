import { createSelector } from 'reselect';
import { getPreferredExportFormat } from 'reduxState/modules/organization/selectors';

const getState = (state): Record<string, any> => state.administrationStatementDownloads;

const getAllData = createSelector(getState, state => state.data);

export const getSelectedDates = createSelector(getState, state => state.selectedDates);

export const getLoadingState = createSelector(getState, state => state.isLoading);

export const getErrorMessage = createSelector(getState, state => state.error);

export const getAvailableDownloads = createSelector(
  getAllData,
  getSelectedDates,
  (data, selectedDates) => data[`${selectedDates.year}-${selectedDates.month}`],
);

export const getSelectedFormat = createSelector(
  getState,
  getPreferredExportFormat,
  (state, preferredFormat) => state.selectedFormat || preferredFormat,
);
