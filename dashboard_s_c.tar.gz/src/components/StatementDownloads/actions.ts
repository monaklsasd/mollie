import { ActionType } from 'reduxState/types';
import * as constants from './constants';

export const fetchAvailability = (
  payload,
): ActionType<typeof constants.FETCH_AVAILABILITY, any> => ({
  type: constants.FETCH_AVAILABILITY,
  payload,
});

export const fetchAvailabilitySuccess = (
  response,
  payload,
): ActionType<typeof constants.FETCH_AVAILABILITY_SUCCESS, any> => ({
  type: constants.FETCH_AVAILABILITY_SUCCESS,
  payload: {
    response,
    ...payload,
  },
});

export const fetchAvailabilityFailure = (
  error,
  payload,
): ActionType<typeof constants.FETCH_AVAILABILITY_FAILURE, any> => ({
  type: constants.FETCH_AVAILABILITY_FAILURE,
  payload: {
    error,
    ...payload,
  },
});

export const updateSelectedRange = (
  payload,
): ActionType<typeof constants.UPDATE_MONTH_YEAR, any> => ({
  type: constants.UPDATE_MONTH_YEAR,
  payload,
});

export const updateFormat = (payload): ActionType<typeof constants.UPDATE_FORMAT, any> => ({
  type: constants.UPDATE_FORMAT,
  payload,
});
