import React from 'react';
import { FormattedMessage, useIntl } from 'react-intl';

// Components
import Currency from 'components/UI/Currency';
import IconPaymentMethods, { AcceptedMethods } from 'components/IconPaymentMethods';
import GridTable from 'components/UI/GridTable';
import GridTableRow from 'components/UI/GridTable/Row';
import GridTableCell from 'components/UI/GridTable/Cell';

// Messages
import commonMessages, { tables } from 'messages';

// Types
import { ChargebackWithPaymentType } from 'reduxState/modules/chargebacks/types';

import './styles.scss';

type Props = {
  data: ChargebackWithPaymentType[];
};

const ChargebacksTable: React.FC<Props> = ({ data }) => {
  const intl = useIntl();
  return (
    <GridTable
      className="chargebacks-table"
      columnRow={[
        <GridTableCell name="methods">
          <FormattedMessage {...tables.methods} />
        </GridTableCell>,
        <GridTableCell name="amount" numeric>
          <FormattedMessage {...tables.amount} />
        </GridTableCell>,
        <GridTableCell name="chargebackId">
          <FormattedMessage {...tables.chargebackId} />
        </GridTableCell>,
        <GridTableCell name="paymentId">
          <FormattedMessage {...tables.paymentId} />
        </GridTableCell>,
        <GridTableCell name="date" numeric>
          <FormattedMessage {...tables.date} />
        </GridTableCell>,
        <GridTableCell name="reversedAt" numeric>
          <FormattedMessage {...tables.reversedAt} />
        </GridTableCell>,
      ]}>
      {data.map(chargeback => (
        <GridTableRow
          key={chargeback.id}
          link={{
            to: `/payments/${chargeback.payment.id}`,
            ariaLabel: intl.formatMessage({
              id: 'chargebacks-table-link-label',
              defaultMessage: 'View payment detail page',
            }),
          }}>
          <GridTableCell name="methods">
            <IconPaymentMethods
              method={chargeback.payment.method as AcceptedMethods}
              width={30}
              height={30}
            />
          </GridTableCell>
          <GridTableCell name="amount" numeric>
            <Currency {...chargeback.amount} />
          </GridTableCell>
          <GridTableCell name="chargebackId">{chargeback.id}</GridTableCell>
          <GridTableCell name="paymentId">{chargeback.payment.id}</GridTableCell>
          <GridTableCell name="date" numeric>
            <span className="chargebacks-table__mobile-label">
              <FormattedMessage {...tables.date} />:{' '}
            </span>
            <FormattedMessage
              {...commonMessages.dateTimeShort}
              values={{ date: new Date(chargeback.chargebackDatetime) }}
            />
          </GridTableCell>

          <GridTableCell name="reversedAt" numeric>
            {chargeback.reversedDatetime && (
              <React.Fragment>
                <span className="chargebacks-table__mobile-label">
                  <FormattedMessage {...tables.reversedAt} />:{' '}
                </span>
                <FormattedMessage
                  {...commonMessages.dateTimeShort}
                  values={{ date: new Date(chargeback.reversedDatetime) }}
                />
              </React.Fragment>
            )}
          </GridTableCell>
        </GridTableRow>
      ))}
    </GridTable>
  );
};
export default ChargebacksTable;
