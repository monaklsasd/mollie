import { defineMessages } from 'react-intl';
import { IntlMessages } from 'types/intl';

const messages: IntlMessages = defineMessages({
  legalRep: {
    id: 'onboarding-stakeholders-legal-representative-title',
    defaultMessage: 'Legal representative',
  },
  legalRepDescription: {
    id: 'onboarding-stakeholders-legal-representative-description',
    defaultMessage:
      'Please enter the information from (one of) the legal representatives of your company. This person should be registered in the company register and authorized to sign in name of the company.',
  },
  associates: {
    id: 'onboarding-stakeholders-associates-title',
    defaultMessage: 'Associates',
  },
  associatesDescription: {
    id: 'onboarding-stakeholders-associates-description',
    defaultMessage:
      'Due to the chosen legal form, we need the information from the associates of your company. The associates are the (co-) owners of your organization as mentioned in the company register.',
  },
  legalRepStatus: {
    id: 'onboarding-stakeholders-status',
    defaultMessage: 'Legal Representative',
  },
  ubo: {
    id: 'onboarding-stakeholders-UBO-title',
    defaultMessage: 'Ultimate beneficial owners',
  },
  uboDescription1: {
    id: 'onboarding-stakeholders-UBO-description-1',
    defaultMessage: `We are legally obligated to request the personal information of the ultimate beneficial owner(s) (UBO) of {company}. An UBO is a person who owns or controls the company. For instance through holding more than 25% (direct or indirect) of the stocks, voting rights or ownership interest, or by exercising effective control through other means.

If no UBO can be appointed according to these criteria, the company executives will be considered as the UBO.`,
    description:
      'There are seven different descriptions for ubos. Depending on ubo category the text will be shown',
  },
  uboDescription2: {
    id: 'onboarding-stakeholders-UBO-description-2',
    defaultMessage: `We are legally obligated to request the personal information of the ultimate beneficial owner(s) (UBO) of {company}. An UBO is a person who owns or controls the company. For instance through holding more than 25% (direct or indirect) of the voting rights or ownership interest, or by exercising effective control over the company.

If no UBO can be appointed according to these criteria, the company executives will be considered as the UBO.`,
    description:
      'There are seven different descriptions for ubos. Depending on ubo category the text will be shown',
  },
  uboDescription3: {
    id: 'onboarding-stakeholders-UBO-description-3',
    defaultMessage: `We are legally obligated to request the personal information of the ultimate beneficial owner(s) (UBO) of {company}. The UBO is the person who is the legal successor in the event of a dissolvement of the church society.

In case no legal successor has been named, please fill in the details of the executives as stated in the statutes or other legal documents of the church society.`,
    description:
      'There are seven different descriptions for ubos. Depending on ubo category the text will be shown',
  },
  uboDescription4: {
    id: 'onboarding-stakeholders-UBO-description-4',
    defaultMessage: `We are legally obligated to request the personal information of the ultimate beneficial owner(s) (UBO) of {company}. An UBO is a person who owns or controls the company. For instance through holding more than 25% (direct or indirect) of the voting rights or ownership interest, or by exercising effective control over the company.

If no UBO can be appointed according to these criteria, the associates of the company will be considered the UBO.`,
    description:
      'There are seven different descriptions for ubos. Depending on ubo category the text will be shown',
  },
  uboDescription5: {
    id: 'onboarding-stakeholders-UBO-description-5',
    defaultMessage: `
   We are legally obligated to request the personal information of the ultimate beneficial owner(s) (UBO) of {company}. UBO’s are the founders, trustees, protectors, beneficiaries of the trust and all other people who are exercising effective control over the trust.`,
    description:
      'There are seven different descriptions for ubos. Depending on ubo category the text will be shown',
  },
  uboDescription6: {
    id: 'onboarding-stakeholders-UBO-description-6',
    defaultMessage: `We are legally obligated to request personal information of the ultimate beneficial owner(s) (UBO) of {company}. This is the owner of the sole proprietorship or the person who exercises effective control.`,
    description:
      'There are seven different descriptions for ubos. Depending on ubo category the text will be shown',
  },
  uboDescription7: {
    id: 'onboarding-stakeholders-UBO-description-7',
    defaultMessage: `We are legally obligated to request all personal information of the ultimate beneficial owner(s) (UBO) of {company}. An UBO is the person who has the ownership over the organization, this includes natural persons who are part of the higher management.`,
    description:
      'There are seven different descriptions for ubos. Depending on ubo category the text will be shown',
  },
  fullName: {
    id: 'onboarding-stakeholders-full-name',
    defaultMessage: 'Name',
  },
  givenNameLabel: {
    id: 'onboarding-stakeholders-first-name',
    defaultMessage: 'First name',
  },
  familyNameLabel: {
    id: 'onboarding-stakeholders-last-name',
    defaultMessage: 'Last name',
  },
  countryOfBirth: {
    id: 'onboarding-stakeholders-country-of-birth',
    defaultMessage: 'Country of birth',
  },
  dateOfBirth: {
    id: 'onboarding-stakeholders-date-of-birth',
    defaultMessage: 'Date of birth',
  },
  nationality: {
    id: 'onboarding-stakeholders-nationality',
    defaultMessage: 'Nationality',
  },
  countryOfResidence: {
    id: 'onboarding-stakeholders-country-of-residence',
    defaultMessage: 'Country of residence',
  },
  pep: {
    id: 'onboarding-stakeholders-pep',
    defaultMessage: 'Politically Exposed Person',
  },
  pepQuestion: {
    id: 'onboarding-stakeholders-pep-question',
    defaultMessage: 'Is this person politically exposed?',
  },
  pepQuestionExplanation: {
    id: 'onboarding-stakeholders-pep-question-explanation',
    defaultMessage:
      'Did or does this person, their close family members, or their business associates, fulfill a prominent public function? Examples would be heads of government, parliament members, ambassadors, and directors of international organizations.',
  },
  pepQuestionNotFilledIn: {
    id: 'onboarding-stakeholders-error-pep-question-row',
    defaultMessage: 'Missing politically exposed person status.{link}',
  },
  pepQuestionNotFilledInLink: {
    id: 'onboarding-stakeholders-error-pep-question-row-link',
    defaultMessage: 'Add status',
  },
  pepRemark: {
    id: 'onboarding-stakeholders-pep-remark',
    defaultMessage: 'Please explain the political activities or how he/she is politically exposed',
  },
  pepRemarkExplanation: {
    id: 'onboarding-stakeholders-pep-remark-explanation',
    defaultMessage:
      'Owners, directors, and senior management of non-state owned businesses and organisations, are not considered politically exposed. Neither are celebrities or low level government officials.',
  },
  uboQuestion: {
    id: 'onboarding-stakeholders-ubo-question',
    defaultMessage: 'Is this person an ultimate beneficial owner?',
  },
  associatesQuestion: {
    id: 'onboarding-stakeholders-associates-question',
    defaultMessage: 'Is this person an associate?',
  },
  yes: {
    id: 'onboarding-stakeholders-yes',
    defaultMessage: 'Yes',
  },
  no: {
    id: 'onboarding-stakeholders-no',
    defaultMessage: 'No',
  },
  ubosErrorMinimalRequirement: {
    id: 'onboarding-stakeholders-ubos-minimal-requirement',
    defaultMessage: 'You need at least one ultimate beneficial owner',
  },
  associatesErrorMinimalRequirement: {
    id: 'onboarding-stakeholders-associates-minimal-requirement',
    defaultMessage: 'You need at least one associate',
  },
  flashMessageErrorSavingStakeholders: {
    id: 'onboarding-stakeholders-error-saving-stakeholders',
    defaultMessage: 'Something went wrong while saving the stakeholders. Please try again.',
  },
  missingRequiredField: {
    id: 'onboarding-stakeholders-row-required-field-missing',
    defaultMessage: 'Missing',
    description: 'This messages will be shown if a field is mandatory but missing',
  },
  stakeholderTooYoungHeader: {
    id: 'onboarding-stakeholders-too-young-header',
    defaultMessage: 'Underage stakeholder(s)',
    description:
      'This messages will be shown if any of the stakeholders are less than 18 years old',
  },
  stakeholderTooYoung: {
    id: 'onboarding-stakeholders-too-young',
    defaultMessage:
      'Mollie is not available for use by minors. All stakeholders of the organization must be 18 years or older to continue.',
    description:
      'This messages will be shown if any of the stakeholders are less than 18 years old',
  },
});

export default messages;
