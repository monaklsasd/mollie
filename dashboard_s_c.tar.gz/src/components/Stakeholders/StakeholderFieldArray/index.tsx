import React from 'react';
import { FormattedMessage, MessageDescriptor } from 'react-intl';

// Components
import AddField from 'components/UI/AddField';
// eslint-disable-next-line
import { FieldProps } from 'formik';
import FormError from 'components/forms/FormError';

// Internals
import StakeholderRow from 'components/Stakeholders/StakeholderRow';
import StakeholderFormModal from 'components/Stakeholders/StakeholderFormModal';
import { MAXIMUM_ENTRIES } from 'components/Stakeholders/constants';
import './styles.scss';

type Props = FieldProps & {
  name: string;
  push: Function;
  replace: Function;
  remove: Function;
};
type State = { isStakeholderModalOpen: boolean };

export class StakeholderFieldArray extends React.Component<Props, State> {
  state = {
    isStakeholderModalOpen: false,
  };

  _getInitialValues = (): any => {
    if (Number.isInteger(this.currentIndex as number)) {
      const { form, name } = this.props;
      return form.values[name][this.currentIndex as number];
    }
  };

  currentIndex: Nullable<number> = null;

  openFormModal = (index?: number) => (): void => {
    this.currentIndex = Number.isInteger(index as number) ? (index as number) : null;
    this.setState({ isStakeholderModalOpen: true });
  };

  closeFormModal = (): void => {
    this.setState({ isStakeholderModalOpen: false });
  };

  getStakeholderFormModalHeadingName = (): React.ReactElement => {
    const { name } = this.props;
    if (name === 'ubos') {
      return (
        <FormattedMessage
          id="stakeholder-field-array-heading-ubo"
          defaultMessage="ultimate beneficial owner"
        />
      );
    }

    return (
      <FormattedMessage
        id="stakeholder-field-array-heading-associates"
        defaultMessage="associate"
      />
    );
  };

  getStakeholderFormModalHeadingMode = (): React.ReactElement => {
    if (Number.isInteger(this.currentIndex as number)) {
      return (
        <FormattedMessage id="stakeholder-field-array-heading-mode-edit" defaultMessage="Edit" />
      );
    }

    return <FormattedMessage id="stakeholder-field-array-heading-mode-add" defaultMessage="Add" />;
  };

  handleConfirm = (values: Record<string, any>): void => {
    const { push, replace } = this.props;

    // if currentIndex is an integer its an update
    if (Number.isInteger(this.currentIndex as number)) {
      replace(this.currentIndex, values);
    }

    if (!Number.isInteger(this.currentIndex as number)) {
      push(values);
    }

    this.closeFormModal();
  };

  handleRemoveRow = (index: number) => (): void => {
    const { remove } = this.props;
    remove(index);
  };

  getMaximumEntries(): Maybe<number> {
    const { form, name } = this.props;

    if (name === 'ubos') {
      return form.values.isUbo ? MAXIMUM_ENTRIES - 1 : MAXIMUM_ENTRIES;
    }

    if (name === 'associates') {
      return form.values.isAssociate ? MAXIMUM_ENTRIES - 1 : MAXIMUM_ENTRIES;
    }
  }

  getRowErrors(index: number): string[] {
    // Get errors for a specific fields on a row
    const { form, name } = this.props;
    const formErrors = (form.errors[name] as unknown) as any[];
    const rowErrors = form.errors && form.errors[name] && formErrors[index];

    // Transform these errors in an Array so we can easily check on a key in the row
    if (rowErrors && typeof rowErrors === 'object') {
      return Object.keys(rowErrors).map(key => key);
    }

    return [];
  }

  render(): React.ReactElement {
    const { form, name } = this.props;

    return (
      <React.Fragment>
        <StakeholderFormModal
          heading={
            <FormattedMessage
              id="stakeholder-field-array-heading"
              defaultMessage="{mode} {name}"
              values={{
                mode: this.getStakeholderFormModalHeadingMode(),
                name: this.getStakeholderFormModalHeadingName(),
              }}
            />
          }
          bodyText={
            <FormattedMessage
              id="stakeholder-field-array-body-text"
              defaultMessage="Please fill out the details of the {name} below and click confirm"
              values={{
                name: this.getStakeholderFormModalHeadingName(),
              }}
            />
          }
          initialValues={this._getInitialValues()}
          isOpen={this.state.isStakeholderModalOpen}
          handleConfirm={this.handleConfirm}
          handleCancel={this.closeFormModal}
        />

        {form.values[name].map((item, index) => (
          <StakeholderRow
            key={index}
            indexKey={index}
            errors={this.getRowErrors(index)}
            values={item}
            onEdit={this.openFormModal(index)}
            onDelete={this.handleRemoveRow(index)}
          />
        ))}

        {/* Set Global Field Array Error */
        typeof form.errors[name] === 'object' &&
          (form.errors[name] as MessageDescriptor)?.id &&
          (form.errors[name] as MessageDescriptor)?.defaultMessage &&
          form.touched[name] && (
            <FormError>
              <FormattedMessage {...(form.errors[name] as MessageDescriptor)} />
            </FormError>
          )}
        {form.values[name].length <= (this.getMaximumEntries() || 0) && (
          <div className="stakeholders-field-array-add-field">
            <AddField
              label={
                <FormattedMessage
                  id="stakeholder-field-array-add-field"
                  defaultMessage="Add {name}"
                  values={{ name: this.getStakeholderFormModalHeadingName() }}
                />
              }
              onClick={this.openFormModal()}
            />
          </div>
        )}
      </React.Fragment>
    );
  }
}

export default StakeholderFieldArray;
