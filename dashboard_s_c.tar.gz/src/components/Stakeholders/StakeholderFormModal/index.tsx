import React from 'react';
import { withFormik, Form, FormikProps } from 'formik';
import { withRouter } from 'react-router-dom';

// Components
import Fieldset from 'components/forms/Fieldset';
import FormModal from 'components/UI/FormModal';

// Internals
import SharedFormFields, {
  validationSharedFormFields,
  initialValuesSharedFormFields,
} from 'components/Stakeholders/SharedFormFields';

// Stylesheets
import './styles.scss';

// Utils
import scrollToError from 'helpers/scrollToError';

type Props = FormikProps<any> & {
  isSubmitting: boolean;
  isValid: boolean;
  errors: any[];
  isOpen: boolean;
  values: any[];
  handleCancel: (...args: any[]) => void;
  submitForm: (...args: any[]) => void;
  bodyText: string;
  heading: string;
  resetForm: (...args: any[]) => void;
  handleConfirm: React.EventHandler<any>;
};

class StakeholderFormModal extends React.Component<Props> {
  componentDidUpdate(prevProps): void {
    const { isSubmitting, isValid, errors, isOpen, resetForm } = this.props;

    if (!prevProps.isOpen && isOpen) {
      resetForm();
    }

    if (isOpen && prevProps.isSubmitting && !isSubmitting && !isValid && this.FormModalRef) {
      scrollToError(errors, this.FormModalRef);
    }
  }

  FormModalRef: Nullable<HTMLElement> = null;

  render(): React.ReactElement {
    const { isOpen, values, handleCancel, heading, submitForm, bodyText } = this.props;

    return (
      <FormModal
        ref={(e: HTMLElement): void => {
          this.FormModalRef = e;
        }}
        isOpen={isOpen}
        handleConfirm={submitForm}
        handleCancel={handleCancel}
        heading={heading}>
        <React.Fragment>
          {bodyText && <p>{bodyText}</p>}
          <Form>
            <Fieldset splitColumns noMargin>
              {(Field): React.ReactElement => (
                <SharedFormFields id="modal" values={values} fieldWrapper={Field} inModal />
              )}
            </Fieldset>
          </Form>
        </React.Fragment>
      </FormModal>
    );
  }
}

export default withRouter<any, any>(
  withFormik<Props, any>({
    enableReinitialize: true,
    handleSubmit: (values, { props }) => {
      props.handleConfirm(values);
    },
    isInitialValid: true,
    validate: validationSharedFormFields,
    mapPropsToValues: props => props.initialValues || initialValuesSharedFormFields,
  })(StakeholderFormModal),
);
