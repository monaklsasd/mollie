import messages from './messages';

export const MAXIMUM_ENTRIES = 10;
export const PEP_REMARK_MAX_LENGTH = 255;

// FieldArray can't pass down props because of performance issues
export const ROW_CLASS_NAME = 'c-table-row-stakeholders';

export const HEADINGS = [
  messages.fullName,
  messages.countryOfBirth,
  messages.dateOfBirth,
  messages.nationality,
  messages.countryOfResidence,
];
