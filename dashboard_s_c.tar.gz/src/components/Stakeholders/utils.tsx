import React from 'react';
import { FormattedMessage } from 'react-intl';

// Constants
import * as constants from './constants';

// Types
import { MessageDescriptor } from 'react-intl';

export const columnHeadings = constants.HEADINGS.map(
  (value: MessageDescriptor): React.ReactNode => <FormattedMessage {...value} />,
)
  // Add empty span because we have 6 columns
  .concat(<span />);

export const getHeaderTable = (
  values: Record<string, any>,
  { arrayKey, optionKey }: { arrayKey: string; optionKey: string },
): Maybe<any[]> => {
  if (values && values[arrayKey] && (!!values[arrayKey].length || values[optionKey] === 'true')) {
    return columnHeadings;
  }
};
