import React from 'react';

// Images
import NL_IDCARD from 'assets/images/identification-examples/nl-idcard.png';
import NL_IDCARD_BLACKEDOUT from 'assets/images/identification-examples/nl-idcard-blacked.png';
import NL_PASSPORT from 'assets/images/identification-examples/nl-passport.jpg';
import NL_PASSPORT_BLACKEDOUT from 'assets/images/identification-examples/nl-passport-blacked.png';

const components = {
  NL_IDCARD,
  NL_IDCARD_BLACKEDOUT,
  NL_PASSPORT,
  NL_PASSPORT_BLACKEDOUT,
};

type Props = {
  blackedOut?: boolean;
  countryCode: string;
  type: string;
};

const IdentificationImage: React.FC<Props> = ({ blackedOut, countryCode, type }) => {
  const componentIndex = `${countryCode}_${type.toUpperCase()}`;
  const componentBlackedOutIndex = `${componentIndex}_BLACKEDOUT`;

  const src = components[componentIndex];
  const srcBlackedout = components[componentBlackedOutIndex];

  if (!src) {
    return null;
  }

  return (
    <div className="identification-example-container">
      <img src={src} alt="" className="identification-example-image" />
      {blackedOut && srcBlackedout && (
        <img className="identification-example-image-overlay" src={srcBlackedout} alt="" />
      )}
    </div>
  );
};

export default IdentificationImage;
