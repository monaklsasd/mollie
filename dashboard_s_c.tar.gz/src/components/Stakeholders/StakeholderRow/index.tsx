import React from 'react';
import { FormattedMessage, FormattedDate, useIntl } from 'react-intl';
import classNames from 'classnames';

// Containers
import Country from 'containers/Country';
import Nationality from 'containers/Nationality';

// Components
import TableRow from 'components/UI/TableRow';
import ButtonGroup from 'components/UI/ButtonGroup';
import Link from 'components/UI/Link';

// Images
import { ReactComponent as IconDelete } from 'assets/icons/delete.svg';
import { ReactComponent as IconEdit } from 'assets/icons/edit.svg';

// Messages
import commonMessages from 'messages';
import messages from '../messages';

// Internals
import * as constants from '../constants';
import './styles.scss';
import { ClassnamesFunction } from 'types/helpers';

type Props = {
  indexKey: string;
  values: Record<string, any>;
  errors?: Array<string>;
  status?: string | React.ReactNode;
  onDelete: React.MouseEventHandler;
  onEdit?: React.MouseEventHandler;
};

const getClassNames: ClassnamesFunction<{ hasError: boolean }> = ({ hasError }) =>
  classNames(
    {
      [`${constants.ROW_CLASS_NAME}--error`]: hasError,
    },
    constants.ROW_CLASS_NAME,
  );

type RequiredFieldProps = {
  value: string;
  hasError: boolean;
};

const RequiredField: React.FC<RequiredFieldProps> = ({ value, children, hasError }) => {
  if (value && hasError) {
    return <span className="c-table-row-stakeholders__required-field-error">{children}</span>;
  }

  if (!value) {
    return (
      <span className="c-table-row-stakeholders__required-field-error">
        <FormattedMessage {...messages.missingRequiredField} />
      </span>
    );
  }

  return <React.Fragment>{children}</React.Fragment>;
};

const StakeholderRow: React.FC<Props> = ({
  indexKey,
  values,
  errors = [],
  status,
  onDelete,
  onEdit,
}) => {
  const intl = useIntl();
  return (
    <TableRow
      key={`TableRow-${indexKey}`}
      className={getClassNames({ hasError: !!errors.length })}
      values={[
        <span>
          <RequiredField
            value={`${values.givenName} ${values.familyName}`}
            hasError={errors.includes('givenName') || errors.includes('familyName')}>
            {`${values.givenName} ${values.familyName}`}
          </RequiredField>
          {status && <span className="c-table-row-stakeholders__status">({status})</span>}
        </span>,
        <span data-header={intl.formatMessage(messages.countryOfBirth)}>
          <RequiredField value={values.countryOfBirth} hasError={errors.includes('countryOfBirth')}>
            <Country code={values.countryOfBirth} />
          </RequiredField>
        </span>,
        <span data-header={intl.formatMessage(messages.dateOfBirth)}>
          <RequiredField value={values.dateOfBirth} hasError={errors.includes('dateOfBirth')}>
            {values.dateOfBirth && <FormattedDate format="short" value={values.dateOfBirth} />}
          </RequiredField>
        </span>,
        <span data-header={intl.formatMessage(messages.nationality)}>
          <RequiredField value={values.nationality} hasError={errors.includes('nationality')}>
            <Nationality code={values.nationality} />
          </RequiredField>
        </span>,
        <span data-header={intl.formatMessage(messages.countryOfResidence)}>
          <RequiredField
            value={values.countryOfResidence}
            hasError={errors.includes('countryOfResidence')}>
            <Country code={values.countryOfResidence} />
          </RequiredField>
        </span>,
        <ButtonGroup compact>
          {onEdit && (
            <Link
              linkStyle="blue"
              className="c-table-row-stakeholders__action"
              onClick={onEdit}
              aria-label={intl.formatMessage(commonMessages.edit)}
              title={intl.formatMessage(commonMessages.edit)}>
              <IconEdit />
            </Link>
          )}
          <Link
            linkStyle="danger"
            className="c-table-row-stakeholders__action"
            onClick={onDelete}
            aria-label={intl.formatMessage(commonMessages.delete)}
            title={intl.formatMessage(commonMessages.delete)}>
            <IconDelete />
          </Link>
        </ButtonGroup>,

        <React.Fragment>
          {errors.includes('isPep') && (
            <div className="c-table-row-stakeholders__required-field-error">
              <FormattedMessage
                {...messages.pepQuestionNotFilledIn}
                values={{
                  link: (
                    <Link
                      className="c-table-row-stakeholders__action"
                      onClick={onEdit}
                      aria-label={intl.formatMessage(commonMessages.edit)}
                      title={intl.formatMessage(commonMessages.edit)}>
                      <FormattedMessage {...messages.pepQuestionNotFilledInLink} />
                    </Link>
                  ),
                }}
              />
            </div>
          )}
          {values.isPep === 'yes' && (
            <div>
              <div className="c-table-row-stakeholders__pep-title">
                <FormattedMessage {...messages.pep} />
              </div>
              <div className="c-table-row-stakeholders__pep-body">{values.pepRemarks}</div>
            </div>
          )}
        </React.Fragment>,
      ]}
    />
  );
};

export default StakeholderRow;
