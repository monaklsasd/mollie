import React from 'react';
import { getIn, FormikValues, FormikErrors } from 'formik';
import moment from 'moment';
import { FormattedMessage } from 'react-intl';

// Components
import ButtonGroup from 'components/UI/ButtonGroup';
import FormikGroup from 'components/forms/FormikGroup';
import InputDate from 'components/forms/InputDate';
import CountrySelect from 'components/forms/CountrySelect';
import NationalitySelect from 'components/forms/NationalitySelect';
import RadioButton from 'components/forms/RadioButton';

// Messages
import formMessages from 'messages/forms';
import messages from './messages';

// Constants
import * as constants from './constants';

// Utils
import isAtOnboardingPage from 'utils/isAtOnboardingPage';

type Values = {
  givenName: string;
  familyName: string;
  countryOfBirth: string;
  dateOfBirth: string;
  nationality: string;
  countryOfResidence: string;
  isPep: string;
  pepRemarks: string;
};

export function validationSharedFormFields<T extends Values = Values>(
  values: T,
  props: Record<string, any>,
): FormikErrors<T> {
  const errors: FormikErrors<T> = {};

  if (!values.givenName) {
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    errors.givenName = formMessages.required;
  }

  if (!values.familyName) {
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    errors.familyName = formMessages.required;
  }

  if (!values.countryOfBirth) {
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    errors.countryOfBirth = formMessages.required;
  }
  if (!values.dateOfBirth) {
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    errors.dateOfBirth = formMessages.required;
  } else if (
    !moment(values.dateOfBirth, 'YYYY-MM-DD', true).isValid() ||
    !moment(values.dateOfBirth, 'YYYY-MM-DD', true).isAfter(moment().subtract(120, 'years'))
  ) {
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    errors.dateOfBirth = formMessages.invalidDate;
  } else if (
    !isAtOnboardingPage(props.location.pathname) &&
    !moment(values.dateOfBirth, 'YYYY-MM-DD', true).isBefore(moment().subtract(18, 'years'))
  ) {
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    errors.dateOfBirth = formMessages.underage;
  }

  if (!values.nationality) {
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    errors.nationality = formMessages.required;
  }

  if (!values.countryOfResidence) {
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    errors.countryOfResidence = formMessages.required;
  }

  if (!values.isPep) {
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    errors.isPep = formMessages.required;
  }

  if (values.isPep === 'yes' && !values.pepRemarks) {
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    errors.pepRemarks = formMessages.required;
  }

  return errors;
}

export const initialValuesSharedFormFields = {
  givenName: '',
  familyName: '',
  countryOfBirth: '',
  dateOfBirth: '',
  nationality: '',
  countryOfResidence: '',
  isPep: undefined,
  pepRemarks: '',
};

const wrapField = (
  Field: React.ComponentType<any>,
  children: React.ReactNode,
  fullWidth?: boolean,
): React.ReactElement => {
  if (Field) {
    return <Field fullWidth={fullWidth}>{children}</Field>;
  }

  return <React.Fragment>{children}</React.Fragment>;
};

const getName = (name: string, prefix?: string): string => (prefix ? `${prefix}.${name}` : name);

type Props = {
  values: FormikValues;
  id: string;
  inModal?: boolean;
  fieldWrapper: React.ComponentType<any>;
  fieldPrefix?: string;
};

const SharedFormFields: React.FC<Props> = ({ values, id, inModal, fieldWrapper, fieldPrefix }) => {
  const isPep = getIn(values, getName('isPep', fieldPrefix));

  return (
    <React.Fragment>
      {wrapField(
        fieldWrapper,
        <FormikGroup
          label={<FormattedMessage {...messages.givenNameLabel} />}
          name={getName('givenName', fieldPrefix)}>
          {(field): React.ReactElement => (
            <input className="l-form-control" type="text" {...field} />
          )}
        </FormikGroup>,
      )}
      {wrapField(
        fieldWrapper,
        <FormikGroup
          label={<FormattedMessage {...messages.familyNameLabel} />}
          name={getName('familyName', fieldPrefix)}>
          {(field): React.ReactElement => (
            <input className="l-form-control" type="text" {...field} />
          )}
        </FormikGroup>,
      )}
      {wrapField(
        fieldWrapper,
        <FormikGroup
          label={<FormattedMessage {...messages.countryOfBirth} />}
          name={getName('countryOfBirth', fieldPrefix)}>
          {(field: Record<string, any>): React.ReactElement => (
            <CountrySelect
              menuPlacement={inModal ? 'top' : undefined}
              // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
              // @ts-ignore
              styles={{
                menuList: (styles: React.CSSProperties): React.CSSProperties => ({
                  ...styles,
                  maxHeight: inModal ? 220 : styles.maxHeight,
                }),
              }}
              inFormikForm
              {...field}
            />
          )}
        </FormikGroup>,
      )}
      {wrapField(
        fieldWrapper,
        <FormikGroup
          label={<FormattedMessage {...messages.dateOfBirth} />}
          name={getName('dateOfBirth', fieldPrefix)}>
          {(field): React.ReactElement => <InputDate {...field} />}
        </FormikGroup>,
      )}
      {wrapField(
        fieldWrapper,
        <FormikGroup
          label={<FormattedMessage {...messages.nationality} />}
          name={getName('nationality', fieldPrefix)}>
          {(field): React.ReactElement => (
            <NationalitySelect
              // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
              // @ts-ignore
              menuPlacement={inModal ? 'top' : undefined}
              styles={{
                menuList: (styles): React.CSSProperties => ({
                  ...styles,
                  maxHeight: inModal ? 220 : styles.maxHeight,
                }),
              }}
              inFormikForm
              {...field}
            />
          )}
        </FormikGroup>,
      )}
      {wrapField(
        fieldWrapper,
        <FormikGroup
          label={<FormattedMessage {...messages.countryOfResidence} />}
          name={getName('countryOfResidence', fieldPrefix)}>
          {(field): React.ReactElement => (
            <CountrySelect
              menuPlacement={inModal ? 'top' : undefined}
              // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
              // @ts-ignore
              styles={{
                menuList: (styles): React.CSSProperties => ({
                  ...styles,
                  maxHeight: inModal ? 220 : styles.maxHeight,
                }),
              }}
              inFormikForm
              {...field}
            />
          )}
        </FormikGroup>,
      )}
      {wrapField(
        fieldWrapper,
        <FormikGroup
          label={<FormattedMessage {...messages.pepQuestion} />}
          name={getName('isPep', fieldPrefix)}>
          {(field): React.ReactElement => (
            <React.Fragment>
              <p>
                <FormattedMessage {...messages.pepQuestionExplanation} />
              </p>
              <ButtonGroup>
                <RadioButton
                  label={<FormattedMessage {...messages.yes} />}
                  {...field}
                  value="yes"
                  id={`${id}-pep-yes`}
                  checked={field.value === 'yes'}
                />
                <RadioButton
                  label={<FormattedMessage {...messages.no} />}
                  {...field}
                  value="no"
                  id={`${id}-pep-no`}
                  checked={field.value === 'no'}
                />
              </ButtonGroup>
            </React.Fragment>
          )}
        </FormikGroup>,
        true,
      )}

      {isPep &&
        isPep === 'yes' &&
        wrapField(
          fieldWrapper,
          <FormikGroup
            label={<FormattedMessage {...messages.pepRemark} />}
            className="c-stakeholder-modal__grid--full-width"
            name={getName('pepRemarks', fieldPrefix)}>
            {(field): React.ReactElement => (
              <React.Fragment>
                <p>
                  <FormattedMessage {...messages.pepRemarkExplanation} />
                </p>
                <textarea
                  maxLength={constants.PEP_REMARK_MAX_LENGTH}
                  className="l-form-control"
                  {...field}
                />
              </React.Fragment>
            )}
          </FormikGroup>,
          true,
        )}
    </React.Fragment>
  );
};

export default SharedFormFields;
