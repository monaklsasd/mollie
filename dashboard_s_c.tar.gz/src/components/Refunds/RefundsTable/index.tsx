import React from 'react';
import { FormattedMessage, useIntl } from 'react-intl';

// Components
import Currency from 'components/UI/Currency';
import IconPaymentMethods, { AcceptedMethods } from 'components/IconPaymentMethods';
import PaymentRefundStatus from 'components/Payment/PaymentRefundStatus';
import GridTable from 'components/UI/GridTable';
import GridTableRow from 'components/UI/GridTable/Row';
import GridTableCell from 'components/UI/GridTable/Cell';

// Helpers
import { displayDate } from 'helpers/date';

// Messages
import { tables } from 'messages';

// Types
import { RefundWithPaymentType } from 'reduxState/modules/refunds/types';

import './styles.scss';

type Props = {
  data: RefundWithPaymentType[];
};

const RefundsTable: React.FC<Props> = ({ data }) => {
  const intl = useIntl();

  return (
    <GridTable
      className="refunds-table"
      columnRow={[
        <GridTableCell name="methods">
          <FormattedMessage {...tables.methods} />
        </GridTableCell>,
        <GridTableCell name="amount" numeric>
          <FormattedMessage {...tables.amount} />
        </GridTableCell>,
        <GridTableCell name="status">
          <FormattedMessage {...tables.status} />
        </GridTableCell>,
        <GridTableCell name="description">
          <FormattedMessage {...tables.details} />
        </GridTableCell>,
        <GridTableCell name="date" numeric>
          <FormattedMessage {...tables.date} />
        </GridTableCell>,
      ]}>
      {data.map(refund => (
        <GridTableRow
          link={{
            to: `/payments/${refund.payment.id}`,
            ariaLabel: intl.formatMessage({
              id: 'refunds-table-expand-row-button-label',
              defaultMessage: 'View payment detail page',
            }),
          }}
          key={refund.id}>
          <GridTableCell name="methods">
            <IconPaymentMethods
              method={refund.payment.method as AcceptedMethods}
              width={30}
              height={30}
            />
          </GridTableCell>
          <GridTableCell name="amount" numeric>
            <Currency {...refund.amount} />
          </GridTableCell>
          <GridTableCell name="status">
            <PaymentRefundStatus status={refund.status as any} />
          </GridTableCell>
          <GridTableCell name="description">{refund.description}</GridTableCell>
          <GridTableCell name="date" numeric>
            {displayDate(refund.refundedDatetime)}
          </GridTableCell>
        </GridTableRow>
      ))}
    </GridTable>
  );
};

export default RefundsTable;
