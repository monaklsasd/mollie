import { createElement } from 'react';

import { ReactComponent as applepay } from 'assets/icons/payment-methods/applepay.svg';
import { ReactComponent as banktransfer } from 'assets/icons/payment-methods/banktransfer.svg';
import { ReactComponent as belfius } from 'assets/icons/payment-methods/belfius.svg';
import { ReactComponent as bitcoin } from 'assets/icons/payment-methods/bitcoin.svg';
import { ReactComponent as creditcard } from 'assets/icons/payment-methods/creditcard.svg';
import { ReactComponent as creditcardAmex } from 'assets/icons/payment-methods/creditcard-amex.svg';
import { ReactComponent as creditcardMaestro } from 'assets/icons/payment-methods/creditcard-maestro.svg';
import { ReactComponent as directdebit } from 'assets/icons/payment-methods/directdebit.svg';
import { ReactComponent as fallback } from 'assets/icons/payment-methods/fallback.svg';
import { ReactComponent as fashioncheque } from 'assets/icons/payment-methods/fashioncheque.svg';
import { ReactComponent as giftcard } from 'assets/icons/payment-methods/giftcard.svg';
import { ReactComponent as ideal } from 'assets/icons/payment-methods/ideal.svg';
import { ReactComponent as inghomepay } from 'assets/icons/payment-methods/inghomepay.svg';
import { ReactComponent as kbc } from 'assets/icons/payment-methods/kbc.svg';
import { ReactComponent as klarna } from 'assets/icons/payment-methods/klarna.svg';
import { ReactComponent as kunstencultuurcadeaukaart } from 'assets/icons/payment-methods/kunstencultuurcadeaukaart.svg';
import { ReactComponent as mistercash } from 'assets/icons/payment-methods/mistercash.svg';
import { ReactComponent as mybank } from 'assets/icons/payment-methods/mybank.svg';
import { ReactComponent as nationalebioscoopbon } from 'assets/icons/payment-methods/nationalebioscoopbon.svg';
import { ReactComponent as nationaleentertainmentcard } from 'assets/icons/payment-methods/nationaleentertainmentcard.svg';
import { ReactComponent as ohmygood } from 'assets/icons/payment-methods/ohmygood.svg';
import { ReactComponent as paypal } from 'assets/icons/payment-methods/paypal.svg';
import { ReactComponent as paysafecard } from 'assets/icons/payment-methods/paysafecard.svg';
import { ReactComponent as podiumcadeaukaart } from 'assets/icons/payment-methods/podiumcadeaukaart.svg';
import { ReactComponent as reiscadeau } from 'assets/icons/payment-methods/reiscadeau.svg';
import { ReactComponent as sofort } from 'assets/icons/payment-methods/sofort.svg';
import { ReactComponent as vvvgiftcard } from 'assets/icons/payment-methods/vvvgiftcard.svg';
import { ReactComponent as webshopgiftcard } from 'assets/icons/payment-methods/webshopgiftcard.svg';
import { ReactComponent as yourgift } from 'assets/icons/payment-methods/yourgift.svg';
import { ReactComponent as eps } from 'assets/icons/payment-methods/eps.svg';
import { ReactComponent as giropay } from 'assets/icons/payment-methods/giropay.svg';
import { ReactComponent as przelewy24 } from 'assets/icons/payment-methods/przelewy24.svg';
import { ReactComponent as travelcheq } from 'assets/icons/payment-methods/travelcheq.svg';
import { ReactComponent as nationalegolfbon } from 'assets/icons/payment-methods/nationalegolfbon.svg';
import { ReactComponent as sportenfitcadeau } from 'assets/icons/payment-methods/sportenfitcadeau.svg';
import { ReactComponent as vvvdinercheque } from 'assets/icons/payment-methods/vvvdinercheque.svg';
import { ReactComponent as vvvlekkerweg } from 'assets/icons/payment-methods/vvvlekkerweg.svg';

// Utils
import GIFTCARD_ISSUERS, { GiftCardIssuers } from 'helpers/giftcardIssuers';
import PAYMENT_METHODS, { PaymentMethod } from 'helpers/paymentMethods';

type Methods = {
  [key in PaymentMethod & GiftCardIssuers]: React.FunctionComponent<React.SVGProps<SVGSVGElement>>;
};

const methods: Partial<Methods> & {
  fallback: React.FunctionComponent<React.SVGProps<SVGSVGElement>>;
} = {
  [GIFTCARD_ISSUERS.FASHIONCHEQUE]: fashioncheque,
  [GIFTCARD_ISSUERS.KUNSTENCULTUURCADEAUKAART]: kunstencultuurcadeaukaart,
  [GIFTCARD_ISSUERS.NATIONALEBIOSCOOPBON]: nationalebioscoopbon,
  [GIFTCARD_ISSUERS.NATIONALEENTERTAINMENTCARD]: nationaleentertainmentcard,
  [GIFTCARD_ISSUERS.NATIONALEGOLFBON]: nationalegolfbon,
  [GIFTCARD_ISSUERS.OHMYGOOD]: ohmygood,
  [GIFTCARD_ISSUERS.PODIUMCADEAUKAART]: podiumcadeaukaart,
  [GIFTCARD_ISSUERS.REISCADEAU]: reiscadeau,
  [GIFTCARD_ISSUERS.SPORTENFITCADEAU]: sportenfitcadeau,
  [GIFTCARD_ISSUERS.TRAVELCHEQ]: travelcheq,
  [GIFTCARD_ISSUERS.VVVDINERCHEQUE]: vvvdinercheque,
  [GIFTCARD_ISSUERS.VVVGIFTCARD]: vvvgiftcard,
  [GIFTCARD_ISSUERS.VVVLEKKERWEG]: vvvlekkerweg,
  [GIFTCARD_ISSUERS.WEBSHOPGIFTCARD]: webshopgiftcard,
  [GIFTCARD_ISSUERS.YOURGIFT]: yourgift,
  [PAYMENT_METHODS.APPLEPAY]: applepay,
  [PAYMENT_METHODS.BANKTRANSFER]: banktransfer,
  [PAYMENT_METHODS.BELFIUS]: belfius,
  [PAYMENT_METHODS.BITCOIN]: bitcoin,
  [PAYMENT_METHODS.CREDITCARD]: creditcard,
  [PAYMENT_METHODS.CREDITCARD_AMEX]: creditcardAmex,
  [PAYMENT_METHODS.CREDITCARD_AMEX_INTRA_EEA]: creditcardAmex,
  [PAYMENT_METHODS.CREDITCARD_CARTE_BANCAIRE]: creditcard,
  [PAYMENT_METHODS.CREDITCARD_DOMESTIC]: creditcard,
  [PAYMENT_METHODS.CREDITCARD_EUROPEAN]: creditcard,
  [PAYMENT_METHODS.CREDITCARD_INTRA_EU_CORPORATE]: creditcard,
  [PAYMENT_METHODS.CREDITCARD_MAESTRO]: creditcardMaestro,
  [PAYMENT_METHODS.CREDITCARD_OTHER]: creditcard,
  [PAYMENT_METHODS.DIRECTDEBIT]: directdebit,
  [PAYMENT_METHODS.GIFTCARD]: giftcard,
  [PAYMENT_METHODS.IDEAL]: ideal,
  [PAYMENT_METHODS.INGHOMEPAY]: inghomepay,
  [PAYMENT_METHODS.KBC]: kbc,
  [PAYMENT_METHODS.KLARNAPAYLATER]: klarna,
  [PAYMENT_METHODS.KLARNASLICEIT]: klarna,
  [PAYMENT_METHODS.MISTERCASH]: mistercash,
  [PAYMENT_METHODS.MYBANK]: mybank,
  [PAYMENT_METHODS.PAYPAL]: paypal,
  [PAYMENT_METHODS.PAYSAFECARD]: paysafecard,
  [PAYMENT_METHODS.SOFORT]: sofort,
  [PAYMENT_METHODS.EPS]: eps,
  [PAYMENT_METHODS.GIROPAY]: giropay,
  [PAYMENT_METHODS.PRZELEWY24]: przelewy24,
  fallback,
};

export type AcceptedMethods = PaymentMethod | GiftCardIssuers;

interface Props extends React.SVGProps<SVGSVGElement> {
  method: AcceptedMethods | 'fallback';
  className?: string;
}

const PaymentMethodsIcon: React.FC<Props> = ({ method, ...rest }) => {
  if (!methods[method]) {
    return createElement(methods.fallback, rest);
  }

  return createElement(methods[method], rest);
};

export default PaymentMethodsIcon;
