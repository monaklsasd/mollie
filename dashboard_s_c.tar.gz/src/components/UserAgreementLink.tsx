import React from 'react';
import { useIntl } from 'react-intl';
import messages from '../messages';

import MollieURL from 'utils/MollieURL';

const getPrettyFromLocale = (locale: string): string => {
  switch (locale) {
    case 'fr-BE':
      return 'be-fr';

    case 'nl-BE':
      return 'be';

    default:
      return locale.slice(0, 2);
  }
};

const getUserAgreementCountryFromCountryCode = (countryCode): string => {
  switch (countryCode) {
    // These have their own
    case 'DE':
    case 'FR':
    case 'NL':
      return countryCode;

    // Rest uses EN
    default:
      return 'EN';
  }
};

interface Props {
  countryCode: string;
}

const UserAgreementLink: React.FC<Props> = ({ countryCode }) => {
  const intl = useIntl();
  return (
    <a
      href={MollieURL.createHref(
        `/terms/?lang=${getPrettyFromLocale(
          intl.locale,
        )}&country=${getUserAgreementCountryFromCountryCode(countryCode)}&redirect_url=${
          window.location.pathname
        }`,
      )}
      target="_blank" // eslint-disable-line react/jsx-no-target-blank
      rel="noopener">
      {intl.formatMessage(messages.userAgreement)}
    </a>
  );
};

export default UserAgreementLink;
