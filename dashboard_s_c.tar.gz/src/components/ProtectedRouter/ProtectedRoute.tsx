import React from 'react';
import { Route, Redirect, RouteComponentProps, match } from 'react-router-dom';

import { checkEveryPermissions } from './checkPermissions';

// Types
import { CheckPermissions } from './checkPermissions';
import { Location } from 'history';
import { AvailablePermissions } from 'helpers/permissions';

export type ProtectedRouteComponentProps = {
  requiredPermissions: AvailablePermissions[];
  grantedPermissions: AvailablePermissions[];
  match: match;
};

interface RouteProps {
  component?: React.ComponentType<ProtectedRouteComponentProps> | React.ComponentType<any>;
  render?: (router: ProtectedRouteComponentProps) => React.ReactNode;
  children?: (router: ProtectedRouteComponentProps) => React.ReactNode;
  path?: string | Array<string>;
  exact?: boolean;
  strict?: boolean;
  location?: Location;
  sensitive?: boolean;
}

export interface ProtectedRouteProps extends RouteProps {
  requiredPermissions: AvailablePermissions[];
  grantedPermissions: AvailablePermissions[];
  checkPermissionsFn?: CheckPermissions;
  redirectTo?: string;
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({
  requiredPermissions,
  grantedPermissions,
  checkPermissionsFn,
  redirectTo,
  component,
  render,
  ...props
}) => (
  <Route
    {...props}
    render={(routeProps: RouteComponentProps): React.ReactNode => {
      // Check if the required permissions are met
      const hasPermissions = (checkPermissionsFn as CheckPermissions)(
        requiredPermissions,
        grantedPermissions,
      );
      // const hasPermissions = checkPermissionsFn(requiredPermissions, grantedPermissions);

      if (!hasPermissions) {
        /*
         * If the required permissions are not met, either redirect (if the "redirectTo" prop is provided)
         * or don't render anything (null)
         */
        return redirectTo ? <Redirect to={redirectTo} /> : null;
      }

      /*
       * Override the Route.render property to make it possible to pass an extended version of
       * the ContextRouter that includes the own "requiredPermissions" and "grantedPermissions"
       * to the underlying component.
       * For this reason, the "component" and "render" props are destructured and not
       * propagated to Route (...props won't contain neither the component nor the render props)
       */
      const renderProps: ProtectedRouteComponentProps = {
        ...routeProps,
        requiredPermissions,
        grantedPermissions,
      };

      if (typeof render === 'function') {
        return render(renderProps);
      }

      return component ? React.createElement(component, renderProps) : null;
    }}
  />
);

ProtectedRoute.defaultProps = {
  checkPermissionsFn: checkEveryPermissions,
};

export default ProtectedRoute;
