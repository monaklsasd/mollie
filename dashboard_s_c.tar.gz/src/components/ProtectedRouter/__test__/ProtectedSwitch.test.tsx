import renderMock from '../__mocks__/renderMock';
import { RouteA, RouteB } from '../__mocks__/Components';
import MockA from '../__mocks__/MockA';

import describeTables from '../__mocks__/describeTables';

describe('ProtectedSwitch', () => {
  describe.each(
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    describeTables,
    '%p with %p permissions',
    (Mock, grantedPermissions, testsTable) => {
      test.each(
        testsTable,
        '%s goes to %s and renders %p',
        (initialEntry, expectedPathname, ExpectedComponent) => {
          const { wrapper, pathname } = renderMock(
            `/${Mock.name}`,
            [initialEntry],
            grantedPermissions,
          )(Mock);

          expect(pathname).toBe(`/${Mock.name}${expectedPathname}`);
          expect(wrapper.find(ExpectedComponent)).toHaveLength(1);
        },
      );
    },
  );

  describe('Passes "grantedPermissions" and "requiredPermissions" to rendered child', () => {
    it('/a passes "grantedPermissions" and "requiredPermissions" to RouteA', () => {
      // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
      // @ts-ignore
      const { wrapper, pathname } = renderMock('/mock-a', ['/a'], ['a', 'b', 'c'])(MockA);

      const renderedRoute = wrapper.find(RouteA);

      expect(pathname).toBe('/mock-a/a');
      expect(renderedRoute).toHaveLength(1);
      expect(renderedRoute.prop('requiredPermissions')).toEqual(['a']);
      expect(renderedRoute.prop('grantedPermissions')).toEqual(['a', 'b', 'c']);
    });

    it('/b passes "grantedPermissions" and "requiredPermissions" to RouteB', () => {
      // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
      // @ts-ignore
      const { wrapper, pathname } = renderMock('/mock-a', ['/b'], ['a', 'b'])(MockA);

      const renderedRoute = wrapper.find(RouteB);

      expect(pathname).toBe('/mock-a/b');
      expect(renderedRoute).toHaveLength(1);
      expect(renderedRoute.prop('requiredPermissions')).toEqual(['b']);
      expect(renderedRoute.prop('grantedPermissions')).toEqual(['a', 'b']);
    });
  });
});
