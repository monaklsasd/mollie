import * as React from 'react';
import { mount } from 'enzyme';
import { MemoryRouter } from 'react-router-dom';

import { ProtectedRoute, checkEveryPermissions } from '../';
import {
  ProtectedRouteComponentProps,
  ProtectedRouteProps,
} from 'components/ProtectedRouter/ProtectedRoute';

type MRP = React.ComponentProps<typeof MemoryRouter>;

type MemoryRouterProps = MRP & {
  children?: React.ReactNode;
};

const Component: React.ComponentType<ProtectedRouteComponentProps> = props => {
  return <div>{props.match.path}</div>;
};

const renderMock = (
  routerProps: MemoryRouterProps,
  protectedRouteProps: ProtectedRouteProps,
): ReturnType<typeof mount> =>
  mount(
    <MemoryRouter {...routerProps}>
      <ProtectedRoute {...protectedRouteProps} />
    </MemoryRouter>,
  );

describe('ProtectedRoute', () => {
  it('passes requiredPermissions and grantedPermission to component via the "component" props', () => {
    const requiredPermissions = ['a'];
    const grantedPermissions = ['a', 'b'];

    const wrapper = renderMock(
      { initialEntries: ['/'] },
      {
        path: '/',
        checkPermissionsFn: checkEveryPermissions,
        component: Component,
        // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
        // @ts-ignore
        requiredPermissions,
        // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
        // @ts-ignore
        grantedPermissions,
      },
    );

    const renderedComponent = wrapper.find(Component);

    expect(renderedComponent).toHaveLength(1);
    expect(renderedComponent.prop('requiredPermissions')).toEqual(requiredPermissions);
    expect(renderedComponent.prop('grantedPermissions')).toEqual(grantedPermissions);
  });

  it('passes requiredPermissions and grantedPermission to component via the "render" props', () => {
    const requiredPermissions = ['a'];
    const grantedPermissions = ['a', 'b'];

    const wrapper = renderMock(
      { initialEntries: ['/'] },
      {
        path: '/',
        checkPermissionsFn: checkEveryPermissions,
        // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
        // @ts-ignore
        requiredPermissions,
        // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
        // @ts-ignore
        grantedPermissions,
        render: renderProps => {
          return <Component {...renderProps} />;
        },
      },
    );

    const renderedComponent = wrapper.find(Component);

    expect(renderedComponent).toHaveLength(1);
    expect(renderedComponent.prop('requiredPermissions')).toEqual(requiredPermissions);
    expect(renderedComponent.prop('grantedPermissions')).toEqual(grantedPermissions);
  });
});
