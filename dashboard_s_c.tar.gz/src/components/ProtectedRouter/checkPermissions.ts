export type CheckPermissions = (
  requiredPermissions: string[],
  grantedPermissions: string[],
) => boolean;

export const checkEveryPermissions: CheckPermissions = (requiredPermissions, grantedPermissions) =>
  requiredPermissions.every(permission => grantedPermissions.includes(permission));

export const checkSomePermissions: CheckPermissions = (requiredPermissions, grantedPermissions) =>
  requiredPermissions.some(permission => grantedPermissions.includes(permission));
