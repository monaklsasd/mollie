import React from 'react';
import { withRouter, Route, Redirect, matchPath, match } from 'react-router-dom';

import ProtectedRoute from './ProtectedRoute';
import { Location } from 'history';
import { AvailablePermissions } from 'helpers/permissions';

type ProtectedSwitchChildren =
  | React.ReactElement<typeof ProtectedRoute>
  | React.ReactElement<typeof Route>
  | React.ReactElement<typeof Redirect>;

export type Props = {
  children: ProtectedSwitchChildren | ProtectedSwitchChildren[];
  location: Location;
  match: match;
};

export const isProtectedRoute = (
  child: ProtectedSwitchChildren & {
    props: {
      requiredPermissions: AvailablePermissions[];
      grantedPermissions: AvailablePermissions[];
    };
  },
): boolean =>
  child.props.requiredPermissions !== undefined || child.props.grantedPermissions !== undefined;

const ProtectedSwitch: React.FC<Props> = props => {
  const {
    location: { pathname },
  } = props;

  const childrenArray: ProtectedSwitchChildren[] = React.Children.toArray(
    props.children,
  ) as ProtectedSwitchChildren[];

  // 1 - Check if route is valid
  const isValidPath = childrenArray.some(child => {
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    const path: Maybe<string> = child.props.path || child.props.from;

    return path ? matchPath(pathname, { ...child.props, path }) : null;
  });

  // 2 - Find out if trying to visit a protected route
  const isProtected = childrenArray.some(child => {
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    if (!isProtectedRoute(child)) {
      return false;
    }

    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    const path: Maybe<string> = child.props.path;

    return !!matchPath(pathname, { ...child.props, path });
  });

  let redirectTo: Nullable<string> = null;

  // 3 - Find matched element
  const matchElement = childrenArray.find(child => {
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    if (!isProtectedRoute(child)) {
      // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
      // @ts-ignore
      const path = child.props.path || child.props.from;
      const match = path ? matchPath(pathname, { ...child.props, path }) : props.match;

      return !!match;
    }

    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    const { path } = child.props;
    const match = matchPath(pathname, { ...child.props, path });
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    const hasPermissions = child.props.checkPermissionsFn(
      // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
      // @ts-ignore
      child.props.requiredPermissions,
      // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
      // @ts-ignore
      child.props.grantedPermissions,
    );

    if (!!match && hasPermissions) {
      redirectTo = null;
      return true;
    }

    if (!redirectTo && hasPermissions && isValidPath && path !== pathname) {
      // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
      // @ts-ignore
      redirectTo = child.props.path;
    }

    return false;
  });

  if (redirectTo && isProtected) {
    return <Redirect to={redirectTo} />;
  }

  return matchElement || null;
};

// eslint-disable-next-line @typescript-eslint/ban-ts-ignore
// @ts-ignore
export default withRouter(ProtectedSwitch);
