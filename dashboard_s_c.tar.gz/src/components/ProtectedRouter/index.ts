import ProtectedSwitch from './ProtectedSwitch';
import ProtectedRoute from './ProtectedRoute';
import { checkEveryPermissions, checkSomePermissions } from './checkPermissions';

export default {
  ProtectedSwitch,
  ProtectedRoute,
  checkEveryPermissions,
  checkSomePermissions,
};

export { ProtectedSwitch, ProtectedRoute, checkEveryPermissions, checkSomePermissions };
