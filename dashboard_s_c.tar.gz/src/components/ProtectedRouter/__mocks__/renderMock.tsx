import React from 'react';
import { MemoryRouter, Route } from 'react-router-dom';
import { mount } from 'enzyme';

// Types
import { RenderMock, RenderMockFunction } from './types';
import { Location } from 'history';

type Props = { location: Location };

const renderMock: RenderMock<Props> = (
  baseName = '/mock-a',
  initialEntries = ['/'],
  grantedPermissions = [],
) => {
  return (Component: React.ComponentType<Props>): ReturnType<RenderMockFunction<Props>> => {
    const wrapper = mount(
      <MemoryRouter initialEntries={initialEntries.map(entry => baseName + entry)}>
        <Route
          path={baseName}
          render={(props): React.ReactElement => (
            // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
            // @ts-ignore
            <Component grantedPermissions={grantedPermissions} {...props} />
          )}
        />
      </MemoryRouter>,
    );

    const { pathname } = wrapper.find(Component).props().location;

    return { wrapper, pathname };
  };
};

export default renderMock;
