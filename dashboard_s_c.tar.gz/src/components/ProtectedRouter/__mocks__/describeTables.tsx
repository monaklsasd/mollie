import { Suite } from './types';

const describeTables: Suite[] = [
  ...require('./MockA').describeTable,
  ...require('./MockB').describeTable,
  ...require('./MockC').describeTable,
  ...require('./MockD').describeTable,
];

export default describeTables;
