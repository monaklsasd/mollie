/* eslint-disable jsx-a11y/heading-has-content */
import React from 'react';

export const RouteA: React.ComponentType<{}> = () => <h1>Route A</h1>;
export const RouteB: React.ComponentType<{}> = () => <h1>RouteB</h1>;
export const NormalRoute: React.ComponentType<{}> = () => <h1>Normal Route</h1>;
export const NotFound: React.ComponentType<{}> = () => <h1>Not Found</h1>;
