import * as React from 'react';
import { Redirect, Route, match } from 'react-router-dom';
import { ProtectedSwitch, ProtectedRoute } from '../index';
import { RouteA, RouteB, NotFound } from './Components';

// Types
import { Suite, MockInnerProps } from './types';

const MockA: React.ComponentType<MockInnerProps & { match: match }> = ({
  grantedPermissions = [],
  ...props
}) => (
  <ProtectedSwitch>
    <ProtectedRoute
      // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
      // @ts-ignore
      requiredPermissions={['a']}
      grantedPermissions={grantedPermissions}
      path={`${props.match.path}/a`}
      component={RouteA}
    />
    <ProtectedRoute
      // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
      // @ts-ignore
      requiredPermissions={['b']}
      grantedPermissions={grantedPermissions}
      path={`${props.match.path}/b`}
      component={RouteB}
    />
    <Redirect from={`${props.match.path}`} exact to={`${props.match.path}/a`} />
    <Route component={NotFound} />
  </ProtectedSwitch>
);

export default MockA;

export const describeTable: Suite[] = [
  [
    MockA,
    [],
    [
      ['/', '/a', NotFound],
      ['/a', '/a', NotFound],
      ['/b', '/b', NotFound],
      ['/c', '/c', NotFound],
    ],
  ],
  [
    MockA,
    ['a'],
    [
      ['/', '/a', RouteA],
      ['/a', '/a', RouteA],
      ['/b', '/a', RouteA],
      ['/c', '/c', NotFound],
    ],
  ],
  [
    MockA,
    ['b'],
    [
      ['/', '/b', RouteB],
      ['/a', '/b', RouteB],
      ['/b', '/b', RouteB],
      ['/c', '/c', NotFound],
    ],
  ],
  [
    MockA,
    ['a', 'b'],
    [
      ['/', '/a', RouteA],
      ['/a', '/a', RouteA],
      ['/b', '/b', RouteB],
      ['/c', '/c', NotFound],
    ],
  ],
];
