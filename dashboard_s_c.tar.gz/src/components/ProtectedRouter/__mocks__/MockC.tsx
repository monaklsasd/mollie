import React from 'react';
import { Redirect, Route, match } from 'react-router-dom';
import { ProtectedSwitch, ProtectedRoute, checkSomePermissions } from '../';
import { RouteA, RouteB, NotFound } from './Components';

// Types
import { Suite, MockInnerProps } from './types';

const MockC: React.ComponentType<MockInnerProps & { match: match }> = ({
  grantedPermissions = [],
  ...props
}) => (
  <ProtectedSwitch>
    <ProtectedRoute
      // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
      // @ts-ignore
      requiredPermissions={['a', 'b']}
      grantedPermissions={grantedPermissions}
      path={`${props.match.path}/a`}
      component={RouteA}
      checkPermissionsFn={checkSomePermissions}
    />
    <ProtectedRoute
      // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
      // @ts-ignore
      requiredPermissions={['b', 'c']}
      grantedPermissions={grantedPermissions}
      path={`${props.match.path}/b`}
      component={RouteB}
      checkPermissionsFn={checkSomePermissions}
    />
    <Redirect from={`${props.match.path}`} exact to={`${props.match.path}/a`} />
    <Route component={NotFound} />
  </ProtectedSwitch>
);

export default MockC;

export const describeTable: Suite[] = [
  [
    MockC,
    [],
    [
      ['/', '/a', NotFound],
      ['/a', '/a', NotFound],
      ['/b', '/b', NotFound],
      ['/c', '/c', NotFound],
    ],
  ],
  [
    MockC,
    ['a'],
    [
      ['/', '/a', RouteA],
      ['/a', '/a', RouteA],
      ['/b', '/a', RouteA],
      ['/c', '/c', NotFound],
    ],
  ],
  [
    MockC,
    ['b'],
    [
      ['/', '/a', RouteA],
      ['/a', '/a', RouteA],
      ['/b', '/b', RouteB],
      ['/c', '/c', NotFound],
    ],
  ],
  [
    MockC,
    ['c'],
    [
      ['/', '/b', RouteB],
      ['/a', '/b', RouteB],
      ['/b', '/b', RouteB],
      ['/c', '/c', NotFound],
    ],
  ],
  [
    MockC,
    ['a', 'c'],
    [
      ['/', '/a', RouteA],
      ['/a', '/a', RouteA],
      ['/b', '/b', RouteB],
      ['/c', '/c', NotFound],
    ],
  ],
];
