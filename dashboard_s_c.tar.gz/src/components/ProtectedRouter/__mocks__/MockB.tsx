import React from 'react';
import { Redirect, Route, match } from 'react-router-dom';
import { ProtectedSwitch, ProtectedRoute } from '../';
import { RouteA, RouteB, NormalRoute, NotFound } from './Components';

// Types
import { Suite, MockInnerProps } from './types';

const MockB: React.ComponentType<MockInnerProps & { match: match }> = ({
  grantedPermissions = [],
  ...props
}) => (
  <ProtectedSwitch>
    <ProtectedRoute
      // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
      // @ts-ignore
      requiredPermissions={['a']}
      grantedPermissions={grantedPermissions}
      path={`${props.match.path}/a`}
      component={RouteA}
    />
    <ProtectedRoute
      // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
      // @ts-ignore
      requiredPermissions={['b']}
      grantedPermissions={grantedPermissions}
      path={`${props.match.path}/b`}
      component={RouteB}
    />
    <Route path={`${props.match.path}/c`} component={NormalRoute} />
    <Redirect from={`${props.match.path}`} exact to={`${props.match.path}/a`} />
    <Route component={NotFound} />
  </ProtectedSwitch>
);

export default MockB;

export const describeTable: Suite[] = [
  [
    MockB,
    [],
    [
      ['/', '/a', NotFound],
      ['/a', '/a', NotFound],
      ['/b', '/b', NotFound],
      ['/c', '/c', NormalRoute],
      ['/d', '/d', NotFound],
    ],
  ],
  [
    MockB,
    ['a'],
    [
      ['/', '/a', RouteA],
      ['/a', '/a', RouteA],
      ['/b', '/a', RouteA],
      ['/c', '/c', NormalRoute],
      ['/d', '/d', NotFound],
    ],
  ],
  [
    MockB,
    ['b'],
    [
      ['/', '/b', RouteB],
      ['/a', '/b', RouteB],
      ['/b', '/b', RouteB],
      ['/c', '/c', NormalRoute],
      ['/d', '/d', NotFound],
    ],
  ],
  [
    MockB,
    ['a', 'b'],
    [
      ['/', '/a', RouteA],
      ['/a', '/a', RouteA],
      ['/b', '/b', RouteB],
      ['/c', '/c', NormalRoute],
      ['/d', '/d', NotFound],
    ],
  ],
];
