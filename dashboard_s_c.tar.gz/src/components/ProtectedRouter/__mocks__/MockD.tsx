import React from 'react';
import { Redirect, Route, match } from 'react-router-dom';
import { ProtectedSwitch, ProtectedRoute } from '../';
import { RouteA, RouteB, NotFound } from './Components';

// Types
import { Suite, MockInnerProps } from './types';

const MockD: React.ComponentType<MockInnerProps & { match: match }> = ({
  grantedPermissions = [],
  ...props
}) => (
  <ProtectedSwitch>
    <ProtectedRoute
      // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
      // @ts-ignore
      requiredPermissions={['a', 'b']}
      grantedPermissions={grantedPermissions}
      path={`${props.match.path}/a`}
      component={RouteA}
    />
    <ProtectedRoute
      // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
      // @ts-ignore
      requiredPermissions={['b']}
      grantedPermissions={grantedPermissions}
      path={`${props.match.path}/b`}
      component={RouteB}
    />
    <Redirect from={`${props.match.path}`} exact to={`${props.match.path}/a`} />
    <Route component={NotFound} />
  </ProtectedSwitch>
);

export default MockD;

export const describeTable: Suite[] = [
  [
    MockD,
    [],
    [
      ['/', '/a', NotFound],
      ['/a', '/a', NotFound],
      ['/b', '/b', NotFound],
      ['/c', '/c', NotFound],
    ],
  ],
  [
    MockD,
    ['a'],
    [
      ['/', '/a', NotFound],
      ['/a', '/a', NotFound],
      ['/b', '/b', NotFound],
      ['/c', '/c', NotFound],
    ],
  ],
  [
    MockD,
    ['b'],
    [
      ['/', '/b', RouteB],
      ['/a', '/b', RouteB],
      ['/b', '/b', RouteB],
      ['/c', '/c', NotFound],
    ],
  ],
  [
    MockD,
    ['a', 'b'],
    [
      ['/', '/a', RouteA],
      ['/a', '/a', RouteA],
      ['/b', '/b', RouteB],
      ['/c', '/c', NotFound],
    ],
  ],
];
