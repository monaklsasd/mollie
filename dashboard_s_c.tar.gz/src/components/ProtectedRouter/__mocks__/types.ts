import React from 'react';

// Types
import { ReactWrapper } from 'enzyme';
import { AvailablePermissions } from 'helpers/permissions';

/**
 * Table of tests to be executed for each Mock
 *
 * - MemoryRoute initial entry
 * - Expected path to be rendered/redirected to by the ProtectedSwitch
 * - Expected component to be rendered by the ProtectedSwitch
 */
export type TestTable<P = any> = [string, string, React.ComponentType<P>];

/**
 * Type describing every Mock suite
 *
 * - Mock component to be used in the test
 * - Permissions granted to the rendered Mock
 * - Table of tests to be executed for the Mock with the given permissions
 */
export type Suite<P = any> = [React.ComponentType<P>, string[], TestTable[]];

export type MockInnerProps = {
  grantedPermissions: AvailablePermissions[];
};

export type RenderMockFunction<T> = (
  Component: React.ComponentType<T>,
) => {
  wrapper: ReactWrapper;
  pathname: string;
};

export type RenderMock<T> = (
  baseName: string,
  initialEntries: string[],
  grantedPermissions: AvailablePermissions[],
) => RenderMockFunction<T>;
