import { DESTINATIONS } from 'services/analytics/constants';

const CATEGORIES = {
  account: {
    category: 'Account',
    destinations: [DESTINATIONS.MP],
  },
};

export const EVENTS = {
  created: {
    event: 'Created',
    ...CATEGORIES.account,
  },
};
