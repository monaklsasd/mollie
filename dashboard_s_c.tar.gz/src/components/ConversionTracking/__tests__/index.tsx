/* eslint-disable @typescript-eslint/camelcase */
import React from 'react';
import ReactTestRenderer from 'react-test-renderer';
import Cookies from 'js-cookie';

import { alias, track, identify, getDistinctId } from 'services/analytics';
import { ConversionTracking } from '../index';
import { EVENTS } from '../tracking';
import { mock_distinct_id } from 'services/analytics/__mocks__';

jest.mock('services/analytics');
jest.mock('js-cookie');

function setupTestRenderer(query?: any): ReturnType<typeof ReactTestRenderer.create> {
  jest.clearAllMocks();

  const props = {
    location: {
      query: {
        ...query,
      },
    },
    history: {
      replace: jest.fn(),
    },
  };
  // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
  // @ts-ignore
  const testRenderer = ReactTestRenderer.create(<ConversionTracking {...props} />);

  // Allow RAF callback to fire
  jest.runAllTimers();

  return testRenderer;
}

describe('<ConversionTracking>', () => {
  const NODE_ENV_ORIG = process.env.NODE_ENV;
  const mollieId = 'afiwm7';
  Cookies.get.mockReturnValue(mollieId);

  // Required for RAF mock to work
  jest.useFakeTimers();
  (global as any).requestAnimationFrame = (callback): void => {
    setTimeout(callback, 0);
  };

  afterAll(() => {
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    process.env.NODE_ENV = NODE_ENV_ORIG;
  });

  describe('when signup parameter is present', () => {
    let testRenderer;

    beforeAll(() => {
      testRenderer = setupTestRenderer({ signup: 1 });
    });

    it('should retrieve mollieId from cookie', () => {
      expect(Cookies.get).toBeCalledWith('mollieId');
    });

    it('should strip signup param from querystring', () => {
      const testInstance = testRenderer.getInstance();
      expect(testInstance.props.history.replace).toHaveBeenCalledWith({ query: {} });
    });

    it('should correctly stitch the session', () => {
      expect(getDistinctId).toHaveBeenCalledTimes(1);
      expect(alias).toHaveBeenCalledWith(mollieId);
      expect(identify).toHaveBeenCalledWith(mock_distinct_id);
      expect(track).toHaveBeenCalledWith(EVENTS.created);
    });
  });

  describe('when signup parameter is not present', () => {
    beforeAll(() => {
      setupTestRenderer();
    });

    it('should call identify only', () => {
      expect(identify).toHaveBeenCalledWith(mollieId);
      expect(alias).not.toHaveBeenCalled();
      expect(track).not.toHaveBeenCalled();
    });
  });

  describe('in production', () => {
    let testRenderer;

    beforeAll(() => {
      // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
      // @ts-ignore
      process.env.NODE_ENV = 'production';
      testRenderer = setupTestRenderer({ signup: 1 });
    });

    it('should render conversion pixels', () => {
      const tree = testRenderer.toJSON();
      expect(tree).toMatchSnapshot();
    });
  });

  describe('outside production', () => {
    let testRenderer;

    beforeAll(() => {
      // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
      // @ts-ignore
      process.env.NODE_ENV = 'development';
      testRenderer = setupTestRenderer({ signup: 1 });
    });

    it('should not render conversion pixels', () => {
      const tree = testRenderer.toJSON();
      expect(tree).toEqual(null);
    });
  });
});
