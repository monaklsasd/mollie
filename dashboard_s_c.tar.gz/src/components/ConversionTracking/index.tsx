import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import { difference, omit } from 'lodash';
import Cookies from 'js-cookie';
import { Location, History } from 'history';

import {
  bingEventPixel,
  facebookEventPixel,
  linkedinConversionPixel,
  googleConversionPixel,
} from 'helpers/domains';
import { alias, identify, track, getDistinctId } from 'services/analytics';
import { LINKEDIN_CONVERSION_IDS, GOOGLE_CONVERSION_IDS } from 'helpers/conversionIds';
import { EVENTS } from './tracking';

/**
 * --------------------------------
 *  On MixPanel Session stitching:
 * --------------------------------
 *
 * When anonymous visitors hit our website:
 *
 * - MixPanel JS lib generates an anonymous, unique identifier and remembers it in a cookie
 *   "mp_mollie" under the distinct_id key.
 *
 * - When we first send data for that user to MixPanel, a new "people profile" is created, with its
 *   "primary key" so to say being the distinct_id. In this case the generated identifier.
 *
 * - We capture their acquisition source (UTM params and/or referral hostname), store it on their
 *   people profile and send a "Campaign Hit" event.
 *
 * However this anonymous profile is fragile; the identifier is tied to a single machine through the cookie.
 *
 * After the visitor signs up we have the ability to use our own unique identifier (from mollie_id cookie)
 * to store events/properties using an ID that's tied to the organisation, regardless of the device.
 * This also allows us to tie frontend events to data sent from the backend.
 *
 * To do this, we alias (point) the new mollie_id to the former anonymous ID, rather than creating a new profile.
 *
 * Aliases in MixPanel work like a lookup table: one profile can have multiple aliases,
 * but an alias can only point to a single profile. This way data can be sent to a profile using
 * any alias or the original profile ID. Since the alias may take a moment to propagate,
 * we identify back to the former anonymous ID to avoid losing data (e.g. the Account Created event).
 *
 * On subsequent visits we forget about the anonymous identifier and continue sending data
 * using the mollie_id by calling mixpanel.identify(mollie_id).
 */

/**
 * - Renders conversion pixels once after signup based on the "signup" parameter in the querystring.
 * - Stitches anonymous sessions to known profiles after signup.
 *
 * Strips the signup parameter after tracking succeeds for cleanliness and to prevent the user
 * from reusing the URL (copy / bookmark).
 *
 * It's not an issue if pixels are fired multiple times for whatever reason;
 * the conversion event is just used to convert a unique marketing journey (once).
 */

interface Props {
  history: History;
  location: Location;
  match: any;
}

interface State {
  shouldTrack: boolean;
}

export class ConversionTracking extends Component<Props, State> {
  constructor(props) {
    super(props);

    const {
      location: { query },
    } = props;

    this.loaded = [];
    this.mollieId = Cookies.get('mollieId');
    this.state = {
      shouldTrack: query.hasOwnProperty('signup'),
    };
    this.pixelUrls = {
      bing: bingEventPixel(EVENTS.created),
      facebook: facebookEventPixel(EVENTS.created),
      linkedin: linkedinConversionPixel(LINKEDIN_CONVERSION_IDS.accountCreated),
      google: googleConversionPixel(GOOGLE_CONVERSION_IDS.accountCreated),
    };
  }

  componentDidMount(): void {
    const {
      location: { query },
      history: { replace },
    } = this.props;

    if (this.state.shouldTrack) {
      // Immediately remove "signup" from the querystring
      // Without RAF history updates but Redux doesn't capture the action
      requestAnimationFrame(() => {
        // @TODO these types aren't working for now. Planning to fix them in:
        // https://mollie.atlassian.net/browse/KYC-1177
        // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
        // @ts-ignore
        replace({
          query: omit(query, 'signup'),
        });
      });

      this.stitchSession();
    } else if (this.mollieId) {
      // Identify each time user renders the dashboard
      identify(this.mollieId);
    }
  }

  shouldComponentUpdate(_nextProps, nextState): boolean {
    return this.state.shouldTrack !== nextState.shouldTrack;
  }

  loaded: Array<any>;
  mollieId: string;
  pixelUrls: { [key: string]: string };

  /**
   * Session stitching: aliases the post-signup mollie_id to the pre-signup anonymous UUID.
   */
  stitchSession(): void {
    const distinctId = getDistinctId();

    // Make sure the UUID is an anonymous pre-signup value: a 54-60 character hash
    if (!distinctId || distinctId.length < 54) {
      return;
    }

    // Alias to the new authenticated mollie_id
    alias(this.mollieId);

    // Identify back to the original anonymous ID to prevent race conditions with aliasing
    identify(distinctId);

    // Track signup event
    track(EVENTS.created);
  }

  /**
   * Callback for each <img> pixel onLoad or onError.
   * We're not concerned about the pixel failing or React's opinion about error codes,
   * we just need to know that the attempt succeeded.
   */
  handlePixelLoaded = key => (): void => {
    this.loaded = [...this.loaded, key];

    // All done: remove the pixels from the DOM on the next render
    if (difference(Object.keys(this.pixelUrls), this.loaded).length === 0) {
      this.setState({
        shouldTrack: false,
      });
    }
  };

  render(): Nullable<React.ReactElement> {
    // Don't render pixels outside production
    if (process.env.NODE_ENV !== 'production') {
      return null;
    }

    if (!this.state.shouldTrack) {
      return null;
    }

    return (
      <div aria-hidden>
        {Object.entries(this.pixelUrls).map(([key, url]) => (
          <img
            key={key}
            src={encodeURI(url)}
            height="0"
            width="0"
            alt=""
            style={{ display: 'none' }}
            onLoad={this.handlePixelLoaded(key)}
            onError={this.handlePixelLoaded(key)}
          />
        ))}
      </div>
    );
  }
}

export default withRouter(ConversionTracking);
