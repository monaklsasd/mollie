import React from 'react';
import classNames from 'classnames';

import './styles.scss';

const getClass = ({ size, className }: Partial<Props>): string =>
  classNames(
    'c-avatar',
    {
      [`c-avatar--${size}`]: size,
    },
    className,
  );

interface Props {
  size?: 'small';
  className?: string;
  seed?: string;
  children?: React.ReactElement | React.ReactElement[];
  backgroundColor?: string;
  fallbackComponent?: React.ReactNode;
}

const Avatar: React.FC<Props> = props => {
  const [failed, setFailed] = React.useState(true);

  let { seed } = props;
  const { fallbackComponent, backgroundColor, children } = props;

  seed = seed || '?';
  const failedBackgroundColor = fallbackComponent ? 'transparent' : backgroundColor || '#FFAA22';

  const style: React.CSSProperties = {
    background: failed ? failedBackgroundColor : '#000',
    textAlign: 'center',
  };

  const childrenWithProps = React.Children.map(children, child =>
    React.cloneElement(child as React.ReactElement, {
      onError: () => setFailed(true),
      onLoad: () => setFailed(false),
      style: { display: failed ? 'none' : 'inline' },
    }),
  );

  return (
    <div className={getClass(props)} style={style}>
      {failed && fallbackComponent}
      {failed && !fallbackComponent && <span className="c-avatar__seed">{seed.substr(0, 1)}</span>}
      <div className="c-avatar__image">{childrenWithProps}</div>
    </div>
  );
};

export default Avatar;
