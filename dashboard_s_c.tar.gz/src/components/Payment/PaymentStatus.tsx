import React from 'react';
import { useIntl, IntlShape } from 'react-intl';
import warning from 'warning';
import { messages, STATUSES } from 'helpers/paymentStatus';

import {
  STATUS_NEUTRAL,
  STATUS_SUCCESS,
  STATUS_PENDING,
  STATUS_ERROR,
  STATUS_INDIFFERENT,
} from 'components/UI/Status';
import StatusBlock from 'components/UI/StatusBlock';

export const getPaymentStatusText = ({
  intl,
  status,
}: {
  intl: IntlShape;
  status: string;
}): string => {
  warning(messages[status], `No translation found for payment status '${status}'.`);

  return messages[status] ? intl.formatMessage(messages[status]) : status;
};

const mapPaymentStatusToStatus = (status: Props['status']): StatusBlockProps['status'] => {
  switch (status) {
    case STATUSES.PAYMENT_STATUS_PAID:
    case STATUSES.PAYMENT_STATUS_PAIDOUT:
      return STATUS_SUCCESS;

    case STATUSES.PAYMENT_STATUS_OPEN:
    case STATUSES.PAYMENT_STATUS_PENDING:
    case STATUSES.PAYMENT_STATUS_AUTHORIZED:
      return STATUS_PENDING;

    case STATUSES.PAYMENT_STATUS_FAILED:
    case STATUSES.PAYMENT_STATUS_CHARGED_BACK:
      return STATUS_ERROR;

    case STATUSES.PAYMENT_STATUS_CANCELLED:
    case STATUSES.PAYMENT_STATUS_EXPIRED:
      return STATUS_INDIFFERENT;

    case STATUSES.PAYMENT_STATUS_PARTIALLY_REFUNDED:
    case STATUSES.PAYMENT_STATUS_REFUNDED:
    default:
      return STATUS_NEUTRAL;
  }
};

type StatusBlockProps = React.ComponentProps<typeof StatusBlock>;

type Status = Props['status'];

type Props = {
  status: string;
};

const PaymentStatus: React.FC<Props> = ({ status }) => {
  const intl = useIntl();
  return (
    <StatusBlock status={mapPaymentStatusToStatus(status)}>
      {getPaymentStatusText({ intl, status })}
    </StatusBlock>
  );
};

export default PaymentStatus;
