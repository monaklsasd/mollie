import { IntlMessages } from './../../types/intl';
import { defineMessages, IntlShape } from 'react-intl';
import warning from 'warning';

const bankFailureReasons: IntlMessages = defineMessages({
  AC01: {
    id: 'payment-bankFailureReason-AC01',
    defaultMessage: 'Account identifier incorrect (i.e. invalid IBAN)',
  },
  AC04: {
    id: 'payment-bankFailureReason-AC04',
    defaultMessage: 'Account closed',
  },
  AC06: {
    id: 'payment-bankFailureReason-AC06',
    defaultMessage: 'Account blocked for Direct Debit',
  },
  AC13: {
    id: 'payment-bankFailureReason-AC13',
    defaultMessage: 'Debtor account is a consumer account',
  },
  AG01: {
    id: 'payment-bankFailureReason-AG01',
    defaultMessage: 'Direct debit forbidden on this account for regulatory reasons',
  },
  AG02: {
    id: 'payment-bankFailureReason-AG02',
    defaultMessage: 'Operation/transaction code incorrect',
  },
  AM04: {
    id: 'payment-bankFailureReason-AM04',
    defaultMessage: 'Insufficient funds',
  },
  AM05: {
    id: 'payment-bankFailureReason-AM05',
    defaultMessage: 'Duplication collection',
  },
  BE01: {
    id: 'payment-bankFailureReason-BE01',
    defaultMessage: 'Debtor’s name does not match with the account holder’s name',
  },
  BE05: {
    id: 'payment-bankFailureReason-BE05',
    defaultMessage: 'Creditor Identifier is missing',
  },
  FF01: {
    id: 'payment-bankFailureReason-FF01',
    defaultMessage: 'Invalid file format',
  },
  MD01: {
    id: 'payment-bankFailureReason-MD01',
    defaultMessage: 'No Mandate',
  },
  MD02: {
    id: 'payment-bankFailureReason-MD02',
    defaultMessage: 'Mandate data missing or incorrect',
  },
  MD06: {
    id: 'payment-bankFailureReason-MD06',
    defaultMessage: 'Return of funds requested by end customer',
  },
  MD07: {
    id: 'payment-bankFailureReason-MD07',
    defaultMessage: 'Debtor deceased',
  },
  MS02: {
    id: 'payment-bankFailureReason-MS02',
    defaultMessage: 'Refusal by the Debtor',
  },
  MS03: {
    id: 'payment-bankFailureReason-MS03',
    defaultMessage: 'Reason not specified',
  },
  RC01: {
    id: 'payment-bankFailureReason-RC01',
    defaultMessage: 'Bank identifier incorrect (i.e. invalid BIC)',
  },
  RR01: {
    id: 'payment-bankFailureReason-RR01',
    defaultMessage: 'Missing debtor account or identification',
  },
  RR02: {
    id: 'payment-bankFailureReason-RR02',
    defaultMessage: 'Missing debtor name or address',
  },
  RR03: {
    id: 'payment-bankFailureReason-RR03',
    defaultMessage: 'Missing creditor name or address',
  },
  RR04: {
    id: 'payment-bankFailureReason-RR04',
    defaultMessage: 'Regulatory Reason',
  },
  SL01: {
    id: 'payment-bankFailureReason-SL01',
    defaultMessage: 'Specific Service offered by the Debtor Bank',
  },
});

export function getBankFailureReasonText(
  intl: IntlShape,
  bankReasonCode: string,
  fallbackText: string,
): string {
  warning(
    bankFailureReasons[bankReasonCode],
    `No bank failure reason found for '${bankReasonCode}'.`,
  );

  return bankFailureReasons[bankReasonCode]
    ? intl.formatMessage(bankFailureReasons[bankReasonCode])
    : fallbackText;
}

export default bankFailureReasons;
