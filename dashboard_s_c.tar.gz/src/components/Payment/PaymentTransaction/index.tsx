import React from 'react';
import { FormattedMessage, useIntl } from 'react-intl';

// Containers
import Country from 'containers/Country';

// Components
import Link from 'components/UI/Link';
import HelpTooltip from 'components/UI/HelpTooltip';
import Currency from 'components/UI/Currency';
import PaymentFailureReason from 'components/Payment/PaymentFailureReason';
import PaymentRoutes from 'components/Payment/PaymentRoutes';
import PaymentStatus from 'components/Payment/PaymentStatus';
import PaymentTransactionDetails from './PaymentTransactionDetails';

// Constants
import PAYMENT_METHODS from 'helpers/paymentMethods';
import { STATUSES } from 'helpers/paymentStatus';

// Utils
import { getCustomerLink } from 'containers/Customers/utils';
import { getOrderLink } from 'containers/Orders/Detail/utils';
import { currencyCanBeConverted } from 'containers/Payment/utils';

// Messages
import commonMessages from 'messages';
import messages from './messages';

// Payment methods specific details
import Bancontact from './Bancontact';
import BankTransfer from './BankTransfer';
import Belfius from './Belfius';
import Bitcoin from './Bitcoin';
import CreditCard from './CreditCard';
import DirectDebit from './DirectDebit';
import Eps from './Eps';
import Giftcard from './Giftcard';
import Giropay from './Giropay';
import Ideal from './Ideal';
import Kbc from './Kbc';
import PayPal from './PayPal';
import Paysafecard from './Paysafecard';
import Sofort from './Sofort';
import RequirePermissions, { Permissions } from 'containers/RequirePermissions';

// Types
import { SettlementType } from 'reduxState/modules/settlements/types';
import { PaymentType } from 'reduxState/modules/payments/types';
import { Amount } from 'reduxState/types';
import { DetailsToRowFunction } from 'components/Payment/PaymentTransaction/types';
import { GiftCardIssuers } from 'helpers/giftcardIssuers';

type Props = {
  payment: PaymentType;
  settlement?: SettlementType;
};

const getAdditionalDetails = (
  transaction: PaymentType['transactions'][0],
  i: number,
): React.ReactNode => {
  // Combine payment method with index to create unique key
  const key = `${transaction.method}-${i}`;

  switch (transaction.method) {
    case PAYMENT_METHODS.MISTERCASH:
      return <Bancontact key={key} {...transaction} />;

    case PAYMENT_METHODS.BANKTRANSFER:
      return <BankTransfer key={key} {...transaction} />;

    case PAYMENT_METHODS.BELFIUS:
      return <Belfius key={key} {...transaction} />;

    case PAYMENT_METHODS.BITCOIN:
      return <Bitcoin key={key} {...transaction} />;

    case PAYMENT_METHODS.CREDITCARD:
      return <CreditCard key={key} {...transaction} />;

    case PAYMENT_METHODS.DIRECTDEBIT:
      return <DirectDebit key={key} {...transaction} />;

    case PAYMENT_METHODS.EPS:
      return <Eps key={key} {...transaction} />;

    case PAYMENT_METHODS.GIFTCARD:
      return <Giftcard key={key} {...transaction} issuer={transaction.issuer as GiftCardIssuers} />;

    case PAYMENT_METHODS.GIROPAY:
      return <Giropay key={key} {...transaction} />;

    case PAYMENT_METHODS.IDEAL:
      return <Ideal key={key} {...transaction} />;

    case PAYMENT_METHODS.KBC:
      return <Kbc key={key} {...transaction} />;

    case PAYMENT_METHODS.PAYPAL:
      return <PayPal key={key} {...transaction} />;

    case PAYMENT_METHODS.PAYSAFECARD:
      return <Paysafecard key={key} {...transaction} />;

    case PAYMENT_METHODS.SOFORT:
      return <Sofort key={key} {...transaction} />;

    default:
      return null;
  }
};

const getAmountRemaining = (payment: PaymentType): number | void => {
  if (!payment.amountRefunded) {
    return;
  }

  if (Number(payment.amountRefunded.value)) {
    return Number(payment.amount.value) - Number(payment.amountRefunded.value);
  }
};

const PaymentTransaction: React.FC<Props> = ({ payment, settlement }) => {
  const intl = useIntl();
  const printableDetails: ReturnType<DetailsToRowFunction<any>> = [
    { label: messages.description, value: payment.description },
    {
      label: messages.amount,
      value: <Currency {...payment.amount} />,
    },
  ];
  const amountRemaining = getAmountRemaining(payment);

  // eslint-disable-next-line no-self-compare
  if (amountRemaining && amountRemaining > 0) {
    printableDetails.push({
      label: messages.amountRemaining,
      value: <Currency value={amountRemaining} currency={payment.amountRemaining?.currency} />,
    });
  }

  if (currencyCanBeConverted(payment)) {
    printableDetails.push({
      label: messages.convertedAmount,
      value: (
        <span>
          <Currency {...payment.convertedAmount} />
          <HelpTooltip
            showOnHover
            ariaLabel={intl.formatMessage(messages.helpTooltipAria)}
            content={<FormattedMessage {...messages.helpTooltip} />}
          />
        </span>
      ),
    });
  }

  if (payment.fees && payment.fees.length > 0) {
    const totalFees: Amount = payment.fees.reduce(
      // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
      // @ts-ignore
      (carry: Amount, fee: { amount: Amount }) => {
        if (carry.currency && fee.amount.currency !== carry.currency) {
          throw new Error('Dashboard does not support fees in multiple currencies');
        }

        return {
          value: (carry.value as number) + Number(fee.amount.value),
          currency: fee.amount.currency,
        };
      },
      { value: 0 },
    );

    printableDetails.push({
      label: messages.fees,
      value: <Currency {...totalFees} />,
    });
  }

  printableDetails.push({
    label: messages.paymentId,
    value: payment.id,
  });

  printableDetails.push({
    label: messages.status,
    value: <PaymentStatus status={payment.status} />,
  });

  if (
    payment.method === PAYMENT_METHODS.CREDITCARD &&
    payment.status === STATUSES.PAYMENT_STATUS_FAILED
  ) {
    printableDetails.push({
      label: messages.failureReason,
      value: <PaymentFailureReason failureReason={payment.failureReason as string} />,
      className: 'u-white-space-normal',
    });
  }

  // Only display link to settlement when settlement is loaded
  if (payment.settlement && settlement) {
    printableDetails.push({
      label: messages.settlement,
      value: (
        <RequirePermissions permissions={[Permissions.SETTLEMENTS_READ]}>
          {(hasSettlementsReadPermissions): React.ReactNode =>
            hasSettlementsReadPermissions ? (
              <Link to={`/administration/settlements/${payment.settlement}`}>
                {settlement.reference}
              </Link>
            ) : (
              settlement.reference
            )
          }
        </RequirePermissions>
      ),
    });
  }

  if (payment.orderId) {
    printableDetails.push({
      label: messages.orderReference,
      value: (
        <RequirePermissions permissions={[Permissions.ORDERS_READ]}>
          {(hasOrdersReadPermissions): React.ReactNode =>
            hasOrdersReadPermissions ? (
              <Link to={getOrderLink({ id: payment.orderId as string })}>{payment.orderId}</Link>
            ) : (
              payment.orderId
            )
          }
        </RequirePermissions>
      ),
    });
  }

  if (payment.customerId) {
    printableDetails.push({
      label: messages.customerReference,
      value: <Link to={getCustomerLink({ id: payment.customerId })}>{payment.customerId}</Link>,
    });
  }

  if (payment.subscriptionId) {
    printableDetails.push({
      label: messages.subscriptionReference,
      value: payment.subscriptionId,
    });
  }

  printableDetails.push.apply(printableDetails, [
    { label: messages.mode, value: payment.mode },
    {
      label: messages.country,
      value: (
        <Country code={payment.countryCode}>
          {(country): React.ReactElement => (
            <span>
              {country ? (
                `${country} (${payment.countryCode})`
              ) : (
                <FormattedMessage {...messages.countryUnknown} />
              )}
            </span>
          )}
        </Country>
      ),
    },
    {
      label: messages.createdAt,
      value: intl.formatMessage(commonMessages.dateTime, {
        date: new Date(payment.createdDatetime),
      }),
    },
  ]);

  if (payment.paidDatetime) {
    printableDetails.push({
      label: messages.paidAt,
      value: intl.formatMessage(commonMessages.dateTime, { date: new Date(payment.paidDatetime) }),
    });
  }

  if (payment.cancelledDatetime) {
    printableDetails.push({
      label: messages.cancelledAt,
      value: intl.formatMessage(commonMessages.dateTime, {
        date: new Date(payment.cancelledDatetime),
      }),
    });
  }

  if (payment.expiredDatetime) {
    printableDetails.push({
      label: messages.expiredAt,
      value: intl.formatMessage(commonMessages.dateTime, {
        date: new Date(payment.expiredDatetime),
      }),
    });
  }

  printableDetails.push.apply(printableDetails, [
    {
      label: messages.paymentUrl,
      value: payment.links && payment.links.paymentUrl ? payment.links.paymentUrl : null,
    },
    {
      label: messages.redirectUrl,
      value: payment.links && payment.links.redirectUrl ? payment.links.redirectUrl : null,
    },
    {
      label: messages.webhookUrl,
      value: payment.links && payment.links.webhookUrl ? payment.links.webhookUrl : null,
    },
    {
      label: messages.metadata,
      value: payment.metadata ? (
        <div className="c-payment-transaction-details__metadata">
          {JSON.stringify(payment.metadata, null, 2)}
        </div>
      ) : null,
    },
    {
      label: messages.applicationFee,
      value: payment.applicationFee ? (
        <span>
          <Currency {...payment.applicationFee.amount} /> -
          <span>{payment.applicationFee.description}</span>
        </span>
      ) : null,
    },
  ]);

  return (
    <React.Fragment>
      <PaymentTransactionDetails
        heading={<FormattedMessage id="payment-paymentdetails" defaultMessage="Paymentdetails" />}
        details={printableDetails}
      />
      {payment.transactions && payment.transactions.map(getAdditionalDetails)}
      {payment.routes && <PaymentRoutes routes={payment.routes} />}
    </React.Fragment>
  );
};

export default PaymentTransaction;
