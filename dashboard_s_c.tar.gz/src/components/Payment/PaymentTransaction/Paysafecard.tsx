import React from 'react';
import { compact, map } from 'lodash';

import PaymentTransactionDetails from './PaymentTransactionDetails';
import messages from './messages';

import {
  PaymentMethodPropsType,
  DetailsToRowFunction,
} from 'components/Payment/PaymentTransaction/types';

type Details = {
  customerReference: string;
};

type Props = PaymentMethodPropsType<Details>;

const detailsToRows: DetailsToRowFunction<Details> = details =>
  compact(
    map(details, (value, label) => {
      switch (label) {
        case 'customerReference':
          return {
            label: messages.customerReference,
            value: details.customerReference,
          };

        default:
          return null;
      }
    }),
  );

const Paysafecard: React.FC<Props> = ({ method, details, amount }) => (
  <PaymentTransactionDetails details={detailsToRows(details)} method={method} amount={amount} />
);

export default Paysafecard;
