import React from 'react';
import { useIntl } from 'react-intl';
import { compact, map } from 'lodash';

import { ReactComponent as ApplePay } from 'assets/icons/wallets/apple-pay.svg';
import PaymentTransactionDetails from './PaymentTransactionDetails';
import PAYMENT_METHODS from 'helpers/paymentMethods';
import messages from './messages';

import {
  PaymentMethodPropsType,
  DetailsToRowFunction,
} from 'components/Payment/PaymentTransaction/types';

type Details = {
  cardAudience: string;
  cardCountry: string;
  cardHolder: string;
  cardLabel: string;
  cardNumber: string;
  cardSecurity: string;
  wallet: string;
};

type Props = PaymentMethodPropsType<Details>;

const detailsToRows: DetailsToRowFunction<Details> = (details, intl) =>
  compact(
    map(details, (value, label) => {
      switch (label) {
        case 'cardAudience':
          return {
            label: messages.cardAudience,
            value: details.cardAudience,
          };

        case 'cardCountry':
          return {
            label: messages.cardCountry,
            value: details.cardCountry,
          };

        case 'cardHolder':
          return {
            label: messages.cardHolder,
            value: details.cardHolder,
          };

        case 'cardLabel':
          if (details.wallet === PAYMENT_METHODS.APPLEPAY) {
            return {
              label: messages.cardLabel,
              value: (
                <React.Fragment>
                  {details.cardLabel} <ApplePay width={32} style={{ marginLeft: '5px' }} />
                </React.Fragment>
              ),
            };
          }
          return {
            label: messages.cardLabel,
            value: details.cardLabel,
          };

        case 'cardNumber':
          return {
            label: messages.cardNumber,
            value: `**** **** **** ${details.cardNumber}`,
            className: 'u-monospace',
          };

        case 'cardSecurity':
          return {
            label: messages.cardSecurity,
            value:
              details.cardSecurity === '3dsecure'
                ? intl?.formatMessage(messages.cardSecurity3dsecure)
                : intl?.formatMessage(messages.cardSecurityNormal),
          };

        default:
          return null;
      }
    }),
  );

const CreditCard: React.FC<Props> = ({ method, details, amount }) => {
  const intl = useIntl();
  return (
    <PaymentTransactionDetails
      details={detailsToRows(details, intl)}
      method={method}
      amount={amount}
    />
  );
};

export default CreditCard;
