import { defineMessages } from 'react-intl';
import { IntlMessages } from 'types/intl';

const messages: IntlMessages = defineMessages({
  helpTooltip: {
    id: 'payment-transaction-help-tooltip',
    defaultMessage: 'This is the converted amount in euros.',
  },
  helpTooltipAria: {
    id: 'payment-transaction-help-tooltip-aria',
    defaultMessage: 'converted amount in euros',
  },
  notAvailable: {
    id: 'not-available',
    defaultMessage: 'Not available',
  },
  amount: {
    id: 'payment-amount',
    defaultMessage: 'Amount',
  },
  convertedAmount: {
    id: 'payment-converted-amount',
    defaultMessage: 'Converted amount',
  },
  fees: {
    id: 'payment-fees',
    defaultMessage: 'Fees',
  },
  description: {
    id: 'payment-description',
    defaultMessage: 'Description',
  },
  paymentId: {
    id: 'payment-paymentId',
    defaultMessage: 'Payment ID',
  },
  status: {
    id: 'payment-status',
    defaultMessage: 'Status',
  },
  failureReason: {
    id: 'payment-failure-reason',
    defaultMessage: 'Failure reason',
  },
  mode: {
    id: 'payment-mode',
    defaultMessage: 'Mode',
  },
  createdAt: {
    id: 'payment-createdAt',
    defaultMessage: 'Created at',
  },
  cancelledAt: {
    id: 'payment-cancelledAt',
    defaultMessage: 'Cancelled at',
  },
  expiredAt: {
    id: 'payment-expiredAt',
    defaultMessage: 'Expired at',
  },
  paidAt: {
    id: 'payment-paidAt',
    defaultMessage: 'Paid at',
  },
  paymentUrl: {
    id: 'payment-paymentUrl',
    defaultMessage: 'Payment URL',
  },
  redirectUrl: {
    id: 'payment-redirectUrl',
    defaultMessage: 'Redirect URL',
  },
  webhookUrl: {
    id: 'payment-webhookUrl',
    defaultMessage: 'Webhook URL',
  },
  metadata: {
    id: 'payment-metadata',
    defaultMessage: 'Metadata',
  },
  applicationFee: {
    id: 'payment-applicationFee',
    defaultMessage: 'Application fee',
  },
  amountRefunded: {
    id: 'payment-amountRefunded',
    defaultMessage: 'Amount refunded',
  },
  consumerName: {
    id: 'payment-consumerName',
    defaultMessage: 'Consumer name',
  },
  consumerEmail: {
    id: 'payment-consumerEmail',
    defaultMessage: 'Consumer email',
  },
  bankAccount: {
    id: 'payment-bankAccount',
    defaultMessage: 'Bank account number',
  },
  bankName: {
    id: 'payment-bankName',
    defaultMessage: 'Name bank',
  },
  consumerAccount: {
    id: 'payment-consumerAccount',
    defaultMessage: 'IBAN',
  },
  bic: {
    id: 'payment-bic',
    defaultMessage: 'BIC',
  },
  cardAudience: {
    id: 'payment-cardAudience',
    defaultMessage: 'Card audience',
  },
  cardCountry: {
    id: 'payment-cardCountry',
    defaultMessage: 'Card country',
  },
  cardHolder: {
    id: 'payment-cardHolder',
    defaultMessage: 'Consumer name',
  },
  cardLabel: {
    id: 'payment-cardLabel',
    defaultMessage: 'Card label',
  },
  cardNumber: {
    id: 'payment-cardNumber',
    defaultMessage: 'Cardnumber',
  },
  feeRegion: {
    id: 'payment-feeRegion',
    defaultMessage: 'Fee region',
  },
  transferReference: {
    id: 'payment-transferReference',
    defaultMessage: 'Transfer reference',
  },
  bitcoinAddress: {
    id: 'payment-bitcoinAddress',
    defaultMessage: 'Bitcoin address',
  },
  bitcoinAmount: {
    id: 'payment-bitcoinAmount',
    defaultMessage: 'Bitcoin amount',
  },
  bitcoinRate: {
    id: 'payment-bitcoinRate',
    defaultMessage: 'Bitcoin rate',
  },
  bitcoinUri: {
    id: 'payment-bitcoinUri',
    defaultMessage: 'Bitcoin URI',
  },
  paypalReference: {
    id: 'payment-paypalReference',
    defaultMessage: 'PayPal reference',
  },
  paypalFee: {
    id: 'payment-paypalFee',
    defaultMessage: 'PayPal fee',
  },
  paypalSellerProtection: {
    id: 'payment-paypalSellerProtection',
    defaultMessage: 'PayPal Seller Protection status',
  },
  customerReference: {
    id: 'payment-customerReference',
    defaultMessage: 'Customer reference',
  },
  cardSecurity: {
    id: 'payment-cardSecurity',
    defaultMessage: 'Security',
  },
  cardSecurity3dsecure: {
    id: 'payment-cardSecurity3dsecure',
    defaultMessage: '3-D Secure',
  },
  cardSecurityNormal: {
    id: 'payment-cardSecurityNormal',
    defaultMessage: 'Normal',
  },
  creditorIdentifier: {
    id: 'payment-creditorIdentifier',
    defaultMessage: 'Creditor identifier',
  },
  dueDate: {
    id: 'payment-dueDate',
    defaultMessage: 'Due date',
  },
  signatureDate: {
    id: 'payment-signatureDate',
    defaultMessage: 'Signature date',
  },
  subscriptionReference: {
    id: 'payment-subscriptionReference',
    defaultMessage: 'Subscription reference',
  },
  bankFailureReason: {
    id: 'payment-bankFailureReason',
    defaultMessage: 'Bank failure reason',
  },
  settlement: {
    id: 'payment-settlement',
    defaultMessage: 'Settlement reference',
  },
  amountRemaining: {
    id: 'payment-amountRemaining',
    defaultMessage: 'Amount remaining',
  },
  country: {
    id: 'payment-country',
    defaultMessage: 'Country',
  },
  countryUnknown: {
    id: 'payment-country-unknown',
    defaultMessage: 'Unknown',
    description: 'Displayed when we couldn’t detect the country based on the consumer’s ip address',
  },
  billingEmail: {
    id: 'payment-billing-email',
    defaultMessage: 'Billing email',
  },
  voucherNumber: {
    id: 'payment-voucher-number',
    defaultMessage: 'Voucher number',
  },
  batchReference: {
    id: 'payment-batch-reference',
    defaultMessage: 'Batch reference',
  },
  fileReference: {
    id: 'payment-file-reference',
    defaultMessage: 'File reference',
  },
  orderReference: {
    id: 'payment-order-reference',
    defaultMessage: 'Order ID',
  },
});

export default messages;
