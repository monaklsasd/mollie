import React from 'react';
import { FormattedMessage } from 'react-intl';

// Components
import IconPaymentMethods, { AcceptedMethods } from 'components/IconPaymentMethods';
import { HelpTooltip } from 'components/UI';
import Currency from 'components/UI/Currency';
import GridTable from 'components/UI/GridTable';
import GridTableRow from 'components/UI/GridTable/Row';
import { GridDescriptionCell } from 'components/UI/GridTable/Cell';

// Utils
import getLocalizedMethodName from 'utils/getLocalizedMethodName';

// Messages
import messages from '../messages';

// Styles
import './styles.scss';

// Types
import { Amount } from 'reduxState/types';
import { DetailsToRowFunction } from 'components/Payment/PaymentTransaction/types';

type Props = {
  amount?: Amount;
  method?: AcceptedMethods;
  heading?: React.ReactNode;
  details: ReturnType<DetailsToRowFunction<any>>;
};

const PaymentTransactionDetails: React.FC<Props> = ({ amount, method, heading, details }) => (
  <GridTable
    title={
      <React.Fragment>
        {method && (
          <IconPaymentMethods
            className="c-payment-transaction-details__icon"
            width={32}
            height={32}
            method={method}
          />
        )}
        {heading || (method && getLocalizedMethodName(method))}
      </React.Fragment>
    }
    listType="description-list"
    className="payment-transaction-table">
    {amount && (
      <GridTableRow>
        <GridDescriptionCell isTerm>
          <FormattedMessage {...messages.amount} />
        </GridDescriptionCell>
        <GridDescriptionCell>
          <Currency {...amount} />
        </GridDescriptionCell>
      </GridTableRow>
    )}
    {details.map(({ label, value, help, className }) => {
      if (value === null) {
        return null;
      }

      return (
        <GridTableRow key={label?.id}>
          <GridDescriptionCell isTerm>
            <FormattedMessage {...label} />
            {help && (
              <FormattedMessage
                id="payment-transaction-details-help-button-label"
                defaultMessage="More info">
                {(msg: string): React.ReactElement => (
                  <HelpTooltip content={help} ariaLabel={msg} />
                )}
              </FormattedMessage>
            )}
          </GridDescriptionCell>
          <GridDescriptionCell className={className}>
            {value ?? <FormattedMessage {...messages.notAvailable} />}
          </GridDescriptionCell>
        </GridTableRow>
      );
    })}
  </GridTable>
);

export default PaymentTransactionDetails;
