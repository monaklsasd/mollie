import React from 'react';
import { compact, map } from 'lodash';

import GiftCardIssuerName from 'containers/GiftCardIssuerName';

import PaymentTransactionDetails from './PaymentTransactionDetails';
import messages from './messages';

import {
  PaymentMethodPropsType,
  DetailsToRowFunction,
} from 'components/Payment/PaymentTransaction/types';

import { GiftCardIssuers } from 'helpers/giftcardIssuers';

type Details = {
  billingEmail: string;
  voucherNumber: string;
};

type Props = PaymentMethodPropsType<Details> & {
  issuer?: GiftCardIssuers;
};

const detailsToRows: DetailsToRowFunction<Details> = details =>
  compact(
    map(details, (value, label) => {
      switch (label) {
        case 'billingEmail':
          return {
            label: messages.billingEmail,
            value: details.billingEmail,
          };

        case 'voucherNumber':
          return {
            label: messages.voucherNumber,
            value: details.voucherNumber,
            className: 'u-monospace',
          };

        default:
          return null;
      }
    }),
  );

const Giftcard: React.FC<Props> = ({ issuer, details, amount }) => (
  <PaymentTransactionDetails
    details={detailsToRows(details)}
    heading={<GiftCardIssuerName issuer={issuer as GiftCardIssuers} />}
    method={issuer}
    amount={amount}
  />
);

export default Giftcard;
