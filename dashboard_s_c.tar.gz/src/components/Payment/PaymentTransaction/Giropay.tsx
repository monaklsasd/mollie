import React from 'react';
import { compact, map } from 'lodash';

import PaymentTransactionDetails from './PaymentTransactionDetails';
import messages from './messages';
import {
  PaymentMethodPropsType,
  DetailsToRowFunction,
} from 'components/Payment/PaymentTransaction/types';

type Details = {
  consumerName: string;
  consumerAccount: string;
  consumerBic: string;
};

type Props = PaymentMethodPropsType<Details>;

const detailsToRows: DetailsToRowFunction<Details> = details =>
  compact(
    map(details, (value, label) => {
      switch (label) {
        case 'consumerName':
          return {
            label: messages.consumerName,
            value: details.consumerName,
          };

        case 'consumerAccount':
          return {
            label: messages.consumerAccount,
            value: details.consumerAccount,
          };

        case 'consumerBic':
          return {
            label: messages.bic,
            value: details.consumerBic,
          };

        default:
          return null;
      }
    }),
  );

const Giropay: React.FC<Props> = ({ details, ...rest }: Props) => (
  <PaymentTransactionDetails details={detailsToRows(details)} {...rest} />
);

export default Giropay;
