import React from 'react';
import { compact, map } from 'lodash';

import PaymentTransactionDetails from './PaymentTransactionDetails';
import messages from './messages';
import {
  PaymentMethodPropsType,
  DetailsToRowFunction,
} from 'components/Payment/PaymentTransaction/types';

type Details = {
  bankAccount: string;
  bankBic: string;
  bankName: string;
  billingEmail: string;
  consumerName: string;
  consumerAccount: string;
  consumerBic: string;
  transferReference: string;
};

type Props = PaymentMethodPropsType<Details>;

const detailsToRows: DetailsToRowFunction<Details> = details =>
  compact(
    map(details, (value, label) => {
      switch (label) {
        case 'bankAccount':
          return {
            label: messages.bankAccount,
            value: details.bankAccount,
          };

        case 'bankName':
          return {
            label: messages.bankName,
            value: details.bankName,
          };

        case 'bankBic':
          return {
            label: messages.bic,
            value: details.bankBic,
          };

        case 'billingEmail':
          return {
            label: messages.billingEmail,
            value: details.billingEmail,
          };

        case 'consumerName':
          return {
            label: messages.consumerName,
            value: details.consumerName,
          };

        case 'consumerAccount':
          return {
            label: messages.consumerAccount,
            value: details.consumerAccount,
          };

        case 'consumerBic':
          return {
            label: messages.bic,
            value: details.consumerBic,
          };

        case 'transferReference':
          return {
            label: messages.transferReference,
            value: details.transferReference,
          };

        default:
          return null;
      }
    }),
  );

const BankTransfer: React.FC<Props> = ({ method, details, amount }) => (
  <PaymentTransactionDetails details={detailsToRows(details)} method={method} amount={amount} />
);

export default BankTransfer;
