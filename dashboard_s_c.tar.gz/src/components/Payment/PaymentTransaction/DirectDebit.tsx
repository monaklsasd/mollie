import React from 'react';
import { FormattedMessage, useIntl, IntlShape } from 'react-intl';
import { compact, map } from 'lodash';

import { getBankFailureReasonText } from 'components/Payment/messages';

import PaymentTransactionDetails from './PaymentTransactionDetails';
import messages from './messages';
import {
  PaymentMethodPropsType,
  DetailsToRowFunction,
} from 'components/Payment/PaymentTransaction/types';

type Details = {
  consumerName: string;
  consumerAccount: string;
  consumerBic: string;
  creditorIdentifier: string;
  signatureDate: string;
  transferReference: string;
  batchReference: string;
  fileReference: string;
  bankName: string;
  bankBic: string;
  bankReason: string;
  bankReasonCode: string;
  dueDate: string;
};

type Props = PaymentMethodPropsType<Details>;

const detailsToRows: DetailsToRowFunction<Details> = (details, intl) =>
  compact(
    map(details, (value, label) => {
      switch (label) {
        case 'bankName':
          return {
            label: messages.bankName,
            value: details.bankName,
          };

        case 'bankBic':
          return {
            label: messages.bic,
            value: details.bankBic,
          };

        case 'bankReason':
          if (!details.bankReason) {
            return {
              value: null,
            };
          }

          return {
            label: messages.bankFailureReason,
            value: `${getBankFailureReasonText(
              intl as IntlShape,
              details.bankReasonCode as string,
              details.bankReason,
            )} (${details.bankReasonCode})`,
          };

        case 'bankReasonCode':
          return {
            value: null,
          };

        case 'consumerName':
          return {
            label: messages.consumerName,
            value: details.consumerName,
          };

        case 'consumerAccount':
          return {
            label: messages.consumerAccount,
            value: details.consumerAccount,
          };

        case 'consumerBic':
          return {
            label: messages.bic,
            value: details.consumerBic,
          };

        case 'creditorIdentifier':
          return {
            label: messages.creditorIdentifier,
            value: details.creditorIdentifier,
          };

        case 'dueDate':
          return {
            label: messages.dueDate,
            value: intl?.formatDate(details.dueDate, { format: 'normal' }),
            help: (
              <FormattedMessage
                id="payment-transactions-details-direct-debit-due-date-explanation"
                defaultMessage="Estimated date the payment is debited from the consumer’s bank account."
                description="Used on the detail page of a SEPA Direct Debit transaction, to explain how the due date is determined."
              />
            ),
          };

        case 'signatureDate':
          return {
            label: messages.signatureDate,
            value: intl?.formatDate(details.signatureDate, { format: 'normal' }),
          };

        case 'transferReference':
          return {
            label: messages.transferReference,
            value: details.transferReference,
          };

        case 'batchReference':
          return {
            label: messages.batchReference,
            value: details.batchReference,
          };

        case 'fileReference':
          return {
            label: messages.fileReference,
            value: details.fileReference,
          };

        default:
          return null;
      }
    }),
  );

const DirectDebit: React.FC<Props> = ({ method, details, amount }) => {
  const intl = useIntl();
  return (
    <PaymentTransactionDetails
      details={detailsToRows(details, intl)}
      method={method}
      amount={amount}
    />
  );
};

export default DirectDebit;
