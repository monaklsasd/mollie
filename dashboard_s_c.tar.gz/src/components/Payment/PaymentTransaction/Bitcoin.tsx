import React from 'react';
import { useIntl } from 'react-intl';
import { compact, map } from 'lodash';

import PaymentTransactionDetails from './PaymentTransactionDetails';
import messages from './messages';
import {
  PaymentMethodPropsType,
  DetailsToRowFunction,
} from 'components/Payment/PaymentTransaction/types';

type Details = {
  bitcoinAddress: string;
  bitcoinAmount: string;
  bitcoinRate: string;
  bitcoinUri: string;
};

type Props = PaymentMethodPropsType<Details>;

const detailsToRows: DetailsToRowFunction<Details> = (details, intl) =>
  compact(
    map(details, (value, label) => {
      switch (label) {
        case 'bitcoinAddress':
          return {
            label: messages.bitcoinAddress,
            value: details.bitcoinAddress,
          };

        case 'bitcoinAmount':
          return {
            label: messages.bitcoinAmount,
            value: details.bitcoinAmount,
          };

        case 'bitcoinRate':
          return {
            label: messages.bitcoinRate,
            value: intl?.formatNumber(Number(details.bitcoinRate), { format: 'EUR' }),
          };

        case 'bitcoinUri':
          return {
            label: messages.bitcoinUri,
            value: details.bitcoinUri,
          };

        default:
          return null;
      }
    }),
  );

const Bitcoin: React.FC<Props> = ({ method, details, amount }) => {
  const intl = useIntl();
  return (
    <PaymentTransactionDetails
      details={detailsToRows(details, intl)}
      method={method}
      amount={amount}
    />
  );
};

export default Bitcoin;
