import React from 'react';
import { compact, map } from 'lodash';

import Currency from 'components/UI/Currency';
import Link from 'components/UI/Link';
import PaymentTransactionDetails from './PaymentTransactionDetails';
import messages from './messages';
import { Amount } from 'reduxState/types';
import {
  PaymentMethodPropsType,
  DetailsToRowFunction,
} from 'components/Payment/PaymentTransaction/types';

type Details = {
  consumerName: string;
  consumerAccount: string;
  paypalReference: string;
  sellerProtection: string;
  paypalFee: Amount;
};

type Props = PaymentMethodPropsType<Details>;

const detailsToRows: DetailsToRowFunction<Details> = details =>
  compact(
    map(details, (value, label) => {
      switch (label) {
        case 'consumerName':
          return {
            label: messages.consumerName,
            value: details.consumerName,
          };

        case 'consumerAccount':
          return {
            label: messages.consumerEmail,
            value: details.consumerAccount,
          };

        case 'paypalReference':
          return {
            label: messages.paypalReference,
            value: (
              <Link href={`https://paypal.com/activity/payment/${details.paypalReference}`}>
                {details.paypalReference}
              </Link>
            ),
          };

        case 'sellerProtection':
          return {
            label: messages.paypalSellerProtection,
            value: details.sellerProtection,
          };

        case 'paypalFee':
          return {
            label: messages.paypalFee,
            value: <Currency {...(details.paypalFee as Amount)} />,
          };

        default:
          return null;
      }
    }),
  );

const PayPal: React.FC<Props> = ({ method, details, amount }) => (
  <PaymentTransactionDetails details={detailsToRows(details)} method={method} amount={amount} />
);

export default PayPal;
