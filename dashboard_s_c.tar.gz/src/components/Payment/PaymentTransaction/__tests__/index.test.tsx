import React from 'react';
import createComponentWithIntl from 'helpers/createComponentWithIntl';
import PAYMENT_METHODS from 'helpers/paymentMethods';
import GIFTCARD_ISSUERS from 'helpers/giftcardIssuers';
import PaymentTransaction from '../index';
import { PaymentType } from 'reduxState/modules/payments/types';
import { AcceptedMethods } from 'components/IconPaymentMethods';

jest.mock('containers/Country');
jest.mock('containers/GiftCardIssuerName', () => 'fashioncheque');

(global as any).Intl.DateTimeFormat = jest.fn(() => ({
  format: (): string => '11/08/2017, 12:00:00',
}));

type Props = {
  payment: PaymentType;
};

describe('<PaymentTransaction>', () => {
  it('renders correctly for a regular payment', () => {
    const props: Props = {
      payment: {
        countryCode: 'NL',
        // @ts-ignore
        method: '',
        details: {},
        refunds: [],
        resource: 'payment',
        id: 'tr_aE6kEwq7HS',
        mode: 'test',
        createdDatetime: '2017-07-11T13:41:58',
        status: 'paid',
        paidDatetime: '2017-07-11T13:42:45',
        amount: { value: '30.02', currency: 'EUR' },
        amountRefunded: { value: '0.00', currency: 'EUR' },
        amountRemaining: { value: '55.02', currency: 'EUR' },
        convertedAmount: { value: '55.02', currency: 'EUR' },
        description: 'test',
        metadata: null,
        transactions: [
          {
            method: PAYMENT_METHODS.IDEAL as AcceptedMethods,
            issuer: 'iDEAL_TEST99',
            amount: { value: '30.02', currency: 'EUR' },
            details: {
              consumerName: 'Ali Baba',
              consumerAccount: 'NL53INGB01234567',
              consumerBic: 'NL2INGB',
            },
          },
        ],
        locale: 'en',
        profileId: 'pfl_D96wnsu869',
        links: {
          redirectUrl: 'http://mollie.dev',
        },
      },
    };

    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    const tree = createComponentWithIntl(<PaymentTransaction {...props} />).toJSON();

    expect(tree).toMatchSnapshot();
  });

  it('renders correctly for a giftcard payment', () => {
    const props: Props = {
      payment: {
        countryCode: 'NL',
        details: {},
        refunds: [],
        resource: 'payment',
        id: 'tr_aE6kEwq7HS',
        mode: 'test',
        createdDatetime: '2017-07-11T13:41:58',
        status: 'paid',
        paidDatetime: '2017-07-11T13:42:45',
        amount: { value: '30.02', currency: 'EUR' },
        amountRefunded: { value: '0.00', currency: 'EUR' },
        amountRemaining: { value: '55.02', currency: 'EUR' },
        convertedAmount: { value: '55.02', currency: 'EUR' },
        description: 'test',
        method: PAYMENT_METHODS.GIFTCARD,
        metadata: null,
        transactions: [
          {
            amount: { value: '30.02', currency: 'EUR' },
            method: PAYMENT_METHODS.GIFTCARD as AcceptedMethods,
            issuer: GIFTCARD_ISSUERS.FASHIONCHEQUE,
            details: {
              billingEmail: 'ali@baba.com',
              voucherNumber: '6000 0000 0000 ****',
            },
          },
        ],
        locale: 'en',
        profileId: 'pfl_D96wnsu869',
        links: {
          redirectUrl: 'http://mollie.dev',
        },
      },
    };

    const tree = createComponentWithIntl(<PaymentTransaction {...props} />).toJSON();

    expect(tree).toMatchSnapshot();
  });

  it('renders correctly for a paypal payment', () => {
    const props: Props = {
      payment: {
        countryCode: 'NL',
        method: PAYMENT_METHODS.PAYPAL,
        details: {},
        refunds: [],
        resource: 'payment',
        id: 'tr_aE6kEwq7HS',
        mode: 'test',
        createdDatetime: '2017-07-11T13:41:58',
        status: 'paid',
        paidDatetime: '2017-07-11T13:42:45',
        amount: { value: '30.02', currency: 'EUR' },
        amountRefunded: { value: '0.00', currency: 'EUR' },
        amountRemaining: { value: '55.02', currency: 'EUR' },
        convertedAmount: { value: '55.02', currency: 'EUR' },
        description: 'test',
        metadata: null,
        transactions: [
          {
            method: PAYMENT_METHODS.PAYPAL as AcceptedMethods,
            amount: { value: '30.02', currency: 'EUR' },
            details: {
              consumerName: 'Ali Baba',
              consumerAccount: 'NL53INGB01234567',
              paypalReference: '3DN896222T349543X',
              paypalPayerId: 'ABC1234567',
              paypalFee: { value: '0.86', currency: 'EUR' },
              sellerProtection: 'Eligible',
            },
          },
        ],
        locale: 'en',
        profileId: 'pfl_D96wnsu869',
        links: {
          redirectUrl: 'http://mollie.dev',
        },
      },
    };

    const tree = createComponentWithIntl(<PaymentTransaction {...props} />).toJSON();

    expect(tree).toMatchSnapshot();
  });

  it('renders correctly for a stacked giftcard payment', () => {
    const props: Props = {
      payment: {
        countryCode: 'NL',
        details: {},
        refunds: [],
        resource: 'payment',
        id: 'tr_aE6kEwq7HS',
        mode: 'test',
        createdDatetime: '2017-07-11T13:41:58',
        status: 'paid',
        paidDatetime: '2017-07-11T13:42:45',
        amount: { value: '55.02', currency: 'EUR' },
        amountRefunded: { value: '0.00', currency: 'EUR' },
        amountRemaining: { value: '55.02', currency: 'EUR' },
        convertedAmount: { value: '55.02', currency: 'EUR' },
        description: 'test',
        method: PAYMENT_METHODS.GIFTCARD,
        metadata: null,
        transactions: [
          {
            method: PAYMENT_METHODS.GIFTCARD as AcceptedMethods,
            amount: { value: '10.00', currency: 'EUR' },
            issuer: GIFTCARD_ISSUERS.FASHIONCHEQUE,
            details: {
              voucher: '1234 5678 1234',
            },
          },
          {
            method: PAYMENT_METHODS.IDEAL as AcceptedMethods,
            amount: { value: '20.00', currency: 'EUR' },
            issuer: 'ideal_TESTNL99',
            details: {
              consumerName: 'Ali Baba',
              consumerAccount: 'NL53INGB01234567',
              consumerBic: 'NL2INGB',
            },
          },
        ],
        locale: 'en',
        profileId: 'pfl_D96wnsu869',
        links: {
          redirectUrl: 'http://mollie.dev',
        },
      },
    };

    const tree = createComponentWithIntl(<PaymentTransaction {...props} />).toJSON();

    expect(tree).toMatchSnapshot();
  });
});
