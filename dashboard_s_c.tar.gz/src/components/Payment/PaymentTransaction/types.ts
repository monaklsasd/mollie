import { Amount } from 'reduxState/types';
import React from 'react';
import { AcceptedMethods } from 'components/IconPaymentMethods';
import { MessageDescriptor, IntlShape } from 'react-intl';

export type PaymentMethodPropsType<
  T extends Record<string, string | Record<string, any>> | any[]
> = {
  amount: Amount;
  method: AcceptedMethods;
  details: Partial<T>;
};

export type DetailsToRowFunction<T> = (
  details: Partial<T>,
  intl?: IntlShape,
) => {
  value: React.ReactNode;
  label?: MessageDescriptor;
  className?: string;
  help?: React.ReactElement;
}[];
