import * as React from 'react';
import { FormattedMessage, FormattedDate } from 'react-intl';

// Components
import Currency from 'components/UI/Currency';
import GridTable from 'components/UI/GridTable';
import GridTableRow from 'components/UI/GridTable/Row';
import GridTableCell from 'components/UI/GridTable/Cell';

// Messages
import { tables } from 'messages';
import messages from './messages';

// Types
import { Route } from 'reduxState/modules/payments/types';

import './styles.scss';

type Props = {
  routes: Route[];
};

const PaymentRoutes: React.FC<Props> = ({ routes }) => {
  if (!routes.length) {
    return null;
  }

  return (
    <GridTable
      title={<FormattedMessage {...messages.title} />}
      className="payment-routes"
      columnRow={[
        <GridTableCell name="destination">
          <FormattedMessage {...messages.destination} />
        </GridTableCell>,
        <GridTableCell name="release-date" numeric>
          <FormattedMessage {...messages.releaseDate} />
        </GridTableCell>,
        <GridTableCell name="amount" numeric>
          <FormattedMessage {...tables.amount} />
        </GridTableCell>,
      ]}>
      {routes.map(route => (
        <GridTableRow key={route.id}>
          <GridTableCell name="destination">{route.destination.balanceId}</GridTableCell>
          <GridTableCell name="release-date" numeric>
            {route.releaseDate ? (
              <FormattedDate format="normal" value={new Date(route.releaseDate)} />
            ) : (
              <span className="u-ghost">
                <FormattedMessage {...messages.noReleaseDate} />
              </span>
            )}
          </GridTableCell>
          <GridTableCell name="amount" numeric>
            <Currency {...route.amount} />
          </GridTableCell>
        </GridTableRow>
      ))}
    </GridTable>
  );
};

export default PaymentRoutes;
