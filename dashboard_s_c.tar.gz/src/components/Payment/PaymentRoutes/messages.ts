import { defineMessages } from 'react-intl';
import { IntlMessages } from 'types/intl';

const messages: IntlMessages = defineMessages({
  title: {
    id: 'payment-routes-heading',
    defaultMessage: 'Routing',
  },
  destination: {
    id: 'payment-routes-destination',
    defaultMessage: 'Destination',
  },
  releaseDate: {
    id: 'payment-routes-label-release-date',
    defaultMessage: 'Release date',
  },
  noReleaseDate: {
    id: 'payment-routes-no-release-date',
    defaultMessage: 'Not applicable',
    description: 'Used when there is no release date set for a payment route',
  },
});

export default messages;
