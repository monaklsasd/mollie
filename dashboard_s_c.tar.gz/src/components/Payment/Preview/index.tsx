import React from 'react';
import { FormattedMessage } from 'react-intl';

// Components
import Currency from 'components/UI/Currency';
import GridTable from 'components/UI/GridTable';
import GridTableRow from 'components/UI/GridTable/Row';
import GridTableCell from 'components/UI/GridTable/Cell';
import StackedIcons, { getPaymentMethod } from 'components/UI/StackedIcons';
import PaymentStatus from 'components/Payment/PaymentStatus';

// Data
import data from './exampleData';

// Messages
import { tables } from 'messages';

import './styles.scss';

const PaymentsPreview: React.FC = () => (
  <React.Fragment>
    <div className="u-overlay-element" />
    <GridTable
      title={<FormattedMessage id="placeholder-preview" defaultMessage="Preview" />}
      className="payments-preview-table"
      columnRow={[
        <GridTableCell name="methods">
          <FormattedMessage {...tables.method} />
        </GridTableCell>,
        <GridTableCell name="amount" numeric>
          <FormattedMessage {...tables.amount} />
        </GridTableCell>,
        <GridTableCell name="status">
          <FormattedMessage {...tables.status} />
        </GridTableCell>,
      ]}>
      {data.map((payment: Record<string, any>) => (
        <GridTableRow key={payment.id}>
          <GridTableCell name="methods">
            <StackedIcons methods={payment.transactions.map(getPaymentMethod)} />
          </GridTableCell>
          <GridTableCell name="amount" numeric>
            <Currency {...payment.amount} />
          </GridTableCell>
          <GridTableCell name="status">
            <PaymentStatus status={payment.status} />
          </GridTableCell>
        </GridTableRow>
      ))}
    </GridTable>
  </React.Fragment>
);

export default PaymentsPreview;
