export default [
  {
    id: 1,
    method: 'ideal',
    amount: { value: '34.50', currency: 'EUR' },
    transactions: [
      {
        method: 'ideal',
      },
    ],
    status: 'paid',
  },
  {
    id: 2,
    amount: { value: '29.99', currency: 'EUR' },
    transactions: [
      {
        method: 'paypal',
      },
    ],
    status: 'expired',
  },
  {
    id: 3,
    amount: { value: '59.75', currency: 'EUR' },
    transactions: [
      {
        method: 'klarnapaylater',
      },
    ],
    status: 'open',
  },
  {
    id: 4,
    amount: { value: '99.50', currency: 'EUR' },
    transactions: [
      {
        method: 'banktransfer',
      },
    ],
    status: 'paid',
  },
  {
    id: 5,
    amount: { value: '59.75', currency: 'EUR' },
    transactions: [
      {
        method: 'klarnapaylater',
      },
    ],
    status: 'paid',
  },
  {
    id: 6,
    amount: { value: '99.50', currency: 'EUR' },
    transactions: [
      {
        method: 'banktransfer',
      },
    ],
    status: 'open',
  },
];
