import React from 'react';
import { FormattedMessage, useIntl } from 'react-intl';
import { uniqBy } from 'lodash';

// Components
import Currency from 'components/UI/Currency';
import Tooltip from 'components/UI/Tooltip';
import StackedIcons, { getPaymentMethod } from 'components/UI/StackedIcons';
import PaymentDetails from 'components/Payment/PaymentDetails';
import PaymentStatus from 'components/Payment/PaymentStatus';
import { STATUSES } from 'helpers/paymentStatus';
import GridTable from 'components/UI/GridTable';
import GridTableRow from 'components/UI/GridTable/Row';
import GridTableCell from 'components/UI/GridTable/Cell';

// Helpers
import { displayDate } from 'helpers/date';

// Messages
import { tables } from 'messages';

// Types
import { PaymentType } from 'reduxState/modules/payments/types';

import './styles.scss';
import { Amount } from 'reduxState/types';

type Props = {
  data: PaymentType[];
};

const renderStatus = (payment: PaymentType): React.ReactElement => {
  const paymentStatus = <PaymentStatus status={payment.status} />;

  if (payment.status === STATUSES.PAYMENT_STATUS_REFUNDED) {
    return (
      <Tooltip
        content={
          <span>
            <FormattedMessage
              id="payments-table-amount-refunded"
              defaultMessage="Amount refunded"
            />
            : <Currency {...(payment.amountRefunded as Amount)} />
          </span>
        }
        showOnHover>
        {paymentStatus}
      </Tooltip>
    );
  }

  return paymentStatus;
};
/* NOTE:
 * The PaymentsPreview component reuses structure and styles from here.
 * If style is extensively changed, the preview component needs to be updated too.
 */
const PaymentsTable: React.FC<Props> = ({ data }) => {
  const intl = useIntl();
  return (
    <GridTable
      className="payments-table"
      columnRow={[
        <GridTableCell name="methods">
          <FormattedMessage {...tables.methods} />
        </GridTableCell>,
        <GridTableCell name="amount" numeric>
          <FormattedMessage {...tables.amount} />
        </GridTableCell>,
        <GridTableCell name="status">
          <FormattedMessage {...tables.status} />
        </GridTableCell>,
        <GridTableCell name="details">
          <FormattedMessage {...tables.details} />
        </GridTableCell>,
        <GridTableCell name="date" numeric>
          <FormattedMessage {...tables.date} />
        </GridTableCell>,
      ]}>
      {data.map((payment: PaymentType) => {
        const methods: React.ComponentProps<typeof StackedIcons>['methods'] = (uniqBy(
          payment.transactions.map(getPaymentMethod),
          'id',
        ) as unknown) as React.ComponentProps<typeof StackedIcons>['methods'];

        return (
          <GridTableRow
            key={payment.id}
            link={{
              to: `/payments/${payment.id}`,
              ariaLabel: intl.formatMessage({
                id: 'payments-table-expand-row-button-label',
                defaultMessage: 'View payment detail page',
              }),
            }}>
            <GridTableCell
              name="methods"
              onTopOfRowLink={
                // Payment method icons
                payment.transactions.length > 1
              }>
              <StackedIcons
                methods={methods}
                showTooltip={payment.transactions.length > 1}
                showFallbackIcon
              />
            </GridTableCell>
            <GridTableCell name="amount" numeric>
              <Currency {...payment.amount} />
            </GridTableCell>
            <GridTableCell
              name="status"
              onTopOfRowLink={payment.status === STATUSES.PAYMENT_STATUS_REFUNDED}>
              {renderStatus(payment)}
            </GridTableCell>
            <GridTableCell name="details">
              <PaymentDetails payment={payment} />
            </GridTableCell>
            <GridTableCell name="date" numeric>
              {displayDate(new Date(payment.createdDatetime))}
            </GridTableCell>
          </GridTableRow>
        );
      })}
    </GridTable>
  );
};

export default PaymentsTable;
