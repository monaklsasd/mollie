import React from 'react';
import { useIntl, IntlShape } from 'react-intl';

import messages from './messages';
import { PAYMENT_FAILURE_REASON_UNKNOWN } from './constants';

type Props = {
  className?: string;
  failureReason: keyof typeof messages;
};

export const getPaymentFailureReasonText = ({
  failureReason,
  intl,
}: Props & { intl: IntlShape }): string => {
  return messages[failureReason]
    ? intl.formatMessage(messages[failureReason])
    : intl.formatMessage(messages[PAYMENT_FAILURE_REASON_UNKNOWN]);
};

const PaymentFailureReason: React.FC<Props> = ({ failureReason }) => {
  const intl = useIntl();
  return <div>{getPaymentFailureReasonText({ intl, failureReason })}</div>;
};

export default PaymentFailureReason;
