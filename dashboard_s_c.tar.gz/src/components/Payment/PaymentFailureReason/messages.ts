import { IntlMessages } from './../../../types/intl';
import { defineMessages } from 'react-intl';

import {
  PAYMENT_FAILURE_REASON_INVALID_CARD_NUMBER,
  PAYMENT_FAILURE_REASON_INVALID_CVV,
  PAYMENT_FAILURE_REASON_INVALID_CARD_HOLDER_NAME,
  PAYMENT_FAILURE_REASON_CARD_EXPIRED,
  PAYMENT_FAILURE_REASON_INVALID_CARD_TYPE,
  PAYMENT_FAILURE_REASON_REFUSED_BY_ISSUER,
  PAYMENT_FAILURE_REASON_INSUFFICIENT_FUNDS,
  PAYMENT_FAILURE_REASON_INACTIVE_CARD,
  PAYMENT_FAILURE_REASON_UNKNOWN,
} from './constants';

const messages: IntlMessages = defineMessages({
  [PAYMENT_FAILURE_REASON_INVALID_CARD_NUMBER]: {
    id: 'payment-failure-reason-invalid-card-number',
    defaultMessage: 'The card number is invalid.',
  },
  [PAYMENT_FAILURE_REASON_INVALID_CVV]: {
    id: 'payment-failure-reason-invalid-cvv',
    defaultMessage: 'The CVV number is invalid.',
  },
  [PAYMENT_FAILURE_REASON_INVALID_CARD_HOLDER_NAME]: {
    id: 'payment-failure-reason-invalid-card-holder-name',
    defaultMessage: 'The card holder name is invalid.',
  },
  [PAYMENT_FAILURE_REASON_CARD_EXPIRED]: {
    id: 'payment-failure-reason-card-expired',
    defaultMessage: 'The used card is expired.',
  },
  [PAYMENT_FAILURE_REASON_INVALID_CARD_TYPE]: {
    id: 'payment-failure-reason-invalid-card-type',
    defaultMessage: 'The card cannot be used for this payment.',
  },
  [PAYMENT_FAILURE_REASON_REFUSED_BY_ISSUER]: {
    id: 'payment-failure-reason-refused-by-issuer',
    defaultMessage: 'The payment is refused by the issuer.',
  },
  [PAYMENT_FAILURE_REASON_INSUFFICIENT_FUNDS]: {
    id: 'payment-failure-reason-insufficient-funds',
    defaultMessage: 'The card has insufficient funds to complete the purchase.',
  },
  [PAYMENT_FAILURE_REASON_INACTIVE_CARD]: {
    id: 'payment-failure-reason-inactive-card',
    defaultMessage:
      'The customer needs to contact their bank to check that the card is working correctly.',
  },
  [PAYMENT_FAILURE_REASON_UNKNOWN]: {
    id: 'payment-failure-reason-unknown',
    defaultMessage:
      'The card has been declined for an unknown reason. The customer should contact their bank for more information.',
  },
});

export default messages;
