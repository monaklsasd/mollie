import React from 'react';
import { head } from 'lodash';

import './styles.scss';
import { PaymentType } from 'reduxState/modules/payments/types';

const getDetailDescription = (details: Props['payment']['details']): string => {
  if (!details) {
    return '';
  }

  if (details.consumerName) {
    return details.consumerName;
  }

  if (details.cardHolder) {
    return details.cardHolder;
  }

  if (details.transferReference) {
    return details.transferReference;
  }

  if (details.customerReference) {
    return details.customerReference;
  }

  if (details.cardNumber) {
    return `**** **** **** ${details.cardNumber}`;
  }

  return '';
};

const PaymentDetails: React.FC<Props> = ({ payment: { description, transactions } }) => {
  const details = (head(transactions)
    ? head(transactions)?.details
    : {}) as Props['payment']['details'];

  return (
    <div className="c-payment-details">
      {description}
      <span className="c-payment-details__add-on">{getDetailDescription(details)}</span>
    </div>
  );
};

interface Props {
  payment: PaymentType<{
    consumerName?: string;
    cardHolder?: string;
    transferReference?: string;
    customerReference?: string;
    cardNumber?: string;
  }>;
}

export default PaymentDetails;
