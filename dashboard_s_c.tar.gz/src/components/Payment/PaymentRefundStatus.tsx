import React from 'react';
import { defineMessages, useIntl, IntlShape } from 'react-intl';
import warning from 'warning';

import StatusBlock from 'components/UI/StatusBlock';
import { STATUS_PENDING, STATUS_NEUTRAL } from 'components/UI/Status';

export const REFUND_STATUS_PENDING = 'pending';
export const REFUND_STATUS_QUEUED = 'queued';
export const REFUND_STATUS_PROCESSING = 'processing';
export const REFUND_STATUS_REFUNDED = 'refunded';

export const STATUSES = [
  REFUND_STATUS_PENDING,
  REFUND_STATUS_QUEUED,
  REFUND_STATUS_PROCESSING,
  REFUND_STATUS_REFUNDED,
];

export const messages = defineMessages({
  [REFUND_STATUS_PENDING]: {
    id: 'refunds-status-pending',
    defaultMessage: 'Pending',
  },
  [REFUND_STATUS_QUEUED]: {
    id: 'refunds-status-queued',
    defaultMessage: 'Queued',
  },
  [REFUND_STATUS_PROCESSING]: {
    id: 'refunds-status-processing',
    defaultMessage: 'Processing',
  },
  [REFUND_STATUS_REFUNDED]: {
    id: 'refunds-status-refunded',
    defaultMessage: 'Refunded',
  },
});

const mapRefundStatusToStatus = (
  status: Props['status'],
): typeof STATUS_PENDING | typeof STATUS_NEUTRAL => {
  switch (status) {
    case REFUND_STATUS_PENDING:
    case REFUND_STATUS_QUEUED:
    case REFUND_STATUS_PROCESSING:
      return STATUS_PENDING;

    case REFUND_STATUS_REFUNDED:
    default:
      return STATUS_NEUTRAL;
  }
};

export const getPaymentRefundStatusText = (intl: IntlShape, status: Props['status']): string => {
  warning(messages[status], `No translation found for payment refund status '${status}'.`);

  return messages[status] ? intl.formatMessage(messages[status]) : status;
};

type Props = {
  className?: string;
  status: keyof typeof messages;
};

const PaymentRefundStatus: React.FC<Props> = ({ status, className = '' }) => {
  const intl = useIntl();
  return (
    <StatusBlock status={mapRefundStatusToStatus(status)} className={className}>
      {getPaymentRefundStatusText(intl, status)}
    </StatusBlock>
  );
};

export default PaymentRefundStatus;
