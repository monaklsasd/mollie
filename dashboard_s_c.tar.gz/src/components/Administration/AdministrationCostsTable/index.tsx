import React from 'react';

import { FormattedMessage, FormattedNumber, useIntl } from 'react-intl';

// Components
import Empty from 'components/UI/Empty';
import Heading from 'components/UI/Heading';
import IconPaymentMethods, { AcceptedMethods } from 'components/IconPaymentMethods';
import Currency from 'components/UI/Currency';
import GridTable from 'components/UI/GridTable';
import { GridTableRow, GridTableRowTotal } from 'components/UI/GridTable/Row';
import GridTableCell from 'components/UI/GridTable/Cell';

// Messages
import { tables } from 'messages';

// Utils
import { translateDescription } from 'containers/Administration/helpers';

// Internals
import methodHasIcon from '../methodHasIcon';
import './styles.scss';

// Types
import { CostItem } from 'reduxState/modules/settlements/types';

interface Props {
  rows: CostItem[];
}

const AdministrationCostsTable: React.FC<Props> = ({ rows }) => {
  const intl = useIntl();

  if (!rows.length) {
    return (
      <div>
        <Heading>
          <FormattedMessage id="balance-costs" defaultMessage="Costs" />
        </Heading>
        <Empty
          compact
          title={<FormattedMessage id="balance-no-costs-found" defaultMessage="No costs found" />}
        />
      </div>
    );
  }

  const totalGrossAmount = rows.reduce((acc, item) => acc + Number(item.amount.gross), 0);

  return (
    <GridTable
      title={<FormattedMessage id="balance-costs" defaultMessage="Costs" />}
      className="administration-costs-table"
      columnRow={[
        <GridTableCell name="methods">
          <FormattedMessage {...tables.method} />
        </GridTableCell>,
        <GridTableCell name="count" numeric>
          <FormattedMessage {...tables.count} />
        </GridTableCell>,
        <GridTableCell name="rate" numeric>
          <FormattedMessage {...tables.rate} />
        </GridTableCell>,
        <GridTableCell name="exclVat" numeric>
          <FormattedMessage {...tables.exclVat} />
        </GridTableCell>,
        <GridTableCell name="amount" numeric>
          <FormattedMessage {...tables.amount} />
        </GridTableCell>,
      ]}>
      {rows.map(item => (
        <GridTableRow key={item.description}>
          <GridTableCell name="methods">
            {methodHasIcon(item.method) && (
              <div className="administration-costs-table__method-icon-description">
                <IconPaymentMethods
                  className="administration-costs-table__icon"
                  method={item.method as AcceptedMethods}
                />
                {translateDescription(intl, item.description)}
              </div>
            )}

            {!methodHasIcon(item.method) && translateDescription(intl, item.description)}
          </GridTableCell>

          <GridTableCell name="count" numeric>
            {item.count}
          </GridTableCell>
          <GridTableCell name="rate" numeric>
            <span>
              {item.rate.fixed && (
                <FormattedNumber
                  value={Number(item.rate.fixed)}
                  minimumFractionDigits={2}
                  maximumFractionDigits={3}
                  format="EUR"
                />
              )}
              {item.rate.fixed && item.rate.percentage && ' + '}
              {item.rate.percentage && (
                <FormattedNumber
                  value={Number(item.rate.percentage) / 100}
                  format="percentage"
                  minimumFractionDigits={0}
                  maximumFractionDigits={2}
                />
              )}
            </span>
          </GridTableCell>
          <GridTableCell name="exclVat" numeric>
            <Currency value={Number(item.amount.net)} />
          </GridTableCell>
          <GridTableCell name="amount" numeric>
            <Currency value={Number(item.amount.gross)} />
          </GridTableCell>
        </GridTableRow>
      ))}

      <GridTableRowTotal>
        <GridTableCell name="label">
          <FormattedMessage {...tables.total} />:
        </GridTableCell>
        <GridTableCell name="total" numeric>
          <Currency value={totalGrossAmount} />
        </GridTableCell>
      </GridTableRowTotal>
    </GridTable>
  );
};

export default AdministrationCostsTable;
