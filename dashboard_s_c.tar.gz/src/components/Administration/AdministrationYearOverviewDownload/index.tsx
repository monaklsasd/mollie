import React, { Component } from 'react';
import { connect } from 'react-redux';
import { FormattedMessage, defineMessages } from 'react-intl';

// Components
import { Button, Tooltip } from 'components/UI';
import InputStepper from 'components/forms/InputStepper';
import { ReactComponent as IconDownload } from 'assets/icons/download.svg';

// Redux
import { getFirstPaymentDateWithFallback } from 'reduxState/modules/organization/selectors';
import { State as ReduxState } from 'reduxState/types';

// Utils
import autobind from 'utils/autobind';
import { getCurrentYearNumber } from 'utils/getCurrentDateNumbers';

// Styles
import './styles.scss';
import MollieURL from 'utils/MollieURL';

const messages = defineMessages({
  increase: {
    id: 'administration-year-picker-next-year',
    defaultMessage: 'Next year',
  },
  decrease: {
    id: 'administration-year-picker-previous-year',
    defaultMessage: 'Previous year',
  },
});

interface Props {
  firstPaymentDate?: Date;
}

interface State {
  year: number;
}

class AdministrationYearOverviewDownload extends Component<Props, State> {
  constructor(props) {
    super(props);

    autobind(this);

    this.state = {
      year: getCurrentYearNumber() - 1,
    };
  }

  onYearChange(year): void {
    this.setState({
      year,
    });
  }

  renderTooltipContents(): React.ReactElement {
    const { firstPaymentDate } = this.props;
    const year = this.state.year;
    const minYear = firstPaymentDate?.getFullYear();

    // You cannot download anything if you registered in the current year
    if (minYear === getCurrentYearNumber()) {
      return (
        <div className="c-administration__tooltip">
          <FormattedMessage
            id="administration-year-picker-overview-not-available-yet"
            defaultMessage="There are no annual reports available yet for your account."
          />
        </div>
      );
    }

    return (
      <div className="c-administration__tooltip">
        <div className="c-administration__form-group">
          <label htmlFor="year-picker" className="u-screenreader-only">
            <FormattedMessage
              id="administration-year-picker-label"
              defaultMessage="Select the year for which to download the annual report"
              description="Not visible in dashboard, just used for screenreaders etc."
            />
          </label>
          <InputStepper
            value={year}
            name="year-picker"
            min={minYear || 1990}
            max={getCurrentYearNumber() - 1}
            decreaseLabel={messages.decrease}
            increaseLabel={messages.increase}
            onChange={this.onYearChange}
            buttonStyle="arrows"
            flexibleWidth
            inputName="year-picker"
          />
        </div>
        <Button
          target="_blank"
          rel="noopener"
          href={MollieURL.createHref(`/annualreport/download/${year}`)}
          primary
          fullWidth>
          <FormattedMessage id="administration-download-annual-report" defaultMessage="Download" />
        </Button>
      </div>
    );
  }

  render(): React.ReactNode {
    return (
      <Tooltip showOnHover={false} noPadding content={this.renderTooltipContents()}>
        <Button>
          <IconDownload width={9} height={12} />
          <FormattedMessage
            id="administration-view-report-downloader"
            defaultMessage="Download annual reports"
          />
        </Button>
      </Tooltip>
    );
  }
}

const mapStateToProps = (state: ReduxState): { [key: string]: any } => ({
  firstPaymentDate: new Date(getFirstPaymentDateWithFallback(state)),
});

export default connect(mapStateToProps)(AdministrationYearOverviewDownload);
