import { IntlMessages } from './../../../types/intl';
import { defineMessages } from 'react-intl';

const messages: IntlMessages = defineMessages({
  availableAmount: {
    id: 'balance-available-amount',
    defaultMessage: 'Available now',
  },
  incomingAmount: {
    id: 'balance-incoming-amount',
    defaultMessage: 'Will be available soon',
  },
  outgoingAmount: {
    id: 'balance-outgoing-amount',
    defaultMessage: 'On the way to your bank',
  },
  incomingExplanation: {
    id: 'balance-incoming-amount-explanation',
    defaultMessage:
      'We received this amount, but can’t pay it out yet, either because your account isn’t fully verified yet, or because the payments have been made by credit card, SOFORT Banking, or SEPA Direct Debit. More information is available in our {link}.',
  },
  incomingExplanationLink: {
    id: 'balance-incoming-amount-hc-link',
    defaultMessage:
      "<a href='https://help.mollie.com/hc/en-us/articles/115003151689' target='_blank' rel='noopener'>Help Center</a>",
  },
  incomingExplanationTooltipLabel: {
    id: 'balance-incoming-amount-explanation-label',
    defaultMessage: 'Why is this?',
    description:
      'This is an ARIA label for the tooltip explaining the incoming balance. It will be visible to people using a screenreader.',
  },
});

export default messages;
