import * as React from 'react';
import { FormattedMessage, FormattedHTMLMessage } from 'react-intl';

// Components
import Currency from 'components/UI/Currency';
import HelpTooltip from 'components/UI/HelpTooltip';

// Types
import { Amount } from 'reduxState/types';

// Internals
import messages from './messages';
import './styles.scss';

type Props = {
  availableAmount: Amount;
  incomingAmount: Amount;
  outgoingAmount: Amount;
};

const CurrentBalance: React.FC<Props> = ({ availableAmount, incomingAmount, outgoingAmount }) => (
  <dl className="current-balance">
    <dt>
      <FormattedMessage {...messages.availableAmount} />
    </dt>
    <dd>
      <span className="current-balance__available-amount">
        <Currency {...availableAmount} />
      </span>
    </dd>
    <dt>
      <FormattedMessage {...messages.incomingAmount} />
      <FormattedMessage {...messages.incomingExplanationTooltipLabel}>
        {(msg: string): React.ReactElement => (
          <HelpTooltip
            ariaLabel={msg}
            content={
              <FormattedMessage
                {...messages.incomingExplanation}
                values={{ link: <FormattedHTMLMessage {...messages.incomingExplanationLink} /> }}
              />
            }
          />
        )}
      </FormattedMessage>
    </dt>
    <dd>
      <Currency {...incomingAmount} />
    </dd>
    <dt>
      <FormattedMessage {...messages.outgoingAmount} />
    </dt>
    <dd>
      <Currency {...outgoingAmount} />
    </dd>
  </dl>
);

export default CurrentBalance;
