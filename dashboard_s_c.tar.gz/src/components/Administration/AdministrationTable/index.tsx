import * as React from 'react';
import { FormattedMessage, FormattedNumber, defineMessages, injectIntl } from 'react-intl';
import { IntlShape } from 'react-intl';

// Components
import Currency from 'components/UI/Currency';
import Empty from 'components/UI/Empty';
import Heading from 'components/UI/Heading';
import IconPaymentMethods, { AcceptedMethods } from 'components/IconPaymentMethods';
import GridTable from 'components/UI/GridTable';
import { GridTableRow, GridTableRowTotal } from 'components/UI/GridTable/Row';
import GridTableCell from 'components/UI/GridTable/Cell';

// Messages
import { tables } from 'messages';

// Utils
import { translateDescription } from 'containers/Administration/helpers';
import { toTitleCase } from 'utils/titleCase';

// Types
import { IntlMessages } from 'types/intl';
import { CostItem } from 'reduxState/modules/settlements/types';

// Internals
import methodHasIcon from '../methodHasIcon';
import './styles.scss';

const messages: IntlMessages = defineMessages({
  revenue: {
    id: 'balance-revenue',
    defaultMessage: 'Revenue',
  },
  deductions: {
    id: 'balance-deductions',
    defaultMessage: 'Deductions',
  },
  noRevenue: {
    id: 'balance-no-revenue',
    defaultMessage: 'No revenue found',
  },
  noDeductions: {
    id: 'balance-no-deductions',
    defaultMessage: 'No deductions found',
  },
});

type Props = {
  rows: CostItem[];
  type: 'revenue' | 'deductions';
  intl: IntlShape;
};

const AdministrationTable: React.FC<Props> = ({ rows, type, intl }) => {
  if (!rows.length) {
    return (
      <div>
        <Heading>
          <FormattedMessage {...messages[type]} />
        </Heading>
        <Empty compact title={<FormattedMessage {...messages[`no${toTitleCase(type)}`]} />} />
      </div>
    );
  }

  const totalGrossAmount = rows.reduce((acc, item) => acc + Number(item.amount.gross), 0);

  return (
    <GridTable
      title={<FormattedMessage {...messages[type]} />}
      className="administration-table"
      columnRow={[
        <GridTableCell name="methods">
          <FormattedMessage {...tables.method} />
        </GridTableCell>,
        <GridTableCell name="count">
          <FormattedMessage {...tables.count} />
        </GridTableCell>,
        <GridTableCell name="amount">
          <FormattedMessage {...tables.amount} />
        </GridTableCell>,
      ]}>
      {rows.map(item => (
        <GridTableRow key={item.description}>
          <GridTableCell name="methods">
            {methodHasIcon(item.method) && (
              <div className="administration-table__method-icon-description">
                <IconPaymentMethods
                  className="administration-costs-table__icon"
                  method={item.method as AcceptedMethods}
                />
                {translateDescription(intl, item.description)}
              </div>
            )}
            {!methodHasIcon(item.method) && translateDescription(intl, item.description)}
          </GridTableCell>
          <GridTableCell name="count">{item.count}</GridTableCell>
          <GridTableCell name="amount">
            <FormattedNumber value={Number(item.amount.gross)} format="EUR" />
          </GridTableCell>
        </GridTableRow>
      ))}
      <GridTableRowTotal>
        <GridTableCell name="label">
          <FormattedMessage {...tables.total} />:
        </GridTableCell>
        <GridTableCell name="total">
          <Currency value={totalGrossAmount} />
        </GridTableCell>
      </GridTableRowTotal>
    </GridTable>
  );
};

export default injectIntl(AdministrationTable);
