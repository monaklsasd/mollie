const methodHasIcon = (method: string): boolean =>
  !!(method && method !== 'refund' && method !== 'chargeback' && method !== 'kickback');

export default methodHasIcon;
