import React from 'react';
import warning from 'warning';
import { useIntl } from 'react-intl';

// Types
import { OrderStatusType } from 'reduxState/modules/orders/types';
import { IntlShape } from 'react-intl';

// Statuses
import {
  STATUS_NEUTRAL,
  STATUS_SUCCESS,
  STATUS_PENDING,
  STATUS_INDIFFERENT,
} from 'components/UI/Status';
import StatusBlock from 'components/UI/StatusBlock';

import { STATUSES, messages } from 'helpers/orderStatus';

type StatusProps = {
  status: OrderStatusType;
  className?: string;
};

export const getOrderStatusText = ({
  status,
  intl,
}: {
  status: StatusProps['status'];
  intl: IntlShape;
}): string => {
  warning(messages[status], `No translation found for payment status '${status}'.`);

  return messages[status] ? intl.formatMessage(messages[status]) : status;
};

const mapOrderStatusToStatus = (
  status: StatusProps['status'],
): React.ComponentProps<typeof StatusBlock>['status'] => {
  switch (status) {
    case STATUSES.ORDER_STATUS_COMPLETED:
      return STATUS_SUCCESS;

    case STATUSES.ORDER_STATUS_AUTHORIZED:
    case STATUSES.ORDER_STATUS_SHIPPING:
    case STATUSES.ORDER_STATUS_PAID:
    case STATUSES.ORDER_STATUS_PENDING:
      return STATUS_PENDING;

    case STATUSES.ORDER_STATUS_CREATED:
    case STATUSES.ORDER_STATUS_CANCELED:
      return STATUS_INDIFFERENT;

    default:
      return STATUS_NEUTRAL;
  }
};

const OrderStatus: React.FC<StatusProps> = ({ status, className }) => {
  const intl = useIntl();
  return (
    <StatusBlock status={mapOrderStatusToStatus(status)} className={className}>
      {getOrderStatusText({ intl, status })}
    </StatusBlock>
  );
};

export default OrderStatus;
