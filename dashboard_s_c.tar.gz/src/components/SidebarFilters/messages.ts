import { IntlMessages } from './../../types/intl';
import { defineMessages } from 'react-intl';

const messages: IntlMessages = defineMessages({
  closeLabel: {
    id: 'transactions-filters-close-label',
    defaultMessage: 'Close filters',
    description: 'Not visible in the interface, only for screenreaders.',
  },
  mobileCloseLabel: {
    id: 'transactions-filters-backdrop-close-label',
    defaultMessage: 'Close filters',
  },
  filters: {
    id: 'transactions-filters-mobile-heading',
    defaultMessage: 'Filters',
  },
  mobileReset: {
    id: 'transactions-filters-mobile-reset',
    defaultMessage: 'Reset',
  },
  reset: {
    id: 'transactions-filters-reset-button',
    defaultMessage: 'Reset',
  },
  filter: {
    id: 'transactions-filters-filter-button',
    defaultMessage: 'Filter',
  },
});

export default messages;
