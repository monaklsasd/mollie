import React from 'react';
import CSSTransitionGroup from 'react-transition-group/CSSTransitionGroup';
import { FormattedMessage } from 'react-intl';
import { injectIntl } from 'react-intl';
import classNames from 'classnames';
import { Link } from 'react-router-dom';

// Components
import Heading from 'components/UI/Heading';
import Button from 'components/UI/Button';
import ButtonGroup from 'components/UI/ButtonGroup';

// Icons
import { ReactComponent as IconClose } from 'assets/icons/close.svg';

// Internals
import messages from './messages';

// Types
import { IntlShape } from 'react-intl';

// Stylesheets
import './styles.scss';
import { ClassnamesFunction } from 'types/helpers';
import { Location } from 'history';

type ButtonProps = React.ComponentProps<typeof Button>;

type Props = {
  intl: IntlShape;
  filtersAreVisible: boolean;
  closeFilters: (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
  className?: string;
  showResetButton: boolean;
  resetRoute: string | Location;
  children?: React.ReactNode;
};

const getClass: ClassnamesFunction<Props> = ({ className }) =>
  classNames('sidebar-filters', className);

const SidebarFilters: React.FC<Props> = ({
  filtersAreVisible,
  children,
  closeFilters,
  intl,
  className,
  showResetButton,
  resetRoute,
}) => (
  <CSSTransitionGroup
    transitionName="sidebar-filters--transition"
    transitionEnterTimeout={350}
    transitionLeaveTimeout={350}>
    {filtersAreVisible && (
      <button key="button" onClick={closeFilters} className="sidebar-filters__backdrop">
        <FormattedMessage {...messages.mobileCloseLabel} />
      </button>
    )}
    {filtersAreVisible && (
      <aside className={getClass({ className })}>
        <header className="sidebar-filters__header">
          <Heading type="h3">
            <FormattedMessage {...messages.filters} />
          </Heading>
          <button
            onClick={closeFilters}
            aria-label={intl.formatMessage(messages.closeLabel)}
            className="sidebar-filters__close">
            <IconClose />
          </button>
          {showResetButton && (
            <Link className="sidebar-filters__mobile-reset" to={resetRoute}>
              <FormattedMessage {...messages.mobileReset} />
            </Link>
          )}
        </header>
        <div className="sidebar-filters__body">
          {children}
          <ButtonGroup className="sidebar-filters__controls">
            <Button onClick={closeFilters} primary className="sidebar-filters__show-results">
              <FormattedMessage {...messages.filter} />
            </Button>

            {showResetButton && (
              <Button className="sidebar-filters__reset" to={resetRoute}>
                <FormattedMessage {...messages.reset} />
              </Button>
            )}
          </ButtonGroup>
        </div>
      </aside>
    )}
  </CSSTransitionGroup>
);

export default injectIntl(SidebarFilters);
