import React from 'react';
import Status from 'components/UI/Status';
import { FormattedMessage } from 'react-intl';
import { BankAccountStatus as Statusses } from 'reduxState/modules/bankAccounts/types';

interface Props {
  status: Statusses;
}
/**
 * For all possible statuses see application/classes/api/transformer/internal/customer/bankaccount.php
 */
const getStatusMessage = (
  status: Props['status'],
): Nullable<React.ReactElement<typeof FormattedMessage>> => {
  switch (status) {
    case 'failed':
      return <FormattedMessage id="bank-account-status-failed" defaultMessage="Failed" />;
    case 'new':
      return <FormattedMessage id="bank-account-status-new" defaultMessage="New" />;
    case 'pending':
      return <FormattedMessage id="bank-account-status-pending" defaultMessage="Pending" />;
    case 'pending-queue':
      return (
        <FormattedMessage
          id="bank-account-status-pending-queue"
          defaultMessage="Will be verified later (currently no action required)"
          description="Displayed when the bank account has status NAME_MISMATCH and the merchant is not yet queued for review by Support."
        />
      );
    case 'verified':
      return <FormattedMessage id="bank-account-status-verified" defaultMessage="Verified" />;
    case 'verification-failed':
      return (
        <FormattedMessage
          id="bank-account-status-verification-failed"
          defaultMessage="Verification failed"
        />
      );
    case 'verification-iban-mismatch':
      return (
        <FormattedMessage
          id="bank-account-status-iban-mismatch"
          defaultMessage="Verification failed: IBAN mismatch"
        />
      );
    case 'queued-for-review':
      return (
        <FormattedMessage
          id="bank-account-status-queued-for-review"
          defaultMessage="Will be verified in approx. one business day"
          description="Displayed when bank account has status NAME_MISMATCH and the merchant is queued for review by Support."
        />
      );
    case 'verification-cancelled':
      return (
        <FormattedMessage
          id="bank-account-status-cancelled"
          defaultMessage="Verification cancelled"
        />
      );
    case 'verification-info-pending':
      return <FormattedMessage id="bank-account-status-info-pending" defaultMessage="Pending" />;
    default:
      return null;
  }
};

const getStatus = (status: Props['status']): React.ComponentProps<typeof Status>['state'] => {
  switch (status) {
    // Pending
    case 'pending':
    case 'pending-queue':
    case 'queued-for-review':
    case 'verification-info-pending':
      return 'pending';
    // Neutral
    case 'new':
      return 'neutral';
    // Ok
    case 'verified':
      return 'success';
    // Error
    case 'failed':
    case 'verification-failed':
    case 'verification-iban-mismatch':
    case 'verification-cancelled':
      return 'error';
    default:
      return 'neutral';
  }
};

const BankAccountStatus: React.FC<Props> = ({ status }): JSX.Element => {
  return <Status message={getStatusMessage(status)} hideDefinition state={getStatus(status)} />;
};

export default BankAccountStatus;
