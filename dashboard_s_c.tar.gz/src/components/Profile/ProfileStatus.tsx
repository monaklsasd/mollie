import React from 'react';
import { join } from 'lodash';
import { defineMessages, IntlShape, useIntl } from 'react-intl';
import warning from 'warning';
import { Status, Tooltip } from 'components/UI';
import { IntlMessages } from 'types/intl';
import { States } from 'components/UI/Status';

export const messages: IntlMessages = defineMessages({
  verified: {
    id: 'profile-status-verified',
    defaultMessage: 'Active',
    description: 'Profile status for verified',
  },
  unverified: {
    id: 'profile-status-unverified',
    defaultMessage: 'Unverified',
    description: 'Profile status for unverified',
  },
  blocked: {
    id: 'profile-status-blocked',
    defaultMessage: 'Blocked',
    description: 'Profile status for blocked',
  },
  rejected: {
    id: 'profile-status-rejected',
    defaultMessage: 'Rejected',
    description: 'Profile status for rejected review',
  },
  pending: {
    id: 'profile-status-previously-pending',
    defaultMessage: 'Review pending',
    description: 'Profile status for pending review',
  },
  partiallyRejected: {
    id: 'profile-status-partially-rejected',
    defaultMessage: 'partially rejected',
    description:
      'Profile status for partially rejected (when Credit card or SEPA Direct debit is denied).',
  },
  noMethods: {
    id: 'profile-status-no-enabled-methods',
    defaultMessage: 'No payment methods selected',
    description: 'Profile status for merchants that didnt select any payment method',
  },
});

export const getProfileStatus = (profile: Props['profile']): string | number => {
  // If profile is not in review, it’s verified
  if (!profile.review) {
    return profile.status;
  }

  // Else, return the review status
  return profile.review.status;
};

const getProfileStatusText = (
  status: ReturnType<typeof getProfileStatus>,
  partiallyRejected: Props['partiallyRejected'],
  intl: IntlShape,
  noEnabledMethods: boolean,
): string => {
  warning(messages[status], `No translation found for profile status '${status}'.`);
  const states: (string | number)[] = [];

  if (noEnabledMethods) {
    return intl.formatMessage(messages.noMethods);
  }
  const translatedStatus = messages[status] ? intl.formatMessage(messages[status]) : status;
  states.push(translatedStatus);

  if (partiallyRejected) {
    states.push(intl.formatMessage(messages.partiallyRejected));
  }

  return join(states, ', ');
};

const wrapInTooltip = (
  children: React.ReactElement,
  status: ReturnType<typeof getProfileStatusText>,
  { noText },
): React.ReactElement => {
  if (!noText) {
    return children;
  }

  return <Tooltip content={status}>{children}</Tooltip>;
};

const getProfileStatusIcon = (
  status: ReturnType<typeof getProfileStatus>,
  partiallyRejected: Props['partiallyRejected'],
  noEnabledMethods: boolean,
): States => {
  if (status === 'rejected' || status === 'blocked') {
    return 'error';
  }

  if (status === 'pending' || partiallyRejected || noEnabledMethods) {
    return 'pending';
  }

  if (status === 'verified') {
    return 'success';
  }

  return 'neutral';
};

const ProfileStatus: React.FC<Props> = props => {
  const { profile, partiallyRejected, noText, noEnabledMethods, ...other } = props;
  const intl = useIntl();
  const status = getProfileStatus(profile);
  const statusText = getProfileStatusText(status, partiallyRejected, intl, noEnabledMethods);

  return wrapInTooltip(
    <Status
      state={getProfileStatusIcon(status, partiallyRejected, noEnabledMethods)}
      message={statusText}
      noText={noText}
      {...other}
    />,
    statusText,
    props,
  );
};

type Props = {
  className?: string;
  profile: {
    status: keyof typeof messages;
    review: {
      status: string;
    };
  };
  noText: boolean;
  partiallyRejected: boolean;
  noEnabledMethods: boolean;
};

export default ProfileStatus;
