import React from 'react';
import { defineMessages, useIntl } from 'react-intl';
import ProfileAssetUploader from './ProfileAssetUploader';
import { IntlMessages } from 'types/intl';

const messages: IntlMessages = defineMessages({
  title: {
    id: 'profile-customize-upload-logo-title',
    defaultMessage: 'Checkout logo',
  },
  text: {
    id: 'profile-customize-upload-logo-text',
    defaultMessage: '(PNG or JPG, max {dimensions})',
    description: 'Dimensions will be something like "640x150"',
  },
  note: {
    id: 'profile-customize-upload-logo-note',
    defaultMessage:
      'Note: the logo will be shown at half size, so it will look sharp on retina screens.',
  },
  btnNew: {
    id: 'profile-customize-upload-logo-new',
    defaultMessage: 'Upload logo',
  },
  btnCancel: {
    id: 'profile-customize-upload-logo-cancel',
    defaultMessage: 'Cancel',
  },
  btnChange: {
    id: 'profile-customize-upload-logo-change',
    defaultMessage: 'Change logo',
  },
  btnRemove: {
    id: 'profile-customize-upload-logo-remove',
    defaultMessage: 'Remove logo',
  },
});

const ProfileLogoUploader: React.FC<Props> = props => {
  const intl = useIntl();
  const profilelogo = {
    assetId: 'profilelogo',
    title: intl.formatMessage(messages.title),
    text: intl.formatMessage(messages.text, { dimensions: '640x150' }),
    note: intl.formatMessage(messages.note),
    btnCancel: intl.formatMessage(messages.btnCancel),
    btnChange: intl.formatMessage(messages.btnChange),
    btnRemove: intl.formatMessage(messages.btnRemove),
    btnUpload: intl.formatMessage(messages.btnNew),
  };

  return <ProfileAssetUploader {...profilelogo} {...props} />;
};

type Props = {
  dropText: string;
  fileText: string;
  current: string;
  isLoading: boolean;
  editing: boolean;
  file: File & { preview: string };
  profileId: string;
  cancelAsset: (...args: any[]) => void;
  changeAsset: (...args: any[]) => void;
  removeAsset: (...args: any[]) => void;
  selectAsset: (...args: any[]) => void;
  uploadAsset: (...args: any[]) => void;
};

export default ProfileLogoUploader;
