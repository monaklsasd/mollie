import React from 'react';

const LogoFrame: React.FC = () => (
  <div className="payscreen-preview__mock-logo">
    <p className="payscreen-preview__mock-placeholder">Logo</p>
  </div>
);

export default LogoFrame;
