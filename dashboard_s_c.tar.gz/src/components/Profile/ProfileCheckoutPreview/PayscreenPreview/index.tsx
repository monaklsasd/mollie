import React from 'react';
import classNames from 'classnames';

import Currency from 'components/UI/Currency';

import { AmexSVG, CreditcardSVG, MastercardSVG, VisaSVG } from './Icons';
import Index from './LogoFrame';

import './styles.scss';
import { ClassnamesFunction } from 'types/helpers';

type OwnProps = {
  hasLogo: boolean;
};

const getClass: ClassnamesFunction<OwnProps> = ({ hasLogo }) =>
  classNames('payscreen-preview__mock', {
    'has-logo': hasLogo,
  });

const PayscreenPreview: React.FC<OwnProps> = ({ hasLogo }) => (
  <div className={getClass({ hasLogo })}>
    {!hasLogo && <Index />}
    <div className="payscreen-preview__mock-wrapper">
      <h3 className="c-heading--h3 payscreen-preview__mock-heading">
        <Currency value="9.99" />
      </h3>
      <div className="payscreen-preview__mock-input" />
      <div className="payscreen-preview__mock-input payscreen-preview__mock-input-icons">
        <MastercardSVG />
        <AmexSVG className="payscreen-preview__mock-icon" />
        <VisaSVG className="payscreen-preview__mock-icon" />
      </div>
      <div className="payscreen-preview__mock-input-wrapper">
        <div className="payscreen-preview__mock-input-tight" />
        <div className="payscreen-preview__mock-input-tight payscreen-preview__mock-input-icons">
          <CreditcardSVG />
        </div>
      </div>
      <div className="payscreen-preview__mock-button" />
    </div>
  </div>
);

export default PayscreenPreview;
