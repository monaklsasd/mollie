import React from 'react';
import { FormattedMessage } from 'react-intl';
import classNames from 'classnames';

// Components
import PayscreenPreview from './PayscreenPreview';

import './styles.scss';
import { ClassnamesFunction } from 'types/helpers';

type OwnProps = {
  profilelogo: Maybe<string>;
  profilewallpaper: Maybe<string>;
  previewUrl: string;
};

const getClass: ClassnamesFunction<{ withWallpaper: boolean }> = ({ withWallpaper }) =>
  classNames('c-checkout-preview', {
    'has-wallpaper': withWallpaper,
  });

const ProfileCheckoutPreview: React.FC<OwnProps> = ({
  profilelogo,
  profilewallpaper,
  previewUrl,
}) => {
  const logo: React.CSSProperties = profilelogo ? { backgroundImage: `url('${profilelogo}')` } : {};
  const wallpaper: React.CSSProperties = profilewallpaper
    ? { backgroundImage: `url('${profilewallpaper}')` }
    : {};

  const withLogo = profilelogo !== '';
  const withWallpaper = profilewallpaper !== '';

  return (
    <div>
      <div className={getClass({ withWallpaper })}>
        {withWallpaper && <div className="c-checkout-preview__wallpaper" style={wallpaper} />}
        {withLogo && (
          <div className="c-checkout-preview__logo-wrapper">
            <div className="c-checkout-preview__logo" style={logo} />
          </div>
        )}
        <PayscreenPreview hasLogo={withLogo} />
      </div>
      <small className="u-pull-right">
        {/* eslint-disable react/jsx-no-target-blank */}
        <a href={previewUrl} rel="noopener" target="_blank">
          <FormattedMessage
            id="profile-customize-preview-link"
            defaultMessage="Open full preview"
          />
        </a>
        {/* eslint-enable react/jsx-no-target-blank */}
      </small>
    </div>
  );
};

ProfileCheckoutPreview.defaultProps = {
  profilelogo: '',
  profilewallpaper: '',
};

export default ProfileCheckoutPreview;
