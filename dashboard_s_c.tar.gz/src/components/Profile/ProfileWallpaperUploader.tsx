import React from 'react';
import { defineMessages, useIntl } from 'react-intl';
import ProfileAssetUploader from './ProfileAssetUploader';
import { IntlMessages } from 'types/intl';

const messages: IntlMessages = defineMessages({
  title: {
    id: 'profile-customize-upload-wallpaper-title',
    defaultMessage: 'Checkout wallpaper',
  },
  text: {
    id: 'profile-customize-upload-wallpaper-text',
    defaultMessage: '(PNG or JPG, max {dimensions})',
    description: 'Dimensions will be something like "1920x1080"',
  },
  btnNew: {
    id: 'profile-customize-upload-wallpaper-new',
    defaultMessage: 'Upload wallpaper',
  },
  btnCancel: {
    id: 'profile-customize-upload-wallpaper-cancel',
    defaultMessage: 'Cancel',
  },
  btnChange: {
    id: 'profile-customize-upload-wallpaper-change',
    defaultMessage: 'Change wallpaper',
  },
  btnRemove: {
    id: 'profile-customize-upload-wallpaper-remove',
    defaultMessage: 'Remove wallpaper',
  },
});

const ProfileWallpaperUploader: React.FC<Props> = props => {
  const intl = useIntl();

  const profilewallpaper = {
    assetId: 'profilewallpaper',
    title: intl.formatMessage(messages.title),
    text: intl.formatMessage(messages.text, { dimensions: '1920x1080' }),
    btnCancel: intl.formatMessage(messages.btnCancel),
    btnChange: intl.formatMessage(messages.btnChange),
    btnRemove: intl.formatMessage(messages.btnRemove),
    btnUpload: intl.formatMessage(messages.btnNew),
  };

  return <ProfileAssetUploader {...profilewallpaper} {...props} />;
};

type Props = {
  dropText: string;
  fileText: string;
  current: string;
  isLoading: boolean;
  editing: boolean;
  file: File & { preview: string };
  profileId: string;
  cancelAsset: (...args: any[]) => void;
  changeAsset: (...args: any[]) => void;
  removeAsset: (...args: any[]) => void;
  selectAsset: (...args: any[]) => void;
  uploadAsset: (...args: any[]) => void;
};

export default ProfileWallpaperUploader;
