import { IntlMessages } from './../../../types/intl';
import { defineMessages } from 'react-intl';

export const labels: IntlMessages = defineMessages({
  button: {
    id: 'payment-method-pricing-and-info-button-label',
    defaultMessage: 'Pricing & info',
  },
});

export const regions = defineMessages({
  applepay: {
    id: 'pricing-and-info-region-apple-pay',
    defaultMessage:
      'Germany, France, Italy, Belgium, Austria, Spain, and more than 30 other countries',
  },
  banktransfer: {
    id: 'pricing-and-info-region-banktransfer',
    defaultMessage: '34 SEPA-countries',
  },
  belfius: {
    id: 'pricing-and-info-region-belfius',
    defaultMessage: 'Belgium',
  },
  creditcard: {
    id: 'pricing-and-info-region-creditcard',
    defaultMessage: 'Worldwide',
  },
  directdebit: {
    id: 'pricing-and-info-region-directdebit',
    defaultMessage: '34 SEPA-countries',
  },
  eps: {
    id: 'pricing-and-info-region-eps',
    defaultMessage: 'Austria',
  },
  giftcard: {
    id: 'pricing-and-info-region-giftcard',
    defaultMessage: 'Netherlands',
  },
  giropay: {
    id: 'pricing-and-info-region-giropay',
    defaultMessage: 'Germany',
  },
  ideal: {
    id: 'pricing-and-info-region-ideal',
    defaultMessage: 'Netherlands',
  },
  inghomepay: {
    id: 'pricing-and-info-region-inghomepay',
    defaultMessage: 'Belgium',
  },
  kbc: {
    id: 'pricing-and-info-region-kbc',
    defaultMessage: 'Belgium',
  },
  klarnapaylater: {
    id: 'pricing-and-info-region-klarnapaylater',
    defaultMessage: 'Germany, Austria, Finland, and The Netherlands',
  },
  klarnasliceit: {
    id: 'pricing-and-info-region-klarnasliceit',
    defaultMessage: 'Germany, Austria, and Finland',
  },
  mistercash: {
    id: 'pricing-and-info-region-bancontact',
    defaultMessage: 'Belgium',
  },
  paypal: {
    id: 'pricing-and-info-region-paypal',
    defaultMessage: 'Worldwide',
  },
  sofort: {
    id: 'pricing-and-info-region-sofort',
    defaultMessage: 'Germany and 12 other countries',
  },
  przelewy24: {
    id: 'pricing-and-info-region-przelewy24',
    defaultMessage: 'Poland',
  },
});

export const rates = defineMessages({
  adult: {
    id: 'pricing-and-info-sofort-adult',
    defaultMessage: 'Transactions for adult',
    description: 'Used for Sofort in the pricing & info modal on the payment methods page.',
  },
  batch: {
    id: 'pricing-and-info-direct-debit-batch',
    defaultMessage: 'Batch transactions',
    description:
      'Used for SEPA Direct Debit in the pricing & info modal on the payment methods page.',
  },
  digital: {
    id: 'pricing-and-info-sofort-digital',
    defaultMessage: 'Transactions for digital',
    description: 'Used for Sofort in the pricing & info modal on the payment methods page.',
  },
  failures: {
    id: 'pricing-and-info-direct-debit-failures',
    defaultMessage: 'Failures',
    description:
      'Used for SEPA Direct Debit in the pricing & info modal on the payment methods page.',
  },
  regular: {
    id: 'pricing-and-info-regular',
    defaultMessage: 'Transactions',
    description: 'Used in the pricing & info modal on the payment methods page.',
  },
  refunds: {
    id: 'pricing-and-info-refunds',
    defaultMessage: 'Refunds',
    description: 'Used in the pricing & info modal on the payment methods page.',
  },
  chargebacks: {
    id: 'pricing-and-info-chargebacks',
    defaultMessage: 'Chargebacks',
    description: 'Used in the pricing & info modal on the payment methods page.',
  },
  unjustified: {
    id: 'pricing-and-info-unjustified-direct-debit',
    defaultMessage: 'Report of unjustified Direct Debit',
    description: 'Used in the pricing & info modal on the payment methods page.',
  },
});

export const descriptions = defineMessages({
  applepay: {
    id: 'pricing-and-info-description-applepay',
    defaultMessage: `
      <strong>We do not charge additional fees for Apple Pay. Payments processed via Apple Pay are charged only for the debit- or credit card used in the payment.</strong>
      <br><br>
      Apple Pay gives your customers an easy, secure, and private way to pay on the web. Customers can use the devices that they have with them every day.
      <br><br>
      Accepting Apple Pay is faster than accepting traditional credit and debit cards and other payment methods. Customers no longer need to spend time searching for their wallet and finding the right card. When using Safari your customers can check out with a single touch.`,
  },
  banktransfer: {
    id: 'pricing-and-info-description-banktransfer',
    defaultMessage:
      'A bank transfer is a manual money transfer into Mollie’s bank account. The consumer needs to reference a unique payment ID when transferring the funds. On average, bank transfers take up to 2 business days. When received by us, the payment is guaranteed and can’t be reversed by the consumer anymore. After we have received the funds, we can pay them out into your business bank account the following business day.',
  },
  belfius: {
    id: 'pricing-and-info-description-belfius',
    defaultMessage:
      'Belgian customers of the Belfius bank easily pay online through the Belfius Pay Button. These payments are guaranteed as soon as they’re authorised. We can pay out funds received through the Belfius Pay Button into your business bank account the next business day.',
  },
  creditcard: {
    id: 'pricing-and-info-description-creditcard',
    defaultMessage:
      'A credit card payment is not guaranteed. The consumer can instruct his or her bank to reverse the payment, which is called a chargeback, for 180 days after the sale. Credit cards are used a lot to pay for online purchases, but can also bring some risks to merchants due to chargebacks. <a href="https://help.mollie.com/hc/en-us/articles/115000972585-What-are-the-risks-of-payments-via-credit-card-" target="_blank" rel="noopener">Read more about the risks of credit card payments</a>. After enabling credit card, we will evaluate your request for this payment method within 2 business days.',
  },
  directdebit: {
    id: 'pricing-and-info-description-directdebit',
    defaultMessage:
      'With SEPA Direct Debit you can automatically debit a customer’s bank account. The customer can reverse a direct debit payment online up to 56 days after the bank account has been charged. After these 56 days a reversal is still possible, but it’s much more complicated. When this happens the bank will charge an added fee. <a href="https://help.mollie.com/hc/nl/articles/115000796469" target="_blank" rel="noopener">Read more about the risks of SEPA Direct Debit here</a>.',
  },
  eps: {
    id: 'pricing-and-info-description-eps',
    defaultMessage:
      'The Electronic Payment Standard (EPS) is a payment method, developed by various Austrian banks. This makes EPS the main bank transfer payment method in Austria and highly popular with Austrian shoppers. With Mollie you can integrate EPS quickly and start processing payments right away. You only pay for successful transactions, no hidden fees involved.',
  },
  giftcard: {
    id: 'pricing-and-info-description-giftcard',
    defaultMessage:
      'Mollie supports a number of different gift cards. To activate gift card payments, you’ll need to enter into an agreement with the publisher of the gift card. <a href="https://help.mollie.com/hc/en-us/articles/115004458349-How-do-I-activate-gift-card-payments-" target="_blank" rel="noopener">Read more information about the activation process</a>. The gift card transactions will be shown in your Dashboard, but the payments will be paid out by the gift card organisation.',
  },
  giropay: {
    id: 'pricing-and-info-description-giropay',
    defaultMessage:
      'Giropay is a popular bank transfer payment method in Germany. It uses more than 1,500 German banks, which makes it a trusted payment method under German customers. With Mollie you can integrate Giropay quickly and start processing payments right away. You only pay for successful transactions, no hidden fees involved.',
  },
  ideal: {
    id: 'pricing-and-info-description-ideal',
    defaultMessage:
      'iDEAL is a guaranteed payment method which can be used by consumers and businesses with a bank account with almost any Dutch bank. We can pay out funds received through iDEAL into your business bank account the next business day.',
  },
  inghomepay: {
    id: 'pricing-and-info-description-inghomepay',
    defaultMessage:
      'Belgian customers from the ING bank easily pay online through ING Home’Pay. These payments are guaranteed as soon as they’re authorised. We can pay out funds received through ING Home’Pay into your business bank account the next business day.',
  },
  kbc: {
    id: 'pricing-and-info-description-kbc',
    defaultMessage:
      'Belgian customers of the KBC/CBC bank easily pay online through the KBC/CBC payment button. These payments are guaranteed as soon as they’re authorised. We can pay out funds received through the KBC/CBC payment button into your business bank account the next business day.',
  },
  klarnapaylater: {
    id: 'pricing-and-info-description-klarnapaylater',
    defaultMessage:
      'With Klarna Pay later you offer your customers the option to pay after receiving the order. The method is currently available for Euro (€) payments in the Netherlands, Germany, Austria and Finland.<br><br> You as a merchant receive the money from Klarna directly after shipping the items. Klarna then takes the risk to collect the payment(s). If you connect your webshop with our API’s, you need to use the Orders API to offer Klarna Pay Later. <a href="https://help.mollie.com/hc/sections/360001873554" rel="noopener" target="_blank">More information</a>.<br><br><small>* Consumer location</small>',
  },
  klarnasliceit: {
    id: 'pricing-and-info-description-klarnasliceit',
    defaultMessage:
      'With Klarna Slice It you offer your customers the option to pay for their order in installments. The method is currently available for Euro (€) payments in Germany, Austria and Finland.<br><br> You as a merchant receive the money from Klarna directly after shipping the items. Klarna then takes the risk to collect the payment(s). If you connect your webshop with our API’s, you need to use the Orders API to offer Klarna Slice It. <a href="https://help.mollie.com/hc/sections/360001873554" rel="noopener" target="_blank">More information</a>.<br><br><small>* Consumer location</small>',
  },
  mistercash: {
    id: 'pricing-and-info-description-bancontact',
    defaultMessage:
      'Bancontact is a guaranteed payment method which is used by many consumers and businesses with a Belgium bank account. We can pay out funds received through Bancontact into your business bank account the next business day.',
  },
  paypal: {
    id: 'pricing-and-info-description-paypal',
    defaultMessage:
      'We built a technical integration with PayPal, so you can easily accept this payment method along with all other payment methods. The PayPal transactions will show up in Dashboard, but the payments will be settled into your PayPal account.',
  },
  paysafecard: {
    id: 'pricing-and-info-description-paysafecard',
    defaultMessage:
      'paysafecard is a prepaid card which can be used in 43 countries to pay online. The payments are guaranteed and can’t be reversed by the consumer. Received funds are paid out once a month on the first business day of the month.',
  },
  sofort: {
    id: 'pricing-and-info-description-sofort',
    defaultMessage:
      'SOFORT is a payment method which can be used in 13 European countries. On average, a SOFORT payment takes up to 3 business days to transfer into Mollie’s bank account. When received by us, the payment is guaranteed and can’t be reversed by the consumer anymore. After we have received the funds, we can pay them out into your business bank account the following business day.',
  },
  przelewy24: {
    id: 'pricing-and-info-description-przelewy24',
    defaultMessage:
      'Przelewy24 is the most popular Polish payment method, with support for more than 30 banks in Poland. Because it uses real-time bank transfer, the payments made with Przelewy24 are 100% guaranteed.',
  },
});

export const captureTypes: IntlMessages = defineMessages({
  first: {
    id: 'pricing-and-info-capture-type-first',
    defaultMessage: 'First capture',
  },
  additional: {
    id: 'pricing-and-info-capture-type-additional',
    defaultMessage: 'Additional captures',
  },
});

export default labels;
