import React from 'react';
import { FormattedMessage, FormattedNumber, FormattedHTMLMessage } from 'react-intl';
import warning from 'warning';

import Heading from 'components/UI/Heading';
import Modal from 'components/UI/Modal';

// Internals
import * as messages from './messages';
import { getDefaultRates, getNonDefaultRates, getUniqueRateTypes } from './utils';

// Types
import { Rates, PricingInfoRate as Rate } from './types';

import './styles.scss';

const renderRate: React.FC<Omit<Rate, 'id' | 'label'>> = ({ fixed, variable, value }) => (
  <span className="c-pricing-and-info__rate">
    {value ? (
      value
    ) : (
      <span>
        {// Show fixed fee when it’s positive or there is no variable fee
        (Number(fixed) > 0 || Number(variable) === 0) && (
          <FormattedNumber
            format="EUR"
            value={Number(fixed)}
            minimumFractionDigits={2}
            maximumFractionDigits={3}
          />
        )}
        {Number(fixed) > 0 && Number(variable) > 0 && ' + '}
        {Number(variable) > 0 && (
          <FormattedNumber format="percentage" value={Number(variable)} maximumFractionDigits={2} />
        )}
      </span>
    )}
  </span>
);

const renderLabel = ({ label, id }: Rate): React.ReactNode => {
  if (label) {
    return label;
  }

  if (messages.rates[id]) {
    return <FormattedMessage {...messages.rates[id]} />;
  }

  warning(true, `Missing translation for message "${id}".`);

  return id;
};

const renderRatesList = (rates: Maybe<Rates>): React.ReactNode => {
  if (!rates) {
    return null;
  }

  return (
    <ul className="c-pricing-and-info__pricing-list">
      {rates.map(item => (
        <li key={item.id}>
          <strong>{renderLabel(item)}</strong>
          {// Does this item contain nested rates?
          item.rates && item.rates.length > 0 ? (
            <ul>
              {item.rates.map(({ id, label, ...rest }) => {
                // We show some subrates only when it haves a custom pricing
                if (!rest.variable && !rest.fixed) return null;

                return (
                  <li key={id}>
                    <span>{label}</span>
                    {renderRate(rest)}
                  </li>
                );
              })}
            </ul>
          ) : (
            renderRate(item)
          )}
        </li>
      ))}
    </ul>
  );
};

type Props = {
  id: string;
  heading: React.ReactNode;
  isOpen: boolean;
  onToggleModal: (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
  rates: Rates;
};

const PricingAndInfo: React.FC<Props> = ({ id, heading, isOpen, onToggleModal, rates }) => {
  const defaultRates = getDefaultRates(rates);

  /**
   * Captures may have a certain "type" associated (e.g. "first", "additional", etc.). We want to show these captures in
   * a separate list.
   */
  const nonDefaultRates = getNonDefaultRates(rates);
  const uniqueCaptureRateTypes = getUniqueRateTypes(nonDefaultRates) || {};

  return (
    <div className="c-pricing-and-info">
      <button className="c-pricing-and-info__button" type="button" onClick={onToggleModal}>
        <FormattedMessage {...messages.labels.button} />
      </button>
      <Modal isOpen={isOpen} onRequestClose={onToggleModal} wide>
        <Heading type="h3" as="h2" className="c-pricing-and-info__heading">
          {heading}
        </Heading>
        {messages.regions[id] && (
          <p className="c-pricing-and-info__region">
            <FormattedMessage {...messages.regions[id]} />
          </p>
        )}
        {Object.keys(uniqueCaptureRateTypes).map(rateType => (
          <React.Fragment key={`${rateType}-${id}`}>
            <Heading type="h3" className="c-pricing-and-info__capture-heading">
              <FormattedMessage {...messages.captureTypes[rateType]} />
            </Heading>
            {renderRatesList(uniqueCaptureRateTypes[rateType])}
          </React.Fragment>
        ))}
        {renderRatesList(defaultRates)}
        {messages.descriptions[id] && (
          <p>
            <FormattedHTMLMessage {...messages.descriptions[id]} />
          </p>
        )}
      </Modal>
    </div>
  );
};

export default PricingAndInfo;
