import { groupBy } from 'lodash';

// Types
import { Rates, PricingInfoRate as Rate } from './types';

/**
 * Some capture rates (like Klarna Pay Later) have a type associated. Possible types are "first" or "additional". We can
 * detect these rates by their "type" property.
 */
export const getDefaultRates = (rates: Maybe<Rates>): Maybe<Rates> => {
  if (!rates) {
    return;
  }

  return rates.filter(rate => !rate.type);
};

export const getNonDefaultRates = (rates: Maybe<Rates>): Maybe<Rates> => {
  if (!rates) {
    return;
  }

  return rates.filter(rate => rate.type);
};

export const getUniqueRateTypes = (rates: Maybe<Rates>): Maybe<Record<string, Rate[]>> => {
  if (!rates) {
    return;
  }

  return groupBy(rates, ({ type }) => type);
};
