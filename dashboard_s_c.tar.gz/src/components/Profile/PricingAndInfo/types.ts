import { OrganizationRate } from './../../../reduxState/modules/organization/types';
import React from 'react';

export type PricingInfoRate = OrganizationRate & {
  label?: React.ReactNode | string;
  value?: React.ReactNode;
  type?: string;
  rates?: (OrganizationRate & {
    label?: React.ReactNode;
    value?: React.ReactNode;
  })[];
};

export type Rates = PricingInfoRate[];
