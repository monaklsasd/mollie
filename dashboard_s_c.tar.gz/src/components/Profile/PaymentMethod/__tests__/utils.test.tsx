import PAYMENT_METHODS, { STATUSES } from 'helpers/paymentMethods';
import { isPaymentMethodActivated, isPaymentMethodPending, Method } from '../utils';

/* eslint-disable no-undef */
describe('ProfileMethods/utils', () => {
  describe('isPaymentMethodActivated', () => {
    const method = PAYMENT_METHODS.IDEAL;

    it('returns false when profile is undefined', () => {
      // @ts-ignore
      const actual = isPaymentMethodActivated(method, undefined);

      expect(actual).toBeFalsy();
    });

    it('returns true when method is activated', () => {
      const profile = {
        methods: {
          ideal: {
            status: STATUSES.ACTIVATED,
          },
        },
      };

      // @ts-ignore
      const actual = isPaymentMethodActivated(method, profile);

      expect(actual).toBeTruthy();
    });

    it('returns false when method is not activated', () => {
      const profile = {
        methods: {
          ideal: {
            status: null,
          },
        },
      };

      // @ts-ignore
      const actual = isPaymentMethodActivated(method, profile);

      expect(actual).toBeFalsy();
    });
  });

  describe('isPaymentMethodPending', () => {
    it('returns false when profile is not defined', () => {
      const profile = undefined;
      const method: Method = {
        status: undefined,
        enabled: true,
        field: {
          enabled: {
            value: true,
          },
        },
      };

      const actual = isPaymentMethodPending(method, profile);

      expect(actual).toBeFalsy();
    });

    it('returns false when profile is not verified', () => {
      const profile = {
        status: 'anything-but-verified',
      };

      const method: Method = {
        status: undefined,
        enabled: true,
        field: {
          enabled: {
            value: true,
          },
        },
      };

      const actual = isPaymentMethodPending(method, profile);

      expect(actual).toBeFalsy();
    });

    it('returns false when method is rejected', () => {
      const profile = {
        status: 'verified',
      };

      const method: Method = {
        status: STATUSES.REJECTED,
        enabled: true,
        field: {
          enabled: {
            value: true,
          },
        },
      };

      const actual = isPaymentMethodPending(method, profile);

      expect(actual).toBeFalsy();
    });

    it('returns false when method field has no value', () => {
      const profile = {
        status: 'verified',
      };

      const method: Method = {
        status: STATUSES.REJECTED,
        enabled: true,
        field: {
          enabled: {},
        },
      };

      const actual = isPaymentMethodPending(method, profile);

      expect(actual).toBe(false);
    });

    it('returns false when method is not enabled in PHP', () => {
      const profile = {
        status: 'verified',
      };

      const method: Method = {
        status: undefined,
        enabled: false,
        field: {
          enabled: {
            value: true,
          },
        },
      };

      const actual = isPaymentMethodPending(method, profile);

      expect(actual).toBe(false);
    });

    it('returns false when method is already activated in PHP', () => {
      const profile = {
        status: 'verified',
      };

      const method = {
        status: STATUSES.ACTIVATED,
        enabled: true,
        field: {
          enabled: {
            value: true,
          },
        },
      };

      const actual = isPaymentMethodPending(method, profile);

      expect(actual).toBe(false);
    });

    it('returns true when method is not activated or rejected in PHP, but enabled on the client with a verified profile', () => {
      const profile = {
        status: 'verified',
      };

      const method: Method = {
        status: undefined,
        enabled: true,
        field: {
          enabled: {
            value: true,
          },
        },
      };

      const actual = isPaymentMethodPending(method, profile);

      expect(actual).toBe(true);
    });
  });
});
