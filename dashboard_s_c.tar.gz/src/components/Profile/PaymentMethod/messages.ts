import { defineMessages } from 'react-intl';
import { IntlMessages } from 'types/intl';

const messages: IntlMessages = defineMessages({
  'profileMethodsFeeType-general': {
    id: 'profile-methods-fee-type-general',
    defaultMessage: '{fixedRate} {ratesSeparator} {variableRate} per transaction',
    description:
      'Rate text for when a payment method has a general rate. e.g. iDEAL with values fixedRate= 0.29, variableRate=null, location=null gives =? <€ 0,29 per transactie>',
  },
  profileMethodsRatesMultipleRates: {
    id: 'profile-methodds-rates-multiple-rates',
    defaultMessage: '+',
    description:
      'If there are both variable and fixed rates for a payment method this is inserted inbetween the two.',
  },
  rejected: {
    id: 'payment-method-rejected',
    defaultMessage: 'Your request for this payment method was denied.',
    description: 'Displayed when method has been rejected by the onboarding team.',
  },
  'pending-review': {
    id: 'payment-method-pending-review',
    defaultMessage:
      'We’re evaluating your request for this payment method. This will take up to 2 business days.',
    description:
      'Displayed when method is enabled in profile but not ready to be used for real payments because we still need to review the merchant application.',
  },
  'pending-boarding': {
    id: 'payment-method-pending-boarding',
    defaultMessage: 'You need to {link} before this payment method can be activated.',
    description:
      'Displayed when method is enabled in profile but not ready to be used for real payments because they need to complete the boarding.',
  },
  applePayPendingReview: {
    id: 'payment-method-apple-pay-pending-review',
    defaultMessage: 'We’re evaluating your request for credit card.',
    description: 'Displayed when Apple Pay is pending because of credit card being in review.',
  },
});

export default messages;
