import React from 'react';
import { FormattedNumber, FormattedMessage } from 'react-intl';

// Components
import Link from 'components/UI/Link';
import { States } from 'components/UI/Status';

// Messages
import messages from './messages';

// Utils
import PAYMENT_METHODS, { STATUSES } from 'helpers/paymentMethods';
import { STATUS_PENDING, STATUS_ERROR, STATUS_SUCCESS, STATUS_NEUTRAL } from 'components/UI/Status';

// Types
import { PricingInfoRate as Rate } from 'components/Profile/PricingAndInfo/types';
import { ProfileType, ProfilePaymentMethodStatus } from 'reduxState/modules/profiles/types';
import { AcceptedMethods } from 'components/IconPaymentMethods';

export const isPaymentMethodActivated = (methodName: string, profile: ProfileType): boolean => {
  if (!profile) {
    return false;
  }

  return profile.methods[methodName].status === STATUSES.ACTIVATED;
};

export type Method = {
  id?: AcceptedMethods;
  enabled?: boolean;
  field?: {
    enabled?: {
      value?: string | boolean;
    };
  };
  status?: keyof typeof STATUSES | string;
};

type Profile = {
  status: string;
};

export const isPaymentMethodPending = (method: Method, profile?: Profile): boolean => {
  // Giftcards are enabled on the issuer level, thus this method can never be pending.
  if (method.id === PAYMENT_METHODS.GIFTCARD) {
    return false;
  }

  // Profile verified
  // Field 'enabled'
  // PHP 'enabled'
  // PHP not 'rejected'
  // PHP not 'activated'
  return !!(
    profile &&
    profile.status === 'verified' &&
    method?.field?.enabled?.value &&
    method.enabled &&
    method.status !== STATUSES.REJECTED &&
    method.status !== STATUSES.ACTIVATED
  );
};

/**
 * Returns the byline with rates for a payment method
 */
export const getRatesTranslation = (rate: Maybe<Rate>): React.ReactNode => {
  if (!rate) {
    return;
  }

  // Allows components to set a specific rate value, for example "€0.25 + PayPal fees"
  if (rate.value) {
    return rate.value;
  }

  // Show fixed rate when it is above zero, but also show it when there is no variable rate.
  // This can happen for payment methods that are free, for instance during trial periods.
  const fixedRate =
    Number(rate.fixed) > 0 || Number(rate.variable) <= 0 ? (
      <span>
        <FormattedNumber format="EUR" value={Number(rate.fixed)} maximumFractionDigits={4} />{' '}
      </span>
    ) : null;

  const variableRate =
    Number(rate.variable) > 0 ? (
      <span>
        <FormattedNumber
          format="percentage"
          value={Number(rate.variable)}
          maximumFractionDigits={2}
        />
      </span>
    ) : null;

  const ratesSeparator =
    Number(rate.variable) > 0 && Number(rate.fixed) > 0 ? (
      <span>
        <FormattedMessage {...messages.profileMethodsRatesMultipleRates} />{' '}
      </span>
    ) : null;

  return (
    <FormattedMessage
      {...messages['profileMethodsFeeType-general']}
      key={rate.id}
      values={{ fixedRate, ratesSeparator, variableRate }}
    />
  );
};

// Right now this function only works for pending, but it would be
// trivial to allow more status messages by getting the reponse
// from an object
type Args = {
  status: Maybe<string>;
  nextUncompletedPage?: string;
  method: string;
};

export const getStatusMessage = ({
  status,
  nextUncompletedPage,
  method,
}: Args): React.ReactNode => {
  if (!status || !messages[status]) {
    return null;
  }

  if (status === STATUSES.PENDING_REVIEW && method === PAYMENT_METHODS.APPLEPAY) {
    return <FormattedMessage {...messages.applePayPendingReview} />;
  }

  return (
    <FormattedMessage
      {...messages[status]}
      values={{
        link: (
          <Link to={`/onboarding/${nextUncompletedPage || ''}`}>
            <FormattedMessage
              id="payment-method-boarding-link-label"
              defaultMessage="complete the boarding"
            />
          </Link>
        ),
      }}
    />
  );
};

export const transformStatus = (status: ProfilePaymentMethodStatus): States => {
  switch (status) {
    case STATUSES.PENDING_BOARDING:
    case STATUSES.PENDING_REVIEW:
      return STATUS_PENDING;

    case STATUSES.REJECTED:
      return STATUS_ERROR;

    case STATUSES.ACTIVATED:
      return STATUS_SUCCESS;

    default:
      return STATUS_NEUTRAL;
  }
};
