import * as React from 'react';
import { find } from 'lodash';
import { Field } from 'formik';
import { connect } from 'react-redux';

// Components
import IconPaymentMethods, { AcceptedMethods } from 'components/IconPaymentMethods';
import ButtonGroup from 'components/UI/ButtonGroup';
import ListItem from 'components/UI/ListItem';
import Toggle from 'components/UI/Toggle';

// Containers
import { getNextUncompletedPageId } from 'containers/Onboarding/selectors';

// Utils
import PAYMENT_METHODS from 'helpers/paymentMethods';
import getLocalizedMethodName from 'utils/getLocalizedMethodName';

// Tracking
import { track } from 'services/analytics';
import { EVENTS } from './tracking';

// Types
import { ProfilePaymentMethodType } from 'reduxState/modules/profiles/types';
import { State as ReduxState } from 'reduxState/types';

// Internals
import { getRatesTranslation, getStatusMessage, transformStatus } from './utils';
import PricingAndInfo from '../PricingAndInfo';
import './styles.scss';
import { PricingInfoRate } from 'components/Profile/PricingAndInfo/types';

const getLink = (id: string): string => {
  if (id === PAYMENT_METHODS.BANKTRANSFER) {
    return '/payments/bank-transfer';
  }

  if (id === PAYMENT_METHODS.CREDITCARD) {
    return '/payments/credit-card';
  }

  if (id === PAYMENT_METHODS.MISTERCASH) {
    return '/payments/bancontact';
  }

  if (id === PAYMENT_METHODS.KBC) {
    return '/payments/kbc-cbc';
  }

  if (id === PAYMENT_METHODS.INGHOMEPAY) {
    return '/payments/ing-homepay';
  }

  if (id === PAYMENT_METHODS.DIRECTDEBIT) {
    return '/payments/direct-debit';
  }

  if (id === PAYMENT_METHODS.KLARNAPAYLATER) {
    return '/payments/klarna-pay-later';
  }

  if (id === PAYMENT_METHODS.KLARNASLICEIT) {
    return '/payments/klarna-slice-it';
  }

  if (id === PAYMENT_METHODS.APPLEPAY) {
    return '/payments/apple-pay';
  }

  return `/payments/${id}`;
};

type Rate = {
  id: string;
  label: React.ReactNode;
  rates: Rate[];
};

type Props = ProfilePaymentMethodType & {
  condition?: Function;
  disabled?: boolean;
  byline?: React.ReactNode;
  children?: React.ReactNode;
  rates: PricingInfoRate[];
  nextUncompletedPage: string;
};

type State = {
  modalIsOpen: boolean;
};

const Condition: React.FC = ({ children }) => (
  <span className="payment-method__condition">{children}</span>
);

class PaymentMethod extends React.Component<Props, State> {
  state = {
    modalIsOpen: false,
  };

  toggleModal = (): void => {
    this.setState({
      modalIsOpen: !this.state.modalIsOpen,
    });
  };

  handleToggle = ({
    nextToggledValue,
    paymentMethod,
  }: {
    nextToggledValue: boolean;
    paymentMethod: string;
  }) => (): void => {
    const toggleState = nextToggledValue ? 'enabled' : 'disabled';

    // eslint-disable-next-line @typescript-eslint/camelcase
    track({ ...EVENTS.paymentMethodToggled, state: toggleState, payment_type: paymentMethod });
  };

  renderChildren(enabled: boolean): React.ReactNode {
    if (!enabled) {
      return null;
    }

    return this.props.children;
  }

  render(): React.ReactElement {
    const {
      id,
      condition,
      disabled,
      status,
      byline,
      children,
      rates,
      nextUncompletedPage,
    } = this.props;

    const name = getLocalizedMethodName(id);
    const link = getLink(id);
    const toggleStatus = status && status.startsWith('pending') ? 'pending' : null;

    return (
      <Field
        name={`methods.${id}.enabled`}
        render={({ field }): React.ReactElement => (
          <ListItem
            heading={
              <React.Fragment>
                {/* eslint-disable-next-line react/jsx-no-target-blank */}
                <a rel="noopener" target="_blank" href={link}>
                  {name}
                </a>{' '}
                {condition && condition(Condition)}
              </React.Fragment>
            }
            byline={byline || getRatesTranslation(find(rates, { id: 'regular' }))}
            icon={<IconPaymentMethods method={id as AcceptedMethods} />}
            control={
              <ButtonGroup>
                <PricingAndInfo
                  isOpen={this.state.modalIsOpen}
                  onToggleModal={this.toggleModal}
                  id={id}
                  rates={rates}
                  heading={name}
                />
                <Toggle
                  onClick={this.handleToggle({
                    nextToggledValue: !field.value,
                    paymentMethod: id,
                  })}
                  status={toggleStatus}
                  disabled={disabled}
                  {...field}
                />
              </ButtonGroup>
            }
            statusMessage={getStatusMessage({ status, nextUncompletedPage, method: id })}
            status={transformStatus(status)}>
            {typeof children === 'function'
              ? children({ field, status })
              : this.renderChildren(field.value)}
          </ListItem>
        )}
      />
    );
  }
}

const mapStateToProps = (
  state: ReduxState,
): { nextUncompletedPage: Props['nextUncompletedPage'] } => ({
  nextUncompletedPage: getNextUncompletedPageId(state),
});

export default connect(mapStateToProps)(PaymentMethod);
