import { DESTINATIONS } from 'services/analytics/constants';

/**
 * Do not change event and category names after taken in use.
 */

export const EVENTS = {
  paymentMethodToggled: {
    category: 'Payment Method',
    event: 'Toggled',
    destinations: [DESTINATIONS.MP],
  },
};

export default EVENTS;
