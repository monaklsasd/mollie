import React from 'react';

import './styles.scss';

type Props = {
  profile: Record<string, any>;
  showIcon?: boolean;
};

const ProfileName: React.FC<Props> = ({ profile, showIcon = true }) => {
  return (
    <span>
      {showIcon && (
        <img
          className="c-profile-name__icon"
          alt=""
          src={`https://www.google.com/s2/favicons?domain=${encodeURIComponent(profile.website)}`}
        />
      )}
      {profile.name}&nbsp;
      <span className="u-text-muted">{profile.website.replace(/(^https?:\/\/|\/+$)/gi, '')}</span>
    </span>
  );
};

export default ProfileName;
