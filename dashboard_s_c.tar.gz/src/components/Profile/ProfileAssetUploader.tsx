import React, { Component } from 'react';

// Components
import { AssetUploader } from 'components/forms';
import { Button, ButtonGroup, LoadingState } from 'components/UI';
import Link from 'components/UI/Link';

// Utils
import autobind from 'utils/autobind';

type Props = {
  title: string;
  text: string;
  note: string;
  btnCancel: string;
  btnChange: string;
  btnRemove: string;
  btnUpload: string;
  dropText: string;
  fileText: string;
  current: string;
  isLoading: boolean;
  editing: boolean;
  file: File & { preview: string };
  profileId: string;
  assetId: string;
  cancelAsset: (...args: any[]) => void;
  changeAsset: (...args: any[]) => void;
  removeAsset: (...args: any[]) => void;
  selectAsset: (...args: any[]) => void;
  uploadAsset: (...args: any[]) => void;
};

class ProfileAssetUploader extends Component<Props> {
  static defaultProps = {
    title: 'Uploader',
    text: '',
    note: '',
    btnCancel: 'Cancel',
    btnChange: 'Change',
    btnRemove: 'Remove',
    btnUpload: 'Upload',
    dropText: 'Drop an image here, or click to select.',
    fileText: 'File',
  };
  constructor(props: Props) {
    super(props);

    autobind(this);
  }

  handleCancel(): void {
    const { cancelAsset, profileId, assetId } = this.props;
    cancelAsset(profileId, assetId);
  }

  handleChange(): void {
    const { changeAsset, profileId, assetId } = this.props;
    changeAsset(profileId, assetId);
  }

  handleFileDrop(files): void {
    const { selectAsset, profileId, assetId } = this.props;
    selectAsset(profileId, assetId, files[0]);
  }

  handleFileDropRejected(_files: any): void {
    // Do nothing for now (Sorry :( )
  }

  handleRemove(): void {
    const { removeAsset, profileId, assetId } = this.props;
    removeAsset(profileId, assetId);
  }

  handleUpload(): void {
    const { uploadAsset, profileId, assetId, file } = this.props;
    uploadAsset(profileId, assetId, file);
  }

  render(): React.ReactElement {
    const {
      title,
      text,
      note,
      dropText,
      fileText,
      btnCancel,
      btnChange,
      btnRemove,
      btnUpload,
      isLoading,
      current,
      editing,
      file,
      assetId,
    } = this.props;

    // Empty preview gives dropzone
    let preview = '';

    // Preview selected file, if any
    if (file) {
      preview = file.preview;
      // Preview current if any and not editing
    } else if (current && !editing) {
      preview = current;
    }

    return (
      <div className="custom-asset-uploader-wrapper">
        <label className="l-form-label" htmlFor={`asset-dropzone-${assetId}`}>
          {title} {text}
        </label>

        <LoadingState isLoading={isLoading} delay={0} compact>
          <div>
            {preview !== '' && (
              <div className="asset-preview">
                <figure>
                  <img alt="" src={preview} />
                </figure>
                {file && (
                  <p>
                    <small>
                      {fileText}: {file.name}
                    </small>
                  </p>
                )}
              </div>
            )}
            {preview === '' && (
              <AssetUploader
                // eslint-disable-next-line @typescript-eslint/no-empty-function
                onDelete={(): void => {}}
                accept={['image/jpeg', 'image/pjpeg', 'image/png']}
                multiple={false}
                onDrop={this.handleFileDrop}
                onDropReject={this.handleFileDropRejected}
                name={assetId}
                dropText={dropText}
                limit={1}
                value={file}
                showPreview
              />
            )}
            <ButtonGroup className="custom-asset-uploader-wrapper__button-group">
              {file !== null && (
                <Button primary onClick={this.handleUpload}>
                  {btnUpload}
                </Button>
              )}

              {file === null && preview !== '' && current !== '' && (
                <Button primary onClick={this.handleChange}>
                  {btnChange}
                </Button>
              )}
              {current !== '' && preview === current && (
                <Link noUnderline linkStyle="danger" onClick={this.handleRemove}>
                  {btnRemove}
                </Link>
              )}
              {preview !== current && <Button onClick={this.handleCancel}>{btnCancel}</Button>}
            </ButtonGroup>
            {note && (
              <p className="custom-asset-uploader-wrapper__note">
                <small>{note}</small>
              </p>
            )}
          </div>
        </LoadingState>
      </div>
    );
  }
}

export default ProfileAssetUploader;
