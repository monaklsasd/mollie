import React from 'react';
import { useIntl } from 'react-intl';
import Select from 'components/forms/Select';

type SelectProps = React.ComponentProps<typeof Select>;

type Props = SelectProps & {
  prependOption?: {
    value: number;
    label: string;
  };
  from?: number;
  to?: number;
  value: number;
};

const SelectMonth: React.FC<Props> = ({
  from = 1,
  prependOption,
  to = 12,
  value,
  ...otherProps
}) => {
  const intl = useIntl();
  const now = new Date();
  const data: { value: string; label: string }[] = [];

  if (prependOption) {
    data.push({
      value: String(prependOption.value),
      label: prependOption.label,
    });
  }

  for (let month = from; month <= to; month++) {
    data.push({
      value: String(month),
      label: intl.formatDate(new Date(now.getFullYear(), month - 1, 1), {
        month: 'long',
      }) /* Javascript: jan = 0, dec = 11 */,
    });
  }

  return <Select {...otherProps} options={data} value={String(value)} />;
};

export default SelectMonth;
