import React from 'react';
import classNames from 'classnames';
import { ErrorMessage, connect, FormikContext } from 'formik';
import { FormattedMessage } from 'react-intl';

import RadioButton from 'components/forms/RadioButton';

// Types
import { ClassnamesFunction } from 'types/helpers';

// Styles
import './styles.scss';

type Props = {
  splitColumns?: boolean;
  children: (...args: any[]) => React.ReactElement;
  label?: React.ReactNode;
  help?: React.ReactNode;
  name: string;
};

const getClass: ClassnamesFunction<Props> = ({ splitColumns }) =>
  classNames('radio-button-group', {
    'radio-button-group--split-columns': splitColumns,
  });

const RadioButtonGroup: React.FC<Props & { formik: FormikContext<any> }> = ({
  children,
  name,
  formik,
  splitColumns,
  label,
  help,
}) => {
  const fieldProps = {
    onChange: formik?.handleChange,
    onBlur: formik?.handleBlur,
    name,
    currentValue: formik?.values[name],
  };

  // Set a default RadioButton with fieldProps. RadioButton only needs an Id.
  const RadioButtonInstance = (customProps: Record<string, any>): React.ReactElement => (
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    <RadioButton {...fieldProps} {...customProps} />
  );

  return (
    <React.Fragment>
      {label && <div className="radio-button-group__label">{label}</div>}
      <div className={getClass({ splitColumns })}>{children(RadioButtonInstance)}</div>
      {help && <p className="radio-button-group__help">{help}</p>}
      <ErrorMessage name={name}>
        {(msg): React.ReactNode => (
          <p className="radio-button-group__error">
            {typeof msg === 'string' ? msg : <FormattedMessage {...msg} />}
          </p>
        )}
      </ErrorMessage>
    </React.Fragment>
  );
};

export default connect<Props>(RadioButtonGroup);
