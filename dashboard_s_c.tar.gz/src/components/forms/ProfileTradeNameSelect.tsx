import React, { Component } from 'react';
import { connect } from 'react-redux';
import { uniqBy } from 'lodash';

// Utils
import autobind from 'utils/autobind';

// Redux
import { TYPE_QUERY_REGISTRATION_NUMBER } from 'reduxState/modules/organizationSuggestions/constants';
import { getOrganization } from 'reduxState/modules/organization/selectors';
import { getOrganizationLocalization } from 'reduxState/modules/organizationLocalizations/selectors';
import { fetchOrganizationSuggestions } from 'reduxState/modules/organizationSuggestions/actions';
import { getOrganizationSuggestions } from 'reduxState/modules/organizationSuggestions/selectors';

// Components
import { Autosuggest } from 'components/forms';

// Types
import { State } from 'reduxState/types';
import { OrganizationState } from 'reduxState/modules/organization/types';
import { OrganizationLocalization } from 'reduxState/modules/organizationLocalizations/types';
import { OrganizationSuggestionsState } from 'reduxState/modules/organizationSuggestions/types';

// Constant
const NR_OF_SUGGESTIONS = 6;

const constructOption = <T extends string>(value: T): { value: T; label: T } => ({
  // Add the organization name.
  value,
  label: value,
});

const constructOptions = (organization, suggestions): ReturnType<typeof uniqBy> => {
  // Build the suggested options for the trade name
  const options = [
    constructOption(organization.name), // Add the organization name, this should be preloaded data.
  ];

  // Add the suggestions from our organizations-search API (+trade names).
  if (suggestions && suggestions.data) {
    suggestions.data.forEach(suggestion => {
      if (suggestion.officialName) {
        options.push(constructOption(suggestion.officialName));
      }

      if (suggestion.tradeNames.length) {
        suggestion.tradeNames.forEach(tradeName => {
          options.push(constructOption(tradeName));
        });
      }
    });
  }

  const cleanOptions = options.filter(option => option === undefined || !!(option && option.value));

  return uniqBy(cleanOptions, 'value');
};

const getSuggestionValue = (suggestion: Suggestion): string => suggestion.value;
const shouldRenderSuggestions = (): true => true;
// Empty function to satisfy propType requirements of React Autosuggest
// eslint-disable-next-line @typescript-eslint/no-empty-function
const autosuggestNoop = (): void => {};

type Suggestion = { value: string };

type Props = {
  organization: OrganizationState;
  fetchOrganizationSuggestions: Function;
  onChange: (event: any) => void;
  placeholder: string;
  suggestions: OrganizationSuggestionsState;
  value: string;
  id: string;
  localization: OrganizationLocalization;
};

export class ProfileTradeName extends Component<Props> {
  constructor(props) {
    super(props);

    autobind(this);
  }

  componentDidMount(): void {
    const {
      organization: { registrationNumber, countryCode },
      fetchOrganizationSuggestions,
    } = this.props;

    if (registrationNumber && countryCode) {
      fetchOrganizationSuggestions(
        countryCode,
        registrationNumber,
        NR_OF_SUGGESTIONS,
        TYPE_QUERY_REGISTRATION_NUMBER,
      );
    }
  }

  handleOnChange(e): void {
    e.preventDefault();

    if (e.key === 'Enter') {
      return;
    }

    this.props.onChange(e.target.value);
  }

  handleSuggestionSelected(e, suggestion): void {
    e.nativeEvent.stopImmediatePropagation();
    if (suggestion.method === 'enter') {
      e.preventDefault();
    }
    this.props.onChange(suggestion.suggestionValue);
  }

  render(): React.ReactElement {
    const { organization, placeholder, suggestions, value, id, ...otherProps } = this.props;
    // Build the suggested options for the trade name.
    const options = constructOptions(organization, suggestions);

    return (
      // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
      // @ts-ignore
      <Autosuggest
        suggestions={options}
        onSuggestionSelected={this.handleSuggestionSelected}
        getSuggestionValue={getSuggestionValue}
        renderSuggestion={getSuggestionValue}
        shouldRenderSuggestions={shouldRenderSuggestions}
        onSuggestionsClearRequested={autosuggestNoop}
        onSuggestionsFetchRequested={autosuggestNoop}
        inputProps={{
          autoComplete: 'none',
          placeholder,
          value,
          id,
          onChange: this.handleOnChange,
        }}
        {...otherProps}
      />
    );
  }
}

type StateProps = {
  organization: Props['organization'];
  localization: Props['localization'];
  suggestions: Props['suggestions'];
};

const mapStateToProps = (state: State): StateProps => ({
  organization: getOrganization(state) as OrganizationState,
  localization: getOrganizationLocalization(state) as OrganizationLocalization,
  suggestions: getOrganizationSuggestions(state) as OrganizationSuggestionsState,
});

const mapDispatchToProps = {
  fetchOrganizationSuggestions,
};

export default connect(mapStateToProps, mapDispatchToProps)(ProfileTradeName);
