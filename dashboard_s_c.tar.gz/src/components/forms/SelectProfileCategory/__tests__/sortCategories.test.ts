import { sortCategories } from '../';
import mccsCategories from 'reduxState/modules/mccCategories/__fixtures__/mccsCategories';

describe('SelectProfileCategory', () => {
  describe('sortCategories', () => {
    it("should sort the categories by label and put the 'Other' value at the end", () => {
      const result = sortCategories(mccsCategories);

      expect(result).toMatchSnapshot();

      const last = result.pop();

      // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
      // @ts-ignore
      expect(last.value).toBe('0');
      // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
      // @ts-ignore
      expect(last.label).toBe('Other');
    });
  });
});
