import React from 'react';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';

// Components
import Select from 'components/forms/Select';

// Redux
import { getMccCategories } from 'reduxState/modules/mccCategories/selectors';

// Types
import { State } from 'reduxState/types';
import { MccCategoriesState } from 'reduxState/modules/mccCategories/types';

type SelectProps = React.ComponentProps<typeof Select>;

type Props = {
  categories: MccCategoriesState;
} & SelectProps;

type TransformedCategory = { value: string; label: string };

export const sortCategories = (categories: MccCategoriesState): TransformedCategory[] =>
  Object.keys(categories)
    .map<TransformedCategory>(key => ({
      value: key,
      label: categories[key],
    }))
    .sort((a, b) => {
      // Place the 'Other' value always at the end
      if (a.value === '0') {
        return 1;
      } else if (b.value === '0') {
        return -1;
      }

      // Taken from https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/sort
      // Ignore casing
      const labelA = a.label.toUpperCase();
      const labelB = b.label.toUpperCase();

      if (labelA < labelB) {
        return -1;
      }

      if (labelA > labelB) {
        return 1;
      }

      return 0;
    });

const SelectProfileCategory: React.FC<Props> = ({ categories, ...props }) => (
  <FormattedMessage
    id="select-profile-category-placeholder"
    defaultMessage="Please select a category">
    {(placeholder: string): React.ReactElement => (
      <Select
        options={sortCategories(categories)}
        placeholder={placeholder}
        inFormikForm
        {...props}
      />
    )}
  </FormattedMessage>
);

const mapStateToProps = (state: State): { categories: Props['categories'] } => ({
  categories: getMccCategories(state),
});

export default connect(mapStateToProps)(SelectProfileCategory);
