import React from 'react';

import classNames from 'classnames';

// Components
import { ReactComponent as IconCheck } from 'assets/icons/check.svg';

import './styles.scss';
import { ClassnamesFunction } from 'types/helpers';

const getClass: ClassnamesFunction<Props> = ({ label, disabled, className }) =>
  classNames('checkbox', className, {
    'checkbox--disabled': disabled,
    'checkbox--with-label': label,
  });

const getLabelClass: ClassnamesFunction<Props> = ({ labelClassName }) =>
  classNames('checkbox__label', labelClassName);

type Props = {
  onChange?: (event: React.ChangeEvent<HTMLInputElement>) => void;
  onBlur?: (event: React.FocusEvent<HTMLInputElement>) => void;
  onFocus?: (event: React.FocusEvent<HTMLInputElement>) => void;
  label: React.ReactNode;
  insideLabel?: boolean;
  name?: string;
  id?: string;
  value?: string | boolean;
  checked?: boolean;
  disabled?: boolean;
  className?: string;
  labelClassName?: string;
};

const Checkbox = ({
  id,
  name,
  insideLabel,
  label,
  disabled,
  onBlur,
  onFocus,
  className,
  value,
  onChange,
  labelClassName,
  ...rest
}: Props): React.ReactElement => {
  const LabelTag = insideLabel ? 'div' : 'label';
  const cid = id && !insideLabel ? id : undefined;
  return (
    <LabelTag
      className={getClass({ label, disabled, className })}
      htmlFor={cid && `input-checkbox-${cid}`}>
      <input
        className="checkbox__input"
        id={cid && `input-checkbox-${cid}`}
        name={name}
        type="checkbox"
        onChange={onChange}
        value={Number(!!value)}
        checked={!!value}
        disabled={disabled}
        onBlur={onBlur}
        onFocus={onFocus}
        {...rest}
      />

      <span className="checkbox__visual">{value && <IconCheck className="checkbox__icon" />}</span>
      <span className={getLabelClass({ labelClassName })}>{label}</span>
    </LabelTag>
  );
};

export default Checkbox;
