import React, { Component } from 'react';
import { find } from 'lodash';
import { defineMessages, injectIntl, IntlShape } from 'react-intl';
import ReactSelect, { components } from 'react-select';
import classNames from 'classnames';

import { IntlMessages } from 'types/intl';
import { ClassnamesFunction } from 'types/helpers';

import { ReactComponent as SelectChevron } from 'assets/icons/select-chevron.svg';

import './styles.scss';

interface Props {
  className?: string;
  clearable?: boolean;
  customItemsAllowed?: boolean;
  intl: IntlShape;
  onBlur?: React.MouseEventHandler;
  onChange?: (arg: number | string) => void;
  options?: Record<string, any>;
  simpleValue?: boolean;
  placeholder?: string;
  value?: string | number;
  inFormikForm?: boolean;
  onGrey?: boolean;
  disabled?: boolean;
  styles?: Record<any, string>;
  noOptionsMessage?: string;
  menuPlacement?: string;
  id?: string;
  isLoading?: boolean;
  autoFocus?: boolean;
}

const getClass: ClassnamesFunction<Props> = ({ className, onGrey }) =>
  classNames('c-select', 'l-form-control', className, {
    'c-select--on-grey-bg': onGrey,
  });

const messages: IntlMessages = defineMessages({
  noResultsLabel: {
    id: 'react-select-no-results-label',
    defaultMessage: 'No results',
  },
});

/*
 * Needed to override autocomplete="off" that react-select hardcodes
 * Passed through the "components" prop
 * autoComplete="off" is ignored by Chrome:
 * https://developer.mozilla.org/en-US/docs/Web/Security/Securing_your_site/Turning_off_form_autocompletion
 */
const Input: React.FC<Props> = props => {
  // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
  // @ts-ignore
  return <components.Input {...props} autoComplete="none" />;
};

const DropdownIndicator: React.FC<Props> = props => {
  return (
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    <components.DropdownIndicator {...props}>
      <div className="c-select__control-chevron">
        <SelectChevron />
      </div>
    </components.DropdownIndicator>
  );
};

class Select extends Component<Props> {
  static defaultProps = {
    clearable: false,
    simpleValue: false,
    customItemsAllowed: false,
  };

  getValue(): Nullable<string> {
    const { value, options } = this.props;

    if (typeof value === 'undefined' || value === '') {
      return null;
    }

    // Force to string since value can also be an integer
    return find(options, { value: String(value) });
  }

  onChange = (value: any): void => {
    // Formik doesn’t like value being undefined, fall back to an empty string.
    const parsedValue = (value && value.value) || '';
    this.props.onChange && this.props.onChange(parsedValue);
  };

  onBlur = (e): void => {
    const { onBlur, inFormikForm } = this.props;

    if (inFormikForm) {
      onBlur && onBlur(e);
    }
  };

  render(): Nullable<React.ReactElement> {
    const {
      options,
      disabled,
      placeholder,
      clearable,
      className,
      intl,
      customItemsAllowed,
      styles,
      noOptionsMessage,
      menuPlacement,
      id,
      onGrey,
      ...otherProps
    } = this.props;
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    const Tag = customItemsAllowed ? ReactSelect.Creatable : ReactSelect;

    return (
      <Tag
        {...otherProps}
        className={getClass({ className, onGrey })}
        classNamePrefix="c-select"
        optionClassName="c-select-input__option"
        options={options}
        isClearable={clearable}
        noOptionsMessage={(): string =>
          noOptionsMessage || intl.formatMessage(messages.noResultsLabel)
        }
        value={this.getValue()}
        onBlur={this.onBlur}
        onChange={this.onChange}
        placeholder={placeholder}
        isDisabled={disabled}
        inputId={id}
        components={{ Input, DropdownIndicator }}
        menuPlacement={menuPlacement || 'auto'}
        styles={{
          ...styles,
          indicatorSeparator: (): null => null,
        }}
      />
    );
  }
}

export { Select };

export default injectIntl(Select);
