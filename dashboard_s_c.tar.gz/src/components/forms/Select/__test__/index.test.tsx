import React from 'react';
import toJson from 'enzyme-to-json';
import Select from '../index';

import { shallowWithIntl } from 'helpers/createComponentWithIntl';

describe('<Select>', () => {
  it('renders three <Select /> components', () => {
    const options = [
      { label: 'testLabel 1', value: 'The value of 1' },
      { label: 'testLabel 2', value: 'The value of 2' },
    ];
    const component = shallowWithIntl(<Select options={options} />).dive();

    expect(toJson(component)).toMatchSnapshot();
  });

  it('should handle custom onChange event', () => {
    const handleOnChange = jest.fn();
    const handleOnBlur = jest.fn();
    const mockEvent = {
      target: { label: 'test', value: 'SomeValue' },
    };

    const component = shallowWithIntl(
      <Select options={[]} onChange={handleOnChange} onBlur={handleOnBlur} />,
    ).dive();

    component.simulate('change', mockEvent);
    component.simulate('blur', mockEvent);

    // Make sure onChange is been called with the right value
    expect(handleOnChange).toHaveBeenCalledWith(mockEvent);

    // Blur is needed so we know it's been called (for set touched or custom fn)
    expect(handleOnBlur).toHaveBeenCalledWith(mockEvent);
  });
});
