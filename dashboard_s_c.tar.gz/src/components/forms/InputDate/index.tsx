import React from 'react';
import MaskedInput, { MaskedInputProps } from 'react-text-mask';
import createAutoCorrectedDatePipe from 'text-mask-addons/dist/createAutoCorrectedDatePipe';

import './styles.scss';

// type MaskedInputProps = React.ComponentProps<typeof MaskedInput>;

type Props = MaskedInputProps & {
  value: string;
  onBlur: () => void;
  onChange: (arg: any) => void;
};

const autoCorrectedDatePipe = createAutoCorrectedDatePipe('dd-mm-yyyy');

const reverse = (str: string): string => {
  if (!str) {
    return '';
  }

  return str
    .split('-')
    .reverse()
    .join('-');
};

const InputDate: React.FC<Props> = props => {
  return (
    <MaskedInput
      className="l-form-control input-date"
      mask={[/\d/, /\d/, '-', /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/]}
      keepCharPositions
      pipe={autoCorrectedDatePipe}
      {...props}
      onChange={(e: React.SyntheticEvent<any>): void => {
        props.onChange(reverse((e.target as HTMLInputElement).value));
      }}
      value={reverse(props.value)}
    />
  );
};

export default InputDate;
