import React from 'react';
import Select from 'components/forms/Select';

import { getCurrentYearNumber } from 'utils/getCurrentDateNumbers';

type SelectProps = React.ComponentProps<typeof Select>;

type Props = SelectProps & {
  from: number;
  to?: number;
  value: number | string;
};

const SelectYear: React.FC<Props> = ({
  from,
  to = getCurrentYearNumber(),
  value,
  ...otherProps
}) => {
  const data: { value: string; label: string }[] = [];

  for (let year = to; year >= from; year--) {
    data.push({
      value: String(year),
      label: String(year),
    });
  }

  return <Select {...otherProps} options={data} value={String(value)} />;
};

export default SelectYear;
