import React from 'react';

import { FastField, Field, connect, getIn, FormikActions, FormikProps } from 'formik';
import { FormattedMessage } from 'react-intl';
import classNames from 'classnames';

// Types
import { ClassnamesFunction } from 'types/helpers';

import './styles.scss';

const getClass: ClassnamesFunction<Props> = ({ className }) =>
  classNames('formik-group', className);

const getLabelClass: ClassnamesFunction<Props> = ({ hideLabel, labelClassName }) =>
  classNames(
    'formik-group__label',
    {
      'u-screenreader-only': hideLabel,
    },
    labelClassName,
  );

type FieldType = {
  name: string;
  value: any;
  onChange: (value: any) => void;
  onBlur: () => void;
};

type FormType = {
  setFieldTouched: FormikActions<any>['setFieldTouched'];
  setFieldValue: FormikActions<any>['setFieldValue'];
};

type FieldProps = {
  field: FieldType;
  form: FormType;
};

type ChildrenArgs = FieldType & {
  id: string;
};

type ChildrenRenderProp = (args: ChildrenArgs) => React.ReactElement;

type Props = {
  id?: string;
  name: string;
  label?: React.ReactNode;
  children: ChildrenRenderProp;
  className?: string;
  hideLabel?: boolean;
  labelClassName?: string;
  help?: React.ReactNode;
  fastField?: boolean;
};

class FormikGroup extends React.Component<Props & { formik: FormikProps<any> }> {
  static defaultProps = {
    hideLabel: false,
    fastField: true,
  };

  handleChange = ({ name, onChange }: FieldType, { setFieldValue }: FormType) => (
    eventOrValue: React.SyntheticEvent<any> | string | File[],
  ): void => {
    // Input is an event
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    if (eventOrValue && (eventOrValue.target as HTMLElement)) {
      onChange(eventOrValue);
      return;
    }

    setFieldValue(name, eventOrValue);
  };

  handleBlur = ({ name }: FieldType, { setFieldTouched }: FormType) => (): void => {
    /*
     * Ideally this method would use onBlur just like this.handleChange above.
     * However, React Select fires the onBlur event on a shim input, instead
     * of the input that contains the passed in name:
     *
     * <input id="input-test" /> <-- This fires the event
     * <input type="hidden" name="test" /> <-- This contains the actual name
     *
     * Therefore the event doesn’t update the correct value in Formik. We’re
     * using setFieldTouched directly as a workaround.
     */
    setFieldTouched(name, true);
  };

  renderError(): React.ReactElement | void {
    const { formik, name } = this.props;
    const error = getIn(formik.errors, name);

    if (error && getIn(formik.touched, name)) {
      return (
        <p className="formik-group__error">
          {typeof error === 'string' ? error : <FormattedMessage {...error} />}
        </p>
      );
    }
  }

  render(): React.ReactElement {
    const {
      label,
      id,
      name,
      children,
      className,
      hideLabel,
      labelClassName,
      help,
      fastField,
    } = this.props;

    if (process.env.NODE_ENV === 'development' && typeof children !== 'function') {
      throw new Error(
        `<FormikGroup> expects children as function, received ${typeof children} from field ${name}.`,
      );
    }

    const Tag = fastField ? FastField : Field;

    return (
      <div className={getClass({ className })} data-control-name={name}>
        {label && (
          <label
            className={getLabelClass({ hideLabel, labelClassName })}
            htmlFor={`input-${id || name}`}>
            {label}
          </label>
        )}
        <Tag
          name={name}
          render={({ field, form }: FieldProps): React.ReactElement => (
            <React.Fragment>
              {children({
                ...field,
                onChange: this.handleChange(field, form),
                onBlur: this.handleBlur(field, form),
                id: `input-${id || name}`,
              })}
              {help && <p className="formik-group__help">{help}</p>}
              {this.renderError()}
            </React.Fragment>
          )}
        />
      </div>
    );
  }
}

export default connect<Props>(FormikGroup);
