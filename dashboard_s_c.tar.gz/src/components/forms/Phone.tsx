import React from 'react';
import classNames from 'classnames';
import { connect } from 'react-redux';
import formatPhoneNumber from 'utils/formatPhoneNumber';
import isPhoneNumber from 'utils/isPhoneNumber';

import { getOrganizationCountryCode } from 'reduxState/modules/organization/selectors';
import { ClassnamesFunction } from 'types/helpers';

import { State } from 'reduxState/types';
import { CountryCode } from 'libphonenumber-js';

type Props = {
  onBlur: (event: React.FocusEvent<HTMLInputElement>) => void;
  onChange: Function;
  countryCode: string;
  initialValue?: string;
  value?: string;
  placeholder?: string;
  name?: string;
  id?: string;
  onGrey?: boolean;
};

const getClass: ClassnamesFunction<Props> = ({ onGrey }) =>
  classNames('l-form-control', {
    'l-form-control--on-grey-bg': onGrey,
  });

class Phone extends React.Component<Props> {
  static defaultProps = {
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    onChange: (): void => {},
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    onBlur: (): void => {},
  };

  componentWillUpdate(nextProps): void {
    const { initialValue, countryCode, onChange } = nextProps;

    if (
      !initialValue ||
      initialValue === this.props.initialValue ||
      initialValue === this.props.value
    ) {
      return;
    }

    let formattedPhoneNumber;

    // Backwards compatibility fix:
    // If the phone number from the back-end is not a valid,
    // use the countryCode to properly format the number.
    if (isPhoneNumber(initialValue)) {
      formattedPhoneNumber = formatPhoneNumber(initialValue);
    } else {
      // This will try to fix the phone number, but if the
      // number is plain wrong it will return it as is.
      formattedPhoneNumber = formatPhoneNumber(initialValue, countryCode);
    }

    onChange(formattedPhoneNumber);
  }

  handleChange = (e: React.ChangeEvent<any>): void => {
    const { countryCode, onChange } = this.props;

    const value = formatPhoneNumber(e.target.value, countryCode as CountryCode);

    onChange(value);
  };

  render(): React.ReactElement {
    const { value, onBlur, name, id, onGrey } = this.props;

    return (
      <input
        value={value}
        onBlur={onBlur}
        name={name}
        id={id}
        className={getClass({ onGrey })}
        type="tel"
        onChange={this.handleChange}
      />
    );
  }
}

const mapStateToProps = (state: State): { countryCode: Props['countryCode'] } => ({
  countryCode: getOrganizationCountryCode(state),
});

export default connect(mapStateToProps)(Phone);
