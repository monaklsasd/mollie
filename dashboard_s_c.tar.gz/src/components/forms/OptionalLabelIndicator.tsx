import React from 'react';
import { FormattedMessage } from 'react-intl';
import commonMessage from 'messages/forms';

const OptionalLabelIndicator: React.FC = ({ children }) => (
  <FormattedMessage {...commonMessage.fieldOptional} values={{ labelElement: children }} />
);

export default OptionalLabelIndicator;
