import React from 'react';
import { injectIntl } from 'react-intl';
import { connect } from 'react-redux';

// Components
import Select from 'components/forms/Select';

// Redux
import { getLocalizedRegistrationTypes } from 'reduxState/modules/organizationLocalizations/selectors';

// Types
import { IntlShape } from 'react-intl';

// Messages
import { formPlaceholders } from 'messages/forms/OrganizationFormMessages';
import { FormikActions } from 'formik';

/*
 * Convert this:
 * {
 *   foundation: {
 *       name: 'Foundation',
 *       registrationNumberRequired: true
 *   }
 * }
 *
 * into this:
 * [{
 *   value: 'foundation',
 *   label: 'Foundation',
 * }]
 */

type RT = { value: string; label: string }[];

const getOptions = (registrationTypes: Record<string, any>): RT =>
  Object.keys(registrationTypes).reduce(
    (acc: RT, curr) =>
      acc.concat({
        value: curr,
        label: registrationTypes[curr].name,
      }),
    [],
  );

type Props = {
  countryCode: Maybe<string>;
  name: string;
  disabled?: boolean;
  setFieldValue: FormikActions<any>['setFieldValue'];
  intl: IntlShape;
  registrationTypes: {
    [key: string]: {
      name: string;
      registrationNumberRequired: boolean;
    };
  };
};

class RegistrationTypeSelect extends React.Component<Props> {
  componentDidUpdate(prevProps): void {
    const { countryCode, setFieldValue, name } = this.props;

    // Clear field when country changes, since each country has its own registration types
    if (countryCode && countryCode !== prevProps.countryCode) {
      setFieldValue(name, '');
    }
  }

  render(): React.ReactElement {
    const { registrationTypes, intl, ...rest } = this.props;

    return (
      <Select
        {...rest}
        placeholder={intl.formatMessage(formPlaceholders.registrationType)}
        options={getOptions(registrationTypes)}
        inFormikForm
      />
    );
  }
}

const mapStateToProps = (state, props) => ({
  registrationTypes: getLocalizedRegistrationTypes(state, props.countryCode),
});

export default connect(mapStateToProps)(injectIntl(RegistrationTypeSelect));
