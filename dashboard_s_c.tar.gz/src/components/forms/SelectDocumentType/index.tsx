import React from 'react';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';

// Components
import Select from 'components/forms/Select';

// Redux
import { getLocalizedIdentityDocumentTypes } from 'reduxState/modules/organizationLocalizations/selectors';

// Internals
import messages from './messages';

// Types
import { State } from 'reduxState/types';

type SelectProps = React.ComponentProps<typeof Select>;
type Props = SelectProps & {
  documentTypes: string[];
};

type SelectOption = { value: string; label: React.ReactElement };

const getSelectOptions = (documentTypes: Props['documentTypes']): SelectOption[] =>
  documentTypes.reduce((carry: SelectOption[], documentType: string) => {
    if (messages[documentType]) {
      carry.push({
        value: documentType,
        label: <FormattedMessage {...messages[documentType]} />,
      });
    }

    return carry;
  }, []);

const SelectDocumentType: React.FC<Props> = ({ documentTypes, ...props }) => (
  <FormattedMessage {...messages.placeholder}>
    {(placeholder: string): React.ReactElement => (
      <Select
        options={getSelectOptions(documentTypes)}
        placeholder={placeholder}
        // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
        // @ts-ignore
        isSearchable={false}
        {...props}
      />
    )}
  </FormattedMessage>
);

const mapStateToProps = (state: State): { documentTypes: Props['documentTypes'] } => ({
  documentTypes: getLocalizedIdentityDocumentTypes(state),
});

export default connect(mapStateToProps)(SelectDocumentType);
