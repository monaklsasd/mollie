import { defineMessages } from 'react-intl';
import { IntlMessages } from 'types/intl';

const messages: IntlMessages = defineMessages({
  passport: {
    id: 'select-document-type-passport',
    defaultMessage: 'Passport',
  },
  idcard: {
    id: 'select-document-type-type-idcard',
    defaultMessage: 'ID card',
  },
  residencepermit: {
    id: 'select-document-type-type-residencepermit',
    defaultMessage: 'Residence permit',
  },
  placeholder: {
    id: 'select-document-type-placeholder',
    defaultMessage: 'Please select a document type',
  },
});

export default messages;
