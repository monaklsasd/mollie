import React, { Component } from 'react';
import classNames from 'classnames';
import matchSuggestion from 'utils/matchSuggestion';

import './styles.scss';

const getClass = ({ valid }: Partial<Props>, { hasFocus }: Partial<State>): string =>
  classNames('c-multi-input', 'l-form-control', {
    'has-focus': hasFocus,
    'is-invalid': valid,
  });

const getStringTillComma = (str: string): string => str.substr(0, str.indexOf(','));

interface Props {
  id?: string;
  onChange?: (...args) => void;
  onBlur?: (...args) => void;
  onFocus?: (...args) => void;
  suggestions?: any[];
  normalizer?: (...args) => void;
  value?: string;
  placeholder?: string;
  limit?: number;
  valid?: boolean;
}

interface State {
  hasFocus: boolean;
  inputValue: string;
  executedNormalizer: boolean;
}

class MultiInput extends Component<Props, State> {
  constructor(props) {
    super(props);

    this.state = {
      hasFocus: false,
      inputValue: '',
      executedNormalizer: false,
    };
  }

  componentDidUpdate(prevProps, prevState): void {
    if (this.state.executedNormalizer || !this.state.inputValue || !prevState.inputValue) {
      return;
    }
    // If the length difference is more than one, that means the new value
    // is a suggestion and we need to highlight the suggested part
    const oldInputLength = prevState.inputValue.length;
    const newInputLength = this.state.inputValue.length;

    if (newInputLength - oldInputLength > 1) {
      (this.input as HTMLInputElement).setSelectionRange(oldInputLength, newInputLength);
    }
  }

  input: Nullable<HTMLInputElement> = null;
  valueArray: string[] = this.getValues(this.props);
  hiddenInput: Nullable<HTMLInputElement> = null;

  getValues(props): string[] {
    const { value, normalizer } = props;

    if (!value) {
      return [];
    }

    return value.split(',').map((x: string) => {
      if (!normalizer) {
        return x;
      }
      return normalizer(x);
    }) as string[];
  }

  handleFocus = (e): void => {
    this.setState({ hasFocus: true });

    // If the input is not empty when it receives focus, it means
    // there is an invalid value at the end of valueArray which
    // we need tot pop
    if (e.target.value) {
      this.popValue();
    }
  };

  handleBlur = (e): void => {
    this.setState({ hasFocus: false });

    if (e.target.value) {
      this.addValue(e.target.value);
    }
  };

  handleKeyDown = (e): void => {
    const fieldValue = e.target.value;

    switch (e.key) {
      case 'Backspace': {
        if (fieldValue) {
          return;
        }

        // If field is empty, remove last item from list
        this.popValue();
        break;
      }

      case 'Enter':
      case 'Tab': {
        if (!fieldValue) {
          return;
        }

        e.preventDefault();

        this.addValue(fieldValue);
        break;
      }

      default: {
        break;
      }
    }
  };

  handleKeyUp = (e): void => {
    const fieldValue = e.target.value;

    switch (e.key) {
      // If user presses comma key, strip all text before comma and
      // create a value out of it.
      case ',': {
        const value = getStringTillComma(fieldValue);

        this.addValue(value);

        break;
      }

      default: {
        if (!this.props.suggestions) {
          return;
        }

        // Check if there is a suggestion
        const suggestion = matchSuggestion(this.props.suggestions, fieldValue);

        // Check whether suggestion exists and is not already in the valueArray
        if (
          suggestion &&
          !this.valueArray.includes(suggestion as string) &&
          e.key !== 'Backspace'
        ) {
          this.setState({
            inputValue: suggestion as string,
          });
        }

        break;
      }
    }
  };

  handleChange = (e): void => {
    let value = e.target.value;

    // Execute normalizer when defined, except when the user presses
    // comma, which should add the value instead
    if (this.props.normalizer && e.target.value.slice(-1) !== ',') {
      value = this.props.normalizer(value);
    }

    this.setState({
      inputValue: value,
      executedNormalizer: value !== e.target.value,
    });
  };

  handleKeyDownOnValue = (e): void => {
    if (e.key !== 'Backspace') {
      return;
    }

    this.input && this.input.focus();
    this.handleDeleteValue(e);
  };

  handleDeleteValue = (e): void => {
    e.preventDefault();
    this.valueArray = this.valueArray.filter(value => value !== e.target.value);
    this.props.onChange && this.props.onChange(this.valueArray.join(','));
  };

  addValue(newValue): void {
    this.setState({
      inputValue: '',
    });

    // Is the value is already in the array, do not add it again
    if (this.valueArray.includes(newValue)) {
      return;
    }

    this.valueArray = ([] as string[]).concat(this.valueArray).concat(newValue);
    this.props.onChange && this.props.onChange(this.valueArray.join(','));
  }

  popValue(): void {
    if (!this.valueArray.length) {
      return;
    }

    this.valueArray = this.valueArray.slice(0, this.valueArray.length - 1);
    this.props.onChange && this.props.onChange(this.valueArray.join(','));
  }

  shouldInputBeDisabled = (): boolean => {
    const { limit } = this.props;

    // Do not disable input if there is no limit or limit hasn’t been reached
    if (!limit || (this.valueArray && this.valueArray.length < limit)) {
      return false;
    }

    return true;
  };

  render(): React.ReactNode {
    const { onBlur, onChange, onFocus, value, placeholder, id } = this.props;
    const inputDisabled = this.shouldInputBeDisabled();
    this.valueArray = this.getValues(this.props);

    return (
      <div className={getClass(this.props, this.state)}>
        {this.valueArray.map(internalValue => (
          <button
            key={internalValue}
            type="button"
            value={internalValue}
            onKeyDown={this.handleKeyDownOnValue}
            onClick={this.handleDeleteValue}
            className="c-multi-input__value">
            {internalValue}
          </button>
        ))}
        <div className="c-multi-input__input">
          <input
            ref={(i): void => {
              this.input = i;
            }}
            type="text"
            onKeyUp={this.handleKeyUp}
            onKeyDown={this.handleKeyDown}
            onFocus={this.handleFocus}
            onBlur={this.handleBlur}
            onChange={this.handleChange}
            value={this.state.inputValue}
            readOnly={inputDisabled}
            placeholder={placeholder}
            id={id}
          />
          <input
            ref={(i): void => {
              this.hiddenInput = i;
            }}
            type="hidden"
            value={value || ''}
            onBlur={onBlur}
            onFocus={onFocus}
            onChange={onChange}
          />
        </div>
      </div>
    );
  }
}

export default MultiInput;
