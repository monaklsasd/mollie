import React, { Component } from 'react';
import { injectIntl, defineMessages, MessageDescriptor, IntlShape } from 'react-intl';
import classNames from 'classnames';

import autobind from 'utils/autobind';

import './styles.scss';

const getClass = ({ className, buttonStyle, flexibleWidth }: Partial<Props>): string =>
  classNames(
    'c-input-stepper',
    {
      'c-input-stepper--arrow-buttons': buttonStyle === 'arrows',
      'c-input-stepper--flexible-width': flexibleWidth,
    },
    className,
  );

const getInBoundsValue = (min: Props['min'], max: Props['max'], value: Props['value']): number =>
  Math.max(min, Math.min(value, max));

const messages: { [key: string]: MessageDescriptor } = defineMessages({
  increase: {
    id: 'input-stepper-default-increase-label',
    defaultMessage: 'Increase',
  },
  decrease: {
    id: 'input-stepper-default-decrease-label',
    defaultMessage: 'Decrease',
  },
});

interface Props {
  value: number;
  min: number;
  max: number;
  onChange: (...args: any[]) => void;
  increaseLabel: string | MessageDescriptor;
  decreaseLabel: string | MessageDescriptor;
  className?: string;
  intl: IntlShape;
  buttonStyle: 'plusminus' | 'arrows';
  flexibleWidth?: boolean;
  inputName: string;
  name: string;
}

class InputStepper extends Component<Props> {
  static defaultProps = {
    increaseLabel: messages.increase,
    decreaseLabel: messages.decrease,
  };

  constructor(props) {
    super(props);

    autobind(this);
  }

  componentWillMount(): void {
    this.forceValueInBounds(this.props.value);
  }

  onBlur(e): void {
    this.forceValueInBounds(parseInt(e.target.value, 10));
  }

  forceValueInBounds(value): void {
    const { min, max, onChange } = this.props;

    // Keep value in between min/max bounds
    const valueInBounds = getInBoundsValue(min, max, value);

    if (value !== valueInBounds) {
      onChange(valueInBounds);
    }
  }

  handleDecrease(): void {
    const { onChange, min, max, value } = this.props;

    onChange(getInBoundsValue(min, max, value) - 1);
  }

  handleIncrease(): void {
    const { onChange, min, max, value } = this.props;

    onChange(getInBoundsValue(min, max, value) + 1);
  }

  handleChange(e): void {
    this.props.onChange(parseInt(e.target.value, 10));
  }

  renderLabel(label: string | MessageDescriptor): string {
    return typeof label === 'object' ? this.props.intl.formatMessage(label) : label;
  }

  render(): React.ReactNode {
    const {
      decreaseLabel,
      increaseLabel,
      value,
      min,
      max,
      className,
      buttonStyle,
      flexibleWidth,
      inputName,
    } = this.props;

    return (
      <div className={getClass({ className, buttonStyle, flexibleWidth })}>
        <input
          type="text"
          name={inputName}
          id={inputName}
          value={value}
          onChange={this.handleChange}
          onBlur={this.onBlur}
        />
        <button
          type="button"
          onClick={this.handleDecrease}
          className="c-input-stepper__minus"
          disabled={value === min}
          aria-controls={inputName}
          aria-label={this.renderLabel(decreaseLabel)}>
          <b>-</b>
        </button>
        <button
          type="button"
          onClick={this.handleIncrease}
          className="c-input-stepper__plus"
          disabled={value === max}
          aria-controls={inputName}
          aria-label={this.renderLabel(increaseLabel)}>
          <b>+</b>
        </button>
      </div>
    );
  }
}

export default injectIntl(InputStepper);
