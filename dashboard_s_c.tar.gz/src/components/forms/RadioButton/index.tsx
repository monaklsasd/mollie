import React from 'react';
import classNames from 'classnames';

import './styles.scss';
import { ClassnamesFunction } from 'types/helpers';

const getClass: ClassnamesFunction<Props> = ({ label, className }) =>
  classNames(
    'radio-button',
    {
      'radio-button--with-label': label,
    },
    className,
  );

type InputProps = React.DetailedHTMLProps<
  React.InputHTMLAttributes<HTMLInputElement>,
  HTMLInputElement
>;

type Props = InputProps & {
  className?: string;
  disabled?: boolean;
  id?: string;
  insideLabel?: boolean;
  label?: React.ReactNode;
  name: string;
  onBlur?: (event: React.FocusEvent<HTMLInputElement>) => void;
  onChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
  currentValue?: string;
  value: string | number;
};

const RadioButton: React.FC<Props> = ({
  name,
  id,
  insideLabel = false,
  label,
  value,
  currentValue,
  disabled,
  className,
  ...rest
}) => {
  const LabelTag = insideLabel ? 'div' : 'label';
  const cid = id && !insideLabel ? id : undefined;

  return (
    <LabelTag className={getClass({ label, className })} htmlFor={cid && `input-radio-${cid}`}>
      <input
        id={`input-radio-${id || value}`}
        type="radio"
        value={value}
        name={name}
        disabled={disabled}
        checked={currentValue === value}
        {...rest}
      />
      <span className="radio-button__visual" />
      {label}
    </LabelTag>
  );
};

export default RadioButton;
