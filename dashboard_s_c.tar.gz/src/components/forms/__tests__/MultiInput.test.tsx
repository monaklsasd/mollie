import React from 'react';
import { shallow } from 'enzyme';

import MultiInput from '../MultiInput';
import formatPhoneNumber from 'utils/formatPhoneNumber';

describe('<MultiInput>', () => {
  const props = {
    onChange: jest.fn(),
    onBlur: jest.fn(),
    onFocus: jest.fn(),
    value: '',
  };

  it('transforms a comma separated value into buttons', () => {
    const component = shallow(<MultiInput {...props} value="foo,bar" />);

    expect(component.find('.c-multi-input__value')).toHaveLength(2);
  });

  it('deletes last value when pressing backspace on empty input', () => {
    const onChange = jest.fn();
    const component = shallow(<MultiInput {...props} value="foo,bar" onChange={onChange} />);
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    component.find('.c-multi-input__input input[type="text"]').prop('onKeyDown')({
      target: {
        // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
        // @ts-ignore
        value: '',
      },
      key: 'Backspace',
    });

    expect(onChange).toBeCalledWith('foo');
  });

  it('calls onChange new value when pressing Enter key in a non-empty input', () => {
    const onChange = jest.fn();
    const preventDefault = jest.fn();
    const component = shallow(<MultiInput {...props} value="foo" onChange={onChange} />);
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    component.find('.c-multi-input__input input[type="text"]').prop('onKeyDown')({
      target: {
        // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
        // @ts-ignore
        value: 'bar',
      },
      preventDefault,
      key: 'Enter',
    });

    expect(onChange).toBeCalledWith('foo,bar');
    expect(preventDefault).toBeCalled();
  });

  it('calls onChange new value when pressing Tab key in a non-empty input', () => {
    const onChange = jest.fn();
    const preventDefault = jest.fn();
    const component = shallow(<MultiInput {...props} value="foo" onChange={onChange} />);
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    component.find('.c-multi-input__input input[type="text"]').prop('onKeyDown')({
      target: {
        // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
        // @ts-ignore
        value: 'bar',
      },
      preventDefault,
      key: 'Tab',
    });

    expect(onChange).toBeCalledWith('foo,bar');
    expect(preventDefault).toBeCalled();
  });

  it('calls onChange new value when blurring input while it is non-empty', () => {
    const onChange = jest.fn();
    const component = shallow(<MultiInput {...props} value="foo" onChange={onChange} />);
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    component.find('.c-multi-input__input input[type="text"]').prop('onBlur')({
      target: {
        // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
        // @ts-ignore
        value: 'bar',
      },
    });

    expect(onChange).toBeCalledWith('foo,bar');
  });

  it('does not prevent default action when pressing Enter key while in an empty form', () => {
    const preventDefault = jest.fn();
    const component = shallow(<MultiInput {...props} value="foo" />);
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    component.find('.c-multi-input__input input[type="text"]').prop('onKeyDown')({
      target: {
        // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
        // @ts-ignore
        value: '',
      },
      preventDefault,
      key: 'Enter',
    });

    expect(preventDefault).not.toBeCalled();
  });

  it('does not prevent default action when pressing Tab key while in an empty form', () => {
    const preventDefault = jest.fn();
    const component = shallow(<MultiInput {...props} value="foo" />);
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    component.find('.c-multi-input__input input[type="text"]').prop('onKeyDown')({
      target: {
        // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
        // @ts-ignore
        value: '',
      },
      preventDefault,
      key: 'Tab',
    });

    expect(preventDefault).not.toBeCalled();
  });

  it('sets input to readonly when limit is reached', () => {
    const component = shallow(<MultiInput {...props} value="foo,bar" limit={2} />);

    expect(component.find('.c-multi-input__input input[type="text"]').prop('readOnly')).toBe(true);
  });

  it('normalizes input', () => {
    const phoneNumber = '0206543210';
    const component = shallow(
      <MultiInput {...props} normalizer={(x): any => formatPhoneNumber(x, 'NL')} />,
    );

    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    component.instance().handleChange({
      target: {
        value: phoneNumber,
      },
    });

    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    expect(component.state().inputValue).toBe(formatPhoneNumber(phoneNumber, 'NL'));
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    expect(component.state().executedNormalizer).toBe(true);
  });
});
