import React from 'react';
import normalizeURL from 'forms/normalizers/URL';

type Props = React.DetailedHTMLProps<
  React.InputHTMLAttributes<HTMLInputElement>,
  HTMLInputElement
> & {
  onChange: (arg: string) => void;
  onBlur: (event: React.FocusEvent<HTMLInputElement>) => void;
};

class Url extends React.Component<Props> {
  handleOnBlur = (e: React.FocusEvent<HTMLInputElement>): void => {
    const val = e.target.value;
    this.props.onChange(normalizeURL(val) as string);
    this.props.onBlur(e);
  };

  render(): React.ReactElement {
    return (
      <input
        className="l-form-control"
        type="url"
        maxLength={255}
        {...this.props}
        onBlur={this.handleOnBlur}
      />
    );
  }
}

export default Url;
