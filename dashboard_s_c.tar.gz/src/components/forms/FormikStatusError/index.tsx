import React from 'react';
import { FormattedMessage } from 'react-intl';
import FormError from 'components/forms/FormError';

type Props = {
  status?: { error?: string };
};

const FormikStatusError: React.FC<Props> = ({ status, ...props }) => {
  if (status && status.error) {
    return (
      <FormError data-control-name="error" {...props}>
        {typeof status.error === 'object' ? <FormattedMessage {...status.error} /> : status.error}
      </FormError>
    );
  }

  return null;
};

export default FormikStatusError;
