import React from 'react';
import classNames from 'classnames';

import Spinner from 'components/UI/Spinner';
import Heading from 'components/UI/Heading';

import './styles.scss';
import { ClassnamesFunction } from 'types/helpers';

type RenderProp = (v: React.ReactNode) => Nullable<React.ReactElement>;

interface Props {
  heading?: React.ReactNode;
  description?: React.ReactNode;
  note?: React.ReactNode;
  className?: string;
  splitColumns?: boolean;
  fullWidth?: boolean;
  isLoading?: boolean;
  noMargin?: boolean;
  theme?: 'grey' | 'black';
}

const getClass: ClassnamesFunction<Props> = ({ splitColumns, className, noMargin, theme }) =>
  classNames(
    'c-fieldset',
    {
      'c-fieldset--split-columns': splitColumns,
      'c-fieldset--no-margin': noMargin,
      [`c-fieldset--theme-${theme}`]: theme,
    },
    className,
  );

const getFieldClass = (fullWidth: Maybe<boolean>): string =>
  classNames('c-fieldset__field', {
    'c-fieldset__field--full-width': fullWidth,
  });

interface FieldProps {
  fullWidth?: Props['fullWidth'];
}

const Field: React.FC<FieldProps> = ({ fullWidth, children }) => (
  <div className={getFieldClass(fullWidth)}>{children}</div>
);

const Fieldset: React.FC<Props> = props => {
  const { heading, description, note, children, isLoading } = props;

  return (
    <fieldset className={getClass(props)}>
      {(heading || description) && (
        <div className="c-fieldset__header">
          {heading && (
            <legend className="c-fieldset__heading">
              <Heading noMargin>{heading}</Heading>
            </legend>
          )}
          <span className="c-fieldset__description">{description}</span>
        </div>
      )}
      <div className="c-fieldset__fields">
        {isLoading && <Spinner delay={0} />}
        {typeof children === 'function'
          ? children(Field)
          : React.Children.map(children as React.ReactElement[], child => {
              // When {false && <SomeObject />} is in the array of Children this spread would fail.
              if (child) {
                // This modifier overides the 50% width rule when the fullWidth prop is set on a child.
                const { fullWidth, ...otherProps } = child.props;

                // @TODO FIX TYPESCRIPT ERROR
                // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
                // @ts-ignore
                return <Field fullWidth={fullWidth}>{React.cloneElement(child, otherProps)}</Field>;
              }

              return null;
            })}
      </div>
      {note && <div className="c-fieldset__note">{note}</div>}
    </fieldset>
  );
};

Fieldset.defaultProps = {
  theme: 'black',
};

export default Fieldset;
