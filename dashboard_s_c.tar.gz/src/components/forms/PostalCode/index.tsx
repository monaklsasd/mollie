import React from 'react';

type Props = {
  onChange: (a: string) => void;
};

class PostalCode extends React.Component<Props> {
  handleOnChange = (e: React.SyntheticEvent<HTMLInputElement>): void => {
    this.props.onChange((e.target as HTMLInputElement).value.replace(/[^a-zA-Z0-9-\s]/g, ''));
  };

  render(): React.ReactElement {
    return (
      <input
        className="l-form-control"
        type="text"
        {...this.props}
        onChange={this.handleOnChange}
      />
    );
  }
}

export default PostalCode;
