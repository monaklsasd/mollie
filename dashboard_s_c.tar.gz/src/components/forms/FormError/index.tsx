import React from 'react';
import './styles.scss';

const FormError: React.FC = ({ children, ...props }) => (
  <p className="c-form-error" {...props}>
    {children}
  </p>
);

export default FormError;
