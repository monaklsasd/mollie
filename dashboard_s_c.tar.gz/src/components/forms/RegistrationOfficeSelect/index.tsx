import React from 'react';
import { injectIntl } from 'react-intl';
import { connect } from 'react-redux';

// Components
import Select from 'components/forms/Select';

// Redux
import { getRegistrationOffices } from 'reduxState/modules/registrationOffices/selectors';
import { fetchRegistrationOffices } from 'reduxState/modules/registrationOffices/actions';
// Types
import { IntlShape } from 'react-intl';
import { RegistrationOfficesState } from 'reduxState/modules/registrationOffices/types';

// Messages
import { formPlaceholders } from 'messages/forms/OrganizationFormMessages';

type SelectProps = React.ComponentProps<typeof Select>;

type Props = SelectProps & {
  fetchRegistrationOffices: Function;
  intl: IntlShape;
  name: string;
  countryCode: string;
  registrationOffices: RegistrationOfficesState;
  disabled?: boolean;
};

class RegistrationOfficeSelect extends React.Component<Props> {
  componentDidMount(): void {
    this.props.fetchRegistrationOffices();
  }

  render(): React.ReactElement {
    const { intl, countryCode, registrationOffices, ...rest } = this.props;

    return (
      <Select
        {...rest}
        placeholder={intl.formatMessage(formPlaceholders.registrationOffice)}
        options={(registrationOffices && registrationOffices[countryCode]) || []}
        inFormikForm
        isLoading={!registrationOffices[countryCode]}
      />
    );
  }
}

const mapDispatchToProps = {
  fetchRegistrationOffices,
};

const mapStateToProps = (state): { registrationOffices: Props['registrationOffices'] } => ({
  registrationOffices: getRegistrationOffices(state),
});

export default connect(mapStateToProps, mapDispatchToProps)(injectIntl(RegistrationOfficeSelect));
