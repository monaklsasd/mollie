import React from 'react';
import { connect } from 'react-redux';
import { injectIntl, defineMessages } from 'react-intl';

// Components
import Select from 'components/forms/Select';

// Redux
import { getCountries } from 'reduxState/modules/countries/selectors';

// Utils
import shallowEqual from 'utils/shallowEqual';

// Types
import { IntlShape } from 'react-intl';
import { CountriesState, CountryProperties } from 'reduxState/modules/countries/types';
import { IntlMessages } from 'types/intl';
import { State as ReduxState } from 'reduxState/types';

const messages: IntlMessages = defineMessages({
  countryNoResult: {
    id: 'countryCode-select-no-result',
    defaultMessage: "Can't find this country...",
  },
});

type SelectProps = React.ComponentProps<typeof Select>;

type Props = SelectProps & {
  countries: CountriesState;
  placeholder?: string;
  intl: IntlShape;
  name: string;
};

type State = {
  countries: {
    value: string;
    label: string;
  }[];
};

class CountrySelect extends React.Component<Props, State> {
  static defaultProps = {
    placeholder: '',
  };

  constructor(props) {
    super(props);

    // Convert countries object to array because objects are hard to sort.
    this.state = {
      countries: this.getCountries(),
    };
  }

  componentDidUpdate(prevProps): void {
    const { countries } = this.props;

    // Update countries when the countries props object changes
    if (
      !shallowEqual(prevProps.countries.EU, countries.EU) ||
      !shallowEqual(prevProps.countries.other, countries.other)
    ) {
      this.setState({
        countries: this.getCountries(),
      });
    }
  }

  getCountries(): State['countries'] {
    const { countries } = this.props;

    const mergedCountries: { [key: string]: CountryProperties } = {
      ...countries.EU,
      ...countries.other,
    };

    const keys = Object.keys(mergedCountries);

    const countriesState: State['countries'] = keys.reduce(
      (prev: State['countries'], countryKey) => {
        return [
          ...prev,
          {
            value: countryKey,
            label: mergedCountries[countryKey].name,
          },
        ];
      },
      [],
    );

    return countriesState;
  }

  render(): React.ReactElement {
    const { intl, placeholder, ...props } = this.props;

    return (
      <Select
        options={this.state.countries}
        placeholder={placeholder}
        noOptionsMessage={intl.formatMessage(messages.countryNoResult)}
        {...props}
      />
    );
  }
}

const mapStateToProps = (state: ReduxState): { countries: Props['countries'] } => ({
  countries: getCountries(state),
});

export default connect(mapStateToProps)(injectIntl(CountrySelect));
