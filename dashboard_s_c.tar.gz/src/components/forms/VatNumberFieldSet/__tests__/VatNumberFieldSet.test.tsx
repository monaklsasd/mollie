import React from 'react';
import { Formik } from 'formik';
import createComponentWithIntl from 'helpers/createComponentWithIntl';
import VatNumberFieldSet from '../';

jest.mock('components/UI/Tooltip');

const getProps = ({
  countryCode,
  selectedCountryIsPartOfEU = true,
  isReseller = false,
  vatInfo = {},
  vatNumber = '',
  vatRegulation = '',
}): React.ComponentProps<typeof VatNumberFieldSet> => ({
  // @ts-ignore
  localization: {
    exampleVatNumber: 'Example VAT number',
  },
  // @ts-ignore
  organization: {
    vatInfo,
    isReseller,
  },
  selectedCountryIsPartOfEU,
  values: {
    countryCode,
    vatNumber,
    vatRegulation,
    registrationType: '',
  },
  vatRates: {
    dutch: {
      rateHigh: 21,
    },
  },
});

const Renderer = (props: React.ComponentProps<typeof VatNumberFieldSet>): React.ReactElement => (
  // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
  // @ts-ignore
  <Formik initialValues={props.values}>
    <VatNumberFieldSet {...props} />
  </Formik>
);

describe('<VatNumberFieldSet>', () => {
  it('renders a message when no country is selected', () => {
    const tree = createComponentWithIntl(
      <Renderer
        {...getProps({
          countryCode: null,
        })}
      />,
    ).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('renders a message when a non-European country is selected', () => {
    const tree = createComponentWithIntl(
      <Renderer
        {...getProps({
          countryCode: 'US',
          selectedCountryIsPartOfEU: false,
        })}
      />,
    ).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('renders an optional VAT number field when a Dutch merchant is selected', () => {
    const tree = createComponentWithIntl(
      <Renderer
        {...getProps({
          countryCode: 'NL',
          vatNumber: 'NL815839091B01',
          vatRegulation: 'dutch',
          vatInfo: {
            inactive: {
              vatNumber: 'NL815839091B01',
              vatRegulation: 'dutch',
              status: 'pending',
            },
          },
        })}
      />,
    ).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('renders a required VAT number field when a Dutch reseller is selected', () => {
    const tree = createComponentWithIntl(
      <Renderer
        {...getProps({
          countryCode: 'NL',
          isReseller: true,
          vatNumber: 'NL815839091B01',
          vatInfo: {
            inactive: {
              vatNumber: 'NL815839091B01',
              status: 'invalid',
            },
          },
        })}
      />,
    ).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('will not show a VAT status when no VAT number is provided', () => {
    const tree = createComponentWithIntl(
      <Renderer
        {...getProps({
          countryCode: 'NL',
          vatNumber: '',
          vatInfo: {
            active: {
              vatNumber: '',
              status: 'active',
            },
          },
        })}
      />,
    ).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('renders a VAT number field with VAT regulation selection when Belgium is selected', () => {
    const tree = createComponentWithIntl(
      <Renderer
        {...getProps({
          countryCode: 'BE',
          vatNumber: 'BE815839091B01',
          vatRegulation: 'shifted',
        })}
      />,
    ).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('renders an optional VAT number field with VAT regulation selection when Belgium is selected with the Dutch VAT regulation', () => {
    const tree = createComponentWithIntl(
      <Renderer
        {...getProps({
          countryCode: 'BE',
          vatNumber: 'BE815839091B01',
          vatRegulation: 'dutch',
          vatInfo: {
            active: {
              vatNumber: 'BE815839091B01',
              vatRegulation: 'dutch',
              status: 'invalid',
            },
          },
        })}
      />,
    ).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('renders displays VatInfoStatus and ActiveVatInfoFlashMessage when both active and inactive VAT info is found', () => {
    const tree = createComponentWithIntl(
      <Renderer
        {...getProps({
          countryCode: 'BE',
          vatNumber: 'BE815839091B01',
          vatRegulation: 'dutch',
          vatInfo: {
            active: {
              vatNumber: 'BE815839000B01',
              vatRegulation: 'shifted',
              status: 'active',
            },
            inactive: {
              vatNumber: 'BE815839091B01',
              vatRegulation: 'dutch',
              status: 'pending',
            },
          },
        })}
      />,
    ).toJSON();
    expect(tree).toMatchSnapshot();
  });
});
