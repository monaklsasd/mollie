import { isVatNumberRequired, getVatNumberError } from '../utils';

describe('isVatNumberRequired', () => {
  describe('isVatNumberRequired', () => {
    it('should return false when the merchant is located outside the EU', () => {
      expect(
        isVatNumberRequired({
          selectedCountryIsPartOfEU: false,
          countryCode: 'US',
          vatRegulation: 'shifted',
          isReseller: false,
        }),
      ).toEqual(false);
    });

    it('should return false for Dutch merchants who are not a reseller', () => {
      expect(
        isVatNumberRequired({
          selectedCountryIsPartOfEU: true,
          countryCode: 'NL',
          vatRegulation: 'dutch',
          isReseller: false,
        }),
      ).toEqual(false);
    });

    it('should return true for Dutch merchants who are a reseller', () => {
      expect(
        isVatNumberRequired({
          selectedCountryIsPartOfEU: true,
          countryCode: 'NL',
          vatRegulation: 'dutch',
          isReseller: true,
        }),
      ).toEqual(true);
    });

    it('should return false for European merchants using the Dutch VAT regulation (small businesses scheme)', () => {
      expect(
        isVatNumberRequired({
          selectedCountryIsPartOfEU: true,
          countryCode: 'BE',
          vatRegulation: 'dutch',
          isReseller: false,
        }),
      ).toEqual(false);
    });

    it('should return true otherwise', () => {
      expect(
        isVatNumberRequired({
          selectedCountryIsPartOfEU: true,
          countryCode: 'BE',
          vatRegulation: 'shifted',
          isReseller: false,
        }),
      ).toEqual(true);
    });
  });

  describe('getVatNumberError', () => {
    it('should not return an error when the VAT number is not required', () => {
      expect(
        getVatNumberError({
          vatNumber: '',
          vatRegulation: '',
          countryCode: 'US',
          selectedCountryIsPartOfEU: false,
        }),
      ).toEqual(undefined);
    });

    it('should return an error when the VAT number is required and empty', () => {
      expect(
        getVatNumberError({
          vatNumber: '',
          vatRegulation: '',
          countryCode: 'BE',
          selectedCountryIsPartOfEU: true,
        }),
      ).toMatchObject({ id: 'error-required', defaultMessage: 'This information is required' });
    });

    it('should return an error when the VAT number is required and not starting with the country code', () => {
      expect(
        getVatNumberError({
          vatNumber: 'FR90833711534',
          vatRegulation: 'shifted',
          countryCode: 'BE',
          selectedCountryIsPartOfEU: true,
        }),
      ).toMatchObject({
        id: 'error-invalid-vat-number-for-selected-country',
        defaultMessage: 'Invalid VAT number provided for the selected country',
      });
    });

    it('should return no error when the VAT number is required and provided a valid VAT number', () => {
      expect(
        getVatNumberError({
          vatNumber: 'FR90833711534',
          vatRegulation: 'shifted',
          countryCode: 'FR',
          selectedCountryIsPartOfEU: true,
        }),
      ).toEqual(undefined);
    });
  });
});
