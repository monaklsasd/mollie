import React from 'react';
import { FormattedMessage } from 'react-intl';
import Status, { STATUS_ERROR, STATUS_NEUTRAL, STATUS_SUCCESS } from 'components/UI/Status';
import { statusMessages } from './messages';

import { OrganizationVatInfo } from 'reduxState/modules/organization/types';

type Props = {
  vatInfo: OrganizationVatInfo;
};

const VatInfoStatus: React.FC<Props> = ({ vatInfo }) => {
  if (!vatInfo.vatNumber) {
    // Do not show status when no VAT number is provided
    return null;
  }

  let state;

  switch (vatInfo.status) {
    case 'invalid':
      state = STATUS_ERROR;
      break;
    case 'approved':
    case 'active':
      state = STATUS_SUCCESS;
      break;
    default:
      state = STATUS_NEUTRAL;
      break;
  }

  return (
    <Status message={<FormattedMessage {...statusMessages[vatInfo.status]} />} state={state} />
  );
};

export default VatInfoStatus;
