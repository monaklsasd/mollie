import React from 'react';
import { FormattedMessage, FormattedHTMLMessage, injectIntl, IntlShape } from 'react-intl';
import Fieldset from 'components/forms/Fieldset';
import HelpTooltip from 'components/UI/HelpTooltip';
import messages from './messages';
import { isVatNumberRequired } from './utils';
import ActiveVatInfoFlashMessage from './ActiveVatInfoFlashMessage';
import VatNumberInput from './VatNumberInput';
import VatInfoStatus from './VatInfoStatus';
import VatRegulationSelection from './VatRegulationSelection';
import { NL } from 'helpers/countries';

import { ApplicationVatRates } from 'reduxState/modules/application/types';
import { OrganizationState } from 'reduxState/modules/organization/types';
import { OrganizationLocalization } from 'reduxState/modules/organizationLocalizations/types';

type Props = {
  localization: OrganizationLocalization;
  organization: OrganizationState;
  selectedCountryIsPartOfEU: boolean;
  values: {
    countryCode: string;
    vatRegulation: string;
    vatNumber?: string;
    registrationType?: string;
  };
  vatRates: ApplicationVatRates;
  intl: IntlShape;
};

const VatNumberFieldSet: React.FC<Props> = props => {
  const {
    localization,
    organization: { vatInfo, isReseller },
    selectedCountryIsPartOfEU,
    values,
    vatRates,
    intl,
  } = props;

  const isCountrySelected = !!values.countryCode;
  const isNlSelected = values.countryCode === NL;
  const dutchVatPercentage = vatRates.dutch.rateHigh / 100;

  const vatNumberRequired = isVatNumberRequired({
    selectedCountryIsPartOfEU,
    isReseller,
    countryCode: values.countryCode,
    vatRegulation: values.vatRegulation,
  });

  // For Dutch merchants where the VAT number is optional we want to show an 'optional' label
  const showOptionalLabel = isNlSelected && !vatNumberRequired;

  const getDescription = (): React.ReactElement<typeof FormattedMessage> | null => {
    if (!isCountrySelected) {
      return <FormattedMessage {...messages.noCountrySelected} />;
    } else if (!selectedCountryIsPartOfEU) {
      return <FormattedMessage {...messages.nonEuropeanCountrySelected} />;
    } else if (isNlSelected) {
      return (
        <FormattedHTMLMessage
          {...messages.countryNlSelected}
          values={{ vatPercentage: dutchVatPercentage }}
        />
      );
    }

    return null;
  };

  let vatInfoStatus;
  let activeVatInfoFlashMessage;

  if (vatInfo.inactive && vatInfo.active) {
    vatInfoStatus = <VatInfoStatus vatInfo={vatInfo.inactive} />;
    activeVatInfoFlashMessage = (
      <ActiveVatInfoFlashMessage
        countryCode={values.countryCode}
        dutchVatPercentage={dutchVatPercentage}
        vatInfo={vatInfo.active}
      />
    );
  } else if (vatInfo.active) {
    vatInfoStatus = <VatInfoStatus vatInfo={vatInfo.active} />;
  } else if (vatInfo.inactive) {
    vatInfoStatus = <VatInfoStatus vatInfo={vatInfo.inactive} />;
  }

  const description = getDescription();

  return (
    <Fieldset heading={<FormattedMessage {...messages.vatInfoHeader} />} description={description}>
      {isCountrySelected && selectedCountryIsPartOfEU && (
        <React.Fragment>
          {activeVatInfoFlashMessage}
          <VatNumberInput
            countryCode={values.countryCode}
            localization={localization}
            status={vatInfoStatus}
            showOptionalLabel={showOptionalLabel}
            labelTooltip={
              !isNlSelected &&
              !isReseller && (
                <HelpTooltip
                  content={<FormattedMessage {...messages.vatNumberLabelVatRegulationsHelpText} />}
                  ariaLabel={intl.formatMessage(messages.vatNumberLabelVatRegulationsHelpText)}
                  showOnHover
                />
              )
            }
          />

          {!isNlSelected && !isReseller && (
            <VatRegulationSelection dutchVatPercentage={dutchVatPercentage} />
          )}
        </React.Fragment>
      )}
    </Fieldset>
  );
};

export default injectIntl(VatNumberFieldSet);
