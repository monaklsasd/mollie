import { defineMessages } from 'react-intl';
import { IntlMessages } from './../../../types/intl';

const messages: IntlMessages = defineMessages({
  vatInfoHeader: {
    id: 'vat-number-section-header',
    defaultMessage: 'VAT info',
  },
  noCountrySelected: {
    id: 'vat-number-no-country-selected',
    defaultMessage: 'Please select a country first.',
    description:
      'This message is shown instead of the VAT number field when no country is selected.',
  },
  countryNlSelected: {
    id: 'vat-number-country-nl-selected',
    defaultMessage:
      'As you have indicated your company is located in The Netherlands, we will apply <strong>{vatPercentage, number, percent} VAT</strong>.',
    description:
      'This message is shown instead of the VAT number field when country NL is selected.',
  },
  nonEuropeanCountrySelected: {
    id: 'vat-number-non-european-country-selected',
    defaultMessage:
      'As you have indicated your company is located outside the European Union, we will not add any VAT to our invoices to you.',
    description:
      'This message is shown instead of the VAT number field when a country is selected outside the European Union.',
  },
  vatNumber: {
    id: 'vat-number-field-label',
    defaultMessage: '{countryCode, select, other {VAT number}}',
    description:
      "This translation gets the parameters {countryCode}. The country code contains the organization location, this way you can add country specific translation for 'VAT number' when required.",
  },
  vatNumberLabelVatRegulationsHelpText: {
    id: 'vat-number-field-label-vat-regulation-help-text',
    defaultMessage:
      "If you don't have a VAT number, or when your VAT number is not active for cross border transactions, select the Dutch VAT regulation.",
    description:
      'Help text shown when the merchant has the option to select the VAT regulation (not available for Dutch merchants or resellers)',
  },
  vatRegulationTitle: {
    id: 'vat-number-applicable-vat-regulation',
    defaultMessage: 'Applicable VAT regulation',
  },
  vatRegulationShiftedHeading: {
    id: 'vat-number-vat-regulation-shifted-heading',
    defaultMessage: 'Shifted VAT',
  },
  vatRegulationShiftedByline: {
    id: 'vat-number-vat-regulation-shifted-byline',
    defaultMessage:
      'Do not apply VAT to my invoices. I will handle VAT declaration with my local tax authority',
  },
  vatRegulationDutchHeading: {
    id: 'vat-number-vat-regulation-dutch-heading',
    defaultMessage: 'Dutch VAT',
  },
  vatRegulationDutchByline: {
    id: 'vat-number-vat-regulation-dutch-byline',
    defaultMessage:
      'Apply {vatPercentage, number, percent} Dutch VAT to my invoices (e.g. for small business schemes)',
    description:
      'You can use {vatPercentage, number, percent} to display the Dutch VAT percentage.',
  },
  activeVatInfoDescription: {
    id: 'vat-number-active-vat-info-description',
    defaultMessage:
      'We currently use VAT number {vatNumber} and apply {vatRegulation}. Your updated VAT info below will become active after it has been approved and the next invoice period has started.',
    description: 'This message is shown when both active and inactive VAT info is available',
  },
  activeVatInfoDescriptionNoVatNumber: {
    id: 'vat-number-active-vat-info-description-no-vat-number',
    defaultMessage:
      'We currently apply {vatRegulation}. Your updated VAT info below will become active after it has been approved and the next invoice period has started.',
    description: 'This message is shown when both active and inactive VAT info is available',
  },
  vatNumberRequired: {
    id: 'vat-number-vat-number-required',
    defaultMessage: 'VAT number required',
  },
  vatNumberOptional: {
    id: 'vat-number-vat-number-optional',
    defaultMessage: 'VAT number optional',
  },
});

export const statusMessages = defineMessages({
  pending: {
    id: 'vat-number-status-description-pending',
    defaultMessage: 'Validating...',
  },
  invalid: {
    id: 'vat-number-status-description-invalid',
    defaultMessage: 'Invalid, please fix',
  },
  approved: {
    id: 'vat-number-status-description-approved',
    defaultMessage: 'Approved',
  },
  active: {
    id: 'vat-number-status-description-active',
    defaultMessage: 'Approved and in use',
  },
});

export default messages;
