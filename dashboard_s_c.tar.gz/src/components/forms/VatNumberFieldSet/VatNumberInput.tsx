import React from 'react';
import { FormattedMessage, useIntl } from 'react-intl';

import { connect, FormikContext } from 'formik';
import FormikGroup from 'components/forms/FormikGroup';
import OptionalLabelIndicator from 'components/forms/OptionalLabelIndicator';
import formMessages from 'messages/forms';
import messages from './messages';

import { OrganizationLocalization } from 'reduxState/modules/organizationLocalizations/types';

type Props = {
  status: Maybe<React.ReactNode>;
  localization: OrganizationLocalization;
  countryCode: Maybe<string>;
  showOptionalLabel: boolean;
  labelTooltip: Maybe<React.ReactNode>;
};

const VatNumberInput: React.FC<Props & { formik: FormikContext<any> }> = ({
  countryCode,
  localization,
  status,
  formik,
  showOptionalLabel,
  labelTooltip,
}) => {
  const fieldIsDirty = formik.initialValues.vatNumber !== formik.values.vatNumber;
  const intl = useIntl();

  return (
    <FormikGroup
      name="vatNumber"
      label={
        <React.Fragment>
          {showOptionalLabel ? (
            <OptionalLabelIndicator>
              <FormattedMessage {...messages.vatNumber} values={{ countryCode }} />
            </OptionalLabelIndicator>
          ) : (
            <FormattedMessage {...messages.vatNumber} values={{ countryCode }} />
          )}
          {labelTooltip}
        </React.Fragment>
      }
      help={!fieldIsDirty && status}>
      {(field): React.ReactElement => (
        <input
          type="text"
          className="l-form-control"
          placeholder={
            localization.exampleVatNumber
              ? intl.formatMessage(formMessages.exampleValue, {
                  value: localization.exampleVatNumber,
                })
              : ''
          }
          {...field}
        />
      )}
    </FormikGroup>
  );
};

export default connect<Props>(VatNumberInput);
