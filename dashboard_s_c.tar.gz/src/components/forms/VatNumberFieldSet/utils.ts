import formMessages from 'messages/forms';
import { NL } from 'helpers/countries';

import { OrganizationState } from 'reduxState/modules/organization/types';
import { MessageDescriptor } from 'react-intl';

type IsVatNumberRequiredArgs = {
  countryCode: Maybe<string>;
  selectedCountryIsPartOfEU: boolean;
  isReseller: Maybe<boolean>;
  vatRegulation: Maybe<string>;
};

/*
 * Check if a VAT number is required
 *
 * For corresponding requirements:
 * - Mollie Platform admin: application/views/admin/klant/edit.php (isVatNumberRequired)
 * - Mollie Platform backend: \Customer\Vat\Info\VatInfoUpdateHandler::isVatNumberRequired
 *
 * @link https://mollie.atlassian.net/wiki/spaces/PRODUCT/pages/458850509
 */
export const isVatNumberRequired = ({
  countryCode,
  selectedCountryIsPartOfEU,
  isReseller,
  vatRegulation,
}: IsVatNumberRequiredArgs): boolean => {
  if (!selectedCountryIsPartOfEU) {
    // No country selected or selected country is outside the EU.
    // Organizations outside the EU do not have a VAT number.
    return false;
  }

  const isDutch = countryCode === NL;

  if (isDutch && !isReseller) {
    // VAT number is not required for Dutch merchants who are not a reseller
    return false;
  }

  if (!isDutch && vatRegulation === 'dutch') {
    // Not required for European merchants using the Small businesses scheme
    return false;
  }

  return true;
};

type GetVatNumberErrorArgs = {
  countryCode: Maybe<string>;
  vatNumber: Maybe<string>;
  vatRegulation: Maybe<string>;
  selectedCountryIsPartOfEU: boolean;
  isReseller?: boolean;
};

export const getVatNumberError = ({
  countryCode,
  vatNumber,
  vatRegulation,
  selectedCountryIsPartOfEU,
  isReseller,
}: GetVatNumberErrorArgs): Maybe<MessageDescriptor> => {
  if (
    !isVatNumberRequired({
      countryCode: countryCode,
      vatRegulation: vatRegulation,
      selectedCountryIsPartOfEU: selectedCountryIsPartOfEU,
      isReseller: isReseller,
    })
  ) {
    return;
  }

  // VAT number is required but not filled
  if (!vatNumber) {
    return formMessages.required;
  }

  // VAT number is filled but in an invalid format
  if (countryCode && !vatNumber.startsWith(countryCode)) {
    return formMessages.invalidVatNumberForSelectedCountry;
  }
};

export const getVatValuesForForm = (
  organization: OrganizationState,
): { vatNumber?: string; vatRegulation?: string } => {
  const vatInfo = organization.vatInfo.inactive || organization.vatInfo.active;

  if (vatInfo) {
    return {
      vatNumber: vatInfo.vatNumber,
      vatRegulation: vatInfo.vatRegulation,
    };
  }

  return {
    vatNumber: '',
    vatRegulation: 'shifted',
  };
};
