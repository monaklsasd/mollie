import React from 'react';
import { FormattedMessage } from 'react-intl';
import RadioButtonGroup from 'components/forms/RadioButtonGroup';
import ListItem from 'components/UI/ListItem';
import messages from './messages';

type Props = {
  dutchVatPercentage: number;
};

const VatRegulationSelection: React.FC<Props> = ({ dutchVatPercentage }) => (
  <React.Fragment>
    <p className="l-form-label">
      <FormattedMessage {...messages.vatRegulationTitle} />
    </p>
    <RadioButtonGroup name="vatRegulation">
      {(RadioButton): React.ReactElement => (
        <ul className="l-list-ui l-list-ui--no-spacing">
          <li>
            <ListItem
              tag="label"
              heading={
                <React.Fragment>
                  <FormattedMessage {...messages.vatRegulationShiftedHeading} /> (
                  <FormattedMessage {...messages.vatNumberRequired} />)
                </React.Fragment>
              }
              byline={<FormattedMessage {...messages.vatRegulationShiftedByline} />}
              htmlFor="input-radio-shifted"
              control={<RadioButton insideLabel value="shifted" />}
              controlPosition="left"
              size="compact"
            />
          </li>
          <li>
            <ListItem
              tag="label"
              heading={
                <React.Fragment>
                  <FormattedMessage {...messages.vatRegulationDutchHeading} /> (
                  <FormattedMessage {...messages.vatNumberOptional} />)
                </React.Fragment>
              }
              byline={
                <FormattedMessage
                  {...messages.vatRegulationDutchByline}
                  values={{ vatPercentage: dutchVatPercentage }}
                />
              }
              htmlFor="input-radio-dutch"
              control={<RadioButton insideLabel value="dutch" />}
              controlPosition="left"
              size="compact"
            />
          </li>
        </ul>
      )}
    </RadioButtonGroup>
  </React.Fragment>
);

export default VatRegulationSelection;
