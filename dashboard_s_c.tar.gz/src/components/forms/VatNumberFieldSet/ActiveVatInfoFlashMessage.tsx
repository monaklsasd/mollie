import React from 'react';
import { FormattedMessage } from 'react-intl';
import FlashMessage from 'components/UI/FlashMessage';
import messages from './messages';

import { OrganizationVatInfo } from 'reduxState/modules/organization/types';

type Props = {
  countryCode: Maybe<string>;
  dutchVatPercentage: number;
  vatInfo: OrganizationVatInfo;
};

const ActiveVatInfoFlashMessage: React.FC<Props> = ({ dutchVatPercentage, vatInfo }) => {
  const vatRegulationMessage =
    vatInfo.vatRegulation === 'dutch' ? (
      <FormattedMessage
        {...messages.vatRegulationDutchHeading}
        values={{ vatPercentage: dutchVatPercentage }}
      />
    ) : (
      <FormattedMessage {...messages.vatRegulationShiftedHeading} />
    );

  const messageToDisplay = vatInfo.vatNumber
    ? messages.activeVatInfoDescription
    : messages.activeVatInfoDescriptionNoVatNumber;

  return (
    <FlashMessage state="info">
      <FormattedMessage
        {...messageToDisplay}
        values={{
          vatNumber: <strong>{vatInfo.vatNumber}</strong>,
          vatRegulation: <strong>{vatRegulationMessage}</strong>,
        }}
      />
    </FlashMessage>
  );
};

export default ActiveVatInfoFlashMessage;
