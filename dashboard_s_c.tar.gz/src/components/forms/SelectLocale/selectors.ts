import { createSelector } from 'reselect';

import { getState } from 'reduxState/modules/intl/selectors';

export const getLocaleOptions = createSelector(getState, ({ availableLocales }) =>
  Object.keys(availableLocales)
    .map(key => ({
      value: key, // en-US
      label: availableLocales[key], // English
      clearableValue: false,
    }))
    .sort((a, b) => a.label.localeCompare(b.label)),
);
