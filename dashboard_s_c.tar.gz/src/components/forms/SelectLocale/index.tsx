import React from 'react';
import { useIntl } from 'react-intl';
import { connect } from 'react-redux';

import Select from 'components/forms/Select';

import messages from './messages';
import { getLocaleOptions } from './selectors';

import { State } from 'reduxState/types';

type SelectProps = React.ComponentProps<typeof Select>;

type Props = SelectProps & {
  localeOptions: {
    value: string;
    label: string;
  }[];
};

const SelectLocale: React.FC<Props> = ({ localeOptions, ...otherProps }) => {
  const intl = useIntl();
  return (
    <Select
      options={localeOptions}
      placeholder={intl.formatMessage(messages.localePlaceholder)}
      noOptionsMessage={intl.formatMessage(messages.localeNoResult)}
      {...otherProps}
    />
  );
};

const mapStateToProps = (state: State): { localeOptions: Props['localeOptions'] } => ({
  // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
  // @ts-ignore
  localeOptions: getLocaleOptions(state),
});

export default connect(mapStateToProps)(SelectLocale);
