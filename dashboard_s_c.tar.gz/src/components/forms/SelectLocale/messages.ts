import { defineMessages } from 'react-intl';
import { IntlMessages } from './../../../types/intl';

const messages: IntlMessages = defineMessages({
  localeNoResult: {
    id: 'account-settings-form-locale-no-result-found',
    defaultMessage: 'No result was found...',
  },
  localePlaceholder: {
    id: 'account-settings-form-locale-placeholder',
    defaultMessage: 'Select your language',
  },
});

export default messages;
