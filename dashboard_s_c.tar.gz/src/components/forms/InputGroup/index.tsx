import React from 'react';
import classNames from 'classnames';

import './styles.scss';

interface Props {
  addOn?: React.ReactNode;
  content?: React.ReactNode;
  addOnPosition?: 'left' | 'right';
  addOnTheme?: 'plain';
  align?: 'left' | 'right' | 'center';
  input: React.ReactNode;
  isLabel?: boolean;
  noInputPadding?: boolean;
  className?: string;
  id?: string;
}

const getClass = ({
  align,
  addOnPosition,
  addOnTheme,
  className,
  noInputPadding,
}: Partial<Props>): string =>
  classNames('c-input-group', className, {
    [`c-input-group--align-${align}`]: align !== 'center',
    [`c-input-group--add-on-${addOnPosition}`]: addOnPosition !== 'left',
    [`c-input-group__add-on--theme-${addOnTheme}`]: addOnTheme,
    'c-input-group--no-input-padding': noInputPadding,
  });

const InputGroup: React.FC<Props> = ({
  addOn,
  addOnPosition,
  addOnTheme,
  align,
  input,
  isLabel,
  noInputPadding,
  className,
  content,
  id,
  ...others
}) => {
  const ComponentTag = isLabel ? 'label' : 'div';
  // Pass props through from parent wrap element when input is react element.
  const modifiedInput = React.isValidElement(input)
    ? React.cloneElement(input, { id, ...input.props })
    : input;

  return (
    <ComponentTag
      className={getClass({
        align,
        addOn,
        addOnPosition,
        addOnTheme,
        noInputPadding,
        className,
        content,
      })}
      {...others}>
      {addOnPosition === 'left' && (
        <span className="c-input-group__add-on">
          <span className="c-input-group__add-on-contents">{addOn}</span>
        </span>
      )}

      <span className="c-input-group__input">{modifiedInput}</span>
      {content && <span className="c-input-group__content">{content}</span>}

      {addOnPosition === 'right' && (
        <span className="c-input-group__add-on">
          <span className="c-input-group__add-on-contents">{addOn}</span>
        </span>
      )}
    </ComponentTag>
  );
};

InputGroup.defaultProps = {
  addOn: false,
  addOnPosition: 'left',
  align: 'center',
  isLabel: true,
  noInputPadding: false,
};

export default InputGroup;
