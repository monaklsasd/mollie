import React from 'react';

type Props = {
  onBlur: Function;
  onChange: Function;
  min: number;
  max: number;
};

class InputNumeric extends React.Component<Props> {
  handleOnChange = (e: React.SyntheticEvent<HTMLInputElement>): void => {
    this.props.onChange((e.target as HTMLInputElement).value.replace(/\D/, ''));
  };

  handleOnBlur = (e: React.SyntheticEvent<HTMLInputElement>): void => {
    const { min, max, onBlur, onChange } = this.props;

    if (!min && !max) {
      return onBlur();
    }

    if (parseInt((e.target as HTMLInputElement).value, 10) < min) {
      onChange(min);
    } else if (parseInt((e.target as HTMLInputElement).value, 10) > max) {
      onChange(max);
    }
    return onBlur();
  };

  render(): React.ReactElement {
    return (
      <input
        className="l-form-control"
        {...this.props}
        onChange={this.handleOnChange}
        onBlur={this.handleOnBlur}
      />
    );
  }
}

export default InputNumeric;
