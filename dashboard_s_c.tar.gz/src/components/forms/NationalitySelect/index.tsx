import React from 'react';
import { connect } from 'react-redux';
import { injectIntl, defineMessages } from 'react-intl';
import { getNationalities } from 'reduxState/modules/nationalities/selectors';
import Select from 'components/forms/Select';

// Types
import { IntlShape } from 'react-intl';
import { NationalitiesState } from 'reduxState/modules/nationalities/types';
import { NationalitiesType } from './types';
import { IntlMessages } from 'types/intl';
import { State as ReduxState } from 'reduxState/types';

const messages: IntlMessages = defineMessages({
  nationalityNoResult: {
    id: 'nationality-select-no-result',
    defaultMessage: "Can't find this nationality...",
  },
});

type Props = {
  nationalities: NationalitiesState;
  placeholder: string;
  intl: IntlShape;
  name: string;
};

type State = {
  nationalities: NationalitiesType;
};

const getNationalitiesArray = (nationalities: NationalitiesState): NationalitiesType => {
  // Convert nationalities object to array because objects are hard to sort.
  return Object.keys(nationalities).reduce(
    (acc: NationalitiesType, currentNationalityKey) =>
      acc.concat([
        {
          value: currentNationalityKey,
          label: nationalities[currentNationalityKey],
        },
      ]),
    [],
  );
};

class NationalitySelect extends React.Component<Props, State> {
  static defaultProps = {
    placeholder: '',
  };

  static getDerivedStateFromProps(nextProps, prevState): State | null {
    if (prevState.nationalities !== nextProps.nationalities) {
      return {
        nationalities: getNationalitiesArray(nextProps.nationalities),
      };
    }
    return null;
  }

  state = {
    nationalities: [],
  };

  render(): React.ReactElement {
    const { intl, placeholder, ...props } = this.props;
    const { nationalities } = this.state;

    return (
      <Select
        options={nationalities}
        placeholder={placeholder}
        noOptionsMessage={intl.formatMessage(messages.nationalityNoResult)}
        {...props}
      />
    );
  }
}

const mapStateToProps = (state: ReduxState): { nationalities: Props['nationalities'] } => ({
  nationalities: getNationalities(state),
});

export default connect(mapStateToProps)(injectIntl(NationalitySelect));
