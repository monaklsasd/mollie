export type NationalitiesType = {
  value: string;
  label: string;
}[];
