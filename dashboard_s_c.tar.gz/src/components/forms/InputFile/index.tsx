import React from 'react';

import { connect, FormikContext } from 'formik';

// Components
import AssetUploader from 'components/forms/AssetUploader';

export type Props = {
  value: File[];
  formik: FormikContext<any>;
  id?: string;
  name: string;
  accept?: string[]; // accepted mime types, see https://github.com/okonet/react-dropzone#features (default pdf and images)
  className?: string;
  limit?: number;
  multiple?: boolean; // whether to accept multiple files
  showPreview?: boolean;
  showFilename?: boolean;
};

class InputFile extends React.Component<Props> {
  static defaultProps = {
    showFilename: true,
  };

  handleDelete = (index: number): void => {
    const {
      formik: { setFieldValue, setFieldTouched },
      name,
      value,
    } = this.props;

    setFieldValue(
      name,
      value.filter((file, i) => i !== index),
    );
    setFieldTouched(name, true);
  };

  onDrop = (file: Props['value']): void => {
    const {
      formik: { setFieldValue, setFieldTouched },
      name,
      value,
    } = this.props;

    setFieldValue(name, value.concat(file));
    setFieldTouched(name, true);
  };

  render(): React.ReactElement {
    const { limit, multiple, value, name, showPreview, showFilename, accept, id } = this.props;

    return (
      <AssetUploader
        accept={accept}
        showFilename={showFilename}
        showPreview={showPreview}
        onDrop={this.onDrop}
        onDropReject={this.onDrop}
        onDelete={this.handleDelete}
        multiple={multiple}
        limit={limit}
        value={value}
        id={id}
        name={name}
      />
    );
  }
}

export default connect<Omit<Props, 'formik'>>(InputFile);
