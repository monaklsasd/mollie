import React from 'react';
import classNames from 'classnames';

// Context
import PageWrapperContext from 'containers/PageWrapper/PageWrapperContext';

// Utils
import { debounce } from 'lodash';
import autobind from 'utils/autobind';

// Images
import { ReactComponent as IconSearch } from 'assets/icons/search.svg';

import './styles.scss';

interface Props {
  value: string;
  onChange?: (q: string) => void;
  onBlur?: React.InputHTMLAttributes<any>['onBlur'];
  onFocus?: React.InputHTMLAttributes<any>['onFocus'];
  debounceTimeout?: number;
  placeholder?: string;
}

interface State {
  value: Props['value'];
  dispatched: boolean;
}

const getClass = ({ inPageWrapperHeader }): string =>
  classNames('l-form-control', 'c-input-search__control', {
    'c-input-search__control--in-page-wrapper-header': inPageWrapperHeader,
  });

class InputSearch extends React.PureComponent<Props, State> {
  static defaultProps = {
    debounceTimeout: 400,
    value: '',
  };

  constructor(props) {
    super(props);

    autobind(this);

    this.state = {
      value: props.value,
      dispatched: true,
    };

    this.handleSearchDebounced = debounce(() => {
      props.onChange.apply(this, [this.state.value]);
      this.setState({ dispatched: true });
    }, props.debounceTimeout);
  }

  componentWillReceiveProps(nextProps): void {
    const { dispatched = true } = this.state;

    // Only change query when last state has been dispatched to onChange
    if (dispatched) {
      this.setState({ value: nextProps.value });
    }
  }

  onVolatileChange(): void {
    this.setState({
      value: (this._input as HTMLInputElement).value,
      dispatched: false,
    });

    this.handleSearchDebounced();
  }

  handleSearchDebounced: Function;
  _input: Nullable<HTMLInputElement> = null;

  onClear(): void {
    this.setState({
      value: '',
      dispatched: false,
    });

    if (this.props.onChange) {
      // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
      // @ts-ignore
      this.props.onChange('');
    }
  }

  render(): React.ReactNode {
    const { onFocus, onBlur, placeholder } = this.props;

    return (
      <div className="c-input-search">
        <IconSearch className={'c-input-search__icon'} width={12} height={12} />
        <PageWrapperContext.Consumer>
          {({ inPageWrapperHeader }): React.ReactNode => (
            <input
              id="profile-payment-search"
              ref={(e): void => {
                this._input = e;
              }}
              type="search"
              className={getClass({ inPageWrapperHeader })}
              placeholder={placeholder}
              value={this.state.value}
              onChange={this.onVolatileChange}
              onBlur={onBlur}
              onFocus={onFocus}
            />
          )}
        </PageWrapperContext.Consumer>
      </div>
    );
  }
}

export default InputSearch;
