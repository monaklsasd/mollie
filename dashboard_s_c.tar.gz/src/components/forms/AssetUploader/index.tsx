import React from 'react';
import { FormattedHTMLMessage, FormattedMessage } from 'react-intl';
import Dropzone from 'react-dropzone';

// Components
import Link from 'components/UI/Link';

// Icons
import { ReactComponent as FileIcon } from 'assets/icons/file.svg';

// Messages
import commonMessages from 'messages';
import messages from './messages';

// Utils
import { printFormats } from './utils';
import getFileHash from 'utils/getFileHash';

import './styles.scss';

const maxFileSizeMb = 50;
export const maxFileSize = maxFileSizeMb * 1024 * 1024;
export const prettyMaxFileSize = `${maxFileSizeMb} MB`;
export const defaultMimeTypes = ['application/pdf', 'image/jpeg', 'image/pjpeg', 'image/png'];

const shouldShowUploader = (value: any[], limit: number): boolean => {
  if (value && !Array.isArray(value) && limit === 1) {
    return false;
  }

  if (value && value.length >= limit) {
    return false;
  }

  return true;
};

type Props = {
  dropText?: string;
  name: string;
  id?: string;
  value: any;
  limit: number; // how many files can be accepted
  className?: string;
  multiple?: boolean; // whether to allow selecting of multiple files at the same time
  onDrop: Function;
  onDropReject: Function;
  onDelete: Function;
  accept: Array<string>; // which filetypes to accept
  showPreview?: boolean;
  showFilename?: boolean;
};

class AssetUploader extends React.Component<Props> {
  static defaultProps = {
    limit: Infinity,
    accept: defaultMimeTypes,
    showFilename: true,
  };

  renderFile(value: File & { preview: string }, index: number): React.ReactElement {
    const { onDelete, showPreview, showFilename } = this.props;

    const src = showPreview && value.preview;
    const name = showFilename && value.name;

    return (
      <div className="c-asset-uploader has-file">
        {src && (
          <figure>
            <img height="100%" alt="" src={src} />
          </figure>
        )}
        {name && <p>{name}</p>}
        <Link onClick={(): void => onDelete(index)} linkStyle="danger">
          <FormattedMessage {...messages.delete} />
        </Link>
      </div>
    );
  }

  render(): React.ReactElement {
    const {
      onDrop,
      onDropReject,
      id,
      name,
      limit,
      value,
      multiple,
      accept,
      showPreview,
    } = this.props;

    return (
      <React.Fragment>
        {value && value.length > 0 && (
          <ul className="l-list-ui">
            {value.map((file, index) => (
              <li key={`${getFileHash(file)}-${index}`}>{this.renderFile(file, index)}</li>
            ))}
          </ul>
        )}
        {// Show dropzone as long as you are below the limit of files you can upload
        shouldShowUploader(value, limit) && (
          <Dropzone
            dropText={this.props.dropText}
            className="c-asset-uploader"
            accept={accept.join(',')}
            disablePreview={!showPreview}
            onDropAccepted={onDrop}
            onDropRejected={onDropReject}
            inputProps={{ id: id || name }}
            maxSize={maxFileSize}
            multiple={multiple && value.length < limit - 1}>
            <span className="c-asset-uploader__icon">
              <FileIcon />
            </span>
            <p className="c-asset-uploader__dropzone-text">
              <FormattedHTMLMessage {...messages.placeholder} />
              <br />
              <small>
                <FormattedMessage {...commonMessages.and}>
                  {(lastSeparator: string): React.ReactElement => (
                    <FormattedMessage
                      {...messages.acceptedFormats}
                      values={{
                        formats: printFormats({
                          formats: accept,
                          lastSeparator,
                        }),
                      }}
                    />
                  )}
                </FormattedMessage>
              </small>
            </p>
          </Dropzone>
        )}
      </React.Fragment>
    );
  }
}

export default AssetUploader;
