import { uniq } from 'lodash';
import arrayToString from 'utils/arrayToString';

/*
 * ['application/pdf', 'image/jpeg'] => ['PDF', 'JPG']
 */
const getPrettyFormats = (formats: Array<string>): string[] =>
  uniq(
    formats.map(format => {
      switch (format) {
        case 'application/pdf':
          return 'PDF';

        case 'image/jpeg':
        case 'image/pjpeg':
          return 'JPG';

        case 'image/png':
          return 'PNG';

        default:
          return format;
      }
    }),
  );

type Args = {
  formats: string[];
  lastSeparator: string;
};

export const printFormats = ({ formats, lastSeparator }: Args): string =>
  arrayToString({ array: getPrettyFormats(formats), lastSeparator });
