import { defineMessages } from 'react-intl';
import { IntlMessages } from './../../../types/intl';

const messages: IntlMessages = defineMessages({
  placeholder: {
    id: 'asset-uploader-placeholder',
    defaultMessage: '<b>Browse</b> or drop your document here',
  },
  acceptedFormats: {
    id: 'asset-uploader-accepted-formats',
    defaultMessage: '{formats} are supported',
  },
  delete: {
    id: 'asset-uploader-delete',
    defaultMessage: 'Delete',
  },
});

export default messages;
