import React from 'react';
import ReactAutosuggest from 'react-autosuggest';

import './styles.scss';

type Props = ReactAutosuggest.AutosuggestProps<any, any> & {
  isLoading: boolean;
};

const Autosuggest = ({ isLoading, ...rest }: Props): React.ReactElement => {
  const loadingClass = isLoading ? 'is-loading' : '';

  return (
    <ReactAutosuggest
      theme={{
        container: `c-autosuggest ${loadingClass}`,
        containerOpen: 'has-suggestions',
        input: 'c-autosuggest__input l-form-control',
        suggestionsContainer: 'c-autosuggest__suggestions',
        suggestion: 'c-autosuggest__suggestion',
      }}
      {...rest}
    />
  );
};

export default Autosuggest;
