import React from 'react';
import { defineMessages, IntlShape, useIntl } from 'react-intl';
import warning from 'warning';

import { STATUS_NEUTRAL, STATUS_SUCCESS, STATUS_PENDING, STATUS_ERROR } from 'components/UI/Status';
import StatusBlock from 'components/UI/StatusBlock';

import { IntlMessages } from 'types/intl';

export const messages: IntlMessages = defineMessages({
  open: {
    id: 'settlement-status-open',
    defaultMessage: 'Open',
  },
  pending: {
    id: 'settlement-status-pending',
    defaultMessage: 'Pending',
  },
  failed: {
    id: 'settlement-status-failed',
    defaultMessage: 'Failed',
  },
  paidout: {
    id: 'settlement-status-paidout',
    defaultMessage: 'Settled',
  },
});

export const getSettlementStatusText = (intl: IntlShape, status: Props['status']): string => {
  warning(messages[status], `No translation found for settlement status '${status}'.`);

  return messages[status] ? intl.formatMessage(messages[status]) : (status as string);
};

type StatusBlockProps = React.ComponentProps<typeof StatusBlock>;

const mapSettlementStatusToStatus = (status: Props['status']): StatusBlockProps['status'] => {
  switch (status) {
    case 'paidout':
      return STATUS_SUCCESS;

    case 'pending':
      return STATUS_PENDING;

    case 'failed':
      return STATUS_ERROR;

    case 'open':
    default:
      return STATUS_NEUTRAL;
  }
};

type Props = {
  status: keyof typeof messages;
  className?: string;
};

const SettlementStatus: React.FC<Props> = ({ className, status }) => {
  const intl = useIntl();
  return (
    <StatusBlock status={mapSettlementStatusToStatus(status)} className={className}>
      {getSettlementStatusText(intl, status)}
    </StatusBlock>
  );
};

export default SettlementStatus;
