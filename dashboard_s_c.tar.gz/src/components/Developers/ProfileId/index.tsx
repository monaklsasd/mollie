import React from 'react';

// Components
import { STATUS_SUCCESS, STATUS_PENDING } from 'components/UI/Status';
import SummaryCardItem from 'components/UI/SummaryCard/Item';
import Key from 'components/UI/Key';

// Types
import { ProfileStatusType } from 'reduxState/modules/profiles/types';

type Props = {
  className?: string;
  profileId: string;
  profileStatus: ProfileStatusType;
};

class DevelopersProfileId extends React.Component<Props> {
  render(): React.ReactElement {
    const { className, profileId, profileStatus } = this.props;

    return (
      <SummaryCardItem className={className}>
        <Key
          status={profileStatus === 'verified' ? STATUS_SUCCESS : STATUS_PENDING}
          label="Profile ID" // Not translated, because all developer docs are in English
          title="Profile ID" // Not translated, because all developer docs are in English
          value={profileId}
          cloaked={false}
        />
      </SummaryCardItem>
    );
  }
}

export default DevelopersProfileId;
