import React from 'react';
import createComponentWithIntl from 'helpers/createComponentWithIntl';
import ProfileId from '../index';

type Props = React.ComponentProps<typeof ProfileId>;

describe('<ProfileId', () => {
  const props: Props = {
    profileId: 'pfl_1234567890',
    profileStatus: 'verified',
  };

  it('shows a profileId without a reset button', () => {
    const tree = createComponentWithIntl(<ProfileId {...props} />).toJSON();
    expect(tree).toMatchSnapshot();
  });
});
