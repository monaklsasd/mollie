import { IntlMessages } from './../../../types/intl';
import { defineMessages } from 'react-intl';

const messages: IntlMessages = defineMessages({
  resetApiKey: {
    id: 'profile-api-key-reset',
    defaultMessage: 'Reset',
  },
  resetApiKeyConfirm: {
    id: 'profile-api-key-reset-confirm-button',
    defaultMessage: 'Yes',
    description:
      'This button is used as positive feedback in a confirmation dialog when attempting to reset an API key.',
  },
  resetApiKeyDialogMessage: {
    id: 'profile-api-key-reset-confirm-dialog-message',
    defaultMessage:
      'Are you sure you want to reset the {mode, select, live {live} test {test}} API key? The current key will be invalidated.',
  },
  generatedAt: {
    id: 'profile-api-key-generated-at',
    defaultMessage: 'Generated on {date, date, normal} at {date, time, short}',
  },
  apiKeyTitle: {
    id: 'profile-api-key-name',
    defaultMessage: '{mode, select, live {Live} test {Test}} API key',
  },
  apiKeyNotYetAvailable: {
    id: 'profile-api-key-when-profile-verified',
    defaultMessage: 'Visible when your website profile has been verified.',
  },
});

export default messages;
