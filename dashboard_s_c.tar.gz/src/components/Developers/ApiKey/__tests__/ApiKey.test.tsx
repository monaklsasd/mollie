import React from 'react';
import { mountWithIntl } from 'helpers/createComponentWithIntl';
import { DevelopersApiKey } from '../index';

jest.mock('react-modal');

describe('<DevelopersApiKey>', () => {
  let props;
  const reset = jest.fn();

  beforeEach(() => {
    props = {
      onReset: reset,
      apiKey: {
        key: 'live_cVHWKgp76Qx2A3k65uz372nb4a3PQs',
        mode: 'live',
        createdDatetime: '2019-09-23T11:29:56.0Z',
      },
      permissions: [
        'balance-reports.read',
        'apikeys.read',
        'apikeys.write',
        'balances.read',
        'balances.write',
        'bankaccounts.read',
        'bankaccounts.write',
        'customers.write',
        'invoices.read',
        'mandates.read',
        'mandates.write',
        'memberships.read',
        'memberships.write',
        'onboarding.read',
        'onboarding.write',
        'orders.read',
        'orders.write',
        'organizations.read',
        'organizations.write',
        'payments.read',
        'payments.write',
        'profiles.read',
        'profiles.write',
        'refunds.read',
        'refunds.write',
        'settlements.read',
        'shipments.read',
        'shipments.write',
        'subscriptions.read',
        'subscriptions.write',
        'transfers.read',
        'transfers.write',
      ],
      profileId: 'pfl_BTRPbcmGvV',
      showKey: true,
    };
  });

  it('shows a live API key with a reset button', () => {
    const component = mountWithIntl(<DevelopersApiKey {...props} />);

    expect(component.find('button').children({ id: 'ui-key-reset' })).toHaveLength(1);
  });
});
