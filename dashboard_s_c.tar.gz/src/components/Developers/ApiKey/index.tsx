import React from 'react';
import { FormattedMessage } from 'react-intl';
import { injectIntl } from 'react-intl';

// Components
import Dialog from 'components/UI/Dialog';
import { STATUS_SUCCESS, STATUS_PENDING } from 'components/UI/Status';
import SummaryCardItem from 'components/UI/SummaryCard/Item';
import Key from 'components/UI/Key';

// Utils
import { hasPermissions } from 'containers/RequirePermissions';
import Permissions from 'helpers/permissions';

// Messages
import messages from './messages';

// Types
import { IntlShape } from 'react-intl';
import { ApiKey } from 'reduxState/modules/apiKeys/types';
import { AvailablePermissions } from 'helpers/permissions';

type Props = {
  className: string;
  profileId: string;
  showKey: boolean;
  apiKey: ApiKey;
  onReset: Function;
  intl: IntlShape;
  permissions: AvailablePermissions[];
};

export class DevelopersApiKey extends React.Component<Props> {
  static defaultProps = {
    showKey: true,
  };

  dialog: Dialog | null = null;

  handleReset = (e: React.MouseEvent<any, MouseEvent>): void => {
    e.preventDefault();

    const {
      profileId,
      apiKey: { mode },
      onReset,
    } = this.props;

    if (!this.dialog) {
      return;
    }

    this.dialog.show(() => {
      onReset({ profileId, mode });
    });
  };

  canReset = (): boolean => hasPermissions(this.props.permissions, [Permissions.APIKEYS_WRITE]);

  render(): React.ReactElement {
    const {
      intl,
      className,
      apiKey: { key, mode, createdDatetime },
      showKey,
    } = this.props;

    return (
      <SummaryCardItem className={className}>
        <Key
          status={mode === 'live' ? STATUS_SUCCESS : STATUS_PENDING}
          label={<FormattedMessage {...messages.apiKeyTitle} values={{ mode }} />}
          value={showKey ? key : ''}
          cloaked={mode === 'live'}
          onReset={this.canReset() ? this.handleReset : undefined}
          title={intl.formatMessage(messages.generatedAt, {
            date: new Date(createdDatetime),
          })}
          noKeyLabel={<FormattedMessage {...messages.apiKeyNotYetAvailable} />}
        />
        <Dialog
          ref={(c): void => {
            this.dialog = c;
          }}
          heading={intl.formatMessage(messages.resetApiKey)}
          byline={intl.formatMessage(messages.resetApiKeyDialogMessage, { mode })}
          confirmLabel={intl.formatMessage(messages.resetApiKeyConfirm)}
        />
      </SummaryCardItem>
    );
  }
}

export default injectIntl(DevelopersApiKey);
