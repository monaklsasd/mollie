import React from 'react';
import classNames from 'classnames';

// Components
import ApiKey from 'components/Developers/ApiKey';
import ProfileId from 'components/Developers/ProfileId';
import SummaryCard from 'components/UI/SummaryCard';

// Types
import { ApiKeyItem } from 'reduxState/modules/apiKeys/types';
import { ClassnamesFunction } from 'types/helpers';
import { AvailablePermissions } from 'helpers/permissions';

import './styles.scss';

type Props = ApiKeyItem & {
  onReset: (event: React.MouseEvent<any, MouseEvent>) => void;
  permissions: AvailablePermissions[];
  showProfile?: boolean;
};

const getClassName: ClassnamesFunction<{ hasKey?: boolean }> = ({ hasKey = true }) =>
  classNames('developers-api-keys__item', {
    'developers-api-keys__item--has-key': hasKey,
  });

const ProfileApiKeys: React.FC<Props> = ({
  profileName,
  profileWebsite,
  profileStatus,
  profileId,
  live,
  test,
  showProfile = true,
  permissions,
  onReset,
}) => (
  /* @TODO findout how apiKey works, remove @ts-ignore and solve error */
  <SummaryCard heading={profileName} byline={profileWebsite} showHeader={showProfile}>
    <ApiKey
      className={getClassName({ hasKey: profileStatus === 'verified' })}
      // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
      // @ts-ignore
      apiKey={live}
      profileId={profileId}
      permissions={permissions}
      onReset={onReset}
      showKey={profileStatus === 'verified'}
    />

    <ApiKey
      showKey
      className={getClassName({})}
      apiKey={test}
      profileId={profileId}
      permissions={permissions}
      onReset={onReset}
    />

    <ProfileId className={getClassName({})} profileId={profileId} profileStatus={profileStatus} />
  </SummaryCard>
);

export default ProfileApiKeys;
