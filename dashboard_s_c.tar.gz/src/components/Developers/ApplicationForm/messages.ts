import { defineMessages } from 'react-intl';
import { IntlMessages } from 'types/intl';

const messages: IntlMessages = defineMessages({
  description: {
    id: 'developers-application-form-description',
    defaultMessage:
      '<p>Your application’s name and description will be displayed to the user on the authorization screen. For information about developing applications check out the <a href={docsLocations} rel="noopener" target="_blank">Mollie Connect documentation</a>.</p>',
  },
  redirectHelp: {
    id: 'developers-application-form-redirect-help',
    defaultMessage: 'The user will be sent here after they authorized or rejected your app.',
  },
  redirectUrlPlaceholder: {
    id: 'developers-application-form-redirect-url-placeholder',
    defaultMessage: 'https://www.example.com or app://action',
  },
});

export const formFields = defineMessages({
  name: {
    id: 'connect-formfield-application-name',
    defaultMessage: 'Name',
  },
  description: {
    id: 'connect-formfield-application-description',
    defaultMessage: 'Description',
  },
  redirectUrl: {
    id: 'connect-formfield-application-redirectUrl',
    defaultMessage: 'Redirect URL',
  },
});

export default messages;
