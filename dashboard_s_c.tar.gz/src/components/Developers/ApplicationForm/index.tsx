import React from 'react';
import { injectIntl, FormattedMessage, FormattedHTMLMessage } from 'react-intl';

// Components
import Fieldset from 'components/forms/Fieldset';
import ButtonGroup from 'components/UI/ButtonGroup';
import Button from 'components/UI/Button';
import FormikForm from 'containers/forms/FormikForm';
import FormikGroup from 'components/forms/FormikGroup';

// Messages
import globalMessages from 'messages';
import formMessages from 'messages/forms';
import messages, { formFields } from './messages';

// Types
import { IntlShape } from 'react-intl';

type Props = {
  intl: IntlShape;
  isSubmitting: boolean;
};

const ApplicationForm = ({ intl, isSubmitting }: Props): React.ReactElement => (
  <FormikForm>
    <Fieldset
      description={
        <FormattedHTMLMessage
          {...messages.description}
          values={{
            docsLocations: intl.formatMessage(globalMessages.docsOverviewLocation),
          }}
        />
      }
      splitColumns>
      <FormikGroup label={<FormattedMessage {...formFields.name} />} name="name">
        {(field): React.ReactElement => <input className="l-form-control" type="text" {...field} />}
      </FormikGroup>
      <FormikGroup label={<FormattedMessage {...formFields.description} />} name="description">
        {(field): React.ReactElement => <input className="l-form-control" type="text" {...field} />}
      </FormikGroup>
      <FormikGroup
        // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
        // @ts-ignore
        fullWidth
        label={<FormattedMessage {...formFields.redirectUrl} />}
        name="redirectUrl"
        help={<FormattedMessage {...messages.redirectHelp} />}>
        {(field): React.ReactElement => (
          <input
            type="url"
            className="l-form-control"
            placeholder={intl.formatMessage(formMessages.exampleValue, {
              value: intl.formatMessage(messages.redirectUrlPlaceholder),
            })}
            {...field}
          />
        )}
      </FormikGroup>
    </Fieldset>
    <ButtonGroup>
      <Button primary size="large" isLoading={isSubmitting}>
        <FormattedMessage {...formMessages.formBtnSave} />
      </Button>
      <Button to="/developers/applications" size="large" type="button" disabled={isSubmitting}>
        <FormattedMessage {...formMessages.formBtnCancel} />
      </Button>
    </ButtonGroup>
  </FormikForm>
);

export default injectIntl(ApplicationForm);
