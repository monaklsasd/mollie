import React, { Component } from 'react';

import { FormattedMessage, injectIntl, IntlShape } from 'react-intl';

// Containers
import RequirePermissions, { Permissions } from 'containers/RequirePermissions';

// Components
import Avatar from 'components/Avatar';
import ButtonGroup from 'components/UI/ButtonGroup';
import Dialog from 'components/UI/Dialog';
import Link from 'components/UI/Link';
import SummaryCard from 'components/UI/SummaryCard';
import SummaryCardItem from 'components/UI/SummaryCard/Item';

interface Props {
  application: {
    id: string;
    name: string;
    website: string;
    redirectUrl: string;
    iconUrl: string;
    clientSecret: string;
  };
  deleteDevelopedApplication: (id: string) => void;
  intl: IntlShape;
}

interface State {
  secretVisible: boolean;
}

class DevelopedApplication extends Component<Props, State> {
  state = {
    secretVisible: false,
  };

  dialog: Nullable<Dialog> = null;

  handleDelete = (): void => {
    const {
      application: { id },
      deleteDevelopedApplication,
    } = this.props;

    if (!this.dialog) {
      return;
    }

    this.dialog.show(() => {
      deleteDevelopedApplication(id);
    });
  };

  handleToggleSecret = (): void => {
    this.setState({
      secretVisible: true,
    });
  };

  render(): React.ReactNode {
    const {
      application: { id, name, website, redirectUrl, iconUrl, clientSecret },
    } = this.props;

    return (
      <>
        <SummaryCard
          avatar={
            <Avatar seed={name}>
              <img src={iconUrl} alt="" />
            </Avatar>
          }
          controls={
            <RequirePermissions permissions={[Permissions.DEVELOPED_APPLICATIONS_WRITE]}>
              <ButtonGroup>
                <Link linkStyle="blue" to={`/developers/applications/${id}`}>
                  <FormattedMessage
                    id="settings-developed-applications-button-edit"
                    defaultMessage="Edit"
                  />
                </Link>
                <Link linkStyle="danger" onClick={this.handleDelete}>
                  <FormattedMessage
                    id="settings-developed-applications-button-delete"
                    defaultMessage="Delete"
                  />
                </Link>
              </ButtonGroup>
            </RequirePermissions>
          }
          heading={name}
          byline={website}>
          <SummaryCardItem>
            <span>
              <FormattedMessage
                id="settings-developed-applications-redirect-url"
                defaultMessage="Redirect URL"
              />
              :
            </span>
            {redirectUrl}
          </SummaryCardItem>
          <SummaryCardItem>
            <span>
              <FormattedMessage
                id="settings-developed-applications-client-id"
                defaultMessage="Client ID"
              />
              :
            </span>
            {id}
          </SummaryCardItem>
          <SummaryCardItem>
            <span>
              <FormattedMessage
                id="settings-developed-applications-client-secret"
                defaultMessage="Client secret"
              />
              :
            </span>
            {this.state.secretVisible ? (
              clientSecret
            ) : (
              <Link onClick={this.handleToggleSecret}>
                <FormattedMessage
                  id="settings-developed-applications-show-secret"
                  defaultMessage="Show secret"
                />
              </Link>
            )}
          </SummaryCardItem>
        </SummaryCard>
        <Dialog
          ref={(c): void => {
            this.dialog = c;
          }}
          heading={
            <FormattedMessage
              id="settings-developed-applications-delete-confirmation-heading"
              defaultMessage="Are you sure you want to delete ‘{name}‘?"
              values={{ name }}
            />
          }
          byline={
            <FormattedMessage
              id="settings-developed-applications-delete-confirmation-description"
              defaultMessage="The application will stop working for all users."
            />
          }
          confirmLabel={
            <FormattedMessage
              id="settings-developed-applications-delete-button-label"
              defaultMessage="Delete application"
            />
          }
        />
      </>
    );
  }
}

export default injectIntl(DevelopedApplication);
