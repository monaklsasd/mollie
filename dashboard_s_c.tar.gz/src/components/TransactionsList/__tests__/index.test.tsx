/* eslint-disable @typescript-eslint/no-empty-function */
import React from 'react';
import { shallow } from 'enzyme';

import RefundsTable from 'components/Refunds/RefundsTable';
import EmptyList from 'components/EmptyList';
import FlashMessage from 'components/UI/FlashMessage';

import { TransactionsList } from '../index';

describe('<TransactionsList>', () => {
  let props;

  beforeEach(() => {
    props = {
      isLoading: false,
      data: [],
      error: null,
      hasMore: false,
      updatedAt: null,
      pagination: {},

      fetchData: (): void => {},
      fetchMoreData: (): void => {},
      toggleFilters: (): void => {},
      filtersAreVisible: false,
      permissions: [],
      filters: {},
      showResetButton: false,
      methods: [],
      location: {
        query: {},
        pathname: '',
        search: '',
        action: '',
      },
      history: {
        push: (): void => {},
        replace: (): void => {},
        go: (): void => {},
        goBack: (): void => {},
        goForward: (): void => {},
        setLeaveHook: (): void => {},
        setRouteLeaveHook: (): void => {},
        isActive: (): void => {},
      },
      tableComponent: RefundsTable,
      emptyMessage: '',
    };
  });

  it('renders an error view when error is provided', () => {
    const error = '-- My error message --';

    const wrapper = shallow(<TransactionsList {...props} error={error} />);
    expect(wrapper.find(FlashMessage).length).toEqual(1);
  });

  it('renders a no data found view when no refunds have been found for a filter', () => {
    const filters = {
      method: 'ideal',
    };

    const wrapper = shallow(
      <TransactionsList
        {...props}
        isLoading={false}
        filters={filters}
        pagination={{ totalCount: 0 }}
      />,
    );
    expect(wrapper.find(EmptyList).length).toEqual(1);
    expect(wrapper.find(RefundsTable).length).toEqual(0);
  });

  it('renders the data list (not loading)', () => {
    const data = [{ id: 're_abcdef' }];

    const wrapper = shallow(
      <TransactionsList
        {...props}
        isLoading={false}
        pagination={{ totalCount: data.length }}
        data={data}
      />,
    );
    expect(wrapper.find(RefundsTable).length).toEqual(1);
    expect(wrapper.find(EmptyList).length).toEqual(0);
  });

  it('renders the data list. Loading state instead of data list.', () => {
    const data = [{ id: 're_abcdef' }, { id: 're_aghijk' }];

    const wrapper = shallow(
      <TransactionsList
        {...props}
        isLoading
        pagination={{ totalCount: data.length }}
        data={data}
      />,
    );
    expect(wrapper.find(RefundsTable).length).toEqual(0);
    expect(wrapper.find(EmptyList).length).toEqual(1);
  });
});
