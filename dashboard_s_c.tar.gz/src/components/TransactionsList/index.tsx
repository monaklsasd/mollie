import React from 'react';
import { withRouter, RouteComponentProps } from 'react-router-dom';
import InfiniteScroll from 'react-infinite-scroller';
import moment from 'moment';
import { isEmpty, omit } from 'lodash';

// Components
import FlashMessage from 'components/UI/FlashMessage';
import LoadingState from 'components/UI/LoadingState';
import Layout from 'components/UI/Layout';
import EmptyList from 'components/EmptyList';
import TransactionsFilters from 'components/TransactionsFilters';

// Utils
import { isEqual } from 'lodash';
import { getResetRoute } from 'containers/Transactions/utils';
import { toggleQueryStringItem } from 'utils/filters';

// Types
import { FilterType } from './types';
import { ActionType, PaginationState } from 'reduxState/types';

// Stylesheets
import './styles.scss';
import { Location } from 'history';
import DatePresets, { PresetType } from 'components/UI/DatePresets';

const FETCH_INTERVAL = 300000; // 5 minutes in milliseconds
const DATE_FORMAT = 'YYYY-MM-DD';

const DATE_PRESETS = ['anytime', 'today', 'this_week', 'this_month', 'custom'] as PresetType[];

type Props = RouteComponentProps & {
  location: Location<{}, FilterType>;
  calculatedFilters: FilterType;
  data: any[];
  emptyMessage: React.ReactNode;
  error: Nullable<string>;
  fetchData: <P = any>(payload?: P | undefined) => ActionType<string, P>;
  fetchMoreData: <P = any>(payload?: P | undefined) => ActionType<string, P>;
  filters: FilterType;
  filtersAreVisible: boolean;
  filterOptions: string[];
  hasMore: boolean;
  isLoading: boolean;
  methods: any[];
  statuses: any[];
  currencies: any[];
  pagination: PaginationState;
  /*
   * Should be React.Component<*> | React.StatelessFunctionalComponent<*>
   * but the latter is not supported in our version of React yet (15.6.1)
   */
  tableComponent: any;
  toggleFilters: React.MouseEventHandler;
  updatedAt: Nullable<number>;
  profiles: {
    id: string;
    name: string;
    website: string;
  }[];
  mode: 'live' | 'test';
  wasLoadedWithMode: Maybe<'live' | 'test'> | null;
  supportedMethods?: Array<string>;
  supportsTestmode?: boolean;
  noTestmodeMessage?: React.ReactNode;
};

export class TransactionsList extends React.Component<Props> {
  static defaultProps = {
    supportsTestmode: true,
  };

  componentDidMount(): void {
    const {
      fetchData,
      calculatedFilters,
      data,
      updatedAt,
      wasLoadedWithMode,
      mode,
      supportsTestmode,
    } = this.props;

    // Never fetch testmode data if testmode is not supported
    if (mode === 'test' && !supportsTestmode) {
      return;
    }

    /*
     * Fetch data if:
     * - There is none (no kidding)
     * - We haven't fetched in some time, there might be new data
     * - The data we have was fetched with a different mode
     */
    if (
      !data.length ||
      Date.now() - Number(updatedAt) > FETCH_INTERVAL ||
      wasLoadedWithMode !== mode
    ) {
      fetchData({ filters: calculatedFilters, mode });
    }
  }

  componentDidUpdate(prevProps: Props): void {
    const { calculatedFilters, mode, fetchData, supportsTestmode } = this.props;

    if (
      // Do not fetch testmode data if testmode is not supported
      (mode === 'test' && !supportsTestmode) ||
      // Do not fetch data if both the filters and mode are the same
      (isEqual(prevProps.calculatedFilters, calculatedFilters) && mode === prevProps.mode)
    ) {
      return;
    }

    fetchData({ filters: calculatedFilters, mode });
  }

  handleStatusChange = (status: string) => (): void => {
    this.updateLocation({
      status: toggleQueryStringItem(status, this.props.location.query.status),
    });
  };

  handleMethodChange = (method: string) => (): void => {
    this.updateLocation({
      methods: toggleQueryStringItem(method, this.props.location.query.methods),
    });
  };

  handleCurrencyChange = (currency: string) => (): void => {
    this.updateLocation({
      currency: toggleQueryStringItem(currency, this.props.location.query.currency),
    });
  };

  handleDatePresetChange = (preset: PresetType): void => {
    const query = {
      period: preset,
    };

    this.updateLocation(query);
  };

  handleDatesChange = ({ startDate, endDate }: { startDate?: string; endDate?: string }): void => {
    const query = {
      from: startDate ? moment(startDate).format(DATE_FORMAT) : undefined,
      to: endDate ? moment(endDate).format(DATE_FORMAT) : undefined,
    };

    this.updateLocation(query);
  };

  handleQueryChange = (searchQuery: Maybe<string>): void => {
    const query = {
      q: searchQuery || undefined,
    };

    this.updateLocation(query);
  };

  handleLoadMore = (): void => {
    // Use RaF (debounce) to make sure isLoadMore is update when scrolling
    // Fixes making duplicate xhr requests
    requestAnimationFrame(() => {
      const { filters, pagination, mode } = this.props;
      const offset = (pagination.offset || 0) + (pagination.count || 0);

      if (pagination.isLoadingMore) {
        return;
      }

      this.props.fetchMoreData({ filters, count: pagination.count, offset, mode });
    });
  };

  updateLocation(query: FilterType): void {
    const { history, location } = this.props;

    /**
     * If a user selected a date preset (&period=custom), we should not
     * add the 'from' and 'to' query parameters to the URL, since those are
     * calculated in the datePresets.
     */
    if (query.period && query.period !== 'custom') {
      delete location.query.from;
      delete location.query.to;
    }

    /**
     * When ever the period is anytime we could remove this from the URL.
     * cause the period='anytime' would be the same as / We have to remove it here
     * to guarantee there is a push been dispatched.
     */
    if (query.period && query.period === 'anytime') {
      query.period = undefined;
    }

    history.push({
      pathname: location.pathname,
      query: {
        ...location.query,
        ...query,
      },
    });
  }

  renderList(): React.ReactElement {
    const {
      data,
      tableComponent: Table,
      error,
      hasMore,
      isLoading,
      location,
      pagination,
      emptyMessage,
    } = this.props;

    if (error) {
      return <FlashMessage>{error}</FlashMessage>;
    }

    if (isLoading || !data.length || pagination.totalCount === 0) {
      return (
        <EmptyList
          title={emptyMessage}
          location={location}
          isLoading={isLoading}
          resetFiltersLink={getResetRoute(location)}
        />
      );
    }

    return (
      <InfiniteScroll
        key="list"
        pageStart={0}
        loadMore={this.handleLoadMore}
        hasMore={hasMore}
        loader={<LoadingState key="loadMore" isLoading compact noBorder delay={2000} />}
        threshold={600}>
        <Table totalCount={pagination.totalCount || 0} data={data} />
      </InfiniteScroll>
    );
  }

  render(): React.ReactElement {
    const {
      filtersAreVisible,
      filterOptions,
      toggleFilters,
      methods,
      location,
      statuses,
      currencies,
      supportsTestmode,
      noTestmodeMessage,
      mode,
    } = this.props;

    if (mode === 'test' && !supportsTestmode) {
      return <FlashMessage state="warning">{noTestmodeMessage}</FlashMessage>;
    }

    type DatePresetsTypes = React.ComponentProps<typeof DatePresets>;

    const selectedDates: DatePresetsTypes['selectedDates'] = {
      startDate: location.query.from ? moment(location.query.from, DATE_FORMAT) : undefined,
      endDate: location.query.to ? moment(location.query.to, DATE_FORMAT) : undefined,
    };

    const showResetButton = !isEmpty(omit(location.query, ['profileId', 'testmode']));
    const resetRoute = getResetRoute(location);

    return (
      <Layout
        className="c-transactions-list"
        hasFilters
        sidebar={
          <TransactionsFilters
            className="c-transactions-list__filters"
            filtersAreVisible={filtersAreVisible}
            closeFilters={toggleFilters}
            methods={methods}
            statuses={statuses}
            currencies={currencies}
            location={location as any}
            datePresets={DATE_PRESETS}
            onQueryChange={this.handleQueryChange}
            onDatesChange={this.handleDatesChange}
            onPresetChange={this.handleDatePresetChange}
            onStatusChange={this.handleStatusChange}
            onMethodChange={this.handleMethodChange}
            onCurrencyChange={this.handleCurrencyChange}
            selectedDates={selectedDates}
            resetRoute={resetRoute}
            showResetButton={showResetButton}
            options={filterOptions}
          />
        }>
        <div className="c-transactions-list__body">{this.renderList()}</div>
      </Layout>
    );
  }
}

export default withRouter(TransactionsList);
