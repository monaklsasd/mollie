import { PresetType } from 'components/UI/DatePresets';

export type FilterType = {
  status?: Maybe<string>;
  methods?: Maybe<string>;
  testmode?: Maybe<string>;
  profileId?: Maybe<string>;
  from?: Maybe<string>;
  to?: Maybe<string>;
  period?: Maybe<PresetType>;
  currency?: Maybe<string>;
  q?: Maybe<string>;
};
