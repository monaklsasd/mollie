import { defineMessages } from 'react-intl';
import { IntlMessages } from 'types/intl';

const messages: IntlMessages = defineMessages({
  instantly: {
    id: 'boarding-organization-bank-account-byline-instantly',
    defaultMessage: 'Instantly',
    description: 'Is shown underneath the verification payment method.',
  },
  nextBusinessDay: {
    id: 'boarding-organization-bank-account-byline-next-business-day',
    defaultMessage: 'Next business day',
    description: 'Is shown underneath the verification payment method.',
  },
  verificationMethodTwoDays: {
    id: 'boarding-organization-bank-account-byline-two-days',
    defaultMessage: 'May take 2-3 business days',
    description: 'Is shown underneath the verification payment method.',
  },
  verificationMethodFallbackByLine: {
    id: 'boarding-organization-bank-account-fallback-byline',
    defaultMessage: 'May take 2-5 business days',
    description:
      'Is shown underneath the verification method name for payment methods that do not have an custom translation.',
  },
  verificationMethodProvideValidIbanFirst: {
    id: 'boarding-organization-bank-account-provide-iban-first',
    defaultMessage: 'Please provide a valid IBAN first.',
  },
  noPaymentMethodFoundForProvidedBankAccountNumber: {
    id: 'bankaccount-verify-no-payment-method-found',
    defaultMessage: 'No payment methods found for the provided IBAN.',
    description:
      'Is shown when there are no payment methods found for the provided bank account number.',
  },
  bankAccountRejected: {
    id: 'boarding-organization-bank-account-status-failed',
    defaultMessage: 'Bank account rejected.',
  },
  bankAccountPending: {
    id: 'boarding-organization-bank-account-status-pending',
    defaultMessage:
      'The bank account verification is pending. We will wait until you complete the verification payment.',
  },
  bankAccountFailed: {
    id: 'boarding-organization-bank-account-status-verification-failed',
    defaultMessage: 'The verification payment failed.',
  },
  bankAccountIbanMismatch: {
    id: 'boarding-organization-bank-account-status-verification-iban-mismatch',
    defaultMessage:
      'We could not match the IBAN of the verification payment with the provided bank account <strong>{providedIBAN}</strong>. Please make sure you use the correct business bank account to make the verification payment.',
  },
  bankAccountNameMismatch: {
    id: 'boarding-organization-bank-account-status-verification-name-mismatch',
    defaultMessage:
      'We could not match the account holder of the verification payment with one of your tradenames. Please make sure that the provided bank account <strong>{providedIBAN}</strong> belongs to one of your tradenames.',
  },
  bankAccountCancelled: {
    id: 'boarding-organization-bank-account-status-verification-cancelled',
    defaultMessage:
      "You've cancelled the verification payment. Please complete the verification with a new payment below.",
  },
  bankAccountInfoPending: {
    id: 'boarding-organization-bank-account-status-verification-info-pending',
    defaultMessage:
      "The verification payment has been completed. Unfortunately we didn't receive all payment details yet so we currently can't complete the verification of your bank account. We'll have to wait for the payment to be transferred to our bank account.",
    description:
      'IBAN or account holder unknown. We have to wait for the payment to be transferred to our bank account.',
  },
});

export default messages;
