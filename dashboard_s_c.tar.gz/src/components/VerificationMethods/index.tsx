import React, { Component } from 'react';
import { FormattedMessage, FormattedHTMLMessage, MessageDescriptor } from 'react-intl';

// Components
import { ListItem, FlashMessage, LoadingState } from 'components/UI';
import IconPaymentMethods from 'components/IconPaymentMethods';
import RadioButtonGroup from 'components/forms/RadioButtonGroup';

// Helpers
import PAYMENT_METHODS from 'helpers/paymentMethods';

// Utils
import getLocalizedMethodName from 'utils/getLocalizedMethodName';
import formatIBAN from 'utils/formatIBAN';

// Messages
import messages from './messages';

// Types
import { FormikProps } from 'formik';
import { PaymentMethod } from 'helpers/paymentMethods';
import { BankAccount } from 'reduxState/modules/bankAccounts/types';

import './styles.scss';

type Props = {
  verificationMethods: Record<string, any>;
  bankAccount?: BankAccount;
} & FormikProps<any>;

const getVerificationMethodByLine = (method: PaymentMethod): MessageDescriptor => {
  switch (method) {
    case PAYMENT_METHODS.IDEAL:
    case PAYMENT_METHODS.MYBANK:
      return messages.instantly;

    case PAYMENT_METHODS.SOFORT:
      return messages.verificationMethodTwoDays;

    case PAYMENT_METHODS.BELFIUS:
    case PAYMENT_METHODS.KBC:
    case PAYMENT_METHODS.INGHOMEPAY:
      return messages.nextBusinessDay;

    default:
      return messages.verificationMethodFallbackByLine;
  }
};

const getVerificationStatus = (bankAccount: BankAccount) => {
  let type = 'danger';
  let message: Nullable<React.ReactElement> = null;

  /**
   * @see Api\Transformer\Internal\Customer\Bankaccount
   **/
  switch (bankAccount.status) {
    case 'failed':
      type = 'error';
      message = <FormattedMessage {...messages.bankAccountRejected} />;
      break;

    case 'pending':
      type = 'warning';
      message = <FormattedMessage {...messages.bankAccountPending} />;
      break;

    case 'verification-failed':
      type = 'error';
      message = <FormattedMessage {...messages.bankAccountFailed} />;
      break;

    case 'verification-iban-mismatch':
      type = 'error';
      message = (
        <FormattedHTMLMessage
          {...messages.bankAccountIbanMismatch}
          values={{
            providedIBAN: formatIBAN(bankAccount.accountNumber, { pretty: true }),
          }}
        />
      );
      break;

    case 'verification-name-mismatch':
      type = 'error';
      message = (
        <FormattedHTMLMessage
          {...messages.bankAccountNameMismatch}
          values={{
            providedIBAN: formatIBAN(bankAccount.accountNumber, { pretty: true }),
          }}
        />
      );
      break;

    case 'verification-cancelled':
      type = 'error';
      message = <FormattedMessage {...messages.bankAccountCancelled} />;
      break;

    case 'verification-info-pending':
      type = 'warning';
      message = <FormattedMessage {...messages.bankAccountInfoPending} />;
      break;
    // no default
  }

  if (message) {
    return <FlashMessage state={type as any}>{message}</FlashMessage>;
  }

  return null;
};

const selectedMethodIsUnavailableForIBAN = (selectedMethod, availableMethods): boolean =>
  availableMethods && !availableMethods.includes(selectedMethod);

class VerificationMethods extends Component<Props> {
  componentDidUpdate(prevProps: Props): void {
    const { values, verificationMethods, setFieldValue } = this.props;
    if (
      verificationMethods.data !== prevProps.verificationMethods.data &&
      selectedMethodIsUnavailableForIBAN(values.method, verificationMethods.data)
    ) {
      // Set method to first verification method
      setFieldValue('method', verificationMethods.data[0]);
    }
  }

  render(): React.ReactNode {
    const { errors, values, verificationMethods, bankAccount } = this.props;

    let content;
    if (!values.bankAccountNumber || errors.bankAccountNumber) {
      content = (
        <FlashMessage state="info">
          <FormattedMessage {...messages.verificationMethodProvideValidIbanFirst} />
        </FlashMessage>
      );
    } else if (verificationMethods.errors && verificationMethods.errors.bankAccountNumber) {
      content = (
        <FlashMessage state="error">
          <FormattedMessage {...verificationMethods.errors.bankAccountNumber} />
        </FlashMessage>
      );
    } else if (verificationMethods.isLoaded && !verificationMethods.data.length) {
      content = (
        <FlashMessage state="info">
          <FormattedMessage {...messages.noPaymentMethodFoundForProvidedBankAccountNumber} />
        </FlashMessage>
      );
    } else if (verificationMethods.data && verificationMethods.data.length) {
      content = (
        <div>
          <RadioButtonGroup name="method">
            {(RadioButton): React.ReactElement => (
              <ul className="l-list-ui">
                {verificationMethods.data.map(methodId => (
                  <li key={methodId}>
                    <ListItem
                      className="verification-methods-list-item"
                      tag="label"
                      htmlFor={`input-radio-${methodId}`}
                      icon={<IconPaymentMethods method={methodId} />}
                      heading={getLocalizedMethodName(methodId)}
                      byline={<FormattedHTMLMessage {...getVerificationMethodByLine(methodId)} />}
                      control={<RadioButton insideLabel value={methodId} />}
                      size="compact"
                    />
                  </li>
                ))}
              </ul>
            )}
          </RadioButtonGroup>
        </div>
      );
    }

    return (
      <LoadingState isLoading={verificationMethods.isLoading} compact noMargin>
        <div>
          {bankAccount && getVerificationStatus(bankAccount)}
          {content}
        </div>
      </LoadingState>
    );
  }
}

export default VerificationMethods;
