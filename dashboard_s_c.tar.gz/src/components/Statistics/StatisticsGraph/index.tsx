import React from 'react';
import { FormattedMessage, FormattedDate, injectIntl } from 'react-intl';
import { IntlShape } from 'react-intl';
import { ResponsiveContainer, AreaChart, Area, CartesianGrid, XAxis, YAxis } from 'recharts';
import moment from 'moment';

// Components
import { FlashMessage, LoadingIndicator } from 'components/UI';
import StatisticsTick from 'components/Statistics/StatisticsTick';
import StatisticsTooltip from 'components/Statistics/StatisticsTooltip';

import * as constants from 'containers/Statistics/constants';

// Utils
import autobind from 'utils/autobind';
import getDocumentWidth from 'utils/getDocumentWidth';
import shallowEqual from 'utils/shallowEqual';

// Types
import { ItemStateType } from 'containers/Statistics/types';

import './styles.scss';

type DataPointType = {
  timestamp: number;
  paymentMethods: {};
  currentAmount?: number;
  previousTimestamp?: number;
  previousAmount?: number;
};

const filterDataPoints = (x, i, dataPoints): boolean => {
  // If we have over 80 data points on a small screen, filter out
  // two thirds so the graph remains properly viewable.
  if (dataPoints.length > 80 && getDocumentWidth() < 560) {
    return i % 3 === 0;
  }

  // If we have over 80 data points (or 40 on a small screen, filter out
  // half so the graph remains properly viewable.
  if (dataPoints.length > 80 || (dataPoints.length > 40 && getDocumentWidth() < 560)) {
    return i % 2 === 0;
  }

  return true;
};

const renderPeriodLabel = (timestamps, interval): React.ReactElement => {
  const fromDate = new Date(timestamps.from * 1000);
  const toDate = new Date(timestamps.to * 1000);

  switch (interval) {
    case constants.INTERVAL_DAY:
      return <FormattedDate value={fromDate} weekday="long" day="numeric" month="long" />;

    case constants.INTERVAL_WEEK:
      return (
        <FormattedMessage
          defaultMessage="Week {weekNumber}"
          id="statistics-label-week"
          values={{
            weekNumber: moment(fromDate.toISOString()).format('W'),
          }}
        />
      );

    case constants.INTERVAL_MONTH:
      return <FormattedDate value={fromDate} month="long" year="numeric" />;

    case constants.INTERVAL_QUARTER:
      return (
        <FormattedMessage
          defaultMessage="Q{quarterNumber}"
          id="statistics-label-quarter"
          values={{
            quarterNumber: moment(fromDate.toISOString()).format('Q Y'),
          }}
        />
      );

    case constants.INTERVAL_YEAR:
      return <FormattedDate value={fromDate} year="numeric" />;

    default:
      return (
        <span>
          <FormattedDate value={fromDate} day="numeric" month="numeric" year="numeric" />
          {' - '}
          <FormattedDate value={toDate} day="numeric" month="numeric" year="numeric" />
        </span>
      );
  }
};

const calculateData = (data, prevData): any => {
  if (!data.timeSeries.length) {
    return [];
  }

  const now = Date.now() / 1000;

  return data.timeSeries.filter(filterDataPoints).map((x, i) => {
    const dataPoint: DataPointType = {
      timestamp: x.timestamp,
      paymentMethods: x.paymentMethods,
    };

    if (x.timestamp <= now) {
      dataPoint.currentAmount = x.totals.payments.amount;
    }

    // eslint-disable-next-line no-param-reassign
    prevData.timeSeries = prevData.timeSeries.filter(filterDataPoints);

    if (prevData.timeSeries[i]) {
      dataPoint.previousTimestamp = prevData.timeSeries[i].timestamp;
      dataPoint.previousAmount = prevData.timeSeries[i].totals.payments.amount;

      /*
       * Ok this looks complicated, but what we’re doing here is turning this:
       * { amount: 10 }
       *
       * into this:
       *
       * { amount: 10, previousAmount: 5 }
       *
       * for each payment method.
       */
      dataPoint.paymentMethods = Object.keys(dataPoint.paymentMethods).reduce(
        (carry, id) => ({
          ...carry,
          [id]: {
            amount: dataPoint.paymentMethods[id].payments.amount,
            previousAmount: prevData.timeSeries[i].paymentMethods[id]
              ? prevData.timeSeries[i].paymentMethods[id].payments.amount
              : 0,
          },
        }),
        {},
      );
    }

    return dataPoint;
  });
};

type Props = {
  interval: Maybe<string>;
  unit: string;
  prevStatistics: ItemStateType;
  statistics: ItemStateType;
  intl: IntlShape;
};

type State = {
  data: any[];
  mirrorYAxis: boolean;
  tickInterval: 4 | 1;
};

class StatisticsGraph extends React.Component<Props, State> {
  constructor(props) {
    super(props);

    this.state = {
      data: [],
      mirrorYAxis: getDocumentWidth() < 680,
      tickInterval: getDocumentWidth() < 860 ? 4 : 1,
    };

    autobind(this);
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    this.asCurrency = this.asCurrency.bind(this);
  }

  componentWillReceiveProps(nextProps): void {
    // Don’t do anything if props are the same
    if (
      shallowEqual(nextProps.statistics.data, this.props.statistics.data) &&
      shallowEqual(nextProps.prevStatistics.data, this.props.prevStatistics.data)
    ) {
      return;
    }

    // Calculate new data when we have data for both current and previous statistics
    this.setState({
      data: calculateData(nextProps.statistics.data, nextProps.prevStatistics.data),
      mirrorYAxis: getDocumentWidth() < 680,
      tickInterval: getDocumentWidth() < 860 ? 4 : 1,
    });
  }

  asCurrency(amount): string {
    return this.props.intl.formatNumber(amount, {
      style: 'currency',
      currency: 'EUR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    });
  }

  render(): React.ReactElement {
    const { interval, unit, statistics, prevStatistics } = this.props;

    const { data, mirrorYAxis, tickInterval } = this.state;

    return (
      <div className="c-statistics-graph">
        {statistics.error && <FlashMessage>{statistics.error}</FlashMessage>}
        {(statistics.isLoading || prevStatistics.isLoading) && <LoadingIndicator delay={800} />}
        <div className="c-statistics-graph__chart">
          <ul className="c-statistics-graph__legend">
            <li>
              <FormattedMessage
                id="statistics-graph-toggle-current-period"
                defaultMessage="Current period"
              />
              {statistics.data.from && (
                <span className="c-statistics-graph__period-label">
                  {' '}
                  ({renderPeriodLabel(statistics.data, interval)})
                </span>
              )}
            </li>
            <li>
              <FormattedMessage
                id="statistics-graph-toggle-previous-period"
                defaultMessage="Previous period"
              />
              {prevStatistics.data.from && (
                <span className="c-statistics-graph__period-label">
                  {' '}
                  ({renderPeriodLabel(prevStatistics.data, interval)})
                </span>
              )}
            </li>
          </ul>
          <ResponsiveContainer width="100%" height={400}>
            <AreaChart
              data={data}
              margin={{
                top: 5,
                left: 5,
                right: 20,
                bottom: 10,
              }}>
              <defs>
                <linearGradient id="previous" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#63BFFF" stopOpacity={0} />
                  <stop offset="3%" stopColor="#63BFFF" stopOpacity={0.1} />
                  <stop offset="97%" stopColor="#63BFFF" stopOpacity={0.1} />
                  <stop offset="100%" stopColor="#63BFFF" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="current" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#0095ff" stopOpacity={0} />
                  <stop offset="3%" stopColor="#0095ff" stopOpacity={0.1} />
                  <stop offset="97%" stopColor="#0095ff" stopOpacity={0.1} />
                  <stop offset="100%" stopColor="#0095ff" stopOpacity={0} />
                </linearGradient>
              </defs>

              <YAxis
                tick={{
                  fill: '#000',
                }}
                tickFormatter={this.asCurrency}
                tickLine={false}
                padding={{
                  left: 15,
                }}
                axisLine={false}
                mirror={mirrorYAxis}
              />

              <XAxis
                dataKey="timestamp"
                tickCount={data.length}
                ticks={data.map(x => x.timestamp)}
                tickLine={false}
                tick={<StatisticsTick unit={unit} fill="#000" />}
                interval={tickInterval}
                style={{
                  axis: {
                    stroke: '#ddd',
                  },
                }}
                padding={{
                  left: 15,
                }}
              />

              <CartesianGrid />

              {data.length > 0 && <StatisticsTooltip unit={unit} />}

              <Area
                dataKey="previousAmount"
                stroke="#63BFFF"
                strokeWidth={1}
                strokeDasharray="5, 3"
                isAnimationActive={false}
                fill="url(#previous)"
                dot={{
                  r: 4,
                  fillOpacity: 1,
                  fill: '#fff',
                  strokeWidth: 2,
                  strokeDasharray: '0',
                }}
                activeDot={{
                  r: 5,
                  stroke: '#fff',
                  strokeWidth: 2,
                }}
              />

              <Area
                dataKey="currentAmount"
                stroke="#0095ff"
                strokeWidth={1}
                isAnimationActive={false}
                fill="url(#current)"
                dot={{
                  r: 4,
                  fillOpacity: 1,
                  fill: '#fff',
                  strokeWidth: 2,
                }}
                activeDot={{
                  r: 5,
                  stroke: '#fff',
                  strokeWidth: 3,
                }}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    );
  }
}

export default injectIntl(StatisticsGraph);
