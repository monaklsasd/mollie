import React from 'react';
import { FormattedNumber } from 'react-intl';
import classNames from 'classnames';

import './styles.scss';

type Props = {
  current: number;
  previous: number;
  reversedColors?: boolean;
};

const getClass = (
  delta: Maybe<number>,
  reversedColors: Maybe<boolean>,
  className: string,
): string =>
  classNames([className], {
    'is-positive': delta && delta > 0,
    'is-negative': delta && delta < 0,
    'is-reversed': reversedColors,
  });

const getDelta = (a: number, b: number): Maybe<number> => {
  if (a === 0 || b === 0) {
    return undefined;
  }

  return (a - b) / b;
};

const renderDelta = (delta: Maybe<number>, reversedColors: Maybe<boolean>): React.ReactElement => {
  if (typeof delta === 'undefined') {
    return <span>--,--</span>;
  }

  return (
    <React.Fragment>
      {!!delta && (
        <span
          className={getClass(delta, reversedColors, 'c-statistics-difference-percentage--arrow')}>
          {delta < 0 && '▾'}
          {delta > 0 && '▴'}
        </span>
      )}
      <FormattedNumber value={Math.abs(delta)} format="percentage" />
    </React.Fragment>
  );
};

const StatisticsDifferencePercentage: React.FC<Props> = ({ current, previous, reversedColors }) => {
  const delta = getDelta(current, previous);

  return (
    <span className={getClass(delta, reversedColors, 'c-statistics-difference-percentage')}>
      {renderDelta(delta, reversedColors)}
    </span>
  );
};

export default StatisticsDifferencePercentage;
