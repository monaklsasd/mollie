import React, { Component } from 'react';
import { FormattedMessage } from 'react-intl';
import { sortBy } from 'lodash';
import moment from 'moment';

// Components
import StatisticsTotalsCard from 'components/Statistics/StatisticsTotalsCard';
import StatisticsMethodCard from 'components/Statistics/StatisticsMethodCard';

// Messages
import messages from 'messages';

//utils
import {
  intervalToMomentDuration,
  normalizeMomentDuration,
  IntervalType,
} from 'utils/parseMomentDuration';

// Types
import { DataType, EntityType } from 'containers/Statistics/types';

import './styles.scss';

const getShares = (totalAmount: number, methods: any): any[] => {
  const shares = Object.keys(methods).map(id => ({
    id,
    share: methods[id].payments.amount / totalAmount,
  }));

  return sortBy(shares, 'share').reverse();
};

const getComparedTo = (normalizedInterval: string, to?: string, from?: string): React.ReactNode => {
  if (!normalizedInterval) {
    return '-';
  }

  switch (normalizedInterval) {
    case 'days':
      return from && moment.unix(parseInt(from, 10)).format('D MMMM');
    case 'isoWeek':
      return (
        <FormattedMessage
          id="statistics-totals-compared-to-week"
          defaultMessage="week {weekNumber}"
          values={{ weekNumber: to && moment.unix(parseInt(to, 10)).format('W') }}
        />
      );
    case 'quarters':
    case 'month':
    case 'year':
    default:
      return <FormattedMessage id="statistics-totals-compared-to" defaultMessage="last year" />;
  }
};

type Props = {
  paymentMethods: {
    [key: string]: DataType & {
      supportsChargebacks: boolean;
      supportsRefunds: boolean;
    };
  };
  totals: DataType;
  previousData: EntityType;
  isLoading: boolean;
  isLoaded: boolean;
  interval: string;
};

class StatisticsTotals extends Component<Props> {
  render(): React.ReactElement {
    const { paymentMethods, totals, previousData, isLoading, isLoaded, interval } = this.props;
    const { totals: previousTotals, to, from } = previousData;
    const shares = getShares(totals.payments.amount, paymentMethods);

    const momentDuration = intervalToMomentDuration(interval as IntervalType);
    const normalizedInterval = normalizeMomentDuration(momentDuration);
    const comparedTo = getComparedTo(normalizedInterval, to, from);

    return (
      <div className="c-statistics-totals">
        <div className="c-statistics-totals__breakdown">
          <StatisticsTotalsCard
            heading={<FormattedMessage {...messages.revenue} />}
            amount={totals.payments.amount}
            previousAmount={previousTotals.payments.amount}
            transactions={totals.payments.count}
            previousTransactions={previousTotals.payments.count}
            comparedTo={comparedTo}
            isLoading={isLoading}
            isLoaded={isLoaded}
          />
          <StatisticsTotalsCard
            heading={<FormattedMessage {...messages.refunds} />}
            amount={totals.refunds.amount}
            previousAmount={previousTotals.refunds.amount}
            transactions={totals.refunds.count}
            previousTransactions={previousTotals.refunds.count}
            reversedColors
            comparedTo={comparedTo}
            isLoading={isLoading}
            isLoaded={isLoaded}
          />
          <StatisticsTotalsCard
            heading={<FormattedMessage {...messages.chargebacks} />}
            amount={totals.chargebacks.amount}
            previousAmount={previousTotals.chargebacks.amount}
            transactions={totals.chargebacks.count}
            previousTransactions={previousTotals.chargebacks.count}
            reversedColors
            comparedTo={comparedTo}
            isLoading={isLoading}
            isLoaded={isLoaded}
          />
        </div>
        <div className="c-statistics-totals__methods">
          {/*
           * Only show payment method totals if there is more than 1, otherwise it’s the same
           * as the totals above.
           */
          Object.keys(paymentMethods).length > 1 &&
            shares.map(({ share, id }) => (
              <StatisticsMethodCard key={id} id={id} share={share} {...paymentMethods[id]} />
            ))}
        </div>
      </div>
    );
  }
}

export default StatisticsTotals;
