import React from 'react';
import { FormattedNumber, injectIntl } from 'react-intl';
import { IntlShape } from 'react-intl';

import abbreviateLongNumbers from 'helpers/abbreviateLongNumbers';

import './styles.scss';

type Props = {
  current: number;
  previous: number;
  intl: IntlShape;
  isCurrency?: boolean;
};

const renderFormat = (
  delta: number,
  isCurrency: Maybe<boolean>,
  intl: IntlShape,
): React.ReactElement => {
  const { value, symbol } = abbreviateLongNumbers(Math.abs(delta), intl.locale);
  const formattedNumberProps: React.ComponentProps<typeof FormattedNumber> = isCurrency
    ? ({
        style: 'currency',
        currency: 'EUR',
        minimumFractionDigits: symbol ? 1 : 2,
      } as React.ComponentProps<typeof FormattedNumber>)
    : ({ minimumFractionDigits: symbol ? 1 : 0 } as React.ComponentProps<typeof FormattedNumber>);

  return (
    <span>
      <FormattedNumber value={Number(value)} {...formattedNumberProps} />
      {symbol}
    </span>
  );
};

const getDelta = (a: number, b: number): number => {
  if (a === 0 || b === 0) {
    return 0;
  }

  return a - b;
};

const renderDelta = (
  delta: number,
  isCurrency: Maybe<boolean>,
  intl: IntlShape,
): React.ReactElement | void => {
  if (delta === 0) {
    return;
  }

  return (
    <span>
      ({delta > 0 && <span>+ </span>}
      {delta < 0 && <span>- </span>}
      {renderFormat(delta, isCurrency, intl)})
    </span>
  );
};

const StatisticsDifferenceNumber: React.FC<Props> = ({ current, previous, isCurrency, intl }) => {
  const delta = getDelta(current, previous);

  return (
    <span className="c-statistics-difference-number">
      {renderFormat(previous, isCurrency, intl)} {renderDelta(delta, isCurrency, intl)}
    </span>
  );
};

StatisticsDifferenceNumber.defaultProps = {
  isCurrency: false,
};

export default injectIntl(StatisticsDifferenceNumber);
