import React from 'react';
import {
  injectIntl,
  FormattedMessage,
  FormattedNumber,
  FormattedDate,
  FormattedTime,
  defineMessages,
} from 'react-intl';
import { IntlShape } from 'react-intl';
import { debounce } from 'lodash';
import moment from 'moment';

// Containers
import * as constants from 'containers/Statistics/constants';

// Components
import IconPaymentMethods, { AcceptedMethods } from 'components/IconPaymentMethods';
import Spinner from 'components/UI/Spinner';
import StackedIcons from 'components/UI/StackedIcons';
import HelpTooltip from 'components/UI/HelpTooltip';
import Link from 'components/UI/Link';
import StatisticsListRow from 'components/Statistics/StatisticsListRow';

// Utils
import autobind from 'utils/autobind';
import getDocumentWidth from 'utils/getDocumentWidth';
import shallowEqual from 'utils/shallowEqual';
import isDateRange from 'utils/isDateRange';

// Icons
import { ReactComponent as IconCollapse } from 'assets/icons/collapse-all.svg';
import { ReactComponent as IconExpandAll } from 'assets/icons/expand-all.svg';

// Messages
import messages, { tables } from 'messages';

import './styles.scss';
import { IntlMessages } from 'types/intl';

const tooltipMessages: IntlMessages = defineMessages({
  revenueTooltipContent: {
    id: 'statistics-list-revenue-tooltip-explanation',
    defaultMessage:
      'Your revenue is the transaction total. It does not include refunds, chargebacks, or Mollie costs.',
  },
  revenueTooltipAriaLabel: {
    id: 'statistics-list-revenue-help-label',
    defaultMessage: 'How is revenue calculated?',
  },
});

const TRANSACTIONS = (
  <FormattedMessage id="statistics-list-label-transactions" defaultMessage="Transactions" />
);
const TRANSACTIONS_SHORT = (
  <abbr>
    <FormattedMessage id="statistics-list-label-transactions-short" defaultMessage="Trx" />
  </abbr>
);
const BREAKPOINT = 960;

type Props = {
  intl: IntlShape;
  location: {
    hash: string;
    query: {
      to?: string;
      from?: string;
    };
  };
  unit: Maybe<string>;
  statistics: {
    isLoading: boolean;
    data: {
      timeSeries: any[];
      totals: {
        chargebacks: {
          amount: number;
          count: number;
        };
        refunds: {
          amount: number;
          count: number;
        };
        payments: {
          amount: number;
          count: number;
        };
      };
    };
  };
};

type State = {
  openRows: any[];
  size: 'small' | 'large';
  now: number;
};

class StatisticsList extends React.Component<Props, State> {
  constructor(props) {
    super(props);

    this.state = {
      openRows: [],
      size: getDocumentWidth() < BREAKPOINT ? 'small' : 'large',
      now: Date.now() / 1000,
    };

    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    this.handleResize = debounce(this.handleResize.bind(this), 200);

    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    this.getRow = this.getRow.bind(this);
    autobind(this);
  }

  componentDidMount(): void {
    window.addEventListener('resize', this.handleResize);
  }

  componentWillReceiveProps(nextProps): void {
    if (!shallowEqual(nextProps, this.props)) {
      this.setState({
        openRows: [],
        now: Date.now() / 1000,
      });
    }
  }

  componentWillUnmount(): void {
    window.removeEventListener('resize', this.handleResize);
  }

  isInThePast = ({ timestamp }): boolean => {
    return timestamp <= this.state.now;
  };

  getHeadings(): React.ReactElement[] {
    const { intl, statistics } = this.props;
    const openRows = this.state.openRows;
    const timeSeries = statistics.data.timeSeries;
    const allRowsAreOpen = openRows.length === timeSeries.length;

    return [
      <FormattedMessage {...tables.date} />,
      <span>
        <FormattedMessage {...messages.revenue} />
        <HelpTooltip
          content={intl.formatMessage(tooltipMessages.revenueTooltipContent)}
          ariaLabel={intl.formatMessage(tooltipMessages.revenueTooltipAriaLabel)}
          className="c-statistics-list__help"
        />
      </span>,
      <span>{this.state.size === 'small' ? TRANSACTIONS_SHORT : TRANSACTIONS}</span>,
      <FormattedMessage {...messages.refunds} />,
      <span>{this.state.size === 'small' ? TRANSACTIONS_SHORT : TRANSACTIONS}</span>,
      <FormattedMessage {...messages.chargebacks} />,
      <span>{this.state.size === 'small' ? TRANSACTIONS_SHORT : TRANSACTIONS}</span>,
      <Link
        linkStyle="blue"
        className="c-statistics-list__button"
        onClick={allRowsAreOpen ? this.handleCloseAll : this.handleOpenAll}>
        {// Would rather do this in one go but the icons won’t update when
        // using a ternary, so using two expressions instead
        allRowsAreOpen && (
          <span>
            <IconCollapse id="contract" />
            <FormattedMessage
              id="statistics-list-collapse-all-label"
              defaultMessage="Collapse all"
            />
          </span>
        )}
        {!allRowsAreOpen && (
          <span>
            <IconExpandAll id="expand" />
            <FormattedMessage id="statistics-list-expand-all-label" defaultMessage="Expand all" />
          </span>
        )}
      </Link>,
    ];
  }

  getDate(data): React.ReactElement {
    const { location, unit } = this.props;
    const value = new Date(data.timestamp * 1000);

    switch (unit) {
      case constants.INTERVAL_HOUR:
        if (isDateRange(location.query.from, location.query.to)) {
          return (
            <FormattedTime
              value={value}
              weekday="short"
              day="numeric"
              month="long"
              hour="numeric"
              minute="numeric"
              hour12={false}
            />
          );
        }

        return <FormattedTime value={value} hour="numeric" minute="numeric" hour12={false} />;

      case constants.INTERVAL_DAY:
        return (
          <FormattedDate value={value} weekday="short" day="numeric" month="short" year="numeric" />
        );

      case constants.INTERVAL_WEEK:
        return (
          <FormattedMessage
            defaultMessage="Week {weekNumber}"
            id="statistics-label-week"
            values={{
              weekNumber: moment(value).format('W'),
            }}
          />
        );

      case constants.INTERVAL_MONTH:
        return <FormattedDate value={value} month="long" year="numeric" />;

      default:
        return <FormattedDate value={value} format="normal" />;
    }
  }

  getRow(item): React.ReactElement[] {
    const { totals, paymentMethods, timestamp } = item;
    const isOpen = this.state.openRows.includes(timestamp);
    const paymentMethodIds = Object.keys(paymentMethods);

    // Add sum row, which is always visible
    const rows = [
      <StatisticsListRow
        onClick={(): void => {
          if (isOpen) {
            this.handleClose(timestamp);
            return;
          }

          this.handleOpen(timestamp);
        }}
        key="main"
        isHighlighted={isOpen}
        isLastChild={isOpen && !paymentMethodIds.length}
        values={[
          this.getDate(item),
          <FormattedNumber value={totals.payments.amount} format="EUR" />,
          <FormattedNumber value={totals.payments.count} />,
          <FormattedNumber value={totals.refunds.amount} format="EUR" />,
          <FormattedNumber value={totals.refunds.count} />,
          <FormattedNumber value={totals.chargebacks.amount} format="EUR" />,
          <FormattedNumber value={totals.chargebacks.count} />,
          // Stacked icons expects objects with id and amount, so we need to
          // do a bit of transforming to get there.
          <StackedIcons
            methods={
              paymentMethodIds.map(id => ({
                id,
                amount: {
                  value: paymentMethods[id].payments.amount,
                },
              })) as any
            }
            align="right"
            showTooltip={paymentMethodIds.length > 1}
          />,
        ]}
      />,
    ];

    // Only add payment method rows when table is open
    if (isOpen) {
      Object.keys(item.paymentMethods).forEach((id, index, arr) => {
        rows.push(
          <StatisticsListRow
            isSubRow
            isLastChild={index + 1 === arr.length}
            key={id}
            values={[
              null,
              <FormattedNumber value={paymentMethods[id].payments.amount} format="EUR" />,
              <FormattedNumber value={paymentMethods[id].payments.count} />,
              <FormattedNumber value={paymentMethods[id].refunds.amount} format="EUR" />,
              <FormattedNumber value={paymentMethods[id].refunds.count} />,
              <FormattedNumber value={paymentMethods[id].chargebacks.amount} format="EUR" />,
              <FormattedNumber value={paymentMethods[id].chargebacks.count} />,
              <IconPaymentMethods method={id as AcceptedMethods} width={30} height={30} />,
            ]}
          />,
        );
      });
    }

    return rows;
  }

  handleResize(): void {
    if (getDocumentWidth() < BREAKPOINT && this.state.size !== 'small') {
      this.setState({
        size: 'small',
      });
      return;
    }

    if (getDocumentWidth() >= BREAKPOINT && this.state.size !== 'large') {
      this.setState({
        size: 'large',
      });
    }
  }

  handleOpen(id): void {
    this.setState({
      openRows: this.state.openRows.concat(id),
    });
  }

  handleClose(id): void {
    this.setState({
      openRows: this.state.openRows.filter(x => x !== id),
    });
  }

  handleOpenAll(): void {
    this.setState({
      openRows: this.props.statistics.data.timeSeries.map(x => x.timestamp),
    });
  }

  handleCloseAll(): void {
    this.setState({
      openRows: [],
    });
  }

  render(): React.ReactElement {
    const statistics = this.props.statistics;

    return (
      <div className="c-statistics-list">
        {statistics.isLoading && <Spinner delay={800} />}
        <StatisticsListRow values={this.getHeadings()} isHeading />
        {statistics.data.timeSeries.filter(this.isInThePast).map(this.getRow)}
      </div>
    );
  }
}

export default injectIntl(StatisticsList);
