import React from 'react';

import { FormattedMessage, FormattedNumber } from 'react-intl';

import NumberDifference from 'components/Statistics/StatisticsDifferenceNumber';
import PercentageDifference from 'components/Statistics/StatisticsDifferencePercentage';
import StatisticsCard from 'components/Statistics/StatisticsCard';

import messages from 'messages';

import './styles.scss';

type Props = {
  heading: React.ReactNode;
  comparedTo: any;
  amount: number;
  previousAmount: number;
  transactions: number;
  previousTransactions: number;
  reversedColors?: boolean;
  isLoading: boolean;
  isLoaded: boolean;
};

const StatisticsTotalsCard: React.FC<Props> = ({
  heading,
  amount,
  previousAmount,
  transactions,
  previousTransactions,
  reversedColors,
  comparedTo,
  isLoading,
  isLoaded,
}) => (
  <StatisticsCard
    className="c-statistics-totals-card"
    heading={heading}
    headingAddOn={<FormattedMessage {...messages.transactions} />}
    isLoading={isLoading && !isLoaded}>
    <div className="c-statistics-totals-card__body">
      <div className="c-statistics-totals-card__row">
        <span className="c-statistics-totals-card__amount">
          <FormattedNumber value={amount} format="EUR" />
        </span>
        <span className="c-statistics-totals-card__transactions">
          <FormattedNumber value={transactions} />
        </span>
      </div>
      <div className="c-statistics-totals-card__compared-text">
        <FormattedMessage
          id="statistics-totals-card-compared-to"
          defaultMessage="Compared to {comparedTo}"
          values={{ comparedTo }}
        />
      </div>

      <div className="c-statistics-totals-card__row">
        <div className="c-statistics-totals-card__amount-difference">
          <PercentageDifference
            reversedColors={reversedColors}
            current={amount}
            previous={previousAmount}
          />
          <NumberDifference current={amount} previous={previousAmount} isCurrency />
        </div>
        <div className="c-statistics-totals-card__transaction-difference">
          <PercentageDifference
            reversedColors={reversedColors}
            current={transactions}
            previous={previousTransactions}
          />
          <NumberDifference current={transactions} previous={previousTransactions} />
        </div>
      </div>
    </div>
  </StatisticsCard>
);

export default StatisticsTotalsCard;
