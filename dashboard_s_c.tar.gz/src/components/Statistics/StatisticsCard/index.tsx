import React from 'react';
import classNames from 'classnames';

import Spinner from 'components/UI/Spinner';

import './styles.scss';

type Props = {
  className?: string;
  heading: React.ReactNode;
  headingAddOn?: React.ReactNode;
  children: React.ReactNode;
  isLoading?: boolean;
};

const StatisticsCard: React.FC<Props> = ({
  className,
  heading,
  headingAddOn,
  isLoading,
  children,
}: Props) => (
  <article className={classNames('c-statistics-card', className)}>
    <header>
      <h3>{heading}</h3>
      {headingAddOn && (
        <span className="c-statistics-card__transactions-heading">{headingAddOn}</span>
      )}
    </header>
    <div className="c-statistics-card__body">
      {!isLoading && children}
      {isLoading && <Spinner />}
    </div>
  </article>
);

export default StatisticsCard;
