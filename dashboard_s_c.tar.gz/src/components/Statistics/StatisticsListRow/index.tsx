import React from 'react';
import { FormattedMessage } from 'react-intl';
import classNames from 'classnames';

import Link from 'components/UI/Link';

import './styles.scss';
import { ClassnamesFunction } from 'types/helpers';

type Props = {
  values: any[];
  onClick?: React.MouseEventHandler;
  isSummary?: boolean;
  isHighlighted?: boolean;
  isLastChild?: boolean;
  isSubRow?: boolean;
  isHeading?: boolean;
};

const getClass: ClassnamesFunction<Props> = ({
  isHeading,
  isSubRow,
  isLastChild,
  isHighlighted,
  isSummary,
}) =>
  classNames('c-statistics-list-row', {
    'c-statistics-list-row--heading': isHeading,
    'c-statistics-list-row--summary': isSummary,
    'c-statistics-list-row--sub': isSubRow,
    'c-statistics-list-row--last': isLastChild,
    'is-highlighted': isHighlighted,
  });

const StatisticsListRow: React.FC<Props> = ({ values, onClick, ...rest }) => (
  <div className={getClass({ ...rest })}>
    <ul>
      {values.map((value, index) => (
        <li className="c-statistics-list-row__item" key={`statistics-list-row-${index}`}>
          {value}
        </li>
      ))}
    </ul>
    {onClick && (
      <Link className="c-statistics-list-row__button" onClick={onClick} fullWidth>
        <FormattedMessage
          id="statistics-list-expand-row-button-label"
          defaultMessage="Show details per payment method"
        />
      </Link>
    )}
  </div>
);
export default StatisticsListRow;
