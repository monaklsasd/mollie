import React from 'react';
import moment from 'moment';
import classNames from 'classnames';
import { FormattedMessage, FormattedDate, FormattedNumber } from 'react-intl';

import * as constants from 'containers/Statistics/constants';
import getLocalizedMethodName from 'utils/getLocalizedMethodName';

import './styles.scss';

const renderDate = (unit: string, value: number): React.ReactElement => {
  switch (unit) {
    case constants.INTERVAL_HOUR:
      return (
        <FormattedDate
          value={value}
          weekday="short"
          day="numeric"
          month="long"
          year="numeric"
          hour="numeric"
          minute="numeric"
          hour12={false}
        />
      );

    case constants.INTERVAL_DAY:
    case constants.INTERVAL_WEEK:
      return (
        <FormattedDate value={value} weekday="long" day="numeric" month="long" year="numeric" />
      );

    case constants.INTERVAL_MONTH:
      return <FormattedDate value={value} month="long" year="numeric" />;

    default:
      return <FormattedDate value={value} format="normal" />;
  }
};

const renderDeltaPercentage = (prev, current): React.ReactElement => {
  if (prev === 0 || current === 0) {
    return <span>–</span>;
  }

  const delta = (current - prev) / prev;
  const isDeltaPositive = delta > 0;

  return (
    <span
      className={classNames({
        'u-color-negative': !isDeltaPositive,
        'u-color-positive': isDeltaPositive,
      })}>
      {isDeltaPositive && <span>+</span>}
      <FormattedNumber format="percentage" minimumFractionDigits={2} value={delta} />
    </span>
  );
};

const getComponentProps = (props: Props): Partial<Props> => {
  let translateX = (props?.coordinate?.x || 0) + 35;
  let flipped = false;

  if ((props?.coordinate?.x || 0) + 290 > (props?.viewBox?.width || 0)) {
    translateX = (props?.coordinate?.x || 0) - 285;
    flipped = true;
  }

  return {
    className: classNames('c-statistics-tooltip', {
      'is-flipped': flipped,
    }),
    style: {
      transform: `translate(${translateX}px, -50%)`,
    },
  };
};

const renderBarDate = (unit: string, value: number): React.ReactElement => {
  const date = moment.unix(value);

  switch (unit) {
    case constants.INTERVAL_HOUR:
      return <span>{date.format('HH:mm')}</span>;

    case constants.INTERVAL_DAY:
    default:
      return (
        <span>
          {date.format('ddd')}
          <br />
          {date.format('DD MMM')}
        </span>
      );

    case constants.INTERVAL_WEEK:
      return (
        <span>
          <FormattedMessage defaultMessage="Week" id="statistics-graph-label-week" />
          <br />
          {date.format('W')}
        </span>
      );

    case constants.INTERVAL_MONTH:
      return (
        <span>
          {date.format('MMM')}
          <br />’{date.format('YY')}
        </span>
      );
  }
};

type Props = {
  viewBox?: {
    width: number;
    height: number;
  };
  style?: React.CSSProperties;
  className?: string;
  coordinate?: {
    x: number;
    y: number;
  };
  type?: string;
  payload?: any[];
  label?: number;
  unit: string;
  active?: boolean;
};

const StatisticsTooltip: React.FC<Props> = props => {
  const { active, coordinate, payload = [], unit } = props;

  if (!active) {
    return null;
  }

  const data = payload[0];
  const methods = data.payload.paymentMethods;
  const now = Date.now();

  const rows = Object.keys(methods).map(id => ({
    id,
    ...methods[id],
    label: getLocalizedMethodName(id),
  }));

  return (
    <div>
      <div {...getComponentProps(props)}>
        <p className="c-statistics-tooltip__date">
          {data.payload.timestamp * 1000 <= now && (
            <span>
              {renderDate(unit, data.payload.timestamp * 1000)}
              <br />
            </span>
          )}
          <b>{renderDate(unit, data.payload.previousTimestamp * 1000)}</b>
        </p>
        <ul>
          {rows.map(row => (
            <li className="c-statistics-tooltip__row" key={row.id}>
              {// Current or past date
              row.amount && [
                <p key="label">
                  <span>{row.label}: </span>
                  <FormattedNumber value={row.amount} format="EUR" />
                </p>,
                <p key="total">
                  <span className="u-screenreader-only">
                    <FormattedMessage
                      id="statistics-tooltip-previous-total"
                      defaultMessage="Total for previous period"
                    />
                    :{' '}
                  </span>
                  <FormattedNumber value={row.previousAmount} format="EUR" />
                </p>,
                <p key="difference">
                  <span className="u-screenreader-only">
                    <FormattedMessage
                      id="statistics-tooltip-difference"
                      defaultMessage="Difference"
                    />
                    :{' '}
                  </span>
                  {renderDeltaPercentage(row.previousAmount, row.amount)}
                </p>,
              ]}
              {// Future date
              !row.amount && (
                <p>
                  <span>{row.label}: </span>
                  <FormattedNumber value={row.previousAmount} format="EUR" />
                </p>
              )}
            </li>
          ))}
        </ul>
        <div className="c-statistics-tooltip__row">
          {// Current or past date
          data.payload.timestamp * 1000 <= now && [
            <p key="label">
              <strong>
                <FormattedMessage id="statistics-tooltip-total" defaultMessage="Total" />:{' '}
              </strong>
              <FormattedNumber value={data.payload.currentAmount} format="EUR" />
            </p>,
            <p key="total">
              <span className="u-screenreader-only">
                <FormattedMessage
                  id="statistics-tooltip-previous-total"
                  defaultMessage="Total for previous period"
                />
                :{' '}
              </span>
              <FormattedNumber value={data.payload.previousAmount} format="EUR" />
            </p>,
            <p key="difference">
              <span className="u-screenreader-only">
                <FormattedMessage id="statistics-tooltip-difference" defaultMessage="Difference" />:{' '}
              </span>
              {renderDeltaPercentage(data.payload.previousAmount, data.payload.currentAmount)}
            </p>,
          ]}
          {// Future date
          data.payload.timestamp * 1000 > now && (
            <p>
              <strong>
                <FormattedMessage id="statistics-tooltip-total" defaultMessage="Total" />:{' '}
              </strong>
              <FormattedNumber value={data.payload.previousAmount} format="EUR" />
            </p>
          )}
        </div>
      </div>
      <div
        className="c-statistics-tooltip__bar"
        style={{ transform: `translateX(${coordinate?.x || 0}px)` }}
      />
      <div
        aria-hidden
        className="c-statistics-tooltip__bar-date"
        style={{ transform: `translateX(${coordinate?.x || 0}px)` }}>
        {renderBarDate(unit, data.payload.timestamp)}
      </div>
    </div>
  );
};

StatisticsTooltip.displayName = 'Tooltip';

export default StatisticsTooltip;
