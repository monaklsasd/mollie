import { Moment, unitOfTime } from 'moment';
import { DateRangeType } from 'containers/Administration/Reports/types';

export type PeriodType = {
  isActivePeriod?: boolean;
  isLast?: boolean;
  isFirst?: boolean;
  isDisabled?: boolean;
  startDate: Moment;
  endDate: Moment;
};

export type ActivePeriodsType = {
  periods: PeriodType[];
  normalizedInterval: unitOfTime.StartOf;
  activeDateRange: DateRangeType;
};

export type VirtualizedCellProps = {
  columnStartIndex: number;
  columnStopIndex: number;
};
