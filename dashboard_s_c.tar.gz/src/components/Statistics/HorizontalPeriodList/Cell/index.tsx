import * as React from 'react';
import classNames from 'classnames';
import { FormattedMessage } from 'react-intl';
import { Moment } from 'moment';

import { PeriodType } from '../types';

import './styles.scss';
import { ClassnamesFunction } from 'types/helpers';

const getClass: ClassnamesFunction<Props['period']> = ({ isActivePeriod, isDisabled }) =>
  classNames('c-horizontal-period-list__item c-statistics-period', {
    'is-active': isActivePeriod,
    'is-disabled': isDisabled,
  });

export type Props = {
  period: PeriodType;
  onClick: (payload: { startDate: Moment; endDate: Moment }) => void;
  style: Record<string, any>;
  normalizedInterval: string;
};

class Cell extends React.Component<Props> {
  getLabel(): React.ReactElement | React.ReactElement[] {
    const {
      period: { startDate, endDate },
      normalizedInterval,
    } = this.props;

    switch (normalizedInterval) {
      case 'days':
        return [
          <span key="top" className="c-statistics-period__title">
            {startDate.format('D MMM')}
          </span>,
          <span key="bottom" className="c-statistics-period__year">
            {startDate && startDate.format('YYYY')}
          </span>,
        ];

      case 'isoWeek':
        return [
          <span key="top" className="c-statistics-period__title">
            <FormattedMessage
              defaultMessage="Week {weekNumber}"
              id="statistics-label-week"
              values={{
                weekNumber: endDate.format('W'),
              }}
            />
          </span>,
          <span key="bottom" className="c-statistics-period__year">
            {startDate && startDate.format('YYYY')}
          </span>,
        ];

      case 'quarters':
        return [
          <span key="top" className="c-statistics-period__title">
            <FormattedMessage
              defaultMessage="Q{quarterNumber}"
              id="statistics-label-quarter"
              values={{
                quarterNumber: startDate.format('Q'),
              }}
            />
          </span>,
          <span key="bottom" className="c-statistics-period__year">
            {startDate && startDate.format('YYYY')}
          </span>,
        ];

      case 'year':
        return (
          <span key="top" className="c-statistics-period__title">
            {startDate.format('YYYY')}
          </span>
        );

      case 'month':
      default:
        return [
          <span key="top" className="c-statistics-period__title">
            {startDate.format('MMMM')}
          </span>,
          <span key="bottom" className="c-statistics-period__year">
            {startDate.format('YYYY')}
          </span>,
        ];
    }
  }

  selectPeriod = (): void => {
    const {
      onClick,
      period: { startDate, endDate },
    } = this.props;

    onClick({
      startDate,
      endDate,
    });
  };

  wrapInLink(children: React.ReactNode): React.ReactElement {
    const { period, style } = this.props;

    if (period.isDisabled) {
      return (
        <div className={getClass(period)} style={style}>
          {children}
        </div>
      );
    }

    return (
      <button onClick={this.selectPeriod} type="button" className={getClass(period)} style={style}>
        {children}
      </button>
    );
  }

  render(): React.ReactElement {
    const {
      period: { startDate },
    } = this.props;

    return this.wrapInLink(
      <span className="c-statistics-period__wrapper">{startDate && this.getLabel()}</span>,
    );
  }
}

export default Cell;
