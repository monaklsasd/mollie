import moment from 'moment';

import { ActivePeriodsType, PeriodType } from './types';

/**
 * In order to determine which cells should be highlighted (when the user is viewing statistics for this
 * perticular period), we need to check which periods are overlapping (and find the first + last overlapping period).
 */
export const findOverlappingPeriods = ({
  periods,
  normalizedInterval,
  activeDateRange,
}: ActivePeriodsType): PeriodType[] =>
  periods.map(({ startDate, endDate, isDisabled }) => {
    const inclusitivity = '[]'; // Both included
    const isActivePeriod = moment(startDate).isBetween(
      activeDateRange.startDate || undefined,
      activeDateRange.endDate || undefined,
      normalizedInterval,
      inclusitivity,
    );
    const isFirst = moment(activeDateRange.startDate || undefined).isBetween(
      startDate,
      endDate,
      normalizedInterval,
      inclusitivity,
    );
    const isLast = moment(activeDateRange.endDate || undefined).isBetween(
      startDate,
      endDate,
      normalizedInterval,
      inclusitivity,
    );

    return {
      isActivePeriod,
      isFirst,
      isLast,
      startDate,
      endDate,
      isDisabled,
    };
  });
