import React from 'react';
import classNames from 'classnames';
import { ClassnamesFunction } from 'types/helpers';

const getClass: ClassnamesFunction<Props> = ({ highlighted }) =>
  classNames('c-horizontal-period-list__button', {
    'is-highlighted': highlighted,
  });

type Props = {
  onClick: React.MouseEventHandler;
  disabled: boolean;
  highlighted: boolean;
};

const Button: React.FC<Props> = ({ onClick, disabled, highlighted }) => (
  <button className={getClass({ highlighted })} onClick={onClick} disabled={disabled}>
    <div className="caret" />
  </button>
);

export default Button;
