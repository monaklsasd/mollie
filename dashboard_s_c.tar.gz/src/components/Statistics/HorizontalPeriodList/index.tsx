import React from 'react';
import { Grid, AutoSizer } from 'react-virtualized';
import classNames from 'classnames';
import moment, { Moment } from 'moment';

import autobind from 'utils/autobind';
import animateValue from 'utils/animateValue';
import shallowEqual from 'utils/shallowEqual';

import Button from './Button';
import Cell from './Cell';
import { findOverlappingPeriods } from './utils';

import { PeriodType, VirtualizedCellProps } from './types';
import { DateRangeType } from 'containers/Administration/Reports/types';

import './styles.scss';

export const COLUMN_WIDTH = 85;
export const COLUMN_WIDTH_LARGE = 110;

const getBoundPosition = ({ columnStartIndex, columnStopIndex, index }): string => {
  if (index < columnStartIndex) {
    return 'offscreenLeft';
  }

  if (index > columnStopIndex) {
    return 'offscreenRight';
  }

  return 'inbounds';
};

const fitsOnScreen = ({
  firstActivePeriodIndex,
  lastActivePeriodIndex,
  firstVisibleColumnIndex,
  lastVisibleColumnIndex,
}): boolean => {
  const visibleColumns = lastVisibleColumnIndex - firstVisibleColumnIndex - 1;
  return lastActivePeriodIndex - firstActivePeriodIndex < visibleColumns;
};

interface Props {
  periods: PeriodType[];
  interval: string;
  onChange: (payload: { startDate: Moment; endDate: Moment }) => void;
  activeDateRange: DateRangeType;
  normalizedInterval: moment.unitOfTime.StartOf;
  className?: string;
  compact?: boolean;
}

type State = {
  firstVisibleColumnIndex: number;
  firstActivePeriodIndex: number;
  firstActivePeriodPosition: string;
  lastActivePeriodIndex: number;
  lastActivePeriodPosition: string;
  lastVisibleColumnIndex: number;
  periods: PeriodType[];
};

type ReactVirtualizedElement = HTMLElement & {
  getOffsetForCell: Function;
  scrollToPosition: Function;
  scrollToCell: Function;
};

class HorizontalPeriodList extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);

    this.state = {
      firstActivePeriodIndex: 0,
      firstActivePeriodPosition: 'inbounds',
      lastActivePeriodIndex: 0,
      lastActivePeriodPosition: 'inbounds',
      firstVisibleColumnIndex: 0,
      lastVisibleColumnIndex: 0,
      periods: [],
    };

    autobind(this);
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    this.renderCell = this.renderCell.bind(this);
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    this.cellDidMount = this.cellDidMount.bind(this);
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    this.scrollToLastActivePeriod = this.scrollToLastActivePeriod.bind(this);
  }

  componentDidMount(): void {
    this.updatePeriods(this.props);
    this.scrollToLastActivePeriod();
  }

  componentWillReceiveProps(nextProps: Props): void {
    this.updatePeriods(nextProps);
  }

  componentDidUpdate(prevProps: Props): void {
    if (!shallowEqual(prevProps.periods, this.props.periods)) {
      this.scrollToLastActivePeriod();
    }
  }

  onMoveLeft(): void {
    const {
      firstActivePeriodIndex,
      lastActivePeriodIndex,
      lastVisibleColumnIndex,
      firstVisibleColumnIndex,
    } = this.state;

    const visibleColumns = lastVisibleColumnIndex - firstVisibleColumnIndex - 1;
    const cellIndex = firstVisibleColumnIndex - visibleColumns;

    // If we can fit the entire selection on the screen, do so and center it.
    if (lastActivePeriodIndex < firstVisibleColumnIndex && fitsOnScreen(this.state)) {
      // Calculate how many cells we need to offset from the firstActivePeriodIndex
      const offset = Math.floor(
        (visibleColumns - (lastActivePeriodIndex - firstActivePeriodIndex)) / 2,
      );

      this.scrollToCell(firstVisibleColumnIndex + 1, Math.max(firstActivePeriodIndex - offset, 0));
      return;
    }

    // If the last selected cell is offscreen to the left side, scroll till
    // it is the last cell.
    if (lastActivePeriodIndex < firstVisibleColumnIndex) {
      this.scrollToCell(
        firstVisibleColumnIndex + 1,
        Math.max(lastActivePeriodIndex - visibleColumns, 0),
      );
      return;
    }

    // If the first selected cell is offscreen to the left side, scroll till
    // it is the first cell.
    if (firstActivePeriodIndex < firstVisibleColumnIndex) {
      this.scrollToCell(firstVisibleColumnIndex + 1, Math.max(firstActivePeriodIndex, 0));
      return;
    }

    // If there are not enough cells left to fill the row, go to the first cell
    if (cellIndex < 0) {
      this.scrollToCell(firstVisibleColumnIndex - cellIndex, 0);
      return;
    }

    this.scrollToCell(firstVisibleColumnIndex + 1, cellIndex);
  }

  onMoveRight(): void {
    const {
      firstActivePeriodIndex,
      lastActivePeriodIndex,
      lastVisibleColumnIndex,
      firstVisibleColumnIndex,
      periods,
    } = this.state;

    const visibleColumns = lastVisibleColumnIndex - firstVisibleColumnIndex - 1;
    const cellIndex = lastVisibleColumnIndex + visibleColumns;

    // If we can fit the entire selection on the screen, do so and center it.
    if (firstActivePeriodIndex > lastVisibleColumnIndex && fitsOnScreen(this.state)) {
      // Calculate how many cells we need to offset from the firstActivePeriodIndex
      const offset = Math.floor(
        (visibleColumns - (lastActivePeriodIndex - firstActivePeriodIndex)) / 2,
      );

      this.scrollToCell(
        lastVisibleColumnIndex - 1,
        Math.min(lastActivePeriodIndex + offset, periods.length - 1),
      );
      return;
    }

    /*
     * If the first selected cell is offscreen to the right side, scroll till
     * it is the first visible cell. React Virtualized will only scroll till it
     * is visible, so we need to add visibleColumns to scroll till it is
     * actually the first cell.
     */
    if (firstActivePeriodIndex > lastVisibleColumnIndex) {
      this.scrollToCell(
        firstVisibleColumnIndex,
        Math.min(firstActivePeriodIndex + visibleColumns, periods.length - 1),
      );
      return;
    }

    // If the last selected cell is offscreen to the right side, scroll till
    // it is the last cell.
    if (lastActivePeriodIndex > lastVisibleColumnIndex) {
      this.scrollToCell(firstVisibleColumnIndex + 1, lastActivePeriodIndex);
      return;
    }

    this.scrollToCell(firstVisibleColumnIndex + 1, cellIndex);
  }

  scrollToCell(startColumnIndex: number, endColumnIndex: number): void {
    if (!this.grid) {
      return;
    }

    const start = this.grid.getOffsetForCell({
      columnIndex: startColumnIndex,
    });

    if (!this.grid) {
      return;
    }

    const end = this.grid.getOffsetForCell({
      columnIndex: endColumnIndex,
    });

    animateValue({
      start: start.scrollLeft,
      end: end.scrollLeft,
      duration: 500,
      onUpdate: position => {
        if (!this.grid) {
          return;
        }

        this.grid.scrollToPosition({
          scrollLeft: position,
        });
      },
    });
  }

  cellDidMount({ columnStartIndex, columnStopIndex }: VirtualizedCellProps): void {
    this.setState({
      firstActivePeriodPosition: getBoundPosition({
        columnStartIndex,
        columnStopIndex,
        index: this.state.firstActivePeriodIndex,
      }),
      lastActivePeriodPosition: getBoundPosition({
        columnStartIndex,
        columnStopIndex,
        index: this.state.lastActivePeriodIndex,
      }),
      firstVisibleColumnIndex: columnStartIndex,
      lastVisibleColumnIndex: columnStopIndex,
    });
  }

  grid: Maybe<ReactVirtualizedElement>;

  scrollToLastActivePeriod(): void {
    if (!this.grid) {
      return;
    }

    // Scroll to the last active cell by passing the index for the last active period.
    this.grid.scrollToCell({
      columnIndex: this.state.lastActivePeriodIndex,
    });
  }

  updatePeriods(props: Props): void {
    const parsedPeriods = findOverlappingPeriods({
      periods: props.periods,
      activeDateRange: props.activeDateRange,
      normalizedInterval: props.normalizedInterval,
    });

    const firstActivePeriodIndex = parsedPeriods.findIndex(p => p.isFirst);
    const lastActivePeriodIndex = parsedPeriods.findIndex(p => p.isLast);

    const { firstVisibleColumnIndex, lastVisibleColumnIndex } = this.state;

    this.setState({
      firstActivePeriodIndex,
      firstActivePeriodPosition: getBoundPosition({
        columnStartIndex: firstVisibleColumnIndex,
        columnStopIndex: lastVisibleColumnIndex,
        index: firstActivePeriodIndex,
      }),
      lastActivePeriodIndex,
      lastActivePeriodPosition: getBoundPosition({
        columnStartIndex: firstVisibleColumnIndex,
        columnStopIndex: lastVisibleColumnIndex,
        index: lastActivePeriodIndex,
      }),
      periods: parsedPeriods,
    });
  }

  renderCell(args: any): React.ReactElement {
    const { activeDateRange, normalizedInterval, onChange } = this.props;

    const { periods } = this.state;

    return (
      <Cell
        onClick={onChange}
        activeDateRange={activeDateRange}
        period={periods[args.columnIndex]}
        normalizedInterval={normalizedInterval}
        {...args}
      />
    );
  }

  render(): React.ReactElement {
    const {
      firstActivePeriodPosition,
      lastActivePeriodPosition,
      firstVisibleColumnIndex,
      lastVisibleColumnIndex,
      periods,
    } = this.state;
    const { compact } = this.props;

    return (
      <div className={classNames('c-horizontal-period-list', this.props.className)}>
        <Button
          onClick={this.onMoveLeft}
          highlighted={
            firstActivePeriodPosition === 'offscreenLeft' ||
            lastActivePeriodPosition === 'offscreenLeft'
          }
          disabled={firstVisibleColumnIndex === 0}
        />
        <div className="c-horizontal-period-list__inner">
          <AutoSizer onResize={this.scrollToLastActivePeriod}>
            {({ height, width }): React.ReactElement => (
              <Grid
                columnWidth={compact ? COLUMN_WIDTH : COLUMN_WIDTH_LARGE}
                rowHeight={height}
                columnCount={this.state.periods.length}
                rowCount={1}
                height={height}
                width={width}
                // Arrow function is needed here to force re-render when activeDateRange changes
                onSectionRendered={(args): void => this.cellDidMount(args)}
                cellRenderer={this.renderCell}
                ref={(grid): void => {
                  this.grid = grid;
                }}
              />
            )}
          </AutoSizer>
        </div>
        <Button
          onClick={this.onMoveRight}
          highlighted={
            firstActivePeriodPosition === 'offscreenRight' ||
            lastActivePeriodPosition === 'offscreenRight'
          }
          disabled={lastVisibleColumnIndex === periods.length - 1}
        />
      </div>
    );
  }
}

export default HorizontalPeriodList;
