import React from 'react';
import renderer from 'react-test-renderer';
import moment from 'moment';

import { INTERVAL_DAY } from 'containers/Statistics/constants';
import { intervalToMomentDuration, normalizeMomentDuration } from 'utils/parseMomentDuration';

import Cell from './../Cell';

/**
 * Unfortunately, testing the whole <HorizontalPeriodList> component using
 * snapshots is hard due to the AutoSizer HOC.
 *
 * @see: https://github.com/bvaughn/react-virtualized/issues/493
 */
describe('<Cell>', () => {
  let props;

  beforeEach(() => {
    const momentDuration = intervalToMomentDuration(INTERVAL_DAY);

    props = {
      period: {
        startDate: moment('01-01-2013', 'DD-MM-YYYY'),
        endDate: moment('31-01-2013', 'DD-MM-YYYY'),
      },
      style: {},
      normalizedInterval: normalizeMomentDuration(momentDuration),
    };
  });

  it('should render a cell which is active', () => {
    // Cell which is not highlighted.
    const defaultTree = renderer.create(<Cell {...props} />).toJSON();
    expect(defaultTree).toMatchSnapshot();

    // Highlighted cell
    props = {
      ...props,
      period: {
        isFirst: true,
        isLast: true,
        isActivePeriod: true,
        ...props.period,
      },
    };

    const highlightedTree = renderer.create(<Cell {...props} />).toJSON();
    expect(highlightedTree).toMatchSnapshot();
  });
});
