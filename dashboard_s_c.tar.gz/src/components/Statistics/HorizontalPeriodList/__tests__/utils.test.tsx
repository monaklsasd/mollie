import moment from 'moment';

import { findOverlappingPeriods } from './../utils';

// Mock Date.now() function so it always returns 01-01-2017 00:00:00
Date.now = jest.fn().mockReturnValue(1483228800000);

describe('utils/findOverlappingPeriods', () => {
  const args = {
    periods: [
      {
        startDate: moment('01-01-2017', 'DD-MM-YYYY'),
        endDate: moment('01-01-2017', 'DD-MM-YYYY'),
      },
      {
        startDate: moment('02-01-2017', 'DD-MM-YYYY'),
        endDate: moment('02-01-2017', 'DD-MM-YYYY'),
      },
      {
        startDate: moment('03-01-2017', 'DD-MM-YYYY'),
        endDate: moment('03-01-2017', 'DD-MM-YYYY'),
      },
      {
        startDate: moment('04-01-2017', 'DD-MM-YYYY'),
        endDate: moment('04-01-2017', 'DD-MM-YYYY'),
      },
    ],
    normalizedInterval: 'day' as moment.unitOfTime.StartOf,
  };

  it('should check wether the current date range is in between the list of dates', () => {
    // Single day
    expect(
      findOverlappingPeriods({
        ...args,
        activeDateRange: {
          startDate: moment('02-01-2017', 'DD-MM-YYYY'),
          endDate: moment('02-01-2017', 'DD-MM-YYYY'),
        },
      }),
    ).toMatchSnapshot();

    // Multiple days
    expect(
      findOverlappingPeriods({
        ...args,
        activeDateRange: {
          startDate: moment('01-01-2017', 'DD-MM-YYYY'),
          endDate: moment('03-01-2017', 'DD-MM-YYYY'),
        },
      }),
    ).toMatchSnapshot();
  });
});
