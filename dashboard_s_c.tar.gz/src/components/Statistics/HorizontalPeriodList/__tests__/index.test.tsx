import React from 'react';
import moment from 'moment';
import { shallow } from 'enzyme';

import { INTERVAL_DAY } from 'containers/Statistics/constants';
import { intervalToMomentDuration, normalizeMomentDuration } from 'utils/parseMomentDuration';
import { getInBetweenPeriods } from 'containers/Statistics/DateRangeSlider';
import HorizontalPeriodList from '../index';

describe('<HorizontalPeriodList>', () => {
  const AMOUNT_OF_CELLS = 9;
  const FIRST_PAYMENT_DATE = '2017-03-01T00:00+0000';
  const interval = INTERVAL_DAY;
  const momentDuration = intervalToMomentDuration(INTERVAL_DAY);
  const periods = getInBetweenPeriods(
    momentDuration,
    FIRST_PAYMENT_DATE,
    new Date(2017, 6, 27),
    AMOUNT_OF_CELLS,
  );

  const defaultProps = {
    periods,
    interval,
    onChange: jest.fn(),
    normalizedInterval: normalizeMomentDuration(momentDuration),
  };

  describe('onMoveLeft', () => {
    it('should move the entire selection into view when it fits', () => {
      const props = {
        ...defaultProps,
        activeDateRange: {
          startDate: moment('01-06-2017', 'DD-MM-YYYY'),
          endDate: moment('06-06-2017', 'DD-MM-YYYY'),
        },
      };

      const wrapper = shallow(<HorizontalPeriodList {...props} />);
      (wrapper.instance() as HorizontalPeriodList).scrollToCell = jest.fn();
      (wrapper.instance() as HorizontalPeriodList).updatePeriods(props);

      // Set the position of the horizontal scroll, this is the 'window' into
      // which the cells are rendered.
      wrapper.setState({
        firstVisibleColumnIndex: 100,
        lastVisibleColumnIndex: 100 + AMOUNT_OF_CELLS,
      });
      (wrapper.instance() as HorizontalPeriodList).onMoveLeft();

      expect(wrapper.state('firstActivePeriodIndex')).toBe(92);
      expect(wrapper.state('lastActivePeriodIndex')).toBe(97);
      expect((wrapper.instance() as HorizontalPeriodList).scrollToCell).toBeCalledWith(101, 91);
    });

    it('should go to the first cell when target cell is below zero', () => {
      const props = {
        ...defaultProps,
        activeDateRange: {
          startDate: moment('04-03-2017', 'DD-MM-YYYY'),
          endDate: moment('04-03-2017', 'DD-MM-YYYY'),
        },
      };

      const wrapper = shallow(<HorizontalPeriodList {...props} />);
      (wrapper.instance() as HorizontalPeriodList).scrollToCell = jest.fn();
      (wrapper.instance() as HorizontalPeriodList).updatePeriods(props);

      // Set the position of the horizontal scroll, this is the 'window' into
      // which the cells are rendered.
      wrapper.setState({
        firstVisibleColumnIndex: 5,
        lastVisibleColumnIndex: 5 + AMOUNT_OF_CELLS,
      });
      (wrapper.instance() as HorizontalPeriodList).onMoveLeft();

      expect(wrapper.state('firstActivePeriodIndex')).toBe(3);
      expect(wrapper.state('lastActivePeriodIndex')).toBe(3);
      expect((wrapper.instance() as HorizontalPeriodList).scrollToCell).toBeCalledWith(6, 0);
    });

    it('should move to the right bound when the entire selection is offscreen to the left, and it doesn’t fit in its entirety', () => {
      const props = {
        ...defaultProps,
        activeDateRange: {
          startDate: moment('01-06-2017', 'DD-MM-YYYY'),
          endDate: moment('14-06-2017', 'DD-MM-YYYY'),
        },
      };

      const wrapper = shallow(<HorizontalPeriodList {...props} />);
      (wrapper.instance() as HorizontalPeriodList).scrollToCell = jest.fn();
      (wrapper.instance() as HorizontalPeriodList).updatePeriods(props);

      // Set the position of the horizontal scroll, this is the 'window' into
      // which the cells are rendered.
      wrapper.setState({
        firstVisibleColumnIndex: 110,
        lastVisibleColumnIndex: 110 + AMOUNT_OF_CELLS,
      });
      (wrapper.instance() as HorizontalPeriodList).onMoveLeft();

      expect(wrapper.state('firstActivePeriodIndex')).toBe(92);
      expect(wrapper.state('lastActivePeriodIndex')).toBe(105);
      // Substract 1 from AMOUNT_OF_CELLS because the last cell should still be in view
      expect((wrapper.instance() as HorizontalPeriodList).scrollToCell).toBeCalledWith(
        111,
        105 - (AMOUNT_OF_CELLS - 1),
      );
    });

    it('should move to the left bound when it isn’t visible, but the right is, and the selection doesn’t fit', () => {
      const props = {
        ...defaultProps,
        activeDateRange: {
          startDate: moment('01-06-2017', 'DD-MM-YYYY'),
          endDate: moment('14-06-2017', 'DD-MM-YYYY'),
        },
      };

      const wrapper = shallow(<HorizontalPeriodList {...props} />);
      (wrapper.instance() as HorizontalPeriodList).scrollToCell = jest.fn();
      (wrapper.instance() as HorizontalPeriodList).updatePeriods(props);

      // Set the position of the horizontal scroll, this is the 'window' into
      // which the cells are rendered.
      wrapper.setState({
        firstVisibleColumnIndex: 100,
        lastVisibleColumnIndex: 100 + AMOUNT_OF_CELLS,
      });
      (wrapper.instance() as HorizontalPeriodList).onMoveLeft();

      expect(wrapper.state('firstActivePeriodIndex')).toBe(92);
      expect(wrapper.state('lastActivePeriodIndex')).toBe(105);
      expect((wrapper.instance() as HorizontalPeriodList).scrollToCell).toBeCalledWith(101, 92);
    });

    it('should move the amount of visible cells minus one when there are no boundaries to the left side', () => {
      const props = {
        ...defaultProps,
        activeDateRange: {
          startDate: moment('01-06-2017', 'DD-MM-YYYY'),
          endDate: moment('14-06-2017', 'DD-MM-YYYY'),
        },
      };

      const wrapper = shallow(<HorizontalPeriodList {...props} />);
      (wrapper.instance() as HorizontalPeriodList).scrollToCell = jest.fn();
      (wrapper.instance() as HorizontalPeriodList).updatePeriods(props);

      // Set the position of the horizontal scroll, this is the 'window' into
      // which the cells are rendered.
      wrapper.setState({
        firstVisibleColumnIndex: 60,
        lastVisibleColumnIndex: 60 + AMOUNT_OF_CELLS,
      });
      (wrapper.instance() as HorizontalPeriodList).onMoveLeft();

      expect(wrapper.state('firstActivePeriodIndex')).toBe(92);
      expect(wrapper.state('lastActivePeriodIndex')).toBe(105);
      expect((wrapper.instance() as HorizontalPeriodList).scrollToCell).toBeCalledWith(
        61,
        60 - (AMOUNT_OF_CELLS - 1),
      );
    });
  });

  describe('onMoveRight', () => {
    it('should move the entire selection into view when it fits', () => {
      const props = {
        ...defaultProps,
        activeDateRange: {
          startDate: moment('01-06-2017', 'DD-MM-YYYY'),
          endDate: moment('06-06-2017', 'DD-MM-YYYY'),
        },
      };

      const wrapper = shallow(<HorizontalPeriodList {...props} />);
      (wrapper.instance() as HorizontalPeriodList).scrollToCell = jest.fn();
      (wrapper.instance() as HorizontalPeriodList).updatePeriods(props);
      wrapper.setState({
        firstVisibleColumnIndex: 80,
        lastVisibleColumnIndex: 88,
      });
      (wrapper.instance() as HorizontalPeriodList).onMoveRight();

      // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
      // @ts-ignore
      expect(wrapper.state('periods').length).toBe(periods.length);
      expect(wrapper.state('firstActivePeriodIndex')).toBe(92);
      expect(wrapper.state('lastActivePeriodIndex')).toBe(97);
      expect((wrapper.instance() as HorizontalPeriodList).scrollToCell).toBeCalledWith(87, 98);
    });

    it('should move to the left bound when the entire selection is offscreen to the right, and it doesn’t fit in its entirety', () => {
      const props = {
        ...defaultProps,
        activeDateRange: {
          startDate: moment('01-06-2017', 'DD-MM-YYYY'),
          endDate: moment('14-06-2017', 'DD-MM-YYYY'),
        },
      };

      const wrapper = shallow(<HorizontalPeriodList {...props} />);
      (wrapper.instance() as HorizontalPeriodList).scrollToCell = jest.fn();
      (wrapper.instance() as HorizontalPeriodList).updatePeriods(props);

      // Set the position of the horizontal scroll, this is the 'window' into
      // which the cells are rendered.
      wrapper.setState({
        firstVisibleColumnIndex: 80,
        lastVisibleColumnIndex: 80 + AMOUNT_OF_CELLS,
      });
      (wrapper.instance() as HorizontalPeriodList).onMoveRight();

      expect(wrapper.state('firstActivePeriodIndex')).toBe(92);
      expect(wrapper.state('lastActivePeriodIndex')).toBe(105);
      // Substract 1 from AMOUNT_OF_CELLS because the last cell should still be in view
      expect((wrapper.instance() as HorizontalPeriodList).scrollToCell).toBeCalledWith(
        80,
        92 + (AMOUNT_OF_CELLS - 1),
      );
    });

    it('should move to the right bound when it isn’t visible and the selection doesn’t fit', () => {
      const props = {
        ...defaultProps,
        activeDateRange: {
          startDate: moment('01-06-2017', 'DD-MM-YYYY'),
          endDate: moment('14-06-2017', 'DD-MM-YYYY'),
        },
      };

      const wrapper = shallow(<HorizontalPeriodList {...props} />);
      (wrapper.instance() as HorizontalPeriodList).scrollToCell = jest.fn();
      (wrapper.instance() as HorizontalPeriodList).updatePeriods(props);

      // Set the position of the horizontal scroll, this is the 'window' into
      // which the cells are rendered.
      wrapper.setState({
        firstVisibleColumnIndex: 90,
        lastVisibleColumnIndex: 90 + AMOUNT_OF_CELLS,
      });
      (wrapper.instance() as HorizontalPeriodList).onMoveRight();

      expect(wrapper.state('firstActivePeriodIndex')).toBe(92);
      expect(wrapper.state('lastActivePeriodIndex')).toBe(105);
      expect((wrapper.instance() as HorizontalPeriodList).scrollToCell).toBeCalledWith(91, 105);
    });

    it('should move the amount of visible cells minus one when there are no boundaries to the right side', () => {
      const props = {
        ...defaultProps,
        activeDateRange: {
          startDate: moment('01-06-2017', 'DD-MM-YYYY'),
          endDate: moment('14-06-2017', 'DD-MM-YYYY'),
        },
      };

      const wrapper = shallow(<HorizontalPeriodList {...props} />);
      (wrapper.instance() as HorizontalPeriodList).scrollToCell = jest.fn();
      (wrapper.instance() as HorizontalPeriodList).updatePeriods(props);

      // Set the position of the horizontal scroll, this is the 'window' into
      // which the cells are rendered.
      wrapper.setState({
        firstVisibleColumnIndex: 110,
        lastVisibleColumnIndex: 110 + AMOUNT_OF_CELLS,
      });
      (wrapper.instance() as HorizontalPeriodList).onMoveRight();

      expect(wrapper.state('firstActivePeriodIndex')).toBe(92);
      expect(wrapper.state('lastActivePeriodIndex')).toBe(105);
      expect((wrapper.instance() as HorizontalPeriodList).scrollToCell).toBeCalledWith(
        111,
        110 + AMOUNT_OF_CELLS + (AMOUNT_OF_CELLS - 1),
      );
    });
  });
});
