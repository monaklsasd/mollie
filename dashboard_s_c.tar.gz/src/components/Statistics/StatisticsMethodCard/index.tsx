import React from 'react';

import { FormattedNumber, FormattedMessage } from 'react-intl';
import StatisticsCard from 'components/Statistics/StatisticsCard';
import IconPaymentMethods, { AcceptedMethods } from 'components/IconPaymentMethods';
import getLocalizedMethodName from 'utils/getLocalizedMethodName';

// Messages
import messages from 'messages';

import './styles.scss';

type Props = {
  share: number;
  id: AcceptedMethods;
  payments: {
    count: number;
    amount: number;
  };
  refunds: {
    count: number;
    amount: number;
  };
  chargebacks: {
    count: number;
    amount: number;
  };
  supportsRefunds: boolean;
  supportsChargebacks: boolean;
};

const StatisticsMethodCard: React.FC<Props> = ({
  id,
  supportsChargebacks,
  supportsRefunds,
  share,
  payments,
  refunds,
  chargebacks,
}) => (
  <StatisticsCard
    className="c-statistics-method-card"
    heading={
      <span>
        <IconPaymentMethods width={28} height={28} method={id} /> {getLocalizedMethodName(id)}
      </span>
    }
    headingAddOn={
      <FormattedMessage
        id="statistics-method-card-revenue-share"
        defaultMessage="{share} of revenue"
        values={{
          share: <FormattedNumber value={share} format="percentage" />,
        }}
      />
    }>
    <ul className="c-statistics-method-card__details">
      <li>
        <span>
          <FormattedMessage {...messages.revenue} />
        </span>
        <span>
          <FormattedNumber value={payments.count} />x
        </span>
        <FormattedNumber value={payments.amount} format="EUR" />
      </li>
      {supportsRefunds && (
        <li>
          <span>
            <FormattedMessage {...messages.refunds} />
          </span>
          <span>
            <FormattedNumber value={refunds.count} />x
          </span>
          <FormattedNumber value={refunds.amount} format="EUR" />
        </li>
      )}
      {supportsChargebacks && (
        <li>
          <span>
            <FormattedMessage {...messages.chargebacks} />
          </span>
          <span>
            <FormattedNumber value={chargebacks.count} />x
          </span>
          <FormattedNumber value={chargebacks.amount} format="EUR" />
        </li>
      )}
    </ul>
  </StatisticsCard>
);

export default StatisticsMethodCard;
