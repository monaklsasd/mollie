import React from 'react';
import moment from 'moment';
import { FormattedMessage } from 'react-intl';

import * as constants from 'containers/Statistics/constants';

type Props = {
  x?: number;
  y?: number;
  fill: string;
  payload?: {
    value: number;
  };
  unit: string;
};

const StatisticsTick: React.FC<Props> = props => {
  const { fill, payload, unit } = props;
  const x = (props.x || 0) + 5;
  const y = (props.y || 0) + 5;
  const date = moment.unix(payload?.value || 0);

  switch (unit) {
    case constants.INTERVAL_HOUR:
      return (
        <text x={x} y={y} textAnchor="middle" fontSize={12} fill={fill}>
          {date.format('HH:mm')}
        </text>
      );

    case constants.INTERVAL_DAY:
    default:
      return (
        <text x={x} y={y} textAnchor="middle" fontSize={12} fill={fill}>
          <tspan>{date.format('ddd')}</tspan>
          <tspan x={x} y={y + 12}>
            {date.format('DD MMM')}
          </tspan>
        </text>
      );

    case constants.INTERVAL_WEEK:
      return (
        <text x={x} y={y} textAnchor="middle" fontSize={12} fill={fill}>
          <FormattedMessage
            tagName="tspan"
            defaultMessage="Week"
            id="statistics-graph-label-week"
          />
          <tspan x={x} y={y + 12}>
            {date.format('W')}
          </tspan>
        </text>
      );

    case constants.INTERVAL_MONTH:
      return (
        <text x={x} y={y} textAnchor="middle" fontSize={12} fill={fill}>
          <tspan>{date.format('MMM')}</tspan>
          <tspan x={x} y={y + 12}>
            ’{date.format('YY')}
          </tspan>
        </text>
      );
  }
};

export default StatisticsTick;
