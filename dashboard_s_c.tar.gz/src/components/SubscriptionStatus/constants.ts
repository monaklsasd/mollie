export const STATUS = {
  PENDING: 'pending',
  ACTIVE: 'active',
  CANCELLED: 'cancelled',
  SUSPENDED: 'suspended',
  COMPLETED: 'completed',
};
