import { IntlMessages } from './../../types/intl';
import { defineMessages } from 'react-intl';
import { STATUS } from './constants';

const messages: IntlMessages = defineMessages({
  [STATUS.PENDING]: {
    id: 'subscription-status-pending',
    defaultMessage: 'Pending',
  },
  [STATUS.ACTIVE]: {
    id: 'subscription-status-active',
    defaultMessage: 'Active',
  },
  [STATUS.CANCELLED]: {
    id: 'subscription-status-cancelled',
    defaultMessage: 'Cancelled',
  },
  [STATUS.SUSPENDED]: {
    id: 'subscription-status-suspended',
    defaultMessage: 'Suspended',
  },
  [STATUS.COMPLETED]: {
    id: 'subscription-status-completed',
    defaultMessage: 'Completed',
  },
});

export default messages;
