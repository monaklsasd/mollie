import React from 'react';
import { FormattedMessage } from 'react-intl';

// Constants
import {
  STATUS_NEUTRAL,
  STATUS_SUCCESS,
  STATUS_PENDING,
  STATUS_INDIFFERENT,
} from 'components/UI/Status';
import { STATUS } from './constants';

// Components
import StatusBlock from 'components/UI/StatusBlock';

// Messages
import messages from './messages';

type StatusBlockProps = React.ComponentProps<typeof StatusBlock>;

const mapSubscriptionStatusToStatus = (status: Props['status']): StatusBlockProps['status'] => {
  switch (status) {
    case STATUS.ACTIVE:
      return STATUS_SUCCESS;

    case STATUS.PENDING:
      return STATUS_PENDING;

    case STATUS.CANCELLED:
    case STATUS.SUSPENDED:
    case STATUS.COMPLETED:
      return STATUS_INDIFFERENT;

    default:
      return STATUS_NEUTRAL;
  }
};

const SubscriptionStatus: React.FC<Props> = ({ status }) => (
  <StatusBlock status={mapSubscriptionStatusToStatus(status)}>
    <FormattedMessage {...messages[status]} />
  </StatusBlock>
);

type Props = {
  status: keyof typeof messages;
};

export default SubscriptionStatus;
