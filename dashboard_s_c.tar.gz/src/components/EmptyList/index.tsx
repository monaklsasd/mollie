import React from 'react';
import { FormattedMessage } from 'react-intl';

// Components
import LoadingIndicator from 'components/UI/LoadingIndicator';
import Heading from 'components/UI/Heading';
import Button from 'components/UI/Button';

// Utils
import { Location } from 'history';
import { isEmpty } from 'lodash';

import './styles.scss';

type Props = {
  isLoading?: boolean;
  location: Record<string, any>;
  title: React.ReactNode;
  explanation?: React.ReactNode;
  resetFiltersLink: string | Location;
};

const EmptyList: React.FC<Props> = ({
  isLoading,
  location,
  explanation,
  title,
  resetFiltersLink,
}) => {
  // Check whether there are filters in the url.
  const showResetLink = !isEmpty(location.query);

  return (
    <div className="c-empty-list">
      {isLoading && <LoadingIndicator />}
      {!isLoading && (
        <div className="c-empty-list__inner">
          <Heading
            noMargin={!explanation && !showResetLink}
            type="h3"
            as="h2"
            className="c-empty-list__title">
            {title}
          </Heading>
          {explanation && <p>{explanation}</p>}
          {showResetLink && (
            <Button primary size="large" to={resetFiltersLink}>
              <FormattedMessage
                id="payments-empty-list-reset-filters"
                defaultMessage="Reset filters"
              />
            </Button>
          )}
        </div>
      )}
    </div>
  );
};

export default EmptyList;
