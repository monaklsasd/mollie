import React, { Component } from 'react';
import classNames from 'classnames';

import { ClassnamesFunction } from 'types/helpers';

import './styles.scss';

const getClass: ClassnamesFunction<Props & State> = ({ backdrop, className, size, isVisible }) =>
  classNames('c-spinner', className, {
    'c-spinner--with-backdrop': backdrop,
    'is-visible': isVisible,
    'c-spinner--small': size === 'small',
  });

interface Props {
  backdrop: boolean;
  delay: number;
  className?: string;
  fill: string;
  size?: 'small';
}

interface State {
  isVisible: boolean;
}

class Spinner extends Component<Props, State> {
  static defaultProps = {
    backdrop: true,
    delay: 1000,
    fill: '#000',
  };

  constructor(props: Props) {
    super(props);

    this.state = {
      isVisible: props.delay <= 0,
    };
  }

  componentDidMount(): void {
    const { delay } = this.props;

    if (delay > 0) {
      this.timeoutSpinner = setTimeout(this.onShowSpinner, delay);
    }
  }

  componentWillUnmount(): void {
    if (this.timeoutSpinner) {
      clearTimeout(this.timeoutSpinner);
    }
  }

  timeoutSpinner: Nullable<ReturnType<typeof setTimeout>> = null;

  onShowSpinner = (): void => {
    this.setState({ isVisible: true });
  };

  onHideSpinner = (): void => {
    this.setState({ isVisible: false });
  };

  _node: Nullable<HTMLElement> = null;

  render(): React.ReactNode {
    const { fill } = this.props;

    return (
      <div
        ref={(c): void => {
          this._node = c;
        }}
        className={getClass({ ...this.props, ...this.state })}>
        <svg
          width="100px"
          height="100px"
          viewBox="30 30 40 40"
          preserveAspectRatio="xMidYMid"
          style={{
            background: 'none',
          }}>
          <g transform="rotate(0 50 50)">
            <rect x="48" y="30" rx="3.84" ry="2.4" width="4" height="12" fill={fill}>
              <animate
                attributeName="opacity"
                values="1;0"
                dur="1s"
                begin="-0.875s"
                repeatCount="indefinite"
              />
            </rect>
          </g>
          <g transform="rotate(45 50 50)">
            <rect x="48" y="30" rx="3.84" ry="2.4" width="4" height="12" fill={fill}>
              <animate
                attributeName="opacity"
                values="1;0"
                dur="1s"
                begin="-0.75s"
                repeatCount="indefinite"
              />
            </rect>
          </g>
          <g transform="rotate(90 50 50)">
            <rect x="48" y="30" rx="3.84" ry="2.4" width="4" height="12" fill={fill}>
              <animate
                attributeName="opacity"
                values="1;0"
                dur="1s"
                begin="-0.625s"
                repeatCount="indefinite"
              />
            </rect>
          </g>
          <g transform="rotate(135 50 50)">
            <rect x="48" y="30" rx="3.84" ry="2.4" width="4" height="12" fill={fill}>
              <animate
                attributeName="opacity"
                values="1;0"
                dur="1s"
                begin="-0.5s"
                repeatCount="indefinite"
              />
            </rect>
          </g>
          <g transform="rotate(180 50 50)">
            <rect x="48" y="30" rx="3.84" ry="2.4" width="4" height="12" fill={fill}>
              <animate
                attributeName="opacity"
                values="1;0"
                dur="1s"
                begin="-0.375s"
                repeatCount="indefinite"
              />
            </rect>
          </g>
          <g transform="rotate(225 50 50)">
            <rect x="48" y="30" rx="3.84" ry="2.4" width="4" height="12" fill={fill}>
              <animate
                attributeName="opacity"
                values="1;0"
                dur="1s"
                begin="-0.25s"
                repeatCount="indefinite"
              />
            </rect>
          </g>
          <g transform="rotate(270 50 50)">
            <rect x="48" y="30" rx="3.84" ry="2.4" width="4" height="12" fill={fill}>
              <animate
                attributeName="opacity"
                values="1;0"
                dur="1s"
                begin="-0.125s"
                repeatCount="indefinite"
              />
            </rect>
          </g>
          <g transform="rotate(315 50 50)">
            <rect x="48" y="30" rx="3.84" ry="2.4" width="4" height="12" fill={fill}>
              <animate
                attributeName="opacity"
                values="1;0"
                dur="1s"
                begin="0s"
                repeatCount="indefinite"
              />
            </rect>
          </g>
        </svg>
      </div>
    );
  }
}

export default Spinner;
