import React from 'react';
import classNames from 'classnames';

import './styles.scss';

interface Props {
  className?: string;
  source: string;
  title?: React.ReactNode;
  description?: React.ReactNode;
  href?: string;
  onClick?: (event: React.MouseEvent<HTMLAnchorElement, MouseEvent>) => void;
}

const ImageLink: React.FC<Props> = ({ title, description, className, onClick, source, href }) => (
  <a
    className={classNames(className, 'image-link')}
    rel="noopener"
    onClick={onClick}
    href={href}
    target="_blank" // eslint-disable-line react/jsx-no-target-blank
  >
    <div className="image-link-text-block">
      {title && <p className="image-link-title">{title}</p>}
      {description && <p className="image-link-description">{description}</p>}
    </div>
    <img className="image-link-img" src={source} alt="" />
  </a>
);

export default ImageLink;
