import React from 'react';
import classNames from 'classnames';

import { ClassnamesFunction } from 'types/helpers';

import './styles.scss';

const getClass: ClassnamesFunction<Props & State> = ({ backdrop, className, isVisible }) =>
  classNames('c-loading-indicator', className, {
    'c-loading-indicator--with-backdrop': backdrop,
    'is-visible': isVisible,
  });

interface Props {
  backdrop: boolean;
  delay: number;
  className?: string;
}

interface State {
  isVisible: boolean;
}

class LoadingIndicator extends React.Component<Props, State> {
  static defaultProps = {
    backdrop: true,
    delay: 300,
  };

  constructor(props: Props) {
    super(props);

    this.state = {
      isVisible: props.delay <= 0,
    };
  }

  componentDidMount(): void {
    const { delay } = this.props;

    if (delay > 0) {
      this.timeoutLoadingIndicator = setTimeout(this.onShowLoadingIndicator, delay);
    }
  }

  componentWillUnmount(): void {
    if (this.timeoutLoadingIndicator) {
      clearTimeout(this.timeoutLoadingIndicator);
    }
  }

  timeoutLoadingIndicator: Nullable<ReturnType<typeof setTimeout>> = null;
  _node: Nullable<HTMLDivElement> = null;

  onShowLoadingIndicator = (): void => {
    this.setState({ isVisible: true });
  };

  render(): React.ReactElement {
    return (
      <div
        ref={(c): void => {
          this._node = c;
        }}
        className={getClass({ ...this.props, ...this.state })}>
        <svg width="210" height="126" viewBox="0 0 210 126" xmlns="http://www.w3.org/2000/svg">
          <path
            d="M105 126V61.5C105 37.476 85.524 18 61.5 18S18 37.476 18 61.5V126"
            fill="none"
            style={{
              animationDelay: `z{this.props.delay}ms`,
            }}
          />
          <path
            d="M192 126V61.5c0-24.024-19.476-43.5-43.5-43.5S105 37.476 105 61.5V126"
            fill="none"
            style={{
              animationDelay: `${this.props.delay}ms`,
            }}
          />
        </svg>
      </div>
    );
  }
}

export default LoadingIndicator;
