import React from 'react';
import classNames from 'classnames';

import { ClassnamesFunction } from 'types/helpers';

// Styles
import './styles.scss';

interface Props {
  className?: string;
  name: string;
  numeric?: boolean;
  onTopOfRowLink?: boolean;
  hasOpenTooltip?: boolean;
  tag?: React.ComponentType<any> | string;
}

const getClass: ClassnamesFunction<Props> = ({
  className,
  numeric,
  name,
  onTopOfRowLink,
  hasOpenTooltip,
}) =>
  classNames(className, 'grid-table-cell', `grid-table-cell__${name}`, {
    'grid-table-cell--numeric': numeric,
    'grid-table-cell--on-top-of-row-link': onTopOfRowLink,
    'grid-table-cell--has-open-tooltip': hasOpenTooltip,
  });

const GridCellFactory: React.FC<Props> = ({
  children,
  className,
  name,
  numeric = false,
  onTopOfRowLink = false,
  hasOpenTooltip = false,
  tag = 'div',
}) => {
  const Tag = tag;

  return (
    <Tag
      style={{ gridArea: name }}
      className={getClass({ className, numeric, name, onTopOfRowLink, hasOpenTooltip })}>
      {children}
    </Tag>
  );
};

export default GridCellFactory;
