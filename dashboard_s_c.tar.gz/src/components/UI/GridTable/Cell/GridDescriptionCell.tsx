import React from 'react';
import classNames from 'classnames';

// Context
import { GridContext, GridContextProps } from '../index';

// Internals
import GridCellFactory from './GridCellFactory';

// Types
import { ClassnamesFunction } from 'types/helpers';

interface Props {
  className?: string;
  name?: string;
  isTerm?: boolean;
}

const getClass: ClassnamesFunction<Props & GridContextProps & { cellName: string }> = ({
  gridTableClassName,
  className,
  cellName,
}) =>
  classNames(`${gridTableClassName}__cell`, `${gridTableClassName}__cell-${cellName}`, className);

const getTag = ({ isTerm, listType }): string => {
  if (listType !== 'description-list' && process.env.NODE_ENV === 'development') {
    // eslint-disable-next-line no-console
    console.warn(
      'GridTable:  listType prop should be set to description-list <GridTable listType="description-list"/>',
    );
  }

  return isTerm ? 'dt' : 'dd';
};

const getName = ({ name, isTerm }): string => {
  if (name) {
    return name;
  }

  return isTerm ? 'description-term' : 'description-details';
};

const GridDescriptionCell: React.FC<Props> = ({ className, name, isTerm = false, ...rest }) => (
  <GridContext.Consumer>
    {({ gridTableClassName, listType }): React.ReactNode => {
      const cellName = getName({ isTerm, name });

      return (
        <GridCellFactory
          name={cellName}
          tag={getTag({ listType, isTerm })}
          className={getClass({ gridTableClassName, className, cellName })}
          {...rest}
        />
      );
    }}
  </GridContext.Consumer>
);

export default GridDescriptionCell;
