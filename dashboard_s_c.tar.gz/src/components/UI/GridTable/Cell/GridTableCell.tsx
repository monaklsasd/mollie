import React from 'react';
import classNames from 'classnames';

// Internals
import GridCellFactory from './GridCellFactory';

// Context
import { GridContext, GridContextProps } from '../index';

// Types
import { ClassnamesFunction } from 'types/helpers';

type FactoryProps = React.ComponentProps<typeof GridCellFactory>;
interface Props extends FactoryProps {
  className?: string;
  name: string;
}

const getClass: ClassnamesFunction<Props & GridContextProps> = ({
  gridTableClassName,
  className,
  name,
}) => classNames(`${gridTableClassName}__cell`, `${gridTableClassName}__cell-${name}`, className);

const GridTableCell: React.FC<Props> = ({ className, name, ...restProps }) => (
  <GridContext.Consumer>
    {({ gridTableClassName }): React.ReactNode => (
      <GridCellFactory
        name={name}
        className={getClass({ gridTableClassName, className, name })}
        {...restProps}
      />
    )}
  </GridContext.Consumer>
);

export default GridTableCell;
