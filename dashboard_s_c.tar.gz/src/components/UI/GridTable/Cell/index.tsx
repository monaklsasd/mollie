import GridTableCell from './GridTableCell';
import GridDescriptionCell from './GridDescriptionCell';

/**
 * Currently there are two different types of cells
 * 1) GridTableCell
 *    - Will render a div and acts as the default
 *    - Example: <GridTableCell />  renders a div
 * 2) GridDescriptionCell
 *    - Will render or a DL or an DT depending on the isTerm prop
 *    - Example: <GridDescriptionCell isTerm />  renders a DT
 *    -          <GridDescriptionCell />         renders a DL
 */

export { GridDescriptionCell };
export default GridTableCell;
