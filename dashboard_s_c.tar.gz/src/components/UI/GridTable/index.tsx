import React from 'react';
import classNames from 'classnames';

import HeadRow from './HeadRow';

import './styles.scss';

interface Props {
  fixedHeader?: boolean;
  className: string;
  listType?: 'table' | 'description-list';
  columnRow?: React.ComponentProps<typeof HeadRow>['columnRow'];
  title?: React.ComponentProps<typeof HeadRow>['title'];
}

// Make grid className available via context
export const GridContext = React.createContext({
  gridTableClassName: 'grid-table',
  listType: 'table',
});

export type GridContextProps = React.ContextType<typeof GridContext>;

const GridTable: React.FC<Props> = ({
  className,
  columnRow,
  children,
  title,
  fixedHeader,
  listType = 'table',
}) => (
  <GridContext.Provider value={{ gridTableClassName: className, listType }}>
    <div className={classNames(className, 'grid-table__container')}>
      {(title || columnRow) && (
        <div className={classNames('grid-table__head', { 'grid-table__head--fixed': fixedHeader })}>
          <HeadRow title={title} columnRow={columnRow} />
        </div>
      )}
      <div
        className={classNames('grid-table__data', {
          'grid-table__data--has-column-row': columnRow,
        })}>
        {children}
      </div>
    </div>
  </GridContext.Provider>
);

export default GridTable;
