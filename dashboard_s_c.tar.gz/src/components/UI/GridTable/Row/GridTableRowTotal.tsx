import React from 'react';
import classNames from 'classnames';

// Components
import GridRowFactory from './GridRowFactory';

// Styles
import './styles.scss';

// Context
import { GridContext, GridContextProps } from '../index';

// Types
import { ClassnamesFunction } from 'types/helpers';

interface Props {
  className?: string;
}

const getClass: ClassnamesFunction<Props & GridContextProps> = ({
  className,
  gridTableClassName,
}) => classNames(className, 'grid-table-row-total', `${gridTableClassName}__row-total`);

const GridTableRowTotal: React.FC<Props> = ({ className, ...restProps }) => (
  <GridContext.Consumer>
    {({ gridTableClassName }): React.ReactNode => (
      <GridRowFactory className={getClass({ className, gridTableClassName })} {...restProps} />
    )}
  </GridContext.Consumer>
);

export default GridTableRowTotal;
