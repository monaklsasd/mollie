import React from 'react';
import classNames from 'classnames';
import { FormattedMessage, MessageDescriptor } from 'react-intl';

// Components
import Link from 'components/UI/Link';

// Context
import { GridContext, GridContextProps } from '../index';

// Types
import { ClassnamesFunction } from 'types/helpers';

// Styles
import './styles.scss';

interface Props {
  className?: string;
  link?: Nullable<{
    to?: React.ComponentProps<typeof Link>['to'];
    onClick?: (...args: any[]) => void;
    ariaLabel?: string | MessageDescriptor;
  }>;
  isHighlighted?: boolean;
}

const getClass: ClassnamesFunction<Props & GridContextProps> = ({
  className,
  isHighlighted,
  listType,
}): string =>
  classNames(className, 'grid-table-row', {
    'grid-table-row--highlighted': isHighlighted,
    [`grid-table-row--type-${listType}`]: listType,
  });

const RowLink = (link: Props['link']): Nullable<React.ReactElement<typeof FormattedMessage>> => {
  if (!link) {
    return null;
  }

  const { ariaLabel, ...linkProps } = link;

  if (ariaLabel && typeof ariaLabel === 'object') {
    return (
      // Use link props to make a "new" formatted message we fake the component.
      <FormattedMessage {...ariaLabel}>
        {(msg: string): React.ReactElement => (
          <Link className="grid-table-row__link" {...linkProps} aria-label={msg} />
        )}
      </FormattedMessage>
    );
  }

  if (ariaLabel) {
    return <Link className="grid-table-row__link" {...linkProps} aria-label={ariaLabel} />;
  }

  return null;
};

const GridRowFactory: React.FC<Props> = ({ children, className, link, isHighlighted }) => (
  <GridContext.Consumer>
    {({ listType }): React.ReactNode => {
      const Tag = listType === 'description-list' ? 'dl' : 'div';

      return (
        <Tag
          className={getClass({
            className,
            isHighlighted,
            listType,
          })}>
          {children}
          <RowLink {...link} />
        </Tag>
      );
    }}
  </GridContext.Consumer>
);

export default GridRowFactory;
