import GridTableRow from './GridTableRow';
import GridTableRowTotal from './GridTableRowTotal';

/**
 * Currently there are two different types of cells
 * 1) GridTableRow
 *    - Will render a div and acts as the default
 *    - Example: <GridTableRow />  renders a div
 * 2) GridTableRowTotal
 *    - renders a div with different classes
 *    - Example: <GridTableRowTotal />
 */

export { GridTableRow, GridTableRowTotal };
export default GridTableRow;
