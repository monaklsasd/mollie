import React from 'react';
import classNames from 'classnames';

// Components
import GridRowFactory from './GridRowFactory';

// Styles
import './styles.scss';

// Context
import { GridContext, GridContextProps } from '../index';

// Types
import { ClassnamesFunction } from 'types/helpers';

type FactoryProps = React.ComponentProps<typeof GridRowFactory>;

type Props = FactoryProps & {
  className?: string;
  isTitle?: boolean;
};

const getClass: ClassnamesFunction<Props & GridContextProps> = ({
  className,
  gridTableClassName,
  isTitle,
}): string => classNames(className, { [`${gridTableClassName}__row`]: !isTitle });

const GridTableRow: React.FC<Props> = ({ className, isTitle = false, ...restProps }) => (
  <GridContext.Consumer>
    {({ gridTableClassName }): React.ReactNode => (
      <GridRowFactory
        className={getClass({ className, gridTableClassName, isTitle })}
        {...restProps}
      />
    )}
  </GridContext.Consumer>
);

export default GridTableRow;
