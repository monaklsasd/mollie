import React from 'react';
import classNames from 'classnames';

// Components
import Heading from 'components/UI/Heading';
import GridTableRow from '../Row';
import GridTableCell from '../Cell';

// Types
import { ClassnamesFunction } from 'types/helpers';

// Styles
import './styles.scss';

const getHeaderRowClassNames: ClassnamesFunction<Props> = ({ columnRow, title }) =>
  classNames('grid-table-head-row', {
    'grid-table-head-row__title': title,
    'grid-table-head-row__column-row': columnRow,
  });

interface Props {
  title: React.ReactNode;
  columnRow?: React.ReactElement | React.ReactElement[];
}

const HeadRow: React.FC<Props> = ({ title, columnRow }) => (
  <React.Fragment>
    {title && (
      <GridTableRow isTitle className={getHeaderRowClassNames({ title })}>
        <GridTableCell name="title" className="grid-table-head-row__title-cell">
          <Heading className="grid-table-head-row__title-header">{title}</Heading>
        </GridTableCell>
      </GridTableRow>
    )}

    {columnRow && (
      <GridTableRow className={getHeaderRowClassNames({ columnRow })}>
        {React.Children.map(columnRow, child =>
          React.cloneElement(child, {
            className: classNames(child.props.className, 'grid-table-head-row__column-cell'),
          }),
        )}
      </GridTableRow>
    )}
  </React.Fragment>
);

export default HeadRow;
