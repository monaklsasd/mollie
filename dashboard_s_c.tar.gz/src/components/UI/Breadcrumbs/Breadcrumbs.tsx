import React, { ReactElement } from 'react';
import Breadcrumb from './Breadcrumb';

type Props = {
  children: (React.ReactElement | null)[];
};

const Breadcrumbs: React.FC<Props> = ({ children }) => {
  const childrenCount = React.Children.count(children);

  return (
    <ul className={'c-breadcrumbs'}>
      {React.Children.map(children, (child, index) => {
        if (!child) {
          return null;
        }
        const isLast = childrenCount === index + 1;

        if (child.props.isBreadcrumb) {
          return React.cloneElement(child, {
            lastCrumb: isLast,
          });
        }

        return <Breadcrumb lastCrumb={isLast}>{child}</Breadcrumb>;
      })}
    </ul>
  );
};

export default Breadcrumbs;
