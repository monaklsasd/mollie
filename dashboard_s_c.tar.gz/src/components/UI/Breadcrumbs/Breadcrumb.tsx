import React from 'react';
import classNames from 'classnames';
import { ReactComponent as IconBreadCrumbDivider } from 'assets/icons/breadcrumb-divider.svg';
import { ClassnamesFunction } from 'types/helpers';

interface Props {
  lastCrumb?: boolean;
  className?: string;
  isBreadcrumb?: boolean;
}

const getClass: ClassnamesFunction<Props> = ({ lastCrumb, className }) =>
  classNames(
    'c-breadcrumb',
    {
      'c-breadcrumb--last': lastCrumb,
    },
    className,
  );

const Breadcrumb: React.FC<Props> = ({ children, lastCrumb, className }) => {
  return (
    <li className={getClass({ lastCrumb, className })}>
      {children}
      {!lastCrumb && (
        <IconBreadCrumbDivider width={32} height={8} className={'c-breadcrumb-divider'} />
      )}
    </li>
  );
};

// isBreadcrumb prop is set to let BreadCrumbs(parent) know it's a breadcrumb (child)
// eslint-disable-next-line @typescript-eslint/ban-ts-ignore
// @ts-ignore
Breadcrumb.defaultProps = { isBreadcrumb: true };

export default Breadcrumb;
