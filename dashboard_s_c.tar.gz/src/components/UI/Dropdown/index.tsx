import * as React from 'react';
import { Link } from 'react-router-dom';
import classNames from 'classnames';
import CSSTransitionGroup from 'react-transition-group/CSSTransitionGroup';

// Context
import PageWrapperContext from 'containers/PageWrapper/PageWrapperContext';

// Utils
import { find, isEmpty } from 'lodash';

// Types
import { ClassnamesFunction } from 'types/helpers';

import './styles.scss';

const getClass: ClassnamesFunction<Props & State & { inPageWrapperHeader: boolean }> = ({
  className,
  isOpen,
  inPageWrapperHeader,
}) =>
  classNames(
    'c-dropdown',
    {
      'is-open': isOpen,
      'c-dropdown--in-page-header': inPageWrapperHeader,
    },
    className,
  );

const getOptionClass: ClassnamesFunction<Item> = ({ active, highlight }) =>
  classNames('c-dropdown__option js-dropdown-option', {
    'is-active': active,
    'is-highlight': highlight,
  });

const getCurrentItemTitle = (items: Props['items']): Item['label'] => {
  const activeItem: Maybe<Item> = find(items, (item: Item) => item.active);
  return activeItem && activeItem.label;
};

interface Item {
  key?: string;
  value: string;
  label: React.ReactNode;
  active: boolean;
  disabled: boolean;
  divider?: boolean;
  type: string;
  url: string;
  highlight: boolean;
}

interface Props {
  buttonTitle?: React.ReactNode;
  className?: string;
  items: Item[];
  id: string;
  onSelect: Function;
}

interface State {
  isOpen: boolean;
}

class Dropdown extends React.Component<Props, State> {
  state = {
    isOpen: false,
  };

  componentWillMount(): void {
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    window.addEventListener('click', this.handleDocumentClick);
  }

  componentWillUnmount(): void {
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    window.removeEventListener('click', this.handleDocumentClick);
  }

  _node: Nullable<HTMLDivElement> = null;
  _trigger: Nullable<HTMLButtonElement> = null;

  getFocusableMenuItems(): HTMLElement[] {
    const node = this._node;

    if (!node) {
      return [];
    }

    return Array.from(node.querySelectorAll('.js-dropdown-option'));
  }

  getItemsAndActiveIndex(): {
    items: HTMLElement[];
    activeIndex: number;
  } {
    const items = this.getFocusableMenuItems();
    const activeIndex = items.indexOf(document.activeElement as HTMLElement);

    return { items, activeIndex };
  }

  close(): void {
    this.setState({
      isOpen: false,
    });
  }

  open(): void {
    this.setState({
      isOpen: true,
    });
  }

  focusNextItem(): void {
    const { items, activeIndex } = this.getItemsAndActiveIndex();
    if (items.length === 0) {
      return;
    }

    const nextIndex = activeIndex === items.length - 1 ? 0 : activeIndex + 1;

    if (items[nextIndex]) {
      items[nextIndex].focus();
    }
  }

  focusPreviousItem(): void {
    const { items, activeIndex } = this.getItemsAndActiveIndex();
    if (items.length === 0) {
      return;
    }

    const prevIndex = activeIndex === 0 ? items.length - 1 : activeIndex - 1;

    if (items[prevIndex]) {
      items[prevIndex].focus();
    }
  }

  handleDocumentClick = (e: React.SyntheticEvent<any>): void => {
    const node = this._node;

    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    if (node && !isEmpty(node) && !node.contains(e.target)) {
      this.close();
    }
  };

  handleTrigger = (e: React.SyntheticEvent<any>): void => {
    e.preventDefault();
    if (!this.state.isOpen) {
      this.open();
    } else {
      this.close();
    }
  };

  handleKeyDown = (e: React.KeyboardEvent, options: { isTrigger?: boolean } = {}): void => {
    if (e.key !== 'ArrowDown' && e.key !== 'ArrowUp' && e.key !== 'Escape' && e.key !== 'Tab') {
      return;
    }

    // When user presses up or down on the trigger and dropdown is not open, open dropdown
    if ((e.key === 'ArrowUp' || e.key === 'ArrowDown') && options.isTrigger && !this.state.isOpen) {
      this.open();
      return;
    }

    switch (e.key) {
      // When user presses escape or tab, close dropdown
      case 'Escape':
        this.close();
        if (this._trigger) {
          this._trigger.focus();
        }
        break;
      case 'Tab':
        this.close();
        break;
      case 'ArrowDown':
        this.focusNextItem();
        e.preventDefault();
        break;
      case 'ArrowUp':
        this.focusPreviousItem();
        e.preventDefault();
        break;
      // no default
    }
  };

  render(): React.ReactNode {
    const { buttonTitle, className, items, id, onSelect } = this.props;
    const title = buttonTitle || getCurrentItemTitle(items);
    const { isOpen } = this.state;

    return (
      <PageWrapperContext.Consumer>
        {({ inPageWrapperHeader }): React.ReactNode => (
          <div
            className={getClass({ className, isOpen, inPageWrapperHeader })}
            ref={(c): void => {
              this._node = c;
            }}>
            <button
              type="button"
              className="c-dropdown__trigger"
              aria-haspopup="true"
              id={id}
              onClick={this.handleTrigger}
              onKeyDown={(e): void => {
                this.handleKeyDown(e, { isTrigger: true });
              }}
              ref={(c): void => {
                this._trigger = c;
              }}>
              {title}
            </button>
            <CSSTransitionGroup
              transitionName="c-dropdown__options"
              transitionEnterTimeout={100}
              transitionLeaveTimeout={100}>
              {this.state.isOpen && (
                <ul className="c-dropdown__options" aria-labelledby={id} key="c-dropdown-options">
                  {items
                    .filter(item => !item.active)
                    .map(item => {
                      const { divider, key, label, value, disabled, type, url } = item;

                      if (divider) {
                        return <li key={key || value} className="c-dropdown__divider" />;
                      }

                      return (
                        <li key={key || value}>
                          {type !== 'link' && (
                            <button
                              type="button"
                              onKeyDown={this.handleKeyDown}
                              disabled={disabled}
                              onClick={(): void => {
                                this.close();
                                // Explicitly check for undefined, because value can be set but false (e.g. '')
                                onSelect(value !== undefined ? value : key);
                              }}
                              className={getOptionClass(item)}>
                              {label}
                            </button>
                          )}
                          {type === 'link' && (
                            <Link
                              onKeyDown={this.handleKeyDown}
                              className={getOptionClass(item)}
                              to={url}>
                              {label}
                            </Link>
                          )}
                        </li>
                      );
                    })}
                </ul>
              )}
            </CSSTransitionGroup>
          </div>
        )}
      </PageWrapperContext.Consumer>
    );
  }
}

export default Dropdown;
