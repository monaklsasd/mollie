import React, { Component } from 'react';
import { DateRangePicker as ReactDatesPicker } from 'react-dates';
import { IntlShape, injectIntl, defineMessages } from 'react-intl';

import { IntlMessages } from 'types/intl';

import moment, { Moment } from 'moment';

import './styles.scss';

const messages: IntlMessages = defineMessages({
  startDatePlaceholder: {
    id: 'date-picker-start-date-placeholder',
    defaultMessage: 'From',
  },
  endDatePlaceholder: {
    id: 'date-picker-end-date-placeholder',
    defaultMessage: 'Till',
  },
});

const getDateFormat = (intl: IntlShape): string => {
  const date = intl.formatDate(new Date('2018-12-01'), {
    year: '2-digit',
    month: '2-digit',
    day: '2-digit',
  });

  return date
    .replace('18', 'YYYY')
    .replace('12', 'MM')
    .replace('01', 'DD');
};

interface Props {
  className?: string;
  startDate: Nullable<Moment>;
  startDateId: string;
  endDate: Nullable<Moment>;
  endDateId: string;
  maxDate?: Moment;
  firstDate?: Nullable<Moment>;
  startPlaceholder?: string;
  endPlaceholder?: string;
  anchorDirection?: Maybe<'left' | 'right'>;
  onDatesChange: (...args: any[]) => void;
  intl: IntlShape;
  readOnly?: boolean;
}

type State = {
  focusedInput: Nullable<'startDate' | 'endDate'>;
  firstDateMoment: Maybe<Moment>;
  todayMoment: Moment;
};

class DateRangePicker extends Component<Props, State> {
  constructor(props: Props) {
    super(props);

    this.DATE_FORMAT = getDateFormat(props.intl);

    this.state = {
      focusedInput: null,
      firstDateMoment: props.firstDate ? moment(props.firstDate).startOf('day') : undefined,
      todayMoment: props.maxDate ? props.maxDate : moment().startOf('day'),
    };
  }

  DATE_FORMAT: string;
  handleFocusChange = (focusedInput: Nullable<'startDate' | 'endDate'>): void => {
    this.setState({ focusedInput });
  };

  isOutsideRange = (date): boolean => {
    const { todayMoment, firstDateMoment } = this.state;

    if (!firstDateMoment) {
      return todayMoment.diff(date, 'days') < 0;
    }

    return todayMoment.diff(date, 'days') < 0 || firstDateMoment.diff(date, 'days') > 0;
  };

  render(): React.ReactNode {
    const { startPlaceholder, endPlaceholder, className, intl, ...rest } = this.props;

    return (
      <div className={className}>
        <ReactDatesPicker
          noBorder
          hideKeyboardShortcutsPanel
          displayFormat={this.DATE_FORMAT}
          focusedInput={this.state.focusedInput}
          isOutsideRange={this.isOutsideRange}
          minimumNights={0}
          numberOfMonths={1}
          onFocusChange={this.handleFocusChange}
          startDatePlaceholderText={
            startPlaceholder || intl.formatMessage(messages.startDatePlaceholder)
          }
          endDatePlaceholderText={endPlaceholder || intl.formatMessage(messages.endDatePlaceholder)}
          {...rest}
        />
      </div>
    );
  }
}

export default injectIntl(DateRangePicker);
