import React from 'react';
import { shallow } from 'enzyme';

import Heading from '../index';

describe('<Heading />', () => {
  it('should render a prop', () => {
    const id = 'testId';
    const renderedComponent = shallow(
      <Heading id={id}>
        <span>test</span>
      </Heading>,
    );
    expect(renderedComponent.prop('id')).toEqual(id);
  });

  it('should render a H1 when type is 1', () => {
    const children = 'Text';
    const renderedComponent = shallow(
      <Heading noMargin type="h1">
        {children}
      </Heading>,
    );

    expect(renderedComponent.find('h1.c-heading.c-heading--h1.c-heading--no-margin')).toHaveLength(
      1,
    );
  });

  it('should render a H3 with classes', () => {
    const children = 'Text';
    const renderedComponent = shallow(
      <Heading noMargin as="h2" type="h3">
        {children}
      </Heading>,
    );

    expect(renderedComponent.find('h3')).toHaveLength(1);
    expect(renderedComponent.hasClass('c-heading--h2')).toBe(true);
    expect(renderedComponent.hasClass('c-heading--no-margin')).toBe(true);
  });

  it('should render its text', () => {
    const children = 'Text';
    const renderedComponent = shallow(<Heading>{children}</Heading>);
    expect(renderedComponent.contains(children)).toBe(true);
  });
});
