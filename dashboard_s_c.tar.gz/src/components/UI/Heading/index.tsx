/**
 * Returns a Heading
 * But now the style and outline are separated
 * Now you can use h2 with h3 styling. see example below
 * <Heading type="h2" as="h3" />
 * and add extra classnames to overwrite or add extra css
 * <Heading className='mycss-class' />
 *
 * No margin bottom can be done like this:
 * As boolean
 * <Heading noMargin />
 */
import React from 'react';
import classNames from 'classnames';

import './styles.scss';

// Types
import { ClassnamesFunction } from 'types/helpers';

const getClass: ClassnamesFunction<Props & { styleAs: As }> = ({
  className,
  styleAs,
  noMargin,
}): string =>
  classNames(
    'c-heading',
    [`c-heading--${styleAs}`],
    { 'c-heading--no-margin': noMargin },
    className,
  );

type As = 'h1' | 'h2' | 'h3';

interface Props {
  type?: As;
  as?: As;
  className?: string;
  noMargin?: boolean;
  id?: string;
}

const Heading: React.FC<Props> = ({
  type = 'h2',
  children,
  as,
  className,
  noMargin,
  ...others
}) => {
  const Tag = type;
  const styleAs = as || type;

  return (
    <Tag className={getClass({ className, styleAs, noMargin })} {...others}>
      {children}
    </Tag>
  );
};

export default Heading;
