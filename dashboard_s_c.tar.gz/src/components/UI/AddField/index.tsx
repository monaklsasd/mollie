import React from 'react';

// Components
import Link from 'components/UI/Link';
import Tooltip from 'components/UI/Tooltip';
import { ReactComponent as IconAddField } from 'assets/icons/add-field.svg';

// Styles
import './styles.scss';

interface Props {
  label: React.ReactElement | string;
  onClick: React.ComponentProps<typeof Link>['onClick'];
  onMouseOver?: React.ComponentProps<typeof Link>['onMouseOver'];
  disabled?: boolean;
  disabledReason?: React.ReactElement;
}

const wrapDisabled = ({ link, disabled, disabledReason }) => {
  if (disabled) {
    return <Tooltip content={disabledReason}>{link}</Tooltip>;
  }

  return link;
};

const AddField: React.FC<Props> = ({
  label,
  onClick,
  onMouseOver,
  disabled,
  disabledReason,
}: Props) =>
  wrapDisabled({
    disabled,
    disabledReason,
    link: (
      <Link
        className={'c-add-field'}
        linkStyle="blue"
        disabled={disabled}
        noUnderline
        onClick={onClick}
        onMouseOver={onMouseOver}>
        <span className="c-add-field__icon-wrapper">
          <IconAddField className={'c-add-field__icon'} />
        </span>
        {label}
      </Link>
    ),
  });

export default AddField;
