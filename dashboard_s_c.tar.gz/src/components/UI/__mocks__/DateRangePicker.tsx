import React from 'react';

export default function DateRangePickerMock(): React.ReactNode {
  return <p>DateRangePicker mock</p>;
}
