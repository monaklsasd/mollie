import React from 'react';
import classNames from 'classnames';

// Constants
import PAYMENT_METHODS, { isPaymentMethod } from 'helpers/paymentMethods';
import GIFTCARD_ISSUERS, { GiftCardIssuers } from 'helpers/giftcardIssuers';

// Containers
import GiftCardIssuerName from 'containers/GiftCardIssuerName';

// Components
import Currency from 'components/UI/Currency';
import IconPaymentMethods, { AcceptedMethods } from 'components/IconPaymentMethods';
import Tooltip from 'components/UI/Tooltip';

// Utils
import getLocalizedMethodName from 'utils/getLocalizedMethodName';

// Types
import { Amount } from 'reduxState/types';
import { PaymentMethod } from 'helpers/paymentMethods';

import './styles.scss';
import { ClassnamesFunction } from 'types/helpers';

const getClass: ClassnamesFunction<Props> = ({ align }) =>
  classNames('c-stacked-icons', {
    'c-stacked-icons--align-right': align === 'right',
  });

interface Props {
  label?: React.ReactElement;
  methods: {
    id: PaymentMethod;
    amount: Amount;
  }[];
  align?: 'right' | 'left';
  showTooltip?: boolean;
  showFallbackIcon?: boolean;
}

const renderIcons = ({
  methods,
  align,
}: {
  methods: Props['methods'];
  align: Props['align'];
}): React.ReactElement => (
  <ul className={getClass({ align })}>
    {/*
     * We’re rendering the elements in reverse order. Why you ask? Because
     * it gives us the advantage that we don’t have to use z-index to
     * stack them correctly. See _c-stacked-icons.scss for more info.
     */
    methods.reverse().map((method, index) => (
      <li key={`stacked-icons-${method.id}-${index}`}>
        <IconPaymentMethods method={method.id} width={30} height={30} />
      </li>
    ))}
  </ul>
);

export const getPaymentMethod = ({
  method,
  amount,
  issuer,
}: {
  amount: Amount;
  issuer?: string;
  method: AcceptedMethods;
}): {
  id: string;
  amount: Amount;
} => {
  if (
    method === PAYMENT_METHODS.GIFTCARD &&
    issuer &&
    Object.values(GIFTCARD_ISSUERS).includes(issuer)
  ) {
    return {
      id: issuer,
      amount,
    };
  }

  return {
    id: method,
    amount,
  };
};

const StackedIcons: React.FC<Props> = ({
  label,
  methods,
  align,
  showTooltip = true,
  showFallbackIcon = false,
}) => {
  if (!methods.length && showFallbackIcon) {
    return <IconPaymentMethods method="fallback" width={30} height={30} />;
  }

  if (!showTooltip) {
    return <div className="c-stacked-icons-wrapper">{renderIcons({ methods, align })}</div>;
  }

  return (
    <Tooltip
      content={
        <div className="c-stacked-icons__tooltip">
          {label && <p>{label}</p>}
          <dl>
            {methods.map((method, index) => [
              <dt key={`method--${method.id}-${index}`}>
                <b className={`c-stacked-icons__indicator u-background-${method.id}`} />
                {isPaymentMethod(method.id) ? (
                  getLocalizedMethodName(method.id)
                ) : (
                  <GiftCardIssuerName issuer={method.id as GiftCardIssuers} />
                )}
              </dt>,
              <dd key={`method-currency-${method.id}-${index}`}>
                <Currency {...method.amount} />
              </dd>,
            ])}
          </dl>
        </div>
      }
      appendTo={document.body}>
      {renderIcons({ methods, align })}
    </Tooltip>
  );
};

StackedIcons.defaultProps = {
  showTooltip: true,
  showFallbackIcon: false,
};

export default StackedIcons;
