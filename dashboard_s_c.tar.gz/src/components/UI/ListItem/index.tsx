/*
 * NOTE: this has nothing to do with the <List> component
 */
import React from 'react';
import classNames from 'classnames';

import Heading from 'components/UI/Heading';

import { ClassnamesFunction } from 'types/helpers';

import './styles.scss';

const getClassNames: ClassnamesFunction<Props> = ({ controlPosition, size, nested, className }) =>
  classNames('c-list-item', className, {
    [`c-list-item--${size}`]: size,
    'c-list-item--nested': nested,
    'c-list-item--flipped': controlPosition === 'left',
  });

const getStatusClass: ClassnamesFunction<Props> = ({ status }): string =>
  classNames('c-list-item__status', {
    [`c-list-item__status-${status}`]: status,
  });

const getIconClass: ClassnamesFunction<Props> = ({ iconSize, iconClassName }): string =>
  classNames(
    'c-list-item__icon',
    {
      [`c-list-item__icon--${iconSize}`]: iconSize !== 'regular',
    },
    iconClassName,
  );

const getHeadingClass: ClassnamesFunction<Props> = ({ size }) =>
  classNames('c-list-item__heading', {
    [`c-list-item__heading--${size}`]: size,
  });

const getByLineClass: ClassnamesFunction<Props> = ({ size, truncateBylineText }) =>
  classNames('c-list-item__byline', {
    [`c-list-item__byline--${size}`]: size,
    'c-list-item__byline--truncate': truncateBylineText,
  });

type DivProps = React.HTMLAttributes<HTMLDivElement>;
type Props = DivProps & {
  htmlFor?: string;
  tag?: string;
  icon?: React.ReactElement;
  iconSize?: 'regular' | 'fill' | 'large';
  iconClassName?: string;
  heading?: React.ReactNode;
  byline?: React.ReactNode;
  children?: React.ReactNode;
  status?: React.ReactNode;
  statusMessage?: React.ReactNode;
  control?: React.ReactElement;
  controlPosition?: 'left' | 'right';
  size?: 'regular' | 'compact' | 'large';
  nested?: boolean;
  truncateBylineText?: boolean;
  className?: string;
};

const ListItem: React.FC<Props> = ({
  tag,
  icon,
  heading,
  byline,
  status,
  statusMessage,
  control,
  controlPosition = 'right',
  size,
  iconSize,
  iconClassName,
  nested,
  truncateBylineText,
  className,
  children,
  ...others
}) => {
  const TagName = tag || 'div';

  return (
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    <TagName className={getClassNames({ controlPosition, size, nested, className })} {...others}>
      {status && statusMessage && <p className={getStatusClass({ status })}>{statusMessage}</p>}
      <div className="c-list-item__body">
        {icon && <figure className={getIconClass({ iconSize, iconClassName })}>{icon}</figure>}
        <div className="c-list-item__header">
          {heading && (
            <Heading type="h3" className={getHeadingClass({ size })}>
              {heading}
            </Heading>
          )}
          {byline && <p className={getByLineClass({ size, truncateBylineText })}>{byline}</p>}
        </div>
        {control && <div className="c-list-item__control">{control}</div>}
        {children && <div className="c-list-item__additional-info">{children}</div>}
      </div>
    </TagName>
  );
};

export default ListItem;
