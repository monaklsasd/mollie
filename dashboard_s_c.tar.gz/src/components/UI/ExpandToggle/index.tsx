import React from 'react';
import classNames from 'classnames';

import { ReactComponent as IconExpand } from 'assets/icons/expand.svg';

import { ClassnamesFunction } from 'types/helpers';

import './styles.scss';

const getClass: ClassnamesFunction<Props> = ({ open }) =>
  classNames('c-expand-toggle', {
    'is-open': open,
  });

interface Props {
  open: boolean;
  onToggle: (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
  openLabel: string;
  closeLabel: string;
}

const ExpandToggle: React.FC<Props> = ({ open, onToggle, openLabel, closeLabel }) => (
  <button
    type="button"
    onClick={onToggle}
    aria-label={open ? closeLabel : openLabel}
    className={getClass({ open })}>
    <IconExpand />
  </button>
);

export default ExpandToggle;
