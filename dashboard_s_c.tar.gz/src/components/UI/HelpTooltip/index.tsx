import React from 'react';
import classNames from 'classnames';

// import components
import Tooltip from 'components/UI/Tooltip';
import Link from 'components/UI/Link';

// import icon
import { ReactComponent as IconInfo } from 'assets/icons/info.svg';

import './styles.scss';

type ToolTipProps = React.ComponentProps<typeof Tooltip>;
type Props = Omit<ToolTipProps, 'children'> & {
  ariaLabel: string;
  className?: string;
};

const HelpTooltip: React.FC<Props> = ({
  content,
  ariaLabel,
  className,
  showOnHover = false,
  ...others
}) => (
  <Tooltip
    content={content}
    containerClassName={classNames('c-help-tooltip', className)}
    showOnHover={showOnHover}
    {...others}>
    <Link className="c-help-tooltip__button" aria-label={ariaLabel}>
      <IconInfo className="c-help-tooltip__icon" />
    </Link>
  </Tooltip>
);

export default HelpTooltip;
