import React from 'react';
import classNames from 'classnames';
import FlashMessage from 'components/UI/FlashMessage';
import { LoadingIndicator, Spinner } from 'components/UI';

import { ClassnamesFunction } from 'types/helpers';

import './styles.scss';

interface Props {
  delay?: number;
  isLoading?: boolean;
  error?: React.ReactNode;
  message?: React.ReactNode;
  compact?: boolean;
  noBorder?: boolean;
  noMargin?: boolean;
  fullHeight?: boolean;
  className?: string;
}

const getClass: ClassnamesFunction<Props> = ({
  compact,
  noBorder,
  noMargin,
  message,
  fullHeight,
  className,
}) =>
  classNames('c-loading-state', className, {
    'c-loading-state--compact': compact,
    'c-loading-state--no-border': noBorder,
    'c-loading-state--with-message': message,
    'c-loading-state--no-margin': noMargin,
    'c-loading-state--full-height': fullHeight,
  });

const LoadingState: React.FC<Props> = ({
  children = null,
  compact,
  isLoading,
  error,
  message,
  noBorder,
  noMargin,
  delay,
  fullHeight,
  className,
}) => {
  if (!isLoading) {
    return <React.Fragment>{children}</React.Fragment>;
  }

  if (error) {
    return <FlashMessage state="error">{error}</FlashMessage>;
  }

  return (
    <div className={getClass({ compact, message, noBorder, noMargin, fullHeight, className })}>
      {compact ? (
        // Delaying the spinner makes no sense when also showing a message.
        <Spinner
          className="c-loading-state__spinner"
          delay={message ? 0 : delay}
          backdrop={false}
        />
      ) : (
        <LoadingIndicator
          className="c-loading-state__spinner"
          delay={message ? 0 : delay}
          backdrop={false}
        />
      )}
      {message && <p>{message}</p>}
    </div>
  );
};

export default LoadingState;
