import React from 'react';
import Heading from 'components/UI/Heading';
import classNames from 'classnames';

import { ClassnamesFunction } from 'types/helpers';

import './styles.scss';

const getClass: ClassnamesFunction<Props> = ({ compact, noMargin, className }) =>
  classNames('c-empty', className, {
    'c-empty--compact': compact,
    'c-empty--no-margin': noMargin,
  });

interface Props {
  icon?: React.ReactNode;
  title?: React.ReactNode;
  explanation?: React.ReactNode;
  compact?: boolean;
  noMargin?: boolean;
  className?: string;
}

const Empty: React.FC<Props> = ({ icon, title, explanation, compact, noMargin, className }) => (
  <div className={getClass({ compact, noMargin, className })}>
    {icon && <span className="c-empty__icon">{icon}</span>}
    {title && (
      <Heading type="h3" as="h2" className="c-empty__title">
        {title}
      </Heading>
    )}
    {explanation && <p>{explanation}</p>}
  </div>
);

export default Empty;
