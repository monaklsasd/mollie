import React from 'react';
import moment, { Moment } from 'moment';
import { defineMessages, useIntl } from 'react-intl';
import { ANCHOR_RIGHT } from 'react-dates/constants';

import DateRangePicker from 'components/UI/DateRangePicker';
import RadioButton from 'components/forms/RadioButton';
import { IntlMessages } from 'types/intl';

import './styles.scss';

// Types
const messages: IntlMessages = defineMessages({
  today: {
    id: 'date-presets-today',
    defaultMessage: 'Today',
  },
  // eslint-disable-next-line @typescript-eslint/camelcase
  this_week: {
    id: 'date-presets-current-week',
    defaultMessage: 'This week',
  },
  // eslint-disable-next-line @typescript-eslint/camelcase
  this_month: {
    id: 'date-presets-current-month',
    defaultMessage: 'This month',
  },
  custom: {
    id: 'date-presets-custom-date',
    defaultMessage: 'Custom',
  },
  anytime: {
    id: 'date-presets-anytime',
    defaultMessage: 'Anytime',
  },
});

export type PresetType = 'anytime' | 'today' | 'this_week' | 'this_month' | 'custom';

interface Props {
  datePresets: PresetType[];
  onDatesChange: (...args: any[]) => void;
  selectedDates: Nullable<{
    startDate: Maybe<Date | Moment>;
    endDate: Maybe<Date | Moment>;
  }>;
  selectedPreset: Nullable<PresetType>;
  onPresetChange: (...args: any[]) => void;
}

const DatePresets: React.FC<Props> = ({
  onDatesChange,
  selectedDates,
  datePresets,
  selectedPreset = 'anytime',
  onPresetChange,
}) => {
  const intl = useIntl();
  return (
    <ul className="date-presets">
      {datePresets.map(preset => (
        <li key={preset}>
          <RadioButton
            id={preset}
            label={intl.formatMessage(messages[preset])}
            checked={selectedPreset === preset}
            name={intl.formatMessage(messages[preset])}
            onChange={(): ReturnType<typeof onPresetChange> => onPresetChange(preset)}
            value={preset}
          />
        </li>
      ))}
      {selectedPreset === 'custom' && selectedDates && (
        <li>
          <DateRangePicker
            className="date-presets__datepicker"
            onDatesChange={onDatesChange}
            startDate={moment(selectedDates.startDate || undefined)}
            startDateId="date-presets-start"
            endDate={moment(selectedDates.endDate || undefined)}
            endDateId="date-presets-end"
            anchorDirection={ANCHOR_RIGHT}
          />
        </li>
      )}
    </ul>
  );
};

export default DatePresets;
