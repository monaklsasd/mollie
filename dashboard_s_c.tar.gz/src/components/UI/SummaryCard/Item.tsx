import React from 'react';
import classNames from 'classnames';
import Link from 'components/UI/Link';
import { ClassnamesFunction } from 'types/helpers';

interface Props {
  to?: string;
  className?: string;
}

const getClass: ClassnamesFunction<Props> = ({ className }) =>
  classNames('summary-card__item', className);

const SummaryCardItem: React.FC<Props> = ({ to, children, className }) => {
  if (to) {
    return (
      <Link noUnderline to={to} className={getClass({ className })}>
        {children}
        <b className="summary-card__arrow" />
      </Link>
    );
  }

  return <div className={getClass({ className })}>{children}</div>;
};

export default SummaryCardItem;
