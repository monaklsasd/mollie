import React from 'react';
import classNames from 'classnames';

import { ClassnamesFunction } from 'types/helpers';

import './styles.scss';

const getClass: ClassnamesFunction<Props> = ({ showHeader }) =>
  classNames('summary-card', {
    'summary-card--no-header': !showHeader,
  });

const getHeaderClassNames: ClassnamesFunction<{ hasChildren: boolean }> = ({ hasChildren }) =>
  classNames('summary-card__header', {
    'summary-card__header--no-children': !hasChildren,
  });

interface Props {
  avatar?: React.ReactNode;
  controls?: React.ReactNode;
  heading: React.ReactNode;
  byline?: React.ReactNode;
  status?: React.ReactNode;
  showHeader?: boolean;
}

const SummaryCard: React.FC<Props> = ({
  avatar,
  heading,
  children,
  controls,
  byline,
  status,
  showHeader,
  ...rest
}) => (
  <article className={getClass({ showHeader })} {...rest}>
    {showHeader && (
      <header className={getHeaderClassNames({ hasChildren: !!children })}>
        {avatar && (
          <span className="summary-card__avatar" aria-hidden>
            {avatar}
          </span>
        )}
        <div className="summary-card__heading-group">
          <h2 className="summary-card__heading">{heading}</h2>
          {byline && <p className="summary-card__byline">{byline}</p>}
        </div>
        {status && <span className="summary-card__status">{status}</span>}
        {controls && <div className="summary-card__controls">{controls}</div>}
      </header>
    )}
    <ul className="summary-card__list">
      {React.Children.map(children, child => (
        <li>{child}</li>
      ))}
    </ul>
  </article>
);

SummaryCard.defaultProps = {
  showHeader: true,
};

export default SummaryCard;
