import React from 'react';
import { FormattedMessage } from 'react-intl';
import CopyToClipboard from 'react-copy-to-clipboard';

// Messages
import globalMessages from 'messages';
import messages from './messages';

// Components
import ButtonGroup from 'components/UI/ButtonGroup';
import Status, { States } from 'components/UI/Status';
import Link from 'components/UI/Link';

// Icons
import { ReactComponent as IconCheck } from 'assets/icons/check-nopadding.svg';

import './styles.scss';

interface Props {
  value?: string;
  label: React.ReactNode;
  status?: States;
  cloaked?: boolean;
  noKeyLabel?: React.ReactNode;
  onReset?: (event: React.MouseEvent<any, MouseEvent>) => void;
  title?: string;
  id?: string;
}

interface State {
  isCopied: boolean;
  isRevealed: boolean;
}

class Key extends React.Component<Props, State> {
  static defaultProps = {
    cloaked: false,
  };

  constructor(props: Props) {
    super(props);

    this.state = {
      isCopied: false,
      isRevealed: !props.cloaked,
    };
  }

  timer: Nullable<ReturnType<typeof setTimeout>> = null;
  copyableInput: Nullable<HTMLInputElement> = null;

  handleFocus = (): void => {
    this.setState({ isRevealed: true }, () => {
      if (this.copyableInput) {
        this.copyableInput.select();
      }
    });
  };

  setCopied = (): void => {
    this.setState({
      isCopied: true,
    });

    this.timer = setTimeout(() => {
      this.setState({
        isCopied: false,
      });
    }, 1000);
  };

  renderCopyButton(value: string): React.ReactNode {
    if (this.state.isCopied) {
      return (
        <div className="ui-key-item__copied-message">
          <IconCheck className="ui-key-item__copied-icon" />
          <FormattedMessage {...globalMessages.copied} />
        </div>
      );
    }

    return (
      <CopyToClipboard text={value} onCopy={this.setCopied}>
        <Link linkStyle="blue">
          <FormattedMessage {...globalMessages.copy} />
        </Link>
      </CopyToClipboard>
    );
  }

  renderResetButton(): React.ReactNode {
    if (!this.props.onReset) {
      return null;
    }

    return (
      <Link onClick={this.props.onReset} linkStyle="danger">
        <FormattedMessage {...messages.resetKey} />
      </Link>
    );
  }

  render(): React.ReactNode {
    const { status, label, value, noKeyLabel, title, id } = this.props;

    const { isRevealed } = this.state;

    return (
      <React.Fragment>
        <p className="l-form-label ui-key-label">
          {status && <Status state={status} iconPlacement="prepend" hideDefinition />}
          {label}
        </p>
        {!value ? (
          noKeyLabel
        ) : (
          <div className="ui-key-item__key">
            {isRevealed && (
              <input
                id={id}
                className="u-monospace"
                onClick={this.handleFocus}
                readOnly
                ref={(c): void => {
                  this.copyableInput = c;
                }}
                title={title}
                value={value}
              />
            )}
            {!isRevealed && (
              <button className="ui-key-button" onClick={this.handleFocus}>
                <div className="ui-key-item__reveal">
                  <div className="u-monospace ui-key-item__reveal-asterisk">
                    {new Array(value.length + 1).join('*')}
                  </div>
                  <div className="ui-key-item__reveal-label">
                    (<FormattedMessage {...messages.keyNotRevealedLabel} />)
                  </div>
                </div>
              </button>
            )}
          </div>
        )}
        {value && (
          <ButtonGroup className="ui-key-item__button-group">
            {this.renderCopyButton(value)}
            {this.renderResetButton()}
          </ButtonGroup>
        )}
      </React.Fragment>
    );
  }
}

export default Key;
