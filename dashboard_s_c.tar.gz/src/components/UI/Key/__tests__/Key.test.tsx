import React from 'react';
import { omit } from 'lodash';
import createComponentWithIntl from 'helpers/createComponentWithIntl';

import { STATUS_SUCCESS } from 'components/UI/Status';

import Key from '../index';

describe('<ApiKey>', () => {
  let props: React.ComponentProps<typeof Key>;

  beforeEach(() => {
    props = {
      value: 'k3yv4lu3',
      label: 'API Live Key',
      status: STATUS_SUCCESS,
      cloaked: true,
      noKeyLabel: 'No key',
      onReset: jest.fn(),
      title: 'The title of the input',
    };
  });

  it('shows a key with a label, a success status, on which you have to click to reveal with 1 additional action', () => {
    const tree = createComponentWithIntl(<Key {...props} />).toJSON();

    expect(tree).toMatchSnapshot();
  });

  it(`should not show a reset button, when there's no reset function`, () => {
    const tree = createComponentWithIntl(<Key {...omit(props, 'onReset')} />).toJSON();
    expect(tree).toMatchSnapshot();
  });
});
