import { IntlMessages } from './../../../types/intl';
import { defineMessages } from 'react-intl';

const messages: IntlMessages = defineMessages({
  keyNotRevealedLabel: {
    id: 'ui-key-is-not-revealed',
    defaultMessage: 'Click to reveal',
  },
  resetKey: {
    id: 'ui-key-reset',
    defaultMessage: 'Reset',
  },
});

export default messages;
