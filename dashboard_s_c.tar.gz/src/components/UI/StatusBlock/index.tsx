import React from 'react';
import classNames from 'classnames';

import { ClassnamesFunction } from 'types/helpers';

import './styles.scss';

const getClass: ClassnamesFunction<Props> = ({ status, className }) =>
  classNames(
    'c-status-block',
    {
      [`c-status-block--${status}`]: status,
    },
    className,
  );

interface Props {
  status: 'neutral' | 'success' | 'error' | 'pending' | 'indifferent';
  hideStatusText?: boolean;
  className?: string;
}

const StatusBlock: React.FC<Props> = ({ status, className, children }) => (
  <span role="status" className={getClass({ status, className })}>
    {children}
  </span>
);

StatusBlock.defaultProps = {
  status: 'indifferent',
};

export default StatusBlock;
