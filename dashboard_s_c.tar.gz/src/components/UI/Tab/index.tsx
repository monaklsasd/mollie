import React from 'react';
import classNames from 'classnames';

import { ClassnamesFunction } from 'types/helpers';

import './styles.scss';

const getClass: ClassnamesFunction<Props> = ({ className, isActive }) =>
  classNames(
    'c-tab',
    {
      'is-active': isActive,
    },
    className,
  );

interface Props {
  onClick?: (el: Nullable<HTMLElement>) => void;
  value?: string;
  className?: string;
  isActive?: boolean;
}

class Tab extends React.Component<Props> {
  node: Nullable<HTMLElement> = null;

  handleClick = (e: React.MouseEvent<HTMLButtonElement>): void => {
    const { onClick } = this.props;

    if (onClick) {
      onClick(this.node);
    }

    e.preventDefault();
  };

  render(): React.ReactNode {
    const { onClick, value, children } = this.props;

    if (onClick) {
      return (
        <button
          type="button"
          className={getClass(this.props)}
          onClick={this.handleClick}
          value={value}
          ref={(c): void => {
            this.node = c;
          }}>
          {children}
        </button>
      );
    }

    return <div className={getClass(this.props)}>{children}</div>;
  }
}

export default Tab;
