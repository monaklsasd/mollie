import * as React from 'react';
import classNames from 'classnames';

import css from './styles.module.scss';

interface Props {
  status: 'pending' | 'warning' | 'neutral';
  count: number;
}

const Badge: React.FC<Props> = ({ status = 'neutral', count }) => (
  <span className={classNames(css.badge, css[status] || '')}>{count}</span>
);

export default Badge;
