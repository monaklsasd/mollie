import React from 'react';
import classNames from 'classnames';

import { ClassnamesFunction } from 'types/helpers';

import './styles.scss';

export type StatusBarState = 'neutral' | 'warning' | 'error';

interface Props {
  state?: StatusBarState;
}

const getClass: ClassnamesFunction<Props> = ({ state }) =>
  classNames('status-bar', {
    [`status-bar--${state}`]: state !== 'neutral',
  });

const StatusBar: React.FC<Props> = ({ children, state = 'neutral' }) => {
  if (!children) {
    return null;
  }

  return (
    <div className={getClass({ state })}>
      <p className="status-bar__content">{children}</p>
    </div>
  );
};

export default StatusBar;
