import React from 'react';
import classNames from 'classnames';

import { ClassnamesFunction } from 'types/helpers';

import './styles.scss';

interface Props {
  className?: string;
  narrow?: boolean;
  isLast?: boolean;
  noMarginTop?: boolean;
  children: React.ReactNode | React.ReactNode[];
}

const getClass: ClassnamesFunction<Props> = ({ className, narrow, isLast, noMarginTop }) =>
  classNames(
    'c-wrapper',
    {
      'c-wrapper--narrow': narrow,
      'c-wrapper--last': isLast,
      'c-wrapper--no-margin-top': noMarginTop,
    },
    className,
  );

const Wrapper: React.FC<Props> = ({
  className,
  children,
  narrow,
  isLast,
  noMarginTop,
  ...others
}) => (
  <div className={getClass({ className, narrow, isLast, noMarginTop })} {...others}>
    {children}
  </div>
);

export default Wrapper;
