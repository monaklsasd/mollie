import React, { Children } from 'react';
import classNames from 'classnames';

import { ClassnamesFunction } from 'types/helpers';

import './styles.scss';

interface Props {
  hasBorders?: boolean;
}

const getClass: ClassnamesFunction<Props> = ({ hasBorders }) =>
  classNames('c-list', {
    'c-list--has-borders': hasBorders,
  });

/*
 * Usage:
 *
 * <List>
 *   <MyComponent />
 *   <MyComponent />
 * </List>
 */
const List: React.FC<Props> = ({ children, ...rest }) => (
  <ul className={getClass(rest)}>
    {Children.map(children, child => (
      <li className="c-list__item">{child}</li>
    ))}
  </ul>
);

export default List;
