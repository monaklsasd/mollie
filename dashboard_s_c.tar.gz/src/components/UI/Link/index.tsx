import React from 'react';
import classNames from 'classnames';
import { Link as RouterLink } from 'react-router-dom';

// Styles
import './styles.scss';

// Types
import { ClassnamesFunction } from 'types/helpers';

const getClass: ClassnamesFunction<Props> = ({
  className,
  fullWidth,
  noUnderline,
  linkStyle,
  disabled,
}) =>
  classNames(
    'c-link',
    {
      'c-link--disabled': disabled,
      'c-link--full-width': fullWidth,
      'c-link--no-underline': noUnderline,
      [`c-link--style-${linkStyle}`]: linkStyle,
    },
    className,
  );

interface Props extends React.AnchorHTMLAttributes<any> {
  className?: string;
  linkStyle?: 'blue' | 'danger';
  rel?: string;
  disabled?: boolean;
  href?: string;
  to?: React.ComponentProps<typeof RouterLink>['to'];
  type?: 'submit' | 'button';
  fullWidth?: boolean;
  noUnderline?: boolean;
}

const Link: React.FC<Props> = ({
  children,
  className,
  disabled = false,
  fullWidth,
  href,
  to,
  type,
  noUnderline,
  linkStyle,
  rel,
  ...other
}) => {
  // make Route Link
  if (to) {
    return disabled ? (
      // For accessibility reasons, the "to" is required to make sure the rendered anchor tag has an href attribute.
      // The preventDefault in the onClick prop prevents the link from being clicked, making it inactive.
      <RouterLink
        to={to}
        onClick={(e): void => e.preventDefault()}
        aria-disabled
        className={getClass({ className, fullWidth, disabled, noUnderline, linkStyle })}>
        {children}
      </RouterLink>
    ) : (
      <RouterLink
        to={to}
        className={getClass({ className, fullWidth, disabled, noUnderline, linkStyle })}
        {...other}>
        {children}
      </RouterLink>
    );
  }

  // If it has prop Href make a link
  if (href) {
    return (
      <a
        className={getClass({ className, fullWidth, disabled, noUnderline, linkStyle })}
        rel={rel}
        {...(!disabled ? { href } : { 'aria-disabled': true })}
        {...other}>
        {children}
      </a>
    );
  }

  return (
    <button
      type={type}
      disabled={disabled}
      className={getClass({ className, fullWidth, disabled, noUnderline, linkStyle })}
      {...other}>
      {children}
    </button>
  );
};

Link.defaultProps = {
  type: 'button',
  rel: 'noopener',
};

export default Link;
