import React from 'react';
import classNames from 'classnames';

import { ClassnamesFunction } from 'types/helpers';

import './styles.scss';

interface Props {
  compact?: boolean;
  className?: string;
  hasSeparator?: boolean;
  flipped?: boolean;
  fullWidthMobile?: boolean;
}

const getClass: ClassnamesFunction<Props> = ({
  fullWidthMobile,
  compact,
  hasSeparator,
  className,
  flipped,
}) =>
  classNames(
    'c-button-group',
    {
      'c-button-group--with-separator': hasSeparator,
      'c-button-group--compact': compact,
      'c-button-group--flipped': flipped,
      'c-button-group--full-width-mobile': fullWidthMobile,
    },
    className,
  );

const ButtonGroup: React.FC<Props> = ({
  compact,
  fullWidthMobile,
  hasSeparator,
  className,
  children,
  flipped,
}) => (
  <ul
    className={getClass({
      fullWidthMobile,
      compact,
      hasSeparator,
      className,
      flipped,
    })}>
    {React.Children.map(children, child => {
      if (!child) {
        return null;
      }

      return <li className="c-button-group__button-wrapper">{child}</li>;
    })}
  </ul>
);

export default ButtonGroup;
