import Tippy, { TippyProps } from '@tippy.js/react';
import React from 'react';
import classNames from 'classnames';
import { ClassnamesFunction } from 'types/helpers';
import './styles.scss';

const getClass: ClassnamesFunction<Props> = ({ className, noPadding }) =>
  classNames(
    {
      'no-padding': noPadding,
    },
    className,
  );

const getContainerClass: ClassnamesFunction<Props> = ({ containerClassName }) =>
  classNames('c-tooltip-container', containerClassName);

type Props = Omit<TippyProps, 'children'> & {
  className?: string;
  containerClassName?: string;
  content: React.ComponentProps<typeof Tippy>['content'];
  showOnHover?: boolean;
  noPadding?: boolean;
  width?: number;
  placement?: React.ComponentProps<typeof Tippy>['placement'];
};

class Tooltip extends React.Component<Props> {
  static defaultProps = {
    showOnHover: true,
    noPadding: false,
    className: '',
    containerClassName: '',
    width: 350,
    placement: 'bottom',
  };

  instance: any = null;

  render(): React.ReactElement {
    const {
      children,
      content,
      showOnHover,
      noPadding,
      className,
      containerClassName,
      width,
      placement,
      ...rest
    } = this.props;
    return (
      <Tippy
        trigger={showOnHover ? 'mouseenter' : 'click'}
        arrow
        animation="shift-toward"
        onCreate={(instance): void => {
          this.instance = instance;
        }}
        placement={placement}
        theme="light"
        interactive
        duration={100}
        popperOptions={{
          positionFixed: true,
        }}
        className={getClass({ className, noPadding })}
        maxWidth={width}
        content={content}
        {...rest}>
        <span role="button" className={getContainerClass({ containerClassName })}>
          {children}
        </span>
      </Tippy>
    );
  }
}

export default Tooltip;
