import React from 'react';
import { FormattedMessage } from 'react-intl';

import Link from 'components/UI/Link';

import './styles.scss';

interface Props {
  onDisable: React.ComponentProps<typeof Link>['onClick'];
}

const TestmodeNotice: React.FC<Props> = ({ onDisable }) => (
  <div className="c-test-mode-notice">
    <FormattedMessage id="test-mode-notice-enabled" defaultMessage="Test mode is enabled." />
    &nbsp;
    <Link onClick={onDisable}>
      <FormattedMessage id="test-mode-notice-disable" defaultMessage="Disable" />
    </Link>
  </div>
);

export default TestmodeNotice;
