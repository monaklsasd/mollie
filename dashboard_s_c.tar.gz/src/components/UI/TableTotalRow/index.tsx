import React from 'react';

import './styles.scss';

interface Props {
  value: React.ReactNode;
  label: React.ReactNode;
}

const TableTotalRow: React.FC<Props> = ({ value, label }: Props) => (
  <div className="c-table-total-row">
    {label}: <strong className="c-table-total-row__value">{value}</strong>
  </div>
);

export default TableTotalRow;
