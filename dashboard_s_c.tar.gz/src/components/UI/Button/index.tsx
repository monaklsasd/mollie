import React from 'react';
import classNames from 'classnames';
import { Link } from 'react-router-dom';
import Spinner from 'components/UI/Spinner';

// Types
import { Location } from 'history';

import './styles.scss';

interface Props {
  size?: 'regular' | 'large';
  className?: string;
  rel?: string;
  disabled?: boolean;
  fullWidth?: boolean;
  href?: string;
  to?: string | Location;
  type?: React.ButtonHTMLAttributes<any>['type'];
  primary?: boolean;
  isLoading?: boolean;
  onClick?: (event: React.MouseEvent<any>) => void;
  target?: string;
  // For all the other props
  [x: string]: any;
}

const getClass = ({
  className,
  isLoading,
  primary,
  size,
  fullWidth,
  disabled,
}: Partial<Props>): string =>
  classNames(
    'c-button',
    {
      'is-loading': isLoading,
      'c-button--disabled': disabled,
      'c-button--primary': primary,
      'c-button--full-width': fullWidth,
      [`c-button--${size}`]: size,
    },
    className,
  );

/**
 * If it looks like a button, works like a button, smells like a button it could be a Link, a tag
 * or a link
 */
class Button extends React.Component<Props> {
  static defaultProps = {
    size: 'regular',
    type: 'submit',
    rel: 'noopener',
  };

  renderContent(): JSX.Element {
    const { isLoading, children } = this.props;

    return (
      <React.Fragment>
        {isLoading && <Spinner aria-hidden backdrop={false} delay={0} />}
        <span className="c-button__children">{children}</span>
      </React.Fragment>
    );
  }

  render(): JSX.Element {
    const { disabled, href, to, type, rel, isLoading, ...other } = this.props;
    // make Route Link
    if (to) {
      return disabled || isLoading ? (
        <Link
          to={to}
          onClick={(e): void => e.preventDefault()}
          aria-disabled
          className={getClass(this.props)}>
          {this.renderContent()}
        </Link>
      ) : (
        <Link to={to} {...other} className={getClass(this.props)}>
          {this.renderContent()}
        </Link>
      );
    }

    // If it has prop Href make a link
    if (href) {
      return (
        <a
          {...other}
          className={getClass(this.props)}
          rel={rel}
          {...(disabled || isLoading ? { 'aria-disabled': true } : { href })}>
          {this.renderContent()}
        </a>
      );
    }

    return (
      <button
        type={type}
        disabled={disabled || isLoading}
        {...other}
        className={getClass(this.props)}>
        {this.renderContent()}
      </button>
    );
  }
}

export default Button;
