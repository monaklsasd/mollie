import React from 'react';
import classNames from 'classnames';

import './styles.scss';

interface Props {
  footer?: React.ReactNode;
}

const Accordion: React.FC<Props> = ({ children, footer }) => (
  <div className="accordion">
    <div className="accordion__items">
      {children &&
        (children as React.ReactElement[]).map(child =>
          React.cloneElement(child, {
            ...child.props,
            className: classNames('accordion__item', child.props.className),
          }),
        )}
    </div>
    {footer && <div className="accordion__footer">{footer}</div>}
  </div>
);

export default Accordion;
