import React from 'react';
import classNames from 'classnames';

import Link from 'components/UI/Link';
import { ReactComponent as AccordionArrow } from 'assets/icons/accordion-arrow.svg';

import { ClassnamesFunction } from 'types/helpers';

import './styles.scss';

interface Props {
  className?: string;
  toggleLabel: Function;
  noBorder: boolean;
  heading: React.ReactNode;
  actions: React.ReactNode;
  isOpen?: boolean;
  disabled?: boolean;
}

interface State {
  isOpen: boolean;
}

const getClass: ClassnamesFunction<Props> = ({ className, noBorder }) =>
  classNames(className, 'collapse', {
    [`collapse--no-border`]: noBorder,
  });

class Collapse extends React.Component<Props, State> {
  state = {
    isOpen: this.props.isOpen || false,
  };

  toggleContent = (): void => {
    this.setState({
      isOpen: !this.state.isOpen,
    });
  };

  render(): JSX.Element {
    const { heading, disabled, actions, className, children, toggleLabel, noBorder } = this.props;

    return (
      <div className={getClass({ className, noBorder })}>
        <div className="collapse__heading">
          <div className="collapse__heading-title">{heading}</div>
          <div className="collapse__header-label">
            <Link
              noUnderline
              onClick={this.toggleContent}
              linkStyle="blue"
              disabled={disabled}
              className="collapse__header-toggle-button">
              {toggleLabel(this.state)}
              <AccordionArrow
                className={classNames('collapse__icon', {
                  [`collapse__icon--opened`]: this.state.isOpen,
                })}
              />
            </Link>
            {actions}
          </div>
        </div>
        <div
          className={classNames('collapse__inner', {
            [`collapse__inner--opened`]: this.state.isOpen,
          })}>
          {children}
        </div>
      </div>
    );
  }
}

export default Collapse;
