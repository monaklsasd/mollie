import * as React from 'react';
import {
  FormattedMessage,
  FormattedHTMLMessage,
  defineMessages,
  MessageDescriptor,
} from 'react-intl';
import classNames from 'classnames';

// Utils
import FORMATS_ARRAY from 'helpers/documentFormats';

// Components
import Table from 'components/UI/Table';
import TableRow from 'components/UI/TableRow';
import Tooltip from 'components/UI/Tooltip';
import FileIcon from 'components/UI/FileIcon';

import './styles.scss';

// Types
import { FormatType } from 'helpers/documentFormats';
import { IntlMessages } from 'types/intl';

const messages: IntlMessages = defineMessages({
  formButtonDownload: {
    id: 'export-btn-download-as-format',
    defaultMessage: 'Download as {format}',
  },
});

interface Props {
  onDownload: (...args: any[]) => void;
  explanation: MessageDescriptor;
  explanationValues?: Record<string, any>;
  formats: FormatType[];
  hasError: boolean;
  onShow?: (...args: any[]) => void;
  onHide?: (...args: any[]) => void;
}

class Export extends React.Component<Props> {
  static defaultProps = {
    formats: FORMATS_ARRAY,
    hasError: false,
  };

  tooltipRef: Nullable<Tooltip> = null;

  handleClick = (format: FormatType) => (): void => {
    this.props.onDownload(format);

    if (this.tooltipRef && this.tooltipRef.instance) {
      // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
      // @ts-ignore
      this.tooltipRef.instance.hide();
    }
  };

  handleOnHide = (): void => {
    const { onHide } = this.props;

    if (onHide) {
      onHide();
    }
  };

  handleOnShow = (): void => {
    const { onShow } = this.props;

    if (onShow) {
      onShow();
    }
  };

  render(): React.ReactNode {
    const { formats, children, explanation, explanationValues, hasError } = this.props;

    const descriptionClassName = classNames('c-export__description', {
      'u-color-error': hasError,
      'u-bold': hasError,
    });

    return (
      <Tooltip
        maxWidth={350}
        showOnHover={false}
        ref={(c): void => {
          this.tooltipRef = c;
        }}
        noPadding
        onShow={this.handleOnShow}
        onHide={this.handleOnHide}
        content={
          <div className="c-export">
            <div className="c-export__contents">
              <p className={descriptionClassName}>
                <FormattedHTMLMessage {...explanation} values={explanationValues} />
              </p>
              <Table className="c-export__table" rowClassName="c-export__table-row">
                {formats.map(format => (
                  <TableRow
                    key={format}
                    values={[
                      <FormattedMessage
                        {...messages.formButtonDownload}
                        values={{ format: format.toUpperCase() }}
                      />,
                      <FileIcon fileType={format}>{format.toUpperCase()}</FileIcon>,
                    ]}
                    disabled={hasError}
                    onClick={this.handleClick(format)}
                  />
                ))}
              </Table>
            </div>
          </div>
        }>
        <React.Fragment>{children}</React.Fragment>
      </Tooltip>
    );
  }
}

export default Export;
