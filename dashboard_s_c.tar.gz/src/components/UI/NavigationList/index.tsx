import React from 'react';
import classNames from 'classnames';

import Checkbox from 'components/forms/Checkbox';

import { ClassnamesFunction } from 'types/helpers';

import './styles.scss';
import { Method } from 'components/Profile/PaymentMethod/utils';

const getClass: ClassnamesFunction<NavigationItem> = ({ hasResults }) =>
  classNames('c-navigation-list--item', {
    'has-results': hasResults,
  });

interface NavigationItem {
  key: Method['id'];
  label: React.ReactNode;
  isActive?: boolean;
  hasResults?: boolean;
}

interface Props {
  onChange: (...args: any[]) => React.ChangeEventHandler;
  items: NavigationItem[];
}

const NavigationList: React.FC<Props> = ({ items, onChange }) => (
  <ul className="c-navigation-list">
    {items.map(({ key, isActive, label, hasResults }) => (
      <li key={key} className={getClass({ hasResults })}>
        <Checkbox name={key} label={label} id={key} value={isActive} onChange={onChange(key)} />
      </li>
    ))}
  </ul>
);

export default NavigationList;
