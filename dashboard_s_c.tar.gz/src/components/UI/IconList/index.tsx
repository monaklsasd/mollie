import React from 'react';
import Heading from 'components/UI/Heading';
import { ReactComponent as CheckIcon } from 'assets/icons/check.svg';
import './styles.scss';

interface Props {
  children: (...args: any[]) => React.ReactNode;
  className?: string;
  heading?: React.ReactNode;
}

interface ItemProps {
  icon: React.ReactElement;
}

const Item: React.FC<ItemProps> = ({ icon, children }) => (
  <li>
    {icon || <CheckIcon />} {children}
  </li>
);

const Iconlist: React.FC<Props> = ({ children, className, heading }: Props) => (
  <div className={className}>
    {heading && (
      <Heading className="iconlist__heading" type="h3" as="h2">
        {heading}
      </Heading>
    )}
    <ul className="iconlist__list">{children(Item)}</ul>
  </div>
);

export default Iconlist;
