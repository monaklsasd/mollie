import React from 'react';
import { FormattedMessage } from 'react-intl';
import classNames from 'classnames';

import ModalNoUI from 'components/UI/ModalNoUI';
import Spinner from 'components/UI/Spinner';
import Heading from 'components/UI/Heading';

import { ClassnamesFunction } from 'types/helpers';

import './styles.scss';

const getClass: ClassnamesFunction<Props> = ({ wide }) =>
  classNames('c-modal', {
    'c-modal--wide': wide,
  });

type ModalNoUIProps = React.ComponentProps<typeof ModalNoUI>;

type Props = ModalNoUIProps & {
  isOpen: boolean;
  onRequestClose: (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
  heading?: React.ReactNode;
  confirmLabel?: React.ReactNode;
  closeLabel?: React.ReactNode;
  handleConfirm?: (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
  wide?: boolean;
  disableConfirm?: boolean;
  confirmIsLoading?: boolean;
  disableCloseButton?: boolean;
};

const Modal: React.FC<Props> = ({
  isOpen,
  onRequestClose,
  heading,
  confirmLabel,
  closeLabel,
  handleConfirm,
  disableConfirm,
  confirmIsLoading,
  disableCloseButton,
  children,
  wide,
  ...otherProps
}) => (
  <ModalNoUI isOpen={isOpen} onRequestClose={onRequestClose} {...otherProps}>
    <div className={getClass({ wide })}>
      <div className="c-modal__content">
        {heading && (
          <Heading type="h3" as="h2" className="c-modal__heading">
            {heading}
          </Heading>
        )}
        {children}
      </div>
      <div className="c-modal__actions">
        <button
          type="button"
          onClick={onRequestClose}
          className="c-modal__action"
          disabled={disableCloseButton}>
          {closeLabel}
        </button>
        {handleConfirm && (
          <button
            type="button"
            onClick={handleConfirm}
            className="c-modal__action c-modal__confirm"
            disabled={disableConfirm}>
            {confirmIsLoading && <Spinner delay={0} />}
            {!confirmIsLoading && confirmLabel}
          </button>
        )}
      </div>
    </div>
  </ModalNoUI>
);

Modal.defaultProps = {
  closeLabel: <FormattedMessage id="modal-close-label" defaultMessage="Close" />,
};

export default Modal;
