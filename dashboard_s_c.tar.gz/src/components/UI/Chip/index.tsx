import React from 'react';
import classNames from 'classnames';

import './styles.scss';

interface Props {
  className?: string;
}

const Chip: React.FC<Props> = ({ className, children }) => (
  <span role="status" className={classNames('chip', className)}>
    {children}
  </span>
);

export default Chip;
