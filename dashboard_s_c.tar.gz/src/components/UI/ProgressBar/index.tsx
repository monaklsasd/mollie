import React from 'react';
import classNames from 'classnames';

import { ClassnamesFunction } from 'types/helpers';

import './styles.scss';

const getClass: ClassnamesFunction<Props> = ({ progress = 4, total = 4, className }) =>
  classNames(
    'c-progress-bar',
    {
      [`c-progress-bar--progress-${(progress / total) * 100}`]: progress,
    },
    className,
  );

interface Props {
  className?: string;
  progress: number;
  total: number;
}

const ProgressBar: React.FC<Props> = ({ progress = 0, total = 4, className }) => {
  return (
    <div className={getClass({ progress, total, className })}>
      <div
        className="c-progress-bar__indicator"
        style={{ width: `${(progress / total) * 100}%` }}
      />
    </div>
  );
};

export default ProgressBar;
