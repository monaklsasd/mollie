import React from 'react';
import classNames from 'classnames';

import Heading from 'components/UI/Heading';
import TableRow from 'components/UI/TableRow';
import TableTotalRow from 'components/UI/TableTotalRow';

import './styles.scss';

interface Props {
  heading?: React.ReactNode;
  description?: React.ReactNode;
  className?: string;
  rowClassName: string;
  columnHeadings?: Nullable<React.ReactNode[]>;
  totalLabel?: React.ReactNode;
  totalValue?: React.ReactNode;
}

const Table: React.FC<Props> = ({
  heading,
  className,
  rowClassName,
  columnHeadings,
  totalLabel,
  totalValue,
  children,
  description,
}) => (
  <div className={classNames(className, 'c-table')}>
    {heading && <Heading>{heading}</Heading>}
    {description && <p className="c-table__description">{description}</p>}
    {columnHeadings && <TableRow className={rowClassName} values={columnHeadings} isHeading />}
    {React.Children.map(
      children,
      child =>
        child &&
        React.cloneElement(child as React.ReactElement, {
          className: rowClassName,
        }),
    )}
    {totalLabel && totalValue && <TableTotalRow label={totalLabel} value={totalValue} />}
  </div>
);

export default Table;
