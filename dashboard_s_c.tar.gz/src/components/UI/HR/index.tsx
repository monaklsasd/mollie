import React from 'react';

import './styles.scss';

const HR: React.FC = () => {
  return <div className="ui-hr__container" />;
};

export default HR;
