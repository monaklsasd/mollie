import { defineMessages } from 'react-intl';
import { IntlMessages } from 'types/intl';

const messages: IntlMessages = defineMessages({
  toggleNavigation: {
    id: 'header-bar-toggle-navigation-label',
    defaultMessage: 'Toggle navigation',
    description: 'Aria label for menu toggle, only visible for screenreaders.',
  },
});

export default messages;
