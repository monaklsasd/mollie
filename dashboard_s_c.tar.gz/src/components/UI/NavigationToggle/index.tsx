import React from 'react';
import classNames from 'classnames';
import { injectIntl, IntlShape } from 'react-intl';

// Components
import Button from 'components/UI/Button';

// Internals
import { SIDEBAR_ID } from 'containers/Sidebar/constants';
import messages from './messages';

// Types
import { ClassnamesFunction } from 'types/helpers';

// Stylesheets
import './styles.scss';

interface Props {
  className?: string;
  intl: IntlShape;
  onClick: React.ComponentProps<typeof Button>['onClick'];
  sidebarIsOpen: boolean;
}

const getClass: ClassnamesFunction<Props> = ({ className }) =>
  classNames('c-navigation-toggle', className);

const NavigationToggle: React.FC<Props> = ({ sidebarIsOpen, className, onClick, intl }) => (
  <Button
    onClick={onClick}
    className={getClass({ className })}
    aria-controls={SIDEBAR_ID}
    aria-expanded={sidebarIsOpen}
    type="button"
    aria-label={intl.formatMessage(messages.toggleNavigation)}>
    <span className="c-navigation-toggle__line" />
    <span className="c-navigation-toggle__line" />
    <span className="c-navigation-toggle__line" />
    <span className="c-navigation-toggle__line" />
  </Button>
);

export default injectIntl(NavigationToggle);
