import React from 'react';
import ReactModal from 'react-modal';
import classNames from 'classnames';

import { ClassnamesFunction } from 'types/helpers';

import './styles.scss';

const getClass: ClassnamesFunction<Props> = ({ isTopModal }) =>
  classNames('c-modal-no-ui', {
    'is-top-modal': isTopModal,
  });

type ReactModelProps = React.ComponentProps<typeof ReactModal>;
interface Props extends ReactModal.Props {
  isTopModal?: boolean;
}

class ModalNoUI extends React.Component<Props> {
  appElement = document.querySelector('#root') as HTMLElement;

  render(): React.ReactNode {
    const { children, isTopModal, isOpen, ...otherProps } = this.props;

    return (
      <ReactModal
        className="c-modal-no-ui__content"
        overlayClassName={getClass({ isTopModal })}
        appElement={this.appElement}
        closeTimeoutMS={150}
        isOpen={isOpen}
        {...otherProps}>
        {children}
      </ReactModal>
    );
  }
}

export default ModalNoUI;
