import React from 'react';
import classNames from 'classnames';

import { ClassnamesFunction } from 'types/helpers';

import './styles.scss';

interface Props {
  className?: string;
  fileType?: string;
}

const getClass: ClassnamesFunction<Props> = ({ fileType, className }) =>
  classNames(
    'c-file-icon',
    {
      [`c-file-icon--${fileType}`]: fileType,
    },
    className,
  );

const FileIcon: React.FC<Props> = ({ fileType, className, children }) => (
  <span className={getClass({ fileType, className })}>{children}</span>
);

export default FileIcon;
