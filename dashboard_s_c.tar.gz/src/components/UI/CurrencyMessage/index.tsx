import * as React from 'react';
import { useIntl, IntlShape } from 'react-intl';
import uppercaseFirstLetter from 'utils/uppercaseFirstLetter';
import './styles.scss';

interface Props {
  currency: string;
}

const getCurrencyName = (
  intl: IntlShape,
  currency: string,
  currencyDisplay: 'name' | 'symbol' = 'symbol',
): string =>
  intl
    .formatNumber(0, {
      currencyDisplay,
      currency,
      style: 'currency',
      // make sure there won't be any fraction digits
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    })
    .replace('0', '')
    .trim();

const CurrencyMessage = ({ currency }: Props): React.ReactElement => {
  const intl = useIntl();

  return (
    <span className="c-currency-message">
      {uppercaseFirstLetter(getCurrencyName(intl, currency, 'name'))}{' '}
      <b>({getCurrencyName(intl, currency)})</b>
    </span>
  );
};

export default CurrencyMessage;
