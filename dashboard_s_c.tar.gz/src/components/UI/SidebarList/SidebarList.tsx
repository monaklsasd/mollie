import React from 'react';

// Import components
import Heading from 'components/UI/Heading';

interface Props {
  title: React.ReactNode;
  subtitle?: React.ReactNode;
  children?: React.ReactNode;
}

const SidebarList: React.FC<Props> = ({ title, subtitle, children, ...otherProps }) => (
  <div className="c-sidebar-list" {...otherProps}>
    <header className="c-sidebar-list__header">
      <Heading type="h2" className="c-sidebar-list__title">
        {title}
      </Heading>
      {subtitle && <span className="c-sidebar-list__subtitle">{subtitle}</span>}
    </header>
    <div className="c-sidebar-list__content">{children}</div>
  </div>
);

export default SidebarList;
