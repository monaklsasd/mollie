import React from 'react';
import classNames from 'classnames';

// Types
import { ClassnamesFunction } from 'types/helpers';

// Styles
import './styles.scss';

const getClass: ClassnamesFunction<Props> = ({ withMargin }) =>
  classNames('c-sidebar-term-wrapper', {
    'c-sidebar-term-wrapper-with-margin': withMargin,
  });

interface Props {
  withMargin?: boolean;
}

const SidebarList: React.FC<Props> = ({ children, withMargin = false, ...otherProps }) => (
  <div className={getClass({ withMargin })} {...otherProps}>
    {children}
  </div>
);

export default SidebarList;
