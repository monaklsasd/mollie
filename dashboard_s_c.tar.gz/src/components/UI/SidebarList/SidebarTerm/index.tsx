import React from 'react';
import classNames from 'classnames';
import { defineMessages, useIntl } from 'react-intl';
import HelpTooltip from 'components/UI/HelpTooltip';
import Currency from 'components/UI/Currency';
import { IntlMessages } from 'types/intl';
import { ClassnamesFunction } from 'types/helpers';
import './styles.scss';
import { Amount } from 'reduxState/types';

const messages: IntlMessages = defineMessages({
  tooltipAriaLabel: {
    id: 'sidebar-term-help-label',
    defaultMessage: 'Additional info',
  },
});

const getClass: ClassnamesFunction<Props> = ({ isFooter }) =>
  classNames('c-sidebar-term__row', {
    'c-sidebar-term__row-footer': isFooter,
  });

const getDTClass: ClassnamesFunction<Props & { hasCurrency: boolean }> = ({
  hasCurrency,
  isFooter,
}) =>
  classNames('c-sidebar-term__cell', {
    'c-sidebar-term__cell-currency': hasCurrency,
    'c-sidebar-term__cell-footer': isFooter,
  });

const getDDClass: ClassnamesFunction<Props> = ({ isFooter, className }) =>
  classNames(className, 'c-sidebar-term__cell', 'c-sidebar-term__cell-value', {
    'c-sidebar-term__cell-footer-value': isFooter,
  });

interface Props {
  label: React.ReactNode;
  className?: string;
  currency?: Amount['currency'];
  value: React.ReactNode;
  additionalInfo?: React.ReactElement;
  isFooter?: boolean;
}

const hasCurrency = (currency: Props['currency']): boolean => typeof currency === 'string';

const SidebarTerm: React.FC<Props> = ({
  label,
  currency,
  value,
  className,
  additionalInfo,
  isFooter,
}) => {
  const resultValue = hasCurrency(currency) ? (
    <Currency value={Number(value)} currency={currency} />
  ) : (
    value
  );

  const intl = useIntl();

  return (
    <dl className={getClass({ isFooter })}>
      <dt className={getDTClass({ hasCurrency: hasCurrency(currency), isFooter })}>
        <span className="c-sidebar-term__cell-label">{label}:</span>
        {additionalInfo && (
          <HelpTooltip
            showOnHover={false}
            ariaLabel={intl.formatMessage(messages.tooltipAriaLabel)}
            content={additionalInfo}
          />
        )}
      </dt>
      <dd className={getDDClass({ isFooter, className })}>{resultValue}</dd>
    </dl>
  );
};

SidebarTerm.defaultProps = {
  isFooter: false,
};

export default SidebarTerm;
