import React from 'react';
import classNames from 'classnames';

import { ClassnamesFunction } from 'types/helpers';

import './styles.scss';

const getClass: ClassnamesFunction<Props> = ({ className, alignRight }) =>
  classNames(
    'c-tab-group-outer',
    {
      'c-tab-group-right': alignRight,
    },
    className,
  );

interface Props {
  children?: React.ReactNode;
  className?: string;
  alignRight?: boolean;
}

const TabGroup: React.FC<Props> = ({ children, className, alignRight }) => (
  <div className={getClass({ className, alignRight })}>
    <div className="c-tab-group">{children}</div>
  </div>
);

export default TabGroup;
