import React from 'react';
import './styles.scss';

const InformationBox: React.FC = ({ children }) => (
  <div className="information-box">{children}</div>
);

export default InformationBox;
