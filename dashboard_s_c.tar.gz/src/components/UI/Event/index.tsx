import React from 'react';
import classNames from 'classnames';

import './styles.scss';

interface Props {
  className?: string;
  status?: React.ReactNode;
  statusClassName?: string;
  description: React.ReactNode;
  date: React.ReactNode;
}

const Event: React.FC<Props> = ({
  className,
  children,
  statusClassName,
  status,
  description,
  date,
  ...rest
}) => (
  <li className={classNames('event', className)} {...rest}>
    {children}
    <div className={classNames('event__status', statusClassName)}>{status}</div>
    <div className="event__description">{description}</div>
    <div className="event__date">{date}</div>
  </li>
);

export default Event;
