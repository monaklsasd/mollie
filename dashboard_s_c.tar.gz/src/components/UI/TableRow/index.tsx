import React from 'react';
import classNames from 'classnames';
import { Link } from 'react-router-dom';

import UILink from 'components/UI/Link';

import { ClassnamesFunction } from 'types/helpers';

import './styles.scss';

const getClass: ClassnamesFunction<Props<{}> & { hasFocus: boolean }> = ({
  className,
  disabled,
  isHeading,
  isSummary,
  hasFocus,
  isHighlighted,
}) =>
  classNames('c-table-row', className, {
    'c-table-row--disabled': disabled,
    'c-table-row--heading': isHeading,
    'c-table-row--summary': isSummary,
    'c-table-row--highlight': isHighlighted,
    'has-focus': hasFocus,
  });

const getItemClass: ClassnamesFunction<Props<{}> & { index: number }> = ({
  onTopOfLink,
  className,
  index,
}) =>
  classNames(
    'c-table-row__item',
    {
      'is-on-top-of-link': onTopOfLink && onTopOfLink(index),
    },
    // To support multiple classnames as a prop we split the string and append  __item to each and every class name
    className && className.split(' ').map(singleClassName => `${singleClassName}__item`),
  );

interface Props<T> {
  className?: string;
  values: T[];
  onClick?: Function;
  disabled?: boolean;
  isHighlighted?: boolean;
  isSummary?: boolean;
  onTopOfLink?: Function;
  isHeading?: boolean;
  linkCallback?: Function;
  link?: string | Record<string, any>;
  linkLabel?: React.ReactNode;
  externalLink?: string;
}

type State = {
  hasFocus: boolean;
};

class TableRow<T = {}> extends React.Component<Props<T>, State> {
  state = {
    hasFocus: false,
  };

  handleToggleFocus = (): void => {
    this.setState({ hasFocus: !this.state.hasFocus });
  };

  onClick = (): void => {
    const { linkCallback } = this.props;

    if (linkCallback) {
      linkCallback();
    }
  };

  getLinkProps(): { [key: string]: any } {
    if (this.props.externalLink) {
      return {
        link: null,
        externalLink: this.props.externalLink,
        linkLabel: this.props.linkLabel,
      };
    }

    if (this.props.link) {
      return {
        link: this.props.link,
        externalLink: undefined,
        linkLabel: this.props.linkLabel,
      };
    }

    return {};
  }

  render(): React.ReactNode {
    const {
      values,
      onClick,
      disabled,
      isHighlighted,
      isHeading,
      isSummary,
      onTopOfLink,
      className,
    } = this.props;

    const { link, externalLink, linkLabel } = this.getLinkProps();

    return (
      <div
        className={getClass({
          isSummary,
          isHeading,
          disabled,
          isHighlighted,
          className,
          hasFocus: this.state.hasFocus,
        })}>
        <ul>
          {values.map((value, index) => (
            <li
              className={getItemClass({ onTopOfLink, className, index })}
              key={`table-row-${index}`}>
              {value}
            </li>
          ))}
        </ul>
        {link && linkLabel && (
          <Link
            className="c-table-row__link"
            to={link}
            onClick={this.onClick}
            onFocus={this.handleToggleFocus}
            onBlur={this.handleToggleFocus}>
            {linkLabel}
          </Link>
        )}
        {externalLink && linkLabel && (
          <a
            className="c-table-row__link"
            rel="noopener"
            target="_blank" // eslint-disable-line react/jsx-no-target-blank
            href={externalLink}
            onClick={this.onClick}
            onFocus={this.handleToggleFocus}
            onBlur={this.handleToggleFocus}>
            {linkLabel}
          </a>
        )}
        {onClick && (
          <UILink
            className="c-table-row__link"
            onFocus={this.handleToggleFocus}
            onBlur={this.handleToggleFocus}
            onClick={
              // eslint-disable-next-line @typescript-eslint/no-empty-function
              (disabled && ((): void => {})) ||
              ((): void => {
                onClick();
                this.onClick();
              })
            }
            disabled={disabled}
          />
        )}
      </div>
    );
  }
}

export default TableRow;
