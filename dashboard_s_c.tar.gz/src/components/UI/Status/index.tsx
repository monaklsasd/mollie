import * as React from 'react';
import classNames from 'classnames';

import { ClassnamesFunction } from 'types/helpers';

import './styles.scss';

export const STATUS_NEUTRAL = 'neutral';
export const STATUS_SUCCESS = 'success';
export const STATUS_PENDING = 'pending';
export const STATUS_ERROR = 'error';
export const STATUS_INFO = 'info';
export const STATUS_WARNING = 'warning';
export const STATUS_INDIFFERENT = 'indifferent';

const getClass: ClassnamesFunction<Props> = ({ state, noText, iconPlacement }) =>
  classNames('c-status', {
    [`c-status--${state}`]: state,
    'c-status--no-text': noText,
    'c-status--icon-placement-prepend': iconPlacement === 'prepend',
  });

export type States =
  | 'neutral'
  | 'success'
  | 'pending'
  | 'error'
  | 'info'
  | 'warning'
  | 'indifferent';

interface Props {
  message?: Nullable<React.ReactNode>;
  noText?: boolean;
  hideDefinition?: boolean;
  iconPlacement?: 'prepend' | 'append';
  state?: States;
}

const Status: React.FC<Props> = ({ message, ...otherProps }) => (
  <span role="status" className={getClass(otherProps)}>
    {message && <i>{message}</i>}
  </span>
);

Status.defaultProps = {
  state: STATUS_NEUTRAL,
  noText: false,
  iconPlacement: 'append',
};

export default Status;
