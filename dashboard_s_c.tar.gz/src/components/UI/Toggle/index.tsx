import React from 'react';
import classNames from 'classnames';

import { ClassnamesFunction } from 'types/helpers';

import './styles.scss';

const getClass: ClassnamesFunction<Props> = ({ status, className }) =>
  classNames(
    'c-toggle',
    {
      'is-pending': status === 'pending',
    },
    className,
  );

interface Props {
  status?: string;
  className?: string;
  name: string;
  value: number;
  id: string;
}

const Toggle: React.FC<Props> = ({ status, className, name, value, ...rest }) => (
  <label htmlFor={name} className={getClass({ status, className })}>
    <input
      type="checkbox"
      id={name}
      name={name}
      value={Number(!!value)}
      checked={!!value}
      {...rest}
    />
    <span className="c-toggle__handle" />
  </label>
);

export default Toggle;
