import React from 'react';
import { FormattedMessage } from 'react-intl';

import Button from 'components/UI/Button';

import { ReactComponent as IconFilterToggle } from 'assets/icons/filter-toggle.svg';
import { ReactComponent as IconClose } from 'assets/icons/close.svg';

import './styles.scss';
import { Location } from 'history';

interface Props {
  resetRoute?: string | Location;
  hasActiveFilters?: boolean;
  onClick: React.ComponentProps<typeof Button>['onClick'];
}

const FilterToggle: React.FC<Props> = ({ onClick, resetRoute, hasActiveFilters }) => {
  // Combi button for toggle and reset
  if (hasActiveFilters) {
    return (
      <div className="c-filter-toggle">
        <Button onClick={onClick} type="button">
          <IconFilterToggle width={12} height={9} />
          <FormattedMessage id="filters-list-filter-toggle" defaultMessage="Filters" />
        </Button>
        <Button to={resetRoute}>
          <IconClose />
        </Button>
      </div>
    );
  }

  return (
    <Button onClick={onClick} type="button">
      <IconFilterToggle width={12} height={9} />
      <FormattedMessage id="filters-list-filter-toggle" defaultMessage="Filters" />
    </Button>
  );
};

export default FilterToggle;
