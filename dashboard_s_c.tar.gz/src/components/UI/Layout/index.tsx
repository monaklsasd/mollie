import React from 'react';
import classNames from 'classnames';

import './styles.scss';

// Types
import { ClassnamesFunction } from 'types/helpers';

const getClass: ClassnamesFunction<Props> = ({ className, sidebar, hasFilters }) =>
  classNames('c-layout', className, {
    'c-layout--has-sidebar': sidebar,
    'c-layout--has-filters': hasFilters,
  });

interface Props {
  className?: string;
  sidebar?: React.ReactNode;
  hasFilters?: boolean;
}

const Layout: React.FC<Props> = ({ className, children, sidebar, hasFilters, ...others }) => {
  if (!sidebar) {
    return <section className={getClass({ className })}>{children}</section>;
  }
  return (
    <div className={getClass({ className, sidebar, hasFilters })} {...others}>
      <div className="c-layout--has-sidebar__sidebar">{sidebar}</div>
      <div className="c-layout--has-sidebar__main">{children}</div>
    </div>
  );
};

export default Layout;
