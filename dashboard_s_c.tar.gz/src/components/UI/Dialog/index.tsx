import * as React from 'react';
import { FormattedMessage } from 'react-intl';
import Heading from 'components/UI/Heading';

import Modal from 'components/UI/ModalNoUI';
import formMessages from 'messages/forms';

import './styles.scss';

/**
 * NOTE ON USAGE
 *
 * This component will not be displayed by default. To trigger the dialog, you need to
 * give it a ref attribute and call the show method like so:
 *
 * # Give it a ref attribute
 * <Dialog ref={d => { this.dialog = d; }} />
 *
 * # Trigger the dialog
 * this.dialog.show([CALLBACK_FUNCTION]);
 *
 * The callback function will be executed when the user confirms the dialog.
 *
 * If the user clicks cancel, the dialog will close but no additional methods will be
 * called. You can pass an onCancel method to <Dialog> which will be called in the
 * case that the user cancels the dialog.
 *
 * For more info see: https://facebook.github.io/react/docs/more-about-refs.html
 */
interface Props {
  heading: React.ReactNode;
  byline?: React.ReactNode;
  onCancel?: (...args: any[]) => void;
  confirmLabel?: React.ReactNode;
  cancelLabel: React.ReactNode;
}

interface State {
  isOpen: boolean;
}

class Dialog extends React.Component<Props, State> {
  static defaultProps = {
    cancelLabel: <FormattedMessage {...formMessages.formBtnCancel} />,
  };

  constructor(props) {
    super(props);
    this.onConfirm = null;
  }

  state = {
    isOpen: false,
  };

  componentWillMount(): void {
    this.setState({ isOpen: false });
  }

  onConfirm: Nullable<(...args: any[]) => void>;

  handleCancel = (): void => {
    this.setState({ isOpen: false });

    if (this.props.onCancel) {
      this.props.onCancel();
    }
  };

  handleConfirm = (): void => {
    this.setState({ isOpen: false });

    if (this.onConfirm) {
      this.onConfirm();
    }
  };

  show(onConfirm: (...args: any[]) => void): void {
    this.setState({ isOpen: true });

    this.onConfirm = onConfirm;
  }

  render(): Nullable<React.ReactElement> {
    const { heading, byline, confirmLabel, cancelLabel } = this.props;
    const { isOpen } = this.state;

    return (
      <Modal isOpen={isOpen} onRequestClose={this.handleCancel} closeTimeoutMS={150}>
        <div className="c-dialog">
          <div className="c-dialog__body">
            <Heading type="h2" className="c-dialog__heading">
              {heading}
            </Heading>
            <p>{byline}</p>
          </div>
          <div className="c-dialog__actions">
            <button onClick={this.handleCancel} className="c-dialog__action">
              {cancelLabel}
            </button>
            {confirmLabel && (
              <button onClick={this.handleConfirm} className="c-dialog__action">
                {confirmLabel}
              </button>
            )}
          </div>
        </div>
      </Modal>
    );
  }
}

export default Dialog;
