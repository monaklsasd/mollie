import React from 'react';

// Components
import Link from 'components/UI/Link';
import { ReactComponent as IconRightArrow } from 'assets/icons/arrow-right-fine.svg';

// Styles
import './styles.scss';

interface Props {
  label: React.ReactNode;
  onClick?: React.ComponentProps<typeof Link>['onClick'];
  href?: string;
}

const ArrowLink: React.FC<Props> = ({ label, onClick, href }: Props) => {
  return (
    <Link
      rel="noopener"
      target="_blank"
      href={href}
      className="c-arrow-link"
      linkStyle="blue"
      noUnderline
      onClick={onClick}>
      {label}&nbsp;
      <span className="c-arrow-link__icon-wrapper">
        <IconRightArrow className={'c-arrow-link__icon'} />
      </span>
    </Link>
  );
};

export default ArrowLink;
