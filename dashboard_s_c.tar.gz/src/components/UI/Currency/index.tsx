import React from 'react';
import { FormattedNumber } from 'react-intl';

import * as constants from './constants';
import formats from './formats';

// Types
import { Format } from './types';
import { Amount } from 'reduxState/types';

export const getFormat = (currency: Maybe<string>): Format => {
  if (currency) {
    return {
      ...constants.DEFAULT_CURRENCY_PROPERTIES,
      currency,
      ...formats[currency.toUpperCase()],
    };
  }

  return constants.DEFAULT_CURRENCY_PROPERTIES;
};

type Props = Omit<React.ComponentProps<typeof FormattedNumber>, 'value' | 'currency'> & Amount;

const Currency: React.FC<Props> = ({
  value,
  currency = constants.DEFAULT_CURRENCY_PROPERTIES.currency,
  ...intlNumberFormatProps
}) => (
  <FormattedNumber
    value={Number(value)}
    {...getFormat(currency || undefined)}
    {...intlNumberFormatProps}
  />
);

export default Currency;
