import { Format } from './types';

export const DEFAULT_CURRENCY_PROPERTIES: Format = {
  currency: 'EUR',
  style: 'currency',
  minimumFractionDigits: 2,
};
