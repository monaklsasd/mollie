import React from 'react';
import { shallow } from 'enzyme';
import createComponentWithIntl from 'helpers/createComponentWithIntl';

import Currency from '../index';
import { DEFAULT_CURRENCY_PROPERTIES } from '../constants';
import formats from '../formats';

describe('<Currency />', () => {
  it('should render with only amount prop', () => {
    const amountProp = 194.95;
    const defaultFormat = DEFAULT_CURRENCY_PROPERTIES;

    const renderedComponent = shallow(<Currency value={amountProp} />);
    const { value, ...others } = renderedComponent.props();

    expect(others.currency).toEqual(defaultFormat.currency);
    expect(value).toEqual(amountProp);
  });

  it('should render with big floats', () => {
    const amountProp = 194.950000000000233;

    const tree = createComponentWithIntl(<Currency value={amountProp} currency={'EUR'} />).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should render a amount with different currencies', () => {
    const amountProp = '194.95';
    // Random currencies and an empty one so it tests its fallback
    const currencies = ['EUR', 'USD', 'GBP', ''];

    currencies.forEach(currency => {
      const tree = createComponentWithIntl(
        <Currency value={Number(amountProp)} currency={currency} />,
      ).toJSON();
      expect(tree).toMatchSnapshot();
    });
  });

  it('all divergent currencies should be equal to their snapshot', () => {
    const amountProp = '194.95';

    Object.keys(formats).forEach(format => {
      const tree = createComponentWithIntl(
        <Currency value={Number(amountProp)} currency={format} />,
      ).toJSON();
      expect(tree).toMatchSnapshot();
    });
  });

  it('should render a maximum of 2 fraction digits by default', () => {
    const amountProp = 194.9578;

    const tree = createComponentWithIntl(<Currency value={amountProp} currency="EUR" />).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should render amounts with more than 10 fraction digits (useful when rendering VAT amounts)', () => {
    const amountProp = 194.9578293029;

    const tree = createComponentWithIntl(
      <Currency value={amountProp} currency="EUR" minimumFractionDigits={10} />,
    ).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should render a maximum of 2 fraction units when providing the amount as an integer', () => {
    const amountProp = 194;

    const tree = createComponentWithIntl(
      <Currency value={amountProp} currency="EUR" minimumFractionDigits={0} />,
    ).toJSON();
    expect(tree).toMatchSnapshot();
  });
});
