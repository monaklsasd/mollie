export interface Format {
  style: 'decimal' | 'currency' | 'percent';
  currency: string;
  minimumFractionDigits: number;
}

export type IntlNumberFormatOptions = Intl.NumberFormatOptions;
