import { Format } from './types';
export interface CurrenciesFormat {
  [countyCode: string]: {
    style?: Format['style'];
    minimumFractionDigits?: number;
  };
}

const formats: CurrenciesFormat = {
  JPY: { minimumFractionDigits: 0 },
};

export default formats;
