import React from 'react';
import classNames from 'classnames';

import { ClassnamesFunction } from 'types/helpers';

import './styles.scss';

interface Props {
  state?: 'success' | 'warning' | 'error' | 'info' | 'default';
  size?: 'small' | 'regular';
  className?: string;
  textAlign?: 'left' | 'center';
}

const getClass: ClassnamesFunction<Props> = ({
  state = 'default',
  className,
  textAlign,
  size = 'regular',
}) =>
  classNames('c-flash-message', className, {
    [`c-flash-message--${state}`]: state !== 'default',
    'c-flash-message--text-left': textAlign === 'left',
    [`c-flash-message--${size}`]: size !== 'regular',
  });

const FlashMessage: React.FC<Props> = ({ children, ...rest }) => (
  <div className={getClass(rest)}>{children}</div>
);

export default FlashMessage;
