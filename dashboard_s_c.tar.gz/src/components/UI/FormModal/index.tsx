import React from 'react';
import { FormattedMessage } from 'react-intl';
import classNames from 'classnames';

// Components
import Button from 'components/UI/Button';
import ModalNoUI from 'components/UI/ModalNoUI';

import { ClassnamesFunction } from 'types/helpers';

import './styles.scss';

interface Props {
  isOpen: boolean;
  handleConfirm: (...args: any[]) => void;
  handleCancel: React.ComponentProps<typeof ModalNoUI>['onRequestClose'];
  heading?: React.ReactNode;
  extraWide?: boolean;
  isSubmitting?: boolean;
  children: React.ReactElement;
}

const getClass: ClassnamesFunction<Props> = ({ extraWide }) =>
  classNames('c-form-modal', {
    'c-form-modal--extra-wide': extraWide,
  });

const FormModal: React.ForwardRefExoticComponent<Props &
  React.RefAttributes<any>> = React.forwardRef<any, Props>(
  (
    { isOpen, handleCancel, handleConfirm, heading, extraWide, children, isSubmitting, ...rest },
    ref: React.Ref<any>,
  ) => (
    <ModalNoUI
      isOpen={isOpen}
      onRequestClose={handleCancel}
      shouldCloseOnOverlayClick={false}
      bodyOpenClassName="has-fullscreen-form-modal"
      {...rest}>
      <div className={getClass({ extraWide })}>
        <div ref={ref} className="c-form-modal__content">
          {heading && <h3 className="c-form-modal__heading">{heading}</h3>}
          {children}
        </div>
        <div className="c-form-modal__actions">
          <Button
            type="button"
            onClick={handleCancel}
            className="c-form-modal__action"
            disabled={isSubmitting}>
            <FormattedMessage id="form-modal-close-label" defaultMessage="Cancel" />
          </Button>
          <Button
            isLoading={isSubmitting}
            type="button"
            onClick={handleConfirm}
            className="c-form-modal__action c-form-modal__confirm">
            <FormattedMessage id="form-modal-confirm-label" defaultMessage="Confirm" />
          </Button>
        </div>
      </div>
    </ModalNoUI>
  ),
);

export default FormModal;
