import React from 'react';
import renderer from 'react-test-renderer';
import Toggle from '../Toggle';

describe('<Toggle>', () => {
  let props;

  beforeEach(() => {
    props = {
      label: 'Toggle',
      name: 'toggle',
      status: 'pending',
      className: 'pull-right',
      value: 1,
      checked: true,
      disabled: false,
      // eslint-disable-next-line @typescript-eslint/no-empty-function
      onChange: (): void => {},
      // eslint-disable-next-line @typescript-eslint/no-empty-function
      onBlur: (): void => {},
      // eslint-disable-next-line @typescript-eslint/no-empty-function
      onFocus: (): void => {},
    };
  });

  it('renders correctly', () => {
    const tree = renderer.create(<Toggle {...props} />).toJSON();

    expect(tree).toMatchSnapshot();
  });
});
