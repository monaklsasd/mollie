import React from 'react';
import createComponentWithIntl from 'helpers/createComponentWithIntl';
import DatePresets from '../DatePresets';

jest.mock('components/UI/DateRangePicker');

describe('<DatePresets>', () => {
  const datePresets = ['today', 'this_week', 'custom'];

  const props = {
    datePresets,
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    onDatesChange: (): void => {},
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    onPresetChange: (): Function => (): void => {},
    selectedDates: {
      startDate: null,
      endDate: null,
    },
  };

  it('should hide date range picker for presets', () => {
    const tree = createComponentWithIntl(
      // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
      // @ts-ignore
      <DatePresets {...props} selectedPreset={'today'} />,
    ).toJSON();

    expect(tree).toMatchSnapshot();
  });

  it('should use the custom option by default', () => {
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    const tree = createComponentWithIntl(<DatePresets {...props} />).toJSON();

    expect(tree).toMatchSnapshot();
  });
});
