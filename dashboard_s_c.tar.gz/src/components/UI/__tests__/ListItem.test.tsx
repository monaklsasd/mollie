import React from 'react';
import renderer from 'react-test-renderer';
import ListItem from '../ListItem';

describe('<ListItem>', () => {
  let props;

  beforeEach(() => {
    props = {
      icon: <img alt="test" className="icon" />,
      heading: 'Creditcard',
      byline: '€0,29 per transactie',
      status: 'pending',
    };
  });

  it('shows status message when passed in', () => {
    const tree = renderer.create(<ListItem {...props} />).toJSON();

    expect(tree).toMatchSnapshot();
  });
});
