import React from 'react';
import { ConnectedRouter } from 'connected-react-router';
import { Provider } from 'react-redux';
import App from 'entries/dashboard/containers/App';
import ScrollToPosition from 'containers/ScrollToPosition';
import { Store } from 'redux';
import { ReduxState } from 'types/state';
import { History } from 'history';

interface Props {
  RoutesComponent: React.ComponentType<any>;
  store: Store<ReduxState>;
  history: History;
}

const Root: React.FC<Props> = ({ RoutesComponent, store, history }) => {
  return (
    <Provider store={store}>
      <ConnectedRouter history={history}>
        <App>
          <ScrollToPosition>
            <RoutesComponent />
          </ScrollToPosition>
        </App>
      </ConnectedRouter>
    </Provider>
  );
};

export default Root;
