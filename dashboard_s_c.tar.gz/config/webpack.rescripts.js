const path = require('path');
const AutoDllPlugin = require('autodll-webpack-plugin');
const FilterWarningsPlugin = require('webpack-filter-warnings-plugin');

const utils = require('./utils');
const paths = require('./paths');

/**
 * If you want to extract messages only available in Hosted Onboarding flow,
 * the hosted onboarding flow needs to be an entry point, it currently is
 * only an entry point in development mode
 * so switching const entry = isEnvDevelopment to const entry = !isEnvDevelopment
 * while running yarn translations:upload will work
 */

module.exports = {
  webpack: config => {
    const isEnvDevelopment = utils.isEnvDevelopment();

    /**
     * We define the different entries for the dashboard here
     * Main (Dashboard) and Onboarding (Hosted onboarding)
     */
    const entry = Object.keys(paths.entries).reduce((acc, key) => {
      const value = paths.entries[key];
      return {
        [key]: isEnvDevelopment ? utils.generateEntry(value) : value,
        ...acc,
      };
    }, {});

    const output = isEnvDevelopment
      ? {
          ...config.output,
          filename: 'static/js/[name].bundle.js',
          publicPath: utils.getPublicPath(),
        }
      : {
          ...config.output,
          filename: 'static/js/[name].[contenthash:10].js',
          chunkFilename: 'static/js/[name].[contenthash:10].chunk.js',
          publicPath: utils.getHomepage() + '/dashboard/build/',
        };

    const module = {
      ...config.module,
      rules: config.module.rules.map(rule => {
        if (!rule.oneOf) {
          return rule;
        }

        return {
          ...rule,
          oneOf: rule.oneOf.map(oneOfRule => {
            if (`${oneOfRule.test}` === `${/\.(js|mjs|jsx|ts|tsx)$/}`) {
              return isEnvDevelopment
                ? {
                    ...oneOfRule,
                    options: {
                      ...oneOfRule.options,
                      plugins: ['react-hot-loader/babel', ...oneOfRule.options.plugins],
                    },
                  }
                : {
                    ...oneOfRule,
                    options: {
                      ...oneOfRule.options,
                      plugins: [
                        ...oneOfRule.options.plugins,
                        'lodash',
                        'recharts',
                        [
                          'react-intl',
                          {
                            messagesDir: 'intl/messages'
                          },
                        ],
                      ],
                    },
                  };
            }

            if (
              [`${/\.(scss|sass)$/}`, `${/\.module\.(scss|sass)$/}`].includes(`${oneOfRule.test}`)
            ) {
              return {
                ...oneOfRule,
                use: oneOfRule.use.map(use => {
                  if (use.loader && use.loader.includes('sass-loader')) {
                    return {
                      ...use,
                      options: {
                        ...use.options,
                        data:
                          '@import "_variables"; @import "functions/breakpoint"; @import "functions/z"; @import "functions/tint"; @import "functions/shade"; @import "mixins/bare-list"; @import "mixins/clearfix"; @import "mixins/visually-hidden";',
                        includePaths: [path.resolve(paths.srcPath, 'styles')],
                      },
                    };
                  }

                  return use;
                }),
              };
            }

            return oneOfRule;
          }),
        };
      }),
    };

    const optimization = {
      ...config.optimization,
      splitChunks: {
        /**
         *  In production we want to split the main bundles and vendors
         *  in different chunks.
         *  Each entry will have its own bundle by default.
         *  Using cacheGroups we split the vendors into a specific bundle for each entry.
         *  A bundle can still be chunked into more specific chunks.
         */
        cacheGroups: isEnvDevelopment
          ? {
              default: false,
            }
          : {
              vendorsMain: {
                name: 'vendorsMain',
                test: /[\\/]node_modules[\\/]/,
                chunks: chunk => chunk.name === 'main',
                enforce: true,
              },
              vendorsHostedOnboarding: {
                name: 'vendorsHostedOnboarding',
                test: /[\\/]node_modules[\\/]/,
                chunks: chunk => chunk.name === 'hostedOnboarding',
                enforce: true,
              },
            },
      },
      runtimeChunk: isEnvDevelopment
        ? false
        : {
            name: 'runtime',
          },
    };

    const plugins = [
      // AutoDll is always the first plugin and shared between development and production environments
      new AutoDllPlugin({
        debug: true,
        filename: isEnvDevelopment ? '[name].js' : '[name].[contenthash:10].js',
        path: '.',
        entry: {
          vendors: ['react', 'react-dom', 'lodash'],
        },
      }),

      /**
       *  Silence mini-css-extract-plugin generating lots of warnings for CSS ordering.
       *  We use CSS modules that should not care for the order of CSS imports, so we
       *  should be safe to ignore these.
       *  See: https://github.com/webpack-contrib/mini-css-extract-plugin/issues/250
       **/
      new FilterWarningsPlugin({
        exclude: /mini-css-extract-plugin[^]*Conflicting order between:/,
      }),
      // Pre-config plugins
      ...(isEnvDevelopment ? [] : []),
      // Default config
      ...config.plugins,
      // Post-config plugins
      ...(isEnvDevelopment ? [] : []),
    ];

    return {
      ...config,
      entry,
      output,
      module,
      optimization,
      plugins,
    };
  },
};
