const path = require('path');
const fs = require('fs');

const utils = require('./utils');
const paths = require('./paths');

module.exports = {
  devServer: config => {
    return {
      ...config,
      port: utils.getPort(),
      host: utils.getHost(),
      https: {
        key: fs.readFileSync(path.resolve(paths.certificatesPath, 'certificate.key'), 'utf8'),
        cert: fs.readFileSync(path.resolve(paths.certificatesPath, 'certificate.crt'), 'utf8'),
      },
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': '*',
      },
    };
  },
};
