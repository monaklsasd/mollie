const path = require('path');
const appPackageJson = path.resolve(process.cwd(), 'package.json');

/**
 * Append/Remove trailing slash
 *
 * @param {string} path
 * @param {boolean} [needsSlash = true]
 * @returns {string}
 */
const ensureSlash = (path, needsSlash = true) => {
  /**
   * Remove any trailing slash by default.
   * A trailing slash will be added later if needsSlash is set to true.
   *
   * @type {string}
   */
  const cleanPath = path.replace(/\/+$/, '');

  return needsSlash ? `${cleanPath}/` : cleanPath;
};

const isEnvDevelopment = () => process.env.NODE_ENV === 'development';
const getPort = () => process.env.PORT || 3000;
const getHost = () => ensureSlash(process.env.HOST || 'cdn.mollie.dev', false);
const getPublicPath = () => `https://${getHost()}:${getPort()}/`;
const getHomepage = () =>
  ensureSlash(process.env.HOMEPAGE || require(appPackageJson).homepage, false);

const generateEntry = path => [
  `webpack-dev-server/client?${getPublicPath()}`,
  'webpack/hot/dev-server',
  path,
];

module.exports = {
  generateEntry,
  isEnvDevelopment,
  getPort,
  getHost,
  getPublicPath,
  getHomepage,
};
