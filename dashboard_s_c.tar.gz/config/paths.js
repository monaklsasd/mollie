const path = require('path');

const srcPath = path.resolve(__dirname, '../src');
const configPath = path.resolve(__dirname);

module.exports = {
  srcPath,
  configPath,
  certificatesPath: path.resolve(configPath, 'certs'),
  entries: {
    main: path.resolve(srcPath, 'entries/dashboard/index'),
    hostedOnboarding: path.resolve(srcPath, 'entries/onboarding/index'),
  },
};
