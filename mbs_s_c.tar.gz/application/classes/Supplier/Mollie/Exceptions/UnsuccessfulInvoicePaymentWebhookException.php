<?php

namespace Supplier\Mollie\Exceptions;

use Model_Banktransaction;
use Supplier\Mollie\MollieException;
use Supplier\Mollie\Response\LedgerInvoicePaymentWebhookResponse;
use Webmozart\Assert\Assert;

class UnsuccessfulInvoicePaymentWebhookException extends MollieException
{
    public static function httpRequestFailed(Model_Banktransaction $transaction, MollieException $e)
    {
        return new self(
            sprintf(
                "This transaction could not be paid towards invoice %s, because the HTTP request to Mollie failed: %s.",
                $transaction->getLedgerInvoiceNumber(),
                $e->getMessage()
            ),
            0,
            $e
        );
    }

    public static function webhookFailed(
        Model_Banktransaction $transaction,
        LedgerInvoicePaymentWebhookResponse $invoice_payment_response
    ): self {
        Assert::true(
            $invoice_payment_response->getStatus()->isFailure(),
            "Expected 'failure' status, got {$invoice_payment_response->getStatus()}"
        );

        return new self(
            sprintf(
                "This transaction could not be paid towards invoice %s, because reporting the invoice payment to"
                . " Mollie failed: %s.",
                $transaction->getLedgerInvoiceNumber(),
                $invoice_payment_response->getErrorMessage() ?? 'No error message provided by Mollie'
            )
        );
    }

    public function getCommentFriendlyMessage()
    {
        return $this->getMessage();
    }
}
