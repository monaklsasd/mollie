<?php

declare(strict_types=1);

namespace Supplier\Mollie;

use Config_Mbs;
use Core\Json;
use Core\Localization\Localizer;
use Core\Money\Currencies;
use GuzzleHttp\Client as GuzzleClient;
use GuzzleHttp\Exception\ConnectException;
use GuzzleHttp\Exception\RequestException;
use GuzzleHttp\RequestOptions;
use InvalidArgumentException;
use Model_Accounting_Twinfield_PrePaymentReference;
use Model_Banktransaction;
use Model_Banktransaction_Settlement;
use Model_Base;
use Mollie\Xml\Signature\DocumentVerifier;
use Money\Money;
use RuntimeException;
use Supplier\Mollie\Exceptions\UnsuccessfulInvoicePaymentWebhookException;
use Supplier\Mollie\Response\BuyRate;
use Supplier\Mollie\Response\ConversionDetails;
use Supplier\Mollie\Response\Invoice;
use Supplier\Mollie\Response\LedgerInvoicePaymentWebhookResponse;
use Supplier\Mollie\Response\Outpayment;
use Supplier\Mollie\Response\TransactionReportingResult;
use Supplier\XmlDSigMiddleware;
use Webmozart\Assert\Assert;
use function array_fill_keys;
use function array_walk;
use function Core\Money\money_to_array;
use function Core\Money\money_to_string;
use function count;
use function gettype;
use function in_array;
use function is_array;
use function is_object;
use function is_string;

/**
 * A class that helps communicating with the various API's the Mollie website offers to Mollie Banking System. These
 * API's can be found in the Mollie class Controller_Suppliers_Mbs.
 *
 * All requests are wrapped in signed XML document so that the Mollie code knows the request came from MBS and not some
 * crook.
 */
class Mollie
{
    use XmlDSigMiddleware;
    /** Should not be too high, if too high then MySQL will go away during HTTP calls. */
    private const CUSTOM_TIMEOUT = 180;

    /** @var GuzzleClient */
    protected $guzzle;

    public function __construct(Config_Mbs $config, DocumentVerifier $document_verifier)
    {
        $this->guzzle = new GuzzleClient(
            [
                'base_uri' => $this->getMollieHostname() . '/suppliers/mbs/',
            ]
        );

        self::registerXmlDSigMiddleware(
            $this->guzzle->getConfig('handler'),
            $document_verifier,
            $config->getPrivateRsaKey()
        );
    }

    public function getMollieHostname(): string
    {
        $endpoints = [
            'production' => 'https://www.mollie.nl',
            'staging'    => 'https://staging.mollie.nl',
        ];

        return $endpoints[MOLLIE_ENV] ?? 'https://mollie.dev';
    }

    protected function sendRequest(string $action, array $data, int $timeout = 30): array
    {
        try {
            $response = $this->guzzle->post(
                $action,
                [
                    RequestOptions::CONNECT_TIMEOUT => 3,
                    RequestOptions::TIMEOUT         => $timeout,
                    RequestOptions::JSON            => $data,
                ]
            );

            $decoded_response = Json::decodeAssociative((string)$response->getBody());

            /*
             * We know Mollie only returns arrays, but occasionally empty array's are returned which are are interpreted
             * as empty strings by the xml->json conversion (<?xml version="1.0"?><response></response>). We correct
             * this here.
             */
            if (is_string($decoded_response) && trim($decoded_response) === '') {
                $decoded_response = [];
            }

            if (!is_array($decoded_response)) {
                throw new MollieException(
                    sprintf(
                        'Didn\'t get an array as response from Mollie. Response was %s.',
                        (string)$response->getBody()
                    )
                );
            }

            return $decoded_response;
        } catch (ConnectException $e) {
            throw new MollieException(
                sprintf(
                    'Unable to connect to Mollie %s',
                    $e->getRequest()->getUri()
                )
            );
        } catch (RequestException $e) {
            throw new MollieException(
                sprintf(
                    'An error occurred while communicating with Mollie (%d %s %s)',
                    $e->getResponse() ? $e->getResponse()->getStatusCode() : 0,
                    $e->getRequest()->getMethod(),
                    $e->getRequest()->getUri()
                ),
                0,
                $e
            );
        }
    }

    /**
     * @deprecated Please inject this service via DI.
     */
    public static function getInstance(Config_Mbs $config): Mollie
    {
        return new Mollie($config, new DocumentVerifier());
    }

    /**
     * Check with Mollie and get all the invoice information so we can create more fully annotated objects for
     * AccountView.
     *
     * @param string[] $invoice_numbers
     *
     * @throws MollieException
     *
     * @return Invoice[]
     */
    public function getInvoiceInformation(array $invoice_numbers): array
    {
        if (count($invoice_numbers) === 0) {
            return [];
        }

        $invoice_numbers = array_unique($invoice_numbers);

        $response = $this->sendRequest('getInvoiceInformation', ['invoices' => $invoice_numbers]);

        $result = array_fill_keys($invoice_numbers, null);

        foreach ($response as $invoice_data) {
            $invoice_data                       = Invoice::createFromResponse($invoice_data);
            $result[$invoice_data->getNumber()] = $invoice_data;
        }

        if (in_array(null, $result, true)) {
            throw new MollieException(
                sprintf(
                    'Data was not returned for all invoices, missing invoice numbers: %s.',
                    implode(', ', array_keys($result, null, true))
                )
            );
        }

        return $result;
    }

    /**
     * Request outpayment information from Mollie
     *
     * @param Money[] $references References is an indexed array with the outpayment reference as the key and the amount
     *                            as the value. The amount is expected to be negative.
     *
     * @return Outpayment[]
     *
     * @see Controller_Suppliers_Mbs::_getOutpaymentInformation() in Mollie Platform.
     */
    public function getOutpaymentsInformation(array $references): array
    {
        if (count($references) === 0) {
            return [];
        }

        array_walk(
            $references,
            function (Money $amount, string $reference) {
                if (!$amount->isNegative()) {
                    throw new MollieException(
                        sprintf(
                            'Reported amount should be negative, %s given for outpayment %s.',
                            Localizer::formatMoney($amount),
                            $reference
                        )
                    );
                }
            }
        );

        $result = array_fill_keys(array_keys($references), null);

        /*
         * This must be done in multiple API calls or the Mollie loadbalancer will drop the connection.
         */
        foreach (array_chunk($references, 1000, true) as $references_chunk) {
            $response = $this->sendRequest(
                'get-outpayments-information',
                [
                    'references' => array_map(
                        function (Money $amount) {
                            return (float)money_to_string($amount);
                        },
                        $references_chunk
                    ),
                ]
            );

            foreach ($response as $outpayment) {
                $outpayment                          = Outpayment::createFromResponse($outpayment);
                $result[$outpayment->getReference()] = $outpayment;
            }
        }

        if (in_array(null, $result, true)) {
            throw new MollieException(
                sprintf(
                    'Data was not returned for all outpayments, missing: %s.',
                    implode(', ', array_keys($result, null, true))
                )
            );
        }

        return $result;
    }

    /**
     * Mark outpayment as exported
     *
     * @param Model_Banktransaction[] $transactions
     */
    public function markOutpaymentsExported(array $transactions): void
    {
        $references = [];

        foreach ($transactions as $transaction) {
            if (!($transaction instanceof Model_Banktransaction)) {
                throw new InvalidArgumentException(
                    sprintf(
                        'Transactions array should only consist of %s, got %s',
                        Model_Banktransaction::class,
                        is_object($transaction) ? get_class($transaction) : gettype($transaction)
                    )
                );
            }

            $references[$transaction->getOutpaymentReference()] = sprintf(
                '%s:%d',
                $transaction->getStatement()->getStatementReference(),
                $transaction->getPrimaryKey()
            );
        }

        if (count($references) === 0) {
            return;
        }

        $response = $this->sendRequest('mark-outpayments-exported', ['references' => $references]);

        $diff = array_diff(array_keys($references), $response['item']['references']);

        if (count($diff) > 0) {
            $reverse_diff = array_diff($response['item']['references'], array_keys($references));

            throw new MollieException(
                sprintf(
                    'Not all Outpayment references returned in the confirmation array. %s were missing, and %s were extra.',
                    implode(', ', $diff),
                    count($reverse_diff) > 0 ? implode(', ', $reverse_diff) : 'none'
                )
            );
        }
    }

    /**
     * Mark a single outpayment as returned (e.g. the transaction bounced and the amount was credited to our account).
     *
     * When successful, the invoice number will be returned
     *
     * @throws MollieException
     *
     * @return string the invoice number
     */
    public function markOutpaymentReturned(
        string $reference,
        Money $amount,
        string $bankaccount_iban_or_number
    ): string {
        $customer_id = strstr($reference, '.', true);

        $response = $this->sendRequest(
            'mark-outpayment-returned',
            [
                'reference'          => $reference,
                'customer_id'        => $customer_id,
                'amount'             => money_to_string($amount),
                'bankaccount_number' => $bankaccount_iban_or_number,
            ]
        );

        if ($response['item']['success'] !== 'true') {
            throw new MollieException(
                sprintf(
                    'Failed to report outpayment %s as returned.',
                    $reference
                )
            );
        }

        return trim($response['item']['invoice_number']);
    }

    /**
     * @throws MollieException
     */
    public function markTransferReturned(string $reference): void
    {
        $response = $this->sendRequest('mark-transfer-returned', ['reference' => $reference]);

        if ($response['item']['reference'] !== $reference) {
            throw new MollieException(
                sprintf(
                    'Failed to report outgoing transfer %s as returned.',
                    $reference
                )
            );
        }
    }

    /**
     * @throws MollieException
     */
    public function markTransferDeducted(string $reference): void
    {
        $response = $this->sendRequest('mark-transfer-deducted', ['reference' => $reference]);

        if ($response['item']['reference'] !== $reference) {
            throw new MollieException(
                sprintf(
                    'Failed to report outgoing transfer %s as deducted.',
                    $reference
                )
            );
        }
    }

    /**
     * @throws MollieException
     */
    public function markPrepaymentSettlementSettled(string $reference): void
    {
        $response = $this->sendRequest('mark-prepayment-settlement-settled', ['reference' => $reference]);

        if ($response['reference'] !== $reference) {
            throw new MollieException(
                sprintf(
                    'Failed to report prepayment settlement %s as settled.',
                    $reference
                )
            );
        }
    }

    /**
     * @throws MollieException
     */
    public function markPrepaymentSettlementReturned(string $reference): void
    {
        $response = $this->sendRequest('mark-prepayment-settlement-returned', ['reference' => $reference]);

        if ($response['reference'] !== $reference) {
            throw new MollieException(
                sprintf(
                    'Failed to report prepayment settlement %s as returned.',
                    $reference
                )
            );
        }
    }

    public function sendLedgerInvoicePaymentWebhook(
        Model_Banktransaction $transaction
    ): LedgerInvoicePaymentWebhookResponse {
        if ($transaction->getLedgerInvoiceNumber() === null) {
            throw new MollieException(sprintf(
                'Cannot report ledger invoice payment for transaction %s since it has no ledger invoice number.',
                $transaction->getPrimaryKey()
            ));
        }

        try {
            $response_data = $this->sendRequest(
                'webhooks/ledger-invoice-payment',
                [
                    'transaction_id'     => $transaction->getPrimaryKey(),
                    'transaction_amount' => money_to_array($transaction->getAmount()),
                    'invoice_number'     => $transaction->getLedgerInvoiceNumber(),
                ]
            );
        } catch (MollieException $e) {
            throw UnsuccessfulInvoicePaymentWebhookException::httpRequestFailed($transaction, $e);
        }

        $response = LedgerInvoicePaymentWebhookResponse::createFromResponse($response_data);

        if ($response->getStatus()->isFailure()) {
            throw UnsuccessfulInvoicePaymentWebhookException::webhookFailed($transaction, $response);
        }

        return $response;
    }

    public function checkQueueStatus(): bool
    {
        if (MOLLIE_ENV === 'development') {
            return true;
        }

        $response = $this->sendRequest('check-queue-status', []);

        $status = $response['status'];

        if (!in_array($status, ['on', 'off'], true)) {
            throw new MollieException(sprintf('Received unknown status for queue: %s.', $status));
        }

        return $status === 'on';
    }

    /**
     * Inform Mollie that a refund was returned to us (and has failed).
     */
    public function informRefundFailed(Model_Banktransaction $refund): void
    {
        $this->sendRequest(
            'informRefundFailed',
            [
                'refund' => [
                    'banktransaction_id' => $refund->getPrimaryKey(),
                    'transaction_id'     => $refund->getTagData()['transaction_id'],
                    'account_number'     => $refund->getOffsetAccountNumber(),
                    'amount'             => (float)money_to_string($refund->getAmount()),
                    'currency'           => Currencies::EUR()->getCode(),
                    'entry_date'         => $refund->getEntryDate()->format('Y-m-d'),
                ],
            ]
        );
    }

    /**
     * @param Model_Accounting_Twinfield_PrePaymentReference[] $pre_payment_references
     *
     * @throws MollieException
     */
    public function informTwinfieldPrePaymentReferences(array $pre_payment_references): void
    {
        $this->sendRequest(
            'inform-pre-payment-references',
            [
                'references' => array_map(
                    function (Model_Accounting_Twinfield_PrePaymentReference $reference) {
                        return [
                            'pre_payment' => [
                                'invoice_number' => $reference->pre_payment->getInvoiceNumber()->toString(),
                                'debtor_number'  => $reference->pre_payment->getDebtorNumber(),
                                'date'           => $reference->pre_payment->getDate()->format('Y-m-d'),
                                'amount'         => $reference->pre_payment->getAmount(),
                            ],
                            'reference' => [
                                'office'  => $reference->reference->getOffice()->getCode(),
                                'code'    => $reference->reference->getCode(),
                                'number'  => $reference->reference->getNumber(),
                                'line_id' => $reference->reference->getLineId(),
                            ],
                        ];
                    },
                    $pre_payment_references
                ),
            ]
        );
    }

    /**
     * @param Model_Banktransaction_Settlement[] $settlements
     *
     * @return TransactionReportingResult[]
     */
    public function informTransactionsReceived(iterable $settlements, ?bool $is_valitor_re_expansion): array
    {
        $transaction_details = [];
        $result              = [];

        foreach ($settlements as $settlement) {
            $transaction_details[] = self::prepareSettlementForRequest($settlement, $is_valitor_re_expansion);

            $result[$settlement->getTransaction()->getPrimaryKey()] = null;
        }

        $response = $this->sendRequest(
            'informTransactionsReceived',
            ['transactions' => $transaction_details],
            self::CUSTOM_TIMEOUT
        );

        try {
            foreach ($response as $details) {
                $details                              = TransactionReportingResult::createFromResponse($details);
                $result[$details->getTransactionId()] = $details;
            }
        } catch (RuntimeException $e) {
            // translate.
            throw new MollieException($e->getMessage(), $e->getCode(), $e);
        }

        if (in_array(null, $result, true)) {
            throw new MollieException(
                sprintf(
                    'Data was not returned for all reported transactions, missing: %s.',
                    implode(', ', array_keys($result, null, true))
                )
            );
        }

        return $result;
    }

    /**
     * @param int[] $payment_ids
     *
     * @return ConversionDetails[]
     */
    public function getConversionDetails(iterable $payment_ids): array
    {
        Assert::allInteger($payment_ids);

        $response = $this->sendRequest(
            'get-conversion-details',
            ['payment_ids' => array_unique($payment_ids)],
            self::CUSTOM_TIMEOUT
        );

        $result = [];

        foreach ($response as $details) {
            $details                          = ConversionDetails::createFromResponse($details);
            $result[$details->getPaymentId()] = $details;
        }

        return $result;
    }

    private static function prepareSettlementForRequest(
        Model_Banktransaction_Settlement $settlement,
        ?bool $is_valitor_re_expansion
    ) {
        $transaction = $settlement->getTransaction();

        if ($transaction->getEntryDate() === null) {
            throw new InvalidArgumentException(
                sprintf(
                    'Transaction #%d doesn\'t have an entry_date.',
                    $transaction->getPrimaryKey()
                )
            );
        }

        $customerDate = null;

        if ($transaction->getCustomerDate()) {
            $customerDate = $transaction->getCustomerDate()->format(Model_Base::DATE_SQL);
        }

        $request_body = [
            'banktransaction_id' => $transaction->getPrimaryKey(),
            'transaction_id'     => $settlement->getSupplierTransactionId(), // Payment identifier
            'payment_method'     => $settlement->getPaymentMethod(), // Payment method
            'amount'             => money_to_string($transaction->getAmount()),
            'currency'           => $transaction->getCurrency()->getCode(),
            'entry_date'         => $transaction->getEntryDate()->format(Model_Base::DATE_ONLY_SQL),
            'customer_date'      => $customerDate,
            'consumer_name'      => $transaction->getOffsetAccountName(),
            'consumer_account'   => $transaction->getOffsetAccountNumber(),
            'consumer_bic'       => $transaction->getOffsetAccountBic(),
            'consumer_country'   => $transaction->getTagData()['consumer_country'] ?? null, // Klarna
            'reason_code'        => $transaction->getTagData()['reason_code'] ?? null, // DirectDebit
            'order_id'           => $transaction->getTagData()['order_id'] ?? null, // Klarna (needed for chargebacks)
        ];

        /*
         * For the Valitor settlements we'll be re-expanding we need a way to signal to Mollie.
         *
         * This and the changes to the methods that call down to here are temporary code and will be removed with:
         * @see https://mollie.atlassian.net/browse/FFS-2000
         */
        if ($is_valitor_re_expansion !== null && $is_valitor_re_expansion === true) {
            $request_body['is_valitor_re_expansion'] = $is_valitor_re_expansion;
        }

        return $request_body;
    }

    /**
     * @param int[] $payment_ids
     *
     * @return BuyRate[]
     */
    public function getBuyRate(iterable $payment_ids): array
    {
        // check types
        Assert::allInteger($payment_ids);

        $response = $this->sendRequest(
            'get-buy-rate',
            ['payment_ids' => array_unique($payment_ids)],
            self::CUSTOM_TIMEOUT
        );

        $result = [];

        foreach ($response as $buy_rate) {
            $buy_rate                          = BuyRate::createFromResponse($buy_rate);
            $result[$buy_rate->getPaymentId()] = $buy_rate;
        }

        return $result;
    }

    public function informBankingFeeCharged(Money $amount, string $sdd_transaction_id, int $bank_transaction_id)
    {
        /**
         * Temporarily updated from isPositive() to !isNegative() for testing purposes. Will be updated once
         *
         * @issue FFS-2662 is done.
         */
        Assert::true(!$amount->isNegative(), "The fee charged by the bank must be sent as positive to this method");

        $this->sendRequest(
            'inform-banking-fee-charged',
            [
                [
                    "amount"                 => money_to_string($amount),
                    "currency"               => $amount->getCurrency()->getCode(),
                    "transaction_id"         => $sdd_transaction_id, // SD12....
                    "mbs_banktransaction_id" => $bank_transaction_id,
                ],
            ]
        );
    }
}
