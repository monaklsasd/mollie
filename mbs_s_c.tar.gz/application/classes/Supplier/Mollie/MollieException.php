<?php

declare(strict_types=1);

namespace Supplier\Mollie;

use RuntimeException;

class MollieException extends RuntimeException
{
}
