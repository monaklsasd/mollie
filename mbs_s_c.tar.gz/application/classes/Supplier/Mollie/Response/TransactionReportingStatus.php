<?php

declare(strict_types=1);

namespace Supplier\Mollie\Response;

use MyCLabs\Enum\Enum;

/**
 * The possible statuses of the reporting of a transation (informTransactionReceived)
 *
 * @method static self SUCCESS()
 * @method static self SKIPPED()
 * @method static self NOT_FOUND()
 * @method static self NOT_PAID()
 * @method static self ALREADY_SETTLED()
 * @method static self INVALID_AMOUNT()
 */
final class TransactionReportingStatus extends Enum
{
    protected const SUCCESS         = 'success';
    protected const SKIPPED         = 'skipped';
    protected const NOT_FOUND       = 'not_found';
    protected const NOT_PAID        = 'not_paid';
    protected const ALREADY_SETTLED = 'already_settled';
    protected const INVALID_AMOUNT  = 'invalid_amount';
}
