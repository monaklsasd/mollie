<?php

declare(strict_types=1);

namespace Supplier\Mollie\Response;

use Core\Money\Currencies;
use Money\Currency;
use function is_string;

class Outpayment
{
    /** @var string */
    private $reference;

    /** @var Debitor */
    private $debitor;

    /** @var OutpaymentTransaction[] */
    private $transactions = [];

    public function __construct(string $reference, Debitor $debitor, array $transactions)
    {
        array_walk($transactions, function (OutpaymentTransaction $transaction) {
        });

        $this->reference    = trim($reference);
        $this->debitor      = $debitor;
        $this->transactions = array_values($transactions);
    }

    public static function createFromResponse(array $response): self
    {
        // Empty xml nodes are returned as an empty string or whitespace characters, not [].
        if (is_string($response['transactions']) && trim($response['transactions']) === '') {
            $response['transactions'] = [];
        }

        return new self(
            $response['reference'],
            Debitor::createFromResponse($response['debitor']),
            array_map(function (array $transaction) {
                return OutpaymentTransaction::createFromResponse($transaction);
            }, $response['transactions'])
        );
    }

    public function getReference(): string
    {
        return $this->reference;
    }

    public function getDebitor(): Debitor
    {
        return $this->debitor;
    }

    public function getCurrency(): Currency
    {
        if (count($this->transactions) === 0) {
            return Currencies::EUR();
        }

        return $this->transactions[0]->getAmount()->getCurrency();
    }

    /**
     * @return OutpaymentTransaction[]
     */
    public function getTransactions(): array
    {
        return $this->transactions;
    }
}
