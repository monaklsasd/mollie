<?php

declare(strict_types=1);

namespace Supplier\Mollie\Response;

use Core\Money\Currencies;
use Money\Money;
use function Core\Money\money_from_string;

class Invoice
{
    /** @var string */
    private $number;

    /** @var Money */
    private $amount;

    /** @var int */
    private $customer_id;

    /** @var Debitor */
    private $debitor;

    public function __construct(string $number, Money $amount, int $customer_id, Debitor $debitor)
    {
        $this->number      = $number;
        $this->amount      = $amount;
        $this->customer_id = $customer_id;
        $this->debitor     = $debitor;
    }

    public static function createFromResponse(array $response): self
    {
        return new self(
            $response['invoice_no'],
            money_from_string($response['amount'], Currencies::EUR()),
            (int)$response['customer_id'],
            Debitor::createFromResponse($response['debitor'])
        );
    }

    public function getNumber(): string
    {
        return $this->number;
    }

    public function getAmount(): Money
    {
        return $this->amount;
    }

    public function getCustomerId(): int
    {
        return $this->customer_id;
    }

    public function getDebitor(): Debitor
    {
        return $this->debitor;
    }
}
