<?php

declare(strict_types=1);

namespace Supplier\Mollie\Response;

use function is_string;

class TransactionReportingResult
{
    /** @var int MBS Banktransaction ID */
    private $transaction_id;

    /** @var TransactionReportingStatus */
    private $status;

    /** @var bool */
    private $is_handled_by_ledger;

    /** @var TransactionDetails|null */
    private $transaction_details;

    /** @var array */
    private $extra_data;

    public function __construct(
        int $transaction_id,
        TransactionReportingStatus $status,
        bool $is_handled_by_ledger,
        ?TransactionDetails $transaction_details = null,
        array $extra_data = []
    ) {
        $this->transaction_id       = $transaction_id;
        $this->status               = $status;
        $this->is_handled_by_ledger = $is_handled_by_ledger;
        $this->transaction_details  = $transaction_details;
        $this->extra_data           = $extra_data;
    }

    public static function createFromResponse(array $response): self
    {
        return new self(
            (int)$response['banktransaction_id'],
            new TransactionReportingStatus($response['status']),
            self::getOrganizationUsesLedgerSystemFrom($response),
            isset($response['mollie_payment_id']) ? TransactionDetails::createFromResponse($response) : null,
            $response['extra'] ?? []
        );
    }

    private static function getOrganizationUsesLedgerSystemFrom(array $response): bool
    {
        if (!isset($response['handled_by_ledger'])) {
            return false;
        }

        return $response['handled_by_ledger'] === '1';
    }

    public function getTransactionId(): int
    {
        return $this->transaction_id;
    }

    public function getStatus(): TransactionReportingStatus
    {
        return $this->status;
    }

    public function isHandledByLedger(): bool
    {
        return $this->is_handled_by_ledger;
    }

    public function hasTransactionDetails(): bool
    {
        return $this->transaction_details !== null;
    }

    public function getTransactionDetails(): TransactionDetails
    {
        return $this->transaction_details;
    }

    public function getAllExtraData(): array
    {
        return $this->extra_data;
    }

    public function getExtraData(string $key)
    {
        $data = $this->extra_data[$key] ?? null;

        if ($data === null) {
            return null;
        }

        if (is_string($data)) {
            $data = trim($data);

            return $data === '' ? null : $data;
        }

        return $data;
    }
}
