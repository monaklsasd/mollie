<?php

declare(strict_types=1);

namespace Supplier\Mollie\Response;

use InvalidArgumentException;
use Money\Currency;
use Money\Money;
use function Core\Money\money_from_string;

class TransactionDetails
{
    /** @var string */
    private $payment_method;

    /** @var int Mollie Payment ID */
    private $payment_id;

    /** @var int Mollie Customer ID */
    private $customer_id;

    /** @var Money */
    private $settlement_amount;

    /** @var string|null */
    private $consumer_iban;

    /** @var string|null */
    private $consumer_bic;

    /** @var string|null */
    private $consumer_name;

    /** @var string|null */
    private $consumer_country;

    public function __construct(
        string $payment_method,
        int $payment_id,
        int $customer_id,
        Money $settlement_amount,
        ?string $consumer_iban = null,
        ?string $consumer_bic = null,
        ?string $consumer_name = null,
        ?string $consumer_country = null
    ) {
        $payment_method = trim($payment_method);

        if ($payment_method === '') {
            throw new InvalidArgumentException(sprintf('payment_method should not be empty.'));
        }

        $this->payment_method    = $payment_method;
        $this->payment_id        = $payment_id;
        $this->customer_id       = $customer_id;
        $this->settlement_amount = $settlement_amount;
        $this->consumer_iban     = $consumer_iban    === null ? null : trim($consumer_iban);
        $this->consumer_bic      = $consumer_bic     === null ? null : trim($consumer_bic);
        $this->consumer_name     = $consumer_name    === null ? null : trim($consumer_name);
        $this->consumer_country  = $consumer_country === null ? null : trim($consumer_country);
    }

    public static function createFromResponse(array $response): self
    {
        return new self(
            (string)$response['payment_method'],
            (int)$response['mollie_payment_id'],
            (int)$response['mollie_customer_id'],
            money_from_string(
                $response['settlement_amount']['value'],
                new Currency($response['settlement_amount']['currency'])
            ),
            $response['consumer_account'] ?? null,
            $response['consumer_bic'] ?? null,
            $response['consumer_name'] ?? null,
            $response['consumer_country'] ?? null
        );
    }

    public function getPaymentMethod(): string
    {
        return $this->payment_method;
    }

    public function getPaymentId(): int
    {
        return $this->payment_id;
    }

    public function getCustomerId(): int
    {
        return $this->customer_id;
    }

    public function getSettlementAmount(): Money
    {
        return $this->settlement_amount;
    }

    public function getConsumerIban(): ?string
    {
        return $this->consumer_iban;
    }

    public function getConsumerBic(): ?string
    {
        return $this->consumer_bic;
    }

    public function getConsumerName(): ?string
    {
        return $this->consumer_name;
    }

    public function getConsumerCountry(): ?string
    {
        return $this->consumer_country;
    }
}
