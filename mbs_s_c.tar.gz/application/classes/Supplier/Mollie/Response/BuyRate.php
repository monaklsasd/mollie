<?php

declare(strict_types=1);

namespace Supplier\Mollie\Response;

use Core\Money\Multiplier;
use Core\Money\PreciseMoney;
use Core\Money\Rate;
use Money\Currency;

class BuyRate
{
    /** @var int */
    private $payment_id;

    /** @var Rate */
    private $rate;

    public function __construct(int $payment_id, Rate $rate)
    {
        $this->payment_id = $payment_id;
        $this->rate       = $rate;
    }

    public static function createFromResponse(array $response): self
    {
        return new self(
            (int)$response['payment_id'],
            new Rate(
                new PreciseMoney($response['fixed_rate']['value'], new Currency($response['fixed_rate']['currency'])),
                Multiplier::fromPercentage($response['variable_rate'])
            )
        );
    }

    public function getPaymentId(): int
    {
        return $this->payment_id;
    }

    public function getRate(): Rate
    {
        return $this->rate;
    }
}
