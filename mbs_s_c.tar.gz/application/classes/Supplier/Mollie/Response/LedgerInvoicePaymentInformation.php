<?php

namespace Supplier\Mollie\Response;

use Money\Currency;
use Money\Money;
use Webmozart\Assert\Assert;
use function Core\Money\money_from_string;

class LedgerInvoicePaymentInformation
{
    /** @var Money */
    private $amount_paid_towards_invoice;

    /** @var Money */
    private $amount_paid_excessively;

    /** @var Money */
    private $remaining_amount_due;

    private function __construct(
        Money $amount_paid_towards_invoice,
        Money $amount_paid_excessively,
        Money $remaining_amount_due
    ) {
        $this->amount_paid_towards_invoice = $amount_paid_towards_invoice;
        $this->amount_paid_excessively     = $amount_paid_excessively;
        $this->remaining_amount_due        = $remaining_amount_due;
    }

    public static function createFromResponse(array $response_data): self
    {
        Assert::keyExists($response_data, 'amount_paid_towards_invoice');
        Assert::keyExists($response_data, 'amount_paid_excessively');
        Assert::keyExists($response_data, 'remaining_amount_due');

        return new self(
            self::parseMoney($response_data['amount_paid_towards_invoice']),
            self::parseMoney($response_data['amount_paid_excessively']),
            self::parseMoney($response_data['remaining_amount_due'])
        );
    }

    private static function parseMoney(array $amount_array): Money
    {
        return money_from_string(
            $amount_array['value'],
            new Currency($amount_array['currency'])
        );
    }

    public function getAmountPaidTowardsInvoice(): Money
    {
        return $this->amount_paid_towards_invoice;
    }

    public function getAmountPaidExcessively(): Money
    {
        return $this->amount_paid_excessively;
    }

    public function getRemainingAmountDue(): Money
    {
        return $this->remaining_amount_due;
    }
}
