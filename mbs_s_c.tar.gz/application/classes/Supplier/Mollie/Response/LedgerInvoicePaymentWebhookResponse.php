<?php

declare(strict_types=1);

namespace Supplier\Mollie\Response;

use LogicException;
use Money\Money;

class LedgerInvoicePaymentWebhookResponse
{
    /** @var LedgerInvoicePaymentWebhookResponseStatus */
    private $status;

    /** @var string|null */
    private $error_message;

    /**
     * Not available when status was 'failure'.
     *
     * @var LedgerInvoiceInformation|null
     */
    private $invoice_information;

    /**
     * Only available when status was 'accepted'.
     *
     * @var LedgerInvoicePaymentInformation|null
     */
    private $invoice_payment_information;

    private function __construct(
        LedgerInvoicePaymentWebhookResponseStatus $status,
        ?LedgerInvoiceInformation $invoice_information,
        ?LedgerInvoicePaymentInformation $invoice_payment_information,
        ?string $error_message
    ) {
        $this->status                      = $status;
        $this->invoice_information         = $invoice_information;
        $this->invoice_payment_information = $invoice_payment_information;
        $this->error_message               = $error_message;
    }

    public function getStatus(): LedgerInvoicePaymentWebhookResponseStatus
    {
        return $this->status;
    }

    public static function createFromResponse(array $response_data): self
    {
        $status                      = self::parseResponseStatus($response_data);
        $invoice_information         = null;
        $invoice_payment_information = null;
        $error_message               = $response_data['error_message'] ?? null;

        if (!$status->isFailure()) {
            $invoice_information = LedgerInvoiceInformation::createFromResponse($response_data);
        }

        if ($status->isAccepted()) {
            $invoice_payment_information = LedgerInvoicePaymentInformation::createFromResponse($response_data);
        }

        return new self($status, $invoice_information, $invoice_payment_information, $error_message);
    }

    private static function parseResponseStatus(array $response): LedgerInvoicePaymentWebhookResponseStatus
    {
        $status = $response['status'] ?? null;

        foreach (LedgerInvoicePaymentWebhookResponseStatus::values() as $possible_status) {
            if ($response['status'] == $possible_status->getValue()) {
                return $possible_status;
            }
        }

        throw new LogicException("Unknown status '{$status}' returned by Mollie");
    }

    public function getInvoiceNumber(): ?string
    {
        if ($this->invoice_information === null) {
            return null;
        }

        return $this->invoice_information->getInvoiceNumber();
    }

    public function getAmountPaidTowardsInvoice(): ?Money
    {
        if ($this->invoice_payment_information === null) {
            return null;
        }

        return $this->invoice_payment_information->getAmountPaidTowardsInvoice();
    }

    public function getAmountPaidExcessively(): ?Money
    {
        if ($this->invoice_payment_information === null) {
            return null;
        }

        return $this->invoice_payment_information->getAmountPaidExcessively();
    }

    public function getRemainingAmountDue(): ?Money
    {
        if ($this->invoice_payment_information === null) {
            return null;
        }

        return $this->invoice_payment_information->getRemainingAmountDue();
    }

    public function getAmountThatShouldHaveBeenPaid(): Money
    {
        return $this->getAmountPaidTowardsInvoice()
            ->add($this->getRemainingAmountDue());
    }

    public function getInvoiceId(): ?int
    {
        if ($this->invoice_information === null) {
            return null;
        }

        return $this->invoice_information->getInvoiceId();
    }

    public function getErrorMessage(): ?string
    {
        return $this->error_message;
    }

    public function invoiceWasPaidExactly(): bool
    {
        return $this->getRemainingAmountDue()->isZero() && $this->getAmountPaidExcessively()->isZero();
    }

    public function invoiceWasUnderpaid(): bool
    {
        return $this->getRemainingAmountDue()->isPositive();
    }

    public function invoiceWasOverpaid(): bool
    {
        return $this->getAmountPaidExcessively()->isPositive();
    }
}
