<?php

declare(strict_types=1);

namespace Supplier\Mollie\Response;

use Core\Money\Currencies;
use Money\Currency;
use Money\Money;
use function Core\Money\money_from_string;
use function is_string;

class OutpaymentTransaction
{
    /** @var string */
    private $description;

    /** @var Money */
    private $amount;

    /** @var string */
    private $invoice_number;

    /** @var int */
    private $accountview_ledger_number;

    /** @var string|null */
    private $sub_number;

    /** @var int|null */
    private $cost_code;

    public function __construct(
        string $description,
        Money $amount,
        string $invoice_number,
        int $accountview_ledger_number,
        ?string $sub_number = null,
        ?int $cost_code = null
    ) {
        if (is_string($sub_number)) {
            $sub_number = trim($sub_number);

            if ($sub_number === '') {
                $sub_number = null;
            }
        }

        $this->description               = trim($description);
        $this->amount                    = $amount;
        $this->invoice_number            = trim($invoice_number);
        $this->accountview_ledger_number = $accountview_ledger_number;
        $this->sub_number                = $sub_number;
        $this->cost_code                 = $cost_code;
    }

    public static function createFromResponse(array $response): self
    {
        return new self(
            $response['trn_desc'],
            money_from_string($response['amount'], Currencies::EUR()),
            $response['inv_nr'],
            (int)$response['acct_nr'],
            $response['sub_nr'] ? (string)$response['sub_nr'] : null,
            $response['cost_code'] ? (int)$response['cost_code'] : null
        );
    }

    public function getDescription(): string
    {
        return $this->description;
    }

    public function getAmount(): Money
    {
        return $this->amount;
    }

    public function getInvoiceNumber(): string
    {
        return $this->invoice_number;
    }

    public function getAccountviewLedgerNumber(): int
    {
        return $this->accountview_ledger_number;
    }

    public function getSubNumber(): ?string
    {
        return $this->sub_number;
    }

    public function getCostCode(): ?int
    {
        return $this->cost_code;
    }

    public function getCurrency(): Currency
    {
        return $this->getAmount()->getCurrency();
    }
}
