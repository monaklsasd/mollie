<?php

declare(strict_types=1);

namespace Supplier\Mollie\Response;

use Core\Money\Currencies;
use InvalidArgumentException;
use Money\Currency;
use Money\Money;
use function Core\Money\money_from_string;
use function is_numeric;

class ConversionDetails
{
    /** @var int */
    private $payment_id;

    /** @var Money */
    private $payment_amount;

    /** @var Money */
    private $settlement_amount;

    /** @var Money */
    private $converted_amount;

    /** @var Money */
    private $markup_risk;

    /** @var Money */
    private $markup_supplier;

    /** @var string */
    private $exchange_rate;

    /** @var string */
    private $markup_rate;

    public function __construct(
        int $payment_id,
        Money $payment_amount,
        Money $settlement_amount,
        Money $converted_amount,
        Money $markup_risk,
        Money $markup_supplier,
        string $exchange_rate,
        string $markup_rate
    ) {
        if (!is_numeric($exchange_rate)) {
            throw new InvalidArgumentException(sprintf(
                'Exchange rate should be numeric string, "%s" given.',
                $exchange_rate
            ));
        }

        if (!is_numeric($markup_rate)) {
            throw new InvalidArgumentException(sprintf(
                'Markup rate should be numeric string, "%s" given.',
                $markup_rate
            ));
        }

        $this->payment_id        = $payment_id;
        $this->payment_amount    = $payment_amount;
        $this->settlement_amount = $settlement_amount;
        $this->converted_amount  = $converted_amount;
        $this->markup_risk       = $markup_risk;
        $this->markup_supplier   = $markup_supplier;
        $this->exchange_rate     = $exchange_rate;
        $this->markup_rate       = $markup_rate;
    }

    public static function createFromResponse(array $response): self
    {
        return new self(
            (int)$response['payment_id'],
            money_from_string($response['payment_amount'], new Currency($response['payment_currency'])),
            money_from_string($response['settlement_amount'], new Currency($response['settlement_currency'])),
            money_from_string($response['converted_amount'], Currencies::EUR()),
            money_from_string($response['markup_risk'], Currencies::EUR()),
            money_from_string($response['markup_supplier'], Currencies::EUR()),
            (string)$response['exchange_rate'],
            (string)$response['markup_rate']
        );
    }

    public function getPaymentId(): int
    {
        return $this->payment_id;
    }

    public function getPaymentAmount(): Money
    {
        return $this->payment_amount;
    }

    public function getSettlementAmount(): Money
    {
        return $this->settlement_amount;
    }

    public function getConvertedAmount(): Money
    {
        return $this->converted_amount;
    }

    public function getMarkupRisk(): Money
    {
        return $this->markup_risk;
    }

    public function getMarkupSupplier(): Money
    {
        return $this->markup_supplier;
    }

    public function getExchangeRate(): string
    {
        return $this->exchange_rate;
    }

    public function getMarkupRate(): string
    {
        return $this->markup_rate;
    }
}
