<?php

declare(strict_types=1);

namespace Supplier\Mollie\Response;

class Debitor
{
    /** @var string */
    private $sub_number;

    /** @var string */
    private $account_name;

    /** @var string|null */
    private $vat_number;

    public function __construct(string $sub_number, string $account_name, ?string $vat_number = null)
    {
        if (is_string($vat_number)) {
            $vat_number = trim($vat_number);

            if ($vat_number === '') {
                $vat_number = null;
            }
        }

        $this->sub_number   = trim($sub_number);
        $this->account_name = trim($account_name);
        $this->vat_number   = $vat_number;
    }

    public static function createFromResponse(array $response)
    {
        return new self(
            $response['sub_nr'],
            $response['acct_name'],
            $response['vat_nr']
        );
    }

    public function getSubNumber(): string
    {
        return $this->sub_number;
    }

    public function getAccountName(): string
    {
        return $this->account_name;
    }

    public function getVatNumber(): ?string
    {
        return $this->vat_number;
    }
}
