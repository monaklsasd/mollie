<?php

namespace Supplier\Mollie\Response;

use MyCLabs\Enum\Enum;

/**
 * @method static LedgerInvoicePaymentWebhookResponseStatus ACCEPTED()
 * @method static LedgerInvoicePaymentWebhookResponseStatus FAILURE()
 * @method static LedgerInvoicePaymentWebhookResponseStatus REJECTED()
 */
class LedgerInvoicePaymentWebhookResponseStatus extends Enum
{
    /**
     * Mollie accepted the payment and at least some portion of it was used to pay the invoice.
     *
     * In this case, the webhook response from Mollie will contain both information about the invoice as well as
     * information about how the payment was processed.
     */
    private const ACCEPTED = 'accepted';

    /**
     * Mollie did not allow the payment to be used to pay the invoice.
     *
     * In this case, the webhook response from Mollie will contain information about the invoice.
     */
    private const REJECTED = 'rejected';

    /**
     * Mollie either failed to find the related invoice or failed to process the webhook.
     *
     * In this case, the webhook response from Mollie will only contain an error message.
     */
    private const FAILURE = 'failure';

    public function isAccepted(): bool
    {
        return $this->equals(self::ACCEPTED());
    }

    public function isRejected(): bool
    {
        return $this->equals(self::REJECTED());
    }

    public function isFailure(): bool
    {
        return $this->equals(self::FAILURE());
    }
}
