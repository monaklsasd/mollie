<?php

namespace Supplier\Mollie\Response;

use Webmozart\Assert\Assert;

class LedgerInvoiceInformation
{
    /** @var int */
    private $invoice_id;

    /** @var string */
    private $invoice_token;

    /** @var string */
    private $invoice_number;

    private function __construct(
        int $invoice_id,
        string $invoice_token,
        string $invoice_number
    ) {
        $this->invoice_id     = $invoice_id;
        $this->invoice_token  = $invoice_token;
        $this->invoice_number = $invoice_number;
    }

    public static function createFromResponse(array $response_data): self
    {
        Assert::keyExists($response_data, 'invoice_id');
        Assert::keyExists($response_data, 'invoice_token');
        Assert::keyExists($response_data, 'invoice_number');

        Assert::integerish($response_data['invoice_id']);
        Assert::stringNotEmpty($response_data['invoice_token']);
        Assert::stringNotEmpty($response_data['invoice_number']);

        return new self(
            (int)$response_data['invoice_id'],
            (string)$response_data['invoice_token'],
            (string)$response_data['invoice_number']
        );
    }

    public function getInvoiceId(): int
    {
        return $this->invoice_id;
    }

    public function getInvoiceToken(): string
    {
        return $this->invoice_token;
    }

    public function getInvoiceNumber(): string
    {
        return $this->invoice_number;
    }
}
