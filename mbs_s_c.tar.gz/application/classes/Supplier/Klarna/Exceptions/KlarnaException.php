<?php

declare(strict_types=1);

namespace Supplier\Klarna\Exceptions;

use Throwable;

interface KlarnaException extends Throwable
{
}
