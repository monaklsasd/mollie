<?php

declare(strict_types=1);

namespace Supplier\Klarna\Exceptions;

use InvalidArgumentException;

class PayoutAmountMismatchException extends InvalidArgumentException implements KlarnaException
{
}
