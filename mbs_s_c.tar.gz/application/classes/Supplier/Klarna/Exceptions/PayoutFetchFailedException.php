<?php

declare(strict_types=1);

namespace Supplier\Klarna\Exceptions;

use RuntimeException;

class PayoutFetchFailedException extends RuntimeException implements KlarnaException
{
}
