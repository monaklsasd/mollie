<?php

declare(strict_types=1);

namespace Supplier\Klarna\Payout;

use Config_Klarna;
use Core\Json;
use DateTime;
use DateTimeImmutable;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\RequestOptions;
use Helper\DateTime\Now;
use Helper\DateTime\Utc;
use Orm\ModelFactory;
use Supplier\Klarna\Exceptions\KlarnaException;
use Supplier\Klarna\Exceptions\PayoutFetchFailedException;
use Supplier\Klarna\Payout\Response\Payout;
use Supplier\Klarna\Payout\Response\PayoutSummary;
use Supplier\Klarna\Payout\Response\PayoutTransaction;
use function rtrim;
use function sprintf;

class PayoutRetriever
{
    use Utc;
    use Now;
    private const PAYOUT_REPORT_ENDPOINT = "settlements/v1/reports/payout-with-transactions";
    private const PAYOUTS_ENDPOINT       = "settlements/v1/payouts";
    private const TRANSACTIONS_ENDPOINT  = "settlements/v1/transactions";

    /** @var ModelFactory */
    private $model_factory;

    /** @var Config_Klarna */
    private $klarna_config;

    /** @var Client */
    private $guzzle;

    public function __construct(ModelFactory $model_factory, Config_Klarna $config)
    {
        $this->klarna_config = $config;
        $this->model_factory = $model_factory;
        $this->guzzle        = new Client([
            "base_uri"              => $config->getEndpointUrl(),
            RequestOptions::HEADERS => ["Authorization" => $this->getAuthorizationHeader()],
        ]);
    }

    /**
     * Retrieves a Payout Report through the Klarna API, returning CSV.
     *
     * @throws KlarnaException
     *
     * @deprecated We don't use this anymore, it doesn't contain all refund ID's
     */
    public function retrievePayoutCsv(string $payout_reference): string
    {
        try {
            $response = $this->guzzle->get(
                self::PAYOUT_REPORT_ENDPOINT,
                [
                    RequestOptions::QUERY => ['payment_reference' => $payout_reference],
                ]
            );

            $payout_report = $response->getBody()->getContents();

            // Remove trailing newline
            return rtrim($payout_report);
        } catch (GuzzleException $e) {
            throw new PayoutFetchFailedException(sprintf(
                'Unable to retrieve report %s',
                $payout_reference
            ), 0, $e);
        }
    }

    /**
     * @return PayoutSummary[] indexed by reference.
     */
    public function fetchPayoutSummaries(
        ?DateTimeImmutable $start_date = null,
        ?DateTimeImmutable $end_date = null,
        int $limit = 100
    ): array {
        if ($start_date === null) {
            $start_date = self::getNow()->modify('- 8 day')->setTime(0, 0, 0);
        }

        if ($end_date === null) {
            $end_date = self::getNow()->modify('- 1 day')->setTime(23, 59, 59);
        }

        try {
            $response = $this->guzzle->get(
                self::PAYOUTS_ENDPOINT,
                [
                    RequestOptions::QUERY => [
                        "start_date" => $start_date->format(DateTime::ATOM),
                        "end_date"   => $end_date->format(DateTime::ATOM),
                        "size"       => $limit,
                    ],
                ]
            );
        } catch (GuzzleException $e) {
            throw new PayoutFetchFailedException('Unable to retrieve payout summaries.', 0, $e);
        }

        $payout_arrays = Json::decodeAssociative($response->getBody()->getContents())['payouts'];

        $payouts = [];

        foreach ($payout_arrays as $payout_array) {
            $payout                           = PayoutSummary::createFromResponse($payout_array);
            $payouts[$payout->getReference()] = $payout;
        }

        return $payouts;
    }

    /**
     * @return PayoutTransaction[]
     */
    public function fetchTransactions(string $payout_reference): array
    {
        try {
            $transactions = [];

            do {
                $response = $this->guzzle->get(
                    self::TRANSACTIONS_ENDPOINT,
                    [
                        RequestOptions::QUERY => [
                            'payment_reference' => $payout_reference,
                            'size'              => 10000,
                            'offset'            => $next_offset ?? 0,
                        ],
                    ]
                );

                $response_array = Json::decodeAssociative($response->getBody()->getContents());

                foreach ($response_array['transactions'] as $transaction_array) {
                    $transactions[] = PayoutTransaction::createFromResponse($transaction_array);
                }

                $next_offset = $response_array['pagination']['offset'] + $response_array['pagination']['count'];
            } while ($next_offset < $response_array['pagination']['total']);
        } catch (GuzzleException $e) {
            throw new PayoutFetchFailedException(sprintf('Unable to retrieve transactions for payout %s.', $payout_reference), 0, $e);
        }

        return $transactions;
    }

    public function fetchPayout(string $payout_reference): Payout
    {
        try {
            $response = $this->guzzle->get(sprintf('%s/%s', self::PAYOUTS_ENDPOINT, $payout_reference));
        } catch (GuzzleException $e) {
            throw new PayoutFetchFailedException(sprintf('Unable to retrieve transactions for payout %s.', $payout_reference), 0, $e);
        }

        return new Payout(
            PayoutSummary::createFromResponse(Json::decodeAssociative($response->getBody()->getContents())),
            ...$this->fetchTransactions($payout_reference)
        );
    }

    private function getAuthorizationHeader(): string
    {
        return 'Basic ' . base64_encode(sprintf(
            '%s:%s',
            $this->klarna_config->getUsername(),
            $this->klarna_config->getPassword()
        ));
    }
}
