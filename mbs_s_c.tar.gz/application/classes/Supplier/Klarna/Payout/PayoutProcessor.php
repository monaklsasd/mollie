<?php

declare(strict_types=1);

namespace Supplier\Klarna\Payout;

use App\Entity\Supplier\Klarna\Capture as CaptureEntity;
use App\Entity\Supplier\Klarna\Payout as PayoutEntity;
use App\Repository\Supplier\Klarna\PayoutRepository;
use BankAccounts\Smp\KlarnaAccount;
use Helper\Database\TransactionCoordinator;
use Supplier\Klarna\Payout\Response\Payout;
use Supplier\Klarna\Payout\Response\PayoutTransaction;
use Throwable;
use TransactionHandlers\TransactionHandlerCoordinator;

class PayoutProcessor
{
    /** @var PayoutRepository */
    private $repository;

    /** @var TransactionCoordinator */
    private $transaction_coordinator;

    /** @var ZeroAmountPayoutTransactionCreator */
    private $zero_amount_payout_transaction_creator;

    /** @var TransactionHandlerCoordinator */
    private $transaction_handler_coordinator;

    public function __construct(
        PayoutRepository $repository,
        TransactionCoordinator $transaction_coordinator,
        ZeroAmountPayoutTransactionCreator $zero_amount_payout_transaction_creator,
        TransactionHandlerCoordinator $transaction_handler_coordinator
    ) {
        $this->repository                             = $repository;
        $this->transaction_coordinator                = $transaction_coordinator;
        $this->zero_amount_payout_transaction_creator = $zero_amount_payout_transaction_creator;
        $this->transaction_handler_coordinator        = $transaction_handler_coordinator;
    }

    public function processPayout(Payout $summary): PayoutEntity
    {
        $payout = $this->createPayoutEntity($summary);

        foreach ($summary->getTransactions() as $transaction) {
            $payout->addCapture($this->createCaptureModel($transaction));
        }

        try {
            $this->transaction_coordinator->begin();
            $this->repository->save($payout);

            /*
             * When a settlement sum is zero no transaction will come in on our account, but we need one to expand the payout.
             * We'll add a € 0,00 Top-level transaction to the statement manually and rerun the handlers if they have already run.
             */
            if ($payout->getSettlementAmount()->isZero() && !$payout->isEmpty()) {
                $transaction = $this->zero_amount_payout_transaction_creator->createTransactionForPayout($payout);
                $transaction->saveOrDie();

                $klarna_handlers = KlarnaAccount::getTransactionHandlerClasses();
                $this->transaction_handler_coordinator->rerunHandler($transaction->getStatement(), reset($klarna_handlers));
            }

            $this->transaction_coordinator->commit();
        } catch (Throwable $e) {
            $this->transaction_coordinator->rollback();

            throw $e;
        }

        return $payout;
    }

    private function createPayoutEntity(Payout $payout): PayoutEntity
    {
        return new PayoutEntity(
            $payout->getReference(),
            $payout->getPayoutDate(),
            $payout->getSettlementAmount(),
            $payout->getTaxAmount(),
            $payout->getSaleAmount(),
            $payout->getFeeAmount(),
            $payout->getReturnAmount(),
            $payout->getReversalAmount(),
            $payout->getCommissionAmount(),
            $payout->getHoldbackAmount(),
            $payout->getRepayAmount(),
            $payout->getReleaseAmount(),
            $payout->getCorrectionAmount()
        );
    }

    private function createCaptureModel(PayoutTransaction $transaction): CaptureEntity
    {
        return new CaptureEntity(
            $transaction->getId(),
            $transaction->getType(),
            $transaction->getAmount(),
            $transaction->getOrderId(),
            $transaction->getShortOrderId(),
            $transaction->getPurchaseCountry(),
            $transaction->getCaptureAt(),
            $transaction->getSaleAt(),
            $transaction->getMerchantReference1(),
            $transaction->getMerchantReference2()
        );
    }
}
