<?php

declare(strict_types=1);

namespace Supplier\Klarna\Payout\Response;

use MyCLabs\Enum\Enum;

/**
 * The different types of transactions we receive in a payout from Klarna
 *
 * The string values match the values used by the Klarna APIs.
 *
 * @method static self COMMISSION()
 * @method static self CORRECTION()
 * @method static self FEE()
 * @method static self RETURN()
 * @method static self REVERSAL()
 * @method static self REVERSAL_MERCHANT_PROTECTION()
 * @method static self SALE()
 */
final class PayoutTransactionType extends Enum
{
    protected const COMMISSION                   = 'COMMISSION';
    protected const CORRECTION                   = 'CORRECTION';
    protected const FEE                          = 'FEE';
    protected const RETURN                       = 'RETURN';
    protected const REVERSAL                     = 'REVERSAL';
    protected const REVERSAL_MERCHANT_PROTECTION = 'REVERSAL_MERCHANT_PROTECTION';
    protected const SALE                         = 'SALE';

    public static function getRefundTypes(): array
    {
        return [
            self::RETURN(),
            self::REVERSAL(),
            self::REVERSAL_MERCHANT_PROTECTION(),
        ];
    }

    public static function getNegativeTypes(): array
    {
        return [
            self::RETURN(),
            self::REVERSAL(),
            self::FEE(),
        ];
    }

    public static function isRefundType(self $type): bool
    {
        foreach (self::getRefundTypes() as $refund_type) {
            if ($type->equals($refund_type)) {
                return true;
            }
        }

        return false;
    }

    public static function isNegativeType(self $type): bool
    {
        foreach (self::getNegativeTypes() as $negative_type) {
            if ($type->equals($negative_type)) {
                return true;
            }
        }

        return false;
    }
}
