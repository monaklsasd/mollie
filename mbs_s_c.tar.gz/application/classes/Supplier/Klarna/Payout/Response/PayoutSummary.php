<?php

declare(strict_types=1);

namespace Supplier\Klarna\Payout\Response;

use App\Util\DateTime\Utc;
use Core\Localization\Localizer;
use DateTimeImmutable;
use Money\Currency;
use Money\Money;
use Supplier\Klarna\Exceptions\PayoutAmountMismatchException;

class PayoutSummary
{
    use Utc;

    /** @var string */
    private $reference;

    /** @var DateTimeImmutable */
    private $payout_date;

    /** @var Money */
    private $settlement_amount;

    /** @var Money */
    private $sale_amount;

    /** @var Money */
    private $return_amount;

    /** @var Money */
    private $reversal_amount;

    /** @var Money */
    private $fee_amount;

    /** @var Money */
    private $fee_correction_amount;

    /** @var Money */
    private $commission_amount;

    /** @var Money */
    private $repay_amount;

    /** @var Money */
    private $release_amount;

    /** @var Money */
    private $holdback_amount;

    /** @var Money */
    private $tax_amount;

    /** @var Money */
    private $correction_amount;

    public function __construct(
        string $reference,
        DateTimeImmutable $payout_date,
        Money $settlement_amount,
        Money $sale_amount,
        Money $return_amount,
        Money $reversal_amount,
        Money $fee_amount,
        Money $fee_correction_amount,
        Money $commission_amount,
        Money $repay_amount,
        Money $release_amount,
        Money $holdback_amount,
        Money $tax_amount,
        Money $correction_amount
    ) {
        $this->reference             = $reference;
        $this->payout_date           = $payout_date;
        $this->settlement_amount     = $settlement_amount;
        $this->sale_amount           = $sale_amount;
        $this->return_amount         = $return_amount;
        $this->reversal_amount       = $reversal_amount;
        $this->fee_amount            = $fee_amount;
        $this->fee_correction_amount = $fee_correction_amount;
        $this->commission_amount     = $commission_amount;
        $this->repay_amount          = $repay_amount;
        $this->release_amount        = $release_amount;
        $this->holdback_amount       = $holdback_amount;
        $this->tax_amount            = $tax_amount;
        $this->correction_amount     = $correction_amount;
    }

    public static function createFromResponse(
        array $response
    ): PayoutSummary {
        $currency = new Currency($response['currency_code']);

        return new self(
            $response['payment_reference'],
            self::toDateTime($response['payout_date']),
            new Money($response['totals']['settlement_amount'], $currency),
            new Money($response['totals']['sale_amount'], $currency),
            new Money($response['totals']['return_amount'], $currency),
            new Money($response['totals']['reversal_amount'], $currency),
            new Money($response['totals']['fee_amount'], $currency),
            new Money($response['totals']['fee_correction_amount'], $currency),
            new Money($response['totals']['commission_amount'], $currency),
            new Money($response['totals']['repay_amount'], $currency),
            new Money($response['totals']['release_amount'], $currency),
            new Money($response['totals']['holdback_amount'], $currency),
            new Money($response['totals']['tax_amount'], $currency),
            new Money($response['totals']['correction_amount'] ?? 0, $currency)
        );
    }

    public function getReference(): string
    {
        return $this->reference;
    }

    public function getPayoutDate(): DateTimeImmutable
    {
        return $this->payout_date;
    }

    public function getCurrency(): Currency
    {
        return $this->settlement_amount->getCurrency();
    }

    public function getSettlementAmount(): Money
    {
        return $this->settlement_amount;
    }

    public function getCommissionAmount(): Money
    {
        return $this->commission_amount;
    }

    public function getRepayAmount(): Money
    {
        return $this->repay_amount;
    }

    public function getSaleAmount(): Money
    {
        return $this->sale_amount;
    }

    public function getHoldbackAmount(): Money
    {
        return $this->holdback_amount;
    }

    public function getTaxAmount(): Money
    {
        return $this->tax_amount;
    }

    public function getFeeCorrectionAmount(): Money
    {
        return $this->fee_correction_amount;
    }

    public function getReversalAmount(): Money
    {
        return $this->reversal_amount;
    }

    public function getReleaseAmount(): Money
    {
        return $this->release_amount;
    }

    public function getReturnAmount(): Money
    {
        return $this->return_amount;
    }

    public function getFeeAmount(): Money
    {
        return $this->fee_amount;
    }

    public function getCorrectionAmount(): Money
    {
        return $this->correction_amount;
    }

    public function assertTotalsAreCorrect(): void
    {
        if (!$this->getFeeCorrectionAmount()->isZero()) {
            throw new PayoutAmountMismatchException(sprintf(
                'The FeeCorrectionAmount of Klarna Payout %s was not zero, but %s. It is a deprecated field and not supported in our system. We would not know how to deal with this field when it is not 0.',
                $this->getReference(),
                Localizer::formatMoney($this->getFeeCorrectionAmount())
            ));
        }

        $settlement_total = (new Money(0, $this->getCurrency()))
            ->add($this->getSaleAmount())
            ->add($this->getCommissionAmount())
            ->add($this->getReleaseAmount())
            ->add($this->getCorrectionAmount())
            ->subtract($this->getFeeAmount())
            ->subtract($this->getReturnAmount())
            ->subtract($this->getReversalAmount())
            ->subtract($this->getHoldbackAmount())
            ->subtract($this->getRepayAmount())
            ->subtract($this->getTaxAmount());

        if (!$this->getSettlementAmount()->equals($settlement_total)) {
            throw new PayoutAmountMismatchException(sprintf(
                'The reported settlement total of Klarna Payout %s doesn\'t match the sum of the other totals. The reported total is %s, the summed total is %s. The difference is %s.',
                $this->getReference(),
                Localizer::formatMoney($this->getSettlementAmount()),
                Localizer::formatMoney($settlement_total),
                Localizer::formatMoney($this->getSettlementAmount()->subtract($settlement_total)->absolute())
            ));
        }
    }
}
