<?php

declare(strict_types=1);

namespace Supplier\Klarna\Payout\Response;

use App\Util\DateTime\Utc;
use DateTimeImmutable;
use InvalidArgumentException;
use Money\Currency;
use Money\Money;

class PayoutTransaction
{
    use Utc;

    /** @var PayoutTransactionType */
    private $type;

    /** @var Money */
    private $amount;

    /** @var string */
    private $order_id;

    /** @var string|null */
    private $short_order_id;

    /** @var string */
    private $purchase_country;

    /** @var DateTimeImmutable */
    private $capture_at;

    /** @var DateTimeImmutable */
    private $sale_at;

    /** @var string|null */
    private $capture_id;

    /** @var string|null */
    private $refund_id;

    /** @var string|null */
    private $merchant_reference_1;

    /** @var string|null */
    private $merchant_reference_2;

    public function __construct(
        PayoutTransactionType $type,
        Money $amount,
        string $order_id,
        ?string $short_order_id,
        string $purchase_country,
        DateTimeImmutable $capture_at,
        DateTimeImmutable $sale_at,
        ?string $capture_id,
        ?string $refund_id,
        ?string $merchant_reference_1,
        ?string $merchant_reference_2
    ) {
        if ($refund_id === null && PayoutTransactionType::RETURN()->equals($type)) {
            throw new InvalidArgumentException(sprintf(
                'For %s transactions, a refund ID is required.',
                $type->getValue()
            ));
        }

        $this->type                 = $type;
        $this->amount               = $amount;
        $this->order_id             = $order_id;
        $this->short_order_id       = $short_order_id;
        $this->purchase_country     = $purchase_country;
        $this->capture_at           = $capture_at;
        $this->sale_at              = $sale_at;
        $this->capture_id           = $capture_id;
        $this->refund_id            = $refund_id;
        $this->merchant_reference_1 = $merchant_reference_1;
        $this->merchant_reference_2 = $merchant_reference_2;
    }

    public static function createFromResponse(array $response): self
    {
        $type   = new PayoutTransactionType($response['type']);
        $amount = new Money($response['amount'], new Currency($response['currency_code']));

        return new self(
            $type,
            $amount,
            $response['order_id'],
            $response['short_order_id'] ?? null,
            $response['purchase_country'],
            self::toDateTime($response['capture_date']),
            self::toDateTime($response['sale_date']),
            $response['capture_id'] ?? null,
            $response['refund_id'] ?? null,
            $response['merchant_reference1'] ?? null,
            $response['merchant_reference2'] ?? null
        );
    }

    public function getId(): string
    {
        if (PayoutTransactionType::isRefundType($this->type)) {
            return $this->getRefundId();
        }

        return $this->getCaptureId();
    }

    public function getType(): PayoutTransactionType
    {
        return $this->type;
    }

    public function getAmount(): Money
    {
        return $this->amount;
    }

    public function getOrderId(): string
    {
        return $this->order_id;
    }

    public function getShortOrderId(): ?string
    {
        return $this->short_order_id;
    }

    public function getPurchaseCountry(): string
    {
        return $this->purchase_country;
    }

    public function getCaptureAt(): DateTimeImmutable
    {
        return $this->capture_at;
    }

    public function getSaleAt(): DateTimeImmutable
    {
        return $this->sale_at;
    }

    public function getCaptureId(): ?string
    {
        return $this->capture_id;
    }

    public function getRefundId(): ?string
    {
        if ($this->refund_id === null
            && (
                PayoutTransactionType::REVERSAL()->equals($this->type)
                || PayoutTransactionType::REVERSAL_MERCHANT_PROTECTION()->equals($this->type)
            )
        ) {
            /*
             * This is a very special case:
             *
             * Reversals without a refund_id can happen, and are caused by a non-standard manual (fraud protection) flow at Klarna.
             * By their advice, we use the order_id to uniquely identify these transactions across our systems.
             *
             * There currently is no workflow on their side that could cause two of of these reversals per order:
             *
             *   Mandy Meuleners [2019-02-05 14:16:31]: Double checked internally and confirmed that this won't ever happen twice
             */
            return $this->order_id;
        }

        return $this->refund_id;
    }

    public function getMerchantReference1(): ?string
    {
        return $this->merchant_reference_1;
    }

    public function getMerchantReference2(): ?string
    {
        return $this->merchant_reference_2;
    }
}
