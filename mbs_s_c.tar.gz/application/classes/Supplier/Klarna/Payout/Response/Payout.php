<?php

declare(strict_types=1);

namespace Supplier\Klarna\Payout\Response;

use Core\Localization\Localizer;
use DateTimeImmutable;
use Money\Currency;
use Money\Money;
use Supplier\Klarna\Exceptions\PayoutAmountMismatchException;

class Payout
{
    /** @var PayoutSummary */
    private $payoutSummary;

    /** @var PayoutTransaction[] */
    private $transactions = [];

    public function __construct(
        PayoutSummary $payoutSummary,
        PayoutTransaction ...$transactions
    ) {
        $this->payoutSummary = $payoutSummary;
        $this->transactions  = array_values($transactions);

        $this->payoutSummary->assertTotalsAreCorrect();
        $this->assertTransactionTotalsAreCorrect();
    }

    public function getReference(): string
    {
        return $this->payoutSummary->getReference();
    }

    public function getPayoutDate(): DateTimeImmutable
    {
        return $this->payoutSummary->getPayoutDate();
    }

    public function getCurrency(): Currency
    {
        return $this->payoutSummary->getCurrency();
    }

    public function getSettlementAmount(): Money
    {
        return $this->payoutSummary->getSettlementAmount();
    }

    public function getCommissionAmount(): Money
    {
        return $this->payoutSummary->getCommissionAmount();
    }

    public function getRepayAmount(): Money
    {
        return $this->payoutSummary->getRepayAmount();
    }

    public function getSaleAmount(): Money
    {
        return $this->payoutSummary->getSaleAmount();
    }

    public function getHoldbackAmount(): Money
    {
        return $this->payoutSummary->getHoldbackAmount();
    }

    public function getTaxAmount(): Money
    {
        return $this->payoutSummary->getTaxAmount();
    }

    public function getFeeCorrectionAmount(): Money
    {
        return $this->payoutSummary->getFeeCorrectionAmount();
    }

    public function getReversalAmount(): Money
    {
        return $this->payoutSummary->getReversalAmount();
    }

    public function getReleaseAmount(): Money
    {
        return $this->payoutSummary->getReleaseAmount();
    }

    public function getReturnAmount(): Money
    {
        return $this->payoutSummary->getReturnAmount();
    }

    public function getFeeAmount(): Money
    {
        return $this->payoutSummary->getFeeAmount();
    }

    public function getCorrectionAmount(): Money
    {
        return $this->payoutSummary->getCorrectionAmount();
    }

    /**
     * @return PayoutTransaction[]
     */
    public function getTransactions(): array
    {
        return $this->transactions;
    }

    private function assertTransactionTotalsAreCorrect(): void
    {
        /** @var Money[][] $totals */
        $totals = [
            PayoutTransactionType::SALE()->getValue() => [
                $this->getSaleAmount(),
                new Money(0, $this->getCurrency()),
            ],
            PayoutTransactionType::FEE()->getValue() => [
                $this->getFeeAmount(),
                new Money(0, $this->getCurrency()),
            ],
            PayoutTransactionType::RETURN()->getValue() => [
                $this->getReturnAmount(),
                new Money(0, $this->getCurrency()),
            ],
            PayoutTransactionType::REVERSAL()->getValue() => [
                $this->getReversalAmount(),
                new Money(0, $this->getCurrency()),
            ],
            PayoutTransactionType::COMMISSION()->getValue() => [
                $this->getCommissionAmount(),
                new Money(0, $this->getCurrency()),
            ],
            PayoutTransactionType::CORRECTION()->getValue() => [
                $this->getCorrectionAmount(),
                new Money(0, $this->getCurrency()),
            ],
        ];

        foreach ($this->transactions as $transaction) {
            $type   = $transaction->getType();
            $amount = $transaction->getAmount();

            if ($transaction->getType()->equals(PayoutTransactionType::REVERSAL_MERCHANT_PROTECTION())) {
                $type   = PayoutTransactionType::REVERSAL();
                $amount = $amount->negative();
            }

            $totals[$type->getValue()][1] = $totals[$type->getValue()][1]->add($amount);
        }

        /** @var Money $expected_amount */
        /** @var Money $actual_amount */
        foreach ($totals as $capture_type => [$expected_amount, $actual_amount]) {
            if (!$expected_amount->equals($actual_amount)) {
                throw new PayoutAmountMismatchException(sprintf(
                    'The total_%s_amount and the total of the transactions of this type in Klarna Payout %s do not match. The reported amount is %s, the calculated amount is %s. The difference is %s.',
                    $capture_type,
                    $this->getReference(),
                    Localizer::formatMoney($expected_amount),
                    Localizer::formatMoney($actual_amount),
                    Localizer::formatMoney($expected_amount->subtract($actual_amount)->absolute())
                ));
            }
        }
    }
}
