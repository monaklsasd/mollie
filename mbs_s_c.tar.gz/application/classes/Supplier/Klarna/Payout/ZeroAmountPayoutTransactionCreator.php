<?php

declare(strict_types=1);

namespace Supplier\Klarna\Payout;

use App\Entity\Supplier\Klarna\Payout;
use BankAccounts\Smp\KlarnaAccount;
use Core\Localization\Localizer;
use Helper\DateTime\Now;
use InvalidArgumentException;
use LogicException;
use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use Orm\ModelFactory;
use Orm\Repositories\BankstatementRepository;
use Orm\Repositories\BanktransactionRepository;

class ZeroAmountPayoutTransactionCreator
{
    use Now;

    /** @var ModelFactory */
    private $model_factory;

    /** @var BankstatementRepository */
    private $statement_repository;

    /** @var BanktransactionRepository */
    private $transaction_repository;

    public function __construct(
        ModelFactory $model_factory,
        BankstatementRepository $statement_repository,
        BanktransactionRepository $transaction_repository
    ) {
        $this->model_factory          = $model_factory;
        $this->statement_repository   = $statement_repository;
        $this->transaction_repository = $transaction_repository;
    }

    public function createTransactionForPayout(Payout $payout): Model_Banktransaction
    {
        if (!$payout->getSettlementAmount()->isZero()) {
            throw new InvalidArgumentException(sprintf(
                'Payout %s total is not 0 but %s. Transaction should be on statement.',
                $payout->getReference(),
                Localizer::formatMoney($payout->getSettlementAmount())
            ));
        }

        if ($payout->isEmpty()) {
            throw new InvalidArgumentException(sprintf(
                'Payout %s is empty, no transaction needed.',
                $payout->getReference()
            ));
        }

        $statement = $this->statement_repository->getByBankAccountAndDate(
            KlarnaAccount::getInstance(),
            $payout->getDate()->setTimezone(self::getSystemTimeZone())
        );

        foreach ($this->transaction_repository->yieldAllByStatementId((int)$statement->getPrimaryKey()) as $transaction
        ) {
            if ($transaction->getAmount()->isZero()
                && $transaction->hasAnyOfTags([
                    TransactionTags::TAG_KLARNA_SETTLEMENT,
                    TransactionTags::TAG_KLARNA_SETTLEMENT_EXPANDED,
                ])
                && $transaction->getTagData()['payout_reference'] ?? $payout->getReference() === ''
            ) {
                throw new LogicException(sprintf(
                    'Zero-amount batch-transaction already created for payout %s: #%d.',
                    $payout->getReference(),
                    $transaction->getPrimaryKey()
                ));
            }
        }

        $transaction = $this->model_factory->create(Model_Banktransaction::class);
        $transaction->setBankAccount($statement->getBankAccount());
        $transaction->setStatement($statement);
        $transaction->setEntryDate($statement->getStatementDate());
        $transaction->setValueDate($statement->getStatementDate());
        $transaction->setDescription(sprintf('ZERO-AMOUNT PAYOUT KLARNA:%s', $payout->getReference()));

        $transaction->setAmount($payout->getSettlementAmount());
        $transaction->setTags([TransactionTags::TAG_KLARNA_SETTLEMENT]);
        $transaction->setTagData(['payout_reference' => $payout->getReference()]);

        return $transaction;
    }
}
