<?php

declare(strict_types=1);

namespace Supplier;

use Core\Json;
use GuzzleHttp\Exception\RequestException;
use GuzzleHttp\Exception\ServerException;
use GuzzleHttp\HandlerStack;
use GuzzleHttp\Middleware;
use Mollie\Cryptography\RsaKey;
use Mollie\Xml\Exception\SigningFailedException;
use Mollie\Xml\Exception\XmlException;
use Mollie\Xml\Signature\DocumentVerifier;
use Mollie\Xml\XmlObject;
use Psr\Http\Message\RequestInterface;
use Psr\Http\Message\ResponseInterface;
use SimpleXMLElement;
use function GuzzleHttp\Psr7\stream_for;
use function strlen;

trait XmlDSigMiddleware
{
    protected static function registerXmlDSigMiddleware(
        HandlerStack $handler,
        DocumentVerifier $document_verifier,
        RsaKey $private_key
    ) {
        // Used to pass the last request to the mapResponse handler so we can create descriptive exceptions.
        $last_request = null;

        // create signed xml with serialized php arrays from supplied json
        $handler->push(Middleware::mapRequest(function (RequestInterface $request) use (
            $document_verifier,
            $private_key,
            &$last_request
        ) {
            try {
                $xmlsec_doc = $document_verifier->createSignedXml(
                    $private_key,
                    serialize(Json::decodeAssociative((string)$request->getBody()))
                );
            } catch (SigningFailedException $e) {
                throw new RequestException(
                    sprintf('Error signing XML message: %s', $e->getMessage()),
                    $request,
                    null,
                    $e
                );
            }

            $last_request = $request
                ->withBody(\GuzzleHttp\Psr7\stream_for($xmlsec_doc))
                ->withHeader('Content-Type', 'text/xml; charset=utf-8')
                ->withHeader('Accept', 'text/xml')
                ->withHeader('Content-Length', strlen($xmlsec_doc));

            return $last_request;
        }), 'json-to-mollie-xml');

        // validate & convert signed xml to json.
        $handler->push(Middleware::mapResponse(function (ResponseInterface $response) use (&$last_request) {
            $body = (string)$response->getBody();

            try {
                $response_data = self::responseXmlToArray(XmlObject::fromString($body));
                $new_response = $response->withBody(stream_for(Json::encode($response_data)));

                if (isset($response_data['item']['errorcode'], $response_data['item']['message'])) {
                    throw new ServerException($response_data['item']['message'], $last_request, $new_response);
                }

                if (isset($response_data['item']['success']) && (string)$response_data['item']['success'] !== 'true') {
                    throw new ServerException(sprintf(
                        'Request to %s could not be succesfully processed.',
                        (string)$last_request->getUri()
                    ), $last_request, $new_response);
                }

                return $new_response;
            } catch (XmlException $e) {
                throw new ServerException(
                    sprintf('Unable to interpret Mollie response to API call, invalid response is: %s', $body),
                    $last_request,
                    $response
                );
            }
        }), 'mollie-xml-to-json');
    }

    /**
     * This method does the reverse of Mollie's Controller_Api_Base::_renderItems
     * It transforms the supplied xml back to the original array.
     *
     * Also works for mccs
     *
     * @return array|string
     */
    protected static function responseXmlToArray(SimpleXMLElement $xml, &$root = [])
    {
        if ($xml->count() === 0) {
            $root = (string)$xml;
        }

        $enumerate = false;
        $last_name = null;

        foreach ($xml->children() as $child) {
            $name = $child->getName();

            if ($name === $last_name) {
                $enumerate = true;

                break;
            }
            $last_name = $name;
        }

        $index = 0;

        foreach ($xml->children() as $name => $child) {
            if ($enumerate) {
                $name .= '#' . $index++;
            }
            self::responseXmlToArray($child, $root[$name]);
        }

        return $root;
    }
}
