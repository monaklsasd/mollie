<?php

declare(strict_types=1);

namespace Supplier\Mccs\Amex\Settlement;

use Core\Money\Currencies;
use Money\Money;
use Webmozart\Assert\Assert;
use function Core\Money\money_from_string;
use function is_string;

class Batch
{
    /** @var Money */
    protected $total_gross_calculated_amount;

    /** @var Money */
    protected $total_gross_declared_amount;

    /** @var Money */
    protected $total_net_amount;

    /** @var Money */
    protected $total_fee_amount;

    /** @var Charge[] */
    protected $charges = [];

    public function __construct(
        Money $total_gross_calculated_amount,
        Money $total_gross_declared_amount,
        Money $total_net_amount,
        Money $total_fee_amount,
        array $charges
    ) {
        Assert::allIsInstanceOf($charges, Charge::class);

        $this->total_gross_calculated_amount = $total_gross_calculated_amount;
        $this->total_gross_declared_amount   = $total_gross_declared_amount;
        $this->total_net_amount              = $total_net_amount;
        $this->total_fee_amount              = $total_fee_amount;
        $this->charges                       = array_values($charges);
    }

    public static function createFromResponse(array $response): self
    {
        // Empty xml nodes are returned as an empty string or whitespace characters, not [].
        if (is_string($response['charges']) && trim($response['charges']) === '') {
            $response['charges'] = [];
        }

        return new self(
            money_from_string($response['total_gross_calculated_amount'], Currencies::EUR()),
            money_from_string($response['total_gross_declared_amount'], Currencies::EUR()),
            money_from_string($response['total_net_amount'], Currencies::EUR()),
            money_from_string($response['total_fee_amount'], Currencies::EUR()),
            array_map(function (array $charge) {
                return Charge::createFromResponse($charge);
            }, $response['charges'])
        );
    }

    public function getTotalGrossCalculatedAmount(): Money
    {
        return $this->total_gross_calculated_amount;
    }

    public function getTotalGrossDeclaredAmount(): Money
    {
        return $this->total_gross_declared_amount;
    }

    public function getTotalNetAmount(): Money
    {
        return $this->total_net_amount;
    }

    public function getTotalFeeAmount(): Money
    {
        return $this->total_fee_amount;
    }

    /**
     * @return Charge[]
     */
    public function getCharges(): array
    {
        return $this->charges;
    }
}
