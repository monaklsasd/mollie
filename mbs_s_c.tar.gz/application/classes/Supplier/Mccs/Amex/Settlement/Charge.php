<?php

declare(strict_types=1);

namespace Supplier\Mccs\Amex\Settlement;

use Core\Money\Currencies;
use DateTimeImmutable;
use Helper\DateTime\Utc;
use Money\Money;
use function Core\Money\money_from_string;

class Charge
{
    use Utc;

    /** @var string */
    protected $type;

    /** @var DateTimeImmutable */
    protected $date;

    /** @var Money */
    protected $amount;

    /** @var string */
    protected $invoice_reference_id;

    /** @var string */
    protected $card_holder;

    /** @var string */
    protected $mccs_transaction_id;

    /** @var string */
    protected $description;

    public function __construct(
        DateTimeImmutable $date,
        Money $amount,
        string $invoice_reference_id,
        string $card_holder,
        string $mccs_transaction_id,
        string $description
    ) {
        $this->type                 = $amount->isNegative() ? 'refund' : 'payment';
        $this->date                 = $date;
        $this->amount               = $amount;
        $this->invoice_reference_id = trim($invoice_reference_id);
        $this->card_holder          = trim($card_holder);
        $this->mccs_transaction_id  = trim($mccs_transaction_id);
        $this->description          = trim($description);
    }

    public static function createFromResponse(array $response): self
    {
        return new self(
            self::toDateTime((string)$response['charge_date'], '!Y-m-d'),
            money_from_string($response['amount'], Currencies::EUR()),
            $response['invoice_reference_id'],
            $response['card_holder'] ?? '',
            $response['mccs_transaction_id'],
            $response['description']
        );
    }

    public function getType(): string
    {
        return $this->type;
    }

    public function getDate(): DateTimeImmutable
    {
        return $this->date;
    }

    public function getAmount(): Money
    {
        return $this->amount;
    }

    public function getInvoiceReferenceId(): string
    {
        return $this->invoice_reference_id;
    }

    public function getCardHolder(): string
    {
        return $this->card_holder;
    }

    public function getMccsTransactionId(): string
    {
        return $this->mccs_transaction_id;
    }

    public function getDescription(): string
    {
        return $this->description;
    }
}
