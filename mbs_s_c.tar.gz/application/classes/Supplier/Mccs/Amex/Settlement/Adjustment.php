<?php

declare(strict_types=1);

namespace Supplier\Mccs\Amex\Settlement;

use Core\Money\Currencies;
use Money\Money;
use function Core\Money\money_from_string;

class Adjustment
{
    public const TYPE_ADJUSTMENT = 'adjustment';
    public const TYPE_CHARGEBACK = 'chargeback';

    /** @var Money */
    protected $gross_amount;

    /** @var Money */
    protected $net_amount;

    /** @var Money */
    protected $fee_amount;

    /** @var Money */
    protected $tax_amount;

    /** @var string */
    protected $record_code;

    /** @var string */
    protected $description;

    public function __construct(
        Money $gross_amount,
        Money $net_amount,
        Money $fee_amount,
        Money $tax_amount,
        string $record_code,
        string $description
    ) {
        $this->gross_amount = $gross_amount;
        $this->net_amount   = $net_amount;
        $this->fee_amount   = $fee_amount;
        $this->tax_amount   = $tax_amount;
        $this->record_code  = trim($record_code);
        $this->description  = trim($description);
    }

    public static function createFromResponse(array $response): self
    {
        return new self(
            money_from_string($response['gross_amount'], Currencies::EUR()),
            money_from_string($response['net_amount'], Currencies::EUR()),
            money_from_string($response['fee_amount'], Currencies::EUR()),
            money_from_string($response['tax_amount'], Currencies::EUR()),
            $response['record_code'],
            $response['description']
        );
    }

    public function getRecordType(): ?string
    {
        if (preg_match('/^ADJ[0-9]+$/', $this->record_code)) {
            return self::TYPE_ADJUSTMENT;
        }

        if (preg_match('/^CBK[0-9]+$/', $this->record_code)) {
            return self::TYPE_CHARGEBACK;
        }

        return null;
    }

    public function isAnnualFee(): bool
    {
        if ($this->getRecordType() !== static::TYPE_ADJUSTMENT) {
            return false;
        }

        if ($this->description !== 'ANNUAL FEE FOR MULTI CURRENCY PROCESSING') {
            return false;
        }

        return true;
    }

    public function isChargebackOrChargebackReversal(): bool
    {
        return $this->getRecordType() === static::TYPE_CHARGEBACK;
    }

    public function getGrossAmount(): Money
    {
        return $this->gross_amount;
    }

    public function getNetAmount(): Money
    {
        return $this->net_amount;
    }

    public function getFeeAmount(): Money
    {
        return $this->fee_amount;
    }

    public function getTaxAmount(): Money
    {
        return $this->tax_amount;
    }

    public function getRecordCode(): string
    {
        return $this->record_code;
    }

    public function getDescription(): string
    {
        return $this->description;
    }
}
