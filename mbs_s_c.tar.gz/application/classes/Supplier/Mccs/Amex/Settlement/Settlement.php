<?php

declare(strict_types=1);

namespace Supplier\Mccs\Amex\Settlement;

use Core\Money\Currencies;
use Money\Money;
use Webmozart\Assert\Assert;
use function Core\Money\money_from_string;
use function is_string;

class Settlement
{
    /** @var Money */
    protected $total_gross_amount;

    /** @var Money */
    protected $total_net_amount;

    /** @var Money */
    protected $total_fee_amount;

    /** @var Money */
    protected $total_tax_amount;

    /** @var Money */
    protected $total_chargeback_amount;

    /** @var Batch[] */
    protected $batches = [];

    /** @var Adjustment[] */
    protected $adjustments = [];

    public function __construct(
        Money $total_gross_amount,
        Money $total_net_amount,
        Money $total_fee_amount,
        Money $total_tax_amount,
        Money $total_chargeback_amount,
        array $batches,
        array $adjustments
    ) {
        Assert::allIsInstanceOf($batches, Batch::class);
        Assert::allIsInstanceOf($adjustments, Adjustment::class);

        $this->total_gross_amount      = $total_gross_amount;
        $this->total_net_amount        = $total_net_amount;
        $this->total_fee_amount        = $total_fee_amount;
        $this->total_tax_amount        = $total_tax_amount;
        $this->total_chargeback_amount = $total_chargeback_amount;
        $this->batches                 = array_values($batches);
        $this->adjustments             = array_values($adjustments);
    }

    public static function createFromResponse(array $response): self
    {
        // Empty xml nodes are returned as an empty string or whitespace characters, not [].
        foreach (['batches', 'adjustments'] as $key) {
            if (is_string($response[$key]) && trim($response[$key]) === '') {
                $response[$key] = [];
            }
        }

        return new self(
            money_from_string($response['total_gross_amount'], Currencies::EUR()),
            money_from_string($response['total_net_amount'], Currencies::EUR()),
            money_from_string($response['total_fee_amount'], Currencies::EUR()),
            money_from_string($response['total_tax_amount'], Currencies::EUR()),
            money_from_string($response['total_chargeback_amount'], Currencies::EUR()),
            array_map(function (array $batch): Batch {
                return Batch::createFromResponse($batch);
            }, $response['batches']),
            array_map(function (array $adjustment): Adjustment {
                return Adjustment::createFromResponse($adjustment);
            }, $response['adjustments'])
        );
    }

    public function getTotalGrossAmount(): Money
    {
        return $this->total_gross_amount;
    }

    public function getTotalNetAmount(): Money
    {
        return $this->total_net_amount;
    }

    public function getTotalFeeAmount(): Money
    {
        return $this->total_fee_amount;
    }

    public function getTotalTaxAmount(): Money
    {
        return $this->total_tax_amount;
    }

    public function getTotalChargebackAmount(): Money
    {
        return $this->total_chargeback_amount;
    }

    /**
     * @return Batch[]
     */
    public function getBatches(): array
    {
        return $this->batches;
    }

    /**
     * @return Adjustment[]
     */
    public function getAdjustments(): array
    {
        return $this->adjustments;
    }
}
