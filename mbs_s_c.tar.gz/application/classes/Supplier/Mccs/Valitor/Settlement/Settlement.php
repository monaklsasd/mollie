<?php

declare(strict_types=1);

namespace Supplier\Mccs\Valitor\Settlement;

use Core\Money\Currencies;
use InvalidArgumentException;
use Money\Money;
use function array_values;
use function Core\Money\money_from_string;
use function is_string;

class Settlement
{
    /** @var string */
    protected $reference;

    /** @var Money */
    protected $amount;

    /** @var Detail[] */
    protected $details = [];

    /** @var Transaction[] */
    protected $transactions = [];

    public function __construct(string $reference, Money $amount, array $details, array $transactions)
    {
        array_walk($details, function (Detail $detail) {
        });

        array_walk($transactions, function (Transaction $transaction) {
        });

        $this->reference    = trim($reference);
        $this->amount       = $amount;
        $this->details      = array_values($details);
        $this->transactions = array_values($transactions);
    }

    /**
     * @throws InvalidArgumentException
     */
    public static function createFromMccsSettlementInformation(array $response): self
    {
        $response = self::makeEmptyDetailsAndTransactionsAsEmptyArrays($response);

        $settlement = new self(
            $response['reference'],
            money_from_string($response['amount'], Currencies::EUR()),
            array_map(function (array $detail) {
                return Detail::createFromMccsSettlementInformation($detail);
            }, $response['details']),
            array_map(function (array $transaction) {
                return Transaction::createFromMccsSettlementInformation($transaction);
            }, $response['transactions'])
        );

        return $settlement;
    }

    /**
     * Empty xml nodes are returned as an empty string or whitespace characters, not [].
     */
    private static function makeEmptyDetailsAndTransactionsAsEmptyArrays(array $response): array
    {
        foreach (['details', 'transactions'] as $key) {
            if (is_string($response[$key]) && trim($response[$key]) === '') {
                $response[$key] = [];
            }
        }

        return $response;
    }

    public function getReference(): string
    {
        return $this->reference;
    }

    public function getAmount(): Money
    {
        return $this->amount;
    }

    /**
     * @return Detail[]
     */
    public function getDetails(): array
    {
        return $this->details;
    }

    /**
     * @return Transaction[]
     */
    public function getTransactions(): array
    {
        return $this->transactions;
    }
}
