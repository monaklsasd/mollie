<?php

declare(strict_types=1);

namespace Supplier\Mccs\Valitor\Settlement;

use Core\Money\Currencies;
use Money\Money;
use function Core\Money\money_from_string;
use function Core\Money\money_to_array;

class Detail
{
    public const DETAIL_KEY_ADDED_SUM                    = 'ADDEDS';
    public const DETAIL_KEY_MERCHANT_SERVICE_CHARGES     = 'BUMERC';
    public const DETAIL_KEY_CHARGEBACK                   = 'CHABAC';
    public const DETAIL_KEY_CHARGEBACK_FEE_AGENT         = 'CHBFAG';
    public const DETAIL_KEY_CHARGEBACK_FEE_VALITOR       = 'CHBFVI';
    public const DETAIL_KEY_COMMISSION_HIGH_RISK         = 'COMAGH';
    public const DETAIL_KEY_COMMISSION_LOW_RISK          = 'COMAGL';
    public const DETAIL_KEY_COMMISSION_MEDIUM_RISK       = 'COMAGM';
    public const DETAIL_KEY_COMMISSION_LOW_AMOUNTS       = 'COMMLA';
    public const DETAIL_KEY_DEDUCTED_SUM                 = 'DEDUCT';
    public const DETAIL_KEY_MANAGEMENT_COSTS             = 'MGCOST';
    public const DETAIL_KEY_NEGATIVE_MERCHANT_SETTLEMENT = 'NEGATI';
    public const DETAIL_KEY_NET_SETTLEMENT               = 'NETSET';
    public const DETAIL_KEY_OTHER_DEDUCTIONS             = 'OTHERF';
    public const DETAIL_KEY_PENALTY_FEE                  = 'PENALF';
    public const DETAIL_KEY_PRE_ARBITRATION              = 'PREARB';
    public const DETAIL_KEY_REFUND                       = 'REFU06';
    public const DETAIL_KEY_REGISTRATION_FEE             = 'REGFEE';
    public const DETAIL_KEY_REJECTED_TRANSACTIONS        = 'REJECT';
    public const DETAIL_KEY_RE_PRESENTMENTS              = 'REPRES';
    public const DETAIL_KEY_REVERSALS                    = 'REVERS';
    public const DETAIL_KEY_ROLLING_RELEASE              = 'ROLREL';
    public const DETAIL_KEY_ROLLING_RESERVE              = 'ROLRES';
    public const DETAIL_KEY_SALE                         = 'SALE05';
    public const DETAIL_KEY_SWIFT_FEE                    = 'SWIFTF';
    public const DETAIL_KEY_TRANSACTION_FEE_SETTLED      = 'TRFSAG';
    public const DETAIL_KEY_TRANSACTION_FEE_UNSETTLED    = 'TRFUAG';
    // As of 01-01-2018 we receive these. One for V(isa), one for M(astercard). See MCCS-18 for details.
    public const DETAIL_KEY_SCHEME_FEE = 'SCHFEE';
    // Record these lines as unknown
    public const RECORD_AS_UNKNOWN = [
        self::DETAIL_KEY_ADDED_SUM,
    ];

    /** @var string */
    protected $settlement_key;

    /** @var Money */
    protected $amount;

    /** @var string */
    protected $comment;

    public function __construct(string $settlement_key, Money $amount, string $comment)
    {
        $this->settlement_key = $settlement_key;
        $this->amount         = $amount;
        $this->comment        = $comment;
    }

    public static function createFromMccsSettlementInformation(array $response): self
    {
        return new self(
            $response['key'],
            money_from_string($response['amount'], Currencies::EUR()),
            $response['info']
        );
    }

    public function getSettlementKey(): string
    {
        return $this->settlement_key;
    }

    public function getAmount(): Money
    {
        return $this->amount;
    }

    public function getComment(): string
    {
        return $this->comment;
    }

    public function toArray(): array
    {
        return [
            'settlement_key' => $this->settlement_key,
            'amount'         => money_to_array($this->amount),
            'comment'        => $this->comment,
        ];
    }
}
