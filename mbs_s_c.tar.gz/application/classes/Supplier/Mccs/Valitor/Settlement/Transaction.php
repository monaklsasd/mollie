<?php

declare(strict_types=1);

namespace Supplier\Mccs\Valitor\Settlement;

use Core\Money\Currencies;
use DateTimeImmutable;
use Helper\DateTime\Utc;
use Money\Money;
use Webmozart\Assert\Assert;
use function Core\Money\money_from_string;

class Transaction
{
    use Utc;

    /** @var string */
    protected $code;

    /** @var Money */
    protected $amount;

    /** @var DateTimeImmutable */
    protected $date;

    /** @var string */
    protected $mccs_transaction_id;

    /** @var string */
    protected $card_holder;

    /** @var string */
    protected $description;

    public function __construct(
        string $code,
        Money $amount,
        DateTimeImmutable $date,
        string $mccs_transaction_id,
        string $card_holder,
        string $description
    ) {
        Assert::notEmpty($mccs_transaction_id);
        Assert::notEmpty($code);

        $this->code                = trim($code);
        $this->amount              = $amount;
        $this->date                = $date;
        $this->mccs_transaction_id = trim($mccs_transaction_id);
        $this->card_holder         = trim($card_holder);
        $this->description         = trim($description);
    }

    public static function createFromMccsSettlementInformation(array $response): self
    {
        return new self(
            $response['key'],
            money_from_string($response['amount'], Currencies::EUR()),
            self::toDateTime((string)$response['date'], '!Y-m-d'),
            $response['mccs_reference'],
            $response['card_holder'],
            $response['description']
        );
    }

    public function getCode(): string
    {
        return $this->code;
    }

    public function getAmount(): Money
    {
        return $this->amount;
    }

    public function getDate(): DateTimeImmutable
    {
        return $this->date;
    }

    public function getMccsTransactionId(): string
    {
        return $this->mccs_transaction_id;
    }

    public function getCardHolder(): string
    {
        return $this->card_holder;
    }

    public function getDescription(): string
    {
        return $this->description;
    }
}
