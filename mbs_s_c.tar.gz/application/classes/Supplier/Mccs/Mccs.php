<?php

declare(strict_types=1);

namespace Supplier\Mccs;

use Config_Mbs;
use Config_Mccs;
use Core\Json;
use GuzzleHttp\Client as GuzzleClient;
use GuzzleHttp\Exception\ConnectException;
use GuzzleHttp\Exception\RequestException;
use GuzzleHttp\Exception\ServerException;
use GuzzleHttp\RequestOptions;
use InvalidArgumentException;
use Model_Banktransaction;
use Mollie\Xml\Signature\DocumentVerifier;
use Supplier\Mccs\Amex\Settlement\Settlement as AmexSettlement;
use Supplier\Mccs\Valitor\Settlement\Settlement as ValitorSettlement;
use Supplier\XmlDSigMiddleware;
use function Core\Money\money_to_string;
use function is_array;
use function is_string;

/**
 * A secure way for Mollie to communicate with Mollie Credit Card System.
 */
class Mccs
{
    use XmlDSigMiddleware;

    /** Paybox reference cannot be found. */
    protected const CODE_PAYBOX_REFERENCE_NOT_FOUND = -4;
    /** Valitor settlement details cannot be found. */
    protected const CODE_VALITOR_SETTLEMENT_DETAILS_NOT_FOUND = -5;
    /** AMEX settlement details cannot be found. */
    protected const CODE_AMEX_SETTLEMENT_DETAILS_NOT_FOUND = -6;

    /** @var GuzzleClient */
    protected $guzzle;

    public function __construct(
        Config_Mbs $signing_config,
        Config_Mccs $reading_config,
        DocumentVerifier $document_verifier
    ) {
        $this->guzzle = new GuzzleClient([
            'base_uri' => $reading_config->getEndpoint(),
        ]);

        self::registerXmlDSigMiddleware(
            $this->guzzle->getConfig('handler'),
            $document_verifier,
            $signing_config->getPrivateRsaKey()
        );
    }

    public function getSupplierName(): string
    {
        return 'Mollie Credit Card System';
    }

    public function getSupplierWebsite(): string
    {
        return 'https://pay.mollie.nl/';
    }

    protected function sendRequest(string $action, array $data, int $timeout = 30): array
    {
        try {
            $response = $this->guzzle->post($action, [
                RequestOptions::CONNECT_TIMEOUT => 3,
                RequestOptions::TIMEOUT         => $timeout,
                RequestOptions::JSON            => $data,
            ]);

            $decoded_response = Json::decodeAssociative((string)$response->getBody());

            /*
             * We know Mccs only returns arrays, but occationally empty array's are returned which are are interpreted
             * as empty strings by the xml->json conversion (<?xml version="1.0"?><response></response>). We correct
             * this here.
             */
            if (is_string($decoded_response) && trim($decoded_response) === '') {
                $decoded_response = [];
            }

            if (!is_array($decoded_response)) {
                throw new MccsException(sprintf(
                    'Didn\'t get an array as response from Mccs. Response was %s.',
                    (string)$response->getBody()
                ));
            }

            return $decoded_response;
        } catch (ConnectException $e) {
            throw new MccsException(sprintf(
                'Unable to connect to Mccs %s',
                $e->getRequest()->getUri()
            ), $e->getCode(), $e);
        } catch (RequestException $e) {
            throw new MccsException(sprintf(
                'An error occurred while communicating with Mccs (%d %s %s). Got response: %s',
                $e->getResponse() ? $e->getResponse()->getStatusCode() : 0,
                $e->getRequest()->getMethod(),
                $e->getRequest()->getUri(),
                $e->getResponse() ? $e->getResponse()->getBody() : 'null'
            ), $e->getCode(), $e);
        }
    }

    /**
     * @throws ReferenceNotFoundException
     */
    public function getTransactionIdForPayboxReferenceAction(string $paybox_reference): string
    {
        try {
            $response = $this->sendRequest('getTransactionIdForPayboxReference', [
                'paybox_reference' => $paybox_reference,
            ]);

            return $response['transaction_id'];
        } catch (MccsException $e) {
            if ($e->getPrevious() instanceof ServerException && $e->getPrevious()->getResponse() !== null) {
                $response_data = Json::decodeAssociative((string)$e->getPrevious()->getResponse()->getBody());

                if (is_array($response_data)
                    && isset($response_data['item']['errorcode'])
                    && (int)$response_data['item']['errorcode'] === self::CODE_PAYBOX_REFERENCE_NOT_FOUND
                ) {
                    throw new ReferenceNotFoundException($response_data['item']['message']);
                }
            }

            throw $e;
        }
    }

    public function getSettlementDetails(string $settlement_number, PaymentProviderType $provider): ValitorSettlement
    {
        $response = $this->sendRequest(
            'settlementInformation',
            [
                'unique_id'        => $settlement_number,
                'payment_provider' => (string)$provider,
            ]
        );

        try {
            if (empty($response)) {
                throw new InvalidArgumentException("No valid response from MCCS.");
            }

            return ValitorSettlement::createFromMccsSettlementInformation($response);
        } catch (InvalidArgumentException $e) {
            throw new MccsException(
                sprintf(
                    'Could not create %s instance using response from MCCS (for settlement: %s)',
                    (string)$provider,
                    $settlement_number
                )
            );
        }
    }

    public function getAmexSettlementDataByBanktransaction(Model_Banktransaction $banktransaction): ?AmexSettlement
    {
        $card_acceptor_id = $banktransaction->getTagData()["card_acceptor_id"] ?? null;

        $response = $this->sendRequest(
            'getAmexSettlementInformation',
            [
                'settlement_net_amount' => money_to_string($banktransaction->getAmount()),
                'card_acceptor_id'      => $card_acceptor_id,
            ],
            120
        );

        return AmexSettlement::createFromResponse($response);
    }
}
