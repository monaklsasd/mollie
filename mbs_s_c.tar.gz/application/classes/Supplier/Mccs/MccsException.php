<?php

declare(strict_types=1);

namespace Supplier\Mccs;

use RuntimeException;

class MccsException extends RuntimeException
{
}
