<?php

declare(strict_types=1);

namespace Supplier\Mccs;

class ReferenceNotFoundException extends MccsException
{
}
