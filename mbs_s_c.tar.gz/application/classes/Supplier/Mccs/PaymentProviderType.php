<?php

namespace Supplier\Mccs;

use MyCLabs\Enum\Enum;

/**
 * @method static self Valitor()
 * @method static self Amex()
 */
class PaymentProviderType extends Enum
{
    private const Valitor = 'Valitor';
    private const Amex    = 'Amex';
}
