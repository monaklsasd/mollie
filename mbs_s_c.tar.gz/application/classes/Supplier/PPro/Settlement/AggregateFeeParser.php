<?php

declare(strict_types=1);

namespace Supplier\PPro\Settlement;

use Iterator;
use League\Csv\Reader;
use Model\Settlement\Ppro\SettlementFileType;
use Model_Settlement_Ppro_File;
use Money\Currency;
use Webmozart\Assert\Assert;
use function Core\Money\money_from_string;

/**
 * Parses fees that are only included in the aggregate files.
 */
class AggregateFeeParser
{
    private const HEADER_MERCHANT_ID    = 'MERCHANT_ID';
    private const HEADER_PAYMENT_METHOD = 'PAYMENT_METHOD';
    private const HEADER_EVENT_TYPE     = 'EVENT_TYPE';
    private const HEADER_EVENT_COUNT    = 'EVENT_COUNT';
    private const HEADER_AMOUNT         = 'AGGREGATE_AMOUNT';
    private const HEADER_CURRENCY       = 'CURRENCY';

    private const TERMINAL_BASED_FEE_CODES = [
        'WIRE_FEE',
        'MERCHANT_SETUP_FEE',
        'MERCHANT_MONTHLY_FEE',
        'INQUIRY_FEE',
        'FRAUD_INQUIRY_FEE',
        'MONTHLY_MINIMUM_FEE',
        'MONTHLY_BASE_FEE',
        'ONE_TIME_FEE',
    ];

    private const TRANSACTION_BASED_FEE_CODES = [
        'ACQUIRING_FEE',
        'DISCOUNT_FEE',
        'SUCCEEDED_FEE',
    ];

    /** Only add balances that are actually settled. We don't track unsettled balances. */
    private const BALANCES_CODES = [
        'STARTING_BALANCE',
    ];

    /**
     * @return array[]
     */
    private function getParsedDataFromFile(Model_Settlement_Ppro_File $settlement_file): iterable
    {
        $reader = Reader::createFromString($settlement_file->contents);
        $reader->setHeaderOffset(0);

        $headers   = $reader->getHeader();
        $empty_row = array_fill_keys($headers, '');

        foreach ($reader->getRecords($headers) as $row) {
            if ($row === $empty_row) {
                return;
            }

            yield $row;
        }
    }

    /**
     * @return AggregateFee[]
     */
    public function parseTerminalFees(Model_Settlement_Ppro_File $aggregate_settlement_file): Iterator
    {
        Assert::true($aggregate_settlement_file->isOfType(SettlementFileType::AGGREGATE()));

        foreach ($this->getParsedDataFromFile($aggregate_settlement_file) as $parsed_data) {
            if (!in_array($parsed_data[self::HEADER_EVENT_TYPE], self::TERMINAL_BASED_FEE_CODES)) {
                /*
                 * Do not create aggregate fee records for other type of events (transaction/succeeded_fee/etc).
                 */
                continue;
            }

            yield new AggregateFee(
                $parsed_data[self::HEADER_EVENT_TYPE],
                $parsed_data[self::HEADER_MERCHANT_ID],
                (int)($parsed_data[self::HEADER_EVENT_COUNT]),
                money_from_string($parsed_data[self::HEADER_AMOUNT], new Currency($parsed_data[self::HEADER_CURRENCY])),
                $parsed_data[self::HEADER_PAYMENT_METHOD]
            );
        }
    }

    /**
     * @return AggregateFee[]
     */
    public function parseTransactionFees(Model_Settlement_Ppro_File $aggregate_settlement_file): Iterator
    {
        Assert::true($aggregate_settlement_file->isOfType(SettlementFileType::AGGREGATE()));

        foreach ($this->getParsedDataFromFile($aggregate_settlement_file) as $parsed_data) {
            if (!in_array($parsed_data[self::HEADER_EVENT_TYPE], self::TRANSACTION_BASED_FEE_CODES)) {
                /*
                 * Do not create aggregate fee records for other type of events (transaction/succeeded_fee/etc).
                 */
                continue;
            }

            yield new AggregateFee(
                $parsed_data[self::HEADER_EVENT_TYPE],
                $parsed_data[self::HEADER_MERCHANT_ID],
                (int)($parsed_data[self::HEADER_EVENT_COUNT]),
                money_from_string($parsed_data[self::HEADER_AMOUNT], new Currency($parsed_data[self::HEADER_CURRENCY])),
                $parsed_data[self::HEADER_PAYMENT_METHOD]
            );
        }
    }

    /**
     * Parses any balances.
     */
    public function parseBalances(Model_Settlement_Ppro_File $aggregate_settlement_file): Iterator
    {
        Assert::true($aggregate_settlement_file->isOfType(SettlementFileType::AGGREGATE()));

        foreach ($this->getParsedDataFromFile($aggregate_settlement_file) as $parsed_data) {
            if (!in_array($parsed_data[self::HEADER_EVENT_TYPE], self::BALANCES_CODES)) {
                /*
                 * Do not create aggregate fee records for other type of events (transaction/succeeded_fee/etc).
                 */
                continue;
            }

            yield new Balance(
                $parsed_data[self::HEADER_EVENT_TYPE],
                money_from_string($parsed_data[self::HEADER_AMOUNT], new Currency($parsed_data[self::HEADER_CURRENCY]))
            );
        }
    }
}
