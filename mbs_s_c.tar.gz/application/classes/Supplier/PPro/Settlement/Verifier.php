<?php

declare(strict_types=1);

namespace Supplier\PPro\Settlement;

use Model_Set;
use Model_Settlement_Ppro_File as SettlementFile;
use Model_Settlement_Ppro_Record;
use function Core\Money\amounts_are_equal;

class Verifier
{
    /** @var RecordParser */
    private $file_parser;

    public function __construct(RecordParser $file_parser)
    {
        $this->file_parser = $file_parser;
    }

    public function verifyRecordsChecksum(Model_Set $settlement_records, SettlementFile $file): bool
    {
        $checksum = $this->file_parser->parseChecksum($file->contents);
        $file->setChecksum($checksum);

        if ($settlement_records->count() === 0) {
            return $checksum->getCount() === 0 && amounts_are_equal($checksum->getAmount(), '0.00');
        }

        $sum_amount = '0';
        /** @var Model_Settlement_Ppro_Record $record */
        foreach ($settlement_records as $record) {
            $sum_amount = bcadd($sum_amount, (string)$record->amount);
        }

        return $checksum->getCount() === $settlement_records->count() && amounts_are_equal($sum_amount, $checksum->getAmount());
    }

    public function verifyFileChecksum(SettlementFile $settlement_file): bool
    {
        return $this->verifyRecordsChecksum($this->file_parser->parseFile($settlement_file), $settlement_file);
    }
}
