<?php

declare(strict_types=1);

namespace Supplier\PPro\Settlement;

use DateTimeImmutable;
use League\Csv\Reader;
use Model_Base;
use Model_Set;
use Model_Settlement_Ppro_File as SettlementFile;
use Model_Settlement_Ppro_Record;
use Model_Settlement_Ppro_Record_Chargeback;
use Model_Settlement_Ppro_Record_Payment_Reference;
use Orm\ModelFactory;
use Supplier\PPro\Reconciliation\FileTypes\FileType;
use Supplier\PPro\Reconciliation\FileTypes\FileTypeFactory;
use Supplier\PPro\Settlement\Exception\ParserException;

class RecordParser
{
    private const LABEL_NAME_SETTLEMENT_DATE = 'SETTLEMENT_DATE';
    private const LABEL_NAME_CHECKSUM_COUNT  = 'RECORD_COUNT';
    private const LABEL_NAME_CHECKSUM_AMOUNT = 'CHECKSUM_AGGREGATE_AMOUNT';
    private const MERCHANT_TX_ID             = 'MERCHANT_TX_ID';
    private const REFERENCE_TX_ID            = 'REFERENCE_TX_ID';
    private const SUFFIX_ID                  = '_ID';
    private const PAYMENT_METHOD             = 'PAYMENT_METHOD';
    private const EVENT_TIMESTAMP            = 'EVENT_TIMESTAMP';
    private const EVENT_TYPE                 = 'EVENT_TYPE';
    private const FEE_TYPE                   = 'FEE_TYPE';
    private const AMOUNT                     = 'AMOUNT';
    private const CURRENCY                   = 'CURRENCY';
    private const COUNTRY                    = 'COUNTRY';
    private const CHARGEBACK_REASON          = 'CHARGEBACK_REASON';
    private const RECORD_TYPE_TRANSACTION    = 'TX';
    private const RECORD_TYPE_REFUND         = 'RF';
    private const RECORD_TYPE_CHARGEBACK     = 'CB';

    /** @var ModelFactory */
    private $model_factory;

    /** @var FileTypeFactory */
    private $file_type_factory;

    public function __construct(ModelFactory $model_factory, FileTypeFactory $file_type_factory)
    {
        $this->model_factory     = $model_factory;
        $this->file_type_factory = $file_type_factory;
    }

    /**
     * @return Model_Settlement_Ppro_Record[]
     */
    public function parseFile(SettlementFile $unparsed_settlement_file): Model_Set
    {
        $record_type = $this->getRecordTypePrefix($unparsed_settlement_file);
        $reader      = Reader::createFromString($unparsed_settlement_file->contents);
        $reader->setHeaderOffset(0);

        $headers   = $reader->getHeader();
        $empty_row = array_fill_keys($headers, '');

        $records = [];

        foreach ($reader->getRecords($headers) as $row) {
            if ($row === $empty_row) {
                break; // Separator line, this indicates the end of fee/volume rows in this file.
            }

            $record = $this->model_factory->create(Model_Settlement_Ppro_Record::class);

            $record->record_type                  = $record_type;
            $record->mollie_transaction_reference = $row[self::MERCHANT_TX_ID];
            $record->payment_method               = $row[self::PAYMENT_METHOD];
            $record->type_specific_id             = $row[$record_type . self::SUFFIX_ID];
            $record->event_type                   = $this->getFileType($unparsed_settlement_file)::containsPaymentEvents()
                    ? $row[self::EVENT_TYPE]
                    : null;
            $record->event_timestamp = (new DateTimeImmutable($row[self::EVENT_TIMESTAMP]))->format(Model_Base::DATE_SQL);
            $record->amount          = $row[self::AMOUNT];
            $record->currency        = $row[self::CURRENCY];
            $record->country         = $row[self::COUNTRY];

            if ($this->getFileType($unparsed_settlement_file)::containsFees()) {
                $record->fee_type = $row[self::FEE_TYPE];
            }

            if ($this->getFileType($unparsed_settlement_file)::containsChargebackDetails()) {
                [$reason_code, $description] = explode(' ', $row[self::CHARGEBACK_REASON], 2);
                $record->chargeback          = $this->createChargebackComponent($reason_code, $description);
            }

            if ($this->getFileType($unparsed_settlement_file)::containsPaymentReference()) {
                $record->payment_reference = $this->createPaymentReferenceComponent((int)$row[self::REFERENCE_TX_ID]);
            }

            $records[] = $record;
        }

        return new Model_Set($records);
    }

    private function getFileType(SettlementFile $file): FileType
    {
        return $this->file_type_factory->getFileTypeByFilename($file->filename);
    }

    public function parseSettlementDate(string $file_contents): DateTimeImmutable
    {
        $settlement_date = $this->findValueByLabelName($file_contents, self::LABEL_NAME_SETTLEMENT_DATE);

        if (empty($settlement_date)) {
            throw new ParserException('Could not find a settlement date within given file contents');
        }

        return new DateTimeImmutable($settlement_date);
    }

    /**
     * @throws ParserException
     */
    public function parseChecksum(string $file_contents): Checksum
    {
        $checksum_count  = $this->findValueByLabelName($file_contents, self::LABEL_NAME_CHECKSUM_COUNT);
        $checksum_amount = $this->findValueByLabelName($file_contents, self::LABEL_NAME_CHECKSUM_AMOUNT);

        if ($checksum_count === null || $checksum_amount === null) {
            throw new ParserException('Could not find the checksum count & amount values within given file contents');
        }

        return new Checksum((int)$checksum_count, (float)$checksum_amount);
    }

    private function findValueByLabelName(string $file_contents, string $label_name): ?string
    {
        $reader = Reader::createFromString($file_contents);

        foreach ($reader->getRecords() as $line) {
            if ($line[0] === $label_name) {
                return $line[1];
            }
        }

        return null;
    }

    private function getRecordTypePrefix(SettlementFile $file): string
    {
        $filetype = $this->getFileType($file);

        if ($filetype::containsTransactionRecords()) {
            return self::RECORD_TYPE_TRANSACTION;
        }

        if ($filetype::containsRefundRecords()) {
            return self::RECORD_TYPE_REFUND;
        }

        if ($filetype::containsChargebackRecords()) {
            return self::RECORD_TYPE_CHARGEBACK;
        }

        throw new ParserException('Cannot determine record type');
    }

    private function createChargebackComponent(string $reason_code, string $description): Model_Settlement_Ppro_Record_Chargeback
    {
        $record_chargeback = $this->model_factory->create(Model_Settlement_Ppro_Record_Chargeback::class);

        $record_chargeback->reason_code        = $reason_code;
        $record_chargeback->reason_description = $description;

        return $record_chargeback;
    }

    private function createPaymentReferenceComponent(int $reference_transaction_id): Model_Settlement_Ppro_Record_Payment_Reference
    {
        $record_payment_reference = $this->model_factory->create(Model_Settlement_Ppro_Record_Payment_Reference::class);

        $record_payment_reference->payment_reference = $reference_transaction_id;

        return $record_payment_reference;
    }
}
