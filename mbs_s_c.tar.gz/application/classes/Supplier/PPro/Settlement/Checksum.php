<?php

declare(strict_types=1);

namespace Supplier\PPro\Settlement;

class Checksum
{
    /** @var int */
    private $count;

    /** @var float */
    private $amount;

    public function __construct(int $count, float $amount)
    {
        $this->count  = $count;
        $this->amount = $amount;
    }

    public function getCount(): int
    {
        return $this->count;
    }

    public function getAmount(): float
    {
        return $this->amount;
    }
}
