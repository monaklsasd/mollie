<?php

declare(strict_types=1);

namespace Supplier\PPro\Settlement\Record;

use CallbackFilterIterator;
use Core\Localization\Localizer;
use DateTimeImmutable;
use Iterator;
use Model\Settlement\Ppro\SettlementFileType;
use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use Model_Base;
use Model_Settlement_Ppro;
use Model_Settlement_Ppro_File;
use Model_Settlement_Ppro_Record;
use Money\Currency;
use Money\Money;
use Orm\ModelFactory;
use Orm\Repositories\PPro\PProSettlementFileRepository;
use Orm\Repositories\PPro\Settlement\RecordRepository;
use OutOfBoundsException;
use Supplier\PPro\Processing\DataRetriever;
use Supplier\PPro\Settlement\AggregateFee;
use Supplier\PPro\Settlement\AggregateFeeParser;
use Supplier\PPro\Settlement\Balance;
use Supplier\PPro\Settlement\Exception\TransformerException;
use function Core\Money\money_from_string;

class TransactionTransformer
{
    public const PAYMENT_METHOD_TAG_BANCONTACT      = 'Bancontact';
    public const PAYMENT_METHOD_TAG_BANCONTACT_OLD  = 'Bancontact/MisterCash';
    public const PAYMENT_METHOD_TAG_EPS             = 'EPS';
    public const PAYMENT_METHOD_TAG_GIROPAY         = 'Giropay';
    public const PAYMENT_METHOD_TAG_IDEAL           = 'Ideal';
    public const PAYMENT_METHOD_TAG_MYBANK          = 'MyBank';
    public const PAYMENT_METHOD_TAG_PRZELEWY24      = 'P24';
    public const PAYMENT_METHOD_TAG_PRZELEWY24_FULL = 'Przelewy24';

    public const PAYMENT_METHOD_FEE_TAG_MAP = [
        self::PAYMENT_METHOD_TAG_BANCONTACT      => TransactionTags::TAG_PPRO_FEE_VARIABLE_BANCONTACT,
        self::PAYMENT_METHOD_TAG_BANCONTACT_OLD  => TransactionTags::TAG_PPRO_FEE_VARIABLE_BANCONTACT,
        self::PAYMENT_METHOD_TAG_EPS             => TransactionTags::TAG_PPRO_FEE_VARIABLE_EPS,
        self::PAYMENT_METHOD_TAG_GIROPAY         => TransactionTags::TAG_PPRO_FEE_VARIABLE_GIROPAY,
        self::PAYMENT_METHOD_TAG_IDEAL           => TransactionTags::TAG_PPRO_FEE_VARIABLE_IDEAL,
        self::PAYMENT_METHOD_TAG_MYBANK          => TransactionTags::TAG_PPRO_FEE_VARIABLE_MYBANK,
        self::PAYMENT_METHOD_TAG_PRZELEWY24      => TransactionTags::TAG_PPRO_FEE_VARIABLE_PRZELEWY24,
        self::PAYMENT_METHOD_TAG_PRZELEWY24_FULL => TransactionTags::TAG_PPRO_FEE_VARIABLE_PRZELEWY24,
    ];

    private const PAYMENT_METHOD_TAG_MAP = [
        self::PAYMENT_METHOD_TAG_BANCONTACT      => TransactionTags::TAG_MISTERCASH,
        self::PAYMENT_METHOD_TAG_BANCONTACT_OLD  => TransactionTags::TAG_MISTERCASH,
        self::PAYMENT_METHOD_TAG_EPS             => TransactionTags::TAG_EPS,
        self::PAYMENT_METHOD_TAG_GIROPAY         => TransactionTags::TAG_GIROPAY,
        self::PAYMENT_METHOD_TAG_IDEAL           => TransactionTags::TAG_IDEAL,
        self::PAYMENT_METHOD_TAG_MYBANK          => TransactionTags::TAG_MYBANK,
        self::PAYMENT_METHOD_TAG_PRZELEWY24      => TransactionTags::TAG_PRZELEWY24,
        self::PAYMENT_METHOD_TAG_PRZELEWY24_FULL => TransactionTags::TAG_PRZELEWY24,
    ];

    /** @var ModelFactory */
    private $model_factory;

    /** @var DataRetriever */
    private $data_retriever;

    /** @var AggregateFeeParser */
    private $aggregate_fee_parser;

    /** @var RecordRepository */
    private $settlement_record_repository;

    /** @var PProSettlementFileRepository */
    private $settlement_file_repository;

    public function __construct(
        ModelFactory $model_factory,
        DataRetriever $processing_data_retriever,
        AggregateFeeParser $aggregate_fee_parser,
        RecordRepository $settlement_record_repository,
        PProSettlementFileRepository $settlement_file_repository
    ) {
        $this->model_factory                = $model_factory;
        $this->data_retriever               = $processing_data_retriever;
        $this->aggregate_fee_parser         = $aggregate_fee_parser;
        $this->settlement_record_repository = $settlement_record_repository;
        $this->settlement_file_repository   = $settlement_file_repository;
    }

    /**
     * PPRO will have one settlement which consists of multiple transfers, one per currency. Hence, we need to pass in
     * the currency so we can get the actual transactions for the transfer we are expanding.
     *
     * @return iterable|Model_Banktransaction[]
     */
    public function transformSettlementRecordsForBatch(Model_Banktransaction $batch_transaction, Model_Settlement_Ppro $settlement): iterable
    {
        $aggregate_file = $this->settlement_file_repository->getSingleSettlementFileOfType($settlement, SettlementFileType::AGGREGATE());

        yield from $this->generateTransactionsForBalances($batch_transaction, $aggregate_file);
        yield from $this->generateTransactionsForVolumeRecords($batch_transaction, $settlement);
        yield from $this->generateTransactionsForFeeRecords($batch_transaction, $settlement, $aggregate_file);
        yield from $this->generateTransactionsForAggregateFees($batch_transaction, $aggregate_file);
    }

    private function getTransactionTypeTag(Model_Settlement_Ppro_Record $record): string
    {
        switch ($record->record_type) {
            case Model_Settlement_Ppro_Record::RECORD_TYPE_CHARGEBACK:
                return TransactionTags::TAG_PPRO_CHARGEBACK;

            case Model_Settlement_Ppro_Record::RECORD_TYPE_REFUND:
                return TransactionTags::TAG_PPRO_REFUND;

            case Model_Settlement_Ppro_Record::RECORD_TYPE_TRANSACTION:
                if ($record->event_type === "FUNDSMISSING" || $record->event_type == "FUNDSRECEIVED") {
                    /*
                     * Treat funds missing as a chargeback.
                     *
                     * Its possible the funds appear mysteriously after they went missing. In that case we create a
                     * "negative chargeback", so use the same tag.
                     */
                    return TransactionTags::TAG_PPRO_CHARGEBACK;
                }

                return TransactionTags::TAG_PPRO_PAYMENT;
        }

        return TransactionTags::TAG_UNKNOWNMISTERCASH;
    }

    private function getPaymentTypeTag(Model_Settlement_Ppro_Record $record): string
    {
        if (!isset(self::PAYMENT_METHOD_TAG_MAP[$record->payment_method])) {
            throw new TransformerException(sprintf(
                'Payment method for settlement record #%d is not mapped to any payment type tag: %s',
                $record->id,
                $record->payment_method
            ));
        }

        return self::PAYMENT_METHOD_TAG_MAP[$record->payment_method];
    }

    /**
     * @return Model_Banktransaction[]
     */
    private function generateTransactionsForVolumeRecords(Model_Banktransaction $batch_transaction, Model_Settlement_Ppro $settlement): iterable
    {
        foreach ($this->settlement_record_repository->getVolumeRecordsFor($settlement) as $record) {
            if (!$record->getCurrency()->equals($batch_transaction->getCurrency())) {
                continue;
            }

            /*
             * It can be both a FUNDSMISSING or a SUCCEEDED type of volume record.
             */

            $description_data = [
                sprintf('Payment currency: %s', $record->getCurrency()),
                sprintf('Consumer country: %s', $record->country),
            ];

            $transaction = $this->model_factory->create(Model_Banktransaction::class);
            $transaction->setParentTransaction($batch_transaction);
            $transaction->setCustomerDate(DateTimeImmutable::createFromFormat(Model_Base::DATE_SQL, $record->event_timestamp));
            $transaction->setAmount(money_from_string((string)$record->amount, $record->getCurrency()));

            $transaction->addTag($this->getTransactionTypeTag($record));
            $transaction->addTag($this->getPaymentTypeTag($record));

            if ($record->refersToPayment()) {
                $transaction->addTagData([
                    'payment_token'  => $record->mollie_transaction_reference,
                    'transaction_id' => $record->type_specific_id,
                ]);

                $description_data[] = sprintf('Payment token: %s', $record->mollie_transaction_reference);
            }

            $transaction->setDescription(implode(', ', $description_data));

            if ($this->shouldAppendConsumerAccountDetailsForRecord($record)) {
                $account_details = $this->data_retriever->getConsumerAccountDetailsForSettlementRecord($record);

                if ($account_details !== null) {
                    $transaction->setOffsetAccountName($account_details->account_holder_name);
                    $transaction->setOffsetAccountNumber($account_details->iban);
                    $transaction->setOffsetAccountBic($account_details->bic);
                }
            }

            yield $transaction;
        }
    }

    private function shouldAppendConsumerAccountDetailsForRecord(Model_Settlement_Ppro_Record $record): bool
    {
        return \in_array(
            $record->payment_method,
            [self::PAYMENT_METHOD_TAG_EPS, self::PAYMENT_METHOD_TAG_GIROPAY],
            true
        );
    }

    /**
     * @return Model_Banktransaction[]
     */
    private function generateTransactionsForFeeRecords(Model_Banktransaction $batch_transaction, Model_Settlement_Ppro $settlement, Model_Settlement_Ppro_File $aggregate_file): iterable
    {
        /*
         * Array containing the total fees per payment method.
         * Because the fees for different payment method should be placed on a different ledger as well,
         * we'll create a separate bank transaction as well.
         */
        $fee_per_payment_method = [];

        /** @var AggregateFee[]|Iterator $filtered */
        $filtered = $this->filterByCurrency($this->aggregate_fee_parser->parseTransactionFees($aggregate_file), $batch_transaction->getCurrency());

        foreach ($filtered as $aggregate_transaction_fee) {
            $payment_method = $aggregate_transaction_fee->getPaymentMethod();

            if (!array_key_exists($payment_method, self::PAYMENT_METHOD_FEE_TAG_MAP)) {
                // Transaction fee for an unknown/unsupported payment method, ignoring.
                continue;
            }

            if (!array_key_exists($payment_method, $fee_per_payment_method)) {
                $fee_per_payment_method[$payment_method] = new Money(0, $batch_transaction->getCurrency());
            }

            $fee_per_payment_method[$payment_method] = $fee_per_payment_method[$payment_method]->add($aggregate_transaction_fee->getAmount());
        }

        foreach ($fee_per_payment_method as $payment_method => $fee_amount) {
            if ($fee_amount->isZero()) {
                continue;
            }

            $fee_transaction = $this->model_factory->create(Model_Banktransaction::class);
            $fee_transaction->setParentTransaction($batch_transaction);
            $fee_transaction->setAmount($fee_amount);
            $fee_transaction->setDescription(sprintf(
                'Variable %s fees for PPRO settlement: %s',
                $payment_method,
                $settlement->reference
            ));
            $fee_transaction->setTags([$this->getFeeTagByPaymentMethod($payment_method)]);

            yield $fee_transaction;
        }
    }

    protected function getFeeTagByPaymentMethod(string $payment_method): string
    {
        if (!array_key_exists($payment_method, self::PAYMENT_METHOD_FEE_TAG_MAP)) {
            throw new OutOfBoundsException('Payment method {$payment_method} does not appear in payment fee mapping.');
        }

        return self::PAYMENT_METHOD_FEE_TAG_MAP[$payment_method];
    }

    /**
     * @return Model_Banktransaction[]
     */
    private function generateTransactionsForAggregateFees(Model_Banktransaction $batch_transaction, Model_Settlement_Ppro_File $aggregate_file): Iterator
    {
        /** @var AggregateFee[]|Iterator $filtered */
        $filtered = $this->filterByCurrency($this->aggregate_fee_parser->parseTerminalFees($aggregate_file), $batch_transaction->getCurrency());

        foreach ($filtered as $aggregate_fee) {
            $fee_transaction = $this->model_factory->create(Model_Banktransaction::class);
            $fee_transaction->setParentTransaction($batch_transaction);
            $fee_transaction->setAmount($aggregate_fee->getAmount());
            $fee_transaction->setDescription(sprintf(
                'PPRO settlement fee (%1$s) x%2$d: %3$s ' . ($aggregate_fee->getMerchantName() ? 'for merchant: %4$s' : ''),
                $aggregate_fee->getType(),
                $aggregate_fee->getCount(),
                Localizer::formatMoney($aggregate_fee->getAmount()),
                $aggregate_fee->getMerchantName()
            ));

            $fee_transaction->setTags([TransactionTags::TAG_BANK_PPRO]);

            yield $fee_transaction;
        }
    }

    private function generateTransactionsForBalances(Model_Banktransaction $batch_transaction, Model_Settlement_Ppro_File $aggregate_file): Iterator
    {
        /** @var Balance[] $filtered */
        $filtered = $this->filterByCurrency($this->aggregate_fee_parser->parseBalances($aggregate_file), $batch_transaction->getCurrency());

        foreach ($filtered as $balance) {
            $balance_transaction = $this->model_factory->create(Model_Banktransaction::class);
            $balance_transaction->setParentTransaction($batch_transaction);
            $balance_transaction->setAmount($balance->getAmount());
            $balance_transaction->setDescription(
                sprintf(
                    '%1$s from PPRO. This was held back at PPRO because the minimum settlement amount for this currency was not met. Can contain various things but parsing it is not implemented.',
                    $balance->getType()
                )
            );
            $balance_transaction->setTags([TransactionTags::TAG_PPRO_BALANCE]);

            yield $balance_transaction;
        }
    }

    private function filterByCurrency(Iterator $source, Currency $only_this_currency): Iterator
    {
        return new CallbackFilterIterator($source, function ($each) use ($only_this_currency): bool {
            /** @var AggregateFee|Balance $each */
            return $each->getAmount()->getCurrency()->equals($only_this_currency);
        });
    }
}
