<?php

declare(strict_types=1);

namespace Supplier\PPro\Settlement;

use Money\Money;

final class AggregateFee
{
    /** @var string */
    private $type;

    /** @var Money */
    private $amount;

    /** @var int */
    private $count;

    /** @var string */
    private $merchant_name;

    /** @var string|null */
    private $payment_method;

    public function __construct(string $type, string $merchant_name, int $count, Money $amount, ?string $payment_method)
    {
        $this->type           = $type;
        $this->merchant_name  = $merchant_name;
        $this->amount         = $amount;
        $this->count          = $count;
        $this->payment_method = $payment_method;
    }

    public function getType(): string
    {
        return $this->type;
    }

    public function getAmount(): Money
    {
        return $this->amount;
    }

    public function getCount(): int
    {
        return $this->count;
    }

    public function getMerchantName(): string
    {
        return $this->merchant_name;
    }

    public function getPaymentMethod(): ?string
    {
        return $this->payment_method;
    }
}
