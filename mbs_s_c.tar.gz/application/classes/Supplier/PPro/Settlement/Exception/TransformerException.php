<?php

declare(strict_types=1);

namespace Supplier\PPro\Settlement\Exception;

use Mollie_Exception;

class TransformerException extends Mollie_Exception
{
}
