<?php

declare(strict_types=1);

namespace Supplier\PPro\Settlement\Exception;

use Mollie_Exception;

class ParserException extends Mollie_Exception
{
}
