<?php

declare(strict_types=1);

namespace Supplier\PPro\Processing;

use Webmozart\Assert\Assert;

/**
 * ConsumerAccountDetails model
 */
class ConsumerAccountDetails
{
    /** @var string */
    public $account_holder_name;

    /** @var string */
    public $iban;

    /** @var string */
    public $bic;

    public function __construct(string $account_holder_name, string $iban, string $bic)
    {
        Assert::allNotEmpty([$account_holder_name, $iban, $bic]);

        $this->account_holder_name = $account_holder_name;
        $this->iban                = $iban;
        $this->bic                 = $bic;
    }
}
