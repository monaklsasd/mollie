<?php

declare(strict_types=1);

namespace Supplier\PPro\Processing;

use Model_Settlement_Ppro_Record;
use Orm\Repositories\PPro\PProConfirmationRepository;

class DataRetriever
{
    public const RECORD_TYPE_TRANSACTION = 'TX';
    public const RECORD_TYPE_REFUND      = 'RF';
    public const RECORD_TYPE_CHARGEBACK  = 'CB';

    /** @var PProConfirmationRepository */
    private $confirmation_repository;

    public function __construct(PProConfirmationRepository $confirmation_repository)
    {
        $this->confirmation_repository = $confirmation_repository;
    }

    public function getConsumerAccountDetailsForSettlementRecord(
        Model_Settlement_Ppro_Record $settlement_record
    ): ?ConsumerAccountDetails {
        $confirmation = $this->confirmation_repository->findByTransactionId(
            $settlement_record->record_type,
            (int)$settlement_record->type_specific_id
        );

        if ($confirmation === null) {
            return null;
        }

        return new ConsumerAccountDetails(
            $confirmation->bankaccount_name,
            $confirmation->bankaccount_nr,
            $confirmation->bic
        );
    }
}
