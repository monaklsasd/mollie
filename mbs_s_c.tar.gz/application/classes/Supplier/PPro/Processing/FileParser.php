<?php

declare(strict_types=1);

namespace Supplier\PPro\Processing;

use DateTimeImmutable;
use League\Csv\Reader;
use Model_Base;
use Model_Ppro_Confirmation;
use Model_Ppro_Processing_File;
use Model_Set;
use Orm\ModelFactory;
use function array_fill_keys;

class FileParser
{
    private const RECORD_TYPE_TRANSACTION = 'TX';
    private const RECORD_TYPE_REFUND      = 'RF';
    private const RECORD_TYPE_CHARGEBACK  = 'CB';

    private const VALUE_FUNDS_RECEIVED  = 'RECEIVED';
    private const COL_TX_ID             = 'TXID';
    private const COL_ACCOUNT_HOLDER    = 'OUT.SRCACCOUNTHOLDER';
    private const COL_AMOUNT            = 'AMOUNT';
    private const COL_BIC               = 'OUT.SRCBIC';
    private const COL_CURRENCY          = 'CURRENCY';
    private const COL_FUNDS_RECEIVED_AT = 'FUNDSRECEIVEDTS';
    private const COL_FUNDS_STATE       = 'FUNDSSTATE';
    private const COL_IBAN              = 'OUT.SRCIBAN';
    private const COL_MOLLIE_REFERENCE  = 'MERCHANTTXID';
    private const COL_TAG               = 'TAG';

    /** @var ModelFactory */
    private $model_factory;

    public function __construct(ModelFactory $model_factory)
    {
        $this->model_factory = $model_factory;
    }

    /**
     * @return Model_Ppro_Confirmation[]
     */
    public function parseConfirmationsInFile(Model_Ppro_Processing_File $processing_file): Model_Set
    {
        $confirmations = [];

        foreach ($this->parseFile($processing_file->contents) as $parsed_line) {
            if ($parsed_line[self::COL_FUNDS_STATE] !== self::VALUE_FUNDS_RECEIVED) {
                continue;
            }

            if (empty($parsed_line[self::COL_ACCOUNT_HOLDER])
                || empty($parsed_line[self::COL_BIC])
                || empty($parsed_line[self::COL_IBAN])
            ) {
                continue;
            }

            $confirmation = $this->model_factory->create(Model_Ppro_Confirmation::class);

            $confirmation->payment_method               = $parsed_line[self::COL_TAG];
            $confirmation->record_type                  = self::RECORD_TYPE_TRANSACTION;
            $confirmation->type_specific_id             = $parsed_line[self::COL_TX_ID];
            $confirmation->event_timestamp              = (new DateTimeImmutable($parsed_line[self::COL_FUNDS_RECEIVED_AT]))->format(Model_Base::DATE_SQL);
            $confirmation->amount                       = $parsed_line[self::COL_AMOUNT];
            $confirmation->currency                     = $parsed_line[self::COL_CURRENCY];
            $confirmation->mollie_transaction_reference = $parsed_line[self::COL_MOLLIE_REFERENCE];
            $confirmation->bankaccount_name             = $parsed_line[self::COL_ACCOUNT_HOLDER];
            $confirmation->bic                          = $parsed_line[self::COL_BIC];
            $confirmation->bankaccount_nr               = $parsed_line[self::COL_IBAN];

            $confirmations[] = $confirmation;
        }

        return new Model_Set($confirmations);
    }

    private function parseFile(string $file_contents): array
    {
        $reader = Reader::createFromString($file_contents);
        $reader->setHeaderOffset(0);

        $headers   = $reader->getHeader();
        $empty_row = array_fill_keys($headers, '');

        $records = [];

        foreach ($reader->getRecords($headers) as $row) {
            if ($row === $empty_row) {
                break; // Separator line, this indicates the end of fee/volume rows in this file.
            }

            $records[] = $row;
        }

        return $records;
    }
}
