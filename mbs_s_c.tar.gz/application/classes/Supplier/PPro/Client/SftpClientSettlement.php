<?php

declare(strict_types=1);

namespace Supplier\PPro\Client;

class SftpClientSettlement extends SftpClient
{
    private const SETTLEMENT_FOLDER_NAME = 'settlements';
    private const SETTLEMENT_FOLDER_PATH = self::SETTLEMENT_FOLDER_NAME . '/';

    public function getSftpUsername(): ?string
    {
        return $this->ppro_config->getSettlementSftpUsername();
    }

    public function getAllSettlementFiles(): array
    {
        $contents = $this->getFilesystem()->listContents(self::SETTLEMENT_FOLDER_NAME);

        $files = array_filter($contents, function ($path) {
            return $path['type'] === 'file';
        });

        return $files;
    }

    public function downloadSettlementFile(string $remote_file, string $local_file): void
    {
        $this->downloadFile(self::SETTLEMENT_FOLDER_PATH . $remote_file, $local_file);
    }
}
