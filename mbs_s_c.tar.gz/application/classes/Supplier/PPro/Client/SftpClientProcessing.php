<?php

declare(strict_types=1);

namespace Supplier\PPro\Client;

class SftpClientProcessing extends SftpClient
{
    public function getSftpUsername(): ?string
    {
        return $this->ppro_config->getProcessingSftpUsername();
    }

    public function getAllProcessingFiles(): array
    {
        $contents = $this->getFilesystem()->listContents();

        $files = array_filter($contents, function ($path) {
            return $path['type'] === 'file';
        });

        return $files;
    }

    /**
     * @throws SftpClientException
     */
    public function downloadProcessingFile(string $remote_file, string $local_file): void
    {
        $this->downloadFile($remote_file, $local_file);
    }
}
