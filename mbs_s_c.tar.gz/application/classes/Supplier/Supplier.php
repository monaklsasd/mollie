<?php

declare(strict_types=1);

namespace Supplier;

/**
 * Implement this interface on a class that is used for connecting to a supplier so that the class becomes
 * self-describing.
 */
interface Supplier
{
    /**
     * Get the name of the supplier.
     *
     * @abstract
     *
     * @return string
     */
    public function getSupplierName();

    /**
     * Get a link to the supplier website.
     *
     * @abstract
     *
     * @return string
     */
    public function getSupplierWebsite();
}
