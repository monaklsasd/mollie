<?php

class Mollie_Testing_Exception extends Mollie_Exception
{
}
