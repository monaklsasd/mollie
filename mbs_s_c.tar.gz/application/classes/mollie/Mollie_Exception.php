<?php
/**
 * Mollie Exception
 *
 * @author Aine Hickey <aine@mollie.nl> Sep 29, 2011 4:15:31 PM
 * @copyright Copyright (C) Mollie B.V.
 *
 * @see http://www.mollie.nl/
 */
class Mollie_Exception extends Exception
{
}
