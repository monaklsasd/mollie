<?php

/**
 * These are the Database Factory and Object classes that are used
 * by the website, daemons and miscellaneous scripts. The factory
 * class has support for different environment configurations. The
 * object class has methods for interacting with the PHP MySQL
 * module, basically wrapping the module. But it also includes
 * some handy methods like safe querying, query caching/logging
 * and fetching entire result sets.
 *
 * @author Mollie Development team <info@mollie.nl>
 * @copyright Copyright (C) Mollie B.V.
 */

/**
 * Library class: sql_db
 *
 * This class is a Database Object that wraps the PHP MySQL module,
 * and it also includes useful features like safe querying, query
 * caching and fetching entire result sets and individual fields.
 */
class sql_db
{
    public const LOCK_PREFIX = "MOLLIEMBS_LOCK_";

    /**
     * Connection timeout in seconds. If the database server is not
     * available, we should fail fast.
     */
    public const CONNECTION_TIMEOUT = 5;

    /**
     * Keeps the last executed query.
     *
     * @var string
     */
    public $query_last;

    /**
     * Log of all queries.
     *
     * @var array[]
     */
    public static $query_log = [];

    public $disable_log = false;

    /**
     * Number of executed transactions.
     *
     * @var int
     */
    public $num_queries = 0;

    /** @var mysqli_result|null */
    protected $query_result;

    /** Duration of the last query. */
    protected $query_last_ms;

    /**
     * Depth of the transaction / save point stack.
     *
     * @var int
     */
    protected $_transaction_depth = 0;

    protected $_cache_enabled = false;

    /** @var mysqli_result[] */
    protected $_cached_results = [];

    /** @var Closure[] */
    protected $query_listeners = [];

    /** @var Mollie_Config_Database */
    private $config;

    /** @var mysqli */
    private $connection;

    public function __construct(Mollie_Config_Database $config)
    {
        $this->config = $config;
    }

    /**
     * Connect to the mysqld service. The object will handle this
     * for you, even though you can do it manually if you wish.
     *
     * @throws Mollie_Database_Exception_Connect
     */
    public function sql_connect()
    {
        if ($this->sql_connected()) {
            throw new Mollie_Database_Exception_Connect("Already connected.");
        }

        $driver              = new mysqli_driver();
        $driver->report_mode = MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT;

        $this->connection = mysqli_init();

        // timezone @ mollie is CET. mysqlserver is UTC so..
        $this->connection->options(MYSQLI_INIT_COMMAND, 'SET time_zone="CET"');
        $this->connection->options(MYSQLI_OPT_LOCAL_INFILE, false);
        $this->connection->options(MYSQLI_OPT_CONNECT_TIMEOUT, self::CONNECTION_TIMEOUT);

        try {
            $this->connection->real_connect(
                $this->config->getHostname(),
                $this->config->getUsername(),
                $this->config->getPassword(),
                $this->config->getDatabaseName()
            );
        } catch (mysqli_sql_exception $e) {
            $this->connection = null;

            throw new Mollie_Database_Exception_Connect($e->getMessage(), $e->getCode(), $e);
        }

        /*
         * Set character set for the connection.
         */
        $this->connection->set_charset("utf8mb4");
    }

    /**
     * Close the connection when the object goes out of scope.
     */
    public function __destruct()
    {
        if ($this->sql_connected()) {
            $this->connection->close();
            $this->connection = null;
        }
    }

    /**
     * @return bool
     */
    public function sql_connected()
    {
        return !empty($this->connection);
    }

    /**
     * @return string
     */
    public function get_database()
    {
        return $this->config->getDatabaseName();
    }

    /**
     * Execute a raw MySQL query on the current connection. Potentially unsafe!!
     *
     * @param string $query
     *
     * @return bool|mysqli_result
     */
    public function sql_query($query)
    {
        if (!$this->sql_connected()) {
            $this->sql_connect();
        }

        // Remove any pre-existing queries
        $this->query_result = null;

        $this->_mysql_query($query);

        return $this->query_result;
    }

    /**
     * Execute multiple queries. Can pass a string or an array of queries.
     *
     * @param array|string $queries
     *
     * @throws Mollie_Database_Exception
     *
     * @return array Will return an array for each result or succeeded query.
     */
    public function sql_multi_query($queries)
    {
        $results = [];

        if (is_array($queries)) {
            $queries_array = $queries;
            $queries       = implode(";", $queries);
        }

        if (!$this->sql_connected()) {
            $this->sql_connect();
        }

        try {
            $this->connection->multi_query($queries);
        } catch (mysqli_sql_exception $e) {
            /* Flush multi queries */
            while ($this->connection->more_results() && $this->connection->next_result()) {
            }

            throw new Mollie_Database_Exception_Query($e->getMessage(), $e->getCode(), "", $e);
        }

        $i = 0;

        while ($this->connection->more_results()) {
            $this->connection->next_result();

            try {
                $result = $this->connection->store_result();
            } catch (mysqli_sql_exception $e) {
                if (isset($queries_array[$i])) {
                    $error_query = $queries_array[$i];
                } else {
                    $error_query = $queries;
                }

                throw new Mollie_Database_Exception_Query($e->getMessage(), $e->getCode(), $error_query, $e);
            }

            if ($result) {
                $results[] = $result;
            } else {
                $results[] = true; /* Return TRUE for a succeeded query */
            }

            $i++;
        }

        return $results;
    }

    /**
     * Like safe_query_generator, but only fetches first column.
     *
     * @param string     $format_query
     * @param mixed|null ...$args
     *
     * @return Generator
     */
    public function safe_query_fetchcol_generator($format_query, ...$args)
    {
        $result = $this->sql_safe_query($format_query, ...$args);

        try {
            while ($row = $this->sql_fetchrow($result)) {
                yield reset($row);
            }
        } finally {
            $this->sql_freeresult($result);
        }
    }

    /**
     * Execute an _escaped_ MySQL query on the current connection. This method is the
     * preferred querying method of this class.
     *
     * sql_db::sql_safe_query ( $format_query, [ $arg1, $arg2, $argN... ])
     *
     * @param $format_query string The query to execute with placeholders for the arguments.
     * @param ...$args string Arguments to put into the placeholders
     *
     * Usage:
     *  - $1, $2 and $N inside $format_query are replaced by escaped and quoted arguments
     *  - ^1, ^2 and ^N inside $format_query are replaced by escaped arguments WITHOUT
     *       quotes, for LIKE statements and numeric comparisons
     *
     * @return bool|mysqli_result
     */
    public function sql_safe_query($format_query, ...$args)
    {
        return $this->sql_query(
            $this->sql_build_safe_query($format_query, ...$args)
        );
    }

    /**
     * @param string  $format_query
     * @param mixed[] ...$args
     *
     * @return string
     */
    public function sql_build_safe_query($format_query, ...$args)
    {
        $replacements = [];

        array_unshift($args, null);

        for ($i = count($args) - 1; $i > 0; $i--) {
            if (is_array($args[$i])) {
                $escaped_param          = $this->sql_escape_array($args[$i]);
                $replacements["^{$i}"]  = '(' . implode(', ', $escaped_param) . ')';
                $replacements["\${$i}"] = '("' . implode('", "', $escaped_param) . '")';

                continue;
            }

            if (is_int($args[$i]) || is_float($args[$i])) {
                $replacements["^{$i}"] = $replacements["\${$i}"] = (string)$args[$i];

                continue;
            }

            if ($args[$i] instanceof Model_Base && !is_array($args[$i]->getPrimaryKey())) {
                $replacements["^{$i}"] = $replacements["\${$i}"] = (int)$args[$i]->getPrimaryKey();

                continue;
            }

            $escaped_param          = $this->sql_escapestring((string)$args[$i]);
            $replacements["^{$i}"]  = $escaped_param;
            $replacements["\${$i}"] = '"' . $escaped_param . '"';
        }

        return strtr($format_query, $replacements);
    }

    /**
     * Get number of rows in result.
     *
     * @param mysqli_result $result
     *
     * @return int
     */
    public function sql_numrows($result = null)
    {
        if ($result === null) {
            return false;
        }

        return $result->num_rows;
    }

    /**
     * Get number of affected rows in previous MySQL operation.
     *
     * @return int
     */
    public function sql_affectedrows()
    {
        return $this->connection->affected_rows;
    }

    /**
     * Execute a query and return a single field from the first row, or null if no rows were found.
     *
     * @param $query
     * @param string|null $field The name of the column to return, set to null to return the first field.
     *
     * @throws Mollie_Database_Exception
     */
    public function sql_fetchone($query, $field = null, array $arguments = [])
    {
        $result = $this->sql_safe_query($query, ...$arguments);

        try {
            if (($return = $this->sql_fetchfield($field === null ? 0 : $field, 0, $result)) === false) {
                return null;
            }

            return $return;
        } finally {
            $this->sql_freeresult($result);
        }
    }

    /**
     * Executes a query and returns the first column from every row in an array
     *
     * @param $format_query
     * @param ...$args mixed Argument to put into the placeholders
     *
     * Usage:
     *  - $1, $2 and $N inside $format_query are replaced by escaped and quoted arguments
     *  - ^1, ^2 and ^N inside $format_query are replaced by escaped arguments WITHOUT
     *       quotes, for LIKE statements and numeric comparisons
     *
     * @return array
     */
    public function sql_fetchcol($format_query, ...$args)
    {
        if (!($result = $this->sql_safe_query($format_query, ...$args)) instanceof mysqli_result) {
            return [];
        }

        $colValues = [];

        while ($row = $result->fetch_row()) {
            $colValues[] = $row[0];
        }

        $this->sql_freeresult($result);

        return $colValues;
    }

    /**
     * Returns a row as associated array from a result set fetched earlier by sql_query().
     *
     * However, in most cases you'd be better of using sql_fetchquery() instead of using sql_query() and this
     * function.
     *
     * @param mysqli_result $query_id A resource returned by sql_query(). If ommitted, it defaults to last query.
     *
     * @see sql_query()
     * @see sql_fetchquery()
     *
     * @return array|bool
     */
    public function sql_fetchrow($query_id = 0)
    {
        if (!$query_id) {
            $query_id = $this->query_result;
        }

        if (!$query_id) {
            return false;
        }

        /*
         * fetch_assoc() returns NULL if there is no next row. Calling functions may expect FALSE, so convert it.
         */
        $result = $query_id->fetch_assoc();

        if ($result === null) {
            return false;
        }

        return $result;
    }

    /**
     * Returns a field of a row in the query result.
     *
     * @param $field string|int The name or index of the field to fetch.
     * @param $rownum int The row number (default row 0)
     * @param $query_id mysqli_result The query result (from sql_query()) to fetch for.
     *
     * @return false|mixed
     */
    public function sql_fetchfield($field, $rownum = 0, $query_id = null)
    {
        if (!$query_id) {
            $query_id = $this->query_result;
        }

        if (!$query_id) {
            return false;
        }

        if ($this->sql_numrows($query_id) === 0) {
            return false;
        }

        $query_id->data_seek($rownum);
        $row = $query_id->fetch_array(MYSQLI_BOTH);

        if (isset($row[$field])) {
            $result = $row[$field];
        } else {
            $result = false;
        }

        $query_id->data_seek(0); // Reset to beginning, I guess.

        return $result;
    }

    /**
     * This function will escape a string for a LIKE query, so it will escape % and _ as well
     *
     * @param string $string The input
     *
     * @return string
     *
     * @author Patrick
     */
    public function sql_escape_like_string($string)
    {
        return strtr($this->sql_escapestring($string), ['%' => '\%', '_' => '\_']);
    }

    /**
     * Returns the ID of the last INSERT query.
     *
     * @return bool|int
     */
    public function sql_nextid()
    {
        return $this->connection->insert_id;
    }

    /**
     * Clear results of the last query and also free memory use by the PHP MySQL module.
     *
     * @param mysqli_result $result_set
     */
    public function sql_freeresult($result_set)
    {
        if ($result_set === $this->query_result) {
            /* Set it to NULL so that it can't get var_dump()'ed. */
            $this->query_result = null;
        }

        if ($this->isCacheEnabled()) {
            return;
        }

        \Webmozart\Assert\Assert::isInstanceOf($result_set, mysqli_result::class);

        $result_set->free();
    }

    /**
     * @return string
     */
    public function sql_escapestring($value)
    {
        if (is_int($value) || is_float($value)) {
            return (string)$value;
        }

        if ($this->sql_connected()) {
            /* Parses strings and NULLs as we want. */
            return $this->connection->real_escape_string($value);
        }

        return strtr($value, [
            "\x00" => "\\\x00",
            "\n"   => "\\\n",
            "\r"   => "\\\r",
            "\\"   => "\\\\",
            "'"    => "\\'",
            "\""   => "\\\"",
            "\x1a" => "\\\x1a",
        ]);
    }

    /**
     * @param string[] $array
     *
     * @return string[]
     */
    protected function sql_escape_array(array $array)
    {
        return array_map([$this, 'sql_escapestring'], $array);
    }

    /**
     * @return string
     */
    public function value_to_sql_field($field_value)
    {
        if ($field_value === null) { // faster than is_null()
            return 'NULL';
        }

        if ($field_value === true) {
            return "1";
        }

        if ($field_value === false) {
            return "0";
        }

        if (is_float($field_value) || is_int($field_value)) {
            return (string)$field_value;
        }

        if (is_array($field_value)) {
            return implode(", ", $this->array_to_sql_fields($field_value));
        }

        // Don't use quotes when it is an integer, or only digits and does not start with "0". todo get rid of this "feature"
        if (ctype_digit($field_value) && $field_value !== "" && mb_strpos($field_value, "0") !== 0 && mb_strlen($field_value) <= 20) {
            return (string)$field_value;
        }

        return '"' . $this->sql_escapestring($field_value) . '"';
    }

    public function array_to_sql_fields(array $array)
    {
        return array_map([$this, 'value_to_sql_field'], $array);
    }

    /**
     * @param        $array_of_fields
     * @param string $prefix
     *
     * @throws Mollie_Database_Exception
     *
     * @return array
     */
    public function sql_columns_from_array_for_where($array_of_fields, $prefix = '')
    {
        return $this->sql_columns_from_array($array_of_fields, $prefix, true);
    }

    /**
     * @param string $prefix
     * @param bool   $for_where
     *
     * @throws Mollie_Database_Exception
     *
     * @return array
     */
    public function sql_columns_from_array(array $array_of_fields, $prefix = '', $for_where = false)
    {
        if ($prefix) {
            $prefix .= '.';
        }

        $result = [];

        foreach ($array_of_fields as $field_name => $field_value) {
            // WHERE <field> IS NULL
            if ($for_where && $field_value === null) {
                $sql_field = "{$prefix}{$field_name} IS NULL";
            }

            // WHERE <comparison>
            elseif ($for_where && is_array($field_value)) {
                if (count($field_value) < 2) {
                    throw new Mollie_Database_Exception('Invalid comparison array for WHERE statement: ' . var_export($field_value, true));
                }

                [$comparison, $value] = $field_value;
                $comparison           = strtoupper($comparison);

                switch ($comparison) {
                    case 'BETWEEN':
                    case 'NOT BETWEEN':
                        \Webmozart\Assert\Assert::isArray($value);
                        \Webmozart\Assert\Assert::keyExists($value, 0);
                        \Webmozart\Assert\Assert::keyExists($value, 1);

                        $sql_field = "{$prefix}{$field_name} {$comparison} " . $this->value_to_sql_field($value[0]);
                        $sql_field .= " AND " . $this->value_to_sql_field($value[1]);

                        break;

                    case 'IN':
                    case 'NOT IN':
                        $values    = $this->array_to_sql_fields($value);
                        $sql_field = "{$prefix}{$field_name} {$comparison}(" . implode(',', $values) . ")";

                        break;

                    case 'GREATEST':
                    case 'LEAST':
                        $values    = $this->array_to_sql_fields($value);
                        $sql_field = "{$prefix}{$field_name} = {$comparison}({$prefix}{$field_name}," . implode(',', $values) . ")";

                        break;

                    case '<>': // Not equal operator
                    case '!=': // Not equal operator
                        if ($value === null) {
                            $sql_field = "{$prefix}{$field_name} IS NOT NULL"; // NULL != NULL === NULL in MySQL land.
                            break;
                        }
                        // fallthrough
                        // no break
                    case '<=>': // NULL-safe equal to operator
                    case '<':
                    case '<=':
                    case '>':
                    case '>=':
                    case 'LIKE':
                    case 'NOT LIKE':
                    case 'LIKE BINARY':
                    case 'NOT LIKE BINARY':
                    case 'REGEXP':
                    case 'NOT REGEXP':
                    case '&':
                    case '~':
                    case '|':
                    case '^':
                        $sql_field = "{$prefix}{$field_name} {$comparison} " . $this->value_to_sql_field($value);

                        break;

                    default:
                        throw new Mollie_Database_Exception("Unknown comparison operator '{$comparison}' for WHERE statement (was " . var_export($field_value, true) . ")");

                     break;
                }
            }
            // UPDATE SET <field>
            elseif (is_array($field_value)) {
                throw new Mollie_Database_Exception('Array not allowed here, got ' . print_r($field_value, true));
            } elseif ($field_name === 0) {
                /*
                 * Assume that someone used ['field', 'value']
                 * instead of ['field' => 'value']
                 */
                throw new Mollie_Database_Exception(
                    "Incorrect usage of WHERE"
                );
            } else {
                $sql_field = "{$prefix}{$field_name} = " . $this->value_to_sql_field($field_value);
            }

            $result[$field_name] = $sql_field;
        }

        return $result;
    }

    /**
     * Check if we are in a transaction.
     *
     * @return bool
     */
    public function in_transaction()
    {
        return $this->_transaction_depth > 0;
    }

    /**
     * Begin a transaction.
     *
     * Transactions can be nested, in that case InnoDB savepoints
     * are used. The transaction will only be committed once the
     * outmost transaction has been committed.
     *
     * Note: when using a try/catch with rollback in the catch,
     * begin should be _outside_ the try.
     */
    public function begin()
    {
        if ($this->_transaction_depth == 0) {
            if (!$this->sql_connected()) {
                $this->sql_connect();
            }

            /*
             * Not in a transaction, begin a transaction.
             */
            $this->log_query("BEGIN");

            $this->connection->begin_transaction();
            $this->run_query_listeners("BEGIN");
        } else {
            /*
             * Already in a transaction, save this savepoint.
             */
            $this->sql_query("SAVEPOINT savepoint{$this->_transaction_depth}");
        }

        $this->_transaction_depth++;
    }

    /**
     * Commit a transaction.
     */
    public function commit()
    {
        if ($this->_transaction_depth == 0) {
            throw new Mollie_Database_Exception("Cannot commit, we are not in a transaction.");
        }

        if ($this->_transaction_depth == 1) {
            $this->log_query("COMMIT");

            $this->connection->commit();
            $this->run_query_listeners("COMMIT");
        } else {
            /*
             * It is not possible to commit savepoints, only
             * transactions can be committed. Remove the savepoint,
             * no longer necessary.
             */
            $savepoint = $this->_transaction_depth - 1;
            $this->sql_query("RELEASE SAVEPOINT savepoint{$savepoint}");
        }
        $this->_transaction_depth--;
    }

    /**
     * Rollback to the last point where commit() was called.
     */
    public function rollback()
    {
        if ($this->_transaction_depth == 0) {
            throw new Mollie_Database_Exception("Cannot rollback, we are not in a transaction.");
        }

        if ($this->_transaction_depth == 1) {
            /*
             * Rollback the transaction.
             */
            $this->log_query("ROLLBACK");

            $this->connection->rollback();
            $this->run_query_listeners("ROLLBACK");
        } else {
            /*
             * Rollback to the last savepoint.
             */
            $savepoint = $this->_transaction_depth - 1;
            $this->sql_query("ROLLBACK TO savepoint{$savepoint}");
        }

        $this->_transaction_depth--;
    }

    /**
     * Protected internal querying function that times, logs and caches the query. Will put results of the query in
     * in $this->query_result property. Will throw a Mollie_Exception_MySQL if there is an error when performing the
     * query (syntax error, connection lost et cetera.
     *
     * @param $query string
     *
     * @throws Mollie_Database_Exception_Query
     */
    protected function _mysql_query($query)
    {
        $this->query_last = $query;

        if ($this->_cache_enabled) {
            $query_hash = md5($query);

            if (isset($this->_cached_results[$query_hash])) {
                $this->query_result  = $this->_cached_results[$query_hash];
                $this->query_last_ms = 0;
                $this->query_result->data_seek(0);

                return;
            }
        }

        $this->num_queries++;

        $before_query_ts = microtime(true);

        try {
            $this->query_result = $this->connection->query($query);
        } catch (mysqli_sql_exception $e) {
            if ($e->getCode() == 1062 /* (ER_DUP_ENTRY) */) {
                throw new Mollie_Database_Exception_Query_DuplicateEntry($e->getMessage(), $e->getCode(), $query, $e);
            }

            if ($e->getCode() == 1213 /* (ER_LOCK_DEADLOCK) */) {
                /*
                 * Transaction is rolled back automatically by MySQL.
                 *
                 * @link https://dev.mysql.com/doc/refman/5.7/en/innodb-deadlocks.html
                 */
                $this->_transaction_depth = 0;

                throw new Mollie_Database_Exception_Query_Deadlock($e->getMessage(), $e->getCode(), $query, $e);
            }

            if (\Core\Strings::startsWith($e->getMessage(), "MySQL server has gone away")) {
                if (PHP_SAPI === "cli" && !$this->in_transaction()) {
                    /*
                     * We're not in a transaction, so we can reset the connection
                     * state on our side, reconnect and carry on on our merry way.
                     *
                     * It is also important that we only reconnect on the CLI. We don't
                     * have any control over the number of Apache processes that try
                     * something. We don't want queries from a DOS to respawn.
                     *
                     * @see https://redmine.mollie.nl/issues/23722
                     */
                    $this->connection = null;
                    $this->sql_connect(); // If the server is down, this will throw again.
                    $this->_mysql_query($query);

                    return;
                }
                /*
                 * In a transaction, cannot recover. Local state and database
                 * state are completely different.
                 */
            }

            /*
             * Convert exceptions to our internal exception class.
             */
            throw new Mollie_Database_Exception_Query($e->getMessage(), 0, $query, $e);
        } finally {
            $this->query_last_ms = microtime(true) - $before_query_ts;
            $this->log_query($this->query_last);
        }

        foreach ($this->query_listeners as $listener) {
            $listener($query);
        }

        if ($this->_cache_enabled && $this->query_result instanceof mysqli_result) {
            $this->_cached_results[$query_hash] = $this->query_result;
        }
    }

    /**
     * Log the query (if necessary).
     *
     * @param $query
     */
    protected function log_query($query)
    {
        if ($this->disable_log) {
            return;
        }

        if (!(MOLLIE_ENV == 'development' || MOLLIE_ENV == 'test') && !defined('MOLLIE_LOG_SQL_OVERRIDE')) {
            return;
        }

        // Do not log on our Continuous Integration builds.
        if (!empty($_SERVER["JENKINS_URL"]) || getenv("CI")) {
            return;
        }

        self::$query_log[] = [
            'sql'      => $query,
            'duration' => $this->query_last_ms,
        ];
    }

    /**
     * Function that wraps sql_safe_query(), fetches the entire result set and calls sql_freeresult().
     *
     * @param string $query             SQL query with argument tokens ($1, ^2...)
     * @param array  $arguments         Arguments that will be escaped and replaced into the query
     * @param string $use_column_as_key (Optional) Resulting array is numeric but you can use the value of a column as key
     *
     * @return array[]
     */
    public function sql_fetchquery($query, $arguments = [], $use_column_as_key = null)
    {
        $result = $this->sql_safe_query($query, ...$arguments);

        if ($use_column_as_key) {
            $rows = [];

            while ($row = $this->sql_fetchrow($result)) {
                $rows[$row[$use_column_as_key]] = $row;
            }
        } else {
            $rows = $this->sql_fetchall($result);
        }

        $this->sql_freeresult($result);

        return $rows;
    }

    /**
     * Fetch a result set, into a big array with all the rows.
     *
     * @param mysqli_result $result
     *
     * @return array[]
     */
    public function sql_fetchall($result)
    {
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    /**
     * Enables MD5-based caching of queries, which uses PHP MySQL module's internal cache.
     */
    public function cacheEnable()
    {
        $this->_cache_enabled = true;
    }

    /**
     * Disables the MD5-based cache.
     */
    public function cacheDisable()
    {
        $this->_cache_enabled = false;

        foreach ($this->_cached_results as $cached_result) {
            $this->sql_freeresult($cached_result);
        }

        $this->_cached_results = [];
    }

    /**
     * @return bool
     */
    public function isCacheEnabled()
    {
        return $this->_cache_enabled;
    }

    /**
     * Get a specific "named lock" from MySQL, for executing a callback.
     *
     * @param string $lock_name
     * @param int    $lock_timeout
     *
     * @throws Exception                            If callback throws an exception
     * @throws Mollie_Database_Exception_Query_Lock If no lock could be obtained.
     *
     * @return mixed Returns whatever the callback returns.
     */
    public function getLockFor($lock_name, callable $callback, $lock_timeout = 10)
    {
        $this->getLock($lock_name, $lock_timeout);

        try {
            return $callback();
        } finally {
            $this->releaseLock($lock_name);
        }
    }

    /**
     * @param string $lock_name
     * @param int    $lock_timeout
     *
     * @throws Mollie_Database_Exception_Query_Lock
     */
    public function getLock($lock_name, $lock_timeout = 10)
    {
        $rows = $this->sql_fetchquery(
            $query = 'SELECT GET_LOCK($1, ^2) AS locked',
            [static::LOCK_PREFIX . $lock_name, (int)$lock_timeout]
        );

        if (empty($rows[0]) || $rows[0]['locked'] != 1) {
            throw new Mollie_Database_Exception_Query_Lock('Failed to obtain named lock.', 0, $this->query_last);
        }
    }

    /**
     * @param string $lock_name
     *
     * @throws Mollie_Database_Exception_Query_Lock
     */
    public function releaseLock($lock_name)
    {
        $rows = $this->sql_fetchquery('SELECT RELEASE_LOCK($1) AS released', [static::LOCK_PREFIX . $lock_name]);

        if (empty($rows[0]) || $rows[0]['released'] != 1) {
            throw new Mollie_Database_Exception_Query_Lock('Failed to release named lock.', 0, $this->query_last);
        }
    }

    /**
     * Register a query listener. This listener will be informed of all queries.
     */
    public function register_query_listener(callable $function)
    {
        $this->query_listeners[spl_object_hash($function)] = $function;
    }

    /**
     * Destroy all query listeners.
     */
    public function destroy_query_listeners(?callable $function = null)
    {
        if ($function === null) {
            $this->query_listeners = [];
        } else {
            unset($this->query_listeners[spl_object_hash($function)]);
        }
    }

    /**
     * @param string $query
     */
    protected function run_query_listeners($query)
    {
        foreach ($this->query_listeners as $listener) {
            $listener($query);
        }
    }

    /**
     * Is the query a data changeing query?
     */
    public static function is_write_query($query)
    {
        if (\Core\Strings::startsWith($query, "SELECT")) {
            return false;
        }

        if (\Core\Strings::startsWith($query, "INSERT") || \Core\Strings::startsWith($query, "UPDATE")) {
            return true;
        }

        return preg_match("!^\\s*(INSERT|UPDATE|DELETE|REPLACE|LOAD DATA)!iS", $query);
    }

    public function inTransactionDo(callable $callable)
    {
        $this->begin();

        try {
            $return_value = $callable();

            $this->commit();

            return $return_value;
        } catch (Throwable $e) {
            if ($this->in_transaction()) {
                $this->rollback();
            }

            throw $e;
        }
    }
}
