<?php
/**
 * Cronjob Exception
 *
 * @author Aine Hickey <aine@mollie.nl> Sep 29, 2011 4:14:28 PM
 * @copyright Copyright (C) Mollie B.V.
 *
 * @see http://www.mollie.nl/
 */
class Mollie_Cronjob_Exception extends Mollie_Exception
{
}
