<?php

/**
 * Run database migrations on the server.
 */
class Mollie_Database_Migrations
{
    /** Magic constant to indicate that we want to migrate to the new version. */
    public const VERSION_NEW = "new";

    /** This is stored in the database to indicate that we have migrated to the "new" version. */
    public const MAGIC_DATABASE_VALUE_FOR_NEW = -1;

    public const DIRECTION_DOWN = "down";
    public const DIRECTION_UP   = "up";

    public const LOCK_NAME = "MIGRATING";

    /**
     * Enable / disable debug mode.
     *
     * @var bool
     */
    private $debug = false;

    /** @var sql_db */
    private $_db;

    /** @var int|string */
    private $current_db_version;

    public function __construct(sql_db $db)
    {
        $this->_db = $db;
    }

    /**
     * Enable / disable debug mode.
     *
     * @param bool $enabled
     */
    final public function setDebugMode($enabled = true)
    {
        $this->debug = $enabled;
    }

    /**
     * @codeCoverageIgnore
     *
     * @param $string
     */
    protected function debug($string)
    {
        if (MOLLIE_ENV === 'test') {
            return;
        }

        if ($this->debug || posix_isatty(STDOUT)) {
            echo date("[Y-m-d H:i:s] ") . trim($string) . PHP_EOL;
        }
    }

    /**
     * Get the current database version, will return either the database version (integer) or the special constant
     * BLEEDING_EDGE to indicate that the /new/ migration has been executed.
     *
     * @return int|string
     */
    public function getCurrentDatabaseVersion()
    {
        if ($this->current_db_version === null) {
            $result = $this->_db->sql_fetchone('SELECT version FROM schema_info LIMIT 1');

            if ($result === null) {
                throw new Mollie_Database_Migrations_Exception("Cannot determine current schema version");
            }

            if ($result != self::MAGIC_DATABASE_VALUE_FOR_NEW) {
                $this->current_db_version = (int)$result;
            } else {
                $this->current_db_version = self::VERSION_NEW;
            }
        }

        return $this->current_db_version;
    }

    /**
     * Get the migration scripts path,
     *
     * @return string
     */
    public function getMigrationPath()
    {
        return MOLLIE_ROOT_PATH . "migrations" . DIRECTORY_SEPARATOR;
    }

    /**
     * Get all available version numbers, such as "0001" or the special number "new".
     *
     * @return array|string[]
     */
    public function getAllVersions()
    {
        $paths = glob("{$this->getMigrationPath()}*", GLOB_ONLYDIR);

        $paths = array_filter(
            array_map(function ($each) {
                return str_replace($this->getMigrationPath(), "", $each);
            }, $paths),
            function ($each) {
                return (MOLLIE_ENV == "test" && $each == Mollie_Database_Migrations::VERSION_NEW) || preg_match("!^\\d{4}\$!", $each);
            }
        );

        return $paths;
    }

    /**
     * @param int $target_version
     */
    public function migrateToVersion($target_version)
    {
        $start = microtime(true);

        try {
            $current_version = $this->getCurrentDatabaseVersion();

            $this->debug("Current schema version is \"{$current_version}\", target schema version is \"{$target_version}\".");

            if ($current_version === $target_version) {
                /*
                 * Nothing to migrate.
                 */
                $this->debug("Already on correct schema version.");

                return;
            }

            if ($target_version !== self::VERSION_NEW) {
                /*
                 * If we are on the bleeding edge, and we want to migrate to another version, we first have to migrate one
                 * version down.
                 */
                if ($current_version === self::VERSION_NEW) {
                    $this->runMigration(self::VERSION_NEW, self::DIRECTION_DOWN);
                    $current_version = $this->getCurrentDatabaseVersion();
                }

                $difference = $target_version - $current_version;

                if ($difference > 0) {
                    for ($i = 1; $i <= $difference; $i++) {
                        $this->runMigration($current_version + $i, self::DIRECTION_UP);
                    }

                    return;
                }

                if ($difference < 0) {
                    for ($i = 0; $i > $difference; $i--) {
                        $this->runMigration($current_version + $i, self::DIRECTION_DOWN);
                    }
                }

                return;
            }

            $all_versions = $this->getAllVersions();

            if (end($all_versions) == self::VERSION_NEW) {
                $this->migrateToVersion(prev($all_versions));
                $this->runMigration(self::VERSION_NEW, self::DIRECTION_UP);
            } else {
                $this->migrateToVersion(end($all_versions));
            }
        } finally {
            $this->debug(sprintf("Done running migrations, took %.2fs.", microtime(true) - $start));
        }
    }

    /**
     * Run a single migration. Will run the migration, in the appropriate direction, and update the current database
     * version appropriately.
     *
     * @param int $migration
     * @param $direction
     *
     * @return bool
     */
    protected function runMigration($migration, $direction)
    {
        $this->debug("Running schema migration \"{$migration}\" in {$direction} direction.");

        if ($migration == self::VERSION_NEW) {
            $filename = sprintf("%1\$s%2\$s/%3\$s.sql", $this->getMigrationPath(), $migration, $direction);
        } else {
            $filename = sprintf("%1\$s%2\$04d/%3\$s.sql", $this->getMigrationPath(), $migration, $direction);
        }

        if (!$this->is_readable($filename)) {
            throw new Mollie_Database_Migrations_Exception("Expecting file {$filename} to exist, yet it does not.");
        }

        $this->_db->getLock(self::LOCK_NAME);

        try {
            $sql_file_content = $this->file_get_contents($filename);

            if (!empty($sql_file_content)) {
                $this->_db->sql_multi_query($sql_file_content);
            }

            if ($direction == self::DIRECTION_UP) {
                // We are now at this version.
                $this->setCurrentDatabaseVersion($migration);
            } else {
                $all_versions = $this->getAllVersions();

                if ($migration == self::VERSION_NEW && end($all_versions) == self::VERSION_NEW) {
                    $this->setCurrentDatabaseVersion((int)(ltrim(prev($all_versions), "0")));
                } else {
                    $this->setCurrentDatabaseVersion($migration - 1);
                }
            }

            $this->debug("Done running schema migration \"{$migration}\" {$direction}.");
            $this->_db->releaseLock(self::LOCK_NAME);

            return true;
        } catch (Mollie_Database_Exception $e) {
            $this->debug("An error occurred while running the migration: {$e->getMessage()}");
            $this->_db->releaseLock(self::LOCK_NAME);

            throw new Mollie_Database_Migrations_Exception("Error running migration {$migration} {$direction}: {$e->getMessage()}", $e->getCode(), $e);
        }
    }

    /**
     * @param $filename
     *
     * @return string
     * @codeCoverageIgnore
     */
    protected function file_get_contents($filename)
    {
        return file_get_contents($filename);
    }

    /**
     * @param $filename
     *
     * @return bool
     * @codeCoverageIgnore
     */
    protected function is_readable($filename)
    {
        return is_readable($filename);
    }

    /**
     * Set the current database version.
     *
     * @param int|string $version A version or the BLEEDING_EDGE constant.
     *
     * @return bool
     */
    protected function setCurrentDatabaseVersion($version)
    {
        $this->debug("Setting schema version to \"{$version}\".");

        if ($version !== self::VERSION_NEW) {
            $db_version = (int)$version;
        } else {
            $db_version = self::MAGIC_DATABASE_VALUE_FOR_NEW;
        }
        $this->_db->sql_safe_query('UPDATE schema_info SET version = ^1 LIMIT 1', $this->_db->value_to_sql_field($db_version));
        $this->current_db_version = $version;

        /*
         * It is not important if any rows were updated, the query has succeeded so the version is updated for sure
         * now.
         */
        return true;
    }

    /**
     * Get the last version that is available and that we can migrate to.
     *
     * @return int|string
     */
    public function getLastVersion()
    {
        $versions = $this->getAllVersions();

        return end($versions);
    }
}
