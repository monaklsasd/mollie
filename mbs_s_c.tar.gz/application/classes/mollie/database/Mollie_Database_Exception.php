<?php
/**
 * Mollie Database Exception
 *
 * @author Rick Wong <wong@mollie.nl>
 * @copyright Copyright (C) Mollie B.V.
 */
class Mollie_Database_Exception extends Mollie_Exception
{
}
