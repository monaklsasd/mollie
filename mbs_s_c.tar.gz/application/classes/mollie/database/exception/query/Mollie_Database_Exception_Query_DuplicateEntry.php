<?php
/**
 * Thrown when there is a duplicate key error.
 */
class Mollie_Database_Exception_Query_DuplicateEntry extends Mollie_Database_Exception_Query
{
}
