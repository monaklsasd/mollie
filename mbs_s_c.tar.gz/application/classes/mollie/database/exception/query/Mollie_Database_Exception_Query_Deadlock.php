<?php
/**
 * Thrown when there is a dead lock detected during the transaction.
 */
class Mollie_Database_Exception_Query_Deadlock extends Mollie_Database_Exception_Query
{
}
