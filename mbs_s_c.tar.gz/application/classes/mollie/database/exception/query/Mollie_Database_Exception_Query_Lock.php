<?php
/**
 * Thrown when there is an error related to GET_LOCK / RELEASE_LOCK
 */
class Mollie_Database_Exception_Query_Lock extends Mollie_Database_Exception_Query
{
}
