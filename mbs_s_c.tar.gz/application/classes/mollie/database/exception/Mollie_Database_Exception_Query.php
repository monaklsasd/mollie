<?php
/**
 * This exception is triggered when there is a MySQL error, that is usually a syntax error.
 */
class Mollie_Database_Exception_Query extends Mollie_Database_Exception
{
    /**
     * The query that triggered the MySQL error.
     *
     * @var string
     */
    protected $query;

    /**
     * @param string $message
     * @param int    $code
     * @param string $query
     */
    public function __construct($message, $code, $query, ?Exception $previous = null)
    {
        $this->query = $query;
        parent::__construct($message . " (query was: {$query})", $code, $previous);
    }

    /**
     * Get the MySQL error, e.g. "You have an error in your SQL syntax; check the manual that corresponds to your MySQL
     * server version for the right syntax to use near"
     *
     * @return string
     */
    public function getMySQLErrorMessage()
    {
        return $this->getMessage();
    }

    /**
     * Return the MySQL error code.
     *
     * @see http://dev.mysql.com/doc/refman/5.5/en/error-messages-server.html
     *
     * @return int
     */
    public function getMySQLErrorCode()
    {
        return $this->getCode();
    }
}
