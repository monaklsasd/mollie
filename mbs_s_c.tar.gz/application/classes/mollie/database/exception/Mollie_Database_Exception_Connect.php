<?php
/**
 * This exception is triggered when there is a MySQL connection error, that is usually an authorization error.
 */
class Mollie_Database_Exception_Connect extends Mollie_Database_Exception
{
}
