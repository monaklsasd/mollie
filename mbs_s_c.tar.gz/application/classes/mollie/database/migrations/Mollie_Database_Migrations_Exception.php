<?php

class Mollie_Database_Migrations_Exception extends Mollie_Exception
{
}
