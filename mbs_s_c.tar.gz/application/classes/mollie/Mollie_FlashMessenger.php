<?php
/**
 * Flash Messenger
 *
 * This is used to send flash message through the SESSION from one page to
 * another with redirects.
 *
 * @author Aine Hickey <aine@mollie.nl> Jul 25, 2011 2:33:24 PM
 * @copyright Copyright (C) Mollie B.V.
 *
 * ------------------------------------------------------------*
 *
 * @example How to use
 *
 * Page 1 - create message:
 * $flash = new Mollie_FlashMessenger();
 * $flash->addMessage('Hello World', 'error');
 *
 * Page 2 - show message:
 * // Controller - Get message
 * $flash = new Mollie_FlashMessenger();
 * $flash_message = $flash->getMessage(); // Will automatically delete message
 *
 * // View Display messgae
 * $messagebox = new Helper_View_MessageBox();
 * $messagebox->addFlashMessage($flash_message);
 * echo $messagebox->render();
 *
 *------------------------------------------------------------*
 */
class Mollie_FlashMessenger implements Countable
{
    public function __construct()
    {
        if (empty($_SESSION['flash'])) {
            $_SESSION['flash'] = [];
        }
    }

    /**
     * Check if messages exist
     *
     * @return bool
     */
    public function hasMessages()
    {
        if (isset($_SESSION['flash']) && !empty($_SESSION['flash'])) {
            return true;
        }

        return false;
    }

    /**
     * Get count of number of flash messages
     *
     * @return int
     */
    public function count()
    {
        if ($this->hasMessages()) {
            return count($_SESSION['flash']);
        }

        return 0;
    }

    /**
     * Add message
     *
     * @param string $message
     * @param string $type
     */
    public function addMessage($message, $type = Helper_View_MessageBox::INFO_BOX)
    {
        foreach ($_SESSION['flash'] as $flash_message) {
            /** @var Mollie_FlashMessenger_Message $flash_message */
            if ($flash_message->getMessage() == $message && $flash_message->getType() == $type) {
                // This error is already in the flash messenger.
                return;
            }
        }

        // Convert to flash message object
        $flash_message = new Mollie_FlashMessenger_Message();
        $flash_message->setMessage($message)
            ->setType($type);

        $_SESSION['flash'][] = $flash_message;
    }

    /**
     * Delete all messages
     */
    public function deleteAll()
    {
        unset($_SESSION['flash']);
    }

    /**
     * Get message. Will return FALSE if there are nog messages available.
     *
     * @return bool|Mollie_FlashMessenger_Message if no message is available
     */
    public function getMessage()
    {
        if ($this->hasMessages()) {
            return array_shift($_SESSION['flash']);
        }

        return false;
    }

    /**
     * Get messages
     *
     * @return bool|Mollie_FlashMessenger_Message[] if no messages are available
     */
    public function getMessages()
    {
        if ($this->hasMessages()) {
            $flash_messages = $_SESSION['flash'];

            unset($_SESSION['flash']);

            return $flash_messages;
        }

        return false;
    }
}
