<?php

interface Mollie_Config_Database
{
    /**
     * @return string
     */
    public function getHostname();

    /**
     * @return string
     */
    public function getUsername();

    /**
     * @return string
     */
    public function getPassword();

    /**
     * @return string
     */
    public function getDatabaseName();
}
