<?php
/**
 * The email in Mollie is configured in an XML file. For every type of email an XML config file exists. The config file
 * defines stuff such as the body of the email, the subject, whether or not to include a header and a footer, and from
 * which email address the email will be sent.
 *
 * The XML file is structured as such:
 *
 * <?xml version="1.0" encoding="UTF-8" ?>
 *  <email>
 *   <subject>iDEAL-betalingen zijn op uw account geactiveerd</subject> <!-- smarty tags allowed -->
 *   <header>true</header>
 *   <footer>true</footer>
 *   <from>
 *    <name>Mollie iDEAL controle</name> <!-- optional, defaults to DEFAULT_FROM_NAME -->
 *    <email>ideal@mollie.nl</email> <!-- optional, defaults to DEFAULT_EMAIL_ADDRESS -->
 *   </from>
 *   <body xmlns="http://www.w3.org/1999/xhtml"> <!-- you can use HTML directly in this element. -->
 *    <p>Goed nieuws! Uw account is nu gereed om iDEAL transacties te ontvangen. Alle stappen zijn goedgekeurd.</p>
 *   </body>
 * </email>
 *
 * Note: the config file does not have to be valid XML, but once rendered it must be valid XML! So you can use
 * constructs like {if $i > 5}, but the output *must* be valid XML.
 *
 * Smarty commands can be used in any field and thus are not limited to the body.
 */
class Mollie_Mail_Config extends SimpleXMLElement
{
    public const DEFAULT_FROM_EMAIL = "info@mollie.nl";
    public const DEFAULT_FROM_NAME  = "Mollie";

    /** @var SimpleXMLElement */
    public $subject;

    /** @var SimpleXMLElement */
    public $body;

    /** @var SimpleXMLElement */
    public $header;

    /** @var SimpleXMLElement */
    public $footer;

    /** @var SimpleXMLElement */
    public $inmail;

    /** @var SimpleXMLElement|null */
    public $from;

    /** @var string */
    protected $to_email;

    /** @var string */
    protected $to_name;

    /**
     * De taal waarin de email opgesteld moet worden.
     *
     * @var string
     */
    protected $preferred_language = Mollie_Mail::LANG_NL;

    /** @var array */
    protected $cache = [];

    /**
     * Get the company which is the sender of this email, e.g. Model_Company::MOLLIE or Model_Company::MOBILETULIP.
     *
     * @return int
     */
    public function getCompany()
    {
        if (preg_match('/@mobiletulip\.com$/i', $this->getFromEmail())) {
            return Model_Company::MOBILETULIP;
        }

        if (preg_match('/@messagebird\.com$/i', $this->getFromEmail())) {
            return Model_Company::MESSAGEBIRD;
        }

        return Model_Company::MOLLIE;
    }

    /**
     * Verkrijg de inhoud van een tag, in de juiste taal indien mogelijk.
     *
     * @param $tag_name string
     *
     * @throws Mollie_Mail_Exception_TagNotFound
     *
     * @return string
     */
    protected function getTagContentByPreferredLanguage($tag_name)
    {
        $cache_id = "{$this->preferred_language}:{$tag_name}";

        if (isset($this->cache[$cache_id])) {
            return $this->cache[$cache_id];
        }

        // First check if a tag with language exists...
        /** @var SimpleXMLElement[] $tags */
        $tags = $this->xpath(sprintf("//email/%s[@lang='%s']", $tag_name, $this->preferred_language));

        if (count($tags) > 1) {
            throw new Mollie_Mail_Exception_TagNotFound("Found multiple elements of {$tag_name} with language {$this->preferred_language}, configuration error.");
        }

        if (empty($tags)) {
            // Check if an unspecified tag exists.
            $tags = $this->xpath(sprintf("//email/%s[not(@lang)]", $tag_name));

            if (empty($tags)) {
                throw new Mollie_Mail_Exception_TagNotFound("Cannot find a tag {$tag_name}, configuration error");
            }
        }

        $tag     = $tags[0];
        $content = $tag->asXml();

        // We willen de innerXml, niet de tag zelf:
        $tags     = explode("/", $tag_name);
        $tag_name = array_pop($tags);
        $content  = trim(preg_replace("!<{$tag_name}[^>]*>(.*)</{$tag_name}>!si", "$1", $content));

        return $this->cache[$cache_id] = $content;
    }

    /**
     * Get the subject as configured in the XML config file.
     *
     * @return string
     */
    public function getSubject()
    {
        return $this->getTagContentByPreferredLanguage("subject");
    }

    /**
     * Get the body as configured in the XML config file.
     *
     * @return string
     */
    public function getBody()
    {
        return $this->getTagContentByPreferredLanguage("body");
    }

    /**
     * Get the body as configured in the XML config file.
     *
     * @return string
     */
    public function getAltBody()
    {
        return $this->getTagContentByPreferredLanguage("altbody");
    }

    public function hasInmail()
    {
        $inmail = $this->getTagContentByPreferredLanguage("inmail");

        if ($inmail === "true") {
            return true;
        }

        return false;
    }

    /**
     * Should the email include a header? Defaults to true.
     *
     * @return bool
     */
    public function hasHeader()
    {
        try {
            $header = $this->getTagContentByPreferredLanguage("header");

            if ($header === "false") {
                return false;
            }
        } catch (Mollie_Exception $e) {
            // No header present.
        }

        return true;
    }

    /**
     * Should the email include a footer with a signature? Defaults to true.
     *
     * @return bool
     */
    public function hasFooter()
    {
        try {
            $footer = $this->getTagContentByPreferredLanguage("footer");

            if ($footer === "false") {
                return false;
            }
        } catch (Mollie_Exception $e) {
            // No footer present
        }

        return true;
    }

    public function importFromMail(Mollie_Mail $mail)
    {
        $this->to_email           = $mail->getToAddress();
        $this->to_name            = $mail->getToName();
        $this->preferred_language = $mail->getPreferredLanguage();
    }

    public function getToEmail()
    {
        return $this->to_email;
    }

    public function getToName()
    {
        return $this->to_name;
    }

    public function getFromEmail()
    {
        try {
            return $this->getTagContentByPreferredLanguage("from/email");
        } catch (Mollie_Mail_Exception $e) {
            return self::DEFAULT_FROM_EMAIL;
        }
    }

    public function getFromName()
    {
        try {
            return $this->getTagContentByPreferredLanguage("from/name");
        } catch (Mollie_Mail_Exception $e) {
            return self::DEFAULT_FROM_NAME;
        }
    }
}
