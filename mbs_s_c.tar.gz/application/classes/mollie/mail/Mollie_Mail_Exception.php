<?php

class Mollie_Mail_Exception extends Mollie_Exception
{
}
