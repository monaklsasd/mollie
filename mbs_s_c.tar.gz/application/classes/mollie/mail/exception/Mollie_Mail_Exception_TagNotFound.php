<?php

class Mollie_Mail_Exception_TagNotFound extends Mollie_Mail_Exception
{
}
