<?php

/**
 * Wrapper for Mollie_Logger that also outputs on commandline if a TTY is available
 */
class Mollie_WorkerLogger extends Mollie_Logger
{
    protected function _logToStdout($type, $title, $message)
    {
        if (posix_isatty(STDOUT) && MOLLIE_ENV != "test") {
            printf(
                "[%s] %s %s - %s%s\n",
                date('Y-m-d H:i:s'),
                $this->_request_id,
                strtoupper($type),
                $title,
                " (" . (isset($this->_call_site) ? $this->_call_site : '') . ")"
            );
        }
    }

    protected function _createLogObj($type, $category, $title, $message)
    {
        $this->_logToStdout($type, $title, $message);
        parent::_createLogObj($type, $category, $title, $message);
    }
}
