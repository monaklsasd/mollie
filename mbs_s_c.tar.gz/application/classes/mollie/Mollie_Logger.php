<?php
/**
 * Mollie Logger
 *
 * @copyright Copyright (C) Mollie B.V.
 *
 * @see http://www.mollie.nl/
 */
class Mollie_Logger
{
    /** Types */
    public const INFO    = 'info';
    public const DEBUG   = 'debug';
    public const WARNING = 'warning';
    public const ERROR   = 'error';

    /** Categories */
    public const LOG_CATEGORY_WEBSITE      = 'website';
    public const LOG_CATEGORY_IMPORTS      = 'imports';
    public const LOG_CATEGORY_IDEAL        = 'ideal';
    public const LOG_CATEGORY_MISC         = 'misc';
    public const LOG_CATEGORY_SECURITY     = 'security';
    public const LOG_CATEGORY_SYSTEM       = 'system';
    public const LOG_CATEGORY_BANKTRANSFER = 'banktransfer';
    public const LOG_CATEGORY_SETTLEMENT   = 'settlement';

    /** @var sql_db */
    protected $_db;

    /** @var string IP address for this request. */
    protected $_ip_address;

    /** Log title prefix. Prepended to all messages when set */
    protected $_call_site;

    /**
     * User ID
     *
     * @var int
     */
    protected $_user_id = 0;

    /** @var string unique ID to match multiple log messages with one request */
    protected $_request_id;

    public function __construct(sql_db $db)
    {
        $this->_db = $db;
    }

    /**
     * Set user ID
     *
     * @param int $id
     */
    public function setUserId($id)
    {
        if ($this->_user_id == 0) {
            $this->_user_id = $id;
        }
    }

    /**
     * @param string $ip_address
     */
    public function setRemoteIpAddress($ip_address)
    {
        $this->_ip_address = $ip_address;
    }

    /**
     * @param string $request_id
     */
    public function setRequestId($request_id)
    {
        $this->_request_id = $request_id;
    }

    /**
     * Set Title Prefix
     */
    public function _determineCallSite()
    {
        $logPrefix = null;

        foreach (debug_backtrace(null) as $trace) {
            if (isset($trace['class']) && $trace['class'] == self::class && preg_match('~^log_(error|info|debug|warning)$~i', $trace['function'])) {
                $logPrefix = str_replace(realpath(MOLLIE_APPDIR), '', $trace['file']) . ':' . $trace['line'];

                if ($logPrefix[0] == '/') {
                    $logPrefix = substr($logPrefix, 1);
                }

                break;
            }
        }
        $this->_call_site = $logPrefix;
    }

    public function unsetCallSite()
    {
        $this->_call_site = null;
    }

    /**
     * Create log record and save
     *
     * @param string $type
     * @param string $category
     * @param string $title
     * @param string $message
     *
     * @return bool
     */
    protected function _createLogObj($type, $category, $title, $message)
    {
        $log             = new Model_Log($this->_db);
        $log->type       = $type;
        $log->title      = $title;
        $log->request_id = $this->_request_id;
        $log->category   = $category;

        if ($this->_user_id) {
            $log->user_id = $this->_user_id;
        }

        $log->ip_address = $this->_ip_address;

        if (PHP_SAPI == 'cli') {
            $log->ip_address = $_SERVER['SERVER_ADDR'] ?? "127.0.0.1";
        }

        $log->message = sprintf(
            "%s%s",
            $this->_call_site,
            $message ? "\n\n{$message}" : ""
        );

        return $log->save();
    }

    /**
     * Log info message
     *
     * @param string $category
     * @param string $title
     * @param string $message
     */
    public function log_info($category, $title, $message)
    {
        $this->_determineCallSite();

        return $this->_createLogObj(self::INFO, $category, $title, $message);
    }

    /**
     * Log warning message
     *
     * @param string $category
     * @param string $title
     * @param string $message
     */
    public function log_warning($category, $title, $message)
    {
        $this->_determineCallSite();

        return $this->_createLogObj(self::WARNING, $category, $title, $message);
    }

    /**
     * Log error message
     *
     * @param string $category
     * @param string $title
     * @param string $message
     */
    public function log_error($category, $title, $message)
    {
        $this->_determineCallSite();
        $result = $this->_createLogObj(self::ERROR, $category, $title, $message);

        $exception = new Exception(sprintf("[%s] %s", $category, $title));
        apm_log_exception($exception);

        return $result;
    }

    /**
     * Log debug message
     *
     * @param string $category
     * @param string $title
     * @param string $message
     */
    public function log_debug($category, $title, $message)
    {
        $this->_determineCallSite();

        return $this->_createLogObj(self::DEBUG, $category, $title, $message);
    }
}
