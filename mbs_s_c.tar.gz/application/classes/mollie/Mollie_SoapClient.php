<?php
/**
 * Mollie SOAP class
 *
 * @author Aine Hickey <aine@mollie.nl> Oct 12, 2011 4:26:49 PM
 * @copyright Copyright (C) Mollie B.V.
 *
 * @see http://www.mollie.nl/
 */
abstract class Mollie_SoapClient
{
    /**
     * Soap Client
     *
     * @var SoapClient
     */
    protected $_soap_client;
    /**
     * Trabing
     *
     * @var bool
     */
    protected $_trace = false;
    /**
     * Trace record
     *
     * @var array
     */
    protected $_trace_record = [];
    /**
     * Errors
     *
     * @var array
     */
    protected $_errors = [];

    /**
     * Constructor
     *
     * @param bool $trace Enable tracing
     */
    public function __construct(SoapClient $soap_client, $trace = false)
    {
        $this->_soap_client = $soap_client;
        $this->_trace       = $trace;
    }

    /**
     * Get errors
     *
     * @return string[]
     */
    public function getErrors()
    {
        return $this->_errors;
    }

    /**
     * Add error
     *
     * @param string $error
     *
     * @return self
     */
    public function addError($error)
    {
        $this->_errors[] = $error;

        return $this;
    }

    /**
     * Get trace
     *
     * @return string
     */
    public function getTrace()
    {
        return $this->_trace_record;
    }

    /**
     * Reset connection
     * As the connection is reused, we may need to empty the saved info.
     */
    public function reset()
    {
        $this->_errors       = [];
        $this->_trace_record = [];
    }

    /**
     * Call SOAP functoin
     *
     * @param string $function_name
     *
     * @return bool Whether call was suscessful
     */
    protected function _call($function_name, array $arguments)
    {
        try {
            // Make SOAP call
            $results = $this->_soap_client->{$function_name}($arguments);
            // Get trace, if requested
            if ($this->_trace) {
                $this->_trace_record = [
                    'last_request_headers' => $this->_soap_client->__getLastRequestHeaders(),
                    'last_request'         => $this->_soap_client->__getLastRequest(),
                    'last_response_header' => $this->_soap_client->__getLastResponseHeaders(),
                    'last_response'        => $this->_soap_client->__getLastResponse(),
                ];
            }

            return $results;
        } catch (SoapFault $e) {
            // Catch any Soap faults and convert to an error message
            $this->addError($e->getMessage());

            return false;
        }
    }
}
