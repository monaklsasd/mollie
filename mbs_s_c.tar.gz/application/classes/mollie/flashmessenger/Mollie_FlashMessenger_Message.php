<?php
/**
 * Flash Message Object
 *
 * @author Aine Hickey <aine@mollie.nl> Oct 7, 2011 1:32:39 PM
 * @copyright Copyright (C) Mollie B.V.
 *
 * @see http://www.mollie.nl/
 */
class Mollie_FlashMessenger_Message
{
    /**
     * Message
     *
     * @var string
     */
    protected $_message;
    /**
     * Type
     *
     * @var string
     */
    protected $_type;

    /**
     * Get message
     *
     * @return string
     */
    public function getMessage()
    {
        return $this->_message;
    }

    /**
     * Get type
     *
     * @return string
     */
    public function getType()
    {
        return $this->_type;
    }

    /**
     * Set the message
     *
     * @param string $message
     *
     * @return Mollie_FlashMessenger_Message
     */
    public function setMessage($message)
    {
        if (!(is_string($message) || is_numeric($message))) {
            throw new Mollie_Exception('Message must be string');
        }

        $this->_message = (string)$message;

        return $this;
    }

    /**
     * Set the type
     *
     * @param string $type
     *
     * @return Mollie_FlashMessenger_Message
     */
    public function setType($type)
    {
        if (!(is_string($type) || is_numeric($type))) {
            throw new Mollie_Exception('Type must be string');
        }

        $this->_type = (string)$type;

        return $this;
    }
}
