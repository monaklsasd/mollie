<?php

/**
 * These are the Database Factory and Object classes that are used
 * by the website, daemons and miscellaneous scripts. The factory
 * class has support for different environment configurations. The
 * object class has methods for interacting with the PHP MySQL
 * module, basically wrapping the module. But it also includes
 * some handy methods like safe querying, query caching/logging
 * and fetching entire result sets.
 *
 * @author Mollie Development team <info@mollie.nl>
 * @copyright Copyright (C) Mollie B.V.
 */

/**
 * @deprecated we use doctrine now, but because the error database is hard to inject in legacy classes, this file is still here.
 */
class DbFactory
{
    /** @var sql_db|null */
    private static $main;

    /** @var sql_db|null */
    private static $error;

    public static function instance(): ?sql_db
    {
        return self::$main;
    }

    public static function error(): ?sql_db
    {
        return self::$error;
    }

    public static function setMain(sql_db $db): void
    {
        self::$main = $db;
    }

    public static function setError(sql_db $db): void
    {
        self::$error = $db;
    }
}
