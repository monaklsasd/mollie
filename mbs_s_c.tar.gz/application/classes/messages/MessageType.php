<?php

namespace Messages;

use MyCLabs\Enum\Enum;

/**
 * @method static self::EXCEPTIONAL_TRANSACTIONS()
 */
final class MessageType extends Enum
{
    public const EXCEPTIONAL_TRANSACTIONS = "exceptional_transactions";
}
