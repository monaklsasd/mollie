<?php

namespace Bootstrappers;

use Core\Di\Bootstrappers\SingleRunBootstrapper;
use Core\Di\DependencyInjector;
use CrappyStaticDi;

class CrappyStaticDiBootstrapper implements SingleRunBootstrapper
{
    /**
     * {@inheritdoc}
     */
    public function boot(DependencyInjector $di): void
    {
        CrappyStaticDi::setDependencyInjector($di);
    }
}
