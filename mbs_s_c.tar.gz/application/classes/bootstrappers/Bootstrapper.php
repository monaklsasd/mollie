<?php

namespace Bootstrappers;

use Core\Di\Bootstrappers\BootstrapperRegistry;
use Core\Di\DependencyInjector;

class Bootstrapper
{
    public static function registerApplicationBootstrappers(DependencyInjector $dependency_injector)
    {
        $bootstrapper_registry = $dependency_injector->getInstance(BootstrapperRegistry::class);

        $bootstrapper_class_names = require MOLLIE_CONFIG_PATH . "bootstrappers/application_bootstrappers.php";

        $bootstrapper_registry->setBootstrapperClasses($bootstrapper_class_names);
        $bootstrapper_registry->register($dependency_injector);
    }

    public static function registerCronjobBootstrappers(DependencyInjector $dependency_injector)
    {
        $bootstrapper_registry = $dependency_injector->getInstance(BootstrapperRegistry::class);

        $bootstrapper_class_names = require MOLLIE_CONFIG_PATH . "bootstrappers/cronjob_bootstrappers.php";

        $bootstrapper_registry->setBootstrapperClasses($bootstrapper_class_names);
        $bootstrapper_registry->register($dependency_injector);
    }
}
