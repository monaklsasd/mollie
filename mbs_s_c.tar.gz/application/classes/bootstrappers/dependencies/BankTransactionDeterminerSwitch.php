<?php

namespace Bootstrappers\Dependencies;

use Core\Di\Bootstrappers\DependencyBootstrapper;
use Core\Di\DependencyInjector;
use Determination\BankTransactionDeterminer;
use Determination\LegacyBankTransactionDeterminer;

class BankTransactionDeterminerSwitch implements DependencyBootstrapper
{
    public function getClasses(): array
    {
        return [
            BankTransactionDeterminer::class,
        ];
    }

    public function instantiate(DependencyInjector $di, string $requested_class)
    {
        /**
         * Currently always using legacy bank transaction determiner.
         */
        return $di->getInstance(LegacyBankTransactionDeterminer::class);
    }
}
