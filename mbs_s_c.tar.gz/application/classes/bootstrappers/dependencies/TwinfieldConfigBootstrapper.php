<?php

namespace Bootstrappers\Dependencies;

use Accounting\Twinfield\ApiConnectors\ApiConnectorFactory;
use Accounting\Twinfield\ApiConnectors\OpenIdApiConnectorFactory;
use Accounting\Twinfield\Config as TwinfieldConfig;
use AccountViewConfiguration;
use Config_Accountview;
use Config_Twinfield;
use Core\Di\Bootstrappers\DependencyBootstrapper;
use Core\Di\DependencyInjector;

class TwinfieldConfigBootstrapper implements DependencyBootstrapper
{
    /**
     * {@inheritdoc}
     */
    public function getClasses(): array
    {
        return [
            TwinfieldConfig::class,
            ApiConnectorFactory::class,
            AccountViewConfiguration::class,
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function instantiate(DependencyInjector $di, string $requested_class)
    {
        if ($requested_class === ApiConnectorFactory::class) {
            return new OpenIdApiConnectorFactory($di->get(TwinfieldConfig::class));
        }

        if ($requested_class === AccountViewConfiguration::class) {
            return $di->get(Config_Accountview::class);
        }

        if ($requested_class === TwinfieldConfig::class) {
            return $di->get(Config_Twinfield::class);
        }
    }
}
