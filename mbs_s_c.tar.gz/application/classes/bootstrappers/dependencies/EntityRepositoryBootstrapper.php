<?php

namespace Bootstrappers\Dependencies;

use App\Entity\ExceptionalTransactions\Suspension;
use App\Entity\Privilege;
use App\Entity\User;
use App\Repository\ExceptionalTransactions\SuspensionRepository;
use App\Repository\PrivilegeRepository;
use App\Repository\UserRepository;
use Core\Di\Bootstrappers\DependencyBootstrapper;
use Core\Di\DependencyInjector;
use Doctrine\ORM\EntityManager;
use LogicException;

class EntityRepositoryBootstrapper implements DependencyBootstrapper
{
    private const ENTITY_REPOSITORY_MAPPING = [
        Privilege::class  => PrivilegeRepository::class,
        Suspension::class => SuspensionRepository::class,
        User::class       => UserRepository::class,
    ];

    public function getClasses(): array
    {
        return array_unique(self::ENTITY_REPOSITORY_MAPPING);
    }

    public function instantiate(DependencyInjector $di, string $requested_class)
    {
        if (!in_array($requested_class, self::ENTITY_REPOSITORY_MAPPING, true)) {
            throw new LogicException(sprintf(
                'Repository %s cannot be injected through DI.',
                $requested_class
            ));
        }

        // try
        $entity_manager = $di->getInstance(EntityManager::class);

        $entity_class_name = array_search($requested_class, self::ENTITY_REPOSITORY_MAPPING, true);
        $repository        = $entity_manager->getRepository($entity_class_name);

        if (!$repository instanceof $requested_class) {
            throw new LogicException(sprintf(
                'Repository class is not properly defined for entity: %s (expecting an instance of: %s, got: %s)',
                $entity_class_name,
                $requested_class,
                get_class($repository)
            ));
        }

        return $repository;
    }
}
