<?php

namespace Domain\Banking;

use App\Entity\BankReport;
use App\Repository\BankReportRepository;
use Bank\Statements\BankToCustomerMessage;
use Bank\Statements\ReportMessage;
use Core\Time\Clock;
use Domain\Banking\Exception\ImportingException;
use Helper\Database\TransactionCoordinator;
use Model_Bankstatement;
use Model_Exception;
use Orm\Repositories\BankstatementRepository;
use StatementHandlers\StatementHandlerFactory;
use TransactionHandlers\Exceptions\DuplicateTransactionHandlerException;
use TransactionHandlers\Exceptions\UnknownTransactionHandlerException;
use TransactionHandlers\TransactionHandlerCoordinator;
use Webmozart\Assert\Assert;

class ReportMessageImporter implements BankToCustomerMessageImporter
{
    /** @var TransactionCoordinator */
    private $dbTransactionCoordinator;

    /** @var BankstatementRepository */
    private $statementRepository;

    /** @var TransactionHandlerCoordinator */
    private $transactionHandlerCoordinator;

    /** @var BankStatementBuilder */
    private $bankStatementBuilder;

    /** @var BankReportRepository */
    private $reportRepository;

    /** @var BankReportBuilder */
    private $bankReportBuilder;

    /** @var BankTransactionBuilder */
    private $bankTransactionBuilder;

    /** @var StatementHandlerFactory */
    private $preTransactionHandlerFactory;

    public function __construct(
        TransactionCoordinator $transactionCoordinator,
        BankstatementRepository $statementRepository,
        BankReportRepository $reportRepository,
        TransactionHandlerCoordinator $transactionHandlerCoordinator,
        BankStatementBuilder $bankStatementBuilder,
        BankReportBuilder $bankReportBuilder,
        BankTransactionBuilder $bankTransactionBuilder,
        StatementHandlerFactory $statementHandlerFactory
    ) {
        $this->dbTransactionCoordinator      = $transactionCoordinator;
        $this->statementRepository           = $statementRepository;
        $this->reportRepository              = $reportRepository;
        $this->transactionHandlerCoordinator = $transactionHandlerCoordinator;
        $this->bankStatementBuilder          = $bankStatementBuilder;
        $this->bankReportBuilder             = $bankReportBuilder;
        $this->bankTransactionBuilder        = $bankTransactionBuilder;
        $this->preTransactionHandlerFactory  = $statementHandlerFactory;
    }

    /**
     * @param ReportMessage $reportFile
     *
     * {@inheritdoc}
     */
    public function import(BankToCustomerMessage $reportFile): void
    {
        Assert::isInstanceOf($reportFile, ReportMessage::class, "This importer can only import intraday reports");

        $this->assertReportIsNotYetImported($reportFile);

        $report             = $this->bankReportBuilder->createFromReportMessage($reportFile);
        $reportTransactions = $reportFile->yieldTransactions();

        if (!$reportTransactions->valid()) {
            $this->reportRepository->save($report);

            return;
        }

        $this->dbTransactionCoordinator->begin();

        $bankStatement = $this->getSingleProvisionalStatementFor($reportFile)
            ?? $this->createNewProvisionalStatement($reportFile);

        try {
            $this->reportRepository->save($report);
            $this->persistTransactionsIn($reportFile, $report, $bankStatement);
            $this->transactionHandlerCoordinator->registerNewStatement($bankStatement);
            $bankStatement->saveOrDie();

            $this->dbTransactionCoordinator->commit();
        } catch (Model_Exception $e) {
            $this->dbTransactionCoordinator->rollback();

            throw ImportingException::cannotSave($reportFile, $e);
        } catch (DuplicateTransactionHandlerException | UnknownTransactionHandlerException $e) {
            $this->dbTransactionCoordinator->rollback();

            throw ImportingException::transactionHandlerErrored($reportFile, $e);
        }
    }

    /**
     * @throws ImportingException
     */
    private function assertReportIsNotYetImported(ReportMessage $bankingFile): void
    {
        $existing = $this->reportRepository->findOneByBankAccountAndReference(
            $bankingFile->getBankAccount(),
            $bankingFile->getReference()
        );

        if ($existing !== null) {
            throw ImportingException::alreadyImported($bankingFile);
        }
    }

    private function getSingleProvisionalStatementFor(ReportMessage $reportFile): ?Model_Bankstatement
    {
        return $this->statementRepository->findProvisionalStatement(
            $reportFile->getBankAccount(),
            Clock::createUtcDateTime()
        );
    }

    /**
     * @throws \Model_Exception_Save In case of persistence error
     */
    private function persistTransactionsIn(
        ReportMessage $reportFile,
        BankReport $report,
        Model_Bankstatement $bankStatement
    ): void {
        $handler = $this->preTransactionHandlerFactory->createForBankAccount($reportFile->getBankAccount());

        foreach ($reportFile->yieldTransactions() as $statementTransaction) {
            $transaction = $this->bankTransactionBuilder->createFromStatementTransaction(
                $reportFile->getBankAccount(),
                $statementTransaction
            );

            $transaction->statement     = $bankStatement;
            $transaction->bankreport_id = $report->getId();

            $handler->handleTransaction($transaction, $statementTransaction);

            $transaction->saveOrDie();
        }
    }

    private function createNewProvisionalStatement(ReportMessage $message): Model_Bankstatement
    {
        $statement = $this->bankStatementBuilder->createProvisionalStatement(
            $message->getBankAccount(),
            $message->getDate()
        );

        $statement->saveOrDie();

        return $statement;
    }
}
