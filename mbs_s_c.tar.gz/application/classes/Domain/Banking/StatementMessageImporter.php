<?php

namespace Domain\Banking;

use App\Util\LoggerAwareTrait;
use Bank\Statements\BankToCustomerMessage;
use Bank\Statements\StatementMessage;
use Core\BusinessDayDeterminer;
use Core\Time\Clock;
use Core\Time\TimeZones;
use Domain\Banking\Exception\ImportingException;
use Helper\Database\TransactionCoordinator;
use Model_Bankstatement;
use Money\Money;
use Orm\Repositories\BankstatementRepository;
use Psr\Log\LoggerAwareInterface;
use Psr\Log\NullLogger;
use StatementHandlers\Exceptions\CannotCreateStatementHandlerException;
use StatementHandlers\Exceptions\SkipTransactionException;
use StatementHandlers\StatementHandlerFactory;
use TransactionHandlers\Exceptions\TransactionHandlerException;
use TransactionHandlers\TransactionHandlerCoordinator;
use Webmozart\Assert\Assert;

class StatementMessageImporter implements BankToCustomerMessageImporter, LoggerAwareInterface
{
    use LoggerAwareTrait;

    /** @var TransactionCoordinator */
    private $dbTransactionCoordinator;

    /** @var BankstatementRepository */
    private $statementRepository;

    /** @var TransactionHandlerCoordinator */
    private $transactionHandlerCoordinator;

    /** @var StatementHandlerFactory */
    private $statementHandlerFactory;

    /** @var BankTransactionBuilder */
    private $bankTransactionBuilder;

    /** @var BankStatementBuilder */
    private $bankStatementBuilder;

    public function __construct(
        TransactionCoordinator $transactionCoordinator,
        BankstatementRepository $statementRepository,
        TransactionHandlerCoordinator $transactionHandlerCoordinator,
        StatementHandlerFactory $statementHandlerFactory,
        BankTransactionBuilder $bankTransactionBuilder,
        BankStatementBuilder $bankStatementBuilder
    ) {
        $this->dbTransactionCoordinator      = $transactionCoordinator;
        $this->statementRepository           = $statementRepository;
        $this->transactionHandlerCoordinator = $transactionHandlerCoordinator;
        $this->statementHandlerFactory       = $statementHandlerFactory;
        $this->bankTransactionBuilder        = $bankTransactionBuilder;
        $this->bankStatementBuilder          = $bankStatementBuilder;
        $this->logger                        = new NullLogger();
    }

    private static function createDateTimeFromTimestamp(int $timestamp)
    {
        return Clock::createDateTimeFromTimestamp($timestamp, TimeZones::amsterdam());
    }

    /**
     * If the closing balance matches with the expected balance, we must update the closing balance with the
     * transaction sum, so when we export to twinfield the transactions sum matches with the statement sum
     */
    private static function ensureClosingBalanceIsAccurate(
        Model_Bankstatement $statement,
        Money $actualClosingBalance
    ): void {
        if ($actualClosingBalance->equals($statement->getClosingBalance()) === false) {
            $statement->setClosingBalance($actualClosingBalance);
            $statement->saveOrDie();
        }
    }

    /**
     * @param StatementMessage $statementFile
     *
     * {@inheritdoc}
     */
    public function import(BankToCustomerMessage $statementFile): void
    {
        Assert::isInstanceOf($statementFile, StatementMessage::class, "This importer can only import statement files");

        $this->dbTransactionCoordinator->begin();

        try {
            $this->assertStatementIsNotYetImported($statementFile);
            $this->assertBankFileHasExpectedOpeningBalance($statementFile);

            $statement = $this->statementRepository->getSingleProvisionalStatement(
                $statementFile->getBankAccount(),
                $statementFile->getDate()
            );

            if ($statement === null) {
                $statement = $this->createPersistedStatement($statementFile);

                $this->storeTransactionsInto($statement, $statementFile);

                $this->transactionHandlerCoordinator->registerNewStatement($statement);
            } else {
                $this->bankStatementBuilder->buildFromStatementMessage($statement, $statementFile);

                $this->assertTransactionSumMatchesStatementMutation($statement);
            }

            $statement->markAsFinalized();
            $statement->saveOrDie();

            $this->dbTransactionCoordinator->commit();
        } catch (CannotCreateStatementHandlerException $exception) {
            $this->dbTransactionCoordinator->rollback();

            throw ImportingException::noStatementHandlerToHandle($statementFile, $exception);
        } catch (TransactionHandlerException $e) {
            $this->dbTransactionCoordinator->rollback();

            throw ImportingException::transactionHandlerErrored($statementFile, $e);
        }
    }

    /**
     * @throws ImportingException
     */
    private function assertStatementIsNotYetImported(StatementMessage $bankingFile): void
    {
        $is_imported = $this->statementRepository->hasBeenImportedYet(
            $bankingFile->getBankAccount(),
            $bankingFile->getReference(),
            $bankingFile->getStatementNumber(),
            $bankingFile->getSequenceNumber()
        );

        if ($is_imported) {
            throw ImportingException::alreadyImported($bankingFile);
        }
    }

    /**
     * @throws ImportingException                    If opening/closing balances do not match the sum of transaction amounts.
     * @throws CannotCreateStatementHandlerException If no pre-transaction handler can be matched for statement.
     */
    private function storeTransactionsInto(Model_Bankstatement $statement, StatementMessage $sourceBankingFile): void
    {
        $transaction_sum         = new Money(0, $statement->getCurrency());
        $ignored_transaction_sum = new Money(0, $statement->getCurrency());

        $preTransactionHandler = $this->statementHandlerFactory->createForBankAccount(
            $statement->getBankAccount()
        );

        foreach ($sourceBankingFile->yieldTransactions() as $statementTransaction) {
            $transaction = $this->bankTransactionBuilder->createFromStatementTransaction(
                $sourceBankingFile->getBankAccount(),
                $statementTransaction
            );

            $transaction->statement = $statement;

            try {
                // @todo: Extract out of this service, these handlers can be triggered asnyc.
                $preTransactionHandler->handleTransaction($transaction, $statementTransaction);
            } catch (SkipTransactionException $e) {
                /**
                 * The closing balance in Belfius statements is incorrect when it contains a SEPA batch. Both the batch
                 * as well as the separate transactions are included. The closing balance is calculated based on all
                 * transactions, it doesn't represent the real closing balance on our banking account.
                 */
                $ignored_transaction_sum = $ignored_transaction_sum->add($statementTransaction->getAmount());

                continue;
            }

            $transaction->saveOrDie();

            $transaction_sum = $transaction_sum->add($statementTransaction->getAmount());
        }

        $openingBalance         = $statement->getOpeningBalance();
        $closingBalance         = $statement->getClosingBalance();
        $expectedClosingBalance = $openingBalance->add($transaction_sum)->add($ignored_transaction_sum);
        $actualClosingBalance   = $openingBalance->add($transaction_sum);

        if (!$closingBalance->equals($expectedClosingBalance)) {
            throw ImportingException::statementBalanceMismatch(
                $openingBalance,
                $closingBalance,
                $expectedClosingBalance,
                $sourceBankingFile
            );
        }

        self::ensureClosingBalanceIsAccurate($statement, $actualClosingBalance);
    }

    private function createPersistedStatement(StatementMessage $statementFile): Model_Bankstatement
    {
        // Create everything from scratch
        $statement = $this->bankStatementBuilder->createFromStatementMessage($statementFile);

        // We need an ID for this new statement before we can store transactions within, hence this save call.
        $statement->saveOrDie();

        return $statement;
    }

    /**
     * @throws ImportingException
     */
    private function assertTransactionSumMatchesStatementMutation(Model_Bankstatement $statement): void
    {
        $transactionsSum = new Money(0, $statement->getBankAccount()::getCurrency());

        foreach ($statement->transactions() as $transaction) {
            $transactionsSum = $transactionsSum->add($transaction->getAmount());
        }

        if (!$transactionsSum->equals($statement->getMutationAmount())) {
            throw ImportingException::statementAmountAndTransactionsSumMismatch(
                $statement->getBankAccount(),
                $transactionsSum,
                $statement->getMutationAmount()
            );
        }
    }

    /**
     * @throws ImportingException
     */
    protected function assertBankFileHasExpectedOpeningBalance(StatementMessage $bankingFile): void
    {
        $bankAccount = $bankingFile->getBankAccount();

        $previous_statement = $this->statementRepository->getLatestBankStatementBefore(
            $bankAccount,
            self::getStatementDateTimeFromBankingFile($bankingFile)
        );

        if ($previous_statement === null) {
            $this->logger->warning(
                sprintf(
                    'There is no previous bank statement for the bank account id [%s] and statement date [%s] ' .
                    'therefore the opening balance of this statement could not be compared with the closing balance ' .
                    'of any previous statement.',
                    $bankAccount::getId(),
                    self::getStatementDateTimeFromBankingFile($bankingFile)->format(\DateTimeInterface::ISO8601)
                ),
                [
                    'reference'         => $bankingFile->getReference(),
                    'account_number'    => $bankingFile->getBankAccount()::getAccountNumber(),
                    'statement_date'    => self::getStatementDateTimeFromBankingFile($bankingFile),
                    'file_path'         => $bankingFile->getFilePath(),
                    'bank_account_name' => $bankAccount::getBankName(),
                ]
            );

            return;
        }

        if (self::isStatementOnNextBusinessDay($previous_statement, $bankingFile) === false) {
            $this->logger->warning(
                'Banking file statement date is not on the next business day of the previous known bank statement. ' .
                'Therefore it will skip the check between the opening balance and the previous closing balance as ' .
                'there is probably another statement between them that we are not yet aware of.',
                [
                    'reference'      => $bankingFile->getReference(),
                    'account_number' => $bankingFile->getBankAccount()::getAccountNumber(),
                    'statement_date' => self::getStatementDateTimeFromBankingFile($bankingFile),
                    'file_path'      => $bankingFile->getFilePath(),
                ]
            );

            return;
        }

        if (self::hasMatchingBalance($bankingFile, $previous_statement) === false) {
            throw ImportingException::createForOpeningClosingBalanceMismatch(
                $previous_statement,
                $bankingFile
            );
        }
    }

    private static function getStatementDateTimeFromBankingFile(StatementMessage $bankingFile): \DateTimeImmutable
    {
        return self::createDateTimeFromTimestamp($bankingFile->getClosingBalance()->getBalanceDateUnixTimestamp());
    }

    /**
     * This methods checks if the next day of a a given bank statement is the same as the date of the banking file;
     * In other words: "Is the next business day after 2019-12-31 === 2020-01-02?"
     */
    private static function isStatementOnNextBusinessDay(Model_Bankstatement $previousStatement, StatementMessage $bankingFile): bool
    {
        $last_date    = new \DateTimeImmutable($previousStatement->statement_date);
        $current_date = self::getStatementDateTimeFromBankingFile($bankingFile);

        Assert::true(
            TimeZones::equal(TimeZones::amsterdam(), $last_date->getTimezone()),
            'The timezone from the previous statement date is not ' . TimeZones::amsterdam()->getName()
        );
        Assert::true(
            TimeZones::equal(TimeZones::amsterdam(), $current_date->getTimezone()),
            'The timezone from the statement date of the banking file is not ' . TimeZones::amsterdam()->getName()
        );

        return BusinessDayDeterminer::getNextDutchBusinessDay($last_date)->format('Ymd') === $current_date->format('Ymd');
    }

    private static function hasMatchingBalance(StatementMessage $bankingFile, Model_Bankstatement $previous): bool
    {
        return $bankingFile->getOpeningBalance()->getAmount()->equals($previous->getClosingBalance()) === true;
    }
}
