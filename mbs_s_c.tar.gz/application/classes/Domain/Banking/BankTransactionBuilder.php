<?php

namespace Domain\Banking;

use Bank\Statements\StatementTransaction;
use BankAccounts\BankAccount;
use Core\Time\Clock;
use Core\Time\TimeZones;
use Model_Banktransaction;
use Orm\ModelFactory;

class BankTransactionBuilder
{
    /** @var ModelFactory */
    private $modelFactory;

    public function __construct(ModelFactory $modelFactory)
    {
        $this->modelFactory = $modelFactory;
    }

    public function createFromStatementTransaction(
        BankAccount $bank_account,
        StatementTransaction $statementTransaction
    ): Model_Banktransaction {
        $transaction = $this->modelFactory->create(Model_Banktransaction::class);

        $transaction->setBankAccount($bank_account);
        $transaction->setEntryDate(
            self::createDateTimeFromTimestamp(
                $statementTransaction->getEntryDateUnixTimestamp()
            )
        );

        $transaction->setValueDate(
            self::createDateTimeFromTimestamp(
                $statementTransaction->getValueDateUnixTimestamp()
            )
        );

        $transaction->setAmount($statementTransaction->getAmount());
        $transaction->setOriginalAmount($statementTransaction->getOriginalAmount());
        $transaction->setOffsetAccountNumber($statementTransaction->getBankAccountNumber());
        $transaction->setDescription($statementTransaction->getDescription());

        if (!empty($statementTransaction->getBic())) {
            $transaction->setOffsetAccountBic($statementTransaction->getBic());
        }

        if (!empty($statementTransaction->getBankAccountName())) {
            $transaction->setOffsetAccountName($statementTransaction->getBankAccountName());
        }

        if (!empty($statementTransaction->getMutationCode())) {
            $transaction->mutation_code = $statementTransaction->getMutationCode();
        }

        return $transaction;
    }

    private static function createDateTimeFromTimestamp(int $timestamp): \DateTimeImmutable
    {
        return Clock::createDateTimeFromTimestamp($timestamp, TimeZones::amsterdam());
    }
}
