<?php

namespace Domain\Banking;

use Bank\Statements\BankToCustomerMessage;
use Bank\Statements\ReportMessage;
use Bank\Statements\StatementMessage;

class BankToCustomerMessageImporterFactory
{
    /** @var StatementMessageImporter */
    private $statementMessageImporter;

    /** @var ReportMessageImporter */
    private $reportMessageImporter;

    public function __construct(
        StatementMessageImporter $statementImporter,
        ReportMessageImporter $reportImporter
    ) {
        $this->statementMessageImporter = $statementImporter;
        $this->reportMessageImporter    = $reportImporter;
    }

    public function getImporterForMessage(BankToCustomerMessage $message): BankToCustomerMessageImporter
    {
        if ($message instanceof StatementMessage) {
            return $this->statementMessageImporter;
        }

        if ($message instanceof ReportMessage) {
            return $this->reportMessageImporter;
        }

        throw new \InvalidArgumentException("No importer found to handle file: " . $message->getReference());
    }
}
