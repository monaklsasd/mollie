<?php

namespace Domain\Banking;

use Bank\Statements\BankToCustomerMessage;

interface BankToCustomerMessageImporter
{
    /**
     * @throws Exception\ImportingException
     */
    public function import(BankToCustomerMessage $bankingFile): void;
}
