<?php

namespace Domain\Banking;

use App\Entity\BankReport;
use Bank\Statements\ReportMessage;

class BankReportBuilder
{
    public function createFromReportMessage(ReportMessage $message): BankReport
    {
        return new BankReport(
            $message->getBankAccount(),
            $message->getReference(),
            $message->getDate(),
            $message->getFilePath()
        );
    }
}
