<?php

namespace Domain\Banking;

use Bank\Statements\StatementMessage;
use BankAccounts\BankAccount;
use Core\Time\Clock;
use Core\Time\TimeZones;
use DateTimeImmutable;
use Model_Bankstatement;
use Money\Money;
use Orm\ModelFactory;

class BankStatementBuilder
{
    /** @var ModelFactory */
    private $modelFactory;

    public function __construct(ModelFactory $modelFactory)
    {
        $this->modelFactory = $modelFactory;
    }

    public function createFromStatementMessage(StatementMessage $bankingFile): Model_Bankstatement
    {
        $statement = $this->createStatement();

        $this->buildFromStatementMessage($statement, $bankingFile);

        return $statement;
    }

    public function createProvisionalStatement(
        BankAccount $bankAccount,
        DateTimeImmutable $statementDate
    ): Model_Bankstatement {
        $statement = $this->createStatement();

        $zeroAmount = new Money(0, $bankAccount::getCurrency());

        $statement->setBankAccount($bankAccount);
        $statement->setStatementReference('N/A');
        $statement->setStatementNumber(0);
        $statement->setSequenceNumber(0);
        $statement->setOpeningBalance($zeroAmount);
        $statement->setClosingBalance($zeroAmount);
        $statement->setStatementDate($statementDate);

        return $statement;
    }

    public function createStatement(): Model_Bankstatement
    {
        $statement = $this->modelFactory->create(Model_Bankstatement::class);
        $statement->setAccountviewStatus(Model_Bankstatement::ACCOUNTVIEW_STATUS_NEW);

        return $statement;
    }

    private static function createDateTimeFromTimestamp(int $timestamp): DateTimeImmutable
    {
        return Clock::createDateTimeFromTimestamp($timestamp, TimeZones::amsterdam());
    }

    public function buildFromStatementMessage(Model_Bankstatement $statement, StatementMessage $bankingFile): void
    {
        $statement->setBankAccount($bankingFile->getBankAccount());
        $statement->setStatementReference($bankingFile->getReference());
        $statement->setStatementNumber($bankingFile->getStatementNumber());
        $statement->setSequenceNumber($bankingFile->getSequenceNumber());
        $statement->setFilePath($bankingFile->getFilePath());

        $statement->setOpeningBalance($bankingFile->getOpeningBalance()->getAmount());
        $statement->setClosingBalance($bankingFile->getClosingBalance()->getAmount());

        $statement->setStatementDate(
            self::createDateTimeFromTimestamp($bankingFile->getClosingBalance()->getBalanceDateUnixTimestamp())
        );
    }
}
