<?php

namespace Domain\Banking\Exception;

use Bank\Statements\BankToCustomerMessage;
use Bank\Statements\StatementMessage;
use BankAccounts\BankAccount;
use Core\Localization\Localizer;
use Exception;
use Money\Money;

class ImportingException extends Exception
{
    public static function unrecognizedBankAccount(BankToCustomerMessage $message): self
    {
        return new self(sprintf(
            'Cannot find Mollie bank account for account number %s (statement ref: %s, file path: %s).',
            $message->getAccountNumber(),
            $message->getReference(),
            $message->getFilePath()
        ));
    }

    public static function noStatementHandlerToHandle(StatementMessage $message, ?Exception $previous): self
    {
        return new self(sprintf(
            'No statement handlers found to handle statement with ref: %s',
            $message->getReference()
        ), 0, $previous);
    }

    public static function alreadyImported(BankToCustomerMessage $message): self
    {
        return new self(sprintf(
            '%s with reference %s for account %d (%s) is already imported (path: %s)',
            get_class($message),
            $message->getReference(),
            $message->getBankAccount()::getId(),
            $message->getBankAccount()::getIban(),
            $message->getFilePath()
        ));
    }

    public static function transactionHandlerErrored(BankToCustomerMessage $message, \Throwable $previous): self
    {
        return new self(
            'Transaction handlers could not be triggered for message: ' . $message->getReference(),
            0,
            $previous
        );
    }

    public static function statementBalanceMismatch(
        Money $openingBalance,
        Money $closingBalance,
        Money $expectedClosingBalance,
        StatementMessage $statementMessage
    ): self {
        return new self(sprintf(
            'Got closing balance %s, expected %s. Opening balance was %s (statement ref: %s, path: %s, diff: %s).',
            Localizer::formatMoney($closingBalance),
            Localizer::formatMoney($expectedClosingBalance),
            Localizer::formatMoney($openingBalance),
            $statementMessage->getReference(),
            $statementMessage->getFilePath(),
            Localizer::formatMoney($expectedClosingBalance->subtract($closingBalance))
        ));
    }

    public static function statementAmountAndTransactionsSumMismatch(
        BankAccount $account,
        Money $transactionsSum,
        Money $statementMutation
    ): self {
        return new self(sprintf(
            "Sum of reported transactions in account #%d (%s) do not match the statement's mutation amount (%s)",
            $account::getId(),
            Localizer::formatMoney($transactionsSum),
            Localizer::formatMoney($statementMutation)
        ));
    }

    public static function cannotSave(BankToCustomerMessage $message, \Model_Exception $exception): self
    {
        return new self(
            sprintf(
                'Cannot import file (path: %s, ref: %s) due to a DB error',
                $message->getFilePath(),
                $message->getReference()
            ),
            0,
            $exception
        );
    }

    public static function createForOpeningClosingBalanceMismatch(\Model_Bankstatement $previous, StatementMessage $current): self
    {
        return new self(
            sprintf(
                'The opening balance [%s] of the statement [%s] does not matches the previous closing balance [%s] from statement [%s]',
                $current->getOpeningBalance()->getAmount()->getAmount(),
                $current->getReference(),
                $previous->getClosingBalance()->getAmount(),
                $previous->getPrimaryKey()
            )
        );
    }
}
