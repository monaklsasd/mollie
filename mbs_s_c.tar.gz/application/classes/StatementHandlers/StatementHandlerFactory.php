<?php

namespace StatementHandlers;

use BankAccounts\BankAccount;
use BankAccounts\BankAccountRepository;
use Core\Di\DependencyInjector;
use Log\DatabaseLogger;
use StatementHandlers\Exceptions\CannotCreateStatementHandlerException;

class StatementHandlerFactory
{
    /** @var BankAccountRepository */
    private $bank_account_repository;

    /** @var DependencyInjector */
    private $dependency_injector;

    /** @var DatabaseLogger */
    private $logger;

    public function __construct(
        BankAccountRepository $bank_account_repository,
        DependencyInjector $dependency_injector,
        DatabaseLogger $logger
    ) {
        $this->bank_account_repository = $bank_account_repository;
        $this->dependency_injector     = $dependency_injector;
        $this->logger                  = $logger;
    }

    /**
     * @throws CannotCreateStatementHandlerException
     *
     * @todo: REMOVE when "StatementHandler"s are converted into Pre-Transaction Handlers.
     */
    public function createForBankAccount(BankAccount $bank_account): StatementHandler
    {
        $handler_class_name = $bank_account::getStatementHandlerClass();

        if (!is_subclass_of($handler_class_name, StatementHandler::class, true)) {
            throw new CannotCreateStatementHandlerException(sprintf(
                'Handler class %s is not an instance of %s.',
                $handler_class_name,
                StatementHandler::class
            ));
        }

        $handler = $this->dependency_injector->get($handler_class_name);
        $handler->setLogger($this->logger);

        return $handler;
    }
}
