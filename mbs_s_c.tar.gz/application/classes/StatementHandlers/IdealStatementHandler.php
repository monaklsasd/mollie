<?php

declare(strict_types=1);

namespace StatementHandlers;

use Bank\Statements\StatementTransaction;
use Helper_Banktransaction_Matching as Matcher;
use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use Model_TransactionRegistration;

class IdealStatementHandler extends StatementHandlerBase
{
    protected function processTransaction(
        Model_Banktransaction $transaction,
        StatementTransaction $statement_transaction
    ): void {
        /*
         * We receive some strange iDEAL transactions every now and then.
         *
         * @issue 16805
         * @issue 16118
         * @issue 16057
         * @issue 15743
         * @issue 15132
         * @issue 14537
         * @issue 14361
         * @issue 14326
         * @issue 13855
         * @issue 13222
         * @issue 13186
         *
         * We are going to pro-actively mark these as iDEAL. Our excellent reconciliation system will then throw out any
         * non-expected transactions.
         */
        if ($transaction_id = Matcher::getAcquirerTransactionId($statement_transaction->getDescription())) {
            $purchase_reference = Matcher::get_purchase_reference($statement_transaction->getDescription());

            $transaction->setTags([TransactionTags::TAG_IDEAL]);
            $transaction->setTagData([
                'ideal' => [
                    'transaction_id'  => $transaction_id,
                    'purchase_number' => $purchase_reference,
                ],
            ]);

            if ($statement_transaction->getCustomerDateUnixTimestamp() !== null) {
                $transaction->setCustomerDate(self::createDateTimeFromTimestamp($statement_transaction->getCustomerDateUnixTimestamp()));
            }

            return;
        }

        $this->detectStandardTransactionTypes($transaction);
    }

    protected function getUnknownTag(): string
    {
        return TransactionTags::TAG_UNKNOWNIDEAL;
    }

    protected function getUnknownRegistrationTag(): string
    {
        return Model_TransactionRegistration::REGISTRATION_UNKNOWN_IDEAL;
    }
}
