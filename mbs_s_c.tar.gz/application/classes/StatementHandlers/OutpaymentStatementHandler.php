<?php

declare(strict_types=1);

namespace StatementHandlers;

use Bank\Statements\StatementTransaction;
use Helper_Banktransaction_Matching;
use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use Model_TransactionRegistration;

class OutpaymentStatementHandler extends StatementHandlerBase
{
    protected function processTransaction(
        Model_Banktransaction $transaction,
        StatementTransaction $statement_transaction
    ): void {
        if ($this->detectStandardTransactionTypes($transaction)) {
            return;
        }

        /**
         * Normal outpayments are in automated sepa batches, but for some merchants outside of Europe (e.g. Curaçao)
         * finance has to manually transfer the outpayment. Those are top-level transaction and get the tag here.
         *
         * The other top level transaction are only the automatically returned outpayments. (closed account etc).
         */
        if ($reference = Helper_Banktransaction_Matching::getTransferPayoutReference($transaction->getDescription())) {
            $transaction->setTagData(['transfer_reference' => $reference]);

            if ($transaction->isReturnedTransaction()) {
                $transaction->addTag(TransactionTags::TAG_FAILURETRANSFER);
            } elseif ($transaction->isDebited()) {
                $transaction->addTag(TransactionTags::TAG_TRANSFER);
            }
        } elseif ($reference = Helper_Banktransaction_Matching::getOutpaymentReference($transaction->getDescription())) {
            $transaction->setTagData(['outpayment_reference' => $reference]);

            if ($transaction->isReturnedTransaction()) {
                $transaction->addTag(TransactionTags::TAG_FAILUREOUTPAYMENT);
            } elseif ($transaction->isDebited()) {
                $transaction->addTag(TransactionTags::TAG_OUTPAYMENT);
            }
        }
    }

    protected function getUnknownTag(): string
    {
        return TransactionTags::TAG_UNKNOWNOUTPAYMENT;
    }

    protected function getUnknownRegistrationTag(): string
    {
        return Model_TransactionRegistration::REGISTRATION_UNKNOWN_OUTPAYMENT;
    }
}
