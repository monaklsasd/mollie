<?php

declare(strict_types=1);

namespace StatementHandlers;

use Bank\Statements\StatementTransaction;
use Bank_Swift_Codes;
use BankAccounts\BankAccountRepository;
use Helper\Database\TransactionCoordinator;
use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use Model_TransactionRegistration;
use Orm\ModelFactory;
use Orm\Repositories\BankstatementRepository;
use Orm\Repositories\SepaBatchTagDeterminer;
use Supplier\Klarna\Payout\PayoutReferenceIdentifier;
use TransactionHandlers\TransactionHandlerCoordinator;

class KlarnaStatementHandler extends StatementHandlerBase
{
    /** @var PayoutReferenceIdentifier */
    private $payout_reference_identifier;

    public function __construct(
        BankstatementRepository $bankstatement_repository,
        BankAccountRepository $bank_account_repository,
        ModelFactory $model_factory,
        TransactionHandlerCoordinator $transaction_handler_coordinator,
        TransactionCoordinator $transaction_coordinator,
        SepaBatchTagDeterminer $sepa_tag_determiner,
        PayoutReferenceIdentifier $payout_reference_identifier
    ) {
        parent::__construct(
            $bankstatement_repository,
            $bank_account_repository,
            $model_factory,
            $transaction_handler_coordinator,
            $transaction_coordinator,
            $sepa_tag_determiner
        );

        $this->payout_reference_identifier = $payout_reference_identifier;
    }

    protected function processTransaction(
        Model_Banktransaction $transaction,
        StatementTransaction $statement_transaction
    ): void {
        if ($this->detectStandardTransactionTypes($transaction)) {
            return;
        }

        if ($transaction->hasAnyOfTags(
            [TransactionTags::TAG_KLARNA_SETTLEMENT, TransactionTags::TAG_KLARNA_SETTLEMENT_EXPANDED]
        )) {
            // Already handled.
            return;
        }

        $reference = $this->payout_reference_identifier->deductReferenceIn($transaction->getDescription());

        /*
         * Klarna's Finnish bank Nordea FI doesn't support references longer than 20 characters in the transaction description.
         * The full (22 digit) reference is however in eref section. If we find a reference there replace the original description.
         */
        if ($reference === null && $statement_transaction->getBic() === 'NDEAFIHH') {
            $eref = $statement_transaction->getSwiftCodeValue(Bank_Swift_Codes::REFERENCE_ORIGINATOR);

            if ($reference = $this->payout_reference_identifier->deductReferenceIn($eref)) {
                $transaction->setDescription($eref);
            }
        }

        if ($reference !== null) {
            $transaction->setTags([TransactionTags::TAG_KLARNA_SETTLEMENT]);
            $transaction->setTagData(['payout_reference' => $reference]);

            return;
        }
    }

    protected function getUnknownTag(): string
    {
        return TransactionTags::TAG_UNKNOWNKLARNA;
    }

    protected function getUnknownRegistrationTag(): string
    {
        return Model_TransactionRegistration::REGISTRATION_UNKNOWN_KLARNA;
    }
}
