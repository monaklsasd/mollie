<?php

declare(strict_types=1);

namespace StatementHandlers;

use App\Util\DateTime\Now;
use Bank\Statements\StatementTransaction;
use BankAccounts\BankAccountRepository;
use BankAccounts\InternalTransactionDetector;
use DateTimeImmutable;
use Helper\Database\TransactionCoordinator;
use Model\Transaction\TransactionTags;
use Model_Bankstatement;
use Model_Banktransaction;
use Money\Money;
use Orm\ModelFactory;
use Orm\Repositories\BankstatementRepository;
use Orm\Repositories\SepaBatchTagDeterminer;
use Psr\Log\LoggerAwareTrait;
use Psr\Log\NullLogger;
use TransactionHandlers\TransactionHandlerCoordinator;
use function count;

abstract class StatementHandlerBase implements StatementHandler
{
    use LoggerAwareTrait;
    use Now;

    /** @var BankstatementRepository */
    protected $statement_repository;

    /** @var BankAccountRepository */
    protected $bank_account_repository;

    /** @var ModelFactory */
    protected $model_factory;

    /** @var TransactionHandlerCoordinator */
    protected $transaction_handler_coordinator;

    /** @var TransactionCoordinator */
    protected $transaction_coordinator;

    /** @var SepaBatchTagDeterminer */
    protected $sepa_tag_determiner;

    /**
     * IMPORTANT: should be reset at the start of ::handleTransaction for this handler to remain stateless
     *
     * @var Model_Bankstatement|null
     */
    protected $statement;

    /**
     * IMPORTANT: should be reset at the start of ::handleTransaction for this handler to remain stateless
     *
     * @var Money
     */
    protected $transaction_sum;

    /** @var InternalTransactionDetector */
    private $internal_transaction_detector;

    public function __construct(
        BankstatementRepository $bankstatement_repository,
        BankAccountRepository $bank_account_repository,
        ModelFactory $model_factory,
        TransactionHandlerCoordinator $transaction_handler_coordinator,
        TransactionCoordinator $transaction_coordinator,
        SepaBatchTagDeterminer $sepa_tag_determiner
    ) {
        $this->statement_repository            = $bankstatement_repository;
        $this->bank_account_repository         = $bank_account_repository;
        $this->model_factory                   = $model_factory;
        $this->transaction_handler_coordinator = $transaction_handler_coordinator;
        $this->transaction_coordinator         = $transaction_coordinator;
        $this->logger                          = new NullLogger();
        $this->sepa_tag_determiner             = $sepa_tag_determiner;

        $this->internal_transaction_detector = new InternalTransactionDetector($this->bank_account_repository);
    }

    /**
     * @throws \Model_Exception_Save
     */
    public function handleTransaction(
        Model_Banktransaction $transaction,
        StatementTransaction $statement_transaction
    ): void {
        $this->processTransaction($transaction, $statement_transaction);

        $transaction->saveOrDie();

        if (count($transaction->getTags()) === 0) {
            $transaction->recordUnknown(
                [$this->getUnknownTag()],
                $this->getUnknownRegistrationTag()
            );
        }
    }

    abstract protected function processTransaction(
        Model_Banktransaction $transaction,
        StatementTransaction $statement_transaction
    ): void;

    abstract protected function getUnknownTag(): string;

    abstract protected function getUnknownRegistrationTag(): string;

    protected function detectStandardTransactionTypes(Model_Banktransaction $transaction): bool
    {
        // Is this is an internal transaction?
        if ($internal_tag = $this->internal_transaction_detector->getInternalTransactionTag($transaction)) {
            $transaction->setTags([$internal_tag]);

            return true;
        }

        // Is this a fee?
        if ($transaction->isBankingFee()) {
            $transaction->setTags([TransactionTags::TAG_BANK]);

            return true;
        }

        // Is it a sepa batch? batch transactions are compressed. So there is never a single bankaccount number.
        if ($transaction->getOffsetAccountNumber() === null && $transaction->isSepaBatch()) {
            $tags = $this->sepa_tag_determiner->getForTransaction($transaction);
            $transaction->setTags($tags);

            return true;
        }

        return false;
    }

    protected static function createDateTimeFromTimestamp(int $timestamp): DateTimeImmutable
    {
        return DateTimeImmutable::createFromFormat('U', (string)$timestamp)->setTimezone(self::getSystemTimeZone());
    }
}
