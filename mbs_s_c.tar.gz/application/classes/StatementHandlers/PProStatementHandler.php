<?php

declare(strict_types=1);

namespace StatementHandlers;

use Bank\Statements\Exceptions\UnidentifiedSettlementException;
use Bank\Statements\SettlementIdentifier;
use Bank\Statements\StatementTransaction;
use BankAccounts\BankAccountRepository;
use Helper\Database\TransactionCoordinator;
use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use Model_TransactionRegistration;
use Orm\ModelFactory;
use Orm\Repositories\BankstatementRepository;
use Orm\Repositories\SepaBatchTagDeterminer;
use TransactionHandlers\TransactionHandlerCoordinator;

/**
 * Handle bank statements for accounts that deal with PPRO payments.
 */
class PProStatementHandler extends StatementHandlerBase
{
    /** @var SettlementIdentifier */
    protected $settlement_identifier;

    public function __construct(
        BankstatementRepository $bankstatement_repository,
        BankAccountRepository $bank_account_repository,
        ModelFactory $model_factory,
        TransactionHandlerCoordinator $transaction_handler_coordinator,
        TransactionCoordinator $transaction_coordinator,
        SettlementIdentifier $settlement_identifier,
        SepaBatchTagDeterminer $sepa_tag_determiner
    ) {
        parent::__construct(
            $bankstatement_repository,
            $bank_account_repository,
            $model_factory,
            $transaction_handler_coordinator,
            $transaction_coordinator,
            $sepa_tag_determiner
        );

        $this->settlement_identifier = $settlement_identifier;
    }

    protected function processTransaction(
        Model_Banktransaction $transaction,
        StatementTransaction $statement_transaction
    ): void {
        if ($transaction->isReceivedPProSettlement()) {
            return; // Already has tag.
        }

        try {
            $settlement_identifier = $this->settlement_identifier->getSettlementIdentifier(
                $transaction->getDescription(),
                SettlementIdentifier::SETTLEMENT_PPRO
            );

            $transaction->setTags([TransactionTags::TAG_PPRO_SETTLEMENT]);
            $transaction->setTagData(['settlement_id' => $settlement_identifier]);
        } catch (UnidentifiedSettlementException $e) {
            $transaction->saveOrDie(); //Need a transaction id for the log.

            $this->logger->info(sprintf(
                'Received PPRO transaction %d with description "%s" that does not contain any settlement identifier or the settlement identifier received from PPRO is wrong.',
                $transaction->getPrimaryKey(),
                $transaction->getDescription()
            ));
        }

        $this->detectStandardTransactionTypes($transaction);
    }

    protected function getUnknownTag(): string
    {
        return TransactionTags::TAG_UNKNOWNMISTERCASH;
    }

    protected function getUnknownRegistrationTag(): string
    {
        return Model_TransactionRegistration::REGISTRATION_UNKNOWN_PPRO;
    }
}
