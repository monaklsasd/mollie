<?php

declare(strict_types=1);

namespace StatementHandlers;

use Bank\Statements\StatementTransaction;
use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use Model_TransactionRegistration;

/**
 * Handle statements from the bank account Amex transfers their settlements to.
 */
class AmexStatementHandler extends StatementHandlerBase
{
    protected function processTransaction(
        Model_Banktransaction $transaction,
        StatementTransaction $statement_transaction
    ): void {
        if ($transaction->isReceivedAmexSettlement()) {
            $transaction->setTags([TransactionTags::TAG_AMEX_SETTLEMENT_NEW]);

            if ($card_acceptor_id = $this->parseCardAcceptorId($transaction->getDescription())) {
                $transaction->setTagData([
                    "card_acceptor_id" => $card_acceptor_id,
                ]);
            }

            return;
        }

        $this->detectStandardTransactionTypes($transaction);
    }

    private function parseCardAcceptorId(string $description): ?string
    {
        if (!preg_match("!^(\\d+) AMERICAN EXPRESS EUROPE LTD!i", $description, $matches)) {
            return null;
        }

        return $matches[1];
    }

    protected function getUnknownTag(): string
    {
        return TransactionTags::TAG_UNKNOWNAMEX;
    }

    protected function getUnknownRegistrationTag(): string
    {
        return Model_TransactionRegistration::REGISTRATION_UNKNOWN_AMEX;
    }
}
