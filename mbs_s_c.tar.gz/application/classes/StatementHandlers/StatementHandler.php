<?php

declare(strict_types=1);

namespace StatementHandlers;

use Bank\Statements\StatementTransaction;
use Psr\Log\LoggerAwareInterface;

interface StatementHandler extends LoggerAwareInterface
{
    public function handleTransaction(
        \Model_Banktransaction $transaction,
        StatementTransaction $statement_transaction
    ): void;
}
