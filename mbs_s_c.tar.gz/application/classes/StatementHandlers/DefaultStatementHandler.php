<?php

declare(strict_types=1);

namespace StatementHandlers;

use Bank\Statements\StatementTransaction;
use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use Model_TransactionRegistration;

class DefaultStatementHandler extends StatementHandlerBase
{
    protected function processTransaction(
        Model_Banktransaction $transaction,
        StatementTransaction $statement_transaction
    ): void {
        $this->detectStandardTransactionTypes($transaction);
    }

    protected function getUnknownTag(): string
    {
        return TransactionTags::TAG_UNKNOWNBANKTRANSFER;
    }

    protected function getUnknownRegistrationTag(): string
    {
        return Model_TransactionRegistration::REGISTRATION_UNKNOWN_BANKTRANSFER;
    }
}
