<?php

declare(strict_types=1);

namespace StatementHandlers;

use Bank\Statements\Balance;
use Bank\Statements\MutationCodes\Belfius;
use Bank\Statements\StatementTransaction;
use Model_Banktransaction;
use StatementHandlers\Exceptions\SkipTransactionException;

/**
 * This trait is specific for handling statements from the Belfius bank. Note that other payment methods like Bancontact
 * and Banktransfer can also use a Belfius bank account.
 *
 * Belfius reports both the batch as well as the separate transactions. They calculate the closing balance in the MT940
 * file based on the transactions inside the file. The closing balance doesn't reflect the real balance and it doesn't
 * match the opening balance of the report the next day.
 *
 * @issue 22548
 */
trait BelfiusStatementFormatTrait
{
    /**
     * Stores whether the current statement is for a belfius account.
     *
     * @var bool
     */
    protected $is_belfius = false;

    /**
     * @throws \Model_Exception_Save
     */
    public function handleTransaction(
        Model_Banktransaction $transaction,
        StatementTransaction $statement_transaction
    ): void {
        $bank_account = $transaction->getBankAccount();

        $this->is_belfius = $bank_account !== null && $bank_account::getBankBic() === 'GKCCBEBB';

        parent::handleTransaction($transaction, $statement_transaction);
    }

    protected function assertBelfiusTransactionType(
        Model_Banktransaction $transaction,
        StatementTransaction $statement_transaction
    ): void {
        if ($this->is_belfius
            && $statement_transaction->getMutationCode() === Belfius::MUTATION_CODE_DETAIL
        ) {
            throw new SkipTransactionException('Belfius detail transaction.');
        }
    }
}
