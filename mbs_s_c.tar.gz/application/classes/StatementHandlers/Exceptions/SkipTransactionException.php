<?php

declare(strict_types=1);

namespace StatementHandlers\Exceptions;

class SkipTransactionException extends StatementHandlerException
{
}
