<?php

declare(strict_types=1);

namespace StatementHandlers\Exceptions;

use Bank\Statements\BankToCustomerMessage;
use Exception;

class StatementHandlerException extends Exception
{
    public static function bankAccountNotFound(
        BankToCustomerMessage $bankingFile,
        Exception $exception
    ): StatementHandlerException {
        return new self(
            sprintf(
                'Cannot find Mollie bank account for account number %s (statement ref: %s, file path: %s).',
                $bankingFile->getAccountNumber(),
                $bankingFile->getReference(),
                $bankingFile->getFilePath()
            ),
            $exception->getCode(),
            $exception
        );
    }
}
