<?php

declare(strict_types=1);

namespace StatementHandlers;

use Bank\Statements\StatementTransaction;
use Helper\BankTransaction\Matching\SofortMatcher;
use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use Model_TransactionRegistration;

class SofortStatementHandler extends StatementHandlerBase
{
    protected function processTransaction(
        Model_Banktransaction $transaction,
        StatementTransaction $statement_transaction
    ): void {
        if ($this->detectStandardTransactionTypes($transaction)) {
            return;
        }

        // We paid out some money, tag it unknown and be done with it. (no registration)
        if ($transaction->isDebited()) {
            $transaction->setTags([TransactionTags::TAG_UNKNOWNSOFORT]);

            return;
        }

        if ($transaction_id = SofortMatcher::getFromDescription($transaction->getDescription())) {
            $transaction->setTags([TransactionTags::TAG_SOFORT]);
            $transaction->setTagData(['transaction_id' => $transaction_id]);

            return;
        }
    }

    protected function getUnknownTag(): string
    {
        return TransactionTags::TAG_UNKNOWNSOFORT;
    }

    protected function getUnknownRegistrationTag(): string
    {
        return Model_TransactionRegistration::REGISTRATION_UNKNOWN_SOFORT;
    }
}
