<?php

declare(strict_types=1);

namespace StatementHandlers;

use Bank\Statements\StatementTransaction;
use Model\Transaction\TransactionTags;
use Model_Banktransaction;

class OrderStatementHandler extends IdealStatementHandler
{
    protected function processTransaction(
        Model_Banktransaction $transaction,
        StatementTransaction $statement_transaction
    ): void {
        if ($statement_transaction->getDescription() !== null
            && preg_match(
                '~(?P<adyen_transaction_id>tx[0-9a-z]+)\s+(?P<adyen_batch_id>batch\s+[0-9]+)~is',
                $statement_transaction->getDescription(),
                $matches
            )
        ) {
            $transaction->setTags([TransactionTags::TAG_ADYEN]);
            $transaction->setTagData([
                'adyencc' => [
                    'transaction_id' => $matches['adyen_transaction_id'],
                    'batch_id'       => $matches['adyen_batch_id'],
                ],
            ]);

            return;
        }

        $this->detectStandardTransactionTypes($transaction);
    }
}
