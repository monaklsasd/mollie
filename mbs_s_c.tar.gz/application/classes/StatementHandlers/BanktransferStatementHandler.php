<?php

declare(strict_types=1);

namespace StatementHandlers;

use Bank\Statements\StatementTransaction;
use Bank_Swift_Codes;
use Helper_Banktransaction_Matching;
use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use Model_TransactionRegistration;

/**
 * Handle bank statements for accounts that deal with Mollie Banktransfer payments.
 */
class BanktransferStatementHandler extends StatementHandlerBase
{
    use BelfiusStatementFormatTrait;

    protected function processTransaction(
        Model_Banktransaction $transaction,
        StatementTransaction $statement_transaction
    ): void {
        $this->assertBelfiusTransactionType($transaction, $statement_transaction);

        if ($this->detectStandardTransactionTypes($transaction)) {
            return;
        }

        // We paid out some money, tag it unknown and be done with it. (no registration)
        if ($statement_transaction->getAmount()->isNegative()) {
            $transaction->setTags([TransactionTags::TAG_UNKNOWNBANKTRANSFER]);

            return;
        }

        // Try to get the supplier_transaction_id, first from the description, then from the swift-reference.
        $transaction_id = Helper_Banktransaction_Matching::get_banktransfer_transaction_id(
            (string)$statement_transaction->getDescription()
        );

        if ($transaction_id === null && $statement_transaction->hasSwiftCode(Bank_Swift_Codes::REFERENCE_ORIGINATOR)) {
            $transaction_id = Helper_Banktransaction_Matching::get_banktransfer_transaction_id(
                $statement_transaction->getSwiftCodeValue(Bank_Swift_Codes::REFERENCE_ORIGINATOR)
            );
        }

        if ($transaction_id !== null) {
            $transaction->setTags([TransactionTags::TAG_BANKTRANSFER]);
            $transaction->setTagData([
                'transaction_id' => $transaction_id,
            ]);

            return;
        }
    }

    protected function getUnknownTag(): string
    {
        return TransactionTags::TAG_UNKNOWNBANKTRANSFER;
    }

    protected function getUnknownRegistrationTag(): string
    {
        return Model_TransactionRegistration::REGISTRATION_UNKNOWN_BANKTRANSFER;
    }
}
