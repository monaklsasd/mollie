<?php

declare(strict_types=1);

namespace StatementHandlers;

use Bank\Statements\StatementTransaction;
use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use Model_TransactionRegistration;

class MisterCashStatementHandler extends StatementHandlerBase
{
    use BelfiusStatementFormatTrait;

    protected function processTransaction(
        Model_Banktransaction $transaction,
        StatementTransaction $statement_transaction
    ): void {
        $this->assertBelfiusTransactionType($transaction, $statement_transaction);

        if ($this->detectStandardTransactionTypes($transaction)) {
            return;
        }

        if ($transaction->isReceivedMisterCash()) {
            $transaction->setTags([TransactionTags::TAG_MISTERCASH]);

            return;
        }
    }

    protected function getUnknownTag(): string
    {
        return TransactionTags::TAG_UNKNOWNMISTERCASH;
    }

    protected function getUnknownRegistrationTag(): string
    {
        return Model_TransactionRegistration::REGISTRATION_UNKNOWN_MISTERCASH;
    }
}
