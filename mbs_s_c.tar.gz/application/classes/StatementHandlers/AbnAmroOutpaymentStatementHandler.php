<?php

declare(strict_types=1);

namespace StatementHandlers;

use Bank\Statements\StatementTransaction;
use Helper\BankTransaction\Matching\PrepaymentSettlementMatcher;
use Model_Banktransaction;

class AbnAmroOutpaymentStatementHandler extends OutpaymentStatementHandler
{
    protected function processTransaction(
        Model_Banktransaction $transaction,
        StatementTransaction $statement_transaction
    ): void {
        if (PrepaymentSettlementMatcher::getPrepaymentSettlementReference($transaction)) {
            PrepaymentSettlementMatcher::markTransactionAsPrepaymentSettlement($transaction);
            $transaction->setAsLedgerTransaction();

            return;
        }

        parent::processTransaction($transaction, $statement_transaction);
    }
}
