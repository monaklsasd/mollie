<?php

declare(strict_types=1);

namespace StatementHandlers;

use Bank\Statements\StatementTransaction;
use Helper_Banktransaction_Matching;
use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use Model_TransactionRegistration;

class KbcStatementHandler extends StatementHandlerBase
{
    protected function processTransaction(
        Model_Banktransaction $transaction,
        StatementTransaction $statement_transaction
    ): void {
        if ($this->detectStandardTransactionTypes($transaction)) {
            return;
        }

        if ($transaction->getAmount()->isPositive()
            && $purchase_reference = Helper_Banktransaction_Matching::get_purchase_reference($transaction->getDescription())
        ) {
            $transaction->setTags([TransactionTags::TAG_KBC]);
            $transaction->addTagData(['transaction_id' => $purchase_reference]);

            return;
        }

        // We paid out some money, tag it unknown and be done with it. (no registration)
        if ($statement_transaction->getAmount()->isNegative()) {
            $transaction->setTags([TransactionTags::TAG_UNKNOWNKBC]);

            return;
        }
    }

    protected function getUnknownTag(): string
    {
        return TransactionTags::TAG_UNKNOWNKBC;
    }

    protected function getUnknownRegistrationTag(): string
    {
        return Model_TransactionRegistration::REGISTRATION_UNKNOWN_KBC;
    }
}
