<?php

declare(strict_types=1);

namespace StatementHandlers;

use Bank\Statements\StatementTransaction;
use Bank_Swift_Codes;
use Helper_Banktransaction_Matching;
use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use Model_TransactionRegistration;
use Webmozart\Assert\Assert;

/**
 * Handle bank statements for accounts that deal with Mollie Direct Debit payments.
 */
class DirectDebitStatementHandler extends StatementHandlerBase
{
    protected function processTransaction(
        Model_Banktransaction $transaction,
        StatementTransaction $statement_transaction
    ): void {
        /*
         * A batch with a negative amount is likely a batch of transactions that were made to our account manually. These
         * transactions were tagged as 'unknowndirectdebit' transactions. We will thus tag the batch as 'unknowndirectdebit'
         * as well, making sure the batch will not be expanded further down the line.
         */
        if ($transaction->isSepaBatch() && $transaction->isDebited()) {
            $transaction->setTags([TransactionTags::TAG_UNKNOWNDIRECTDEBIT]);

            return;
        }

        if ($this->detectStandardTransactionTypes($transaction)) {
            return;
        }

        $transaction_id = $this->getDirectDebitTransactionId($statement_transaction);

        if ($transaction_id === null) {
            return; // No transaction_id found! This is not a Mollie Direct Debit.
        }

        if ($this->isAdditonalEuCostsForFailureTransaction($statement_transaction)) {
            $transaction->setTags([TransactionTags::TAG_STORNODIRECTDEBIT_COSTSEU]);
            $transaction->setTagData(['transaction_id' => $transaction_id]);

            return;
        }

        /*
         * Get failed reason code via Bank_Swift_Codes::EXTERNAL_REJECTION_CODE "/RTRN/" section of MT940,
         * or if it's provided via description.
         */
        $reason_code = $statement_transaction->hasSwiftCode(Bank_Swift_Codes::EXTERNAL_REJECTION_CODE)
            ? $statement_transaction->getSwiftCodeValue(Bank_Swift_Codes::EXTERNAL_REJECTION_CODE)
            : Helper_Banktransaction_Matching::get_directdebit_reason_code($transaction->getDescription());

        // Default reason code.
        if ($reason_code === null) {
            $reason_code = Bank_Swift_Codes::REASON_CODE_BANK_SUPPLIED_NO_REASON;
        }

        $transaction->setTags([TransactionTags::TAG_FAILUREDIRECTDEBIT]);
        $transaction->setTagData([
            'transaction_id' => $transaction_id,
            'reason_code'    => $reason_code,
        ]);
    }

    private function isAdditonalEuCostsForFailureTransaction(StatementTransaction $statement_transaction): bool
    {
        $info = $statement_transaction->getSwiftCodeValue(Bank_Swift_Codes::INFORMATION);

        if ($info === 'Verschuldigde kosten bank debiteur') {
            Assert::true($statement_transaction->getAmount()->isNegative(), "Costs owed to bank cannot be positive");

            return true;
        }

        return false;
    }

    private function getDirectDebitTransactionId(StatementTransaction $statement_transaction): ?string
    {
        $reference = $statement_transaction->getSwiftCodeValue(Bank_Swift_Codes::REFERENCE_ORIGINATOR) ?: $statement_transaction->getSwiftCodeValue(Bank_Swift_Codes::CUSTOMER_REFERENCE);

        if ($reference === null) {
            return null;
        }

        return Helper_Banktransaction_Matching::get_directdebit_sd($reference);
    }

    protected function getUnknownTag(): string
    {
        return TransactionTags::TAG_UNKNOWNDIRECTDEBIT;
    }

    protected function getUnknownRegistrationTag(): string
    {
        return Model_TransactionRegistration::REGISTRATION_UNKNOWN_DIRECTDEBIT;
    }
}
