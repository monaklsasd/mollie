<?php

declare(strict_types=1);

namespace StatementHandlers;

use Bank\Statements\StatementTransaction;
use Helper_Bank_OgmVcs;
use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use Model_TransactionRegistration;

/**
 * Handle bank statements for accounts that deal with Home'Pay payments.
 */
class IngHomePayStatementHandler extends StatementHandlerBase
{
    protected function processTransaction(
        Model_Banktransaction $transaction,
        StatementTransaction $statement_transaction
    ): void {
        if ($this->detectStandardTransactionTypes($transaction)) {
            return;
        }

        if ($transaction->getAmount()->isPositive() && $transaction_id = Helper_Bank_OgmVcs::find_ogm($transaction->getDescription())) {
            $transaction->setTags([TransactionTags::TAG_INGHOMEPAY]);
            $transaction->setTagData(['transaction_id' => $transaction_id]);

            return;
        }

        // We paid out some money, tag it unknown and be done with it. (no registration)
        if ($statement_transaction->getAmount()->isNegative()) {
            $transaction->setTags([TransactionTags::TAG_UNKNOWNINGHOMEPAY]);

            return;
        }
    }

    protected function getUnknownTag(): string
    {
        return TransactionTags::TAG_UNKNOWNINGHOMEPAY;
    }

    protected function getUnknownRegistrationTag(): string
    {
        return Model_TransactionRegistration::REGISTRATION_UNKNOWN_INGHOMEPAY;
    }
}
