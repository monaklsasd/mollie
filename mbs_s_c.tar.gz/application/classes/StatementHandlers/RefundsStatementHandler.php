<?php

declare(strict_types=1);

namespace StatementHandlers;

use Bank\Statements\StatementTransaction;
use Helper_Banktransaction_Matching;
use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use Model_TransactionRegistration;

class RefundsStatementHandler extends StatementHandlerBase
{
    protected function processTransaction(
        Model_Banktransaction $transaction,
        StatementTransaction $statement_transaction
    ): void {
        /*
         * All normal refunds are in the sepa batch, (only) the returned ones are top level transactions.
         * So for now we can only extract the ID from from those transactions here.
         */
        if ($transaction->isReturnedTransaction()
            && $transaction_id = Helper_Banktransaction_Matching::getRefundPaymentId($transaction->getDescription())
        ) {
            $transaction->setSupplierTransactionId($transaction_id);
            $transaction->setTags([TransactionTags::TAG_FAILUREREFUND]);

            return;
        }

        $result = $this->detectStandardTransactionTypes($transaction);

        /**
         * Normal refunds can be top level transactions as well. This happens mostly for handled by ledger refunds,
         * because there is a little number of refunds performed, so we're not waiting to get more to batch them.
         * Thus, we're trying here to tag them accordingly one more time.
         */
        if ($result === false
            && $transaction_id = Helper_Banktransaction_Matching::getRefundPaymentId($transaction->getDescription())
        ) {
            $transaction->setSupplierTransactionId($transaction_id);
            $transaction->setTags([TransactionTags::TAG_REFUNDS]);
        }
    }

    protected function getUnknownTag(): string
    {
        return TransactionTags::TAG_UNKNOWNREFUND;
    }

    protected function getUnknownRegistrationTag(): string
    {
        return Model_TransactionRegistration::REGISTRATION_UNKNOWN_REFUND;
    }
}
