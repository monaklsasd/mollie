<?php

declare(strict_types=1);

namespace StatementHandlers;

use Bank\Statements\StatementTransaction;
use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use Model_TransactionRegistration;

class MollieAccountStatementHandler extends StatementHandlerBase
{
    protected function processTransaction(
        Model_Banktransaction $transaction,
        StatementTransaction $statement_transaction
    ): void {
        if ($this->detectStandardTransactionTypes($transaction)) {
            return;
        }

        // Mark for manual handling, so they do not get the 'unknown' registration.
        $transaction->addTag(TransactionTags::TAG_MANUAL_HANDLING);
    }

    protected function getUnknownTag(): string
    {
        return TransactionTags::TAG_UNKNOWNBANKTRANSFER;
    }

    protected function getUnknownRegistrationTag(): string
    {
        return Model_TransactionRegistration::REGISTRATION_UNKNOWN_BANKTRANSFER;
    }
}
