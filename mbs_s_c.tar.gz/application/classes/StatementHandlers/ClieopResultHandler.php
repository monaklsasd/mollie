<?php

declare(strict_types=1);

namespace StatementHandlers;

use Bank_ClieopResult;
use Core\Localization\Localizer;
use Helper_Banktransaction_Matching;
use Model_BankPaymentBatch;
use Model_Exception;
use Mollie_Logger;
use Orm\Repositories\BankPaymentBatchRepository;
use OutOfBoundsException;
use Supplier\Mollie\Mollie;
use Supplier\Mollie\MollieException;

/**
 * When this class receives the callback call from the ClieopResultParser, it updates the Model_BankPaymentBatch
 * according to the data that is in the ClieopResult file.
 *
 * TODO: This shouldn't be a statement handler, as it doesn't handle statements, but it handles a ClieopResult.
 */
class ClieopResultHandler
{
    /** @var BankPaymentBatchRepository */
    protected $repository;

    /** @var Mollie_Logger */
    protected $logger;

    /** @var */
    protected $mollie;

    public function __construct(BankPaymentBatchRepository $repository, Mollie_Logger $logger, Mollie $mollie)
    {
        $this->repository = $repository;
        $this->logger     = $logger;
        $this->mollie     = $mollie;
    }

    /**
     * Actually process the clieopresult as received from the bank.
     *
     * It is possible that we receive multiple status updates on a batch. E.g. if it was completed, and then later we
     * might receive updates that some transactions were rejected.
     *
     * @throws Model_Exception
     *
     * @return bool
     */
    public function callbackResults(Bank_ClieopResult $result)
    {
        try {
            $batch = $this->repository->getByReference($result->getInterchangeReference());
        } catch (OutOfBoundsException $e) {
            $this->logger->log_error(
                Mollie_Logger::LOG_CATEGORY_IMPORTS,
                "Cannot find batch by given batch reference",
                "Unknown batch: " . $result->getInterchangeReference()
            );

            return false;
        }

        /*
         * When we have not even attempted to send this batch to the bank, we do not expect to receive an update on its
         * status.
         */
        if (!$batch->anAttemptWasMadeToSendToBank()) {
            $batch->storeHistoryEntry('Received reply from the bank, but the batch has never been sent!');

            $this->logger->log_warning(
                Mollie_Logger::LOG_CATEGORY_IMPORTS,
                sprintf('Batch #%d hasn\'t been sent to the bank yet, not updating', $batch->getPrimaryKey()),
                $result->getRawData()
            );

            return false;
        }

        /*
         * In this case, we have successfully sent the batch to the bank, but we did not receive confirmation of the
         * upload, which resulted in the status not getting updated.
         */
        if (!$batch->isSentToBank()) {
            $batch->storeHistoryEntry(
                'Received reply from the bank, while we have not received a confirmation of successfully sending yet.'
            );

            $this->updateBatchStatus($batch, Model_BankPaymentBatch::SENT_TO_BANK);
        }

        $rejected_transactions = $result->getRejectedTransactions();

        foreach ($rejected_transactions as $rejected_transaction) {
            $batch->storeHistoryEntry(sprintf(
                'Transaction rejected by the bank: %s to account %s to the name of %s with description %s.',
                Localizer::formatMoney($rejected_transaction->getAmount()),
                $rejected_transaction->getRecipientBankAccount()->getIban(),
                $rejected_transaction->getRecipientBankAccount()->getAccountHolderName(),
                $rejected_transaction->getMessage()
            ));

            if ($outpayment_reference = Helper_Banktransaction_Matching::getOutpaymentReference(
                $rejected_transaction->getMessage()
            )) {
                /*
                 * Als er een uitbetaling is geweigerd, informeer dan de Mollie applicatie en deze zorgt dat de klant
                 * dit probleem gaat oplossen. Dit bericht komt op dezelfde werkdag binnen als de uitbetaling gedaan
                 * is, dus dan gaat het proces één dag sneller.
                 */
                try {
                    $recipient_account = $rejected_transaction->getRecipientBankAccount();
                    $this->mollie->markOutpaymentReturned(
                        $outpayment_reference,
                        $rejected_transaction->getAmount(),
                        $recipient_account->getIban() ?? $recipient_account->getNumber()
                    );
                } catch (MollieException $e) {
                    apm_log_exception($e); // Gotta catch 'm all.
                }
            }
        }

        if (!$batch->hasBankResponse()) {
            /*
             * Batch is not completed, update batch status.
             */
            $this->updateBatchWithResponse($batch, $result);
        }

        return true;
    }

    private function updateBatchWithResponse(Model_BankPaymentBatch $batch, Bank_ClieopResult $result)
    {
        $batch->result_contents = $result->getRawData();
        $completed              = Model_BankPaymentBatch::COMPLETED;
        $history_message        = 'Payment batch is processed and being executed!';

        if (!$result->isSuccessful()) {
            $history_message = 'Payment batch is only partially processed and executed.';
            $completed       = Model_BankPaymentBatch::COMPLETED_PARTIALLY;

            /* Lack of funds may cause a full rejection */
            if ($result->isRejected()) {
                $history_message = 'Payment batch not processed. Message from the bank: ' . $result->getRejectionReason();
                $completed       = Model_BankPaymentBatch::FAILED;
            }
        }

        $batch->storeHistoryEntry($history_message);
        $this->updateBatchStatus($batch, $completed);
    }

    private function updateBatchStatus(Model_BankPaymentBatch $batch, $new_status): void
    {
        if (!$batch->updateToStatus($new_status)) {
            $batch->storeHistoryEntry('Unable to update the batch!');

            throw new Model_Exception('Could not update batch');
        }
    }
}
