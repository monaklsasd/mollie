<?php

declare(strict_types=1);

namespace StatementHandlers;

use Bank\Statements\StatementTransaction;
use Helper_Banktransaction_Matching;
use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use Model_TransactionRegistration;

class BelfiusStatementHandler extends StatementHandlerBase
{
    use BelfiusStatementFormatTrait;

    /**
     * @throws Exceptions\SkipTransactionException
     */
    protected function processTransaction(
        Model_Banktransaction $transaction,
        StatementTransaction $statement_transaction
    ): void {
        $this->assertBelfiusTransactionType($transaction, $statement_transaction);

        if ($this->detectStandardTransactionTypes($transaction)) {
            return;
        }

        // We paid out some money, tag it unknown and be done with it. (no registration)
        if (!$transaction->getAmount()->isPositive()) {
            $transaction->setTags([TransactionTags::TAG_UNKNOWNBELFIUS]);

            return;
        }

        if ($reference = Helper_Banktransaction_Matching::get_purchase_reference($transaction->getDescription())) {
            $transaction->setTags([TransactionTags::TAG_BELFIUS]);
            $transaction->setTagData(['transaction_id' => $reference]);

            return;
        }
    }

    protected function getUnknownTag(): string
    {
        return TransactionTags::TAG_UNKNOWNBELFIUS;
    }

    protected function getUnknownRegistrationTag(): string
    {
        return Model_TransactionRegistration::REGISTRATION_UNKNOWN_BELFIUS;
    }
}
