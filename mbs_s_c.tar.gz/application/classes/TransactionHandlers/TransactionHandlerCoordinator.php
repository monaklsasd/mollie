<?php

declare(strict_types=1);

namespace TransactionHandlers;

use BankAccounts\BankAccount;
use BankAccounts\BankAccountRepository;
use DateTimeImmutable;
use DateTimeZone;
use Helper\DateTime\Utc;
use Model_Bankstatement;
use Mollie_Database_Exception_Query_DuplicateEntry;
use Mollie_Logger;
use SplStack;
use sql_db;
use TransactionHandlers\Exceptions\DuplicateTransactionHandlerException;
use TransactionHandlers\Exceptions\JobStatusMismatchException;
use TransactionHandlers\Exceptions\StatementAlreadyRegistereredException;
use TransactionHandlers\Exceptions\UnknownTransactionHandlerException;
use function count;
use function get_class;

class TransactionHandlerCoordinator
{
    use Utc;

    /** @var sql_db */
    protected $db;

    /** @var Mollie_Logger */
    protected $logger;

    /** @var BankAccountRepository */
    protected $bank_account_repository;

    /** @var DateTimeZone */
    private static $utc;

    public function __construct(
        sql_db $db,
        Mollie_Logger $logger,
        BankAccountRepository $bank_account_repository
    ) {
        $this->db                      = $db;
        $this->logger                  = $logger;
        $this->bank_account_repository = $bank_account_repository;
    }

    /**
     * @throws DuplicateTransactionHandlerException
     * @throws UnknownTransactionHandlerException
     */
    public function registerNewStatement(Model_Bankstatement $statement): void
    {
        $this->registerNextHandlerForStatement($statement);
    }

    /**
     * @return SplStack|TransactionHandlerJob[]
     */
    public function getQueuedTransactionHandlerJobs(): SplStack
    {
        $job_data = $this->db->sql_fetchquery('
            SELECT 
                `statementimport_id`,
                `handler_class_name`,
                `status`,
                `tries`,
                `run_at_utc`,
                `started_at_utc`,
                `stopped_at_utc`
            FROM `bank_statement_transaction_handler_jobs`
            WHERE
              `status` = $1 AND
              `run_at_utc` <= UTC_TIMESTAMP
            ORDER BY RAND()
        ', [Status::QUEUED()]);

        $jobs = new SplStack();

        array_walk($job_data, function (array $job_data) use ($jobs) {
            $jobs->push(self::jobFromArray($job_data));
        });

        return $jobs;
    }

    /**
     * @return TransactionHandlerJob[]
     */
    public function getLogForStatement(Model_Bankstatement $statement): array
    {
        $result = $this->db->sql_fetchquery('
            SELECT 
                `statementimport_id`,
                `handler_class_name`,
                `status`,
                `tries`,
                `run_at_utc`,
                `started_at_utc`,
                `stopped_at_utc`
            FROM
              `bank_statement_transaction_handler_jobs`
            WHERE
              statementimport_id = ^1
        ', [(int)$statement->getPrimaryKey()], 'handler_class_name');

        return array_map([__CLASS__, 'jobFromArray'], $result);
    }

    /**
     * @return TransactionHandlerJob[]
     */
    public function getLogForDashboard(): array
    {
        $result = $this->db->sql_fetchquery('
            SELECT 
                `job`.`statementimport_id`,
                `job`.`handler_class_name`,
                `job`.`status`,
                `job`.`tries`,
                `job`.`run_at_utc`,
                `job`.`started_at_utc`,
                `job`.`stopped_at_utc`
            FROM
              `bank_statement_transaction_handler_jobs` AS `job`
            INNER JOIN `bank_statement_imports` AS `statement` ON `job`.`statementimport_id` = `statement`.`id`
            WHERE
              (`job`.`status` <> $1)
            OR
              (`job`.`status` = $1 AND `job`.`tries` > 1 AND `job`.`started_at_utc` > DATE_SUB(UTC_TIMESTAMP, INTERVAL 2 DAY))
            ORDER BY `statement`.`statement_date` DESC;
              
        ', [Status::DONE()]);

        return array_map('self::jobFromArray', $result);
    }

    /**
     * @return int|null average duration in seconds, or null if not run before.
     */
    public function getAverageDurationForJob(
        string $transaction_handler_class_name,
        BankAccount $bank_account
    ): ?int {
        $result = $this->db->sql_fetchone(
            'SELECT
                    CAST(AVG(TIMESTAMPDIFF(SECOND, jobs.started_at_utc, jobs.stopped_at_utc)) AS UNSIGNED)
                FROM
                    bank_statement_transaction_handler_jobs AS jobs
                INNER JOIN bank_statement_imports AS statement ON jobs.statementimport_id = statement.id
                WHERE
                    jobs.handler_class_name = $1 AND
                    statement.bankaccount_id = ^2 AND
                    jobs.tries = ^3 AND
                    jobs.status = $4;
            ',
            null,
            [$transaction_handler_class_name, $bank_account::getId(), 1, Status::DONE()]
        );

        if ($result === null) {
            return null;
        }

        return (int)$result;
    }

    /**
     * @throws DuplicateTransactionHandlerException
     * @throws UnknownTransactionHandlerException
     */
    private function getNextTransactionHandlerClassName(
        BankAccount $bank_account,
        ?string $current_transaction_handler_class_name = null
    ): ?string {
        $transaction_handler_class_names = $bank_account->getTransactionHandlerClasses();

        if (count($transaction_handler_class_names) === 0) {
            return null;
        }

        //only when searching for first handler, run duplicate check
        if ($current_transaction_handler_class_name === null) {
            $handler_count = array_count_values($transaction_handler_class_names);

            if (count($transaction_handler_class_names) !== count($handler_count)) {
                asort($handler_count);

                throw new DuplicateTransactionHandlerException(sprintf(
                    'The transactionhandler "%s" has been registered more than once (%d times) for bankaccount %d.',
                    key($handler_count),
                    current($handler_count),
                    $bank_account::getId()
                ));
            }

            return current($transaction_handler_class_names);
        }

        if (!in_array($current_transaction_handler_class_name, $transaction_handler_class_names, true)) {
            throw new UnknownTransactionHandlerException(sprintf(
                'The transactionhandler "%s" is no longer registered with bankaccount %d, don\'t know which job to trigger next.',
                $current_transaction_handler_class_name,
                $bank_account::getId()
            ));
        }

        while (current($transaction_handler_class_names) !== $current_transaction_handler_class_name) {
            next($transaction_handler_class_names);
        }

        return next($transaction_handler_class_names) ?: null;
    }

    /**
     * @throws StatementAlreadyRegistereredException
     * @throws DuplicateTransactionHandlerException
     * @throws UnknownTransactionHandlerException
     */
    protected function registerNextHandlerForStatement(
        Model_Bankstatement $statement,
        ?string $current_transaction_handler_class_name = null
    ): ?string {
        $bank_account = $statement->getBankAccount();

        $next_job = $this->getNextTransactionHandlerClassName($bank_account, $current_transaction_handler_class_name);

        if ($next_job === null) {
            return null;
        }

        try {
            $this->db->sql_safe_query(
                '
            INSERT INTO `bank_statement_transaction_handler_jobs` 
                (`statementimport_id`, `handler_class_name`, `run_at_utc`)
            VALUES
                (^1, $2, UTC_TIMESTAMP)
            ',
                $statement->getPrimaryKey(),
                $next_job
            );
        } catch (Mollie_Database_Exception_Query_DuplicateEntry $e) {
            if ($next_job === $this->getNextTransactionHandlerClassName($bank_account)) {
                throw new StatementAlreadyRegistereredException(sprintf(
                    'Statement %d already registered for processing by %s.',
                    $statement->getPrimaryKey(),
                    $next_job
                ));
            }

            // If it is not the first job, this is probably caused by a rerun. The next job should be queued again.
            $this->rerunHandler($statement, $next_job);
        }

        return $next_job;
    }

    /**
     * @throws JobStatusMismatchException
     */
    public function markHandlerRunning(Model_Bankstatement $statement, TransactionHandler $transaction_handler): void
    {
        $this->db->sql_safe_query(
            '
            UPDATE `bank_statement_transaction_handler_jobs`
            SET 
                `status` = $1,
                `tries` = `tries` + 1,
                `run_at_utc` = NULL,
                `started_at_utc` = UTC_TIMESTAMP,
                `stopped_at_utc` = NULL
            WHERE
              `status` = "queued" AND
              `statementimport_id` = ^2 AND
              `handler_class_name` = $3
            ',
            Status::RUNNING(),
            $statement->getPrimaryKey(),
            get_class($transaction_handler)
        );

        if ($this->db->sql_affectedrows() === 0) {
            throw new JobStatusMismatchException(sprintf(
                'Couldn\'t find queued "%s" job for statement %d, possibly concurrency issue',
                get_class($transaction_handler),
                $statement->getPrimaryKey()
            ));
        }
    }

    /**
     * @return TransactionHandlerJob|null next job for this statement
     */
    public function markHandlerDone(
        Model_Bankstatement $statement,
        TransactionHandler $transaction_handler
    ): ?TransactionHandlerJob {
        $transaction_handler_class_name = get_class($transaction_handler);

        $this->db->sql_safe_query(
            '
            UPDATE `bank_statement_transaction_handler_jobs`
            SET 
                `status` = $1,
                `run_at_utc` = NULL,
                `stopped_at_utc` = UTC_TIMESTAMP
            WHERE
              `status` = $2 AND
              `statementimport_id` = ^3 AND
              `handler_class_name` = $4
            ',
            Status::DONE(),
            Status::RUNNING(),
            $statement->getPrimaryKey(),
            $transaction_handler_class_name
        );

        // Register next job.
        $next_handler_class_name = $this->registerNextHandlerForStatement($statement, $transaction_handler_class_name);

        if ($next_handler_class_name === null) {
            return null;
        }

        return new TransactionHandlerJob(
            (int)$statement->getPrimaryKey(),
            $next_handler_class_name,
            Status::QUEUED(),
            0,
            new DateTimeImmutable('now', self::getUtc()),
            null,
            null
        );
    }

    public function markHandlerFailed(Model_Bankstatement $statement, TransactionHandler $transaction_handler): void
    {
        $tries = $this->db->sql_fetchone(
            '
            SELECT `tries` 
            FROM `bank_statement_transaction_handler_jobs`
            WHERE
                `status` = $1 AND
                `statementimport_id` = ^2 AND
                `handler_class_name` = $3
            ',
            'tries',
            [
                Status::RUNNING(),
                $statement->getPrimaryKey(),
                get_class($transaction_handler),
            ]
        );

        $status_value = Status::FAILED();
        $run_at_value = 'NULL';

        if ($transaction_handler->getMaxTries() === 0 || $tries < $transaction_handler->getMaxTries()) {
            $status_value = Status::QUEUED();
            $run_at_value = sprintf('UTC_TIMESTAMP + INTERVAL %d SECOND', $transaction_handler->getRetryDelay());
        }

        $this->db->sql_safe_query(
            '
            UPDATE `bank_statement_transaction_handler_jobs`
            SET 
                `status` = $1, run_at_utc = ^2, stopped_at_utc = UTC_TIMESTAMP
            WHERE
              `status` = $3 AND
              `statementimport_id` = ^4 AND
              `handler_class_name` = $5
            ',
            $status_value,
            $run_at_value,
            Status::RUNNING(),
            $statement->getPrimaryKey(),
            get_class($transaction_handler)
        );
    }

    /**
     * Will trigger a handler to run again immediately
     */
    public function rerunHandler(Model_Bankstatement $statement, string $transaction_handler_class_name): void
    {
        $this->db->sql_safe_query(
            'INSERT INTO `bank_statement_transaction_handler_jobs` (status, run_at_utc, statementimport_id, handler_class_name) VALUES ($1, UTC_TIMESTAMP, ^2, $3) ON DUPLICATE KEY UPDATE status = $1, run_at_utc = UTC_TIMESTAMP',
            Status::QUEUED(),
            $statement->getPrimaryKey(),
            $transaction_handler_class_name
        );
    }

    private static function jobFromArray(array $job): TransactionHandlerJob
    {
        return new TransactionHandlerJob(
            (int)$job['statementimport_id'],
            $job['handler_class_name'],
            new Status($job['status']),
            (int)$job['tries'],
            self::toDateTime($job['run_at_utc'] ?? null),
            self::toDateTime($job['started_at_utc'] ?? null),
            self::toDateTime($job['stopped_at_utc'] ?? null)
        );
    }
}
