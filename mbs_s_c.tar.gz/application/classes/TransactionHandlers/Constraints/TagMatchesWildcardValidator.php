<?php

declare(strict_types=1);

namespace TransactionHandlers\Constraints;

use Model_Banktransaction;
use Symfony\Component\Validator\Constraint;
use Symfony\Component\Validator\ConstraintValidator;
use Webmozart\Assert\Assert;

class TagMatchesWildcardValidator extends ConstraintValidator
{
    /**
     * @param Model_Banktransaction $transaction
     * @param TagMatchesWildcard    $constraint
     */
    public function validate($transaction, Constraint $constraint)
    {
        Assert::isInstanceOf($transaction, Model_Banktransaction::class);
        Assert::isInstanceOf($constraint, TagMatchesWildcard::class);

        $regexp = sprintf('/%s/', preg_quote($constraint->tag_wildcard, '/'));

        if (\count(preg_grep($regexp, $transaction->getTags())) === 0) {
            $this->context->buildViolation($constraint->message)
                ->setParameter('{{ wildcard }}', $constraint->tag_wildcard)
                ->setParameter('{{ actual_tag }}', implode(', ', $transaction->getTags()))
                ->addViolation();
        }
    }
}
