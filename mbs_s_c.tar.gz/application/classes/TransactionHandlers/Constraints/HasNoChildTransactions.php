<?php

declare(strict_types=1);

namespace TransactionHandlers\Constraints;

use Symfony\Component\Validator\Constraint;

class HasNoChildTransactions extends Constraint
{
    public $message = 'Transaction has {{ child_count }} child transactions';

    public function getTargets()
    {
        return self::CLASS_CONSTRAINT;
    }
}
