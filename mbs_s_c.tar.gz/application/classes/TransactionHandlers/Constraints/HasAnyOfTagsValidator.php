<?php

declare(strict_types=1);

namespace TransactionHandlers\Constraints;

use Model_Banktransaction;
use Symfony\Component\Validator\Constraint;
use Symfony\Component\Validator\ConstraintValidator;
use Symfony\Component\Validator\Exception\UnexpectedTypeException;
use Webmozart\Assert\Assert;

class HasAnyOfTagsValidator extends ConstraintValidator
{
    /**
     * @param Model_Banktransaction $transaction
     * @param HasAnyOfTags          $constraint
     */
    public function validate($transaction, Constraint $constraint)
    {
        if (!$constraint instanceof HasAnyOfTags) {
            throw new UnexpectedTypeException($constraint, HasAnyOfTags::class);
        }

        Assert::isInstanceOf($transaction, Model_Banktransaction::class);

        if (!$transaction->hasAnyOfTags($constraint->tags_to_find)) {
            $this->context->buildViolation($constraint->message)
                ->setParameter('{{ tags_to_find }}', implode(', ', $constraint->tags_to_find))
                ->setParameter('{{ actual_tags }}', implode(', ', $transaction->getTags()))
                ->addViolation();
        }
    }
}
