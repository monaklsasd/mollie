<?php

declare(strict_types=1);

namespace TransactionHandlers\Constraints;

use Model_Banktransaction;
use Symfony\Component\Validator\Constraint;
use Symfony\Component\Validator\ConstraintValidator;
use Webmozart\Assert\Assert;

class ParentTagExactlyMatchesValidator extends ConstraintValidator
{
    /**
     * @param Model_Banktransaction $transaction
     */
    public function validate($transaction, Constraint $constraint)
    {
        Assert::isInstanceOf($transaction, Model_Banktransaction::class);
        Assert::isInstanceOf($constraint, ParentTagExactlyMatches::class);

        $parent = $transaction->getParentTransaction();

        if ($parent === null) {
            $this->context->buildViolation($constraint->message)
                ->setParameter('{{ expected_tag }}', $constraint->tag)
                ->setParameter('{{ actual_tag }}', '[NO PARENT]')
                ->addViolation();

            return;
        }

        if (\count($parent->getTags()) !== 1 || $parent->getTags()[0] !== $constraint->tag) {
            $this->context->buildViolation($constraint->message)
                ->setParameter('{{ expected_tag }}', $constraint->tag)
                ->setParameter('{{ actual_tag }}', implode(', ', $parent->getTags()))
                ->addViolation();
        }
    }
}
