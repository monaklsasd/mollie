<?php

declare(strict_types=1);

namespace TransactionHandlers\Constraints;

use Symfony\Component\Validator\Constraint;

class DoesntHaveAnyOfTags extends Constraint
{
    /** @var string[] */
    public $tags_to_find = [];

    public $message = 'Transaction has some of these tags: {{ tags_to_find }}. The full tag list is {{ actual_tags }}';

    public function __construct(array $tags_to_look_for)
    {
        parent::__construct();

        $this->tags_to_find = $tags_to_look_for;
    }

    public function getTargets()
    {
        return self::CLASS_CONSTRAINT;
    }
}
