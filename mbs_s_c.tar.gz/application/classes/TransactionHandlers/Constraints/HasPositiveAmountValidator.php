<?php

declare(strict_types=1);

namespace TransactionHandlers\Constraints;

use Core\Localization\Localizer;
use Model_Banktransaction;
use Symfony\Component\Validator\Constraint;
use Symfony\Component\Validator\ConstraintValidator;
use Webmozart\Assert\Assert;

class HasPositiveAmountValidator extends ConstraintValidator
{
    /**
     * @param Model_Banktransaction $transaction
     */
    public function validate($transaction, Constraint $constraint)
    {
        Assert::isInstanceOf($transaction, Model_Banktransaction::class);
        Assert::isInstanceOf($constraint, HasPositiveAmount::class);

        if (!$transaction->getAmount()->isPositive()) {
            $this->context->buildViolation($constraint->message)
                ->setParameter('{{ amount }}', Localizer::formatMoney($transaction->getAmount()))
                ->addViolation();
        }
    }
}
