<?php

declare(strict_types=1);

namespace TransactionHandlers\Constraints;

use Symfony\Component\Validator\Constraint;

class ParentTagExactlyMatches extends Constraint
{
    public $tag;

    public $message = 'Parent transaction does not have expected tag: {{ expected_tag }}, but instead: {{ actual_tag }}';

    public function __construct(string $expected_tag)
    {
        parent::__construct();

        $this->tag = $expected_tag;
    }

    public function getTargets()
    {
        return self::CLASS_CONSTRAINT;
    }
}
