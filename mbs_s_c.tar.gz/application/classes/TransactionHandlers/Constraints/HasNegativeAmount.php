<?php

declare(strict_types=1);

namespace TransactionHandlers\Constraints;

use Symfony\Component\Validator\Constraint;

class HasNegativeAmount extends Constraint
{
    public $message = 'Transaction has non-negative amount: {{ amount }}';

    public function getTargets()
    {
        return self::CLASS_CONSTRAINT;
    }
}
