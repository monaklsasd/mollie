<?php

declare(strict_types=1);

namespace TransactionHandlers\Constraints;

use Symfony\Component\Validator\Constraint;

class HasNoSettlement extends Constraint
{
    public $message = 'Transaction already settled';

    public function getTargets()
    {
        return self::CLASS_CONSTRAINT;
    }
}
