<?php

declare(strict_types=1);

namespace TransactionHandlers\Constraints;

use Symfony\Component\Validator\Constraint;

class TagExactlyMatches extends Constraint
{
    public $tag;
    public $message = 'Transaction does not have expected tag: {{ expected_tag }}, but instead: {{ actual_tag }}';

    public function __construct(string $expected_tag)
    {
        parent::__construct();

        $this->tag = $expected_tag;
    }

    public function getTargets()
    {
        return self::CLASS_CONSTRAINT;
    }
}
