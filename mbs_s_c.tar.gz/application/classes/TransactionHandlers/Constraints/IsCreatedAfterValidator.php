<?php

declare(strict_types=1);

namespace TransactionHandlers\Constraints;

use Model_Banktransaction;
use Symfony\Component\Validator\Constraint;
use Symfony\Component\Validator\ConstraintValidator;
use Webmozart\Assert\Assert;

class IsCreatedAfterValidator extends ConstraintValidator
{
    public function validate($transaction, Constraint $constraint)
    {
        Assert::isInstanceOf($transaction, Model_Banktransaction::class);
        Assert::isInstanceOf($constraint, IsCreatedAfter::class);

        $date_from = $constraint->date_from->format('Y-m-d');

        if ($transaction->entry_date <= $date_from) {
            $this->context->buildViolation($constraint->message)
                ->setParameter('{{ date_from }}', (string)$date_from)
                ->setParameter('{{ transaction_date }}', (string)$transaction->entry_date)
                ->addViolation();
        }
    }
}
