<?php

declare(strict_types=1);

namespace TransactionHandlers\Constraints;

use Symfony\Component\Validator\Constraint;

class TagMatchesWildcard extends Constraint
{
    public $tag_wildcard;
    public $message = 'Transaction tag {{ actual_tag }} does not match wildcard: {{ wildcard }}';

    public function __construct(string $wildcard)
    {
        parent::__construct();

        $this->tag_wildcard = $wildcard;
    }

    public function getTargets()
    {
        return self::CLASS_CONSTRAINT;
    }
}
