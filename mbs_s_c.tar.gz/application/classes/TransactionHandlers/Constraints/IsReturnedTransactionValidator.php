<?php

declare(strict_types=1);

namespace TransactionHandlers\Constraints;

use Model_Banktransaction;
use Symfony\Component\Validator\Constraint;
use Symfony\Component\Validator\ConstraintValidator;
use Webmozart\Assert\Assert;

class IsReturnedTransactionValidator extends ConstraintValidator
{
    /**
     * @param Model_Banktransaction $transaction
     */
    public function validate($transaction, Constraint $constraint)
    {
        Assert::isInstanceOf($transaction, Model_Banktransaction::class);

        if (!$transaction->isReturnedTransaction()) {
            $this->context->buildViolation($constraint->message)
                ->addViolation();
        }
    }
}
