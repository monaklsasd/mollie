<?php

declare(strict_types=1);

namespace TransactionHandlers\Constraints;

use DateTimeInterface;
use Symfony\Component\Validator\Constraint;

class IsCreatedAfter extends Constraint
{
    public $message = 'Transaction is not created after {{ date_from }} but instead: {{ transaction_date }}';

    /** @var DateTimeInterface */
    public $date_from;

    public function __construct(DateTimeInterface $entry_date_from)
    {
        parent::__construct();

        $this->date_from = $entry_date_from;
    }

    public function getTargets()
    {
        return self::CLASS_CONSTRAINT;
    }
}
