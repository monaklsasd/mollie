<?php

declare(strict_types=1);

namespace TransactionHandlers\Constraints;

use Model_Banktransaction;
use Symfony\Component\Validator\Constraint;
use Symfony\Component\Validator\ConstraintValidator;
use Symfony\Component\Validator\Exception\UnexpectedTypeException;
use Webmozart\Assert\Assert;

class OptionalParentHasAnyOfTagsValidator extends ConstraintValidator
{
    /**
     * @param Model_Banktransaction $transaction
     * @param HasAnyOfTags          $constraint
     */
    public function validate($transaction, Constraint $constraint)
    {
        if (!$constraint instanceof OptionalParentHasAnyOfTags) {
            throw new UnexpectedTypeException($constraint, OptionalParentHasAnyOfTags::class);
        }

        Assert::isInstanceOf($transaction, Model_Banktransaction::class);

        $parent = $transaction->getParentTransaction();

        if ($parent === null) {
            return;
        }

        if (!$parent->hasAnyOfTags($constraint->tags_to_find)) {
            $this->context->buildViolation($constraint->message)
                ->setParameter('{{ expected_tag }}', implode(', ', $constraint->tags_to_find))
                ->setParameter('{{ actual_tag }}', implode(', ', $parent->getTags()))
                ->addViolation();
        }
    }
}
