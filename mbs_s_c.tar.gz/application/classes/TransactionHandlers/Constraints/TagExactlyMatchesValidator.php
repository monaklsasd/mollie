<?php

declare(strict_types=1);

namespace TransactionHandlers\Constraints;

use Model_Banktransaction;
use Symfony\Component\Validator\Constraint;
use Symfony\Component\Validator\ConstraintValidator;
use Webmozart\Assert\Assert;

class TagExactlyMatchesValidator extends ConstraintValidator
{
    /**
     * @param Model_Banktransaction $transaction
     * @param TagExactlyMatches     $constraint
     */
    public function validate($transaction, Constraint $constraint)
    {
        Assert::isInstanceOf($transaction, Model_Banktransaction::class);
        Assert::isInstanceOf($constraint, TagExactlyMatches::class);

        if (\count($transaction->getTags()) !== 1 || $transaction->getTags()[0] !== $constraint->tag) {
            $this->context->buildViolation($constraint->message)
                ->setParameter('{{ expected_tag }}', $constraint->tag)
                ->setParameter('{{ actual_tag }}', implode(', ', $transaction->getTags()))
                ->addViolation();
        }
    }
}
