<?php

declare(strict_types=1);

namespace TransactionHandlers\Constraints;

use Symfony\Component\Validator\Constraint;

class HasSettlement extends Constraint
{
    public $message = 'Transaction not yet settled';

    public function getTargets()
    {
        return self::CLASS_CONSTRAINT;
    }
}
