<?php

declare(strict_types=1);

namespace TransactionHandlers\Constraints;

use Model_Banktransaction;
use Symfony\Component\Validator\Constraint;
use Symfony\Component\Validator\ConstraintValidator;
use Symfony\Component\Validator\Exception\UnexpectedTypeException;
use Webmozart\Assert\Assert;

class DoesntHaveAnyOfTagsValidator extends ConstraintValidator
{
    /**
     * @param Model_Banktransaction $transaction
     * @param HasAnyOfTags          $constraint
     */
    public function validate($transaction, Constraint $constraint)
    {
        if (!$constraint instanceof DoesntHaveAnyOfTags) {
            throw new UnexpectedTypeException($constraint, DoesntHaveAnyOfTags::class);
        }

        Assert::isInstanceOf($transaction, Model_Banktransaction::class);

        if (\count(array_intersect($constraint->tags_to_find, $transaction->getTags())) > 0) {
            $this->context->buildViolation($constraint->message)
                ->setParameter('{{ tags_to_find }}', implode(', ', $constraint->tags_to_find))
                ->setParameter('{{ actual_tags }}', implode(', ', $transaction->getTags()))
                ->addViolation();
        }
    }
}
