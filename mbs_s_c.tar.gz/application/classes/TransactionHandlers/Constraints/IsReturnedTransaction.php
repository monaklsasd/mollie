<?php

declare(strict_types=1);

namespace TransactionHandlers\Constraints;

use Symfony\Component\Validator\Constraint;

class IsReturnedTransaction extends Constraint
{
    public $message = 'Transaction is not a returned transaction.';

    public function getTargets()
    {
        return self::CLASS_CONSTRAINT;
    }
}
