<?php

declare(strict_types=1);

namespace TransactionHandlers\Exceptions;

class TransactionHandlerRuntimeException extends TransactionHandlerException
{
}
