<?php

declare(strict_types=1);

namespace TransactionHandlers\Exceptions;

class JobStatusMismatchException extends TransactionHandlerRuntimeException
{
}
