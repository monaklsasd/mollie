<?php

declare(strict_types=1);

namespace TransactionHandlers\Exceptions;

class StatementAlreadyRegistereredException extends TransactionHandlerRuntimeException
{
}
