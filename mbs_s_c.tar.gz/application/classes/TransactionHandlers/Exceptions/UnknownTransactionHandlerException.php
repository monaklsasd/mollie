<?php

declare(strict_types=1);

namespace TransactionHandlers\Exceptions;

class UnknownTransactionHandlerException extends TransactionHandlerException
{
}
