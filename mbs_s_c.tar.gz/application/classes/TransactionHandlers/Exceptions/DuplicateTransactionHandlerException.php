<?php

declare(strict_types=1);

namespace TransactionHandlers\Exceptions;

class DuplicateTransactionHandlerException extends TransactionHandlerException
{
}
