<?php

declare(strict_types=1);

namespace TransactionHandlers;

use DateTimeImmutable;

class TransactionHandlerJob
{
    /** @var int */
    protected $statement_import_id;

    /** @var string */
    protected $handler_class_name;

    /** @var Status */
    protected $status;

    /** @var int */
    protected $tries;

    /** @var DateTimeImmutable|null */
    protected $run_at;

    /** @var DateTimeImmutable|null */
    protected $started_at;

    /** @var DateTimeImmutable|null */
    protected $stopped_at;

    public function __construct(
        int $statement_import_id,
        string $handler_class_name,
        Status $status,
        int $tries,
        ?DateTimeImmutable $run_at,
        ?DateTimeImmutable $started_at,
        ?DateTimeImmutable $stopped_at
    ) {
        $this->statement_import_id = $statement_import_id;
        $this->handler_class_name  = $handler_class_name;
        $this->status              = $status;
        $this->tries               = $tries;
        $this->run_at              = $run_at;
        $this->started_at          = $started_at;
        $this->stopped_at          = $stopped_at;
    }

    public function getStatementImportId(): int
    {
        return $this->statement_import_id;
    }

    public function getHandlerClassName(): string
    {
        return $this->handler_class_name;
    }

    public function getStatus(): Status
    {
        return $this->status;
    }

    public function getTries(): int
    {
        return $this->tries;
    }

    public function getRunAt(): ?DateTimeImmutable
    {
        return $this->run_at;
    }

    public function getStartedAt(): ?DateTimeImmutable
    {
        return $this->started_at;
    }

    public function getStoppedAt(): ?DateTimeImmutable
    {
        return $this->stopped_at;
    }
}
