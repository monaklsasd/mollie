<?php

declare(strict_types=1);

namespace TransactionHandlers\Expanding;

use Core\Localization\Localizer;
use Helper\Database\TransactionCoordinator;
use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use Model_TransactionRegistration;
use Money\Money;
use Orm\ModelFactory;
use Supplier\Mccs\Amex\Settlement\Batch;
use Supplier\Mccs\Amex\Settlement\Settlement as AmexSettlement;
use Supplier\Mccs\Mccs;
use TransactionHandlers\Constraints\HasPositiveAmount;
use TransactionHandlers\Constraints\TagExactlyMatches;
use TransactionHandlers\Expanding\Exception\AmexSettlementInvalid;
use Validation\ValidatorFactory;
use function count;

/**
 * Expand creditcard batch transactions into separate transactions based on info from MCCS.
 */
class AmexBatchExpander extends BatchExpanderBase
{
    /** @var Mccs */
    protected $mccs;

    public function __construct(
        ValidatorFactory $validator_factory,
        TransactionCoordinator $transaction_coordinator,
        ModelFactory $model_factory,
        Mccs $mccs
    ) {
        parent::__construct($validator_factory, $transaction_coordinator, $model_factory);
        $this->mccs = $mccs;
    }

    public function getTransactionConstraints(): array
    {
        return array_merge(parent::getTransactionConstraints(), [
            new HasPositiveAmount(),
            new TagExactlyMatches(TransactionTags::TAG_AMEX_SETTLEMENT_NEW),
        ]);
    }

    protected function isExpandable(Model_Banktransaction $banktransaction): bool
    {
        return $banktransaction->isReceivedAmexSettlement();
    }

    /**
     * @throws AmexSettlementInvalid
     *
     * @return Model_Banktransaction[]
     */
    protected function expandTransaction(Model_Banktransaction $banktransaction_settlement): iterable
    {
        $this->setLastProcessedTransaction($banktransaction_settlement);
        // Create a new Model_Set for all transactions
        $transactions = [];

        /** @var AmexSettlement|null $amex_settlement */
        $amex_settlement = $this->mccs->getAmexSettlementDataByBanktransaction($banktransaction_settlement);

        // If data for one of the references are missing, just quit and try the entire batch again later.
        if (!$amex_settlement
            || (count($amex_settlement->getBatches()) === 0 && count($amex_settlement->getAdjustments()) === 0)
        ) {
            throw new AmexSettlementInvalid(sprintf(
                'Cannot find AMEX settlement for transaction #%d.',
                $banktransaction_settlement->getPrimaryKey()
            ));
        }

        // Verify whether this settlement actually makes sense, will throw an exception if any of the totals are off
        $this->verifySettlementTotals($banktransaction_settlement, $amex_settlement);

        /** @var Money $total_fees */
        $total_fees = Money::EUR(0);

        // Create transactions for all charges within the charge batches.
        foreach ($amex_settlement->getBatches() as $batch) {
            foreach ($this->createTransactionsFromBatch($banktransaction_settlement, $batch) as $child_transaction) {
                $transactions[] = $child_transaction;
            }

            $total_fees = $total_fees->add($batch->getTotalFeeAmount());
        }

        // Create a single transaction for all charge fees.
        if (!$total_fees->isZero()) {
            $fee_transaction = $this->createChildTransaction($banktransaction_settlement);

            $fee_transaction->setTags([TransactionTags::TAG_AMEX_FEE_VARIABLE]);

            $fee_transaction->setAmount($total_fees);
            $fee_transaction->setDescription('Variable fees for AMEX settlement');

            $transactions[] = $fee_transaction;
        }

        // Create transactions for each adjustment received (either a chargeback, an annual fee, or something similar).
        foreach ($amex_settlement->getAdjustments() as $adjustment) {
            $adjustment_transaction = $this->createChildTransaction($banktransaction_settlement);

            if ($adjustment->isAnnualFee()) {
                $adjustment_transaction->setTags([TransactionTags::TAG_AMEX_COSTS]);
            } elseif ($adjustment->isChargebackOrChargebackReversal()) {
                $adjustment_transaction->setTags([TransactionTags::TAG_AMEX_CHARGEBACK]);
            } else {
                $adjustment_transaction->setTags([TransactionTags::TAG_UNKNOWNAMEX]);
            }

            $adjustment_transaction->setAmount($adjustment->getNetAmount());
            $adjustment_transaction->setDescription($adjustment->getDescription());

            $adjustment_transaction->setTagData([
                'record_code' => $adjustment->getRecordCode(),
            ]);

            $transactions[] = $adjustment_transaction;
        }

        // We've expanded the settlement
        $banktransaction_settlement->setTags([TransactionTags::TAG_AMEX_SETTLEMENT_EXPANDED]);

        return $transactions;
    }

    /**
     * Create and return children transactions for the entire settlement, which will have the $banktransaction_parent
     * set as their parent
     *
     * @return Model_Banktransaction[]
     */
    protected function createTransactionsFromBatch(
        Model_Banktransaction $banktransaction_parent,
        Batch $batch
    ): array {
        $child_transactions = [];

        foreach ($batch->getCharges() as $charge) {
            $child_transaction = $this->createChildTransaction($banktransaction_parent);

            $child_transaction->setCustomerDate($charge->getDate());
            $child_transaction->setAmount($charge->getAmount());
            $child_transaction->setDescription($charge->getDescription());

            // With a mccs_transaction_id, we know we can match it to a payment or refund
            if (!empty($charge->getMccsTransactionId())) {
                if ($charge->getType() === 'payment') {
                    $child_transaction->setTags([TransactionTags::TAG_AMEX_PAYMENT]);
                } elseif ($charge->getType() === 'refund') {
                    $child_transaction->setTags([TransactionTags::TAG_AMEX_REFUND]);
                }
            } else {
                // Without one, we can't, so we record it as unknown
                $child_transaction->recordUnknown(
                    [TransactionTags::TAG_UNKNOWNAMEX],
                    Model_TransactionRegistration::REGISTRATION_UNKNOWN_AMEX
                );
            }

            $child_transaction->setTagData([
                'invoice_reference_id' => $charge->getInvoiceReferenceId(),
                'transaction_id'       => $charge->getMccsTransactionId(),
            ]);

            $child_transactions[] = $child_transaction;
        }

        return $child_transactions;
    }

    /**
     * These checks are also done at MCCS. MCCS should never be able to report an erroneous file. If this method throws
     * an exception, we should be worried.
     *
     * @throws AmexSettlementInvalid
     */
    protected function verifySettlementTotals(
        Model_Banktransaction $banktransaction_settlement,
        AmexSettlement $amex_settlement
    ): void {
        if (!$amex_settlement->getTotalNetAmount()->equals(
            $amex_settlement->getTotalGrossAmount()
                ->add($amex_settlement->getTotalFeeAmount())
                ->add($amex_settlement->getTotalChargebackAmount())
        )) {
            throw new AmexSettlementInvalid(sprintf(
                'The file net amount %s does not match the gross amount %s, fee amount %s and adjustment amount %s in bank transaction #%d.',
                Localizer::formatMoney($amex_settlement->getTotalNetAmount()),
                Localizer::formatMoney($amex_settlement->getTotalGrossAmount()),
                Localizer::formatMoney($amex_settlement->getTotalFeeAmount()),
                Localizer::formatMoney($amex_settlement->getTotalChargebackAmount()),
                $banktransaction_settlement->getPrimaryKey()
            ));
        }

        /** @var Money */
        $total_batch_net_amount = Money::EUR(0);
        /** @var Money $total_batch_gross_amount */
        $total_batch_gross_amount = Money::EUR(0);
        /** @var Money $total_batch_fee_amount */
        $total_batch_fee_amount = Money::EUR(0);

        foreach ($amex_settlement->getBatches() as $charge_batch) {
            if (!$charge_batch->getTotalGrossCalculatedAmount()->equals($charge_batch->getTotalGrossDeclaredAmount())) {
                throw new AmexSettlementInvalid(sprintf(
                    'The calculated gross amount %s does not match the declared gross amount %s of one of the batches of bank transaction #%d.',
                    Localizer::formatMoney($charge_batch->getTotalGrossCalculatedAmount()),
                    Localizer::formatMoney($charge_batch->getTotalGrossDeclaredAmount()),
                    $banktransaction_settlement->getPrimaryKey()
                ));
            }

            if (!$charge_batch->getTotalNetAmount()->equals(
                $charge_batch->getTotalGrossCalculatedAmount()->add($charge_batch->getTotalFeeAmount())
            )) {
                throw new AmexSettlementInvalid(sprintf(
                    'The charge batch net amount %s does not match the gross amount %s and fee amount %s of one of the batches of bank transaction #%d.',
                    Localizer::formatMoney($charge_batch->getTotalNetAmount()),
                    Localizer::formatMoney($charge_batch->getTotalGrossCalculatedAmount()),
                    Localizer::formatMoney($charge_batch->getTotalFeeAmount()),
                    $banktransaction_settlement->getPrimaryKey()
                ));
            }

            $total_batch_net_amount   = $total_batch_net_amount->add($charge_batch->getTotalNetAmount());
            $total_batch_gross_amount = $total_batch_gross_amount->add($charge_batch->getTotalGrossCalculatedAmount());
            $total_batch_fee_amount   = $total_batch_fee_amount->add($charge_batch->getTotalFeeAmount());
        }

        if (!$amex_settlement->getTotalNetAmount()->equals(
            $total_batch_net_amount->add($amex_settlement->getTotalChargebackAmount())
        )) {
            throw new AmexSettlementInvalid(sprintf(
                'The file net amount %s does not match the net amount %s of its batches in bank transaction #%d.',
                Localizer::formatMoney($amex_settlement->getTotalNetAmount()),
                Localizer::formatMoney($total_batch_net_amount),
                $banktransaction_settlement->getPrimaryKey()
            ));
        }

        if (!$amex_settlement->getTotalGrossAmount()->equals($total_batch_gross_amount)) {
            throw new AmexSettlementInvalid(sprintf(
                'The file gross amount %s does not match the gross amount %s of its batches in bank transaction #%d.',
                Localizer::formatMoney($amex_settlement->getTotalGrossAmount()),
                Localizer::formatMoney($total_batch_gross_amount),
                $banktransaction_settlement->getPrimaryKey()
            ));
        }

        /*
         * This exception will never occur, since a wrong fee will have triggered the net=gross+fee check, the
         * file_gross=sum(batch_gross) check, or the file_net=sum(batch_net) check. The piece of code is here strictly
         * for OCD reasons.
         */
        if (!$amex_settlement->getTotalFeeAmount()->equals($total_batch_fee_amount)) {
            throw new AmexSettlementInvalid(sprintf(
                'The file fee amount %s does not match the fee amount %s of its batches in bank transaction #%d.',
                Localizer::formatMoney($amex_settlement->getTotalFeeAmount()),
                Localizer::formatMoney($total_batch_fee_amount),
                $banktransaction_settlement->getPrimaryKey()
            ));
        }

        /** @var Money $total_chargeback_amount */
        $total_chargeback_amount = Money::EUR(0);

        foreach ($amex_settlement->getAdjustments() as $adjustment) {
            $adjustment_record_valid = false;

            if ($adjustment->getNetAmount()->equals($adjustment->getGrossAmount()->add($adjustment->getFeeAmount()))) {
                $adjustment_record_valid = true;
            }
            // Some records may have the exact same net, gross, and fee amounts. This is obviously erroneous, but we'll
            // let it slide.
            elseif ($adjustment->getNetAmount()->equals($adjustment->getGrossAmount())
                && $adjustment->getNetAmount()->equals($adjustment->getFeeAmount())
            ) {
                $adjustment_record_valid = true;
            }

            if (!$adjustment_record_valid) {
                throw new AmexSettlementInvalid(sprintf(
                    'The adjustment net amount %s does not match the gross amount %s and fee amount %s in bank transaction #%d.',
                    Localizer::formatMoney($adjustment->getNetAmount()),
                    Localizer::formatMoney($adjustment->getGrossAmount()),
                    Localizer::formatMoney($adjustment->getFeeAmount()),
                    $banktransaction_settlement->getPrimaryKey()
                ));
            }

            $total_chargeback_amount = $total_chargeback_amount->add($adjustment->getNetAmount());
        }

        if (!$amex_settlement->getTotalChargebackAmount()->equals($total_chargeback_amount)) {
            throw new AmexSettlementInvalid(sprintf(
                'The file total adjustment amount %s does not match the net amount %s of the adjustments of bank transaction #%d.',
                Localizer::formatMoney($amex_settlement->getTotalChargebackAmount()),
                Localizer::formatMoney($total_chargeback_amount),
                $banktransaction_settlement->getPrimaryKey()
            ));
        }
    }
}
