<?php

declare(strict_types=1);

namespace TransactionHandlers\Expanding\Exception;

use TransactionHandlers\Exceptions\TransactionHandlerRuntimeException;

class InvalidBatchException extends TransactionHandlerRuntimeException
{
}
