<?php

declare(strict_types=1);

namespace TransactionHandlers\Expanding\Exception;

class AmexSettlementInvalid extends InvalidSettlementException
{
}
