<?php

declare(strict_types=1);

namespace TransactionHandlers\Expanding;

use Helper_Banktransaction_Matching;
use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use Mollie\BankingFiles\Batch\BatchTransaction;

/**
 * Expand SEPA direct debit batch transactions.
 */
class DirectDebitBatchExpander extends SepaBatchExpander
{
    protected function buildBanktransaction(
        Model_Banktransaction $batch_transaction,
        BatchTransaction $child_transaction
    ): Model_Banktransaction {
        $transaction = $this->createChildTransaction($batch_transaction);
        $this->setLastProcessedTransaction($transaction);

        /* Now copy specifics from the transaction IN the batch */
        $transaction->setAmount($child_transaction->getAmount()->negative());
        $transaction->setDescription($child_transaction->getDescription());
        $transaction->setOffsetAccountNumber($child_transaction->getDebtorBankaccount());
        $transaction->setOffsetAccountName($child_transaction->getDebtorName());
        $transaction->setOffsetAccountBic(null); // BIC is only known in CAMT.053 file

        /* Add the directdebit tag */
        $transaction->setTags([TransactionTags::TAG_DIRECTDEBIT]);

        /*
         * Parse DirectDebits's reference.
         */
        $transaction_id = Helper_Banktransaction_Matching::get_directdebit_sd(
            $child_transaction->getReference()
        );

        if ($transaction_id !== null) {
            $transaction->setTagData(['transaction_id' => $transaction_id]);
        }

        return $transaction;
    }
}
