<?php

declare(strict_types=1);

namespace TransactionHandlers\Expanding;

use Helper_Banktransaction_Matching;
use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use Mollie\BankingFiles\Batch\BatchTransaction;

class RefundsBatchExpander extends SepaBatchExpander
{
    protected function expandTransaction(Model_Banktransaction $batch_transaction): iterable
    {
        $child_transactions = parent::expandTransaction($batch_transaction);
        $batch_transaction->addTag(TransactionTags::TAG_REFUNDS);

        return $child_transactions;
    }

    protected function buildBanktransaction(
        Model_Banktransaction $batch_transaction,
        BatchTransaction $child_transaction
    ): Model_Banktransaction {
        $this->setLastProcessedTransaction($batch_transaction);
        $banktransaction = parent::buildBanktransaction($batch_transaction, $child_transaction);

        $refund_transaction_id = Helper_Banktransaction_Matching::getRefundPaymentId(
            (string)$child_transaction->getDescription()
        );

        if ($refund_transaction_id !== null) {
            $banktransaction->addTag(TransactionTags::TAG_REFUNDS);
            $banktransaction->addTagData([
                'transaction_id' => $refund_transaction_id,
            ]);
        } else {
            $banktransaction->addTag(TransactionTags::TAG_UNKNOWNREFUND);
        }

        return $banktransaction;
    }
}
