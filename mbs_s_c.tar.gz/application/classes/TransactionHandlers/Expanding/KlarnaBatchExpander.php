<?php

declare(strict_types=1);

namespace TransactionHandlers\Expanding;

use App\Entity\Supplier\Klarna\Capture;
use App\Entity\Supplier\Klarna\Payout;
use App\Repository\Supplier\Klarna\PayoutRepository;
use Core\Localization\Localizer;
use Helper\Database\TransactionCoordinator;
use Helper\DateTime\Utc;
use InvalidArgumentException;
use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use Model_Set;
use Money\Money;
use Orm\ModelFactory;
use Supplier\Klarna\Payout\Response\PayoutTransactionType;
use TransactionHandlers\Constraints\HasAnyOfTags;
use TransactionHandlers\Expanding\Exception\InvalidBatchException;
use TransactionHandlers\Expanding\Exception\InvalidSettlementException;
use Validation\ValidatorFactory;
use function array_key_exists;
use function Core\Money\money_to_string;

class KlarnaBatchExpander extends BatchExpanderBase
{
    use Utc;

    /** @var PayoutRepository */
    private $payout_repository;

    public function __construct(
        ValidatorFactory $validator_factory,
        TransactionCoordinator $transaction_coordinator,
        ModelFactory $model_factory,
        PayoutRepository $payout_repository
    ) {
        parent::__construct($validator_factory, $transaction_coordinator, $model_factory);

        $this->payout_repository = $payout_repository;
    }

    public function getRetryDelay(): int
    {
        // Seems to only fail when payouts come in too late. Increase delay to give the payouts bit more time to arrive.
        return 3600 * 5;
    }

    protected function getTransactionConstraints(): array
    {
        return array_merge(
            parent::getTransactionConstraints(),
            [new HasAnyOfTags([TransactionTags::TAG_KLARNA_SETTLEMENT])]
        );
    }

    protected function isExpandable(Model_Banktransaction $banktransaction): bool
    {
        if (!$banktransaction->hasTag(TransactionTags::TAG_KLARNA_SETTLEMENT)) {
            return false;
        }

        /** @var string|null $reference */
        $reference = $banktransaction->getTagData()['payout_reference'] ?? null;

        if ($reference === null) {
            throw new InvalidSettlementException(sprintf(
                'No payout reference could be found in batch transaction: #%d',
                $banktransaction->getPrimaryKey()
            ));
        }

        return $this->payout_repository->findByReference($reference) !== null;
    }

    protected function expandTransaction(Model_Banktransaction $batch_transaction): iterable
    {
        $this->setLastProcessedTransaction($batch_transaction);
        $child_transactions = new Model_Set();
        $payout             = $this->payout_repository->getByReference(
            $batch_transaction->getTagData()['payout_reference']
        );

        if ($rolling_reserve_transaction = $this->createRollingReserveTransaction($batch_transaction, $payout)) {
            $child_transactions->append($rolling_reserve_transaction);

            $this->logger->error(sprintf(
                'We received rolling reserve amounts for Klarna Payout %s (Batch transaction #%d). According to our agreement we should never receive these.',
                $payout->getReference(),
                $batch_transaction->getPrimaryKey()
            ), $rolling_reserve_transaction->getTagData());
        }

        foreach ($payout->getCaptures() as $capture) {
            $transaction = $this->transformCaptureToTransaction($batch_transaction, $capture);
            $child_transactions->append($transaction);
        }

        self::mergeFeeTransactions($child_transactions);
        self::mergeReversalTransactions($child_transactions);

        if ($tax_transaction = $this->createTaxTransaction($batch_transaction, $payout)) {
            $child_transactions->append($tax_transaction);

            $this->logger->error(sprintf(
                'We were charged tax for Klarna Payout %s (Batch transaction #%d). According to our agreement we should never receive these.',
                $payout->getReference(),
                $batch_transaction->getPrimaryKey()
            ), $tax_transaction->getTagData());
        }

        $this->assertSumOfChildTransactionsMatchBatchSum($batch_transaction, $child_transactions);

        $batch_transaction->setTags([TransactionTags::TAG_KLARNA_SETTLEMENT_EXPANDED]);

        return $child_transactions;
    }

    /**
     * The method modifies the supplied Model_Set and transactions in it. Fee records for the same capture will be
     * merged.
     *
     * @param Model_Banktransaction[]|Model_Set $transactions
     */
    protected static function mergeFeeTransactions(Model_Set $transactions): void
    {
        /** @var Model_Banktransaction[] $fee_transaction_map */
        $fee_transaction_map = [];

        foreach ($transactions as $transaction) {
            if (!$transaction->hasTag(TransactionTags::TAG_KLARNA_FEE)) {
                continue;
            }

            $capture_id = $transaction->getTagData()['transaction_id'];

            if (!array_key_exists($capture_id, $fee_transaction_map)) {
                $fee_transaction_map[$capture_id] = $transaction;

                continue;
            }

            // Add amount to earlier found fee transaction
            $summed_amount = $fee_transaction_map[$capture_id]->getAmount()->add($transaction->getAmount());
            $fee_transaction_map[$capture_id]->setAmount($summed_amount);

            $new_fee_count = $fee_transaction_map[$capture_id]->getTagData()['aggregated_fee_count'] + $transaction->getTagData()['aggregated_fee_count'];
            $fee_transaction_map[$capture_id]->addTagData(['aggregated_fee_count' => $new_fee_count]);

            //remove 'extra' transaction from set.
            $transactions->filter(function ($t) use ($transaction) {
                return $t !== $transaction;
            });
        }
    }

    /**
     * The method modifies the supplied Model_Set and transactions in it. reversal records with the same refund id will be
     * merged.
     *
     * @param Model_Banktransaction[]|Model_Set $transactions
     */
    protected static function mergeReversalTransactions(Model_Set $transactions): void
    {
        /** @var Model_Banktransaction[] $reversal_transaction_map */
        $reversal_transaction_map = [];

        foreach ($transactions as $transaction) {
            if (!$transaction->hasTag(TransactionTags::TAG_KLARNA_CHARGEBACK)) {
                continue;
            }

            $refund_id = $transaction->getTagData()['transaction_id'];

            if (!array_key_exists($refund_id, $reversal_transaction_map)) {
                $reversal_transaction_map[$refund_id] = $transaction;

                continue;
            }

            // Add amount to earlier found reversal transaction
            $summed_amount = $reversal_transaction_map[$refund_id]->getAmount()->add($transaction->getAmount());
            $reversal_transaction_map[$refund_id]->setAmount($summed_amount);

            $new_fee_count = $reversal_transaction_map[$refund_id]->getTagData()['aggregated_reversal_count'] + $transaction->getTagData()['aggregated_reversal_count'];
            $reversal_transaction_map[$refund_id]->addTagData(['aggregated_reversal_count' => $new_fee_count]);

            // Remove 'extra' transaction from set.
            $transactions->filter(function (Model_Banktransaction $t) use ($transaction): bool {
                return $t !== $transaction;
            });
        }
    }

    protected function createRollingReserveTransaction(
        Model_Banktransaction $batch_transaction,
        Payout $payout
    ): ?Model_Banktransaction {
        $amount = $payout->getReleaseAmount()
            ->subtract($payout->getHoldbackAmount())
            ->subtract($payout->getRepayAmount());

        if ($amount->isZero()) {
            return null;
        }

        $transaction = $this->createChildTransaction($batch_transaction);
        $transaction->setDescription('Rolling Reserve');
        $transaction->setCustomerDate($payout->getDate());
        $transaction->setAmount($amount);
        $transaction->addTag(TransactionTags::TAG_KLARNA_ROLLING_RESERVE);
        $transaction->setTagData([
            'currency' => $payout->getCurrency()->getCode(),
            'holdback' => money_to_string($payout->getHoldbackAmount()),
            'repay'    => money_to_string($payout->getRepayAmount()),
            'release'  => money_to_string($payout->getReleaseAmount()),
        ]);

        return $transaction;
    }

    protected function createTaxTransaction(
        Model_Banktransaction $batch_transaction,
        Payout $payout
    ): ?Model_Banktransaction {
        $amount = $payout->getTaxAmount();

        if ($amount->isZero()) {
            return null;
        }

        $transaction = $this->createChildTransaction($batch_transaction);
        $transaction->setDescription('Tax (Swedish merchant)');
        $transaction->setCustomerDate($payout->getDate());
        $transaction->setAmount($amount->negative());
        $transaction->addTag(TransactionTags::TAG_KLARNA_FEE_DIFFERENCE);

        return $transaction;
    }

    private function transformCaptureToTransaction(
        Model_Banktransaction $batch_transaction,
        Capture $capture
    ): Model_Banktransaction {
        $transaction = $this->createChildTransaction($batch_transaction);
        $transaction->setCustomerDate($capture->getCaptureAtUtc());
        $transaction->setAmount($capture->getAmount());
        $transaction->addTag(self::getTransactionTypeTagForCapture($capture));
        $transaction->setTagData([
            'payment_currency'    => $capture->getCurrency()->getCode(),
            'consumer_country'    => $capture->getPurchaseCountry(),
            'merchant_reference1' => $capture->getMerchantReference1(),
            'merchant_reference2' => $capture->getMerchantReference2(),
            'transaction_id'      => $capture->getTransactionId(),
            'order_id'            => $capture->getOrderId(),
        ]);

        if ($capture->getType()->equals(PayoutTransactionType::FEE())) {
            $transaction->addTagData(['aggregated_fee_count' => 1]);
        }

        if ($capture->getType()->equals(PayoutTransactionType::REVERSAL())
            || $capture->getType()->equals(PayoutTransactionType::REVERSAL_MERCHANT_PROTECTION())
        ) {
            $transaction->addTagData(['aggregated_reversal_count' => 1]);
        }

        $transaction->setDescription(self::getDescriptionForCapture($capture));

        return $transaction;
    }

    private static function getTransactionTypeTagForCapture(
        Capture $capture
    ): string {
        if ($capture->getType()->equals(PayoutTransactionType::FEE())) {
            foreach ($capture->getPayout()->getCaptures() as $related_capture) {
                if ($related_capture->getType()->equals(PayoutTransactionType::SALE())
                    && $related_capture->getTransactionId() === $capture->getTransactionId()
                ) {
                    return TransactionTags::TAG_KLARNA_FEE;
                }
            }

            return TransactionTags::TAG_KLARNA_FEE_DELAYED;
        }

        if ($capture->getType()->equals(PayoutTransactionType::SALE())) {
            return TransactionTags::TAG_KLARNA;
        }

        if ($capture->getType()->equals(PayoutTransactionType::RETURN())) {
            return TransactionTags::TAG_KLARNA_REFUND;
        }

        if ($capture->getType()->equals(PayoutTransactionType::REVERSAL())
            || $capture->getType()->equals(PayoutTransactionType::REVERSAL_MERCHANT_PROTECTION())
        ) {
            return TransactionTags::TAG_KLARNA_CHARGEBACK;
        }

        if ($capture->getType()->equals(PayoutTransactionType::COMMISSION())) {
            return TransactionTags::TAG_KLARNA_FEE;
        }

        if ($capture->getType()->equals(PayoutTransactionType::CORRECTION())) {
            return Model_Banktransaction::TAG_KLARNA_CORRECTION;
        }

        throw new InvalidBatchException(sprintf(
            'No payment type tag defined for capture type: %s',
            $capture->getType()->getValue()
        ));
    }

    private static function getDescriptionForCapture(Capture $capture): string
    {
        return trim(sprintf(
            '%s %s',
            ucfirst(strtolower($capture->getType()->getValue())),
            implode(' / ', array_filter([
                $capture->getTransactionId(),
                $capture->getFullMerchantReference(),
            ]))
        ));
    }

    /**
     * @throws InvalidArgumentException
     */
    private function assertSumOfChildTransactionsMatchBatchSum(
        Model_Banktransaction $batch_transaction,
        Model_Set $child_transactions
    ): void {
        $child_transactions_sum = $child_transactions->reduce(function (Money $sum, Model_Banktransaction $child_transaction) {
            return $sum->add($child_transaction->getAmount());
        }, Money::EUR(0));

        if (!$child_transactions_sum->equals($batch_transaction->getAmount())) {
            throw new InvalidArgumentException(sprintf(
                'Expected the sum of the child transaction of Klarna batch transaction #%d to match the batch amount. Sum is %s, batch amount is %s.',
                $batch_transaction->getPrimaryKey(),
                Localizer::formatMoney($child_transactions_sum),
                Localizer::formatMoney($batch_transaction->getAmount())
            ));
        }
    }
}
