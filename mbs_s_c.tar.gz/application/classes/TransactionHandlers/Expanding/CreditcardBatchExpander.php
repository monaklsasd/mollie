<?php

declare(strict_types=1);

namespace TransactionHandlers\Expanding;

use Core\Money\Currencies;
use Generator;
use Helper\Database\TransactionCoordinator;
use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use Model_Exception;
use Model_TransactionRegistration;
use Money\Money;
use Orm\ModelFactory;
use Supplier\Mccs\Mccs;
use Supplier\Mccs\MccsException;
use Supplier\Mccs\PaymentProviderType;
use Supplier\Mccs\Valitor\Settlement\Detail as ValitorSettlementDetail;
use Supplier\Mccs\Valitor\Settlement\Settlement;
use Supplier\Mccs\Valitor\Settlement\Settlement as ValitorSettlement;
use TransactionHandlers\Constraints\HasPositiveAmount;
use TransactionHandlers\Constraints\TagExactlyMatches;
use TransactionHandlers\Expanding\Exception\InvalidSettlementException;
use Validation\ValidatorFactory;
use function Core\Money\money_to_string;

/**
 * Expand creditcard batch transactions into separate transactions based on info from MCCS.
 */
class CreditcardBatchExpander extends BatchExpanderBase
{
    private const DETAIL_KEYS_TO_EXPAND = [
        ValitorSettlementDetail::DETAIL_KEY_SALE,
        ValitorSettlementDetail::DETAIL_KEY_REFUND,
        ValitorSettlementDetail::DETAIL_KEY_CHARGEBACK,
    ];

    protected $mccs;

    public function __construct(
        ValidatorFactory $validator_factory,
        TransactionCoordinator $transaction_coordinator,
        ModelFactory $model_factory,
        Mccs $mccs
    ) {
        parent::__construct($validator_factory, $transaction_coordinator, $model_factory);
        $this->mccs = $mccs;
    }

    public function getTransactionConstraints(): array
    {
        return array_merge(parent::getTransactionConstraints(), [
            new HasPositiveAmount(),
            new TagExactlyMatches(TransactionTags::TAG_VALITOR_SETTLEMENT_UNSPECIFIED),
        ]);
    }

    protected function isExpandable(Model_Banktransaction $banktransaction): bool
    {
        return $banktransaction->isReceivedValitorSettlement();
    }

    protected function expandTransaction(Model_Banktransaction $batch_transaction): iterable
    {
        $this->setLastProcessedTransaction($batch_transaction);
        $tag_data = $this->getTagData($batch_transaction);

        /** @var Settlement[] $settlements */
        $settlements = [];
        /** @var Money[] $settlement_detail_totals */
        $settlement_detail_totals = [];
        /** @var Money[] $settlement_transaction_totals */
        $settlement_transaction_totals  = [];
        $banktransactions               = [];
        $accumulated_settlement_details = [];
        $settlement_total               = Money::EUR('0');

        foreach ($tag_data['settlement_numbers'] as $settlement_number) {
            $settlement_details = $this->getSettlementInfo($settlement_number, PaymentProviderType::Valitor());
            $settlements[]      = $settlement_details;

            foreach ($settlement_details->getDetails() as $detail) {
                $current_key_total                                     = $settlement_detail_totals[$detail->getSettlementKey()] ?? new Money(0, $detail->getAmount()->getCurrency());
                $settlement_detail_totals[$detail->getSettlementKey()] = $current_key_total->add($detail->getAmount());
            }

            foreach ($settlement_details->getTransactions() as $transaction) {
                $current_key_total                                      = $settlement_transaction_totals[$transaction->getCode()] ?? new Money(0, $transaction->getAmount()->getCurrency());
                $settlement_transaction_totals[$transaction->getCode()] = $current_key_total->add($transaction->getAmount());
            }
        }

        $total_category_diff = self::calculateDifferenceBetweenTransactionAndDetailTotalAmount($settlement_transaction_totals, $settlement_detail_totals);

        if (!$total_category_diff->isZero()) {
            throw new InvalidSettlementException(sprintf("Received different transactions and details amounts from MCCS: %s", money_to_string($total_category_diff)));
        }

        foreach ($settlements as $settlement_details) {
            $settlement_total                 = $this->increaseSettlementTotal($settlement_details, $settlement_total);
            $accumulated_settlement_details[] = $this->createSettlementDetail($settlement_details);
            $banktransactions_from_settlement = $this->getBanktransactionsFromSettlementDetails($batch_transaction, $settlement_details);
            $banktransactions                 = array_merge($banktransactions, $banktransactions_from_settlement);
        }

        $settlement_difference_transaction = $this->createTransactionToReflectTheDifferenceBetweenReceivedAmountAndValitorSpec($batch_transaction, $settlement_total);

        if ($settlement_difference_transaction) {
            $banktransactions[] = $settlement_difference_transaction;
        }

        $tag_data['settlement_details'] = $accumulated_settlement_details;

        $this->updateTagsOnBatchTransaction($batch_transaction, $tag_data);

        return $banktransactions;
    }

    /**
     * Calculate the difference between total transactions amount and total details amount from settlement.
     */
    private static function calculateDifferenceBetweenTransactionAndDetailTotalAmount(array $settlement_transaction_totals, array $settlement_detail_totals): Money
    {
        $total_category_diff = new Money(0, Currencies::EUR());

        foreach ($settlement_transaction_totals as $settlement_transaction_code => $amount) {
            if (!isset($settlement_detail_totals[$settlement_transaction_code])) {
                throw new InvalidSettlementException("Received invalid settlement data from MCCS");
            }

            $settlement_detail_amount = $settlement_detail_totals[$settlement_transaction_code];

            if (!$amount->equals($settlement_detail_amount)) {
                $diff                = $amount->subtract($settlement_detail_amount);
                $total_category_diff = $total_category_diff->add($diff);
            }
        }

        return $total_category_diff;
    }

    /**
     * Calculate the sum of all detail amounts.
     */
    private function calculateSettlementTotal(ValitorSettlement $settlement_details): Money
    {
        return array_reduce(
            $settlement_details->getDetails(),
            function (Money $current_amount, ValitorSettlementDetail $detail) {
                return $current_amount->add($detail->getAmount());
            },
            Money::EUR('0')
        );
    }

    /**
     * Create a subtransaction, based on the batch transaction and a Valitor details object.
     *
     * @throws InvalidSettlementException
     *
     * @return iterable|Model_Banktransaction[]
     */
    protected function createBanktransactionsFromSettlementDetails(
        Model_Banktransaction $batch_transaction,
        ValitorSettlement $settlement_details
    ): iterable {
        $child_transactions = [];

        /** @var Model_Banktransaction[] $duplicate_transactions */
        $duplicate_transactions = $this->model_factory->yieldAll(
            Model_Banktransaction::class,
            [
                'parent_id' => $batch_transaction->id,
                'tag_data'  => ['!=', null],
            ]
        );

        $duplicate_mccs_transaction_ids = [];

        if ($duplicate_transactions instanceof Generator) {
            foreach ($duplicate_transactions as $duplicate_transaction) {
                if ($duplicate_transaction->hasTag(TransactionTags::TAG_VALITOR_DETAIL)) {
                    $this->logger->debug('Skipping duplicate transaction because it\'s a valitor_detail.');

                    continue;
                }

                $duplicate_mccs_transaction_ids[$duplicate_transaction->getTagData()['transaction_id']] = true;
            }
        }

        // Create a transaction for each expanded category.
        foreach ($settlement_details->getTransactions() as $transaction_details) {
            // Note transactions use the 'code' field for the settlement key, unlike the settlement category details.
            if (!in_array($transaction_details->getCode(), self::DETAIL_KEYS_TO_EXPAND, true)) {
                $this->logger->debug('Skipping transaction because it\'s not in the detail keys to expand.');

                continue;
            }

            // We don't want to recreate already created transactions
            if (array_key_exists($transaction_details->getMccsTransactionId(), $duplicate_mccs_transaction_ids)) {
                $this->logger->debug(sprintf(
                    'Skipping transaction because it\'s a duplicate: %s.',
                    $transaction_details->getMccsTransactionId()
                ));

                continue;
            }

            $child_transaction = $this->createChildTransaction($batch_transaction);

            $child_transaction->setCustomerDate($transaction_details->getDate()); // Payment date
            $child_transaction->setAmount($transaction_details->getAmount());
            $child_transaction->setOffsetAccountName($transaction_details->getCardHolder());
            $child_transaction->setDescription($transaction_details->getDescription());

            if (empty($transaction_details->getMccsTransactionId())) {
                throw new InvalidSettlementException("Received missing settlement information from MCCS");
            }

            switch ($transaction_details->getCode()) {
                case ValitorSettlementDetail::DETAIL_KEY_REFUND:
                    $tag = TransactionTags::TAG_CREDITCARD_REFUND;

                    break;

                case ValitorSettlementDetail::DETAIL_KEY_CHARGEBACK:
                    $tag = TransactionTags::TAG_VALITOR_CHARGEBACK;

                    break;

                case ValitorSettlementDetail::DETAIL_KEY_SALE:
                default:
                    $tag = TransactionTags::TAG_CREDITCARD;

                    break;
            }

            $child_transaction->addTag($tag);
            $child_transaction->setTagData(['transaction_id' => $transaction_details->getMccsTransactionId()]);

            $child_transactions[] = $child_transaction;
        }

        /** @var Model_Banktransaction[] $category_transactions */
        $category_transactions = [];

        // Create a single transaction for each non-expanded category.
        foreach ($settlement_details->getDetails() as $category_details) {
            if (count($duplicate_mccs_transaction_ids) > 0) {
                // Details should already exist for a previously expanded batch.
                $this->logger->debug('Skipping details completely because batch was previously expanded.');

                break;
            }

            $category_key = $category_details->getSettlementKey();

            if (\in_array($category_key, self::DETAIL_KEYS_TO_EXPAND, true)) {
                // Already expanded, don't create a child transaction twice.
                $this->logger->debug('Skipping detail because it\'s in the detail keys to expand.');

                continue;
            }

            // Multiple rules may exist for a single key. Group their amounts into a single transaction.
            if (!isset($category_transactions[$category_key])) {
                $child_transaction = $this->createChildTransaction($batch_transaction);

                $description = sprintf('Valitor %s', $category_key);

                if (mb_strlen($category_details->getComment()) > 0) {
                    $description .= sprintf(' (%s)', $category_details->getComment());
                }

                $child_transaction->setAmount($category_details->getAmount());
                $child_transaction->setDescription($description);

                // Record as unknown
                if (\in_array($category_key, ValitorSettlementDetail::RECORD_AS_UNKNOWN, true)) {
                    $child_transaction->recordUnknown(
                        [TransactionTags::TAG_UNKNOWNCREDITCARD],
                        Model_TransactionRegistration::REGISTRATION_UNKNOWN_CREDITCARD
                    );
                }

                // Use addTag so unknown transaction will also get this tag
                $child_transaction->addTag(TransactionTags::TAG_VALITOR_DETAIL);

                $child_transaction->setTagData(['settlement_key' => $category_key]);

                $category_transactions[$category_key] = $child_transaction;
            } else {
                $category_transactions[$category_key]->setAmount(
                    $category_transactions[$category_key]->getAmount()->add($category_details->getAmount())
                );
            }
        }

        return array_merge($child_transactions, $category_transactions);
    }

    /**
     * @throws InvalidSettlementException
     */
    private function getSettlementInfo(
        string $settlement_number,
        PaymentProviderType $payment_provider
    ): ValitorSettlement {
        try {
            $details = $this->mccs->getSettlementDetails($settlement_number, $payment_provider);
        } catch (MccsException $e) {
            throw new InvalidSettlementException(
                'Could not retrieve settlement details #' .
                $settlement_number,
                0,
                $e
            );
        }

        // If details for one of the subtransactions are missing, just quit and try the entire batch again later.
        if (!$details) {
            throw new InvalidSettlementException('Details for one of the subtransactions are missing');
        }

        return $details;
    }

    /**
     * @throws InvalidSettlementException
     * @throws Model_Exception
     *
     * @return string[]
     */
    private function getTagData(Model_Banktransaction $batch_transaction): array
    {
        $tag_data = $batch_transaction->getTagData();

        if (empty($tag_data['settlement_numbers'])) {
            throw new InvalidSettlementException('No settlement numbers found');
        }

        return $tag_data;
    }

    /**
     * Do not use $details->amount reported by Valitor. It does not contain the detail line ADDEDS for example.
     *
     * @see https://redmine.mollie.nl/issues/19158#note-11
     */
    private function increaseSettlementTotal(ValitorSettlement $details, Money $settlement_total): Money
    {
        return $settlement_total->add($this->calculateSettlementTotal($details));
    }

    private function createSettlementDetail(ValitorSettlement $settlement_detail): array
    {
        return [
            'amount'  => (float)money_to_string($settlement_detail->getAmount()),
            'details' => $settlement_detail->getDetails(),
        ];
    }

    /**
     * @throws InvalidSettlementException
     * @throws Model_Exception
     */
    private function getBanktransactionsFromSettlementDetails(
        Model_Banktransaction $batch_transaction,
        ValitorSettlement $settlement_details
    ): array {
        $banktransactions = [];

        foreach ($this->createBanktransactionsFromSettlementDetails($batch_transaction, $settlement_details) as $transaction) {
            $banktransactions[] = $transaction;
        }

        return $banktransactions;
    }

    private function isThereDifferenceBetweenReceivedAmountAndValitorSpec(
        Model_Banktransaction $batch_transaction,
        Money $settlement_total
    ): Money {
        return $batch_transaction->getAmount()->subtract($settlement_total);
    }

    private function createTransactionToReflectTheDifferenceBetweenReceivedAmountAndValitorSpec(
        Model_Banktransaction $batch_transaction,
        Money $settlement_total
    ): ?Model_Banktransaction {
        $difference = $this->isThereDifferenceBetweenReceivedAmountAndValitorSpec($batch_transaction, $settlement_total);

        if ($difference->isZero()) {
            return null;
        }

        $child_transaction = $this->createChildTransaction($batch_transaction);
        $child_transaction->setAmount($difference);
        $child_transaction->setDescription('Valitor: difference due to mismatch between settlement and amount on bank account.');
        $child_transaction->setTags([TransactionTags::TAG_VALITOR_DETAIL]);

        return $child_transaction;
    }

    private function updateTagsOnBatchTransaction(Model_Banktransaction $batch_transaction, array $tag_data): void
    {
        $batch_transaction->setTags([TransactionTags::TAG_VALITOR_SETTLEMENT]); // Clears 'unspecified' tag.
        $batch_transaction->setTagData($tag_data);
    }
}
