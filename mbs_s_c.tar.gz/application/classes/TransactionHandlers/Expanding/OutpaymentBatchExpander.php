<?php

declare(strict_types=1);

namespace TransactionHandlers\Expanding;

use Helper_Banktransaction_Matching;
use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use Model_TransactionRegistration;
use Mollie\BankingFiles\Batch\BatchTransaction;

class OutpaymentBatchExpander extends SepaBatchExpander
{
    protected function buildBanktransaction(
        Model_Banktransaction $batch_transaction,
        BatchTransaction $statement_child_transaction
    ): Model_Banktransaction {
        $this->setLastProcessedTransaction($batch_transaction);
        $transaction = parent::buildBanktransaction($batch_transaction, $statement_child_transaction);

        if ($reference = Helper_Banktransaction_Matching::getOutpaymentReference($transaction->getDescription())) {
            $transaction->setTagData(['outpayment_reference' => $reference]);
            $transaction->addTag(TransactionTags::TAG_OUTPAYMENT);
        } elseif ($reference = Helper_Banktransaction_Matching::getTransferPayoutReference($transaction->getDescription())) {
            $transaction->setTagData(['transfer_reference' => $reference]);
            $transaction->addTag(TransactionTags::TAG_TRANSFER);
        } else {
            $transaction->recordUnknown(
                [TransactionTags::TAG_UNKNOWNOUTPAYMENT],
                Model_TransactionRegistration::REGISTRATION_UNKNOWN_OUTPAYMENT
            );
        }

        return $transaction;
    }
}
