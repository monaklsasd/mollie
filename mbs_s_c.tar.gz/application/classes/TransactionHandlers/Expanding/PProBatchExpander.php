<?php

declare(strict_types=1);

namespace TransactionHandlers\Expanding;

use Core\Localization\Localizer;
use Helper\Database\TransactionCoordinator;
use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use Model_Settlement_Ppro;
use Money\Money;
use Orm\ModelFactory;
use Orm\Repositories\PPro\Settlement\RecordRepository;
use Orm\Repositories\PPro\SettlementRepository;
use Supplier\PPro\Settlement\Record\TransactionTransformer;
use TransactionHandlers\Constraints\TagExactlyMatches;
use TransactionHandlers\Expanding\Exception\InvalidSettlementException;
use Validation\ValidatorFactory;
use function iterator_to_array;

/**
 * Expand PPRO batch transactions into separate transactions based on information in settlement reports.
 */
class PProBatchExpander extends BatchExpanderBase
{
    /** @var SettlementRepository */
    private $settlement_repository;

    /** @var TransactionTransformer */
    private $transformer;

    /** @var RecordRepository */
    private $record_repository;

    public function __construct(
        ValidatorFactory $validator_factory,
        TransactionCoordinator $transaction_coordinator,
        ModelFactory $model_factory,
        SettlementRepository $settlement_repository,
        TransactionTransformer $transaction_transformer,
        RecordRepository $record_repository
    ) {
        parent::__construct($validator_factory, $transaction_coordinator, $model_factory);

        $this->settlement_repository = $settlement_repository;
        $this->transformer           = $transaction_transformer;
        $this->record_repository     = $record_repository;
    }

    public function getTransactionConstraints(): array
    {
        return [
            new TagExactlyMatches(TransactionTags::TAG_PPRO_SETTLEMENT),
        ];
    }

    protected function isExpandable(Model_Banktransaction $banktransaction): bool
    {
        if (!$banktransaction->isReceivedPProSettlement()) {
            return false;
        }

        $settlement = $this->getSettlementFromTransaction($banktransaction);
        $this->assertSettlementFilesAreParsed($settlement);

        return true;
    }

    protected function expandTransaction(Model_Banktransaction $batch_transaction): iterable
    {
        $this->setLastProcessedTransaction($batch_transaction);

        $settlement = $this->getSettlementFromTransaction($batch_transaction);

        $this->assertSettlementFilesAreParsed($settlement);
        $this->assertSettlementConsistsOfOnlySupportedEvents($settlement);
        $this->assertSettlementContainsSupportedPaymentRecords($settlement);

        $child_transactions = iterator_to_array($this->transformer->transformSettlementRecordsForBatch($batch_transaction, $settlement), false);

        $this->assertSumOfChildTransactionsMatchesWithTransactionSum(
            $batch_transaction,
            $child_transactions
        );

        $batch_transaction->setTags([TransactionTags::TAG_PPRO_SETTLEMENT_EXPANDED]);

        return $child_transactions;
    }

    /**
     * @throws InvalidSettlementException
     */
    private function getSettlementFromTransaction(Model_Banktransaction $batch_transaction): Model_Settlement_Ppro
    {
        $tag_data = $batch_transaction->getTagData();

        if (empty($tag_data['settlement_id'])) {
            throw new InvalidSettlementException(sprintf(
                'No settlement reference could be found in batch transaction: #%d',
                $batch_transaction->getPrimaryKey()
            ));
        }

        $settlement_reference = $tag_data['settlement_id'];
        $settlement           = $this->settlement_repository->findByReference($settlement_reference);

        if ($settlement === null) {
            throw new InvalidSettlementException('Could not find settlement with reference: ' . $settlement_reference);
        }

        return $settlement;
    }

    private function assertSettlementConsistsOfOnlySupportedEvents(Model_Settlement_Ppro $settlement): void
    {
        $supported_event_types = [null, 'FUNDSMISSING', 'FUNDSRECEIVED', 'SUCCEEDED'];

        foreach ($this->record_repository->getVolumeRecordsFor($settlement) as $record) {
            if (!\in_array($record->event_type, $supported_event_types, true)) {
                throw new InvalidSettlementException(sprintf(
                    'Cannot expand settlement #%d, unsupported event type: "%s" in record #%d',
                    $settlement->getPrimaryKey(),
                    $record->event_type,
                    $record->getPrimaryKey()
                ));
            }
        }
    }

    private function assertSettlementContainsSupportedPaymentRecords(Model_Settlement_Ppro $settlement): void
    {
        $supported_record_payment_methods = [
            TransactionTransformer::PAYMENT_METHOD_TAG_BANCONTACT,
            TransactionTransformer::PAYMENT_METHOD_TAG_BANCONTACT_OLD,
            TransactionTransformer::PAYMENT_METHOD_TAG_EPS,
            TransactionTransformer::PAYMENT_METHOD_TAG_GIROPAY,
            TransactionTransformer::PAYMENT_METHOD_TAG_IDEAL,
            TransactionTransformer::PAYMENT_METHOD_TAG_MYBANK,
            TransactionTransformer::PAYMENT_METHOD_TAG_PRZELEWY24,
            TransactionTransformer::PAYMENT_METHOD_TAG_PRZELEWY24_FULL,
        ];

        foreach ($settlement->records() as $record) {
            if (!\in_array($record->payment_method, $supported_record_payment_methods, true)) {
                throw new InvalidSettlementException(sprintf(
                    'Cannot expand settlement #%d, record for an unsupported payment type found: %s',
                    $settlement->getPrimaryKey(),
                    $record->payment_method
                ));
            }
        }
    }

    private function assertSettlementFilesAreParsed(Model_Settlement_Ppro $settlement): void
    {
        foreach ($settlement->files() as $file) {
            if (!$file->isProcessed()) {
                throw new InvalidSettlementException(sprintf(
                    'Cannot expand settlement #%d, unparsed file found: %s',
                    $settlement->getPrimaryKey(),
                    $file->filename
                ));
            }
        }
    }

    protected function handleTransaction(Model_Banktransaction $transaction): void
    {
        if (\in_array((int)$transaction->getPrimaryKey(), [112145383, 113076463], true)) {
            return;
        }
        parent::handleTransaction($transaction);
    }

    private function assertSumOfChildTransactionsMatchesWithTransactionSum(
        Model_Banktransaction $batch_transaction,
        array $child_transactions
    ): void {
        $child_sum = array_reduce($child_transactions, function (Money $sum, Model_Banktransaction $child_transaction) {
            return $sum->add($child_transaction->getAmount());
        }, new Money(0, $batch_transaction->getCurrency()));

        $difference = $batch_transaction->getAmount()->subtract($child_sum);

        if (!$difference->isZero()) {
            throw new InvalidSettlementException(sprintf(
                'Batch transaction (#%1$d) amount (%2$s) does not match sum of child transactions amounts (%3$s) (∆ %4$s).',
                $batch_transaction->id,
                Localizer::formatMoney($batch_transaction->getAmount()),
                Localizer::formatMoney($child_sum),
                Localizer::formatMoney($difference)
            ));
        }
    }
}
