<?php

declare(strict_types=1);

namespace TransactionHandlers\Expanding;

use Core\Localization\Localizer;
use Helper\Database\TransactionCoordinator;
use Helper_Banktransaction_Matching;
use Model\Transaction\TransactionTags;
use Model_BankPaymentBatch;
use Model_Banktransaction;
use Mollie\BankingFiles\Batch\BatchTransaction;
use Money\Money;
use Orm\ModelFactory;
use Orm\Repositories\BankPaymentBatchRepository;
use TransactionHandlers\Constraints\TagExactlyMatches;
use TransactionHandlers\Expanding\Exception\InvalidBatchException;
use Validation\ValidatorFactory;
use function count;
use function in_array;
use function is_array;
use function sprintf;

/**
 * Expand SEPA transactions. This expands a transaction on our bank statement which represents a SEPA batch into its
 * original child transactions.
 *
 * Note that if you use this for a new batch, you should add a filter rule to make sure only transactions with the right
 * tag are passed to this handler.
 */
class SepaBatchExpander extends BatchExpanderBase
{
    /**
     * Sometimes a SDD batch is partially rejected, for example because of an invalid signature date for a transaction.
     * Add that payment transaction ID to this list. If at a later time the transaction succeeds, remove it from the
     * list again.
     */
    private static $REJECTED_DIRECTDEBIT_TRANSACTIONS_IDS = [
        /**
         * @see https://redmine.mollie.nl/issues/23016
         *        'SD38000011526135',
         *        'SD89000053248894',
         *        'SD04000046828539',
         *        'SD45000038611416',
         *        'SD27000015535149',
         *        'SD61000021402455',
         *        'SD93000033313285',
         *        'SD30000077400725',
         *        'SD24000010510991',
         *        'SD70000040700152',
         *        'SD60000009357789',
         *        'SD29000041495223',
         *        'SD08000018660055',
         *        'SD14000049401187',
         *        'SD74000033161531',
         *        'SD15000048796956',
         *        'SD61000099134472',
         *        'SD36000007471862',
         *        'SD44000065655422',
         *        'SD80000042555582',
         *        'SD77000064387911',
         *        'SD19000061447139',
         *        'SD13000081186262',
         *        'SD34000044983156',
         *        'SD89000087707659',
         *        'SD50000028858364',
         *        'SD78000077869050',
         *        'SD39000085241461',
         *        'SD35000000658988',
         *        'SD70000041254701',
         *        'SD58000049775397',
         * @issue PAY-275
         *        'SD76791301023866',
         *        'SD24142164990594',
         */
        'SD24519981335596',
    ];

    /** @var BankPaymentBatchRepository */
    private $batch_repository;

    public function __construct(
        ValidatorFactory $validator_factory,
        TransactionCoordinator $transaction_coordinator,
        ModelFactory $model_factory,
        BankPaymentBatchRepository $batch_repository
    ) {
        parent::__construct($validator_factory, $transaction_coordinator, $model_factory);
        $this->batch_repository = $batch_repository;
    }

    public function getTransactionConstraints(): array
    {
        return array_merge(parent::getTransactionConstraints(), [
            new TagExactlyMatches(TransactionTags::TAG_SEPA),
        ]);
    }

    /**
     * Original transaction has to be a SEPA transaction.
     */
    protected function isExpandable(Model_Banktransaction $banktransaction): bool
    {
        return $banktransaction->isSepaTransaction();
    }

    /**
     * @throws InvalidBatchException
     */
    protected function expandTransaction(Model_Banktransaction $batch_transaction): iterable
    {
        $this->setLastProcessedTransaction($batch_transaction);

        if (!($sepa_file = $this->batch_repository->findBySepaPaymentInfoId($batch_transaction->getSepaBatchReference()))) {
            throw new InvalidBatchException(sprintf(
                'Cannot find SEPA batch for transaction #%d!',
                $batch_transaction->getPrimaryKey()
            ));
        }

        $expanded_transactions = [];

        /* Keep track of the amount we are splitting up. */
        $sum = new Money(0, $batch_transaction->getCurrency());

        $sepa_batch_id = $batch_transaction->getSepaBatchReference();
        $sepa_batch    = $sepa_file->getReader()->getBatch($sepa_batch_id);

        if (!$sepa_batch) {
            throw new InvalidBatchException(sprintf(
                'Failed to find SEPA Batch with ID %s!',
                $sepa_batch_id
            ));
        }

        $sepa_transactions = $sepa_batch->getTransactions();

        if (!is_array($sepa_transactions) || !count($sepa_transactions)) {
            throw new InvalidBatchException(sprintf(
                'Failed to read SEPA transactions for transaction #%d!',
                $batch_transaction->getPrimaryKey()
            ));
        }

        foreach ($sepa_transactions as $single_transaction) {
            $directdebit_transaction_id = Helper_Banktransaction_Matching::get_directdebit_sd(
                $single_transaction->getReference()
            );

            if ($directdebit_transaction_id !== null
                && in_array($directdebit_transaction_id, self::$REJECTED_DIRECTDEBIT_TRANSACTIONS_IDS, true)) {
                continue;
            }

            $transaction             = $this->buildBanktransaction($batch_transaction, $single_transaction);
            $expanded_transactions[] = $transaction;
            $sum                     = $sum->add($transaction->getAmount());
        }

        if (!$sum->equals($batch_transaction->getAmount())) {
            throw new InvalidBatchException(sprintf(
                'Sum of the expanded transactions %s does not match the original transaction amount %s for #%d.',
                Localizer::formatMoney($sum),
                Localizer::formatMoney($batch_transaction->getAmount()),
                $batch_transaction->getPrimaryKey()
            ));
        }

        if ($sepa_file->getStatus() !== Model_BankPaymentBatch::RECONCILED) {
            $sepa_file->markAsReconciled($batch_transaction);
            $sepa_file->saveOrDie();
        } elseif ($sepa_file->transaction->getPrimaryKey() !== $batch_transaction->getPrimaryKey()) {
            $sepa_file->storeHistoryEntry(sprintf('ERROR: Reconciled AGAIN in transaction #%d.', $batch_transaction->getPrimaryKey()));
            $this->logger->error(sprintf(
                'Sepa batch #%d seems to be executed twice. Once in transaction #%d and now again in #%d. The reconciliation process is not halted but this requires investigation.',
                $sepa_file->getPrimaryKey(),
                $sepa_file->transaction->getPrimaryKey(),
                $batch_transaction->getPrimaryKey()
            ));
        }

        return $expanded_transactions;
    }

    /**
     * Create a Model_Banktransaction for the child transaction, which is represented by a Transaction object.
     *
     * Adds data that should be persisted.
     */
    protected function buildBanktransaction(
        Model_Banktransaction $batch_transaction,
        BatchTransaction $child_transaction
    ): Model_Banktransaction {
        $transaction = $this->createChildTransaction($batch_transaction);

        /* Now copy specifics from the transaction IN the batch */
        $transaction->setAmount($child_transaction->getAmount()->negative());
        $transaction->setDescription($child_transaction->getDescription());
        $transaction->setOffsetAccountNumber($child_transaction->getCreditorBankaccount());
        $transaction->setOffsetAccountName($child_transaction->getCreditorName());
        $transaction->setOffsetAccountBic($child_transaction->getCreditorBic());

        $credittransfer_rf = Helper_Banktransaction_Matching::get_credittransfer_rf(
            $child_transaction->getReference()
        );

        if ($credittransfer_rf !== null) {
            $transaction->setTagData(['credittransfer_rf' => $credittransfer_rf]);
        }

        return $transaction;
    }
}
