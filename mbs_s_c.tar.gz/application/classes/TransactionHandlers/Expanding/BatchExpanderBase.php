<?php

declare(strict_types=1);

namespace TransactionHandlers\Expanding;

use Exception;
use Helper\Database\TransactionCoordinator;
use Model_Banktransaction;
use Orm\ModelFactory;
use TransactionHandlers\Constraints\HasNoChildTransactions;
use TransactionHandlers\Exceptions\TransactionHandlerRuntimeException;
use TransactionHandlers\SingleTransactionHandler;
use Validation\ValidatorFactory;

abstract class BatchExpanderBase extends SingleTransactionHandler
{
    /** @var TransactionCoordinator */
    protected $transaction_coordinator;

    /** @var ModelFactory */
    protected $model_factory;

    public function __construct(ValidatorFactory $validator_factory, TransactionCoordinator $transaction_coordinator, ModelFactory $model_factory)
    {
        parent::__construct($validator_factory);
        $this->transaction_coordinator = $transaction_coordinator;
        $this->model_factory           = $model_factory;
    }

    protected function getTransactionConstraints(): array
    {
        return array_merge(parent::getTransactionConstraints(), [new HasNoChildTransactions()]);
    }

    /**
     * @throws TransactionHandlerRuntimeException
     * @throws Exception
     */
    protected function handleTransaction(Model_Banktransaction $transaction): void
    {
        $this->setLastProcessedTransaction($transaction);

        if (!$this->isExpandable($transaction)) {
            throw new TransactionHandlerRuntimeException(sprintf(
                'Transaction %d is not a valid batch transaction for %s.',
                $transaction->getPrimaryKey(),
                static::class
            ));
        }

        $this->transaction_coordinator->begin();

        try {
            $expanded_transactions = $this->expandTransaction($transaction);

            $transaction->saveOrDie();

            foreach ($expanded_transactions as $expanded_transaction) {
                $expanded_transaction->saveOrDie();
            }

            $transaction->addComment(sprintf(
                'Expanded batch transaction %d into %d transactions.',
                $transaction->getPrimaryKey(),
                \count($expanded_transactions)
            ));

            $this->transaction_coordinator->commit();
        } catch (Exception $e) {
            $this->transaction_coordinator->rollback();

            throw $e;
        }
    }

    protected function createChildTransaction(Model_Banktransaction $parent_transaction): Model_Banktransaction
    {
        $child_transaction = $this->model_factory->create(Model_Banktransaction::class);
        $child_transaction->setParentTransaction($parent_transaction);

        return $child_transaction;
    }

    /**
     * Check if the given BankTransaction can be expanded, will cause handler to throw exception and fail if false is
     * returned This is preferable over adding it to the constraints and being skipped; it means something requires
     * manual attention.
     */
    abstract protected function isExpandable(Model_Banktransaction $banktransaction): bool;

    /**
     * Expand the given banktransaction into a subset of banktransactions.
     * Afterwards, the new childtransactions and transaction itself will be saved.
     *
     * @return iterable|Model_Banktransaction[]
     */
    abstract protected function expandTransaction(Model_Banktransaction $batch_transaction): iterable;
}
