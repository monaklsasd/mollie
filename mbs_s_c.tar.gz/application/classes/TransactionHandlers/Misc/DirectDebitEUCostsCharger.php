<?php

namespace TransactionHandlers\Misc;

use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use Supplier\Mollie\Mollie;
use TransactionHandlers\Constraints\HasNegativeAmount;
use TransactionHandlers\Constraints\TagExactlyMatches;
use TransactionHandlers\SingleTransactionHandler;
use Validation\ValidatorFactory;
use Webmozart\Assert\Assert;

/**
 * Informs Mollie Platform of charges we receive from German and Austrian banks that ABN AMRO forwards to Mollie
 * Platform. Mollie Platform will then add a nice mark up and charge the merchants.
 *
 * These transactions can be recognized by their tag 'stornodirectdebit_costsEU'.
 */
class DirectDebitEuCostsCharger extends SingleTransactionHandler
{
    /** @var Mollie */
    private $mollie_platform;

    public function __construct(ValidatorFactory $validator_factory, Mollie $mollie_platform)
    {
        parent::__construct($validator_factory);
        $this->mollie_platform = $mollie_platform;
    }

    protected function getTransactionConstraints(): array
    {
        return [
            new TagExactlyMatches(TransactionTags::TAG_STORNODIRECTDEBIT_COSTSEU),
            new HasNegativeAmount(),
        ];
    }

    protected function handleTransaction(Model_Banktransaction $transaction): void
    {
        $tag_data = $transaction->getTagData();

        Assert::keyExists($tag_data, "transaction_id");

        $sdd_transaction_id = $tag_data["transaction_id"];

        $this->mollie_platform->informBankingFeeCharged(
            $transaction->getAmount()->absolute(),
            $sdd_transaction_id,
            $transaction->getPrimaryKey()
        );
    }
}
