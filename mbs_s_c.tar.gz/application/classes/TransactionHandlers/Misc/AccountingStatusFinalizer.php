<?php

namespace TransactionHandlers\Misc;

use Model_Bankstatement;
use Model_Banktransaction;
use Orm\Repositories\ValitorStatementsReExpandedRepository;
use TransactionHandlers\SingleTransactionHandler;
use Validation\ValidatorFactory;

class AccountingStatusFinalizer extends SingleTransactionHandler
{
    /** @var ValitorStatementsReExpandedRepository */
    private $valitor_statements_re_expanded_repository;

    public function __construct(
        ValidatorFactory $validator_factory,
        ValitorStatementsReExpandedRepository $valitor_statements_re_expanded_repository
    ) {
        parent::__construct($validator_factory);
        $this->valitor_statements_re_expanded_repository = $valitor_statements_re_expanded_repository;
    }

    public function handleTransaction(Model_Banktransaction $transaction): void
    {
        $statement = $transaction->getStatement();

        /*
         * For Twinfield reported Valitor statements that we want to re-expand we need to make sure we don't allow the
         * reconciliation amounts to be sent to Twinfield again.
         * @see https://mollie.atlassian.net/browse/FFS-1990
         *
         * This is temporary code and should be removed with:
         * @see https://mollie.atlassian.net/browse/FFS-2000
         */
        if ($this->valitor_statements_re_expanded_repository->isCurrentlyReExpandingValitorStatement($statement)) {
            $statement->setAccountviewStatus(Model_Bankstatement::ACCOUNTVIEW_STATUS_QUEUED);
            $statement->saveOrDie();

            return;
        }

        if ($statement->getAccountviewStatus() !== Model_Bankstatement::ACCOUNTVIEW_STATUS_READY) {
            $statement->setAccountviewStatus(Model_Bankstatement::ACCOUNTVIEW_STATUS_READY);
            $statement->saveOrDie();
        }
    }
}
