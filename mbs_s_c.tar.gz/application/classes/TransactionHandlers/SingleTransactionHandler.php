<?php

declare(strict_types=1);

namespace TransactionHandlers;

use Generator;
use Model_Banktransaction;
use ReflectionClass;
use TransactionHandlers\Exceptions\TransactionHandlerRuntimeException;

abstract class SingleTransactionHandler extends AbstractTransactionHandler
{
    /**
     * @param Generator|iterable|Model_Banktransaction[] $transactions
     */
    public function run(iterable $transactions): bool
    {
        $failure_count = 0;

        foreach ($transactions as $transaction) {
            $this->setLastProcessedTransaction($transaction);
            $constraint_violations = $this->transaction_validator->validate(
                $transaction,
                $this->getTransactionConstraints()
            );

            if ($constraint_violations->count() > 0) {
                $this->logger->debug(sprintf(
                    'Skipping transaction #%d: %s.',
                    $transaction->getPrimaryKey(),
                    implode(', ', self::formatConstraintViolationsForLog($constraint_violations))
                ));

                continue;
            }

            try {
                $this->handleTransaction($transaction);
            } catch (TransactionHandlerRuntimeException $e) {
                $exception = new TransactionHandlerRuntimeException(sprintf(
                    'A %s occurred while running %s for Transaction %d: %s',
                    (new ReflectionClass(\get_class($e)))->getShortName(),
                    (new ReflectionClass(static::class))->getShortName(),
                    $transaction->getPrimaryKey(),
                    $e->getMessage()
                ), 0, $e);
                $this->logger->error($exception->getMessage(), ['exception' => $exception]);
                $failure_count++;
            }
        }

        return $failure_count === 0; //if there were any failures, it will have to run again.
    }
}
