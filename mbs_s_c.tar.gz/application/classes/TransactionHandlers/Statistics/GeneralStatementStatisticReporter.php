<?php

declare(strict_types=1);

namespace TransactionHandlers\Statistics;

use Helper\DateTime\Utc;
use Model\Transaction\TransactionTags;
use Model_Bankstatement;
use Model_Banktransaction as Trx;
use Money\Money;
use Statistics\BankFeeSum;
use Statistics\FailedSettlementCount;
use Statistics\StatisticRepository;
use Statistics\SuccessfulSettlementCount;
use Statistics\SuccessfulSettlementSum;
use Statistics\TotalSettlementCount;
use Statistics\UnknownSettlementCount;
use TransactionHandlers\Constraints\HasNoChildTransactions;
use TransactionHandlers\SingleTransactionHandler;
use Validation\ValidatorFactory;
use function count;

class GeneralStatementStatisticReporter extends SingleTransactionHandler
{
    use Utc;

    /** @var StatisticRepository */
    protected $statistic_repository;

    /**
     * IMPORTANT: should be reset at the start of ::run for this handler to remain stateless
     *
     * @var Model_Bankstatement
     */
    protected $statement;

    /**
     * IMPORTANT: should be reset at the start of ::run for this handler to remain stateless
     *
     * @var int[]
     */
    protected $settlement_counts = [];

    /**
     * IMPORTANT: should be reset at the start of ::run for this handler to remain stateless
     *
     * @var int[]
     */
    protected $success_counts = [];

    /**
     * IMPORTANT: should be reset at the start of ::run for this handler to remain stateless
     *
     * @var int[]
     */
    protected $failed_counts = [];

    /**
     * IMPORTANT: should be reset at the start of ::run for this handler to remain stateless
     *
     * @var int[]
     */
    protected $unknown_counts = [];

    /**
     * IMPORTANT: should be reset at the start of ::run for this handler to remain stateless
     *
     * @var Money[]
     */
    protected $successful_settlement_sums = [];

    /**
     * IMPORTANT: should be reset at the start of ::run for this handler to remain stateless
     *
     * @var Money
     */
    protected $fee_sum;

    /**
     * GeneralStatementStatisticReporter constructor.
     */
    public function __construct(ValidatorFactory $validator_factory, StatisticRepository $statistic_repository)
    {
        parent::__construct($validator_factory);
        $this->statistic_repository = $statistic_repository;
    }

    protected function getTransactionConstraints(): array
    {
        /** get only innermost child transactions */
        return [new HasNoChildTransactions()];
    }

    public function run(iterable $transactions): bool
    {
        $this->clearCollectedValues();

        $result = parent::run($transactions);

        $statistics_grouped_per_method = [
            TotalSettlementCount::class      => $this->settlement_counts,
            SuccessfulSettlementCount::class => $this->success_counts,
            FailedSettlementCount::class     => $this->failed_counts,
            UnknownSettlementCount::class    => $this->unknown_counts,
            SuccessfulSettlementSum::class   => $this->successful_settlement_sums,
        ];

        $statistics = [];

        foreach ($statistics_grouped_per_method as $statistic_class_name => $statistic_type) {
            foreach ($statistic_type as $method => $value) {
                $statistics[] = $statistic_class_name::createFromStatement($this->statement, $method, $value);
            }
        }

        if ($this->fee_sum !== null) {
            $statistics[] = BankFeeSum::createFromStatement($this->statement, null, $this->fee_sum);
        }

        $this->statistic_repository->save(...$statistics);

        $this->clearCollectedValues();

        return $result;
    }

    protected function handleTransaction(Trx $transaction): void
    {
        if ($this->statement === null) {
            // 'Cache' for use in ::run, no access to transactions there.
            $this->statement = $transaction->getStatement();
        }

        if ($transaction->hasAnyOfTags(TransactionTags::BANK_FEE_TAGS)) {
            $this->fee_sum = self::addAmountToTotal($this->fee_sum, $transaction);

            return; // Rest of method deals with settlements;
        }

        // Success.
        if ($method_tag = self::getFirstMatchingTag(TransactionTags::SETTLEMENT_TAGS, $transaction->getTags())) {
            $this->success_counts[$method_tag]             = ($this->success_counts[$method_tag] ?? 0) + 1;
            $this->successful_settlement_sums[$method_tag] = self::addAmountToTotal(
                $this->successful_settlement_sums[$method_tag] ?? null,
                $transaction
            );

        // Failed.
        } elseif ($failed_tag = self::getFirstMatchingTag(TransactionTags::FAILED_SETTLEMENT_TAGS, $transaction->getTags())) {
            $method_tag                       = array_search($failed_tag, TransactionTags::FAILED_SETTLEMENT_TAGS, true);
            $this->failed_counts[$method_tag] = ($this->failed_counts[$method_tag] ?? 0) + 1;

        // Unknown.
        } elseif ($unknown_tag = self::getFirstMatchingTag(TransactionTags::UNKNOWN_SETTLEMENT_TAGS, $transaction->getTags())) {
            $method_tag                        = array_search($unknown_tag, TransactionTags::UNKNOWN_SETTLEMENT_TAGS, true);
            $this->unknown_counts[$method_tag] = ($this->unknown_counts[$method_tag] ?? 0) + 1;
        }

        if ($method_tag !== null) {
            $this->settlement_counts[$method_tag] = ($this->settlement_counts[$method_tag] ?? 0) + 1;
        }
    }

    private function clearCollectedValues()
    {
        $this->statement                  = null;
        $this->settlement_counts          = [];
        $this->success_counts             = [];
        $this->failed_counts              = [];
        $this->unknown_counts             = [];
        $this->successful_settlement_sums = [];
        $this->fee_sum                    = null;
    }

    private static function getFirstMatchingTag(array $needles, array $haystack): ?string
    {
        $found_needles = array_intersect($needles, $haystack);

        if (count($found_needles) === 0) {
            return null;
        }

        return reset($found_needles);
    }

    private static function addAmountToTotal(?Money $total, Trx $transaction)
    {
        return $total ? $total->add($transaction->getAmount()) : $transaction->getAmount();
    }
}
