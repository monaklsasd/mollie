<?php

declare(strict_types=1);

namespace TransactionHandlers;

use Core\Di\DependencyInjector;
use Log\DatabaseLogger;

class TransactionHandlerFactory
{
    /** @var DependencyInjector */
    private $dependency_injector;

    /** @var DatabaseLogger */
    private $logger;

    public function __construct(DependencyInjector $dependency_injector, DatabaseLogger $logger)
    {
        $this->dependency_injector = $dependency_injector;
        $this->logger              = $logger;
    }

    public function createHandler(string $class_name): AbstractTransactionHandler
    {
        $handler = $this->dependency_injector->get($class_name);
        $handler->setLogger($this->logger);

        return $handler;
    }
}
