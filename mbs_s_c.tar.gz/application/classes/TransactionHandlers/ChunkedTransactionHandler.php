<?php

declare(strict_types=1);

namespace TransactionHandlers;

use Model_Banktransaction;
use ReflectionClass;
use TransactionHandlers\Exceptions\TransactionHandlerRuntimeException;

abstract class ChunkedTransactionHandler extends AbstractTransactionHandler
{
    /**
     * IMPORTANT: should be reset at the start of ::run for this handler to remain stateless
     *
     * This is a class property instead of a local variable because errors can be reported
     * through reportSingleTransactionException as well.
     *
     * @var int
     */
    protected $failure_count = 0;

    protected function getChunkSize(): int
    {
        return 30;
    }

    public function run(iterable $transactions): bool
    {
        $this->failure_count = 0; //this makes sure the failure status doesn't carry over between runs, DON'T REMOVE
        $chunk               = [];

        foreach ($transactions as $transaction) {
            $this->setLastProcessedTransaction($transaction);
            $constraint_violations = $this->transaction_validator->validate($transaction, $this->getTransactionConstraints());

            if ($constraint_violations->count() > 0) {
                $this->logger->debug(sprintf(
                    'Skipping transaction #%d: %s.',
                    $transaction->getPrimaryKey(),
                    implode(', ', self::formatConstraintViolationsForLog($constraint_violations))
                ));

                continue;
            }

            $chunk[] = $transaction;

            if ($this->getChunkSize() <= \count($chunk)) {
                $this->runChunk($chunk);
                $chunk = [];
            }
        }

        if (\count($chunk) > 0) {
            $this->runChunk($chunk);
        }

        return $this->failure_count === 0;
    }

    /**
     * @param iterable|Model_Banktransaction[] $transactions
     */
    protected function runChunk(iterable $transactions): void
    {
        try {
            $this->preChunk($transactions);

            foreach ($transactions as $transaction) {
                try {
                    $this->handleTransaction($transaction);
                } catch (TransactionHandlerRuntimeException $e) {
                    $exception = new TransactionHandlerRuntimeException(sprintf(
                        'A %s occurred while running %s for Transaction %d: %s',
                        (new ReflectionClass(\get_class($e)))->getShortName(),
                        (new ReflectionClass(static::class))->getShortName(),
                        $transaction->getPrimaryKey(),
                        $e->getMessage()
                    ), 0, $e);
                    $this->logger->error($exception->getMessage(), ['exception' => $exception]);
                    $this->failure_count++;
                }
            }

            $this->postChunk($transactions);
        } catch (TransactionHandlerRuntimeException $e) {
            $chunk_description = 'a';

            if (\is_array($transactions)) {
                $chunk_description = sprintf(
                    'the %d-%d',
                    $transactions[0]->getPrimaryKey(),
                    $transactions[\count($transactions) - 1]->getPrimaryKey()
                );
            }

            $exception = new TransactionHandlerRuntimeException(sprintf(
                'A %s occurred while preparing or finishing %s for %s chunk of Transactions: %s',
                \get_class($e),
                static::class,
                $chunk_description,
                $e->getMessage()
            ), 0, $e);
            $this->logger->error($exception->getMessage(), ['exception' => $exception]);
            $this->failure_count++;
        }
    }

    /**
     * @param iterable|Model_Banktransaction[] $transactions
     *
     * @throws TransactionHandlerRuntimeException use this to indicate failures for a single chunk,
     *                                            but continue with the batch
     */
    abstract protected function preChunk(iterable $transactions): void;

    /**
     * @param iterable|Model_Banktransaction[] $transactions
     *
     * @throws TransactionHandlerRuntimeException use this to indicate failures for a single chunk,
     *                                            but continue with the batch
     */
    abstract protected function postChunk(iterable $transactions): void;
}
