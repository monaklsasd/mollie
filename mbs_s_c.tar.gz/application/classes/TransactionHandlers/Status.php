<?php

declare(strict_types=1);

namespace TransactionHandlers;

use MyCLabs\Enum\Enum;

/**
 * The possible status of a TransactionHandlerJob
 *
 * The statuses set here should match the possible values of the enum in the MySQL database.
 *
 * @method static self QUEUED()
 * @method static self RUNNING()
 * @method static self DONE()
 * @method static self FAILED()
 */
final class Status extends Enum
{
    public const QUEUED  = 'queued';
    public const RUNNING = 'running';
    public const DONE    = 'done';
    public const FAILED  = 'failed';
}
