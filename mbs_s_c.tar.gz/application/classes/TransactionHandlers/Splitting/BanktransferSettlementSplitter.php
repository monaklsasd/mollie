<?php

declare(strict_types=1);

namespace TransactionHandlers\Splitting;

use App\Entity\User;
use Bank\Batch\SepaBatchGenerator;
use Core\Localization\Localizer;
use Exception;
use Helper\Database\TransactionCoordinator;
use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use Model_TransactionRegistration;
use Money\Currency;
use Money\Money;
use Orm\ModelFactory;
use TransactionHandlers\Constraints\HasAnyOfTags;
use TransactionHandlers\Constraints\HasNoChildTransactions;
use TransactionHandlers\Constraints\HasSettlement;
use TransactionHandlers\Exceptions\TransactionHandlerRuntimeException;
use TransactionHandlers\SingleTransactionHandler;
use Validation\ValidatorFactory;
use function Core\Money\money_from_string;
use function count;

class BanktransferSettlementSplitter extends SingleTransactionHandler
{
    protected const REFUND_THRESHOLD = 100; // in cents

    /** @var TransactionCoordinator */
    protected $transaction_coordinator;

    /** @var ModelFactory */
    protected $model_factory;

    /** @var SepaBatchGenerator */
    protected $batch_generator;

    /**
     * All settlement-difference transactions that should be refunded.
     * This variable should be cleared at the start of each run.
     *
     * @var Model_Banktransaction[]
     */
    protected $refunds = [];

    public function __construct(
        ValidatorFactory $validator_factory,
        TransactionCoordinator $transaction_coordinator,
        ModelFactory $model_factory,
        SepaBatchGenerator $batch_generator
    ) {
        parent::__construct($validator_factory);
        $this->transaction_coordinator = $transaction_coordinator;
        $this->model_factory           = $model_factory;
        $this->batch_generator         = $batch_generator;
    }

    public function run(iterable $transactions): bool
    {
        // Start with empty state.
        $this->refunds = [];

        $result = parent::run($transactions);

        if (count($this->refunds) > 0) {
            $this->createRefundBatches();
        }

        return $result;
    }

    protected function createRefundBatches(): void
    {
        $warnings = [];

        /** @var Model_Banktransaction $transaction */
        $transaction = $this->refunds[0];

        $this->batch_generator->setCurrentUser(User::getSystemUser());
        $this->batch_generator->createRefundBatchesForTransactions(
            $this->refunds,
            sprintf('Overpayments banktransfer on %s', $transaction->getEntryDate()->format('Y-m-d')),
            'Received too much money for banktransfer. Transaction accepted, returning overpaid amount. Regards, Mollie',
            $warnings
        );

        if (count($warnings) > 0) {
            foreach ($warnings as $warning) {
                $this->logger->warning($warning);
            }
        }
    }

    protected function handleTransaction(Model_Banktransaction $transaction): void
    {
        $settlement_amount = $transaction->getTagData()['settlement_amount'] ?? null;

        if ($settlement_amount === null) {
            return; // No settlement amount communicated, maybe old transaction.
        }

        $settled = money_from_string($settlement_amount['value'], new Currency($settlement_amount['currency']));
        $gained  = $transaction->getAmount();

        if (!$settled->isSameCurrency($gained)) {
            throw new TransactionHandlerRuntimeException(sprintf(
                'Splitting of banktransfers settled in a different currency than the transfer is not yet supported. Gained: %s, Settlement: %s.',
                Localizer::formatMoney($gained),
                Localizer::formatMoney($settled)
            ));
        }

        $diff = $gained->subtract($settled);

        if ($diff->isZero()) {
            return; // Nothing to do
        }

        try {
            $this->transaction_coordinator->begin();

            [$settlement_child, $diff_child] = $this->splitTransaction($transaction, $settled, $diff);

            if ($diff->greaterThanOrEqual(new Money(self::REFUND_THRESHOLD, $diff->getCurrency()))) {
                $this->refundDiff($diff_child);
            }

            $this->transaction_coordinator->commit();
        } catch (Exception $e) {
            $this->transaction_coordinator->rollback();

            throw $e;
        }
    }

    /**
     * The original transaction is split in the settlement part and the diff part.
     *
     * @return Model_Banktransaction[] [0 => settlement, 1 => diff]
     */
    protected function splitTransaction(
        Model_Banktransaction $transaction,
        Money $settled,
        Money $diff
    ): array {
        $settlement_child = $this->model_factory->create(Model_Banktransaction::class);

        $settlement_child->setParentTransaction($transaction);
        $settlement_child->setDescription('Payment settlement amount');
        $settlement_child->setOffsetAccountNumber($transaction->getOffsetAccountNumber());
        $settlement_child->setOffsetAccountName($transaction->getOffsetAccountName());
        $settlement_child->setAmount($settled);
        $settlement_child->setTags($transaction->getTags());
        $settlement_child->setTagData($transaction->getTagData());

        $diff_child = $this->model_factory->create(Model_Banktransaction::class);

        $diff_child->setParentTransaction($transaction);
        $diff_child->setDescription('Payment difference');
        $diff_child->setOffsetAccountNumber($transaction->getOffsetAccountNumber());
        $diff_child->setOffsetAccountName($transaction->getOffsetAccountName());
        $diff_child->setAmount($diff);
        $diff_child->setTags([TransactionTags::TAG_BANKTRANSFER_DIFFERENCE]);

        // Remove tags from original transaction.
        $transaction->setTags([]);

        $settlement_child->saveOrDie();
        $diff_child->saveOrDie();
        $transaction->saveOrDie();

        /*
         * Move settlement to main child, that is the actual settlement transaction.
         * The MBS-id reported to Mollie earlier will still point to the parent transaction. That is okay.
         */
        $settlement = $transaction->getSettlement();
        $transaction->setSettlement(null);

        $settlement->fromTransaction($settlement_child, $settlement->getSupplierTransactionId(), $settlement->getPaymentMethod());
        $settlement_child->setSettlement($settlement);
        $settlement->saveOrDie();

        return [$settlement_child, $diff_child];
    }

    protected function refundDiff(Model_Banktransaction $transaction)
    {
        /*
         * Differences that will be refunded need a registration so the refund progress is trackable.
         * If for any reason they are not added to the batch automatically, this registration will
         * make them show up on the 'exceptional transactions' page as 'not handled'.
         */
        $transaction->addTag(TransactionTags::TAG_UNKNOWNBANKTRANSFER);
        $transaction->recordUnknown(
            $transaction->getTags(),
            Model_TransactionRegistration::REGISTRATION_OVERPAID_BANKTRANSFER
        );
        $this->refunds[] = $transaction;
    }

    public function getTransactionConstraints(): array
    {
        return [
            new HasNoChildTransactions(),
            new HasSettlement(),
            new HasAnyOfTags([
                TransactionTags::TAG_BANKTRANSFER,
            ]),
        ];
    }
}
