<?php

declare(strict_types=1);

namespace TransactionHandlers\Splitting;

use Core\Localization\Localizer;
use DateTimeImmutable;
use DateTimeZone;
use Helper\Database\TransactionCoordinator;
use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use Money\Money;
use Orm\ModelFactory;
use Supplier\Mollie\Mollie;
use Supplier\Mollie\Response\ConversionDetails;
use Throwable;
use TransactionHandlers\ChunkedTransactionHandler;
use TransactionHandlers\Constraints\DoesntHaveAnyOfTags;
use TransactionHandlers\Constraints\HasAnyOfTags;
use TransactionHandlers\Constraints\HasNoChildTransactions;
use TransactionHandlers\Constraints\HasSettlement;
use TransactionHandlers\Constraints\IsCreatedAfter;
use TransactionHandlers\Exceptions\TransactionHandlerRuntimeException;
use Validation\ValidatorFactory;

/**
 * Splits the settlement of FX transactions that are settled on a EUR bank account (and thus converted in the process by
 * the supplier) into parts:
 *
 * - The amount to be settled to the merchant
 * - The amount that we estimated our supplier to take
 * - Any revenue (or loss) for Mollie B.V. due to differences between the actual and estimated amounts.
 */
class MultiCurrencyTransactionSplitter extends ChunkedTransactionHandler
{
    /** @var TransactionCoordinator */
    protected $transaction_coordinator;

    /** @var ModelFactory */
    protected $model_factory;

    /** @var Mollie */
    protected $mollie;

    /**
     * IMPORTANT: should be empty at the start of each chunk for this handler to remain stateless
     *
     * @var ConversionDetails[]
     */
    protected $payment_conversions = [];

    public function __construct(
        ValidatorFactory $validator_factory,
        TransactionCoordinator $transaction_coordinator,
        ModelFactory $model_factory,
        Mollie $mollie
    ) {
        parent::__construct($validator_factory);
        $this->transaction_coordinator = $transaction_coordinator;
        $this->model_factory           = $model_factory;
        $this->mollie                  = $mollie;
    }

    protected function preChunk(iterable $transactions): void
    {
        $this->payment_conversions = [];
        $payment_id_map            = [];

        /**
         * @var Model_Banktransaction[]
         */
        foreach ($transactions as $transaction) {
            $payment_id_map[$transaction->getSettlement()->getMolliePaymentId()] = $transaction->getPrimaryKey();
        }

        foreach ($this->mollie->getConversionDetails(array_keys($payment_id_map)) as $conversion) {
            $this->payment_conversions[$payment_id_map[$conversion->getPaymentId()]] = $conversion;
        }
    }

    protected function postChunk(iterable $transactions): void
    {
        $this->payment_conversions = []; //keep handler stateless
    }

    protected function handleTransaction(Model_Banktransaction $transaction): void
    {
        if (!isset($this->payment_conversions[$transaction->getPrimaryKey()])) {
            return;
        }

        $conversion = $this->payment_conversions[$transaction->getPrimaryKey()];

        $child_transactions = $this->createChildTransactions(
            $transaction,
            $conversion->getSettlementAmount(),
            $conversion->getConvertedAmount(),
            $conversion->getMarkupRisk(),
            $conversion->getMarkupSupplier()
        );

        $transaction->setTags([]);

        try {
            $this->transaction_coordinator->begin();

            $transaction->saveOrDie();

            foreach ($child_transactions as $child_transaction) {
                $child_transaction->saveOrDie();
            }

            /*
             * Move settlement to main child, that is the actual settlement transaction.
             * This also prevent rerunned transaction handlers from trying to report the child transaction as well.
             *
             * The MBS-id reporter to Mollie earlier will still point to the parent transaction. That is okay.
             */
            $settlement = $transaction->getSettlement();
            $transaction->setSettlement(null);

            $settlement->fromTransaction($child_transactions[0], $settlement->getSupplierTransactionId(), $settlement->getPaymentMethod());
            $child_transactions[0]->setSettlement($settlement);
            $settlement->saveOrDie();

            $this->transaction_coordinator->commit();
        } catch (Throwable $e) {
            if ($this->transaction_coordinator->inTransaction()) {
                $this->transaction_coordinator->rollback();
            }

            throw $e;
        }
    }

    /**
     * Get the supplier transaction id from the transaction. The transaction id can be understood by the Mollie
     * application.
     *
     * @throws TransactionHandlerRuntimeException
     */
    protected function deductProviderTransactionId(Model_Banktransaction $transaction): string
    {
        $tag_data = $transaction->getTagData();

        if (!$tag_data || empty($tag_data['transaction_id'])) {
            throw new TransactionHandlerRuntimeException(sprintf(
                'Error fetching supplier transaction id from transaction #%d',
                $transaction->id
            ));
        }

        return $tag_data['transaction_id'];
    }

    /**
     * @throws TransactionHandlerRuntimeException If created child transactions total does not match main transaction's.
     */
    private function createChildTransactions(
        Model_Banktransaction $transaction,
        Money $settlement_amount,
        Money $converted_amount,
        Money $markup_risk,
        Money $markup_supplier
    ): iterable {
        $child_transactions = [];

        $child_transactions[] = $this->prepareChildTransactionFor(
            $transaction,
            $settlement_amount,
            $transaction->getTags(), //forward all tags
            'Payment settlement amount'
        );

        $child_transactions[] = $this->prepareChildTransactionFor(
            $transaction,
            $markup_risk,
            [TransactionTags::TAG_MC_FX_MARGIN],
            'Mollie FX margin (valutaresultaat)'
        );

        $estimated_exchange_amount = $converted_amount->subtract($markup_supplier);
        $exchange_difference       = $transaction->getAmount()->subtract($estimated_exchange_amount);

        if (!$exchange_difference->isZero()) {
            $child_transactions[] = $this->prepareChildTransactionFor(
                $transaction,
                $exchange_difference,
                [TransactionTags::TAG_MC_EXCHANGE_RATE_DIFFERENCE],
                'Exchange rate difference'
            );
        }

        $child_transactions_sum = array_reduce(
            $child_transactions,
            function (Money $carry, Model_Banktransaction $transaction): Money {
                return $carry->add($transaction->getAmount());
            },
            new Money(0, $transaction->getCurrency())
        );

        if (!$transaction->getAmount()->equals($child_transactions_sum)) {
            throw new TransactionHandlerRuntimeException(
                sprintf(
                    'Sum of child transactions amounts %s do not match parent\'s (#%s) amount: %s',
                    Localizer::formatMoney($child_transactions_sum),
                    $transaction->id,
                    Localizer::formatMoney($transaction->getAmount())
                )
            );
        }

        return $child_transactions;
    }

    /**
     * @param string[] $tags
     */
    private function prepareChildTransactionFor(
        Model_Banktransaction $transaction,
        Money $amount,
        array $tags,
        string $description
    ): Model_Banktransaction {
        $child_transaction = $this->model_factory->create(Model_Banktransaction::class);
        $child_transaction->setParentTransaction($transaction);

        $child_transaction->setOffsetAccountName($transaction->getOffsetAccountName());
        $child_transaction->setOffsetAccountNumber($transaction->getOffsetAccountNumber());
        $child_transaction->setDescription($description);

        $child_transaction->setAmount($amount);
        $child_transaction->setTags($tags);
        $child_transaction->addTag(TransactionTags::TAG_MC_CHILD_TRANSACTION);
        $child_transaction->setTagData($transaction->getTagData());

        return $child_transaction;
    }

    public function getTransactionConstraints(): array
    {
        return [
            new HasNoChildTransactions(),
            // Filter out any transactions that is already split.
            new HasSettlement(),
            new IsCreatedAfter(DateTimeImmutable::createFromFormat(
                'Y-m-d',
                '2018-03-19',
                new DateTimeZone('Europe/Amsterdam')
            )),
            new HasAnyOfTags([
                TransactionTags::TAG_CREDITCARD,
                TransactionTags::TAG_CREDITCARD_REFUND,
                TransactionTags::TAG_AMEX_PAYMENT,
                TransactionTags::TAG_AMEX_REFUND,
            ]),
            new DoesntHaveAnyOfTags([TransactionTags::TAG_MC_CHILD_TRANSACTION]),
            // Don't split already-split child transactions.
        ];
    }
}
