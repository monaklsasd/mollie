<?php

declare(strict_types=1);

namespace TransactionHandlers\Splitting;

use Core\Money\PreciseMoney;
use Exception;
use Helper\Database\TransactionCoordinator;
use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use Money\Money;
use Orm\ModelFactory;
use Orm\Repositories\BankTransaction\BankTransactionSettlementRepository;
use Supplier\Mollie\Mollie;
use Supplier\Mollie\Response\BuyRate;
use TransactionHandlers\ChunkedTransactionHandler;
use TransactionHandlers\Constraints\HasAnyOfTags;
use TransactionHandlers\Constraints\HasNegativeAmount;
use TransactionHandlers\Constraints\HasNoChildTransactions;
use TransactionHandlers\Exceptions\TransactionHandlerRuntimeException;
use Validation\ValidatorFactory;
use function count;

class KlarnaFeeSplitter extends ChunkedTransactionHandler
{
    /** @var TransactionCoordinator */
    protected $transaction_coordinator;

    /** @var ModelFactory */
    protected $model_factory;

    /** @var BankTransactionSettlementRepository */
    protected $settlement_repository;

    /** @var Mollie */
    protected $mollie;

    /**
     * IMPORTANT: should be empty at the start of each chunk for this handler to remain stateless
     *
     * @var BuyRate[]
     */
    protected $buy_rates = [];

    /**
     * IMPORTANT: should be empty at the start of each chunk for this handler to remain stateless
     *
     * @var Model_Banktransaction[]
     */
    protected $settlement_transactions = [];

    public function __construct(
        ValidatorFactory $validator_factory,
        TransactionCoordinator $transaction_coordinator,
        ModelFactory $model_factory,
        BankTransactionSettlementRepository $settlement_repository,
        Mollie $mollie
    ) {
        parent::__construct($validator_factory);
        $this->transaction_coordinator = $transaction_coordinator;
        $this->model_factory           = $model_factory;
        $this->settlement_repository   = $settlement_repository;
        $this->mollie                  = $mollie;
    }

    /**
     * @param iterable|Model_Banktransaction[] $transactions
     */
    protected function preChunk(iterable $transactions): void
    {
        $this->buy_rates               = [];
        $this->settlement_transactions = [];

        $klarna_ids = [];

        foreach ($transactions as $transaction) {
            $this->setLastProcessedTransaction($transaction);

            if (!empty($klarna_id = $transaction->getTagData()['transaction_id'] ?? null)) {
                $klarna_ids[] = $transaction->getTagData()['transaction_id'];
            }
        }

        $payment_id_map = [];

        foreach ($this->settlement_repository->findByKlarnaIds($klarna_ids) as $settlement) {
            $payment_id_map[$settlement->getMolliePaymentId()]                      = $settlement->getSupplierTransactionId();
            $this->settlement_transactions[$settlement->getSupplierTransactionId()] = $settlement->getTransaction();
        }

        foreach ($this->mollie->getBuyRate(array_keys($payment_id_map)) as $buy_rate) {
            $this->buy_rates[$payment_id_map[$buy_rate->getPaymentId()]] = $buy_rate;
        }
    }

    protected function postChunk(iterable $transactions): void
    {
        //keep handler stateless
        $this->buy_rates               = [];
        $this->settlement_transactions = [];
    }

    protected function handleTransaction(Model_Banktransaction $transaction): void
    {
        if (empty($klarna_id = $transaction->getTagData()['transaction_id'] ?? null)) {
            $this->logger->warning(sprintf(
                'Klarna Fee transaction #%d doesn\'t have a capture-id, can\'t verify buy-rate.',
                $transaction->getPrimaryKey()
            ));

            return;
        }

        if (($settlement_transaction = $this->settlement_transactions[$klarna_id] ?? null) === null) {
            $this->logger->warning(sprintf(
                'Settlement Transaction not found for Klarna Fee transaction #%d (capture-id: %s).',
                $transaction->getPrimaryKey(),
                $klarna_id
            ));

            return;
        }

        // Add the 'real' transaction type to the fee transaction so it's easier to make totals
        $klarna_subtypes = array_intersect(
            $settlement_transaction->getTags(),
            TransactionTags::KLARNA_SUBTYPE_TAGS
        );

        if (count($klarna_subtypes) > 0 && !$transaction->hasTag($klarna_subtype = reset($klarna_subtypes))) {
            $transaction->addTag($klarna_subtype);
            $transaction->saveOrDie();
        }

        if (($buy_rate = $this->buy_rates[$klarna_id] ?? null) === null) {
            $this->logger->warning(sprintf(
                'Buy rate not returned by Mollie for Klarna Fee transaction #%d (capture-id: %s).',
                $transaction->getPrimaryKey(),
                $klarna_id
            ));

            return;
        }

        /** @var bool|null $is_first_capture */
        if (($is_first_capture = $settlement_transaction->getTagData()['is_first_capture'] ?? null) === null) {
            $this->logger->warning(sprintf(
                'Mollie didn\'t report whether the Settlement Transaction for Klarna Fee transaction #%d (capture-id: %s) was the first of the Order.',
                $transaction->getPrimaryKey(),
                $klarna_id
            ));

            return;
        }

        if (!$transaction->getCurrency()->equals($buy_rate->getRate()->getFixedRate()->getCurrency())) {
            throw new TransactionHandlerRuntimeException(sprintf(
                'Fees in a different currency than the buy rate are currently not supported. Buy rate is %s, fee transaction is %s.',
                $buy_rate->getRate()->getFixedRate()->getCurrency()->getCode(),
                $transaction->getCurrency()->getCode()
            ));
        }

        $expected_fee = self::getExpectedFeeAmount($settlement_transaction->getAmount(), $buy_rate, $is_first_capture);
        $expected_fee = $expected_fee->negative(); // Fee transactions are always negative.

        if ($expected_fee->equals($transaction->getAmount())) {
            return;
        }

        try {
            $this->transaction_coordinator->begin();

            [$expected, $diff] = $this->splitFee($transaction, $expected_fee);

            if (!$expected->getAmount()->isZero()) {
                $expected->saveOrDie(); // fix for first two Klarna transactions where buy-rate is 0.
            }
            $diff->saveOrDie();
            $transaction->saveOrDie();

            $this->transaction_coordinator->commit();
        } catch (Exception $e) {
            $this->transaction_coordinator->rollback();

            throw $e;
        }
    }

    protected function splitFee(
        Model_Banktransaction $transaction,
        Money $expected_fee
    ): array {
        $expected = $this->model_factory->create(Model_Banktransaction::class);

        $expected->setParentTransaction($transaction);
        $expected->setDescription($transaction->getDescription());
        $expected->setAmount($expected_fee);
        $expected->setTags($transaction->getTags());
        $expected->setTagData($transaction->getTagData());

        $diff = $this->model_factory->create(Model_Banktransaction::class);

        $diff->setParentTransaction($transaction);
        $diff->setDescription('Fee difference');
        $diff->setAmount($transaction->getAmount()->subtract($expected_fee));
        $diff->setTags([TransactionTags::TAG_KLARNA_FEE_DIFFERENCE]);
        $diff->setTagData($transaction->getTagData());

        // Remove tags and tagdata from original transaction, not needed anymore.
        $transaction->setTags([]);
        $transaction->setTagData();

        return [$expected, $diff];
    }

    private static function getExpectedFeeAmount(
        Money $settlement_amount,
        BuyRate $buy_rate,
        bool $is_first_capture
    ): Money {
        $fee = PreciseMoney::fromMoney($settlement_amount)->multiply($buy_rate->getRate()->getVariableRate());

        if ($is_first_capture) {
            $fee = $fee->add($buy_rate->getRate()->getFixedRate());
        }

        return $fee->roundToRealAmount()->toMoney(); // TODO: not sure yet, might have to be roundUpToRealAmount.
    }

    public function getTransactionConstraints(): array
    {
        return [
            new HasNoChildTransactions(),
            new HasNegativeAmount(), // omit COMMISSION transactions.
            new HasAnyOfTags([
                TransactionTags::TAG_KLARNA_FEE,
            ]),
        ];
    }
}
