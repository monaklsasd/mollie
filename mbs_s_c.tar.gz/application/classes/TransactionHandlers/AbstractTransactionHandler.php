<?php

declare(strict_types=1);

namespace TransactionHandlers;

use Model_Banktransaction;
use Psr\Log\LoggerAwareTrait;
use Psr\Log\NullLogger;
use Symfony\Component\Validator\Constraint;
use Symfony\Component\Validator\ConstraintViolation;
use Symfony\Component\Validator\ConstraintViolationListInterface;
use TransactionHandlers\Exceptions\TransactionHandlerRuntimeException;
use Validation\ValidatorFactory;

abstract class AbstractTransactionHandler implements TransactionHandler
{
    use LoggerAwareTrait;

    /** @var ValidatorFactory */
    protected $transaction_validator;

    /** @var Model_Banktransaction|null */
    private $last_processed_transaction;

    public function __construct(
        ValidatorFactory $validator_factory
    ) {
        $this->transaction_validator = $validator_factory->createValidator();
        $this->logger                = new NullLogger();
    }

    public function getMaxTries(): int
    {
        return 3;
    }

    public function getRetryDelay(): int
    {
        return 3600;
    }

    /**
     * @return Constraint[]
     */
    protected function getTransactionConstraints(): array
    {
        return [];
    }

    /**
     * @throws TransactionHandlerRuntimeException use this to indicate failures for a single transaction, but continue
     *                                            with the batch
     */
    abstract protected function handleTransaction(Model_Banktransaction $transaction): void;

    /**
     * @param ConstraintViolation[]|ConstraintViolationListInterface $violation_list
     *
     * @return string[]
     */
    protected static function formatConstraintViolationsForLog(ConstraintViolationListInterface $violation_list): array
    {
        $messages = [];

        foreach ($violation_list as $violation) {
            $messages[] = $violation->getMessage();
        }

        return $messages;
    }

    protected function setLastProcessedTransaction(Model_Banktransaction $transaction): void
    {
        $this->last_processed_transaction = $transaction;
    }

    public function getLastProcessedTransaction(): ?Model_Banktransaction
    {
        return $this->last_processed_transaction;
    }
}
