<?php

declare(strict_types=1);

namespace TransactionHandlers\Reporting;

use Model\Transaction\TransactionTags;
use TransactionHandlers\Constraints\HasNoSettlement;
use TransactionHandlers\Constraints\TagExactlyMatches;

/**
 * A transaction handler that receives failed Mollie Direct Debit payments and records.
 */
class DirectDebitFailureReporter extends DirectDebitReporter
{
    public function getTransactionConstraints(): array
    {
        //needs HasNoSettlement() from SettlementReporter, but not the 'tag contains' from DirectDebitReporter, so don't use parent:: here.
        return [
            new HasNoSettlement(),
            new TagExactlyMatches(TransactionTags::TAG_FAILUREDIRECTDEBIT),
        ];
    }
}
