<?php

declare(strict_types=1);

namespace TransactionHandlers\Reporting;

use DateTimeImmutable;
use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use Supplier\Mollie\Mollie;
use Supplier\Mollie\MollieException;
use TransactionHandlers\Constraints\HasPositiveAmount;
use TransactionHandlers\Constraints\IsCreatedAfter;
use TransactionHandlers\Constraints\TagExactlyMatches;
use TransactionHandlers\SingleTransactionHandler;
use Validation\ValidatorFactory;

class ReturnedOutpaymentReporter extends SingleTransactionHandler
{
    public const RETURNED_OUTPAYMENT_FAILED_MESSAGE = 'Outpayment recognized as returned, unable to inform Mollie automatically.';

    /** @var Mollie */
    protected $mollie;

    public function __construct(
        ValidatorFactory $validator_factory,
        Mollie $mollie
    ) {
        parent::__construct($validator_factory);
        $this->mollie = $mollie;
    }

    protected function handleTransaction(Model_Banktransaction $transaction): void
    {
        $this->setLastProcessedTransaction($transaction);

        try {
            $invoice_number = $this->mollie->markOutpaymentReturned(
                $transaction->getOutpaymentReference(),
                $transaction->getAmount(),
                $transaction->getOffsetAccountNumber()
            );

            $transaction->addComment(sprintf(
                'Outpayment recognized as returned, Mollie informed automatically. Invoice number: %s.',
                $invoice_number
            ));
            $transaction->addTagData(['invoice_number' => $invoice_number]);
            $transaction->saveOrDie();
        } catch (MollieException $e) {
            $transaction->addComment(self::RETURNED_OUTPAYMENT_FAILED_MESSAGE);
        }
    }

    protected function getTransactionConstraints(): array
    {
        return [
            new TagExactlyMatches(TransactionTags::TAG_FAILUREOUTPAYMENT),
            new HasPositiveAmount(),
            new IsCreatedAfter(new DateTimeImmutable('2013-10-29')),
        ];
    }
}
