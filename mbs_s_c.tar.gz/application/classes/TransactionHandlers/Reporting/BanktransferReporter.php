<?php

declare(strict_types=1);

namespace TransactionHandlers\Reporting;

use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use Model_TransactionRegistration;
use Supplier\Mollie\MollieException;
use Supplier\Mollie\Response\TransactionReportingResult;
use TransactionHandlers\Constraints\HasPositiveAmount;
use TransactionHandlers\Constraints\TagExactlyMatches;
use TransactionHandlers\Exceptions\TransactionHandlerRuntimeException;
use function Core\Money\money_to_array;

/**
 * A transaction handler that receives Mollie Banktransfer payments and records.
 */
class BanktransferReporter extends SettlementReporter
{
    protected function getPaymentMethodTag(): string
    {
        return TransactionTags::TAG_BANKTRANSFER;
    }

    protected function getUnknownTransactionTag(): string
    {
        return TransactionTags::TAG_UNKNOWNBANKTRANSFER;
    }

    protected function getUnknownTransactionRegistrationType(): string
    {
        return Model_TransactionRegistration::REGISTRATION_UNKNOWN_BANKTRANSFER;
    }

    protected function getFailedTransactionTag(): string
    {
        return TransactionTags::TAG_UNKNOWNBANKTRANSFER;
    }

    protected function getFailedTransactionRegistrationType(): string
    {
        return Model_TransactionRegistration::REGISTRATION_UNKNOWN_BANKTRANSFER;
    }

    protected function processExtraData(
        Model_Banktransaction $transaction,
        TransactionReportingResult $reporting_result
    ): void {
        if ($reporting_result->hasTransactionDetails()
            && $transaction->hasSettlement()
            && $transaction->getSettlement()->hasMolliePaymentId()
        ) {
            $transaction->addTagData([
                'settlement_amount' => money_to_array($reporting_result->getTransactionDetails()->getSettlementAmount()),
            ]);

            $transaction->saveOrDie();
        }
    }

    /**
     * This block is here to rewrite the error message. for banktransfers, timeouts are a bigger issue than for
     * all other payment methods.
     *
     * @throws TransactionHandlerRuntimeException
     */
    protected function preChunk(iterable $transactions): void
    {
        try {
            parent::preChunk($transactions);
        } catch (TransactionHandlerRuntimeException $e) {
            // Add an extra log entry that contains instructions for a fix, then throw the original.
            if ($e->getPrevious() instanceof MollieException) {
                $this->logger->critical(
                    'The reporting of banktransfer settlements to Mollie failed! ' .
                    'Please make sure this chunk didn\'t contain any expired payments. ' .
                    'Look at mbs/scripts/fixes/recon-846-return-expired-banktransfers.php for a previous fix.',
                    ['exception' => $e]
                );
            }

            throw $e;
        }
    }

    public function getTransactionConstraints(): array
    {
        return array_merge(parent::getTransactionConstraints(), [
            new HasPositiveAmount(),
            new TagExactlyMatches(TransactionTags::TAG_BANKTRANSFER),
        ]);
    }
}
