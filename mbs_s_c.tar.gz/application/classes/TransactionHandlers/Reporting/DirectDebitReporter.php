<?php

declare(strict_types=1);

namespace TransactionHandlers\Reporting;

use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use Model_TransactionRegistration;
use Supplier\Mollie\Response\TransactionReportingResult;
use TransactionHandlers\Constraints\HasAnyOfTags;
use TransactionHandlers\Constraints\ParentTagExactlyMatches;

/**
 * A transaction handler that receives Mollie Direct Debit payments and records.
 */
class DirectDebitReporter extends SettlementReporter
{
    protected function processExtraData(
        Model_Banktransaction $transaction,
        TransactionReportingResult $reporting_result
    ): void {
        $this->setLastProcessedTransaction($transaction);

        if (($chargeback_payment_id = $reporting_result->getExtraData('chargeback_payment_id'))
            && !$transaction->hasTag(TransactionTags::TAG_STORNODIRECTDEBIT)
        ) {
            $transaction->setTags([TransactionTags::TAG_STORNODIRECTDEBIT]);
            $transaction->addComment(sprintf(
                'Linked to "chargeback": %s',
                $this->getMolliePaymentLink((int)$chargeback_payment_id)
            ));
            $transaction->saveOrDie();
        }
    }

    /**
     * Child transaction of tag 'sepa' should have tag 'directdebit'
     */
    protected function getPaymentMethodTag(): string
    {
        return TransactionTags::TAG_DIRECTDEBIT;
    }

    protected function getUnknownTransactionTag(): string
    {
        return TransactionTags::TAG_UNKNOWNDIRECTDEBIT;
    }

    protected function getUnknownTransactionRegistrationType(): string
    {
        return Model_TransactionRegistration::REGISTRATION_UNKNOWN_DIRECTDEBIT;
    }

    protected function getFailedTransactionTag(): string
    {
        return TransactionTags::TAG_FAILUREDIRECTDEBIT;
    }

    protected function getFailedTransactionRegistrationType(): string
    {
        return Model_TransactionRegistration::REGISTRATION_FAILURE_DIRECTDEBIT;
    }

    public function getTransactionConstraints(): array
    {
        return array_merge(parent::getTransactionConstraints(), [
            new HasAnyOfTags([TransactionTags::TAG_DIRECTDEBIT]),
            new ParentTagExactlyMatches(TransactionTags::TAG_SEPA),
        ]);
    }
}
