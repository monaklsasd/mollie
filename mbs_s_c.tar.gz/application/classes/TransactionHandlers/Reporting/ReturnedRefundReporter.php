<?php

declare(strict_types=1);

namespace TransactionHandlers\Reporting;

use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use Model_TransactionRegistration;
use Supplier\Mollie\Mollie;
use Supplier\Mollie\MollieException;
use TransactionHandlers\Constraints\IsReturnedTransaction;
use TransactionHandlers\Constraints\TagExactlyMatches;
use TransactionHandlers\Exceptions\TransactionHandlerRuntimeException;
use TransactionHandlers\SingleTransactionHandler;
use Validation\ValidatorFactory;
use function Core\Money\money_to_string;

class ReturnedRefundReporter extends SingleTransactionHandler
{
    /** @var Mollie */
    protected $mollie;

    public function __construct(
        ValidatorFactory $validator_factory,
        Mollie $mollie
    ) {
        parent::__construct($validator_factory);
        $this->mollie = $mollie;
    }

    protected function getTransactionConstraints(): array
    {
        return array_merge(parent::getTransactionConstraints(), [
            new TagExactlyMatches(TransactionTags::TAG_FAILUREREFUND),
            new IsReturnedTransaction(),
        ]);
    }

    protected function handleTransaction(Model_Banktransaction $transaction): void
    {
        $this->setLastProcessedTransaction($transaction);

        if (empty($transaction->getTagData()['transaction_id'])) {
            $transaction->recordUnknown(
                [TransactionTags::TAG_UNKNOWNREFUND],
                Model_TransactionRegistration::REGISTRATION_UNKNOWN_REFUND
            );

            return;
        }

        try {
            $this->mollie->informRefundFailed($transaction);
        } catch (MollieException $e) {
            throw new TransactionHandlerRuntimeException($e->getMessage(), $e->getCode(), $e);
        }

        $transaction->addComment('Refund recognized as returned, Mollie informed automatically.'); //has save built in
        $transaction->setTags([TransactionTags::TAG_FAILUREIDEAL, TransactionTags::TAG_REFUNDS]);
        $transaction->addTagData([
            'account_number' => $transaction->getOffsetAccountNumber(),
            'amount'         => (float)money_to_string($transaction->getAmount()),
        ]);
        $transaction->saveOrDie();
    }
}
