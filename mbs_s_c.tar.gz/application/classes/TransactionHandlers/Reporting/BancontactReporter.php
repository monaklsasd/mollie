<?php

declare(strict_types=1);

namespace TransactionHandlers\Reporting;

use Config_Bankaccountverification;
use Helper\Database\TransactionCoordinator;
use Helper_Banktransaction_Matching;
use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use Model_TransactionRegistration;
use Orm\ModelFactory;
use Orm\Repositories\ValitorStatementsReExpandedRepository;
use Supplier\Mccs\Mccs;
use Supplier\Mccs\ReferenceNotFoundException;
use Supplier\Mollie\Mollie;
use TransactionHandlers\Constraints\HasPositiveAmount;
use TransactionHandlers\Constraints\TagExactlyMatches;
use Validation\ValidatorFactory;

/**
 * A transaction handler that receives Mollie Mister Cash payments and records.
 */
class BancontactReporter extends SettlementReporter
{
    /** @var Mccs */
    protected $mccs;

    public function __construct(
        ValidatorFactory $validator_factory,
        Mollie $mollie,
        Config_Bankaccountverification $config,
        ModelFactory $model_factory,
        TransactionCoordinator $transaction_coordinator,
        Mccs $mccs,
        ValitorStatementsReExpandedRepository $valitor_statements_re_expanded_repository
    ) {
        parent::__construct(
            $validator_factory,
            $mollie,
            $config,
            $model_factory,
            $transaction_coordinator,
            $valitor_statements_re_expanded_repository
        );
        $this->mccs = $mccs;
    }

    protected function getPaymentMethodTag(): string
    {
        return TransactionTags::TAG_MISTERCASH;
    }

    protected function getUnknownTransactionTag(): string
    {
        return TransactionTags::TAG_UNKNOWNMISTERCASH;
    }

    protected function getUnknownTransactionRegistrationType(): string
    {
        return Model_TransactionRegistration::REGISTRATION_UNKNOWN_MISTERCASH;
    }

    protected function getFailedTransactionTag(): string
    {
        return TransactionTags::TAG_FAILUREMISTERCASH;
    }

    protected function getFailedTransactionRegistrationType(): string
    {
        return Model_TransactionRegistration::REGISTRATION_FAILURE_MISTERCASH;
    }

    protected function preChunk(iterable $transactions): void
    {
        foreach ($transactions as $index => $transaction) {
            if (!$this->resolveTransactionIdsFromDescription($transaction)) {
                unset($transactions[$index]); //skip this transaction for now
            }
        }
        parent::preChunk($transactions);
    }

    protected function resolveTransactionIdsFromDescription(Model_Banktransaction $transaction): bool
    {
        $paybox_reference = Helper_Banktransaction_Matching::get_paybox_reference($transaction->getDescription());

        if ($paybox_reference === null) {
            $this->logger->warning(sprintf(
                'No paybox reference found for transaction %s. Maybe it was paid out in bulk?',
                $transaction->getPrimaryKey()
            ));

            return false;
        }

        try {
            $mccs_transaction_id = $this->mccs->getTransactionIdForPayboxReferenceAction($paybox_reference);

            $transaction->setTagData([
                'transaction_id'   => $mccs_transaction_id,
                'paybox_reference' => $paybox_reference,
            ]);
            $transaction->saveOrDie();

            return true;
        } catch (ReferenceNotFoundException $e) {
            // Recording it as unknown will make sure the transaction is skipped on the next run (tag is changed).
            $transaction->recordUnknown(
                [$this->getUnknownTransactionTag()],
                $this->getUnknownTransactionRegistrationType()
            );

            $this->logger->warning(sprintf(
                'No MCCS transaction found for transaction %s. It\'s paybox reference is %s.',
                $transaction->getPrimaryKey(),
                $paybox_reference
            ));

            return false;
        }
    }

    /**
     * {@inheritdoc}
     */
    public function getTransactionConstraints(): array
    {
        return array_merge(parent::getTransactionConstraints(), [
            new HasPositiveAmount(),
            new TagExactlyMatches(TransactionTags::TAG_MISTERCASH),
        ]);
    }
}
