<?php

declare(strict_types=1);

namespace TransactionHandlers\Reporting;

use Model\Transaction\TransactionTags;
use Model_TransactionRegistration;
use TransactionHandlers\Constraints\HasPositiveAmount;
use TransactionHandlers\Constraints\TagExactlyMatches;

/**
 * A transaction handler that receives Mollie Belfius Payment Button payments and records.
 */
class BelfiusReporter extends SettlementReporter
{
    protected function getPaymentMethodTag(): string
    {
        return TransactionTags::TAG_BELFIUS;
    }

    protected function getUnknownTransactionTag(): string
    {
        return TransactionTags::TAG_UNKNOWNBELFIUS;
    }

    protected function getUnknownTransactionRegistrationType(): string
    {
        return Model_TransactionRegistration::REGISTRATION_UNKNOWN_BELFIUS;
    }

    protected function getFailedTransactionTag(): string
    {
        return TransactionTags::TAG_FAILUREBELFIUS;
    }

    protected function getFailedTransactionRegistrationType(): string
    {
        return Model_TransactionRegistration::REGISTRATION_FAILURE_BELFIUS;
    }

    public function getTransactionConstraints(): array
    {
        return array_merge(parent::getTransactionConstraints(), [
            new HasPositiveAmount(),
            new TagExactlyMatches(TransactionTags::TAG_BELFIUS),
        ]);
    }
}
