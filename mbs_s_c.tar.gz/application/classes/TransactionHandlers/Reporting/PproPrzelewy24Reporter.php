<?php

declare(strict_types=1);

namespace TransactionHandlers\Reporting;

use Model\Transaction\TransactionTags;
use Model_TransactionRegistration;
use TransactionHandlers\Constraints\HasAnyOfTags;
use TransactionHandlers\Constraints\ParentTagExactlyMatches;

/**
 * A transaction handler that reports Przelewy24 payments done through PPRO.
 */
class PproPrzelewy24Reporter extends SettlementReporter
{
    protected function getPaymentMethodTag(): string
    {
        return TransactionTags::TAG_PRZELEWY24;
    }

    protected function getUnknownTransactionTag(): string
    {
        return TransactionTags::TAG_UNKNOWNPRZELEWY24;
    }

    protected function getUnknownTransactionRegistrationType(): string
    {
        return Model_TransactionRegistration::REGISTRATION_UNKNOWN_PPRO;
    }

    protected function getFailedTransactionTag(): string
    {
        return TransactionTags::TAG_FAILUREPRZELEWY24;
    }

    protected function getFailedTransactionRegistrationType(): string
    {
        return Model_TransactionRegistration::REGISTRATION_FAILURE_PPRO;
    }

    /**
     * {@inheritdoc}
     */
    public function getTransactionConstraints(): array
    {
        return array_merge(parent::getTransactionConstraints(), [
            new ParentTagExactlyMatches(TransactionTags::TAG_PPRO_SETTLEMENT_EXPANDED),
            new HasAnyOfTags([
                TransactionTags::TAG_PPRO_PAYMENT,
                TransactionTags::TAG_PPRO_REFUND,
            ]),
            new HasAnyOfTags([TransactionTags::TAG_PRZELEWY24]),
        ]);
    }
}
