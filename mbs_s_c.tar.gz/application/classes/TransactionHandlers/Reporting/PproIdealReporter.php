<?php

declare(strict_types=1);

namespace TransactionHandlers\Reporting;

use Model\Transaction\TransactionTags;
use Model_TransactionRegistration;
use TransactionHandlers\Constraints\HasAnyOfTags;
use TransactionHandlers\Constraints\ParentTagExactlyMatches;

/**
 * A transaction handler that reports iDEAL payments done through PPRO.
 */
class PproIdealReporter extends SettlementReporter
{
    protected function getPaymentMethodTag(): string
    {
        return TransactionTags::TAG_IDEAL;
    }

    protected function getUnknownTransactionTag(): string
    {
        return TransactionTags::TAG_UNKNOWNIDEAL;
    }

    protected function getUnknownTransactionRegistrationType(): string
    {
        return Model_TransactionRegistration::REGISTRATION_UNKNOWN_PPRO;
    }

    protected function getFailedTransactionTag(): string
    {
        return TransactionTags::TAG_FAILUREIDEAL;
    }

    protected function getFailedTransactionRegistrationType(): string
    {
        return Model_TransactionRegistration::REGISTRATION_FAILURE_IDEAL;
    }

    /**
     * {@inheritdoc}
     */
    public function getTransactionConstraints(): array
    {
        return array_merge(parent::getTransactionConstraints(), [
            new ParentTagExactlyMatches(TransactionTags::TAG_PPRO_SETTLEMENT_EXPANDED),
            new HasAnyOfTags([
                TransactionTags::TAG_PPRO_PAYMENT,
                TransactionTags::TAG_PPRO_REFUND,
            ]),
            new HasAnyOfTags([TransactionTags::TAG_IDEAL]),
        ]);
    }
}
