<?php

declare(strict_types=1);

namespace TransactionHandlers\Reporting;

use Config_Bankaccountverification;
use Exception;
use Helper\Database\TransactionCoordinator;
use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use Model_Banktransaction_Settlement;
use Model_Exception_Save;
use Orm\ModelFactory;
use Orm\Repositories\ValitorStatementsReExpandedRepository;
use Supplier\Mollie\Mollie;
use Supplier\Mollie\MollieException;
use Supplier\Mollie\Response\TransactionDetails;
use Supplier\Mollie\Response\TransactionReportingResult;
use Supplier\Mollie\Response\TransactionReportingStatus;
use TransactionHandlers\ChunkedTransactionHandler;
use TransactionHandlers\Constraints\HasNoSettlement;
use TransactionHandlers\Exceptions\TransactionHandlerRuntimeException;
use TransactionHandlers\Reporting\Exception\InvalidMollieResponseException;
use Validation\ValidatorFactory;
use function in_array;

/**
 * A transaction handler to inform Mollie that a payment has been received
 */
abstract class SettlementReporter extends ChunkedTransactionHandler
{
    /** @var Mollie */
    protected $mollie;

    /** @var Config_Bankaccountverification */
    protected $config;

    /** @var ModelFactory */
    protected $model_factory;

    /** @var TransactionCoordinator */
    protected $transaction_coordinator;

    /**
     * IMPORTANT: should be reset at the start of ::run for this handler to remain stateless
     *
     * @var int
     */
    protected $unknown_transaction_count = 0;

    /**
     * IMPORTANT: should be reset at the start of ::run for this handler to remain stateless
     *
     * @var int
     */
    protected $failed_transaction_count = 0;

    /**
     * IMPORTANT: should be empty at the start of each chunk for this handler to remain stateless
     *
     * @var TransactionReportingResult[]
     *
     * @example [$banktransaction_id => $data]
     */
    protected $mollie_settlement_reponses = [];

    /** @var ValitorStatementsReExpandedRepository */
    private $valitor_statements_re_expanded_repository;

    public function __construct(
        ValidatorFactory $validator_factory,
        Mollie $mollie,
        Config_Bankaccountverification $config,
        ModelFactory $model_factory,
        TransactionCoordinator $transaction_coordinator,
        ValitorStatementsReExpandedRepository $valitor_statements_re_expanded_repository
    ) {
        parent::__construct($validator_factory);

        $this->mollie                                    = $mollie;
        $this->config                                    = $config;
        $this->model_factory                             = $model_factory;
        $this->transaction_coordinator                   = $transaction_coordinator;
        $this->valitor_statements_re_expanded_repository = $valitor_statements_re_expanded_repository;
    }

    protected function getTransactionConstraints(): array
    {
        return array_merge(
            parent::getTransactionConstraints(),
            [
                new HasNoSettlement(),
            ]
        );
    }

    public function run(iterable $transactions): bool
    {
        $this->unknown_transaction_count = 0; //this makes sure no data caries over between runs, DON'T REMOVE
        $this->failed_transaction_count  = 0;

        $result = parent::run($transactions);

        if ($this->unknown_transaction_count > 0) {
            $this->logger->notice(
                sprintf(
                    'Received %d %s transaction(s) that Mollie didn\'t recognize',
                    $this->unknown_transaction_count,
                    $this->getPaymentMethodTag()
                )
            );
        }

        if ($this->failed_transaction_count > 0) {
            $this->logger->notice(
                sprintf(
                    'Received %d %s transaction(s) that Mollie could not settle because of a failure',
                    $this->failed_transaction_count,
                    $this->getPaymentMethodTag()
                )
            );
        }

        return $result;
    }

    protected function preChunk(iterable $transactions): void
    {
        $is_re_expanded_valitor_settlement = null;

        $settlements = [];

        /** @var Model_Banktransaction[] $transactions */
        foreach ($transactions as $key => $transaction) {
            if ($is_re_expanded_valitor_settlement === null) {
                $is_re_expanded_valitor_settlement = $this->valitor_statements_re_expanded_repository->isCurrentlyReExpandingValitorStatement(
                    $transaction->getStatement()
                );
            }

            /*
             * We link the settlement to the transaction immediately here, it works because settlement->save is not
             * triggered between preChuck & handleTransaction, but this has to be covered by tests.
             *
             * Or use a temporary settlement here to trigger the api call, and create the 'real' one below
             * in the success function.
             *
             * TODO!
             */
            $settlement = $this->model_factory->create(Model_Banktransaction_Settlement::class);
            $settlement->fromTransaction(
                $transaction,
                $this->getSupplierTransactionId($transaction),
                $this->getPaymentMethodTag()
            );

            $transaction->setSettlement($settlement);
            $settlements[] = $transaction->getSettlement();
        }

        try {
            $this->mollie_settlement_reponses = $this->mollie->informTransactionsReceived(
                $settlements,
                $is_re_expanded_valitor_settlement
            );
        } catch (MollieException $e) {
            throw new TransactionHandlerRuntimeException(
                sprintf(
                    'An exception occurred while trying to inform Mollie of received transactions: %s',
                    $e->getMessage()
                ),
                0,
                $e
            );
        }
    }

    protected function postChunk(iterable $transactions): void
    {
        $this->mollie_settlement_reponses = []; //keep handler stateless
    }

    protected function handleTransaction(Model_Banktransaction $transaction): void
    {
        if (!isset($this->mollie_settlement_reponses[$transaction->getPrimaryKey()])) {
            throw new InvalidMollieResponseException(
                sprintf(
                    'No result returned by Mollie for banktransaction #%d.',
                    $transaction->getPrimaryKey()
                )
            );
        }

        try {
            $this->transaction_coordinator->begin();

            $reporting_result = $this->mollie_settlement_reponses[$transaction->getPrimaryKey()];

            if (!(
                TransactionReportingStatus::NOT_FOUND()->equals($reporting_result->getStatus()) || TransactionReportingStatus::SKIPPED()->equals($reporting_result->getStatus())
            ) && !$reporting_result->hasTransactionDetails()
            ) {
                throw new InvalidMollieResponseException(
                    sprintf(
                        'No transaction details returned by Mollie for banktransaction #%d.',
                        $transaction->getPrimaryKey()
                    )
                );
            }

            switch ($reporting_result->getStatus()->getValue()) {
                /*
                 * Failed settlement
                 */
                case TransactionReportingStatus::INVALID_AMOUNT()->getValue():
                    $this->failed_transaction_count++;

                    $this->recordTransactionAsFailed($transaction);

                    $transaction->addComment(
                        sprintf(
                            'Invalid amount received for payment: %s',
                            $this->getMolliePaymentLink($reporting_result->getTransactionDetails()->getPaymentId())
                        )
                    );

                    break;
                /*
                 * Failed settlement
                 */
                case TransactionReportingStatus::NOT_PAID()->getValue():
                    $this->failed_transaction_count++;

                    $this->recordTransactionAsFailed($transaction);

                    $transaction->addComment(
                        sprintf(
                            '"Payment": %s  not paid in Mollie.',
                            $this->getMolliePaymentLink($reporting_result->getTransactionDetails()->getPaymentId())
                        )
                    );

                    break;
                /*
                 * Failed settlement
                 */
                case TransactionReportingStatus::ALREADY_SETTLED()->getValue():
                    $this->failed_transaction_count++;

                    $this->recordTransactionAsFailed($transaction);

                    $transaction->addComment(
                        sprintf(
                            '"Payment": %s received twice.',
                            $this->getMolliePaymentLink($reporting_result->getTransactionDetails()->getPaymentId())
                        )
                    );

                    break;
                /*
                 * Unknown transaction
                 */
                case TransactionReportingStatus::NOT_FOUND()->getValue():
                    $this->unknown_transaction_count++;

                    $this->recordTransactionAsUnknown($transaction);

                    break;
                /*
                 * Mollie has already once processed this transaction for this payment, everything matches.
                 * Probably MBS is reporting this for the second time.
                 */
                case TransactionReportingStatus::SKIPPED()->getValue():
                    if ($this->isAlreadyReportedToMollieSuccessfully($transaction, $reporting_result)) {
                        /*
                         * This transaction has already been marked as "settled" and coupled with a payment.
                         * Nothing to do.
                         */
                        break;
                    }

                /*
                 * If no settlement exists for transaction, and we receive a "SKIPPED" status, then it means this
                 * is a duplicate report that could not have been previously handled correctly by MBS. So, continue
                 * as if it's a success.
                 */

                /*
                 * Successful settlement
                 */
                // no break
                case TransactionReportingStatus::SUCCESS()->getValue():
                    $details = $reporting_result->getTransactionDetails();

                    $transaction->getSettlement()->setMolliePaymentId($details->getPaymentId());

                    if ($this->isBankVerificationPayment($details)) {
                        $transaction->addTag(TransactionTags::TAG_BOARDING);
                        $transaction->saveOrDie();
                    }

                    if ($transaction->getOffsetAccountNumber() === null && $details->getConsumerIban() !== null) {
                        $transaction->setOffsetAccountNumber($details->getConsumerIban());
                        $transaction->setOffsetAccountBic($details->getConsumerBic());
                        $transaction->saveOrDie();
                    }

                    $transaction->addComment(
                        sprintf(
                            'Linked to "payment": %s',
                            $this->getMolliePaymentLink($details->getPaymentId())
                        )
                    );

                    break;

                default:
                    throw new TransactionHandlerRuntimeException(
                        sprintf(
                            'Unknown status %s returned by Mollie for banktransaction #%d.',
                            $reporting_result->getStatus()->getValue(),
                            $transaction->getPrimaryKey()
                        )
                    );

                    break;
            }

            $this->processExtraData($transaction, $reporting_result);

            if ($transaction->hasSettlement() && $transaction->getSettlement()->hasMolliePaymentId()) {
                $transaction->getSettlement()->saveOrDie();
            }

            if ($reporting_result->isHandledByLedger()) {
                $transaction->setAsLedgerTransaction();
                $transaction->saveOrDie();
            }

            // addComment and recordUnknown trigger save immediately, this commits those changes.
            $this->transaction_coordinator->commit();
        } catch (Exception $e) {
            $this->transaction_coordinator->rollback();

            if ($e instanceof Model_Exception_Save) {
                throw new TransactionHandlerRuntimeException(
                    sprintf(
                        'Failed to save settlement for transaction %d after notifying Mollie',
                        $transaction->getPrimaryKey()
                    ),
                    0,
                    $e
                );
            }

            throw $e;
        }
    }

    private function isBankVerificationPayment(TransactionDetails $transaction_details): bool
    {
        if (!$this->bankAccountSupportsBankVerificationPayments()) {
            return false;
        }

        return $transaction_details->getCustomerId() === $this->config->getVerificationAccountId();
    }

    private function bankAccountSupportsBankVerificationPayments()
    {
        return in_array(
            $this->getPaymentMethodTag(),
            TransactionTags::POSSIBLE_BANKACCOUNT_VERIFICATION_TAGS,
            true
        );
    }

    private function isAlreadyReportedToMollieSuccessfully(
        Model_Banktransaction $bank_transaction,
        TransactionReportingResult $transaction_reporting_result
    ): bool {
        if (!$transaction_reporting_result->hasTransactionDetails()) {
            return false;
        }

        return $bank_transaction->hasSettlement() && $bank_transaction->getSettlement()->hasMolliePaymentId();
    }

    protected function getMolliePaymentLink(int $mollie_payment_id): string
    {
        return sprintf(
            '%s/admin/payments/show/%d',
            $this->mollie->getMollieHostname(),
            $mollie_payment_id
        );
    }

    /**
     * Get the supplier transaction id from the transaction. The transaction id can be understood by the Mollie
     * application.
     *
     * @throws TransactionHandlerRuntimeException
     */
    protected function getSupplierTransactionId(Model_Banktransaction $transaction): string
    {
        $supplier_transaction_id = $transaction->getSupplierTransactionId();

        if ($supplier_transaction_id === null) {
            throw new TransactionHandlerRuntimeException(
                sprintf(
                    'Error fetching supplier transaction id from tag data for transaction #%d',
                    $transaction->id
                )
            );
        }

        return $supplier_transaction_id;
    }

    protected function recordTransactionAsUnknown(Model_Banktransaction $transaction): void
    {
        $transaction->setSettlement(null);
        $transaction->recordUnknown(
            [$this->getUnknownTransactionTag()],
            $this->getUnknownTransactionRegistrationType()
        );
    }

    protected function recordTransactionAsFailed(Model_Banktransaction $transaction): void
    {
        $transaction->setSettlement(null);
        $transaction->recordUnknown(
            [$this->getFailedTransactionTag()],
            $this->getFailedTransactionRegistrationType()
        );
    }

    /**
     * @return string One of the TransactionTags::TAG_* constants.
     */
    abstract protected function getPaymentMethodTag(): string;

    /**
     * @return string One of the TransactionTags::TAG_* constants.
     */
    abstract protected function getUnknownTransactionTag(): string;

    /**
     * @return string One of the Model_TransactionRegistration::REGISTRATION_* constants.
     */
    abstract protected function getUnknownTransactionRegistrationType(): string;

    /**
     * @return string One of the TransactionTags::TAG_* constants.
     */
    abstract protected function getFailedTransactionTag(): string;

    /**
     * @return string One of the Model_TransactionRegistration::REGISTRATION_* constants.
     */
    abstract protected function getFailedTransactionRegistrationType(): string;

    /**
     * Process extra data retrieved from Mollie
     */
    protected function processExtraData(
        Model_Banktransaction $transaction,
        TransactionReportingResult $reporting_result
    ): void {
        // Overwrite method if necessary, don't forget to save changed entities.
    }
}
