<?php

declare(strict_types=1);

namespace TransactionHandlers\Reporting;

use App\Ledger\CanGetPrepaymentSettlementReferenceTrait;
use App\Ledger\LedgerTransactionException;
use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use Supplier\Mollie\Mollie;
use Supplier\Mollie\MollieException;
use TransactionHandlers\Constraints\HasPositiveAmount;
use TransactionHandlers\Constraints\TagExactlyMatches;
use TransactionHandlers\Exceptions\TransactionHandlerRuntimeException;
use TransactionHandlers\SingleTransactionHandler;
use Validation\ValidatorFactory;

class PrepaymentSettlementReporter extends SingleTransactionHandler
{
    use CanGetPrepaymentSettlementReferenceTrait;

    /** @var Mollie */
    protected $mollie_supplier;

    public function __construct(
        ValidatorFactory $validator_factory,
        Mollie $mollie
    ) {
        parent::__construct($validator_factory);

        $this->mollie_supplier = $mollie;
    }

    /**
     * @throws TransactionHandlerRuntimeException
     */
    protected function handleTransaction(Model_Banktransaction $transaction): void
    {
        $this->setLastProcessedTransaction($transaction);

        try {
            $this->mollie_supplier->markPrepaymentSettlementSettled(
                $this->getPrepaymentSettlementReference($transaction)
            );

            $transaction->addComment('Successfully informed Mollie about prepayment settlement.');
        } catch (MollieException $e) {
            $transaction->addComment('Prepayment settlement was deducted but was not recognized by Mollie.');
        } catch (LedgerTransactionException $e) {
            throw new TransactionHandlerRuntimeException($e->getMessage(), $e->getCode(), $e);
        }
    }

    protected function getTransactionConstraints(): array
    {
        return [
            new TagExactlyMatches(TransactionTags::TAG_PREPAYMENT_SETTLEMENT_RECEIVED),
            new HasPositiveAmount(),
        ];
    }
}
