<?php

declare(strict_types=1);

namespace TransactionHandlers\Reporting;

use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use Model_TransactionRegistration;
use Supplier\Mollie\Response\TransactionReportingResult;
use Supplier\Mollie\Response\TransactionReportingStatus;
use TransactionHandlers\Constraints\HasAnyOfTags;
use TransactionHandlers\Constraints\ParentTagExactlyMatches;
use TransactionHandlers\Reporting\Exception\InvalidMollieResponseException;

/**
 * A transaction handler that reports Klarna payments.
 */
class KlarnaReporter extends SettlementReporter
{
    protected function getPaymentMethodTag(): string
    {
        return TransactionTags::TAG_KLARNA;
    }

    protected function getUnknownTransactionTag(): string
    {
        return TransactionTags::TAG_UNKNOWNKLARNA;
    }

    protected function getUnknownTransactionRegistrationType(): string
    {
        return Model_TransactionRegistration::REGISTRATION_UNKNOWN_KLARNA;
    }

    protected function getFailedTransactionTag(): string
    {
        return TransactionTags::TAG_FAILUREKLARNA;
    }

    protected function getFailedTransactionRegistrationType(): string
    {
        return Model_TransactionRegistration::REGISTRATION_FAILURE_KLARNA;
    }

    /**
     * {@inheritdoc}
     */
    public function getTransactionConstraints(): array
    {
        return array_merge(parent::getTransactionConstraints(), [
            new ParentTagExactlyMatches(TransactionTags::TAG_KLARNA_SETTLEMENT_EXPANDED),
            new HasAnyOfTags([
                TransactionTags::TAG_KLARNA,
                TransactionTags::TAG_KLARNA_REFUND,
                TransactionTags::TAG_KLARNA_CHARGEBACK,
            ]),
        ]);
    }

    protected function processExtraData(
        Model_Banktransaction $transaction,
        TransactionReportingResult $reporting_result
    ): void {
        if (!$reporting_result->getStatus()->equals(TransactionReportingStatus::SUCCESS())) {
            // Unsuccessful reporting result, no additional data to process.
            return;
        }

        $payment_subtype = $reporting_result->getTransactionDetails()->getPaymentMethod();

        if (!in_array($payment_subtype, TransactionTags::KLARNA_SUBTYPE_TAGS, true)) {
            throw new InvalidMollieResponseException(sprintf(
                'Mollie returned an invalid subtype: %s. Valid subtypes: %s',
                $payment_subtype,
                implode(', ', TransactionTags::KLARNA_SUBTYPE_TAGS)
            ));
        }

        $transaction->addTag($payment_subtype);
        $transaction->saveOrDie();

        if (null !== $is_first_capture = $reporting_result->getExtraData('is_first_capture')) {
            $transaction->addTagData(['is_first_capture' => (bool)$is_first_capture]);
            $transaction->saveOrDie();
        }
    }
}
