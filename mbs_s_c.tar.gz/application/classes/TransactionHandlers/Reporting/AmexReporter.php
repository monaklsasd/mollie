<?php

declare(strict_types=1);

namespace TransactionHandlers\Reporting;

use Model\Transaction\TransactionTags;
use Model_TransactionRegistration;
use TransactionHandlers\Constraints\HasAnyOfTags;
use TransactionHandlers\Constraints\ParentTagExactlyMatches;

/**
 * A transaction handler that receives Mollie AMEX payments.
 */
class AmexReporter extends SettlementReporter
{
    protected function getPaymentMethodTag(): string
    {
        return TransactionTags::TAG_CREDITCARD;
    }

    protected function getUnknownTransactionTag(): string
    {
        return TransactionTags::TAG_UNKNOWNAMEX;
    }

    protected function getUnknownTransactionRegistrationType(): string
    {
        return Model_TransactionRegistration::REGISTRATION_UNKNOWN_AMEX;
    }

    protected function getFailedTransactionTag(): string
    {
        return TransactionTags::TAG_FAILUREAMEX;
    }

    protected function getFailedTransactionRegistrationType(): string
    {
        return Model_TransactionRegistration::REGISTRATION_FAILURE_AMEX;
    }

    public function getTransactionConstraints(): array
    {
        return array_merge(parent::getTransactionConstraints(), [
            new HasAnyOfTags([
                TransactionTags::TAG_AMEX_PAYMENT,
                TransactionTags::TAG_AMEX_REFUND,
            ]),
            new ParentTagExactlyMatches(TransactionTags::TAG_AMEX_SETTLEMENT_EXPANDED),
        ]);
    }
}
