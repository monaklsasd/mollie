<?php

declare(strict_types=1);

namespace TransactionHandlers\Reporting;

use DateTimeImmutable;
use DateTimeZone;
use Model\Transaction\TransactionTags;
use Model_TransactionRegistration;
use TransactionHandlers\Constraints\IsCreatedAfter;
use TransactionHandlers\Constraints\OptionalParentHasAnyOfTags;
use TransactionHandlers\Constraints\TagExactlyMatches;

class RefundReporter extends SettlementReporter
{
    protected function getPaymentMethodTag(): string
    {
        return TransactionTags::TAG_REFUNDS;
    }

    protected function getUnknownTransactionTag(): string
    {
        return TransactionTags::TAG_UNKNOWNREFUND;
    }

    protected function getUnknownTransactionRegistrationType(): string
    {
        return Model_TransactionRegistration::REGISTRATION_UNKNOWN_REFUND;
    }

    protected function getFailedTransactionTag(): string
    {
        return TransactionTags::TAG_FAILUREREFUND;
    }

    protected function getFailedTransactionRegistrationType(): string
    {
        return Model_TransactionRegistration::REGISTRATION_FAILURE_REFUND;
    }

    public function getTransactionConstraints(): array
    {
        return array_merge(parent::getTransactionConstraints(), [
            new TagExactlyMatches(TransactionTags::TAG_REFUNDS),
            new IsCreatedAfter(DateTimeImmutable::createFromFormat('Y-m-d', '2016-07-11', new DateTimeZone('Europe/Amsterdam'))),
            new OptionalParentHasAnyOfTags([TransactionTags::TAG_SEPA]),
        ]);
    }
}
