<?php

declare(strict_types=1);

namespace TransactionHandlers\Reporting;

use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use Model_TransactionRegistration;
use TransactionHandlers\Constraints\HasPositiveAmount;
use TransactionHandlers\Constraints\TagExactlyMatches;
use TransactionHandlers\Exceptions\TransactionHandlerRuntimeException;

/**
 * A transaction handler that receives iDEAL payments and records.
 */
class IdealReporter extends SettlementReporter
{
    protected function getPaymentMethodTag(): string
    {
        return TransactionTags::TAG_IDEAL;
    }

    protected function getUnknownTransactionTag(): string
    {
        return TransactionTags::TAG_UNKNOWNIDEAL;
    }

    protected function getUnknownTransactionRegistrationType(): string
    {
        return Model_TransactionRegistration::REGISTRATION_UNKNOWN_IDEAL;
    }

    protected function getFailedTransactionTag(): string
    {
        return TransactionTags::TAG_FAILUREIDEAL;
    }

    protected function getFailedTransactionRegistrationType(): string
    {
        return Model_TransactionRegistration::REGISTRATION_FAILURE_IDEAL;
    }

    protected function getSupplierTransactionId(Model_Banktransaction $transaction): string
    {
        $tag_data = $transaction->getTagData();

        if (!$tag_data || empty($tag_data['ideal']['transaction_id'])) {
            throw new TransactionHandlerRuntimeException(sprintf(
                'Error fetching supplier transaction id from tag data for transaction #%d',
                $transaction->getPrimaryKey()
            ));
        }

        return $tag_data['ideal']['transaction_id'];
    }

    public function getTransactionConstraints(): array
    {
        return array_merge(parent::getTransactionConstraints(), [
            new HasPositiveAmount(),
            new TagExactlyMatches(TransactionTags::TAG_IDEAL),
        ]);
    }
}
