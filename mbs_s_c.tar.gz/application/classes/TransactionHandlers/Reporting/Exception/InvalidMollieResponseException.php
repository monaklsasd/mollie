<?php

declare(strict_types=1);

namespace TransactionHandlers\Reporting\Exception;

use TransactionHandlers\Exceptions\TransactionHandlerRuntimeException;

class InvalidMollieResponseException extends TransactionHandlerRuntimeException
{
}
