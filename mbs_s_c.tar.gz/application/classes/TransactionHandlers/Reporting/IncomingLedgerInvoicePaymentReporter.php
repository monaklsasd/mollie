<?php

declare(strict_types=1);

namespace TransactionHandlers\Reporting;

use Core\Localization\Localizer;
use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use Supplier\Mollie\Exceptions\UnsuccessfulInvoicePaymentWebhookException;
use Supplier\Mollie\Mollie;
use Supplier\Mollie\Response\LedgerInvoicePaymentWebhookResponse;
use TransactionHandlers\Constraints\HasPositiveAmount;
use TransactionHandlers\Constraints\TagExactlyMatches;
use TransactionHandlers\Exceptions\TransactionHandlerRuntimeException;
use TransactionHandlers\SingleTransactionHandler;
use Validation\ValidatorFactory;
use Webmozart\Assert\Assert;

class IncomingLedgerInvoicePaymentReporter extends SingleTransactionHandler
{
    /** @var Mollie */
    protected $mollie_supplier;

    public function __construct(
        ValidatorFactory $validator_factory,
        Mollie $mollie_supplier
    ) {
        parent::__construct($validator_factory);

        $this->mollie_supplier = $mollie_supplier;
    }

    /**
     * @throws TransactionHandlerRuntimeException
     */
    protected function handleTransaction(Model_Banktransaction $transaction): void
    {
        $this->setLastProcessedTransaction($transaction);

        if ($transaction->getLedgerInvoiceNumber() === null) {
            return;
        }

        $transaction->setAsLedgerTransaction();
        $transaction->setTags([TransactionTags::TAG_LEDGER_INVOICE_PAYMENT]);
        $transaction->saveOrDie();

        try {
            $response = $this->mollie_supplier->sendLedgerInvoicePaymentWebhook($transaction);

            $transaction->addComment($this->createCommentForWebhookResponse($transaction, $response));
            $transaction->addTagData(['is_payment_accepted' => true]);
        } catch (UnsuccessfulInvoicePaymentWebhookException $e) {
            $transaction->addTagData(['is_payment_accepted' => false]);
            $transaction->addComment($e->getCommentFriendlyMessage());
        }

        $transaction->saveOrDie();
    }

    private function createCommentForWebhookResponse(
        Model_Banktransaction $transaction,
        LedgerInvoicePaymentWebhookResponse $invoice_payment_response
    ): string {
        $base_comment = sprintf(
            'Successfully informed Mollie about invoice payment for invoice <a href="%s" target="_blank">%s</a>. ',
            $this->getInvoiceLinkHref($invoice_payment_response->getInvoiceId()),
            $invoice_payment_response->getInvoiceNumber()
        );

        if ($invoice_payment_response->getStatus()->isRejected()) {
            return $base_comment . sprintf(
                "<b>However, Mollie rejected the invoice payment: %s</b>",
                $invoice_payment_response->getErrorMessage()
            );
        }

        Assert::true(
            $invoice_payment_response->getStatus()->isAccepted(),
            "Expected only 'rejected' or 'accepted' status in this method '{$invoice_payment_response->getStatus()}'"
        );

        if ($invoice_payment_response->invoiceWasPaidExactly()) {
            return $base_comment . sprintf(
                "The invoice has been paid exactly (%s).",
                Localizer::formatMoney($invoice_payment_response->getAmountPaidTowardsInvoice())
            );
        }

        if ($invoice_payment_response->invoiceWasUnderpaid()) {
            return $base_comment . sprintf(
                "<b>The invoice has been partially paid (%s / %s)</b>.",
                Localizer::formatMoney($invoice_payment_response->getAmountPaidTowardsInvoice()),
                Localizer::formatMoney($invoice_payment_response->getAmountThatShouldHaveBeenPaid())
            );
        }

        Assert::true($invoice_payment_response->invoiceWasOverpaid());

        return $base_comment . sprintf(
            "<b>The invoice has been paid for more than was needed (%s / %s), %s should be sent back</b>.",
            Localizer::formatMoney($transaction->getAmount()),
            Localizer::formatMoney($invoice_payment_response->getAmountThatShouldHaveBeenPaid()),
            Localizer::formatMoney($invoice_payment_response->getAmountPaidExcessively())
        );
    }

    private function getInvoiceLinkHref(int $invoice_id): string
    {
        return "https://www.mollie.com/admin/finance-ledger/invoicing/show-invoice/{$invoice_id}";
    }

    protected function getTransactionConstraints(): array
    {
        return [
            new TagExactlyMatches(TransactionTags::TAG_MANUAL_HANDLING),
            new HasPositiveAmount(),
        ];
    }
}
