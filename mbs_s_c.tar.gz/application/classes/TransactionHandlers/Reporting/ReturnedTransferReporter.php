<?php

declare(strict_types=1);

namespace TransactionHandlers\Reporting;

use App\Ledger\CanGetTransferPayoutReferenceTrait;
use App\Ledger\LedgerTransactionException;
use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use Orm\ModelFactory;
use Supplier\Mollie\Mollie;
use Supplier\Mollie\MollieException;
use TransactionHandlers\Constraints\HasPositiveAmount;
use TransactionHandlers\Constraints\TagExactlyMatches;
use TransactionHandlers\Exceptions\TransactionHandlerRuntimeException;
use TransactionHandlers\SingleTransactionHandler;
use Validation\ValidatorFactory;

class ReturnedTransferReporter extends SingleTransactionHandler
{
    use CanGetTransferPayoutReferenceTrait;

    public const RETURNED_TRANSFER_FAILED_MESSAGE  = 'Transfer was returned but was unable to inform Mollie.';
    public const RETURNED_TRANSFER_SUCCESS_MESSAGE = 'Successfully informed Mollie about returned transfer.';

    /** @var Mollie */
    protected $mollie_supplier;

    /** @var ModelFactory */
    private $model_factory;

    public function __construct(
        ValidatorFactory $validator_factory,
        Mollie $mollie,
        ModelFactory $model_factory
    ) {
        parent::__construct($validator_factory);

        $this->mollie_supplier = $mollie;
        $this->model_factory   = $model_factory;
    }

    /**
     * @throws TransactionHandlerRuntimeException
     */
    protected function handleTransaction(Model_Banktransaction $transaction): void
    {
        $this->setLastProcessedTransaction($transaction);

        $transaction->setAsLedgerTransaction();
        $transaction->saveOrDie();

        try {
            $this->mollie_supplier->markTransferReturned(
                $this->getTransferPayoutReference($transaction)
            );

            $transaction->addComment(self::RETURNED_TRANSFER_SUCCESS_MESSAGE);
        } catch (MollieException $e) {
            $transaction->addComment(self::RETURNED_TRANSFER_FAILED_MESSAGE);

            // TODO: This info will log to `mollie_mbs`.`logs` while trying to identify what type of errors are mollie returning.
            $this->logger->notice('MollieException was thrown while reporting a failed transfer', ['exception' => $e]);
        } catch (LedgerTransactionException $e) {
            throw new TransactionHandlerRuntimeException($e->getMessage(), $e->getCode(), $e);
        }
    }

    protected function getTransactionConstraints(): array
    {
        return [
            new TagExactlyMatches(TransactionTags::TAG_FAILURETRANSFER),
            new HasPositiveAmount(),
        ];
    }
}
