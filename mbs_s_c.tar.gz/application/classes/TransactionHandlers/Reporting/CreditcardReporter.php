<?php

declare(strict_types=1);

namespace TransactionHandlers\Reporting;

use Model\Transaction\TransactionTags;
use Model_TransactionRegistration;
use TransactionHandlers\Constraints\HasAnyOfTags;

/**
 * A transaction handler that receives Mollie creditcard payments.
 */
class CreditcardReporter extends SettlementReporter
{
    protected function getPaymentMethodTag(): string
    {
        return TransactionTags::TAG_CREDITCARD;
    }

    protected function getUnknownTransactionTag(): string
    {
        return TransactionTags::TAG_UNKNOWNCREDITCARD;
    }

    protected function getUnknownTransactionRegistrationType(): string
    {
        return Model_TransactionRegistration::REGISTRATION_UNKNOWN_CREDITCARD;
    }

    protected function getFailedTransactionTag(): string
    {
        return TransactionTags::TAG_FAILURECREDITCARD;
    }

    protected function getFailedTransactionRegistrationType(): string
    {
        return Model_TransactionRegistration::REGISTRATION_FAILURE_CREDITCARD;
    }

    public function getTransactionConstraints(): array
    {
        return array_merge(parent::getTransactionConstraints(), [
            new HasAnyOfTags([
                TransactionTags::TAG_CREDITCARD,
                TransactionTags::TAG_CREDITCARD_REFUND,
            ]),
        ]);
    }
}
