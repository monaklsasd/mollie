<?php

declare(strict_types=1);

namespace TransactionHandlers\Reporting;

use Model\Transaction\TransactionTags;
use Model_TransactionRegistration;
use TransactionHandlers\Constraints\HasPositiveAmount;
use TransactionHandlers\Constraints\TagExactlyMatches;

/**
 * A transaction handler that receives Mollie ING Home'Pay payments and records.
 */
class IngHomePayReporter extends SettlementReporter
{
    protected function getPaymentMethodTag(): string
    {
        return TransactionTags::TAG_INGHOMEPAY;
    }

    protected function getUnknownTransactionTag(): string
    {
        return TransactionTags::TAG_UNKNOWNINGHOMEPAY;
    }

    protected function getUnknownTransactionRegistrationType(): string
    {
        return Model_TransactionRegistration::REGISTRATION_UNKNOWN_INGHOMEPAY;
    }

    protected function getFailedTransactionTag(): string
    {
        return TransactionTags::TAG_FAILUREINGHOMEPAY;
    }

    protected function getFailedTransactionRegistrationType(): string
    {
        return Model_TransactionRegistration::REGISTRATION_FAILURE_INGHOMEPAY;
    }

    public function getTransactionConstraints(): array
    {
        return array_merge(parent::getTransactionConstraints(), [
            new HasPositiveAmount(),
            new TagExactlyMatches(TransactionTags::TAG_INGHOMEPAY),
        ]);
    }
}
