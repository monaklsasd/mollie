<?php

declare(strict_types=1);

namespace TransactionHandlers;

use Generator;
use Model_Banktransaction;
use Psr\Log\LoggerAwareInterface;

interface TransactionHandler extends LoggerAwareInterface
{
    /**
     * @param Generator|iterable|Model_Banktransaction[] $transactions
     */
    public function run(iterable $transactions): bool;

    /**
     * Returns how many times this handler can fail before we stop retrying. return 0 for no maximum
     */
    public function getMaxTries(): int;

    /**
     * Returns after how many seconds this handler can be retried.
     */
    public function getRetryDelay(): int;

    public function getLastProcessedTransaction(): ?Model_Banktransaction;
}
