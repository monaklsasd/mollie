<?php

use Core\Di\DependencyInjector;
use Core\Di\Exceptions\FailedInstantiatingClassException;
use Core\Di\Exceptions\FailedLoadingDependencyException;
use Core\Di\Exceptions\InvalidClassNameException;
use Core\Di\Exceptions\InvalidDependencyConfigurationException;

/**
 * @deprecated Look at the name. Do you really want to use this?!
 */
class CrappyStaticDi
{
    /** @var DependencyInjector|null */
    private static $dependency_injector;

    /**
     * @deprecated For cave usage only. Guaranteed flames when used in other places.
     *
     * @throws FailedInstantiatingClassException
     * @throws FailedLoadingDependencyException
     * @throws InvalidClassNameException
     * @throws InvalidDependencyConfigurationException
     */
    public static function getInstance(string $class_name)
    {
        return self::getDependencyInjector()->getInstance($class_name);
    }

    public static function setDependencyInjector(DependencyInjector $dependency_injector): void
    {
        self::$dependency_injector = $dependency_injector;
    }

    private static function getDependencyInjector(): DependencyInjector
    {
        if (self::$dependency_injector === null) {
            self::$dependency_injector = new DependencyInjector();
        }

        return self::$dependency_injector;
    }
}
