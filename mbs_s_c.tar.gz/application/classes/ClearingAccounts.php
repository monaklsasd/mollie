<?php

use Accounting\Account;
use Accounting\Account\AccountFactory;
use Accounting\Organization;

class ClearingAccounts
{
    public static function idealPayments(Model_Banktransaction $bank_transaction): Account
    {
        return AccountFactory::createFromTwinfield(
            Organization::STICHTING_MOLLIE_PAYMENTS(),
            $bank_transaction->isLedgerTransaction()
                ? AccountView_Object_Transaction::LEDGER_CLEARING_ACCOUNT_IDEAL
                : AccountView_Object_Transaction::LEDGER_RECEIVED_IDEAL
        );
    }

    public static function creditCardPaymentsValitor(Model_Banktransaction $bank_transaction): Account
    {
        return AccountFactory::createFromTwinfield(
            Organization::STICHTING_MOLLIE_PAYMENTS(),
            $bank_transaction->isLedgerTransaction()
                ? AccountView_Object_Transaction::LEDGER_CLEARING_ACCOUNT_CREDIT_CARD_VALITOR
                : AccountView_Object_Transaction::LEDGER_TUSSENREKENING_VALITOR_CREDITCARD
        );
    }

    public static function creditCardPaymentsAmex(Model_Banktransaction $bank_transaction): Account
    {
        return AccountFactory::createFromTwinfield(
            Organization::STICHTING_MOLLIE_PAYMENTS(),
            $bank_transaction->isLedgerTransaction()
                ? AccountView_Object_Transaction::LEDGER_CLEARING_ACCOUNT_CREDIT_CARD_AMEX
                : AccountView_Object_Transaction::LEDGER_TUSSENREKENING_AMEX_CREDITCARD
        );
    }

    public static function creditCardRefundsValitor(Model_Banktransaction $bank_transaction): Account
    {
        return AccountFactory::createFromTwinfield(
            Organization::STICHTING_MOLLIE_PAYMENTS(),
            $bank_transaction->isLedgerTransaction()
                ? AccountView_Object_Transaction::LEDGER_CLEARING_ACCOUNT_CREDIT_CARD_VALITOR_REFUNDS
                : AccountView_Object_Transaction::LEDGER_TUSSENREKENING_VALITOR_REFUNDS
        );
    }

    public static function creditCardRefundsAmex(Model_Banktransaction $bank_transaction): Account
    {
        return AccountFactory::createFromTwinfield(
            Organization::STICHTING_MOLLIE_PAYMENTS(),
            $bank_transaction->isLedgerTransaction()
                ? AccountView_Object_Transaction::LEDGER_CLEARING_ACCOUNT_CREDIT_CARD_AMEX_REFUNDS
                : AccountView_Object_Transaction::LEDGER_TUSSENREKENING_AMEX_REFUNDS
        );
    }

    public static function creditCardChargebacksValitor(Model_Banktransaction $bank_transaction): Account
    {
        return AccountFactory::createFromTwinfield(
            Organization::STICHTING_MOLLIE_PAYMENTS(),
            $bank_transaction->isLedgerTransaction()
                ? AccountView_Object_Transaction::LEDGER_CLEARING_ACCOUNT_CREDIT_CARD_VALITOR_CHARGEBACKS
                : AccountView_Object_Transaction::LEDGER_TUSSENREKENING_VALITOR_CHARGEBACKS
        );
    }

    public static function creditCardChargebacksAmex(Model_Banktransaction $bank_transaction): Account
    {
        return AccountFactory::createFromTwinfield(
            Organization::STICHTING_MOLLIE_PAYMENTS(),
            $bank_transaction->isLedgerTransaction()
                ? AccountView_Object_Transaction::LEDGER_CLEARING_ACCOUNT_CREDIT_CARD_AMEX_CHARGEBACKS
                : AccountView_Object_Transaction::LEDGER_TUSSENREKENING_AMEX_CHARGEBACKS
        );
    }

    public static function creditCardRollingReserveValitor(Model_Banktransaction $bank_transaction): Account
    {
        return AccountFactory::createFromTwinfield(
            Organization::STICHTING_MOLLIE_PAYMENTS(),
            $bank_transaction->isLedgerTransaction()
                ? AccountView_Object_Transaction::LEDGER_CLEARING_ACCOUNT_CREDIT_CARD_VALITOR_ROLLING_RESERVE_LEFT_TO_RECEIVE
                : AccountView_Object_Transaction::LEDGER_TUSSENREKENING_VALITOR_ROLLING_RESERVE
        );
    }

    public static function bancontactPayments(Model_Banktransaction $bank_transaction): Account
    {
        return AccountFactory::createFromTwinfield(
            Organization::STICHTING_MOLLIE_PAYMENTS(),
            $bank_transaction->isLedgerTransaction()
                ? AccountView_Object_Transaction::LEDGER_CLEARING_ACCOUNT_BANCONTACT
                : AccountView_Object_Transaction::LEDGER_RECEIVED_MISTERCASH
        );
    }

    public static function refunds(Model_Banktransaction $bank_transaction): Account
    {
        return AccountFactory::createFromTwinfield(
            Organization::STICHTING_MOLLIE_PAYMENTS(),
            $bank_transaction->isLedgerTransaction()
                ? AccountView_Object_Transaction::LEDGER_CLEARING_ACCOUNT_REFUNDS
                : AccountView_Object_Transaction::LEDGER_TUSSENREKENING_REFUNDS
        );
    }

    public static function directDebitPayments(Model_Banktransaction $bank_transaction): Account
    {
        return AccountFactory::createFromTwinfield(
            Organization::STICHTING_MOLLIE_PAYMENTS(),
            $bank_transaction->isLedgerTransaction()
                ? AccountView_Object_Transaction::LEDGER_CLEARING_ACCOUNT_DIRECT_DEBIT
                : AccountView_Object_Transaction::LEDGER_TUSSENREKENING_DIRECTDEBIT
        );
    }

    public static function directDebitChargebacks(Model_Banktransaction $bank_transaction): Account
    {
        return AccountFactory::createFromTwinfield(
            Organization::STICHTING_MOLLIE_PAYMENTS(),
            $bank_transaction->isLedgerTransaction()
                ? AccountView_Object_Transaction::LEDGER_CLEARING_ACCOUNT_DIRECT_DEBIT_CHARGEBACK
                : AccountView_Object_Transaction::LEDGER_TUSSENREKENING_STORNO_DIRECTDEBIT
        );
    }

    public static function directDebitFailures(Model_Banktransaction $bank_transaction): Account
    {
        return AccountFactory::createFromTwinfield(
            Organization::STICHTING_MOLLIE_PAYMENTS(),
            $bank_transaction->isLedgerTransaction()
                ? AccountView_Object_Transaction::LEDGER_CLEARING_ACCOUNT_DIRECT_DEBIT_FAILED
                : AccountView_Object_Transaction::LEDGER_TUSSENREKENING_FAILED_DIRECTDEBIT
        );
    }

    public static function bankTransferPayments(Model_Banktransaction $bank_transaction): Account
    {
        return AccountFactory::createFromTwinfield(
            Organization::STICHTING_MOLLIE_PAYMENTS(),
            $bank_transaction->isLedgerTransaction()
                ? AccountView_Object_Transaction::LEDGER_CLEARING_ACCOUNT_BANK_TRANSFER
                : AccountView_Object_Transaction::LEDGER_TUSSENREKENING_OVERBOEKING
        );
    }

    public static function sofortPayments(Model_Banktransaction $bank_transaction): Account
    {
        return AccountFactory::createFromTwinfield(
            Organization::STICHTING_MOLLIE_PAYMENTS(),
            $bank_transaction->isLedgerTransaction()
                ? AccountView_Object_Transaction::LEDGER_CLEARING_ACCOUNT_SOFORT
                : AccountView_Object_Transaction::LEDGER_TUSSENREKENING_SOFORT
        );
    }

    public static function kbcPayments(Model_Banktransaction $bank_transaction): Account
    {
        return AccountFactory::createFromTwinfield(
            Organization::STICHTING_MOLLIE_PAYMENTS(),
            $bank_transaction->isLedgerTransaction()
                ? AccountView_Object_Transaction::LEDGER_CLEARING_ACCOUNT_KBC
                : AccountView_Object_Transaction::LEDGER_TUSSENREKENING_KBC
        );
    }

    public static function belfiusPayments(Model_Banktransaction $bank_transaction): Account
    {
        return AccountFactory::createFromTwinfield(
            Organization::STICHTING_MOLLIE_PAYMENTS(),
            $bank_transaction->isLedgerTransaction()
                ? AccountView_Object_Transaction::LEDGER_CLEARING_ACCOUNT_BELFIUS
                : AccountView_Object_Transaction::LEDGER_TUSSENREKENING_BELFIUS
        );
    }

    public static function ingHomepayPayments(Model_Banktransaction $bank_transaction): Account
    {
        return AccountFactory::createFromTwinfield(
            Organization::STICHTING_MOLLIE_PAYMENTS(),
            $bank_transaction->isLedgerTransaction()
                ? AccountView_Object_Transaction::LEDGER_CLEARING_ACCOUNT_ING_HOMEPAY
                : AccountView_Object_Transaction::LEDGER_TUSSENREKENING_INGHOMEPAY
        );
    }

    public static function bitcoinPayments(Model_Banktransaction $bank_transaction): Account
    {
        return AccountFactory::createFromTwinfield(
            Organization::STICHTING_MOLLIE_PAYMENTS(),
            $bank_transaction->isLedgerTransaction()
                ? AccountView_Object_Transaction::LEDGER_CLEARING_ACCOUNT_BITCOIN
                : AccountView_Object_Transaction::LEDGER_TUSSENREKENING_BITCOIN
        );
    }

    public static function giropayPayments(Model_Banktransaction $bank_transaction): Account
    {
        return AccountFactory::createFromTwinfield(
            Organization::STICHTING_MOLLIE_PAYMENTS(),
            $bank_transaction->isLedgerTransaction()
                ? AccountView_Object_Transaction::LEDGER_CLEARING_ACCOUNT_GIROPAY
                : AccountView_Object_Transaction::LEDGER_TUSSENREKENING_GIROPAY
        );
    }

    public static function epsPayments(Model_Banktransaction $bank_transaction): Account
    {
        return AccountFactory::createFromTwinfield(
            Organization::STICHTING_MOLLIE_PAYMENTS(),
            $bank_transaction->isLedgerTransaction()
                ? AccountView_Object_Transaction::LEDGER_CLEARING_ACCOUNT_EPS
                : AccountView_Object_Transaction::LEDGER_TUSSENREKENING_EPS
        );
    }

    public static function przelewy24Payments(Model_Banktransaction $bank_transaction): Account
    {
        return AccountFactory::createFromTwinfield(
            Organization::STICHTING_MOLLIE_PAYMENTS(),
            $bank_transaction->isLedgerTransaction()
                ? AccountView_Object_Transaction::LEDGER_CLEARING_ACCOUNT_PRZELEWY24
                : AccountView_Object_Transaction::LEDGER_TUSSENREKENING_PRZELEWY24
        );
    }

    public static function przelewy24Refunds(Model_Banktransaction $bank_transaction): Account
    {
        return AccountFactory::createFromTwinfield(
            Organization::STICHTING_MOLLIE_PAYMENTS(),
            $bank_transaction->isLedgerTransaction()
                ? AccountView_Object_Transaction::LEDGER_CLEARING_ACCOUNT_PRZELEWY24_REFUNDS
                : AccountView_Object_Transaction::LEDGER_TUSSENREKENING_PRZELEWY24_REFUNDS
        );
    }

    public static function mybankPayments(Model_Banktransaction $bank_transaction): Account
    {
        return AccountFactory::createFromTwinfield(
            Organization::STICHTING_MOLLIE_PAYMENTS(),
            $bank_transaction->isLedgerTransaction()
                ? AccountView_Object_Transaction::LEDGER_CLEARING_ACCOUNT_MYBANK
                : AccountView_Object_Transaction::LEDGER_TUSSENREKENING_MYBANK
        );
    }

    public static function klarnaPayLaterPayments(Model_Banktransaction $bank_transaction): Account
    {
        return AccountFactory::createFromTwinfield(
            Organization::STICHTING_MOLLIE_PAYMENTS(),
            $bank_transaction->isLedgerTransaction()
                ? AccountView_Object_Transaction::LEDGER_CLEARING_ACCOUNT_KLARNA_PAY_LATER
                : AccountView_Object_Transaction::LEDGER_TUSSENREKENING_KLARNA_PAYLATER
        );
    }

    public static function klarnaSliceItPayments(Model_Banktransaction $bank_transaction): Account
    {
        return AccountFactory::createFromTwinfield(
            Organization::STICHTING_MOLLIE_PAYMENTS(),
            $bank_transaction->isLedgerTransaction()
                ? AccountView_Object_Transaction::LEDGER_CLEARING_ACCOUNT_KLARNA_SLICE_IT
                : AccountView_Object_Transaction::LEDGER_TUSSENREKENING_KLARNA_SLICEIT
        );
    }

    public static function klarnaRefunds(Model_Banktransaction $bank_transaction): Account
    {
        return AccountFactory::createFromTwinfield(
            Organization::STICHTING_MOLLIE_PAYMENTS(),
            $bank_transaction->isLedgerTransaction()
                ? AccountView_Object_Transaction::LEDGER_CLEARING_ACCOUNT_KLARNA_REFUNDS
                : AccountView_Object_Transaction::LEDGER_TUSSENREKENING_KLARNA_RETURNS
        );
    }

    public static function klarnaChargebacks(Model_Banktransaction $bank_transaction): Account
    {
        return AccountFactory::createFromTwinfield(
            Organization::STICHTING_MOLLIE_PAYMENTS(),
            $bank_transaction->isLedgerTransaction()
                ? AccountView_Object_Transaction::LEDGER_CLEARING_ACCOUNT_KLARNA_CHARGEBACKS
                : AccountView_Object_Transaction::LEDGER_TUSSENREKENING_KLARNA_CHARGEBACKS
        );
    }
}
