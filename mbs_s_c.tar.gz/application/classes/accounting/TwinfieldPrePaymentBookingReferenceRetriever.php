<?php

namespace Accounting;

use Core\InvoiceNumber;
use Core\Time\Clock;
use DateTimeImmutable;
use LogicException;
use Model_Accounting_PrePaymentAggregation;
use Orm\Repositories\Accounting\TwinfieldReferenceRepository;
use Orm\Repositories\PrePaymentAggregationRepository;
use PhpTwinfield\BankTransaction;
use PhpTwinfield\BookingReference;
use PhpTwinfield\BookingReferenceInterface;
use PhpTwinfield\Enums\LineType;
use PhpTwinfield\Transactions\BankTransactionLine\Detail;

/**
 * The goal of this class is to check whether we've already sent a given BankTransaction full of merchant pre payments
 * to Twinfield before. If we have, then the returned booking reference can be used to alter the Twinfield API call
 * to an update, instead of a create.
 */
class TwinfieldPrePaymentBookingReferenceRetriever
{
    /** @var PrePaymentAggregationRepository */
    private $pre_payment_aggregation_repository;

    /** @var TwinfieldReferenceRepository */
    private $twinfield_reference_repository;

    public function __construct(
        PrePaymentAggregationRepository $pre_payment_aggregation_repository,
        TwinfieldReferenceRepository $twinfield_reference_repository
    ) {
        $this->pre_payment_aggregation_repository = $pre_payment_aggregation_repository;
        $this->twinfield_reference_repository     = $twinfield_reference_repository;
    }

    public function getBookingReferenceFrom(BankTransaction $bank_transaction): ?BookingReferenceInterface
    {
        $date = Clock::createImmutableDateTimeFrom($bank_transaction->getDate());

        foreach ($bank_transaction->getLines() as $line) {
            if ($line->getLineType()->equals(LineType::DETAIL())) {
                /** @var Detail $line */
                $invoice_number = $line->getInvoiceNumber();

                if (!self::isMerchantPrePaymentLine($invoice_number)) {
                    continue;
                }

                $pre_payment_aggregation = $this->getPrePaymentAggregation($invoice_number, $date);

                $existing_booking_reference = $this->getExistingBookingReference($pre_payment_aggregation, $bank_transaction);

                if ($existing_booking_reference !== null) {
                    return $existing_booking_reference;
                }

                /*
                 * Exit early if we couldn't find a reference for the first pre payment line in the bank transaction.
                 *
                 * They either all have a reference, or none of them do. There is no use in looking through another 249.
                 */
                break;
            }
        }

        return null;
    }

    private static function isMerchantPrePaymentLine(?string $invoice_number): bool
    {
        return !empty($invoice_number);
    }

    private function getPrePaymentAggregation(
        string $invoice_number,
        DateTimeImmutable $date
    ): Model_Accounting_PrePaymentAggregation {
        $pre_payment_aggregation = $this->pre_payment_aggregation_repository->getByInvoiceNumberAndDate(
            InvoiceNumber::fromString($invoice_number),
            $date
        );

        if ($pre_payment_aggregation === null) {
            $message = sprintf(
                "Failed to find pre payment aggregation with invoice number %s and date %s. This should be impossible" .
                " since this pre payment is being reported to Twinfield, so it must exist.",
                $invoice_number,
                $date->format('Y-m-d')
            );

            throw new LogicException($message);
        }

        return $pre_payment_aggregation;
    }

    private function getExistingBookingReference(
        Model_Accounting_PrePaymentAggregation $pre_payment_aggregation,
        BankTransaction $bank_transaction
    ): ?BookingReferenceInterface {
        $twinfield_reference = $this->twinfield_reference_repository->getForPrePaymentAggregation(
            $pre_payment_aggregation
        );

        if ($twinfield_reference === null) {
            return null;
        }

        $booking_reference = BookingReference::fromMatchReference($twinfield_reference);

        if (!self::referenceMatches($booking_reference, $bank_transaction)) {
            $message = sprintf(
                "Existing Twinfield reference found for pre payment aggregation #%d does not match the office/code" .
                " combination of the bank transaction that is being sent to Twinfield (%s/%s)",
                $pre_payment_aggregation->getPrimaryKeyName(),
                $bank_transaction->getOffice()->getCode(),
                $bank_transaction->getCode()
            );

            throw new LogicException($message);
        }

        return $booking_reference;
    }

    private static function referenceMatches(BookingReferenceInterface $booking_reference, BankTransaction $line): bool
    {
        return $booking_reference->getOffice()->getCode() === $line->getOffice()->getCode()
            && $booking_reference->getCode()              === $line->getCode();
    }
}
