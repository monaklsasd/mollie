<?php

namespace Accounting\Matching\Exceptions;

use Core\InvoiceNumber;
use DateTimeImmutable;
use Model_Accounting_PrePaymentAggregation;
use PhpTwinfield\Transactions\BankTransactionLine\Detail;

class MatchReferencePersistingException extends AbstractException
{
    public static function unknown(InvoiceNumber $invoice_number, DateTimeImmutable $date): self
    {
        $message = sprintf(
            'Cannot find pre payment aggregation with invoice number %s and date %s',
            $invoice_number->toString(),
            $date->format('Y-m-d')
        );

        return new self($message);
    }

    public static function debtorMismatch(
        Model_Accounting_PrePaymentAggregation $pre_payment_aggregation,
        Detail $detail_line
    ): self {
        $message = sprintf(
            'Pre payment #%s with invoice number %s and date %s has debtor number %s, but debtor number %s' .
            ' was sent to Twinfield',
            $pre_payment_aggregation->getPrimaryKey(),
            $pre_payment_aggregation->getInvoiceNumber()->toString(),
            $pre_payment_aggregation->getDate()->format('Y-m-d'),
            $pre_payment_aggregation->getDebtorNumber(),
            $detail_line->getDim2()
        );

        return new self($message);
    }
}
