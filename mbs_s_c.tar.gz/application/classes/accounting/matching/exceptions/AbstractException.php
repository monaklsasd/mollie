<?php

namespace Accounting\Matching\Exceptions;

class AbstractException extends \Accounting\Exceptions\AbstractException
{
}
