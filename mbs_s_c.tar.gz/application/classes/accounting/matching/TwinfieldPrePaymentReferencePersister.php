<?php

namespace Accounting\Matching;

use Accounting\Matching\Exceptions\MatchReferencePersistingException;
use Core\InvoiceNumber;
use Core\Time\Clock;
use DateTimeImmutable;
use Model_Accounting_PrePaymentAggregation;
use Orm\Repositories\Accounting\TwinfieldPrePaymentReferenceRepository;
use Orm\Repositories\Accounting\TwinfieldReferenceRepository;
use Orm\Repositories\PrePaymentAggregationRepository;
use PhpTwinfield\BankTransaction;
use PhpTwinfield\Enums\LineType;
use PhpTwinfield\Transactions\BankTransactionLine\Detail;
use PhpTwinfield\Transactions\TransactionLine;

class TwinfieldPrePaymentReferencePersister
{
    /** @var TwinfieldReferenceRepository */
    private $twinfield_reference_repository;

    /** @var TwinfieldPrePaymentReferenceRepository */
    private $twinfield_pre_payment_reference_repository;

    /** @var PrePaymentAggregationRepository */
    private $pre_payment_aggregation_repository;

    public function __construct(
        PrePaymentAggregationRepository $pre_payment_aggregation_repository,
        TwinfieldReferenceRepository $twinfield_reference_repository,
        TwinfieldPrePaymentReferenceRepository $twinfield_pre_payment_reference_repository
    ) {
        $this->twinfield_reference_repository             = $twinfield_reference_repository;
        $this->twinfield_pre_payment_reference_repository = $twinfield_pre_payment_reference_repository;
        $this->pre_payment_aggregation_repository         = $pre_payment_aggregation_repository;
    }

    /**
     * @throws MatchReferencePersistingException
     */
    public function persistReferencesFrom(BankTransaction $bank_transaction): void
    {
        foreach ($bank_transaction->getLines() as $line) {
            if ($this->isMerchantPrePaymentLine($line)) {
                /** @var Detail $line */
                $this->storeMerchantPrePaymentReference(
                    $line,
                    Clock::createImmutableDateTimeFrom($bank_transaction->getDate())
                );
            }
        }
    }

    private function isMerchantPrePaymentLine(TransactionLine $line): bool
    {
        if (!$line->getLineType()->equals(LineType::DETAIL())) {
            return false;
        }

        /** @var Detail $line */
        return $line->getInvoiceNumber() !== null && $line->getDim2() !== null;
    }

    /**
     * @throws MatchReferencePersistingException
     */
    private function storeMerchantPrePaymentReference(
        Detail $detail_line,
        DateTimeImmutable $pre_payment_aggregation_date
    ): void {
        $reference_model         = $this->twinfield_reference_repository->create($detail_line->getReference());
        $pre_payment_aggregation = $this->getMerchantPrePaymentAggregation($detail_line, $pre_payment_aggregation_date);

        $this->twinfield_pre_payment_reference_repository->create($pre_payment_aggregation, $reference_model);
    }

    /**
     * @throws MatchReferencePersistingException
     */
    private function getMerchantPrePaymentAggregation(
        Detail $detail_line,
        DateTimeImmutable $pre_payment_aggregation_date
    ): Model_Accounting_PrePaymentAggregation {
        $invoice_number = InvoiceNumber::fromString($detail_line->getInvoiceNumber());

        $merchant_pre_payment_aggregation = $this->pre_payment_aggregation_repository->getByInvoiceNumberAndDate(
            $invoice_number,
            $pre_payment_aggregation_date
        );

        if (!$merchant_pre_payment_aggregation) {
            throw MatchReferencePersistingException::unknown($invoice_number, $pre_payment_aggregation_date);
        }

        if (!($merchant_pre_payment_aggregation->getDebtorNumber() === $detail_line->getDim2())) {
            throw MatchReferencePersistingException::debtorMismatch($merchant_pre_payment_aggregation, $detail_line);
        }

        return $merchant_pre_payment_aggregation;
    }
}
