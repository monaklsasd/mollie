<?php

namespace Accounting\AccountView;

use AccountView_Object_Transaction;
use Core\InvoiceNumber;
use Model_Accounting_PrePaymentAggregation;

class PrePaymentAggregation
{
    /** @var string */
    private $debtor_number;

    /** @var InvoiceNumber */
    private $invoice_number;

    /** @var string */
    private $amount;

    public static function fromModel(
        Model_Accounting_PrePaymentAggregation $pre_payment_aggregation
    ): PrePaymentAggregation {
        return new PrePaymentAggregation(
            $pre_payment_aggregation->getInvoiceNumber(),
            $pre_payment_aggregation->getDebtorNumber(),
            $pre_payment_aggregation->getAmount()
        );
    }

    public function __construct(
        InvoiceNumber $invoice_number,
        string $debtor_number,
        string $amount
    ) {
        $this->invoice_number = $invoice_number;
        $this->debtor_number  = $debtor_number;
        $this->amount         = $amount;
    }

    public function getLedgerNumber(): int
    {
        return AccountView_Object_Transaction::LEDGER_DEBTOR;
    }

    public function getDescription(): string
    {
        return $this->invoice_number->toString();
    }

    public function getDebtorNumber(): string
    {
        return $this->debtor_number;
    }

    public function getInvoiceNumber(): InvoiceNumber
    {
        return $this->invoice_number;
    }

    public function getAmount(): string
    {
        return $this->amount;
    }
}
