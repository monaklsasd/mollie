<?php

namespace Accounting\AccountView;

use AccountView_Object_Abstract;
use AccountView_Object_Transaction;
use DateTimeImmutable;
use InvalidArgumentException;
use Model_Accounting_PrePaymentAggregation;

class PrePaymentAggregationList extends AccountView_Object_Abstract
{
    /** @var PrePaymentAggregation[] */
    private $pre_payment_aggregations = [];

    /** @var string */
    private $total_amount = '0';

    /** @var string */
    private $description = '';

    /** @var DateTimeImmutable */
    private $date;

    public function __construct(DateTimeImmutable $date)
    {
        $this->date = $date;
    }

    public function addPrePaymentAggregation(Model_Accounting_PrePaymentAggregation $pre_payment_aggregation): void
    {
        if ($pre_payment_aggregation->getDate()->format('Y-m') !== $this->date->format('Y-m')) {
            throw new InvalidArgumentException('Pre payment aggregations must be wrapped in the same month');
        }
        $this->total_amount = bcadd($this->total_amount, $pre_payment_aggregation->getAmount(), 2);

        $this->pre_payment_aggregations[] = PrePaymentAggregation::fromModel($pre_payment_aggregation);
    }

    public function getLedgerNumber(): int
    {
        return AccountView_Object_Transaction::LEDGER_MERCHANT_PREPAYMENTS;
    }

    public function getTotalAmount(): string
    {
        return $this->total_amount;
    }

    public function getDate(): DateTimeImmutable
    {
        return $this->date;
    }

    public function getDescription(): string
    {
        return $this->description;
    }

    public function setDescription(string $description)
    {
        $this->description = $description;
    }

    /**
     * @return PrePaymentAggregation[]
     */
    public function getPrePaymentAggregations(): array
    {
        return $this->pre_payment_aggregations;
    }

    public function getPrePaymentAggregationCount(): int
    {
        return count($this->pre_payment_aggregations);
    }
}
