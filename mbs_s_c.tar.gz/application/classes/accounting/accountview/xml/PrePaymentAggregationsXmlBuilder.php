<?php

namespace Accounting\AccountView\Xml;

use Accounting\AccountView\PrePaymentAggregationList;
use AccountView_XmlBuilder_AbstractXmlBuilder;
use Core\InvoiceNumber;
use DateTimeInterface;

class PrePaymentAggregationsXmlBuilder extends AccountView_XmlBuilder_AbstractXmlBuilder
{
    public function generateXml(?PrePaymentAggregationList $pre_payment_aggregations = null)
    {
        $xml = $this->_createAvXmlHeader($pre_payment_aggregations->getAdministration());

        $xml .= "
            <EBUSTRNRQ>
                <TRNUID>{$pre_payment_aggregations->getTrxUid()}</TRNUID>
                <BUSOBJ KEY=\"830\">DJ2</BUSOBJ>
			    <ROWADDRQ>
                    <HDR_DESC>{$pre_payment_aggregations->getDescription()}</HDR_DESC>
                    <PERIOD>{$pre_payment_aggregations->getDate()->format('n')}</PERIOD>";

        $xml .= $this->createDayJournalLine(
            $pre_payment_aggregations->getLedgerNumber(),
            $pre_payment_aggregations->getDescription(),
            $pre_payment_aggregations->getTotalAmount(),
            $pre_payment_aggregations->getDate()
        );

        foreach ($pre_payment_aggregations->getPrePaymentAggregations() as $pre_payment_aggregation) {
            $xml .= $this->createDayJournalLine(
                $pre_payment_aggregation->getLedgerNumber(),
                $pre_payment_aggregation->getDescription(),
                -$pre_payment_aggregation->getAmount(),
                $pre_payment_aggregations->getDate(),
                $pre_payment_aggregation->getDebtorNumber(),
                $pre_payment_aggregation->getInvoiceNumber()
            );
        }

        $xml .= '</ROWADDRQ>
            </EBUSTRNRQ>';

        $xml .= $this->_createAvXmlFooter();

        return $xml;
    }

    private function createDayJournalLine(
        int $ledger_number,
        string $description,
        string $amount,
        DateTimeInterface $date,
        ?string $debtor_number = null,
        ?InvoiceNumber $invoice_number = null
    ): string {
        return sprintf(
            "
            <DJ_LINE>
                <ACCT_NR>%d</ACCT_NR>
                <TRN_DESC>%s</TRN_DESC>
                <TRN_DATE>%s</TRN_DATE>
                <AMOUNT>%.2f</AMOUNT>
                %s
                %s
            </DJ_LINE>
            ",
            $ledger_number,
            $description,
            $date->format('Y-m-d'),
            $amount,
            $debtor_number === null ? '' : "<SUB_NR>{$debtor_number}</SUB_NR>",
            $invoice_number === null ? '' : "<INV_NR>{$invoice_number->toString()}</INV_NR>"
        );
    }
}
