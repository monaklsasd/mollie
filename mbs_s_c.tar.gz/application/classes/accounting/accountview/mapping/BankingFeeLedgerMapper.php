<?php

namespace Accounting\AccountView\Mapping;

use AccountView_Object_Transaction;
use BankAccounts\BankAccountRepository;
use BankAccounts\Exceptions\BankAccountNotFoundException;
use BankAccounts\Smp\AbnAmroOutpaymentsAccount;
use BankAccounts\Smp\AmexAccount;
use BankAccounts\Smp\BancontactAccount;
use BankAccounts\Smp\BelfiusDirectNetAccount;
use BankAccounts\Smp\BelgianBankTransferAccount;
use BankAccounts\Smp\BitcoinAccount;
use BankAccounts\Smp\ConsumerRefundsAccount;
use BankAccounts\Smp\DeutscheBankAmexAccount;
use BankAccounts\Smp\DeutscheBankBelgiumOutpaymentsAccount;
use BankAccounts\Smp\DeutscheBankDutchBankTransferAccount;
use BankAccounts\Smp\DeutscheBankDutchDirectDebitAccount;
use BankAccounts\Smp\DeutscheBankDutchOutpaymentsAccount;
use BankAccounts\Smp\DeutscheBankFrenchOutpaymentsAccount;
use BankAccounts\Smp\DeutscheBankGermanBankTransferAccount;
use BankAccounts\Smp\DeutscheBankGermanDirectDebitAccount;
use BankAccounts\Smp\DeutscheBankGermanOutpaymentsAccount;
use BankAccounts\Smp\DeutscheBankIdealAccount;
use BankAccounts\Smp\DeutscheBankPolishOutpaymentsAccount;
use BankAccounts\Smp\DeutscheBankRefundsAccount;
use BankAccounts\Smp\DirectDebitAbnAccount;
use BankAccounts\Smp\DirectDebitIngAccount;
use BankAccounts\Smp\DirectDebitRabobankAccount;
use BankAccounts\Smp\DutchBankTransferAccount;
use BankAccounts\Smp\FrenchBankTransferAccount;
use BankAccounts\Smp\GermanBankTransferAccount;
use BankAccounts\Smp\IdealAbnAccount;
use BankAccounts\Smp\IdealIngAccount;
use BankAccounts\Smp\IdealRabobankAccount;
use BankAccounts\Smp\KbcAccount;
use BankAccounts\Smp\OldSofortAccount;
use BankAccounts\Smp\PproEurSettlementAccount;
use BankAccounts\Smp\RabobankOutpaymentsAccount;
use BankAccounts\Smp\SofortAccount;
use BankAccounts\Smp\SofortStartselectAccount;
use BankAccounts\Smp\ValitorAccount;
use Exception;

class BankingFeeLedgerMapper
{
    /** Default ledger number for banking fees. */
    private const BANKING_FEES_DEFAULT_LEDGER_NUMBER = AccountView_Object_Transaction::LEDGER_ABNARMO_COSTS;

    /** Each bank account is mapped to a specific banking fee ledger number. */
    private const BANKING_FEES_ACCOUNT_LEDGER_MAP = [
        AbnAmroOutpaymentsAccount::class             => AccountView_Object_Transaction::LEDGER_BANKING_FEE_OUTPAYMENT,
        AmexAccount::class                           => AccountView_Object_Transaction::LEDGER_BANKING_FEE_AMEX,
        DeutscheBankAmexAccount::class               => AccountView_Object_Transaction::LEDGER_BANKING_FEE_AMEX,
        BancontactAccount::class                     => AccountView_Object_Transaction::LEDGER_BANKING_FEE_BANCONTACT,
        BelfiusDirectNetAccount::class               => AccountView_Object_Transaction::LEDGER_BANKING_FEE_BELFIUS,
        BelgianBankTransferAccount::class            => AccountView_Object_Transaction::LEDGER_BANKING_FEE_BANKTRANSFER,
        DeutscheBankDutchBankTransferAccount::class  => AccountView_Object_Transaction::LEDGER_BANKING_FEE_BANKTRANSFER,
        DeutscheBankGermanBankTransferAccount::class => AccountView_Object_Transaction::LEDGER_BANKING_FEE_BANKTRANSFER,
        BitcoinAccount::class                        => AccountView_Object_Transaction::LEDGER_BANKING_FEE_BITCOIN_AND_PAYSAFECARD,
        ConsumerRefundsAccount::class                => AccountView_Object_Transaction::LEDGER_BANKING_FEE_REFUND,
        DeutscheBankRefundsAccount::class            => AccountView_Object_Transaction::LEDGER_BANKING_FEE_REFUND,
        DeutscheBankBelgiumOutpaymentsAccount::class => AccountView_Object_Transaction::LEDGER_BANKING_FEE_OUTPAYMENT,
        DeutscheBankDutchOutpaymentsAccount::class   => AccountView_Object_Transaction::LEDGER_BANKING_FEE_OUTPAYMENT,
        DeutscheBankFrenchOutpaymentsAccount::class  => AccountView_Object_Transaction::LEDGER_BANKING_FEE_OUTPAYMENT,
        DeutscheBankGermanOutpaymentsAccount::class  => AccountView_Object_Transaction::LEDGER_BANKING_FEE_OUTPAYMENT,
        DeutscheBankPolishOutpaymentsAccount::class  => AccountView_Object_Transaction::LEDGER_BANKING_FEE_OUTPAYMENT,
        DirectDebitAbnAccount::class                 => AccountView_Object_Transaction::LEDGER_BANKING_FEE_SEPA_DIRECT_DEBIT,
        DirectDebitIngAccount::class                 => AccountView_Object_Transaction::LEDGER_BANKING_FEE_SEPA_DIRECT_DEBIT,
        DirectDebitRabobankAccount::class            => AccountView_Object_Transaction::LEDGER_BANKING_FEE_SEPA_DIRECT_DEBIT,
        DeutscheBankDutchDirectDebitAccount::class   => AccountView_Object_Transaction::LEDGER_BANKING_FEE_SEPA_DIRECT_DEBIT,
        DeutscheBankGermanDirectDebitAccount::class  => AccountView_Object_Transaction::LEDGER_BANKING_FEE_SEPA_DIRECT_DEBIT,
        DutchBankTransferAccount::class              => AccountView_Object_Transaction::LEDGER_BANKING_FEE_BANKTRANSFER,
        FrenchBankTransferAccount::class             => AccountView_Object_Transaction::LEDGER_BANKING_FEE_BANKTRANSFER,
        GermanBankTransferAccount::class             => AccountView_Object_Transaction::LEDGER_BANKING_FEE_BANKTRANSFER,
        IdealAbnAccount::class                       => AccountView_Object_Transaction::LEDGER_BANKING_FEE_IDEAL,
        IdealIngAccount::class                       => AccountView_Object_Transaction::LEDGER_BANKING_FEE_IDEAL,
        IdealRabobankAccount::class                  => AccountView_Object_Transaction::LEDGER_BANKING_FEE_IDEAL,
        DeutscheBankIdealAccount::class              => AccountView_Object_Transaction::LEDGER_BANKING_FEE_IDEAL,
        KbcAccount::class                            => AccountView_Object_Transaction::LEDGER_BANKING_FEE_KBC,
        OldSofortAccount::class                      => AccountView_Object_Transaction::LEDGER_BANKING_FEE_SOFORT,
        PproEurSettlementAccount::class              => AccountView_Object_Transaction::LEDGER_BANKING_FEE_BANCONTACT,
        RabobankOutpaymentsAccount::class            => AccountView_Object_Transaction::LEDGER_BANKING_FEE_OUTPAYMENT,
        SofortAccount::class                         => AccountView_Object_Transaction::LEDGER_BANKING_FEE_SOFORT,
        SofortStartselectAccount::class              => AccountView_Object_Transaction::LEDGER_BANKING_FEE_SOFORT,
        ValitorAccount::class                        => AccountView_Object_Transaction::LEDGER_BANKING_FEE_VALITOR,
    ];

    /** @var BankAccountRepository */
    private $bank_account_repository;

    public function __construct(BankAccountRepository $bank_account_repository)
    {
        $this->bank_account_repository = $bank_account_repository;
    }

    /**
     * Returns specific banking fee ledger number for the bank account with given ID.
     */
    public function getBankingFeeLedgerForBankAccountId(int $bankaccount_id): int
    {
        try {
            $bank_account = $this->bank_account_repository->getById($bankaccount_id);
        } catch (BankAccountNotFoundException $e) {
            apm_log_exception(
                new Exception(
                    "Could not determine banking fee ledger number for bank account with ID: " . $bankaccount_id,
                    $e->getCode(),
                    $e
                ),
                E_WARNING
            );

            // In this kind of exceptional cases, use the default ledger number for banking fees.
            return self::BANKING_FEES_DEFAULT_LEDGER_NUMBER;
        }

        if (isset(self::BANKING_FEES_ACCOUNT_LEDGER_MAP[get_class($bank_account)])) {
            return self::BANKING_FEES_ACCOUNT_LEDGER_MAP[get_class($bank_account)];
        }

        return self::BANKING_FEES_DEFAULT_LEDGER_NUMBER;
    }
}
