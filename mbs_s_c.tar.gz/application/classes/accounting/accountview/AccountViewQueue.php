<?php

namespace Accounting\AccountView;

use AccountView_Model_Queue;
use Orm\ModelFactory;

class AccountViewQueue
{
    public const TYPE_MERCHANT_PRE_PAYMENTS = 'merchant-prepayments';

    /** @var ModelFactory */
    private $model_factory;

    public function __construct(ModelFactory $model_factory)
    {
        $this->model_factory = $model_factory;
    }

    public function queueXmlMessage(string $xml, string $message_type)
    {
        $av_queue_item = $this->model_factory->create(AccountView_Model_Queue::class);

        $av_queue_item->xml    = $xml;
        $av_queue_item->type   = $message_type;
        $av_queue_item->status = AccountView_Model_Queue::STATUS_WAITING;

        $av_queue_item->saveOrDie();
    }
}
