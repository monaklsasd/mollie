<?php

namespace Accounting\AccountView\Export;

use Accounting\Exceptions\InvalidPrePaymentAggregationException;
use Accounting\PrePaymentAggregationService;
use AccountView_Ledger;
use AccountView_Object_Aggregated_Transaction;
use AccountView_Object_Exception;
use AccountView_Object_Statement;
use AccountView_Object_Subject;
use AccountView_Object_Transaction;
use App\Util\DateTime\Now;
use BankAccounts\BankAccountRepository;
use Config_Accountview;
use Core\InvoiceNumber;
use Core\Localization\Localizer;
use Core\Strings;
use Core\Time\TimeZones;
use DateTimeImmutable;
use Model\Transaction\TransactionTags;
use Model_Bankstatement;
use Model_Banktransaction;
use Money\Money;
use Orm\Repositories\BanktransactionRepository;
use Supplier\Mollie\Mollie;
use Supplier\Mollie\MollieException;
use Supplier\Mollie\Response\OutpaymentTransaction;
use function Core\Money\money_from_string;
use function Core\Money\money_to_string;

class BankstatementTransformer
{
    use Now;
    public const UNGROUPABLE_TRANSACTION_TAGS = [
        TransactionTags::TAG_VALITOR_DETAIL,
        TransactionTags::TAG_VALITOR_SETTLEMENT,
        TransactionTags::TAG_VALITOR_SETTLEMENT_UNSPECIFIED,
        TransactionTags::TAG_AMEX_FEE_VARIABLE,
        TransactionTags::TAG_AMEX_SETTLEMENT_EXPANDED,
        TransactionTags::TAG_AMEX_SETTLEMENT_NEW,
    ];

    /** @var Config_Accountview */
    private $config;

    /** @var Mollie */
    private $mollie_supplier;

    /** @var PrePaymentAggregationService */
    private $aggregation_service;

    /** @var BankAccountRepository */
    private $bank_account_repository;

    /** @var BanktransactionRepository */
    private $bank_transaction_repository;

    /** @var TransactionTransformer */
    private $transaction_transformer;

    public function __construct(
        Config_Accountview $config,
        Mollie $mollie_supplier,
        PrePaymentAggregationService $aggregation_service,
        BankAccountRepository $bank_account_repository,
        BanktransactionRepository $bank_transaction_repository,
        TransactionTransformer $transaction_transformer
    ) {
        $this->config                      = $config;
        $this->mollie_supplier             = $mollie_supplier;
        $this->aggregation_service         = $aggregation_service;
        $this->bank_account_repository     = $bank_account_repository;
        $this->bank_transaction_repository = $bank_transaction_repository;
        $this->transaction_transformer     = $transaction_transformer;
    }

    /**
     * @throws \AccountView_Object_Exception
     * @throws \BankAccounts\Exceptions\BankAccountNotFoundException
     */
    public function transform(Model_Bankstatement $bank_statement): AccountView_Object_Statement
    {
        // Convert this model into AccountView object
        $av_statement = new AccountView_Object_Statement();

        $bank_account = $bank_statement->getBankAccount();
        $av_statement
            ->setBankAccountNumber($bank_account::getIban())
            ->setDate($bank_statement->getStatementDate()->format('Y-m-d'))
            ->setCurrency($bank_statement->getCurrency()->getCode())
            ->setDjCode($bank_account::getBankTag())
            ->setStatementNumber((string)$bank_statement->getStatementNumber())
            ->setDescription(sprintf(
                "%s: %s",
                $bank_account::getIban(),
                $bank_statement->getStatementReference()
            ))
            ->setOpeningBalance(money_to_string($bank_statement->getOpeningBalance()))
            ->setClosingBalance(money_to_string($bank_statement->getClosingBalance()))
            ->setAdministration(sprintf(
                '%s%s',
                $this->config->getAdministration(),
                $bank_statement->getStatementDate()->format('Y')
            ));

        $is_outpayment_account = $this->bank_account_repository->isOutpaymentBankAccount($bank_account::getId());

        // Iterate through related transactions to:
        //   1. Convert regular transactions into AccountView objects
        //   2. Collect "outpayment transactions"

        /** @var AccountView_Object_Transaction[] $av_transactions */
        $av_transactions = [];
        /** @var Money[] $outpayment_references */
        $outpayment_references = [];
        /** @var string[] $invoice_references */
        $invoice_references = [];

        /*
         * Iterate over all transactions that are not child transactions
         */
        foreach ($this->bank_transaction_repository->yieldInnerMostTransactionsByStatementId((int)$bank_statement->getPrimaryKey()) as $transaction) {
            if ($transaction->getAmount()->isZero()) {
                continue; // Zero-amount transactions exist for fx-margins for very low transaction amounts.
            }

            /*
             * Outpayments should never be collapsed, if we detect an outpayment export it as such
             * instead of a normal transaction. Debited only, because then we know the transaction is
             * initialized by us, not an out-of-workflow transaction from the user.
             */
            if ($is_outpayment_account
                && $transaction->isDebited()
                && $outpayment_reference = $transaction->getOutpaymentReference()
            ) {
                /*
                 * An outpayment might be split in multiple bank transfers. In that case, we want to sum the outpayment
                 * amounts so we can end with the correct amount.
                 *
                 * For example, Finance may choose to transfer a amount manually like this:
                 *
                 * - € -1107165.32 BITONIC B V REF 832437.1711.04 deel 4
                 * - € -1500000.00 BITONIC B V REF 832437.1711.04 deel 3
                 * - € -1500000.00 BITONIC B V REF 832437.1711.04 deel 2
                 * - € -1500000.00 BITONIC B V REF 832437.1711.04 deel 1
                 */
                if (!array_key_exists($outpayment_reference, $outpayment_references)) {
                    $outpayment_references[$outpayment_reference] = new Money(0, $bank_statement->getCurrency());
                }

                $outpayment_references[$outpayment_reference] = $outpayment_references[$outpayment_reference]->add(
                    $transaction->getAmount()
                );

                continue;
            }

            $av_transaction = $this->transaction_transformer->transform($transaction);
            $av_transaction->setCurrency($transaction->getCurrency()->getCode());

            // When we have to collapse, we merge transactions based on the arguments set in the 'hash'
            if ($this->isCollapsable($transaction)) {
                $av_transaction = AccountView_Object_Aggregated_Transaction::fromTransaction($av_transaction);

                $transaction_hash = sprintf(
                    '%s.%s.%s.%s',
                    $transaction->getEntryDate()->format('Y-m-d'),
                    implode(',', $transaction->getTags()),
                    $transaction->isCredited() ? '+' : '-',
                    $transaction->isLedgerTransaction() ? 'Ledger' : 'Legacy'
                );

                if (array_key_exists($transaction_hash, $av_transactions)) {
                    $av_transactions[$transaction_hash]->addTransaction($av_transaction);
                } else {
                    $av_transactions[$transaction_hash] = $av_transaction;
                }

                continue;
            }

            // When should not collapse, store by id
            $av_transactions[$transaction->getPrimaryKey()] = $av_transaction;

            // We only look for invoices when the transactions are exported individually.
            if ($invoice_reference = $transaction->getInvoiceNumber()) {
                $invoice_references[] = $invoice_reference;
            }
        }

        $this->addTransactions($av_statement, $av_transactions);
        $this->addInvoicesToStatement($av_statement, $invoice_references);
        $this->addOutpaymentTransactions($av_statement, $outpayment_references);

        $av_statement_amount = money_from_string($av_statement->getTotalAmount(), $bank_statement->getCurrency());

        if (!$bank_statement->getMutationAmount()->equals($av_statement_amount)) {
            throw new AccountView_Object_Exception(sprintf(
                'Statement amount %s and transactions total amount %s are not the same.',
                Localizer::formatMoney($bank_statement->getMutationAmount()),
                Localizer::formatMoney($av_statement_amount)
            ));
        }

        return $av_statement;
    }

    /**
     * @param AccountView_Object_Transaction[] $av_transactions
     */
    private function addTransactions(AccountView_Object_Statement $av_statement, array $av_transactions): void
    {
        $this->amendDescriptionForInternalTransactions($av_transactions);

        foreach ($av_transactions as $av_transaction) {
            $av_statement->addTransaction($av_transaction);
        }
    }

    /**
     * @param AccountView_Object_Transaction[] $av_transactions
     */
    private function amendDescriptionForInternalTransactions(array &$av_transactions): void
    {
        foreach ($av_transactions as &$av_transaction) {
            /*
             * In the AccountView administration, there is only one ledger number for both internal & intra_company.
             * In Twinfield, we have more advanced bookkeeping
             * Prefix the description with the tag so we have the info when we do the conversion.
             *
             * @issue PROC-458
             *
             * Moved from transactiontransformer to statementtransformer to work for collapsed transactions as well.
             */
            if (self::hasAnyOfTags(
                $av_transaction,
                [TransactionTags::TAG_INTERNAL, TransactionTags::TAG_INTRA_COMPANY]
            )) {
                // Convert to normal transaction because we cannot set the description of aggregated transactions
                if ($av_transaction instanceof AccountView_Object_Aggregated_Transaction) {
                    $av_transaction = AccountView_Object_Transaction::fromAggregatedTransaction($av_transaction);
                }

                $av_transaction->setDescription(sprintf(
                    '%s: %s',
                    $av_transaction->getType(),
                    $av_transaction->getDescription()
                ));
            }
        }
    }

    /**
     * @param Money[] $outpayment_references
     *
     * @throws AccountView_Object_Exception
     * @throws InvalidPrePaymentAggregationException
     */
    private function addOutpaymentTransactions(
        AccountView_Object_Statement $av_statement,
        array $outpayment_references
    ): void {
        if (count($outpayment_references) === 0) {
            return;
        }

        uksort($outpayment_references, function ($ref_a, $ref_b) {
            $customer_a = strstr($ref_a, '.', true);
            $customer_b = strstr($ref_b, '.', true);

            if ($customer_a === $customer_b) {
                $rest_a = mb_substr($ref_a, mb_strpos($ref_a, '.') + 1);
                $rest_b = mb_substr($ref_b, mb_strpos($ref_b, '.') + 1);

                return $rest_a > $rest_b;
            }

            return $customer_a > $customer_b;
        });

        $outpayment_infos        = $this->mollie_supplier->getOutpaymentsInformation($outpayment_references);
        $outpayment_transactions = [];

        foreach ($outpayment_infos as $outpayment_info) {
            // Add customer to statement debitors
            $av_subject = new AccountView_Object_Subject();
            $av_subject->generateTrxUid();
            $av_subject->setCode($outpayment_info->getDebitor()->getSubNumber())
                ->setName($outpayment_info->getDebitor()->getAccountName())
                ->setVatNumber($outpayment_info->getDebitor()->getVatNumber());
            $av_statement->addSubject($av_subject);

            $outpayment_sum = new Money(0, $outpayment_info->getCurrency());

            // Add each subtotal to statement transactions
            foreach ($outpayment_info->getTransactions() as $outpayment_transaction) {
                // AccountView does not work well with debtor amount = 0.
                // Do not export zero debtor amount to AccountView. Refs #12125
                if ($outpayment_transaction->getAccountviewLedgerNumber() === AccountView_Object_Transaction::LEDGER_DEBTOR
                    && $outpayment_transaction->getAmount()->isZero()
                ) {
                    continue;
                }

                $av_transaction = self::outpaymentTransactionToAccountViewObject(
                    $outpayment_transaction,
                    $av_statement->getDate()
                );

                $outpayment_sum = $outpayment_sum->add($outpayment_transaction->getAmount());

                if (self::outpaymentSubtotalRequiresAttention($av_transaction)) {
                    $av_statement->addTransaction($av_transaction);
                } else {
                    $outpayment_transactions[] = $av_transaction;
                }
            }

            $difference = $outpayment_references[$outpayment_info->getReference()]->subtract($outpayment_sum)->absolute();

            if (!$difference->isZero()) {
                throw new AccountView_Object_Exception(sprintf(
                    'Outpayment %s has a difference of %s (%s - %s)',
                    $outpayment_info->getReference(),
                    Localizer::formatMoney($difference),
                    Localizer::formatMoney($outpayment_references[$outpayment_info->getReference()]),
                    Localizer::formatMoney($outpayment_sum)
                ));
            }
        }

        foreach ($this->aggregateOutpaymentTransactions($av_statement, $outpayment_transactions) as $outpayment_transaction) {
            $av_statement->addTransaction($outpayment_transaction);
        }
    }

    private function addInvoicesToStatement(AccountView_Object_Statement $av_statement, array $invoice_references): void
    {
        try {
            $invoices = $this->mollie_supplier->getInvoiceInformation($invoice_references);
        } catch (MollieException $e) {
            throw new AccountView_Object_Exception(sprintf(
                'Error retrieving invoice information from Mollie for bank statement #%s: %s',
                $av_statement->getStatementNumber(),
                $e->getMessage()
            ), 0, $e);
        }

        foreach ($invoices as $invoice) {
            // Add customer to statement debitors
            $av_subject = new AccountView_Object_Subject();
            $av_subject->generateTrxUid();
            $av_subject->setCode($invoice->getDebitor()->getSubNumber())
                ->setName($invoice->getDebitor()->getAccountName())
                ->setVatNumber($invoice->getDebitor()->getVatNumber());

            $av_statement->addSubject($av_subject);
        }
    }

    protected static function outpaymentTransactionToAccountViewObject(
        OutpaymentTransaction $transaction,
        $statement_date
    ): AccountView_Object_Transaction {
        $av_transaction = new AccountView_Object_Transaction();

        $av_transaction->setSubNumber($transaction->getSubNumber());
        $av_transaction->setLedgerNumber($transaction->getAccountviewLedgerNumber());
        $av_transaction->setInvoiceNumber($transaction->getInvoiceNumber());
        $av_transaction->setAmount(money_to_string($transaction->getAmount()));
        $av_transaction->setCurrency($transaction->getCurrency()->getCode());
        $av_transaction->setDescription($transaction->getDescription());
        $av_transaction->setCostCode($transaction->getCostCode() ?: '');
        $av_transaction->setDate($statement_date);

        return $av_transaction;
    }

    private static function outpaymentSubtotalRequiresAttention(AccountView_Object_Transaction $av_transaction): bool
    {
        if ($av_transaction->getInvoiceNumber() === '') {
            return true;
        }

        if (Strings::startsWith($av_transaction->getDescription(), 'HANDM.')) {
            return true;
        }

        if (Strings::endsWith($av_transaction->getDescription(), 'AMOUNT MISMATCH')) {
            return true;
        }

        return false;
    }

    /**
     * Aggregate AccountView Outpayment transactions by suspense account. If not a suspense account, the transaction is
     * copied and returned as is.
     *
     * This will, in effect, merge all the payment method settlements together each day while leaving the debtor ledger
     * transactions as is.
     *
     * Assumptions:
     * - All transactions should have identical entry dates.
     *
     * @param AccountView_Object_Transaction[] $transactions
     *
     * @throws InvalidPrePaymentAggregationException
     * @throws AccountView_Object_Exception
     *
     * @return AccountView_Object_Transaction[]
     */
    protected function aggregateOutpaymentTransactions(
        AccountView_Object_Statement $av_statement,
        array $transactions
    ): array {
        /** @var AccountView_Object_Transaction[] $unaggregated_transactions */
        $unaggregated_transactions = [];

        /** @var AccountView_Object_Transaction[] $suspense_account_transactions */
        $suspense_account_transactions = [];

        /** @var int[] $count_suspense_account_transactions */
        $count_suspense_account_transactions = [];

        /** @var AccountView_Object_Transaction $debitor_account_transaction */
        $debitor_account_transaction = null;

        $debitor_account_transaction_count = 0;

        foreach ($transactions as $transaction) {
            /*
             * We want to aggregate\compress all the merchant's withheld costs into a single booking.
             */
            if ($this->isMerchantPrePayment($av_statement, $transaction)) {
                $this->aggregation_service->recordAggregation(
                    InvoiceNumber::fromString($transaction->getInvoiceNumber()),
                    $transaction->getSubNumber(),
                    bcadd((string)$transaction->getAmount(), '0', 2),
                    new DateTimeImmutable($transaction->getDate(), TimeZones::amsterdam())
                );

                if ($debitor_account_transaction === null) {
                    $debitor_account_transaction = new AccountView_Object_Transaction();
                    $debitor_account_transaction->setLedgerNumber(
                        AccountView_Object_Transaction::LEDGER_MERCHANT_PREPAYMENTS
                    );
                    $debitor_account_transaction->setDate($av_statement->getDate());
                }

                $debitor_account_transaction_count++;
                $debitor_account_transaction->addAmount($transaction->getAmount());

                continue;
            }

            if (!AccountView_Ledger::isSuspenseAccount((int)$transaction->getLedgerNumber())) {
                $unaggregated_transactions[] = $transaction;

                continue;
            }

            /*
             * Group by ledger number and by cost code. For the current year, the cost code will be empty string.
             * For earlier years, the cost code will be that year.
             */
            $key = sprintf('%s-%s', $transaction->getLedgerNumber(), $transaction->getCostCode());

            if (empty($suspense_account_transactions[$key])) {
                $suspense_account_transactions[$key] = new AccountView_Object_Transaction();
                $suspense_account_transactions[$key]
                    ->setDate($transaction->getDate())
                    ->setCurrency($transaction->getCurrency())
                    ->setDescription(sprintf(
                        'Aggregated %s for %s',
                        $transaction->getLedgerNumber(),
                        $transaction->getDate()
                    ))
                    ->setLedgerNumber($transaction->getLedgerNumber())
                    ->setCostCode($transaction->getCostCode());

                /* Keep a count */
                $count_suspense_account_transactions[$key] = 0;
            }

            $count_suspense_account_transactions[$key]++;
            $suspense_account_transactions[$key]->addAmount($transaction->getAmount());
        }

        foreach ($suspense_account_transactions as $key => $suspense_account_transaction) {
            $suspense_account_transaction->setDescription(
                "{$suspense_account_transaction->getDescription()} ({$count_suspense_account_transactions[$key]}x)"
            );
        }

        /*
         * Sort by key (which, conveniently, is ledger no / cost code,
         * so that the order always is consistent.
         */
        ksort($suspense_account_transactions);

        if ($debitor_account_transaction !== null) {
            $debitor_account_transaction->setDescription(
                "{$debitor_account_transaction_count}x Prepayments of merchants"
            );
            $debitor_account_transaction->setCurrency($transaction->getCurrency());

            return array_merge(
                array_values($suspense_account_transactions),
                [$debitor_account_transaction],
                $unaggregated_transactions
            );
        }

        return array_merge(
            array_values($suspense_account_transactions),
            $unaggregated_transactions
        );
    }

    private function isMerchantPrePayment(
        AccountView_Object_Statement $av_statement,
        AccountView_Object_Transaction $av_transaction
    ): bool {
        $isDebtor = $av_transaction->getLedgerNumber() === (string)AccountView_Object_Transaction::LEDGER_DEBTOR;

        $isOutpaymentBankAccount = $this->bank_account_repository->isOutpaymentBankAccount(
            $this->bank_account_repository->getByIbanOrAccountNumber($av_statement->getBankAccountNumber())::getId()
        );

        return $isDebtor && $isOutpaymentBankAccount;
    }

    private function isCollapsable(Model_Banktransaction $transaction): bool
    {
        if (!$this->bank_account_repository->getById($transaction->getBankAccountId())::shouldBeAggregatedForExport()) {
            return false;
        }

        if ($transaction->hasAnyOfTags(self::UNGROUPABLE_TRANSACTION_TAGS)) {
            return false;
        }

        return true;
    }

    private static function hasAnyOfTags(AccountView_Object_Transaction $av_transaction, array $tags): bool
    {
        return count(array_intersect($tags, explode(',', $av_transaction->getType()))) > 0;
    }
}
