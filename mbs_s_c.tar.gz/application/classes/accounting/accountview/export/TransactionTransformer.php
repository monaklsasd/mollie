<?php

namespace Accounting\AccountView\Export;

use Accounting\AccountView\Mapping\BankingFeeLedgerMapper;
use AccountView_Object_Subject;
use AccountView_Object_Transaction;
use BankAccounts\BankAccountRepository;
use BankAccounts\Exceptions\BankAccountNotFoundException;
use ClearingAccounts;
use Config_Accountview;
use Determination\BankTransactionDeterminer;
use Helper\BankTransaction\Matching\PrepaymentSettlementMatcher;
use Ledger\Journal;
use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use Supplier\Mccs\Valitor\Settlement\Detail as ValitorSettlementDetail;
use function Core\Money\money_to_string;

class TransactionTransformer
{
    /** @var Config_Accountview */
    private $accountview_config;

    /** @var BankingFeeLedgerMapper */
    private $banking_fee_ledger_mapper;

    /** @var BankAccountRepository */
    private $bank_account_repository;

    /** @var BankTransactionDeterminer */
    private $transaction_determiner;

    public function __construct(
        Config_Accountview $config,
        BankingFeeLedgerMapper $banking_fee_ledger_mapper,
        BankAccountRepository $bank_account_repository,
        BankTransactionDeterminer $transaction_determiner
    ) {
        $this->accountview_config        = $config;
        $this->banking_fee_ledger_mapper = $banking_fee_ledger_mapper;
        $this->bank_account_repository   = $bank_account_repository;
        $this->transaction_determiner    = $transaction_determiner;
    }

    public function transform(Model_Banktransaction $bank_transaction): AccountView_Object_Transaction
    {
        // Convert this into AccountView object
        $av_transaction = new AccountView_Object_Transaction();

        $av_transaction->setAmount(money_to_string($bank_transaction->getAmount()))
            ->setCurrency($bank_transaction->getCurrency()->getCode())
            ->setDate($bank_transaction->getEntryDate()->format('Y-m-d')) // Make sure we use the entry date (boekdatum) here.
            ->setType(implode(',', $bank_transaction->getTags()))
            ->setDescription(trim($bank_transaction->getDescription()))
            ->setAdministration($this->accountview_config->getAdministration() . $bank_transaction->getEntryDate()->format('Y'));

        // @codeCoverageIgnoreStart
        if (MOLLIE_ENV === 'development') {
            // In development: Set defaults
            $av_transaction->setLedgerNumber('LEEGTEST');
            $av_transaction->setInvoiceNumber(2200);
        }
        // @codeCoverageIgnoreEnd

        // Set invoice number and ledger number based on transaction type/details
        if ($bank_transaction->getInvoiceNumber()) {
            $av_transaction->setInvoiceNumber($bank_transaction->getInvoiceNumber());
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_DEBTOR);
        } elseif ($bank_transaction->hasAnyOfTags([TransactionTags::TAG_INTERNAL, TransactionTags::TAG_INTRA_COMPANY])) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_KRUISPOSTEN);
        } elseif ($bank_transaction->isTransferSmpToBv()) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_MERCHANT_PREPAYMENTS);
        } elseif ($bank_transaction->isBankingFee()) {
            $av_transaction->setLedgerNumber(
                $this->banking_fee_ledger_mapper->getBankingFeeLedgerForBankAccountId($bank_transaction->getBankAccountId())
            );
        } elseif ($bank_transaction->isReceivedBankaccountVerification()) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_ACCOUNT_VERIFICATION_PAYMENTS);
        } elseif ($bank_transaction->isReceivedIdeal()) {
            $av_transaction->setLedgerNumber(
                ClearingAccounts::idealPayments($bank_transaction)->getLedgerNumber()
            );
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_UNKNOWNIDEAL)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_WRONGLY_RECEIVED_PAYMENTS);
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_FAILUREIDEAL)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_INVALID_RECEIVED_IDEAL_PAYMENTS);
        } elseif ($bank_transaction->isAdyenOutpayment()) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_TUSSENREKENING_ADYEN);
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_REFUNDS)) {
            /* Both refunds and failed refunds should go here. */
            $av_transaction->setLedgerNumber(
                ClearingAccounts::refunds($bank_transaction)->getLedgerNumber()
            );
        } elseif ($bank_transaction->isReceivedMisterCash()) {
            $av_transaction->setLedgerNumber(
                ClearingAccounts::bancontactPayments($bank_transaction)->getLedgerNumber()
            );
        } elseif ($bank_transaction->isReceivedBankTransfer()) {
            $av_transaction->setLedgerNumber(
                ClearingAccounts::bankTransferPayments($bank_transaction)->getLedgerNumber()
            );
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_UNKNOWNBANKTRANSFER)) {
            $ledger_number = AccountView_Object_Transaction::LEDGER_WRONGLY_RECIEVED_SCT_PAYMENTS;

            $bank_account = null;

            try {
                $bank_account = $this->bank_account_repository->getById($bank_transaction->getBankAccountId());
            } catch (BankAccountNotFoundException $e) {
            }

            switch (substr($bank_account ? $bank_account::getIban() : '', 0, 2)) {
                case 'BE':
                    $ledger_number = AccountView_Object_Transaction::LEDGER_WRONGLY_RECIEVED_SCT_PAYMENTS_BELGIUM;

                    break;

                case 'DE':
                    $ledger_number = AccountView_Object_Transaction::LEDGER_WRONGLY_RECEIVED_SCT_PAYMENTS_GERMANY;

                    break;

                case 'FR':
                    $ledger_number = AccountView_Object_Transaction::LEDGER_WRONGLY_RECEIVED_SCT_PAYMENTS_FRANCE;

                    break;
            }
            $av_transaction->setLedgerNumber($ledger_number);
        } elseif ($bank_transaction->isReceivedBitcoin()) {
            $av_transaction->setLedgerNumber(
                ClearingAccounts::bitcoinPayments($bank_transaction)->getLedgerNumber()
            );
        } elseif ($bank_transaction->isReceivedSofortBanking()) {
            $av_transaction->setLedgerNumber(
                ClearingAccounts::sofortPayments($bank_transaction)->getLedgerNumber()
            );
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_UNKNOWNSOFORT)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_WRONGLY_RECIEVED_SOFORT_PAYMENTS);
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_FAILURESOFORT)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_INVALID_RECIEVED_SOFORT_PAYMENTS);
        }
        /*
         * Belfius
         */
        elseif ($bank_transaction->isReceivedBelfiusDirectNet()) {
            $av_transaction->setLedgerNumber(
                ClearingAccounts::belfiusPayments($bank_transaction)->getLedgerNumber()
            );
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_UNKNOWNBELFIUS)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_WRONGLY_RECIEVED_BELFIUS_PAYMENTS);
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_FAILUREBELFIUS)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_INVALID_RECIEVED_BELFIUS_PAYMENTS);
        }
        /*
         * PPro fees
         */
        elseif ($bank_transaction->hasTag(TransactionTags::TAG_PPRO_FEE_VARIABLE_EPS)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_PPRO_EPS_FEES);
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_PPRO_FEE_VARIABLE_BANCONTACT)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_PPRO_BANCONTACT_FEES);
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_PPRO_FEE_VARIABLE_GIROPAY)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_PPRO_GIROPAY_FEES);
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_PPRO_FEE_VARIABLE_MYBANK)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_PPRO_MYBANK_FEES);
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_PPRO_FEE_VARIABLE_PRZELEWY24)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_PPRO_PRZELEWY24_FEES);
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_PPRO_FEE_VARIABLE)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_PPRO_GIROPAY_FEES);
        }

        /*
         * KBC
         */
        elseif ($bank_transaction->isReceivedKbc()) {
            $av_transaction->setLedgerNumber(
                ClearingAccounts::kbcPayments($bank_transaction)->getLedgerNumber()
            );
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_UNKNOWNKBC)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_WRONGLY_RECEIVED_KBC_PAYMENTS);
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_FAILUREKBC)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_INVALID_RECEIVED_KBC_PAYMENTS);
        }
        /*
         * ING Home'Pay
         */
        elseif ($bank_transaction->isReceivedIngHomePay()) {
            $av_transaction->setLedgerNumber(
                ClearingAccounts::ingHomepayPayments($bank_transaction)->getLedgerNumber()
            );
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_UNKNOWNINGHOMEPAY)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_WRONGLY_RECEIVED_INGHOMEPAY_PAYMENTS);
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_FAILUREINGHOMEPAY)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_INVALID_RECEIVED_INGHOMEPAY_PAYMENTS);
        }
        /*
         * Giropay
         */
        elseif ($bank_transaction->isReceivedGiropay()) {
            $av_transaction->setLedgerNumber(
                ClearingAccounts::giropayPayments($bank_transaction)->getLedgerNumber()
            );
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_UNKNOWNGIROPAY)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_WRONGLY_RECEIVED_GIROPAY_PAYMENTS);
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_FAILUREGIROPAY)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_INVALID_RECEIVED_GIROPAY_PAYMENTS);
        }
        /*
         * EPS
         */
        elseif ($bank_transaction->isReceivedEps()) {
            $av_transaction->setLedgerNumber(
                ClearingAccounts::epsPayments($bank_transaction)->getLedgerNumber()
            );
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_UNKNOWNEPS)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_WRONGLY_RECEIVED_EPS_PAYMENTS);
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_FAILUREEPS)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_INVALID_RECEIVED_EPS_PAYMENTS);
        }
        /*
         * Przelewy24
         */
        elseif ($bank_transaction->isReceivedPrzelewy24Refund()) {
            $av_transaction->setLedgerNumber(
                ClearingAccounts::przelewy24Refunds($bank_transaction)->getLedgerNumber()
            );
        } elseif ($bank_transaction->isReceivedPrzelewy24()) {
            $av_transaction->setLedgerNumber(
                ClearingAccounts::przelewy24Payments($bank_transaction)->getLedgerNumber()
            );
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_UNKNOWNPRZELEWY24)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_WRONGLY_RECEIVED_PRZELEWY24_PAYMENTS);
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_FAILUREPRZELEWY24)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_INVALID_RECEIVED_PRZELEWY24_PAYMENTS);
        }
        /*
         * MyBank
         */
        elseif ($bank_transaction->isReceivedMyBank()) {
            $av_transaction->setLedgerNumber(
                ClearingAccounts::mybankPayments($bank_transaction)->getLedgerNumber()
            );
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_UNKNOWNMYBANK)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_WRONGLY_RECEIVED_MYBANK_PAYMENTS);
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_FAILUREMYBANK)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_INVALID_RECEIVED_MYBANK_PAYMENTS);
        }
        /*
         * MisterCash
         */
        elseif ($bank_transaction->hasTag(TransactionTags::TAG_UNKNOWNMISTERCASH)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_WRONGLY_RECIEVED_MISTERCASH_PAYMENTS);
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_FAILUREMISTERCASH)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_INVALID_RECIEVED_MISTERCASH_PAYMENTS);
        }
        /*
         * Direct Debit
         */
        elseif ($bank_transaction->isReceivedStornoDirectDebit()) {
            $av_transaction->setLedgerNumber(
                ClearingAccounts::directDebitChargebacks($bank_transaction)->getLedgerNumber()
            );
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_FAILUREDIRECTDEBIT)) {
            $av_transaction->setLedgerNumber(
                ClearingAccounts::directDebitFailures($bank_transaction)->getLedgerNumber()
            );
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_UNKNOWNDIRECTDEBIT)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_WRONGLY_RECIEVED_DIRECTDEBIT_PAYMENTS);
        } elseif ($bank_transaction->isReceivedSepaDirectDebit()) {
            $av_transaction->setLedgerNumber(
                ClearingAccounts::directDebitPayments($bank_transaction)->getLedgerNumber()
            );
        /*
         *  Direct Debit Fees/Costs
         */
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_STORNODIRECTDEBIT_COSTSEU)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_DIRECTDEBIT_COSTS_EU);
        }
        /*
         * Valitor
         */
        elseif ($bank_transaction->hasTag(TransactionTags::TAG_VALITOR_SETTLEMENT_UNSPECIFIED)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::VRAAGPOSTEN);
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_VALITOR_SETTLEMENT)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::VRAAGPOSTEN);
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_VALITOR_DETAIL)) {
            $tag_data = $bank_transaction->getTagData();

            if (isset($tag_data["settlement_key"])) {
                switch ($tag_data["settlement_key"]) {
                    case ValitorSettlementDetail::DETAIL_KEY_SALE:
                        $av_transaction->setLedgerNumber(
                            ClearingAccounts::creditCardPaymentsValitor($bank_transaction)->getLedgerNumber()
                        );

                        break;

                    case ValitorSettlementDetail::DETAIL_KEY_ROLLING_RELEASE:
                    case ValitorSettlementDetail::DETAIL_KEY_ROLLING_RESERVE:
                        $av_transaction->setLedgerNumber(
                            ClearingAccounts::creditCardRollingReserveValitor($bank_transaction)->getLedgerNumber()
                        );

                        break;

                    case ValitorSettlementDetail::DETAIL_KEY_REFUND:
                        $av_transaction->setLedgerNumber(
                            ClearingAccounts::creditCardRefundsValitor($bank_transaction)->getLedgerNumber()
                        );

                        break;

                    case ValitorSettlementDetail::DETAIL_KEY_CHARGEBACK:
                    case ValitorSettlementDetail::DETAIL_KEY_RE_PRESENTMENTS:
                    case ValitorSettlementDetail::DETAIL_KEY_REVERSALS:
                        $av_transaction->setLedgerNumber(
                            ClearingAccounts::creditCardChargebacksValitor($bank_transaction)->getLedgerNumber()
                        );

                        break;

                    case ValitorSettlementDetail::DETAIL_KEY_MERCHANT_SERVICE_CHARGES:
                    case ValitorSettlementDetail::DETAIL_KEY_COMMISSION_HIGH_RISK:
                    case ValitorSettlementDetail::DETAIL_KEY_COMMISSION_LOW_RISK:
                    case ValitorSettlementDetail::DETAIL_KEY_COMMISSION_MEDIUM_RISK:
                    case ValitorSettlementDetail::DETAIL_KEY_COMMISSION_LOW_AMOUNTS:
                        $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_VALITOR_VARIABLE_FEES);

                        break;

                    case ValitorSettlementDetail::DETAIL_KEY_CHARGEBACK_FEE_AGENT:
                    case ValitorSettlementDetail::DETAIL_KEY_CHARGEBACK_FEE_VALITOR:
                        $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_VALITOR_CHARGEBACK_FEES);

                        break;

                    case ValitorSettlementDetail::DETAIL_KEY_TRANSACTION_FEE_SETTLED:
                    case ValitorSettlementDetail::DETAIL_KEY_TRANSACTION_FEE_UNSETTLED:
                        $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_VALITOR_SETTLEMENT_FEES);

                        break;

                    case ValitorSettlementDetail::DETAIL_KEY_REGISTRATION_FEE:
                        $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_VALITOR_REGISTRATION_FEES);

                        break;

                    case ValitorSettlementDetail::DETAIL_KEY_SWIFT_FEE:
                        $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_VALITOR_SWIFT_FEES);

                        break;

                    case ValitorSettlementDetail::DETAIL_KEY_SCHEME_FEE:
                        $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_VALITOR_SCHEME_FEES);

                        break;

                    default:
                        $av_transaction->setLedgerNumber(AccountView_Object_Transaction::VRAAGPOSTEN);

                        break;
                }
            }
        }
        /*
         * AMEX
         */
        elseif ($bank_transaction->hasTag(TransactionTags::TAG_AMEX_SETTLEMENT_NEW)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::VRAAGPOSTEN);
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_AMEX_SETTLEMENT_EXPANDED)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::VRAAGPOSTEN);
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_AMEX_PAYMENT)) {
            $av_transaction->setLedgerNumber(
                ClearingAccounts::creditCardPaymentsAmex($bank_transaction)->getLedgerNumber()
            );
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_AMEX_REFUND)) {
            $av_transaction->setLedgerNumber(
                ClearingAccounts::creditCardRefundsAmex($bank_transaction)->getLedgerNumber()
            );
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_AMEX_CHARGEBACK)) {
            $av_transaction->setLedgerNumber(
                ClearingAccounts::creditCardChargebacksAmex($bank_transaction)->getLedgerNumber()
            );
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_AMEX_FEE_VARIABLE)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_AMEX_VARIABLE_FEES);
        }
        /**
         * Creditcard
         *
         * Section 'Creditcard' is placed below section 'Valitor' for Valitor detail transaction with tag 'unknowncreditcard,valitor_detail' like ADDEDS
         * These transactions should get the AV ledger number VRAAGPOSTEN and not LEDGER_WRONGLY_RECEIVED_CREDITCARD_PAYMENTS
         *
         * @see https://redmine.mollie.nl/issues/19158#note-11
         */
        elseif ($bank_transaction->isReceivedCreditcard()) {
            $av_transaction->setLedgerNumber(
                ClearingAccounts::creditCardPaymentsValitor($bank_transaction)->getLedgerNumber()
            );
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_CREDITCARD_REFUND)) {
            $av_transaction->setLedgerNumber(
                ClearingAccounts::creditCardRefundsValitor($bank_transaction)->getLedgerNumber()
            );
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_VALITOR_CHARGEBACK)) {
            $av_transaction->setLedgerNumber(
                ClearingAccounts::creditCardChargebacksValitor($bank_transaction)->getLedgerNumber()
            );
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_UNKNOWNCREDITCARD)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_WRONGLY_RECEIVED_CREDITCARD_PAYMENTS);
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_FAILURECREDITCARD)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_INVALID_RECEIVED_CREDITCARD_PAYMENTS);
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_FAILUREAMEX)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_INVALID_RECEIVED_AMEX_PAYMENTS);
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_UNKNOWNAMEX)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_WRONGLY_RECEIVED_AMEX_PAYMENTS);
        }

        /*
         * Klarna
         */
        elseif ($bank_transaction->isReceivedKlarnaRefund()) {
            $av_transaction->setLedgerNumber(
                ClearingAccounts::klarnaRefunds($bank_transaction)->getLedgerNumber()
            );
        } elseif ($bank_transaction->isReceivedKlarnaChargeback()) {
            $av_transaction->setLedgerNumber(
                ClearingAccounts::klarnaChargebacks($bank_transaction)->getLedgerNumber()
            );
        } elseif ($bank_transaction->isReceivedKlarnaPayLater()) {
            $av_transaction->setLedgerNumber(
                ClearingAccounts::klarnaPayLaterPayments($bank_transaction)->getLedgerNumber()
            );
        } elseif ($bank_transaction->isReceivedKlarnaSliceIt()) {
            $av_transaction->setLedgerNumber(
                ClearingAccounts::klarnaSliceItPayments($bank_transaction)->getLedgerNumber()
            );
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_UNKNOWNKLARNA)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_WRONGLY_RECEIVED_KLARNA_PAYMENTS);
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_FAILUREKLARNA)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_INVALID_RECEIVED_KLARNA_PAYMENTS);
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_KLARNA_CORRECTION)) {
            /**
             * We [temporally] use the Klarna Rolling reserve ledger.
             * We might need to change this in the future if/when a dedicated Klarna correction ledger is created.
             *
             * @see https://mollie.atlassian.net/browse/FFS-1003
             */
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_CLEARING_ACCOUNT_KLARNA_ROLLING_RESERVE);
        }

        /*
         * Klarna (Captures) child transactions
         */
        elseif ($bank_transaction->hasTag(TransactionTags::TAG_KLARNA_FEE)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_KLARNA_FEES);
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_KLARNA_FEE_DIFFERENCE)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_KLARNA_FEES);
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_KLARNA_FEE_DELAYED)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_KLARNA_FEES);
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_KLARNA_ROLLING_RESERVE)) {
            // We should not receive these.
        }

        /**
         * Multi-currency child transactions
         */
        elseif ($bank_transaction->hasTag(TransactionTags::TAG_MC_FX_MARGIN)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_MC_FX_MARGIN);
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_MC_EXCHANGE_RATE_DIFFERENCE)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_MC_EXCHANGE_RATE_DIFFERENCE);
        }

        /**
         * Banktransfer differences
         *
         * important: this matching should be done after unknownbanktransfer. Some transactions have both tags, unknown takes precedence.
         */
        elseif ($bank_transaction->hasTag(TransactionTags::TAG_BANKTRANSFER_DIFFERENCE)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_BANKTRANSFER_DIFFERENCES);
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_UNKNOWNOUTPAYMENT)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_WRONGLY_RECEIVED_OUTPAYMENT);
        }

        if ($bank_transaction->hasTag(TransactionTags::TAG_TRANSFER)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_CLEARING_ACCOUNT_MERCHANTS);
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_FAILURETRANSFER)) {
            $av_transaction->setLedgerNumber(AccountView_Object_Transaction::LEDGER_CLEARING_ACCOUNT_MERCHANTS);
        } elseif ($outpayment_reference = $bank_transaction->getOutpaymentReference()) {
            $subject = AccountView_Object_Subject::PREFIX . strstr($outpayment_reference, '.', true);
            $reason  = $this->transaction_determiner->isRefundedOutpayment($bank_transaction, $outpayment_reference)
                    ? 'REK.ONB.'
                    : 'DUBBEL';

            $av_transaction
                ->setSubNumber($subject)
                ->setLedgerNumber(AccountView_Object_Transaction::LEDGER_DEBTOR_SMP)
                ->setDescription(trim("{$reason} REF {$outpayment_reference}"));

            /*
             * Mollie will pass us the invoice number. This is stored in the tag data the first time the outpayment is
             * reported as returned to Mollie. We'll pass it on to AccountView here.
             */
            if (!empty($bank_transaction->getTagData()["invoice_number"])) {
                $av_transaction->setInvoiceNumber($bank_transaction->getTagData()["invoice_number"]);
            }
        }

        if ($bank_transaction->hasAnyOfTags(
            [
                TransactionTags::TAG_PREPAYMENT_SETTLEMENT_SENT,
                TransactionTags::TAG_FAILURE_PREPAYMENT_SETTLEMENT,
            ]
        )) {
            $prepayment_settlement_reference = PrepaymentSettlementMatcher::getPrepaymentSettlementReference(
                $bank_transaction
            );

            $reference_source_journal = $prepayment_settlement_reference->getSourceJournal();

            if ($reference_source_journal->equals(Journal::STICHTING_MOLLIE_PAYMENTS())) {
                $av_transaction->setLedgerNumber(
                    AccountView_Object_Transaction::LEDGER_PREPAYMENT_SETTLEMENT_DEBITED_SMP
                );
            } elseif ($reference_source_journal->equals(Journal::MOLLIE_BV())) {
                $av_transaction->setLedgerNumber(
                    AccountView_Object_Transaction::LEDGER_PREPAYMENT_SETTLEMENT_DEBITED_BV
                );
            }
        } elseif ($bank_transaction->hasTag(TransactionTags::TAG_PREPAYMENT_SETTLEMENT_RECEIVED)) {
            $prepayment_settlement_reference = PrepaymentSettlementMatcher::getPrepaymentSettlementReference(
                $bank_transaction
            );

            $reference_source_journal = $prepayment_settlement_reference->getSourceJournal();

            if ($reference_source_journal->equals(Journal::STICHTING_MOLLIE_PAYMENTS())) {
                $av_transaction->setLedgerNumber(
                    AccountView_Object_Transaction::LEDGER_PREPAYMENT_SETTLEMENT_CREDITED_BV
                );
            } elseif ($reference_source_journal->equals(Journal::MOLLIE_BV())) {
                $av_transaction->setLedgerNumber(
                    AccountView_Object_Transaction::LEDGER_PREPAYMENT_SETTLEMENT_CREDITED_SMP
                );
            }
        }

        if ($bank_transaction->getOffsetAccountName() !== null) {
            $av_transaction->setDescription(trim(sprintf(
                "%s\r\n%s",
                $bank_transaction->getOffsetAccountName(),
                $av_transaction->getDescription()
            )));
        }

        return $av_transaction;
    }
}
