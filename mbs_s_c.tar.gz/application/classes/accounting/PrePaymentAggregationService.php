<?php

namespace Accounting;

use Accounting\Exceptions\AlreadyReportedException;
use Accounting\Exceptions\InvalidPrePaymentAggregationException;
use Core\BusinessDayDeterminer;
use Core\InvoiceNumber;
use DateTimeImmutable;
use Generator;
use Model_Accounting_PrePaymentAggregation;
use Orm\Repositories\PrePaymentAggregationRepository;

class PrePaymentAggregationService
{
    /** @var PrePaymentAggregationRepository */
    private $pre_payment_aggregation_repository;

    public function __construct(
        PrePaymentAggregationRepository $pre_payment_aggregation_repository
    ) {
        $this->pre_payment_aggregation_repository = $pre_payment_aggregation_repository;
    }

    /**
     * @throws InvalidPrePaymentAggregationException
     */
    public function recordAggregation(
        InvoiceNumber $invoice_number,
        string $debtor_number,
        string $amount,
        DateTimeImmutable $date
    ): void {
        $date = BusinessDayDeterminer::getLastDutchBusinessDayOfMonth($date);

        $pre_payment_aggregation = $this->pre_payment_aggregation_repository->getByInvoiceNumberAndDate(
            $invoice_number,
            $date
        );

        if ($pre_payment_aggregation) {
            $this->verifyAggregationIsValid($pre_payment_aggregation, $debtor_number);
            $this->addAmountToExistingPrePaymentAggregation($pre_payment_aggregation, $amount);
        } else {
            $this->pre_payment_aggregation_repository->create($invoice_number, $debtor_number, $amount, $date);
        }
    }

    /**
     * @throws InvalidPrePaymentAggregationException
     */
    private function verifyAggregationIsValid(
        Model_Accounting_PrePaymentAggregation $pre_payment_aggregation,
        string $debtor_number
    ): void {
        if ($pre_payment_aggregation->getDebtorNumber() !== $debtor_number) {
            throw InvalidPrePaymentAggregationException::differentDebtorForSameInvoiceNumber(
                $pre_payment_aggregation,
                $debtor_number
            );
        }
    }

    private function addAmountToExistingPrePaymentAggregation(
        Model_Accounting_PrePaymentAggregation $pre_payment_aggregation,
        string $amount
    ): void {
        $pre_payment_aggregation->addAmount($amount);
        $pre_payment_aggregation->saveOrDie();
    }

    /**
     * @return Generator|Model_Accounting_PrePaymentAggregation[]
     */
    public function yieldAllUnreported(DateTimeImmutable $datetime): Generator
    {
        yield from $this->pre_payment_aggregation_repository->yieldAllUnreported($datetime);
    }

    /**
     * @return DateTimeImmutable[]
     */
    public function getAllUnreportedAggregationDatesAscendingBefore(DateTimeImmutable $datetime): array
    {
        /*
         * Per year, there are only 12 unique aggregation dates for merchant pre payments. These dates are the last
         * business days of each month.
         *
         * This method can be used in workers that want to retrieve all aggregation dates for which unreported
         * pre payment aggregations are still present on a daily basis. These workers will often pass the current
         * datetime to this method.
         *
         * To prevent incomplete aggregations from being reported, the last business day of the reference month is
         * always used as the non-inclusive boundary. This means that the aggregation date 2017-10-31 will only be
         * retrieved when a datetime of 2017-11-01 or higher is passed. Even passing 2016-07-31 will not result in
         * the aggregation date 2016-07-29, since 2016-07-29 is the last business day of that month.
         */
        $datetime = BusinessDayDeterminer::getLastDutchBusinessDayOfMonth($datetime);

        return $this->pre_payment_aggregation_repository->getAllUnreportedAggregationDatesAscending($datetime);
    }

    /**
     * @throws AlreadyReportedException
     */
    public function markAsReported(Model_Accounting_PrePaymentAggregation $pre_payment_aggregation): void
    {
        $this->pre_payment_aggregation_repository->markAsReported($pre_payment_aggregation);
    }
}
