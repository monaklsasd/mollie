### Accounting

When a bank statement model is transformed into an AccountView object,
it retrieves outpayment information from Mollie for each outpayment
reference that it finds in its transactions. This outpayment information
contains contains numerous transactions on the 1300 Debtor ledger with a
positive amount, also known as pre payments.

Instead of adding all of these 1300 Debtor transactions to the
AccountView object, they are compressed into a single transaction with
the total amount. During the aggregation, details of individual
transactions are stored in the database on a per merchant/debtor basis.

At the end of the month, all of these individual debtor transactions are 
transformed into AccountView objects with a negated amount. The total is
booked against a positive transaction on the 1806 merchant-pre-payments
ledger.

See the article on [AccountView Compressions](https://docs.google.com/document/d/1bB8D4SorZAiMEzXDcWidZ142tBtkkFNG5CdafiF-fAY/edit) for more details 


## Pre payments<a name="headin"></a>

Pre payments refer to withheld costs. Withheld costs
are costs (e.g. payment fees) that we deduct from the merchant's
settlement/outpayment. It is called a pre payment because the merchant
has not actually been invoiced for these costs.