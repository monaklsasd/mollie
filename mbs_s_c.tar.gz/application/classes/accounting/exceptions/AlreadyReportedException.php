<?php

namespace Accounting\Exceptions;

use Model_Accounting_PrePaymentAggregation;
use Mollie_Database_Exception_Query_DuplicateEntry;

class AlreadyReportedException extends AbstractException
{
    public static function duplicateEntry(
        Model_Accounting_PrePaymentAggregation $pre_payment_aggregation,
        Mollie_Database_Exception_Query_DuplicateEntry $e
    ): AlreadyReportedException {
        return new self(
            "Pre payment aggregation #{$pre_payment_aggregation->getPrimaryKey()} has already been reported",
            0,
            $e
        );
    }
}
