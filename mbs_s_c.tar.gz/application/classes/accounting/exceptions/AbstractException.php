<?php

namespace Accounting\Exceptions;

use Mollie_Exception;

class AbstractException extends Mollie_Exception
{
}
