<?php

namespace Accounting\Exceptions;

class NothingToCorrectException extends AbstractException
{
    public static function bankStatementNotExported(): self
    {
        return new self(
            "The bank statement has not been exported to AccountView (nor Twinfield) yet, so there is nothing to correct"
        );
    }
}
