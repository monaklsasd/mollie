<?php

namespace Accounting\Exceptions;

class TwinfieldTransactionCorrectionException extends AbstractException
{
    public static function apiCallFailed(\Accounting\Twinfield\Exception $e): self
    {
        return new self(
            "Failed to correct transaction in Twinfield: {$e->getMessage()}",
            0,
            $e
        );
    }
}
