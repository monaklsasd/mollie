<?php

namespace Accounting\Exceptions;

use Core\InvoiceNumber;
use DateTimeImmutable;
use Model_Accounting_PrePaymentAggregation;
use Mollie_Database_Exception_Query_DuplicateEntry;

class InvalidPrePaymentAggregationException extends AbstractException
{
    public static function duplicate(
        InvoiceNumber $invoice_number,
        DateTimeImmutable $date,
        Mollie_Database_Exception_Query_DuplicateEntry $e
    ): InvalidPrePaymentAggregationException {
        $message = sprintf(
            'Cannot create new pre payment aggregation with invoice number %s and date %s, already exists',
            $invoice_number->toString(),
            $date->format('Y-m-d')
        );

        return new self($message, 0, $e);
    }

    public static function differentDebtorForSameInvoiceNumber(
        Model_Accounting_PrePaymentAggregation $existing_pre_payment_aggregation,
        string $different_debtor_number
    ): InvalidPrePaymentAggregationException {
        $message = sprintf(
            'Pre payment aggregation with invoice number %s already exists for debtor %s, so '
            . 'cannot add a pre payment from debtor %s to it',
            $existing_pre_payment_aggregation->getInvoiceNumber()->toString(),
            $existing_pre_payment_aggregation->getDebtorNumber(),
            $different_debtor_number
        );

        return new self($message);
    }
}
