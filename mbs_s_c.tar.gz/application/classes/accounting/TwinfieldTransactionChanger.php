<?php

namespace Accounting;

use Accounting\Exceptions\NothingToCorrectException;
use Accounting\Exceptions\TwinfieldTransactionCorrectionException;
use Accounting\Maps\Mapper;
use Accounting\Twinfield\BankAccountUtil;
use Accounting\Twinfield\TwinfieldSupplier;
use AccountView_Object_Transaction;
use Core\Money\Currencies;
use DateTimeImmutable;
use LogicException;
use Model_Bankstatement;
use Model_Banktransaction;
use Money\Money;
use PhpTwinfield\ElectronicBankStatement;
use PhpTwinfield\ElectronicBankStatementTransaction;
use function Core\Money\money_from_string;

class TwinfieldTransactionChanger
{
    /** @var TwinfieldSupplier */
    private $twinfield_supplier;

    public function __construct(TwinfieldSupplier $twinfield_supplier)
    {
        $this->twinfield_supplier = $twinfield_supplier;
    }

    /**
     * @throws NothingToCorrectException
     * @throws TwinfieldTransactionCorrectionException
     */
    public function correctTransactionInTwinfield(
        Model_Banktransaction $transaction,
        AccountView_Object_Transaction $old_av_transaction,
        AccountView_Object_Transaction $new_av_transaction
    ): void {
        self::assertAccountViewStatusWarrantsCorrection($transaction);

        $mbs_bank_account = $transaction->getBankAccount();
        $office           = BankAccountUtil::getOfficeForIban($mbs_bank_account::getIban());

        $electronic_bank_statement = new ElectronicBankStatement();
        $electronic_bank_statement->setImportDuplicate(false);
        $electronic_bank_statement->setStartvalue(Money::EUR(0));
        $electronic_bank_statement->setOffice($office);
        $electronic_bank_statement->setIban($mbs_bank_account::getIban());
        $electronic_bank_statement->setDate(new DateTimeImmutable($transaction->getStatement()->getStatementDate()->format('Y-m-d')));
        $electronic_bank_statement->setStatementnumber($transaction->getStatement()->getStatementNumber());

        $electronic_bank_statement->setTransactions([
            $this->createTransactionFrom($new_av_transaction, $transaction),
            $this->createContraTransactionFrom($old_av_transaction, $transaction),
        ]);

        try {
            $this->twinfield_supplier->addOrUpdateElectronicBankStatement($electronic_bank_statement);
        } catch (\Accounting\Twinfield\Exception $e) {
            throw TwinfieldTransactionCorrectionException::apiCallFailed($e);
        }
    }

    /**
     * @throws NothingToCorrectException
     * @throws LogicException
     */
    private static function assertAccountViewStatusWarrantsCorrection(Model_Banktransaction $transaction): void
    {
        $statement = $transaction->getStatement();

        if ($statement->getAccountviewStatus() === Model_Bankstatement::ACCOUNTVIEW_STATUS_NEW
            || $statement->getAccountviewStatus() === Model_Bankstatement::ACCOUNTVIEW_STATUS_READY
        ) {
            throw NothingToCorrectException::bankStatementNotExported();
        }

        if ($statement->getAccountviewStatus() === Model_Bankstatement::ACCOUNTVIEW_STATUS_SKIPPED) {
            throw new LogicException(
                "Attempting to change the tag of transaction #{$transaction->getPrimaryKey()} that is in" .
                " bank statement #{$statement->getPrimaryKey()} with AV status skipped, which should only be set on" .
                " bank statements with 0 transactions."
            );
        }
    }

    private function createTransactionFrom(
        AccountView_Object_Transaction $av_transaction,
        Model_Banktransaction $bank_transaction
    ): ElectronicBankStatementTransaction {
        return $this->createTransaction(
            money_from_string((string)$av_transaction->getAmount(), Currencies::EUR()),
            $bank_transaction,
            $av_transaction
        );
    }

    private function createTransaction(
        Money $amount,
        Model_Banktransaction $bank_transaction,
        AccountView_Object_Transaction $av_transaction
    ): ElectronicBankStatementTransaction {
        $bank_statement_transaction = new ElectronicBankStatementTransaction();
        $bank_statement_transaction->setValue($amount);

        $bank_statement_transaction->setDescription(
            substr("Correction: {$av_transaction->getDescription()}", 0, 40)
        );

        if (!empty($av_transaction->getLedgerNumber())) {
            $organization = BankAccountUtil::getOrganizationForIban(
                $bank_transaction->getBankAccount()::getIban()
            );

            $bank_statement_transaction->setDim1(
                Mapper::mapFromOrganization($av_transaction->getLedgerNumber(), $organization)
            );
        }

        /*
         * Bank transactions always have a type code. You can put anything you want in this field, with a max length of
         * 4 characters. According to Peter from Twinfield we should just put a dummy value, e.g. '00'.
         */
        $bank_statement_transaction->setType('00');

        return $bank_statement_transaction;
    }

    private function createContraTransactionFrom(
        AccountView_Object_Transaction $av_transaction,
        Model_Banktransaction $bank_transaction
    ): ElectronicBankStatementTransaction {
        return $this->createTransaction(
            money_from_string((string)$av_transaction->getAmount(), Currencies::EUR())->multiply(-1),
            $bank_transaction,
            $av_transaction
        );
    }
}
