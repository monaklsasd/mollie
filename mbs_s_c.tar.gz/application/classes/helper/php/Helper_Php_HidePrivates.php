<?php

/**
 * Like underwear, this class hides your privates when your pants are var_dumped.
 */
trait Helper_Php_HidePrivates
{
    /**
     * Special version of __debugInfo() to prevent private, protected and static
     * properties being leaked via var_dump().
     *
     * @return array
     */
    public function __debugInfo()
    {
        $reflection = new ReflectionClass(__CLASS__);

        $dump = [];

        foreach ($reflection->getProperties(ReflectionProperty::IS_PUBLIC) as $property) {
            if (!$property->isStatic()) {
                $dump[$property->getName()] = $property->getValue($this);
            }
        }

        return $dump;
    }
}
