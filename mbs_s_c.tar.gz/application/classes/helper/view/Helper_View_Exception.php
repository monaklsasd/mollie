<?php
/**
 * Helper View Exception
 *
 * @author Aine Hickey <aine@mollie.nl> Apr 5, 2011 5:00:56 PM
 * @copyright Copyright (C) Mollie B.V.
 *
 * @see http://www.mollie.nl/
 */
class Helper_View_Exception extends Exception
{
}
