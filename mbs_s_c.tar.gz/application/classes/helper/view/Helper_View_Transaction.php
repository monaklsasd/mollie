<?php

use Model\Transaction\TransactionTags;

class Helper_View_Transaction
{
    public static function getAugmentedDescription(Model_Banktransaction $transaction): string
    {
        $description = htmlentities($transaction->getDescription(), ENT_QUOTES, 'UTF-8');

        // Try to find an invoice number
        if ($transaction->getAmount()->isPositive() && !$transaction->isSepaTransaction()) {
            $description = self::linkInvoiceNumberIfPresent($description, $transaction);

            $description = preg_replace(
                '~ORDER\s*NUMMER\*?\s+([0-9]{5,})~',
                '<a href="https://www.mollie.com/admin/invoices/search?term=$1&view=highlight" target="_blank">$0</a>',
                $description
            );

            if ($transaction->isReceivedIdeal()) {
                $description = preg_replace(
                    '~(M0*\d{6,}M[a-z\d]+)~i',
                    '<a href="https://www.mollie.com/admin/api-payments/?search=$1">$1</a>',
                    $description
                );
            } else {
                try {
                    $tag_data = $transaction->getTagData();
                } catch (Exception $e) {
                    $tag_data = [];
                }

                if (!empty($tag_data['transaction_id'])) {
                    $transaction_id = preg_replace('~[/. -]*~', '', $tag_data['transaction_id']);

                    for ($find = '', $i = 0; $i < mb_strlen($transaction_id); $i++) {
                        $find .= $transaction_id[$i] . '[/. -]*';
                    }

                    if ($transaction->hasAnyOfTags([
                        TransactionTags::TAG_BANKTRANSFER,
                        TransactionTags::TAG_UNKNOWNBANKTRANSFER,
                    ])) {
                        $description = preg_replace(
                            "~({$find})~",
                            $link = '<a href="https://www.mollie.com/admin/api-payments/?search=' . urlencode($tag_data['transaction_id']) . '">$1</a>',
                            $description,
                            -1,
                            $count
                        );
                    } elseif ($transaction->hasTag(TransactionTags::TAG_SOFORT)
                        || $transaction->hasTag(TransactionTags::TAG_UNKNOWNSOFORT)
                        || $transaction->hasTag(TransactionTags::TAG_FAILURESOFORT)) {
                        $description = preg_replace(
                            "~({$find})~i",
                            $link = '<a href="https://www.mollie.com/admin/api-payments/?search=' . urlencode($tag_data['transaction_id']) . '">$1</a>',
                            $description,
                            -1,
                            $count
                        );
                    }

                    if (empty($count) && isset($link)) {
                        $description .= '<br>' . str_replace("$1", $tag_data['transaction_id'], " {$link}");
                    }
                }
            }
        }

        if (preg_match("!KLANT ID (\\d+)!", $transaction->getDescription(), $matches)) {
            $description = str_replace(
                $matches[0],
                "<a href=\"https://www.mollie.com/admin/klant/{$matches[1]}\">{$matches[0]}</a>",
                $description
            );
        }

        if (preg_match("!REF (\\d{4,}\\.\\d{4}\\.\\d{2})!", $transaction->getDescription(), $matches)) {
            $description = str_replace(
                $matches[0],
                "<a href=\"https://www.mollie.com/admin/customers/outpayment-search/?reference=" . urlencode($matches[1]) . "\">{$matches[0]}</a>",
                $description
            );
        }

        return $description;
    }

    /**
     * @return string
     */
    public static function getCommentData(Model_Banktransaction $transaction)
    {
        $comment_text = '';

        if (preg_match('~([2-9][0-9]{3})\.([0-9]{5,})~', $transaction->getDescription(), $matches)) {
            $comment_text .= '"factuur ' . $matches[0] . '":' . sprintf('https://www.mollie.com/admin/invoices/search?term=%d.%d&view=highlight', $matches[1], $matches[2]);
            $comment_text .= ' . Verwerkt.';
        }

        return $comment_text;
    }

    public static function linkInvoiceNumberIfPresent(
        string $description_to_alter,
        Model_Banktransaction $transaction
    ): string {
        $invoice_number = null;

        if ($transaction->getLedgerInvoiceNumber() !== null) {
            $invoice_number = $transaction->getLedgerInvoiceNumber();
            $url            = 'https://www.mollie.com/admin/finance-ledger/invoicing/search-invoice/%s';

            return self::replaceInvoiceNumberWithLinkInDescription($url, $invoice_number, $description_to_alter);
        }

        if ($transaction->getInvoiceNumber() !== null) {
            $invoice_number = $transaction->getInvoiceNumber();
            $url            = 'https://www.mollie.com/admin/invoices/search?term=%s&view=highlight';

            return self::replaceInvoiceNumberWithLinkInDescription($url, $invoice_number, $description_to_alter);
        }

        return $description_to_alter;
    }

    private static function replaceInvoiceNumberWithLinkInDescription(string $url, string $invoice_number, string $description): string
    {
        $url                 = sprintf($url, $invoice_number);
        $invoice_number_link = sprintf(
            '<a href="%s" target="_blank">%s</a>',
            $url,
            $invoice_number
        );

        return str_replace(
            $invoice_number,
            $invoice_number_link,
            $description
        );
    }
}
