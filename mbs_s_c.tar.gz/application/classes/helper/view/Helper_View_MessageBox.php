<?php
/**
 * Message Box class
 *
 * @author Aine Hickey <aine@mollie.nl> Apr 5, 2011 4:32:09 PM
 * @copyright Copyright (C) Mollie B.V.
 */
class Helper_View_MessageBox
{
    public const SUCCESS_BOX = 'success';
    public const ERROR_BOX   = 'error';
    public const INFO_BOX    = 'info';
    public const WARNING_BOX = 'warning';
    public const STICKY_BOX  = 'sticky';
    public const CODE_BOX    = 'code';

    /**
     * Default box titles
     *
     * @var array
     */
    protected $_titles = [
        'success' => 'Success',
        'error'   => 'Error',
        'info'    => 'Info',
        'warning' => 'Warning',
        'sticky'  => 'Sticky',
        'code'    => 'Code',
    ];

    /**
     * Message id (HTML attribute)
     *
     * @var string
     */
    protected $_id = '';
    /**
     * Message type
     *
     * @var string
     */
    protected $_type = 'warning';
    /**
     * Message style
     *
     * @var string
     */
    protected $_style = '';
    /**
     * Message array
     *
     * @var array
     */
    protected $_messages = [];
    /**
     * Subtitle
     *
     * @var string
     */
    protected $_subtitle;
    /**
     * Title
     *
     * @var string
     */
    protected $_title;
    /**
     * Display title
     *
     * @var bool
     */
    protected $_display_title = true;
    /**
     * HTML to be returned
     *
     * @var string
     */
    protected $_html;
    /**
     * Allowed HTML tags
     *
     * @var string
     */
    protected $_allowed_tags = '<strong><em><p><a><br><small><pre>';
    /**
     * Use bullet points with message points
     *
     * @var bool
     */
    protected $_bullet_points = false;

    /**
     * Constructor
     *
     * @param string $type    (Optional) Type of the message box
     * @param string $message (Optional) First message in the message box
     */
    public function __construct($type = 'warning', $message = null)
    {
        $this->_type = $type;

        if (!empty($message)) {
            $this->_messages[] = $message;
        }
    }

    /**
     * Get title
     *
     * @return string Title
     */
    public function getTitle()
    {
        if ($this->_title) {
            return $this->_title;
        }

        return $this->_titles[$this->_type];
    }

    /**
     * Set the subtitle
     *
     * @param string $subtitle
     *
     * @return Helper_View_MessageBox
     */
    public function setSubtitle($subtitle)
    {
        $this->_subtitle = $subtitle;

        return $this;
    }

    /**
     * Set the id (HTML attribute)
     *
     * @param string $id
     *
     * @return Helper_View_MessageBox
     */
    public function setId($id)
    {
        $this->_id = $id;

        return $this;
    }

    /**
     * @param string $type Message box type
     *
     * @return Helper_View_MessageBox
     */
    public function setType($type)
    {
        // Check type exists
        if (!array_key_exists($type, $this->_titles)) {
            throw new Helper_View_Exception('Invalid type given.', -1);
        }

        $this->_type = $type;

        return $this;
    }

    /**
     * Set the title
     *
     * @param string $title
     *
     * @return Helper_View_MessageBox
     */
    public function setTitle($title)
    {
        $this->_title = $title;

        return $this;
    }

    /**
     * Set the style
     *
     * @param string $style
     *
     * @return Helper_View_MessageBox
     */
    public function setStyle($style)
    {
        $this->_style = $style;

        return $this;
    }

    /**
     * @param string $message Message string. HTML allowed
     *
     * @return Helper_View_MessageBox
     */
    public function addMessage($message)
    {
        if (is_array($message)) {
            foreach ($message as $m) {
                // Strip unwanted html tags.
                $this->_messages[] = strip_tags($m, $this->_allowed_tags);
            }
        } else {
            // Strip unwanted html tags.
            $this->_messages[] = strip_tags($message, $this->_allowed_tags);
        }

        return $this;
    }

    /**
     * Add a flash message
     *
     * @return Helper_View_MessageBox
     */
    public function addFlashMessage(Mollie_FlashMessenger_Message $flash)
    {
        $this->_messages[] = $flash->getMessage();
        $this->_type       = $flash->getType();

        return $this;
    }

    /**
     * Disable title
     *
     * @return Helper_View_MessageBox
     */
    public function disableTitle()
    {
        $this->_display_title = false;

        return $this;
    }

    /**
     * Add bullet points to front of messages
     */
    public function addBulletPoints()
    {
        $this->_bullet_points = true;

        return $this;
    }

    /**
     * @return string Html of the messagebox
     */
    public function render()
    {
        // If not message, don't show anything.
        if (!$this->_messages) {
            return '';
        }

        $this->_html = '<div id="' . $this->_id . '" class="alert alert-block alert-' . $this->_type . '" style="' . $this->_style . '">';

        // Add title
        if ($this->_display_title) {
            $this->_html .= '<h4>' . $this->getTitle() . '</h4>';
        }

        // Add subtitle
        if ($this->_subtitle) {
            $this->_html .= '<p>' . $this->_subtitle . '</p>';
        }

        // Add messages, using unordered list

        if ($this->_bullet_points) {
            $this->_html .= '<ul>';

            foreach ($this->_messages as $message) {
                $this->_html .= '<li>' . $message . '</li>';
            }

            $this->_html .= '</ul>';
        } else {
            foreach ($this->_messages as $message) {
                $this->_html .= '<p>' . $message . '</p>';
            }
        }

        $this->_html .= '</div> <!-- END errorbox -->';

        return $this->_html;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->render();
    }
}
