<?php

declare(strict_types=1);

use Core\Strings;

/**
 *  Prefill texts for returning payments on page 'Exceptional transactions'
 */
class Helper_View_ReturnPayments
{
    private const TYPE = [
        Model_TransactionRegistration::REGISTRATION_UNKNOWN_IDEAL         => "Geen iDEAL transactie",
        Model_TransactionRegistration::REGISTRATION_FAILURE_IDEAL         => "Mislukte iDEAL transactie",
        Model_TransactionRegistration::REGISTRATION_UNKNOWN_BANKTRANSFER  => "Incorrect payment mollie.com",
        Model_TransactionRegistration::REGISTRATION_OVERPAID_BANKTRANSFER => "Overpaid payment mollie.com",
        Model_TransactionRegistration::REGISTRATION_UNKNOWN_SOFORT        => "Unknown SOFORT transaction",
        Model_TransactionRegistration::REGISTRATION_FAILURE_SOFORT        => "Failed SOFORT transaction",
        Model_TransactionRegistration::REGISTRATION_UNKNOWN_MISTERCASH    => "Unknown Bancontact transaction",
        Model_TransactionRegistration::REGISTRATION_FAILURE_MISTERCASH    => "Failed Bancontact transaction",
        Model_TransactionRegistration::REGISTRATION_UNKNOWN_BELFIUS       => "Unknown Belfius transaction",
        Model_TransactionRegistration::REGISTRATION_FAILURE_BELFIUS       => "Failed Belfius transaction",
        Model_TransactionRegistration::REGISTRATION_UNKNOWN_BITCOIN       => "Unknown Bitcoin transaction",
        Model_TransactionRegistration::REGISTRATION_UNKNOWN_KBC           => "Unknown KBC transaction",
        Model_TransactionRegistration::REGISTRATION_FAILURE_KBC           => "Failed KBC transaction",
        Model_TransactionRegistration::REGISTRATION_UNKNOWN_DIRECTDEBIT   => "Unknown direct debit transaction",
        Model_TransactionRegistration::REGISTRATION_FAILURE_DIRECTDEBIT   => "Failed direct debit transaction",
        Model_TransactionRegistration::REGISTRATION_UNKNOWN_CREDITCARD    => "Unknown credit card transaction",
        Model_TransactionRegistration::REGISTRATION_FAILURE_CREDITCARD    => "Failed credit card transaction",
        Model_TransactionRegistration::REGISTRATION_UNKNOWN_AMEX          => "Unknown AMEX transaction",
        Model_TransactionRegistration::REGISTRATION_FAILURE_AMEX          => "Failed AMEX transaction",
        Model_TransactionRegistration::REGISTRATION_UNKNOWN_PPRO          => "Unknown PPRO transaction",
        Model_TransactionRegistration::REGISTRATION_FAILURE_PPRO          => "Failed PPRO transaction",
        Model_TransactionRegistration::REGISTRATION_UNKNOWN_INGHOMEPAY    => "Unknown ING HomePay transaction",
        Model_TransactionRegistration::REGISTRATION_FAILURE_INGHOMEPAY    => "Failed ING HomePay transaction",
        Model_TransactionRegistration::REGISTRATION_UNKNOWN_REFUND        => "Unknown refund",
        Model_TransactionRegistration::REGISTRATION_FAILURE_REFUND        => "Failed refund",
        Model_TransactionRegistration::REGISTRATION_UNKNOWN_OUTPAYMENT    => "Unknown payment on Mollie bank account",
        Model_TransactionRegistration::REGISTRATION_FAILURE_OUTPAYMENT    => "Unknown payment on Mollie bank account",
        Model_TransactionRegistration::REGISTRATION_UNKNOWN_KLARNA        => "Unknown Klarna transaction",
        Model_TransactionRegistration::REGISTRATION_FAILURE_KLARNA        => "Failed Klarna transaction",
    ];

    /**
     * @return array Short and long prefill text
     */
    public static function getForTagAndDate(string $tag, string $date): array
    {
        if (!array_key_exists($tag, self::TYPE)) {
            return ['short' => '', 'long' => ''];
        }

        $transaction_type = self::TYPE[$tag];

        if (Strings::areSimilar($tag, Model_TransactionRegistration::REGISTRATION_UNKNOWN_IDEAL)
            || Strings::areSimilar($tag, Model_TransactionRegistration::REGISTRATION_FAILURE_IDEAL)) {
            $prefills["short"] = "{$transaction_type} dd {$date}";
            $prefills["long"]  = "{$transaction_type}. Neem aub contact op met de webshop waarvoor de betaling bestemd is. Mvg, Mollie";
        } elseif (Strings::areSimilar($tag, Model_TransactionRegistration::REGISTRATION_UNKNOWN_OUTPAYMENT)
            || Strings::areSimilar($tag, Model_TransactionRegistration::REGISTRATION_FAILURE_OUTPAYMENT)) {
            $prefills["short"] = "{$transaction_type} on {$date}";
            $prefills["long"]  = "{$transaction_type}. Regards, Mollie";
        } else {
            $prefills["short"] = "{$transaction_type} on {$date}";
            $prefills["long"]  = "{$transaction_type}. Please contact the webshop the payment was intended for. Regards, Mollie";
        }

        return $prefills;
    }
}
