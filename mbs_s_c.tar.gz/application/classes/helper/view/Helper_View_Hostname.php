<?php
/**
 * Hostname lookup
 */
class Helper_View_Hostname
{
    public static function fromIp($ip)
    {
        $known_hosts = [
            '127.0.0.1'     => 'localhost',
            '10.250.250.1'  => 'vmhost',
            '77.245.85.229' => 'dc1-web-1.mollie.nl',
            '77.245.85.230' => 'dc1-web-2.mollie.nl',
            '77.245.85.241' => 'dc2-web-1.mollie.nl',
            '95.97.49.170'  => 'Mollie Office',
        ];

        if (isset($known_hosts[$ip])) {
            return $known_hosts[$ip];
        }

        return $ip;
    }
}
