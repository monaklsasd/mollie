<?php

class Helper_View_Date
{
    /**
     * Smarty date_format modifier plugin
     *
     * Type:     modifier<br>
     * Name:     date_format<br>
     * Purpose:  format datestamps via strftime<br>
     * Input:<br>
     *          - string: input date string
     *          - format: strftime format for output
     *          - default_date: default date if $string is empty
     *
     * @see http://www.smarty.net/manual/en/language.modifier.date.format.php date_format (Smarty online manual)
     *
     * @author Monte Ohrt <monte at ohrt dot com>
     *
     * @param string $string input date string
     * @param string $format strftime or date format for output
     *
     * @return string |void
     *
     * @uses smarty_make_timestamp()
     */
    public static function date($string, $format = '%e %B %Y')
    {
        if ($string != '') {
            $timestamp = self::smarty_make_timestamp($string);
        } else {
            return;
        }

        if (strpos($format, '%') !== false) {
            return trim(strftime($format, $timestamp));
        }

        return date($format, $timestamp);
    }

    public static function datetime($string, $format = '%Y-%m-%d, %T')
    {
        if ($string != '') {
            $timestamp = self::smarty_make_timestamp($string);
        } else {
            return;
        }

        if ($timestamp > strtotime('today')) {
            $format = '%T';
        }

        if (strpos($format, '%') !== false) {
            return trim(strftime($format, $timestamp));
        }

        return date($format, $timestamp);
    }

    /**
     * Function: smarty_make_timestamp<br>
     * Purpose:  used by other smarty functions to make a timestamp from a string.
     *
     * @author   Monte Ohrt <monte at ohrt dot com>
     *
     * @param DateTime|int|string $string date object, timestamp or string that can be converted using strtotime()
     *
     * @return int
     */
    protected static function smarty_make_timestamp($string)
    {
        if (empty($string)) {
            // use "now":
            return time();
        }

        if ($string instanceof DateTime) {
            return $string->getTimestamp();
        }

        if (strlen($string) == 14 && ctype_digit($string)) {
            // it is mysql timestamp format of YYYYMMDDHHMMSS?
            return mktime(
                substr($string, 8, 2),
                substr($string, 10, 2),
                substr($string, 12, 2),
                substr($string, 4, 2),
                substr($string, 6, 2),
                substr($string, 0, 4)
            );
        }

        if (ctype_digit($string)) {
            // it is a numeric string, we handle it as timestamp
            return (int)$string;
        }
        // strtotime should handle it
        $time = strtotime($string);

        if ($time == -1 || $time === false) {
            // strtotime() was not able to parse $string, use "now":
            return time();
        }

        return $time;
    }
}
