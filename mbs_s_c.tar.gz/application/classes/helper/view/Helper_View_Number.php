<?php
/**
 * Helper_View_Number
 *
 * This view helper contains functions to correctly format any kind of numeric value.
 *
 * @author Rick Wong <wong@mollie.nl>
 * @copyright Copyright (C) Mollie B.V.
 */
class Helper_View_Number
{
    /**
     * Generic numeric value formatting
     *
     * @param mixed $number   Numeric value
     * @param int   $decimals (Optional) Number of decimals to display
     *
     * @return string
     */
    public static function numeric($number, $decimals = 0)
    {
        return number_format($number, $decimals, ',', '.');
    }

    /**
     * Percentage formatting.
     *
     * @param        $fraction float|int value with decimals.
     * @param int    $decimals (Optional) Number of decimals to display.
     * @param string $suffix   (Optional) Symbol to append to the output. Defaults to % symbol.
     *
     * @return string
     */
    public static function percentage($fraction, $decimals = 1, $suffix = '%')
    {
        return preg_replace('/,0+$/', '', number_format($fraction * 100, $decimals, ',', '')) . $suffix;
    }

    /**
     * Currency value formatting (always 2 decimals)
     *
     * @param mixed  $amount         Numeric amount
     * @param string $symbol         (Optional) Currency symbol
     * @param string $not_applicable (Optional) If amount is empty, then return this string
     * @param int    $decimals       (Optional) Number of decimals to display
     *
     * @return string
     */
    public static function currency($amount, $symbol = '€', $not_applicable = '', $decimals = 2)
    {
        if ($amount == 0 && !empty($not_applicable)) {
            return $not_applicable;
        }

        // Don't rely on number_format rounding
        $amount = round($amount, $decimals);

        $nbsp = html_entity_decode('&nbsp;', null, 'UTF-8');

        return ($amount < 0 ? "-{$nbsp}" : '') . $symbol . $nbsp . number_format(abs($amount), $decimals, ',', '.');
    }
}
