<?php

declare(strict_types=1);

namespace Helper\DateTime;

use Core\Time\Clock;
use DateTimeImmutable;
use DateTimeZone;

trait Now
{
    /** @var DateTimeZone */
    private static $system_timezone;

    protected static function getSystemTimeZone(): DateTimeZone
    {
        return self::$system_timezone ?? self::$system_timezone = new DateTimeZone(date_default_timezone_get());
    }

    protected static function getNow(): DateTimeImmutable
    {
        $now = DateTimeImmutable::createFromFormat('U.u', Clock::getTimestampWithMicroseconds());

        /*
         * When setting a datetime object from timestamps, it will ignore the timezone parameter and default to UTC.
         * So we always set the timezone afterwards.
         *
         * When using the Utc trait, this method will always UTC timestamps.
         */
        if (method_exists(__CLASS__, 'getUtc')) {
            $timezone = self::getUtc();
        } else {
            $timezone = self::getSystemTimeZone();
        }

        return $now->setTimezone($timezone);
    }
}
