<?php

declare(strict_types=1);

namespace Helper\DateTime;

use DateTimeImmutable;
use DateTimeZone;
use InvalidArgumentException;

trait Utc
{
    /** @var DateTimeZone */
    private static $utc;

    protected static function getUtc(): DateTimeZone
    {
        return self::$utc = self::$utc ?? new DateTimeZone('UTC');
    }

    protected static function toDateTime(?string $date_time_string, $format = 'Y-m-d H:i:s'): ?DateTimeImmutable
    {
        if ($date_time_string === null) {
            return null;
        }

        if (false === $date_time = DateTimeImmutable::createFromFormat($format, $date_time_string, self::getUtc())) {
            throw new InvalidArgumentException(sprintf(
                'Could not parse "%s" as date string in "%s" format.',
                $date_time_string,
                $format
            ));
        }

        return $date_time;
    }
}
