<?php

declare(strict_types=1);

namespace Helper\Database\Exceptions;

use RuntimeException;

class TransactionHelperLockException extends RuntimeException
{
}
