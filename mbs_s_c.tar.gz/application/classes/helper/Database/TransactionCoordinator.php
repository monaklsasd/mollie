<?php

declare(strict_types=1);

namespace Helper\Database;

use Helper\Database\Exceptions\TransactionHelperLockException;
use Mollie_Database_Exception_Query_Lock;
use sql_db;

class TransactionCoordinator
{
    /** @var sql_db */
    private $db;

    /** @var string[] */
    private $locks = [];

    public function __construct(sql_db $db)
    {
        $this->db = $db;
    }

    public function __destruct()
    {
        foreach ($this->locks as $lock_name) {
            $this->release($lock_name, true);
        }
    }

    /**
     * @throws TransactionHelperLockException
     */
    public function lock(string $name, int $timeout = 10): void
    {
        try {
            $this->db->getLock($name, $timeout);
            $this->locks[] = $name;
        } catch (Mollie_Database_Exception_Query_Lock $e) {
            throw new TransactionHelperLockException($e->getMessage(), $e->getCode(), $e);
        }
    }

    /**
     * @throws TransactionHelperLockException
     */
    public function release(string $name, bool $ignore_unknown_lock_exception = true): void
    {
        try {
            $this->db->releaseLock($name);
            $this->locks = array_diff($this->locks, [$name]);
        } catch (Mollie_Database_Exception_Query_Lock $e) {
            if ($ignore_unknown_lock_exception === false) {
                throw new TransactionHelperLockException($e->getMessage(), $e->getCode(), $e);
            }
        }
    }

    public function begin(): void
    {
        $this->db->begin();
    }

    public function commit(): void
    {
        $this->db->commit();
    }

    public function rollback(): void
    {
        $this->db->rollback();
    }

    public function inTransaction(): bool
    {
        $this->db->in_transaction();
    }
}
