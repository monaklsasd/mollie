<?php

/**
 * Helper_Iso_7064 - ISO 7064 define algorithms for calculating check digit characters.
 *
 * @author    Rick Wong <wong@mollie.nl> Feb 18, 2014
 * @copyright Mollie B.V.
 */
abstract class Helper_Iso_7064
{
    protected static $alphabet_mapping = [
        'A' => 10,
        'B' => 11,
        'C' => 12,
        'D' => 13,
        'E' => 14,
        'F' => 15,
        'G' => 16,
        'H' => 17,
        'I' => 18,
        'J' => 19,
        'K' => 20,
        'L' => 21,
        'M' => 22,
        'N' => 23,
        'O' => 24,
        'P' => 25,
        'Q' => 26,
        'R' => 27,
        'S' => 28,
        'T' => 29,
        'U' => 30,
        'V' => 31,
        'W' => 32,
        'X' => 33,
        'Y' => 34,
        'Z' => 35,
    ];

    /**
     * @param string $checksum
     * @param string $sequence
     *
     * @return int
     */
    protected static function _calculate($checksum, $sequence)
    {
        $input = $sequence . $checksum;
        $input = strtr($input, static::$alphabet_mapping);

        return (int)bcmod($input, 97);
    }

    /**
     * @param string $sequence
     *
     * @throws Helper_Exception
     *
     * @return bool
     */
    public static function validate($sequence)
    {
        $checksum = substr($sequence, 0, 4);
        $sequence = substr($sequence, 4);

        return static::_calculate($checksum, $sequence) === 1;
    }

    /**
     * @param string $prefix
     * @param string $sequence
     *
     * @throws Helper_Exception
     *
     * @return string
     */
    public static function generate($prefix, $sequence)
    {
        if (strlen($prefix) != 2) {
            throw new Helper_Exception("ISO 7064 prefix must be two characters: {$prefix}");
        }

        if (strlen($sequence) == 0) {
            throw new Helper_Exception('ISO 7064 sequence cannot be empty');
        }

        $checksum = $prefix . sprintf('%02u', (98 - static::_calculate($prefix . '00', $sequence)));

        return $checksum . $sequence;
    }
}
