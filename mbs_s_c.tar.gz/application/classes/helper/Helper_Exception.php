<?php

class Helper_Exception extends Mollie_Exception
{
}
