<?php

class Helper_Csrf
{
    /**
     * @param string $identifier Alternative identifier, default is REQUEST_URI
     *
     * @return string HTML input field with unique CSRF token
     */
    public static function token_field($field = '_formtoken', $identifier = '')
    {
        return '<input type="hidden" name="' . $field . '" value="' . self::token($identifier) . '" />';
    }

    /**
     * @param string $identifier Alternative identifier, default is REQUEST_URI
     *
     * @return string Returns a unique CSRF token
     */
    public static function token($identifier = '')
    {
        if (!isset($_SESSION['csrf_tokens'])) {
            $_SESSION['csrf_tokens'] = [];
        }

        $token      = sha1(MOLLIE_SALT_CSRF . session_id() . uniqid());
        $identifier = self::_hashIdentifier($identifier);

        return $_SESSION['csrf_tokens'][$identifier] = $token;
    }

    /**
     * Validate and unset CSRF token.
     *
     * @param string $field      User submitted token field
     * @param string $identifier Alternative identifier, default is REQUEST_URI
     *
     * @return bool
     */
    public static function validate($field, $identifier = '')
    {
        $identifier = self::_hashIdentifier($identifier);

        if ($_SESSION['csrf_tokens'][$identifier] === $field) {
            unset($_SESSION['csrf_tokens'][$identifier]);

            return true;
        }

        return false;
    }

    /**
     * Generate identifier has as key to store the token inside the session
     *
     * @param string $identifier
     *
     * @return string
     */
    protected static function _hashIdentifier($identifier = '')
    {
        return sha1(empty($identifier) ? $_SERVER['REQUEST_URI'] : $identifier);
    }
}
