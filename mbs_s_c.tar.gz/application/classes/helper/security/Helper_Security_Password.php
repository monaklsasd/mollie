<?php
/**
 * Some helper functions for password validation and generation.
 */
class Helper_Security_Password
{
    /** Minimum length of the password, in characters. */
    public const MIN_PASSWORD_LENGTH = 8;

    /**
     * Generate a password.
     *
     * @param int $length
     *
     * @return string
     */
    public static function generate_password($length = self::MIN_PASSWORD_LENGTH)
    {
        // Chars without confusing chars like l, 1, I !, and 0 O and o.
        $chars = "23456789abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVW!@#\$%^&*()+";

        for ($password = ""; strlen($password) < $length; $password .= $chars[mt_rand(0, strlen($chars) - 1)]) {
        }

        return $password;
    }

    /**
     * Replace unobvious characters with other, random characters. This prevent human error during copying.
     *
     * @param string $input
     *
     * @return string
     */
    public static function replace_unclear_characters_with_clear_characters($input)
    {
        $illegal_chars = "1IloO0";

        $input = preg_replace_callback("![" . preg_quote($illegal_chars, "!") . "]!", function () {
            $valid_chars = "23456789abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVW";

            return $valid_chars[mt_rand(0, strlen($valid_chars) - 1)];
        }, $input);

        return $input;
    }

    /**
     * Generate a random code, which can be used for whatever (email verification, password resets, account activation).
     *
     * @param int $length
     *
     * @return string
     */
    public static function generate_unique_code($length = 32)
    {
        return bin2hex(openssl_random_pseudo_bytes(floor($length / 2)));
    }

    /**
     * Generate a random code, which can be used for whatever (email verification, password resets, account activation).
     *
     * @param int $maximum
     *
     * @return int
     */
    public static function generate_unique_number($maximum)
    {
        return mt_rand(0, (int)$maximum);
    }

    /**
     * Generate a random GUID (35 chars).
     *
     * @return string
     */
    public static function generate_guid()
    {
        if (function_exists('com_create_guid') === true) {
            return trim(com_create_guid(), '{}');
        }

        return sprintf('%04X%04X-%04X-%04X-%04X-%04X%04X%04X', mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(16384, 20479), mt_rand(32768, 49151), mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(0, 65535));
    }

    /**
     * Generate a random code in base64 notation with a provided length.
     *
     * @param int  $length
     * @param bool $compatibility_mode Replaces non-alphanumeric characters.
     *
     * @return string
     */
    public static function generate_unique_base64($length = 32, $compatibility_mode = true)
    {
        $result = substr(base64_encode(openssl_random_pseudo_bytes($length)), 0, $length);

        if ($compatibility_mode) {
            $result = strtr($result, ['+' => 'A', '/' => 'B', '=' => 'C']);
        }

        return $result;
    }
}
