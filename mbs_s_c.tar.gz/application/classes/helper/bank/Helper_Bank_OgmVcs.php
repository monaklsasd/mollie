<?php

/**
 * Class Helper_Bank_OgmVcs.
 *
 * Parses, and format Overschrijvingen met Gestructureerde Mededeling (OGM).
 *
 * @see https://nl.wikipedia.org/wiki/Gestructureerde_mededeling
 * @see http://www.sepabelgium.be/nl/de-gestructureerde-mededeling
 * @see https://www.febelfin.be/sites/default/files/Payments/AOS-OGMVCS.pdf
 * @see http://www.exactsoftware.com/docs/DocView.aspx?DocumentID=%7B10a9fb99-d948-4068-806f-959bd4305b5f%7D&NoSubject=1
 */
final class Helper_Bank_OgmVcs
{
    public const OGM_LENGTH = 12;

    /**
     * No constructor, static usage only.
     */
    private function __construct()
    {
    }

    public static function generate(): string
    {
        $random_digits = Helper_Security_Password::generate_unique_number(1e10);
        $check_digits  = $random_digits % 97 ?: 97;

        return sprintf("%010d%02d", $random_digits, $check_digits);
    }

    public static function validate(string $ogm): bool
    {
        if (!ctype_digit($ogm)) {
            return false;
        }

        if (strlen($ogm) != self::OGM_LENGTH) {
            return false;
        }

        $check_digits = (int)(substr($ogm, -2));

        if ($check_digits == 97) {
            $check_digits = 0;
        }

        $random_digits = substr($ogm, 0, -2);

        return $random_digits % 97 == $check_digits;
    }

    public static function find_ogm(?string $text): ?string
    {
        /*
         * Remove all non-alphanumeric characters.
         */
        $cleaned_text = preg_replace("/[^a-z0-9]*/i", "", $text);

        /*
         * Get all numbers, separated by a group of letters.
         */
        $numbers = preg_split("/[a-z]+/i", $cleaned_text, null, PREG_SPLIT_NO_EMPTY);

        $possible_ogms = [];

        /*
         * Get the possible OGM's in this text.
         */
        foreach ($numbers as $number) {
            if (strlen($number) < self::OGM_LENGTH) {
                /*
                 * Too short, cannot possible be a valid OGM.
                 */
                continue;
            }

            for ($i = 0; $i <= strlen($number) - self::OGM_LENGTH; $i++) {
                $possible_ogm = substr($number, $i, self::OGM_LENGTH);

                if (self::validate($possible_ogm)) {
                    /*
                     * This could be a OGM, let's add it to the result array.
                     */
                    $possible_ogms[] = $possible_ogm;
                }
            }
        }

        $number_of_possible_ogms = count($possible_ogms);

        if ($number_of_possible_ogms === 1) {
            /*
             * One possible OGM found, this is it.
             */
            return $possible_ogms[0];
        }

        if ($number_of_possible_ogms > 1) {
            /*
             * Multiple possible OGM's are found.
             * An OGM fully contained between / characters is most likely to be the correct one.
             */
            foreach ($possible_ogms as $possible_ogm) {
                $ogm_length = self::OGM_LENGTH;
                preg_match_all("#([/]{1,})(\\d{{$ogm_length}})\\1#", $text, $matches);

                if (in_array($possible_ogm, $matches[2])) {
                    return $possible_ogm;
                }
            }
            /*
             * No surrounding characters? Just make a guess and return the first one then.
             */
            return $possible_ogms[0];
        }

        return null;
    }

    /**
     * Format according to Belgium standards.
     */
    public static function format(string $ogm): string
    {
        return "+++" . substr($ogm, 0, 3) . "/" . substr($ogm, 3, 4) . "/" . substr($ogm, 7) . "+++";
    }
}
