<?php

class Helper_Banktransaction_Matching
{
    /**  (?<![T0-9]) means: not preceded by a T or a digit. */
    private const LEGACY_OUTPAYMENT_REFERENCE_PATTERN     = '/(?<![T0-9])([1-9]\d{3,}\.(?:[0-2][0-9])(?:0[1-9]|1[0-2])\.\d{2})(?!C)/i';
    private const TRANSFER_REFERENCE_PATTERN              = '/(?:T)([0-9]{8}\.(?:[0-2][0-9])(?:0[1-9]|1[0-2])\.\d{2})/i';
    private const PREPAYMENT_SETTLEMENT_REFERENCE_PATTERN = '/Prepayment Settlement (\d{8}\.0[0-1].\d{6})/i';

    /**
     * Will search for a RF ID (SEPA) or Gestructureerde Mededeling (OGM)
     *
     * @param $string
     *
     * @return string|null
     */
    public static function get_banktransfer_transaction_id(?string $string)
    {
        if ($string === null) {
            return null;
        }

        if (stripos($string, "RF") !== false) {
            /* First try RF transaction id */
            if ($transaction_id = Helper_Banktransaction_Matching::get_banktransfer_rf($string)) {
                return $transaction_id;
            }
        }

        return Helper_Bank_OgmVcs::find_ogm($string) ?: Helper_Banktransaction_Matching::get_banktransfer_rf($string);
    }

    /**
     * Get the mollie transaction id from a string, if present. Look for the given prefix.
     *
     * @param string $prefix of 2 characters, e.g. "RF" or "SD"
     */
    public static function get_mollie_transaction_id(string $string, string $prefix): ?string
    {
        if (trim($string) === '') {
            return null;
        }

        $string = preg_replace("!\\(EREF\\)!i", "", $string);

        $mapping = [
            "("   => "9",
            ")"   => "0",
            "RFF" => "RF3",
        ];

        $valid_char_to_int_translations = [
            "B" => 8,
            "I" => 1,
            "G" => 9, /* Sometimes also interpreted as a 6 */
            "O" => 0,
            "S" => 5,
            "Y" => 4,
            "Z" => 2,
        ];

        foreach ($valid_char_to_int_translations as $first_search => $first_replace) {
            $mapping["{$prefix}{$first_search}"] = "{$prefix}{$first_replace}";

            foreach ($valid_char_to_int_translations as $second_search => $second_replace) {
                $mapping["{$prefix}{$first_search}{$second_search}"] = "{$prefix}{$first_replace}{$second_replace}";
            }
        }

        /*
         * Sort by length longest first, and alphabetically
         */
        uksort($mapping, function ($a, $b) {
            if (strlen($a) == strlen($b)) {
                return strcmp($a, $b);
            }

            return strlen($b) - strlen($a);
        });

        $string = str_replace(array_keys($mapping), array_values($mapping), $string);

        $description = mb_strtoupper(preg_replace("![-/.\r\n ]!", "", $string));

        $regexp_escaped_prefix = preg_quote($prefix, '!');

        /* Replace any "O"'s surrounded by digits by zeroes */
        $description = preg_replace_callback("!(\\d+|{$regexp_escaped_prefix})(O+)(\\d+)!", function (array $matches) {
            return "{$matches[1]}" . str_repeat("0", strlen($matches[2])) . "{$matches[3]}";
        }, $description);

        /* Be greedy here */
        if (!preg_match_all("!({$regexp_escaped_prefix})?(\\d{10,})!i", $description, $matches, PREG_PATTERN_ORDER)) {
            return null;
        }

        $unique_matches = array_unique($matches[0]);

        $unique_matches = array_filter($unique_matches, function ($each) {
            if (ctype_digit($each) && strlen($each) < 11) {
                /*
                 * There are supposed to be 14 digits. Less than 11 digits provided and no prefix provided? Probably not
                 * a bank transfer reference.
                 */
                return false;
            }

            return true;
        });

        /*
         * Sort all the numbers that start with prefix to the top.
         */
        usort($unique_matches, function ($a, $b) use ($prefix) {
            if (strpos($a, $prefix) === 0 && strpos($b, $prefix) === 0) {
                return 0;
            }

            if (strpos($b, $prefix) === 0) {
                return 1;
            }

            return -1;
        });

        foreach ($unique_matches as $match) {
            if (strpos($match, $prefix) !== 0) {
                $match = $prefix . $match;
            }

            if (strlen($match) === 16) {
                /* Happy path with a match that's exactly the right length */
                if (Helper_Iso_7064::validate($match)) {
                    return $match;
                }
            } elseif (strlen($match) > 16) {
                /* Started with prefix, but there are some trailing digits. Just trim and see if we get lucky */
                $trimmed_match = substr($match, 0, 16);

                if (Helper_Iso_7064::validate($trimmed_match)) {
                    return $trimmed_match;
                }
            } elseif (strlen($match) < 16) {
                /* Maybe one or more zeroes were missed? Add them back and see if we get lucky now */
                $missing_zeroes    = 16 - strlen($match);
                $zero_padded_match = implode("", [substr($match, 0, 4), str_repeat("0", $missing_zeroes), substr($match, 4)]);

                if (Helper_Iso_7064::validate($zero_padded_match)) {
                    return $zero_padded_match;
                }
            }

            if (strlen($match) === 17) {
                /*
                 * One digit too long. See if we can throw out random digits.
                 *
                 * We'll get this wrong in 14/97 of the cases through. But better than nothing. Skip the first two "RF"
                 * chars.
                 */
                for ($char_to_skip = 2; $char_to_skip < strlen($match); $char_to_skip++) {
                    $with_one_char_removed = substr($match, 0, $char_to_skip) . substr($match, $char_to_skip + 1);

                    if (Helper_Iso_7064::validate($with_one_char_removed)) {
                        return $with_one_char_removed;
                    }
                }
            }
        }

        return null;
    }

    /**
     * Get the bank transfer id (transaction id in Mollie) from a string, if present. Starts with "RF...".
     */
    public static function get_banktransfer_rf(string $string): ?string
    {
        return self::get_mollie_transaction_id($string, 'RF');
    }

    /**
     * Get the direct debit id (transaction id in Mollie) from a string, if present. Starts with "SD...".
     */
    public static function get_directdebit_sd(string $string): ?string
    {
        return self::get_mollie_transaction_id($string, 'SD');
    }

    /**
     * Get the direct debit reason code from description "... (redencode: AB01) ..."
     * However more often the MT940 /RTRN/ section already has a value provided, see
     * Bank_StatementReader_MT940::_parseSepaReversalTransactionDescription
     *
     * @param $string
     *
     * @return string|null
     */
    public static function get_directdebit_reason_code(?string $string)
    {
        if ($string === null) {
            return null;
        }

        if (preg_match('/reden(code)?:\s*(?P<reason_code>[A-Z]{2}[0-9]{2})/i', $string, $matches)) {
            return mb_strtoupper($matches['reason_code']);
        }

        return null;
    }

    /**
     * Get a purchase reference (MnnnnnnMnnnnnn), if present.
     *
     * @param $description
     *
     * @return string|null
     */
    public static function get_purchase_reference(?string $description)
    {
        if ($description === null) {
            return null;
        }

        if (preg_match("!(?P<purchase_reference>M[0-9]{6,7}M[A-Z0-9]{7,8})!", $description, $matches)) {
            return $matches["purchase_reference"];
        }

        return null;
    }

    /**
     * Get the acquirer transaction id, if present.
     */
    public static function getAcquirerTransactionId(?string $description): ?string
    {
        if ($description === null) {
            return null;
        }

        if (preg_match('/0\s*0[235]0[10][\d\s]{11,}/', $description, $matches)) {
            $found = preg_replace('/\s+/', '', $matches[0]);

            if (strlen($found) >= 16) {
                /* It is possible that some numbers follow the acquirer ID, ignore that */
                return substr($found, 0, 16);
            }
        }

        return null;
    }

    /**
     * Get the outpayment reference in a string, if there is one. Doesn't match transfer payouts, which have a leading T
     *
     * @param string $description
     *
     * @return string
     */
    public static function getOutpaymentReference(?string $description): ?string
    {
        if ($description === null) {
            return null;
        }

        if (!preg_match(self::LEGACY_OUTPAYMENT_REFERENCE_PATTERN, $description, $matches)) {
            return null;
        }

        return $matches[1];
    }

    /**
     * Determine if string contains a transfer payout reference (which has a leading 'T' before the reference)
     *
     * @param string $description
     *
     * @return bool
     */
    public static function getTransferPayoutReference(?string $description): ?string
    {
        if ($description === null) {
            return null;
        }

        if (!preg_match(self::TRANSFER_REFERENCE_PATTERN, $description, $matches)) {
            return null;
        }

        return $matches[1];
    }

    public static function getPrepaymentSettlementReference(?string $description): ?string
    {
        if ($description === null) {
            return null;
        }

        if (!preg_match(self::PREPAYMENT_SETTLEMENT_REFERENCE_PATTERN, $description, $matches)) {
            return null;
        }

        return $matches[1];
    }

    /**
     * Get the credit transfer reference in a string, if there is one.
     */
    public static function get_credittransfer_rf(string $reference): ?string
    {
        if (!preg_match('/(credittransfer-[0-9]+\\.[0-9]+)/i', $reference, $matches)) {
            return null;
        }

        return $matches[1];
    }

    public static function getRefundPaymentId(?string $description): ?string
    {
        if ($description === null) {
            return null;
        }

        if (!preg_match("!(?P<refund_payment_id>\\d{8,}) Refund!", $description, $matches)) {
            return null;
        }

        $refund_payment_id = $matches['refund_payment_id'];

        if (!is_numeric($refund_payment_id)) {
            return null;
        }

        return $refund_payment_id;
    }

    /**
     * Get the 12 char Paybox reference from the description of the transaction.
     */
    public static function get_paybox_reference(?string $description): ?string
    {
        if ($description === null) {
            return null;
        }

        if (preg_match("!\\d{2}/\\d{2} REF[^-]+ - ([a-f0-9]+)!", $description, $matches)) {
            return strtoupper($matches[1]);
        }

        if (preg_match("!([a-f0-9]{12})\r?\n\\1\\)\$!", $description, $matches)) {
            return strtoupper($matches[1]);
        }

        if (strpos($description, ", BANKSYS") !== 0) {
            return null;
        }

        if (!preg_match("!0+([A-F0-9]{12}) 00(?: \\([^)]+\\))?\$!", $description, $matches)) {
            return null;
        }

        return $matches[1];
    }

    /**
     * Matches descriptions from bank transactions from Valitor to get the correct settlement numbers. More details
     * on these settlements can be retrieved from MCCS.
     *
     * @param string $description
     *
     * @return string[]
     */
    public static function get_valitor_settlement_numbers(?string $description)
    {
        if ($description === null) {
            return [];
        }

        if (preg_match_all("!M\\d{6,}!", $description, $matches)) {
            return array_unique($matches[0]);
        }

        return [];
    }

    /**
     * Get the original account number and account holder from a wereldoverboeking or a "SEPA iDEAL" overboeking.
     *
     * @param $description
     *
     * @return string[]|null
     */
    public static function get_original_transaction_details($description)
    {
        if (strpos($description, "ONZE REF") === 0) {
            if (preg_match(
                "!(BEGUNST(?:\\.|IGDE|)|OPDRACHTGEVER)[\r\n]+/(ID/)?(?P<account_number>[A-Z0-9]{8,})\\s+(?P<account_holder>[^\r\n]+)!",
                $description,
                $matches
            )) {
                return [$matches["account_number"], $matches["account_holder"]];
            }
        }

        if (strpos($description, "SEPA iDEAL") === 0) {
            $account_number = null;
            $account_holder = null;

            if (preg_match("!IBAN: (?P<account_number>NL\\d{2}[A-Z\\d]{14})!", $description, $matches)) {
                $account_number = $matches["account_number"];
            }

            if (preg_match("!Naam: (?P<account_holder>.*?)Omschrijving!s", $description, $matches)) {
                $account_holder = str_replace(["\n", "\r", "  "], " ", trim($matches["account_holder"]));
            }

            if ($account_number && $account_holder) {
                return [$account_number, $account_holder];
            }
        }

        return null;
    }

    /**
     * Get the (truncated) Mister Cash transaction id from a refund description.
     *
     * @param $description
     */
    public static function get_mistercash_transaction_id($description)
    {
        if (strpos($description, "Refund") === false) {
            return null;
        }

        if (!preg_match("!transactie ([a-f0-9]{12}) !", $description, $matches)) {
            return null;
        }

        return $matches[1];
    }
}
