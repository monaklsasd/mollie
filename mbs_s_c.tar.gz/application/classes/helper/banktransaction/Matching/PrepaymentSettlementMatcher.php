<?php

namespace Helper\BankTransaction\Matching;

use Helper_Banktransaction_Matching;
use Ledger\PrepaymentSettlements\PrepaymentSettlementReference;
use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use Webmozart\Assert\Assert;

/**
 * Prepayment Settlements represent the movement of funds in Ledger between two journals. In this case, the two
 * journals are the Mollie BV (CheckingAccount) and the Stichting Mollie Payments (SMP - AbnAmroOutpaymentsAccount).
 * Generally MBS would tag these as 'intra_company', but they are more than that and should be identified more
 * specifically.
 *
 * The movement between the two journals/bank accounts can be indicative of transferring payment method fees, from
 * the SMP to the BV, or of transferring partner commissions or invoice rounding differences back to the merchants,
 * from the BV to the SMP.
 *
 * In the Legacy system, pre-Ledger, system the prepayment settlement from the SMP to the BV was handled through
 * the Outpayments batches and simply marked as intra_company. No automated system exists for the reverse operation.
 *
 * Each prepayment settlement will appear in both of the journals/bank accounts in question. One as a negative amount
 * (prepayment settlement sent) and one as a positive amount (prepayment settlement received), both with the same exact
 * bank transaction description.
 *
 * A rare edge case is when a prepayment settlement fails, being returned by the bank on the originating source account.
 * So there would be both a positive and negative amount on the same statement across days.
 */
class PrepaymentSettlementMatcher
{
    public static function getPrepaymentSettlementReference(
        Model_Banktransaction $transaction
    ): ?PrepaymentSettlementReference {
        $reference_string = Helper_Banktransaction_Matching::getPrepaymentSettlementReference(
            $transaction->getDescription()
        );

        return $reference_string !== null ? PrepaymentSettlementReference::fromString($reference_string) : null;
    }

    public static function markTransactionAsPrepaymentSettlement(Model_Banktransaction $transaction): void
    {
        $reference                 = self::getPrepaymentSettlementReference($transaction);
        $current_statement_journal = $transaction->getJournal();

        Assert::notNull($reference);

        $transaction->setTagData(
            [
                'prepayment_settlement_reference' => $reference->getReference(),
                'source_journal'                  => $current_statement_journal->getValue(),
            ]
        );

        if ($reference->getSourceJournal()->equals($current_statement_journal)) {
            self::processSentPrepaymentSettlement($transaction);
        } else {
            self::processReceivedPrepaymentSettlement($transaction);
        }
    }

    private static function processSentPrepaymentSettlement(Model_Banktransaction $transaction): void
    {
        if ($transaction->isDebited()) {
            $transaction->addTag(TransactionTags::TAG_PREPAYMENT_SETTLEMENT_SENT);

            return;
        }

        Assert::true(
            $transaction->isReturnedTransaction(),
            "Unexpected transaction for prepayment settlement that was sent, must be a returned settlement if not debited"
        );
        $transaction->addTag(TransactionTags::TAG_FAILURE_PREPAYMENT_SETTLEMENT);
    }

    private static function processReceivedPrepaymentSettlement(Model_Banktransaction $transaction): void
    {
        Assert::true(
            $transaction->isCredited(),
            "Unexpected transaction for prepayment settlement that is being received, must be credited"
        );
        Assert::false(
            $transaction->isReturnedTransaction(),
            "Returned transaction on a bank account that isn't the originator for the prepayment settlement reference."
        );

        $transaction->addTag(TransactionTags::TAG_PREPAYMENT_SETTLEMENT_RECEIVED);
    }
}
