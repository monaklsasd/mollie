<?php

namespace Helper\BankTransaction\Matching;

class SofortMatcher
{
    /** This is the most common prefix for SOFORT transactions. */
    private const SOFORT_PREFIX = "93222-";

    /**
     * Get the SOFORT Banking transaction ID from the description.
     */
    public static function getFromDescription(?string $description): ?string
    {
        if ($description === null) {
            return null;
        }

        $description = preg_replace("!\\s+!", "", $description);

        $separator = "[-. ]?";

        if (preg_match("!(?P<sofort_user_id>9322[234]){$separator}(?P<project_id>\\d{6}){$separator}(?P<code_a>[0-9A-F]{1,8}){$separator}(?P<code_b>[0-9A-F]{0,4})!i", $description, $matches)) {
            return rtrim("{$matches["sofort_user_id"]}-{$matches["project_id"]}-{$matches["code_a"]}-{$matches["code_b"]}", "-");
        }

        /*
         * Check if it was truncated on the front.
         */
        if (preg_match('!(?P<sofort_prefix>\d{0,5}-?)\d{6}-[0-9A-F]{8}-[0-9A-F]{4}!i', $description, $matches)) {
            $prefix = substr(self::SOFORT_PREFIX, 0, strlen(self::SOFORT_PREFIX) - strlen($matches["sofort_prefix"]));

            return "{$prefix}{$matches[0]}";
        }

        return null;
    }
}
