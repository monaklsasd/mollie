<?php

namespace ExceptionalTransactions;

use App\Entity\ExceptionalTransactions\Suspension;
use App\Entity\User;
use App\Repository\ExceptionalTransactions\SuspensionRepository;
use Doctrine\ORM\EntityManager;
use Model_Banktransaction;
use Webmozart\Assert\Assert;

class TransactionSuspender
{
    /** @var EntityManager */
    private $entity_manager;

    /** @var SuspensionRepository */
    private $suspension_repository;

    public function __construct(EntityManager $entity_manager, SuspensionRepository $suspension_repository)
    {
        $this->entity_manager        = $entity_manager;
        $this->suspension_repository = $suspension_repository;
    }

    public function putTransactionOnHold(
        Model_Banktransaction $bank_transaction,
        User $suspender,
        ?string $suspension_reason
    ): void {
        $suspension = new Suspension();

        $suspension->setBankTransaction($bank_transaction);
        $suspension->setReason($suspension_reason);
        $suspension->setSuspendedBy($suspender);

        $this->entity_manager->persist($suspension);
        $this->entity_manager->flush();
    }

    public function unsuspendTransaction(
        Model_Banktransaction $banktransaction,
        User $deleted_by
    ): void {
        $suspensions = $this->suspension_repository->findByBankTransactions([$banktransaction]);

        if ($suspensions->count() < 1) {
            return;
        }

        Assert::count(
            $suspensions,
            1,
            sprintf("Multiple active suspensions found for transaction: #%d, something is wrong.", $banktransaction->id)
        );

        /** @var Suspension $suspension */
        $suspension = $suspensions->first();
        $suspension->setDeleted($deleted_by);

        $this->entity_manager->persist($suspension);
        $this->entity_manager->flush();
    }
}
