<?php

namespace Controller\Exception;

use Controller_Exception;

class UserNotFoundException extends Controller_Exception
{
}
