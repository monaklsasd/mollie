<?php

use App\Controller\Legacy\LegacyBridgeController;
use App\Entity\Privilege;
use App\Entity\User;
use App\Repository\UserRepository;
use Core\Controllers\Controller;
use Symfony\Component\Security\Core\Authorization\AuthorizationCheckerInterface;

/**
 * Base class for controllers
 *
 * @author Mathieu Kooiman <mathieu@mollie.nl>
 * @copyright Copyright (C), Mollie B.V.
 */
abstract class Controller_Base implements Controller
{
    /** HTTP Methods. */
    public const METHOD_GET     = 'GET';
    public const METHOD_POST    = 'POST';
    public const METHOD_DELETE  = 'DELETE';
    public const METHOD_HEAD    = 'HEAD';
    public const METHOD_OPTIONS = 'OPTIONS';

    /** The request has succeeded. */
    public const HTTP_OK = 200;

    /**
     * The request has been fulfilled and resulted in a new resource being created. The newly created resource can be
     * referenced by the URI(s) returned in the entity of the response, with the most specific URI for the resource
     * given by a Location header field. The response SHOULD include an entity containing a list of resource
     * characteristics and location(s) from which the user or user agent can choose the one most appropriate. The entity
     * format is specified by the media type given in the Content-Type header field. The origin server MUST create the
     * resource before returning the 201 status code. If the action cannot be carried out immediately, the server SHOULD
     * respond with 202 (Accepted) response instead.
     */
    public const HTTP_CREATED = 201;

    /**
     * The server has fulfilled the request but does not need to return an entity-body, and might want to return updated
     * metainformation. The response MAY include new or updated metainformation in the form of entity-headers, which if
     * present SHOULD be associated with the requested variant.
     */
    public const HTTP_NO_CONTENT = 204;

    /**
     * The requested resource has been assigned a new permanent URI and any future references to this resource SHOULD
     * use one of the returned URIs. Clients with link editing capabilities ought to automatically re-link references
     * to the Request-URI to one or more of the new references returned by the server, where possible. This response is
     * cacheable unless indicated otherwise.
     */
    public const HTTP_MOVED_PERMANENTLY = 301;

    /**
     * The requested resource resides temporarily under a different URI. Since the redirection might be altered on
     * occasion, the client SHOULD continue to use the Request-URI for future requests. This response is only cacheable
     * if indicated by a Cache-Control or Expires header field.
     */
    public const HTTP_FOUND = 302;

    /**
     * The response to the request can be found under a different URI and SHOULD be retrieved using a GET method on that
     * resource. This method exists primarily to allow the output of a POST-activated script to redirect the user agent
     * to a selected resource. The new URI is not a substitute reference for the originally requested resource. The 303
     * response MUST NOT be cached, but the response to the second (redirected) request might be cacheable.
     */
    public const HTTP_SEE_OTHER = 303;

    /**
     * If the client has performed a conditional GET request and access is allowed, but the document has not been
     * modified, the server SHOULD respond with this status code. The 304 response MUST NOT contain a message-body, and
     * thus is always terminated by the first empty line after the header fields.
     */
    public const HTTP_NOT_MODIFIED = 304;

    /**
     * The requested resource resides temporarily under a different URI. Since the redirection MAY be altered on
     * occasion, the client SHOULD continue to use the Request-URI for future requests. This response is only cacheable
     * if indicated by a Cache-Control or Expires header field.
     */
    public const HTTP_TEMPORARY_REDIRECT = 307;

    /**
     * The request could not be understood by the server due to malformed syntax. The client SHOULD NOT repeat the
     * request without modifications.
     */
    public const HTTP_BAD_REQUEST = 400;

    /**
     * The request requires user authentication. The response MUST include a WWW-Authenticate header field (section
     * 14.47) containing a challenge applicable to the requested resource. The client MAY repeat the request with a
     * suitable Authorization header field (section 14.8). If the request already included Authorization credentials,
     * then the 401 response indicates that authorization has been refused for those credentials. If the 401 response
     * contains the same challenge as the prior response, and the user agent has already attempted authentication at
     * least once, then the user SHOULD be presented the entity that was given in the response, since that entity might
     * include relevant diagnostic information.
     */
    public const HTTP_UNAUTHORIZED = 401;

    /**
     * The server understood the request, but is refusing to fulfill it. Authorization will not help and the request
     * SHOULD NOT be repeated. If the request method was not HEAD and the server wishes to make public why the request
     * has not been fulfilled, it SHOULD describe the reason for the refusal in the entity. If the server does not wish
     * to make this information available to the client, the status code 404 (Not Found) can be used instead.
     */
    public const HTTP_FORBIDDEN = 403;

    /**
     * The server has not found anything matching the Request-URI. No indication is given of whether the condition is
     * temporary or permanent. The 410 (Gone) status code SHOULD be used if the server knows, through some internally
     * configurable mechanism, that an old resource is permanently unavailable and has no forwarding address. This
     * status code is commonly used when the server does not wish to reveal exactly why the request has been refused, or
     * when no other response is applicable.
     */
    public const HTTP_NOT_FOUND = 404;

    /**
     * The method specified in the Request-Line is not allowed for the resource identified by the Request-URI. The
     * response MUST include an Allow header containing a list of valid methods for the requested resource.
     */
    public const HTTP_METHOD_NOT_ALLOWED = 405;

    /**
     * The resource identified by the request is only capable of generating response entities which have content
     * characteristics not acceptable according to the accept headers sent in the request.
     */
    public const HTTP_NOT_ACCEPTABLE = 406;

    /**
     * The requested resource is no longer available at the server and no forwarding address is known. This condition is
     * expected to be considered permanent. Clients with link editing capabilities SHOULD delete references to the
     * Request-URI after user approval. If the server does not know, or has no facility to determine, whether or not the
     * condition is permanent, the status code 404 (Not Found) SHOULD be used instead. This response is cacheable unless
     * indicated otherwise.
     */
    public const HTTP_GONE = 410;

    /**
     * The server is refusing to service the request because the entity of the request is in a format not supported by
     * the requested resource for the requested method.
     */
    public const HTTP_UNSUPPORTED_MEDIA_TYPE = 415;

    /** The request was well-formed but was unable to be followed due to semantic errors. */
    public const HTTP_UNPROCESSABLE_ENTITY = 422;

    /** The server encountered an unexpected condition which prevented it from fulfilling the request. */
    public const HTTP_INTERNAL_SERVER_ERROR = 500;

    /**
     * The server, while acting as a gateway or proxy, received an invalid response from the upstream server it accessed
     * in attempting to fulfill the request.
     */
    public const HTTP_BAD_GATEWAY = 502;

    /**
     * The server is currently unable to handle the request due to a temporary overloading or maintenance of the server.
     * The implication is that this is a temporary condition which will be alleviated after some delay. If known, the
     * length of the delay MAY be indicated in a Retry-After header. If no Retry-After is given, the client SHOULD
     * handle the response as it would for a 500 response.
     */
    public const HTTP_SERVICE_UNAVAILABLE = 503;

    /** @var sql_db */
    protected $_db;

    /**
     * Logger
     *
     * @var Mollie_Logger
     */
    protected $_logger;

    /** @var User|null */
    protected $_user;

    /** @var Mollie_FlashMessenger */
    protected $flash_messenger;

    /** @var UserRepository */
    protected $user_repository;

    /** @var AuthorizationCheckerInterface */
    protected $authorization_checker;

    /** @var string[] */
    protected $response_headers = [];

    /** @var \Symfony\Bundle\FrameworkBundle\Routing\Router */
    protected $symfony_router;

    /** @var int */
    protected static $_status_code = self::HTTP_OK;

    /**
     * List of success messages that will be visible in the next page.
     *
     * @var string[]
     */
    private $_successes = [];

    /** @var string[] */
    private $_errors = [];

    /** @var string[] */
    private $_warnings = [];

    public function __construct(
        sql_db $db,
        Mollie_Logger $logger,
        Mollie_FlashMessenger $flash_messenger,
        UserRepository $user_repository,
        AuthorizationCheckerInterface $authorization_checker,
        LegacyBridgeController $legacy_bridge_controller
    ) {
        $this->_db                   = $db;
        $this->_logger               = $logger;
        $this->flash_messenger       = $flash_messenger;
        $this->user_repository       = $user_repository;
        $this->authorization_checker = $authorization_checker;

        $this->symfony_router = $legacy_bridge_controller->getRouter();

        $this->_logger->setRemoteIpAddress($this->getRequestIp());

        if (isset($_SERVER['UNIQUE_ID'])) {
            $this->_logger->setRequestId($_SERVER['UNIQUE_ID']);
        }

        if ($this->canPerformSensitiveRequests() === false) {
            $this->increaseApmLogDetails();
        }
    }

    /**
     * Allow storing of more data to aid in debugging
     */
    protected function increaseApmLogDetails()
    {
        // Allow storing POST data
        ini_set('apm.store_post', true);

        // Allow storing potentially sensitive cookies
        ini_set('apm.store_cookies', true);

        // Include some arguments in the strack trace
        ini_set('apm.dump_max_depth', 1);
    }

    /**
     * Determines if we need to take some extra care dealing with logging for this request
     */
    protected function canPerformSensitiveRequests()
    {
        return false;
    }

    public function getRequiredPrivilegesForAction($action)
    {
        return [];
    }

    /**
     * Get the Flash Messenger
     *
     * @see https://www.youtube.com/watch?v=GBXd0Qivrhg
     *
     * @return Mollie_FlashMessenger
     */
    private function _getFlashMessenger()
    {
        return $this->flash_messenger;
    }

    /**
     * Do we have any errors yet? These errors will be visible on the next page.
     *
     * @return bool
     */
    public function hasErrors()
    {
        return count($this->_errors) > 0;
    }

    /**
     * Add a warning message to the next page.
     *
     * @param $text
     */
    public function addWarning($text)
    {
        $this->_warnings[] = $text;
        $this->_getFlashMessenger()->addMessage($text, Helper_View_MessageBox::WARNING_BOX);
    }

    /**
     * Add an error message to the next page.
     *
     * @param $text
     */
    public function addError($text)
    {
        $this->_errors[] = $text;
        $this->_getFlashMessenger()->addMessage($text, Helper_View_MessageBox::ERROR_BOX);
    }

    /**
     * Add a success message to the next page.
     *
     * @param $text
     */
    public function addSuccess($text)
    {
        $this->_successes[] = $text;
        $this->_getFlashMessenger()->addMessage($text, Helper_View_MessageBox::SUCCESS_BOX);
    }

    public function preAction($action_name)
    {
        if ($this->_user === null) {
            throw new LogicException('Not user is signed in. This should have been caught earlier');
        }

        $this->_logger->setUserId($this->_user->getId());

        if (!$this->userHasRequiredPrivilegesForAction($action_name, true)) {
            $this->_showInsufficientPrivilegesPage();

            return false;
        }

        return true;
    }

    protected function userHasPrivileges(string ...$privilegeNames): bool
    {
        $roleNames = array_map([Privilege::class, 'getRoleNameFromPrivilegeName'], $privilegeNames);

        foreach ($roleNames as $roleName) {
            if (!$this->authorization_checker->isGranted($roleName)) {
                return false;
            }
        }

        return true;
    }

    protected function userHasRequiredPrivilegesForAction(string $action_name, bool $log_insufficient_privileges = false): bool
    {
        $active_privileges = [];

        $required_privileges = $this->getRequiredPrivilegesForAction(strtolower($action_name));

        $isGranted = $this->userHasPrivileges(...$required_privileges);

        if (!$isGranted && $log_insufficient_privileges) {
            foreach ($this->_getCurrentUser()->getPrivileges() as $privilege) {
                $active_privileges[] = $privilege->getName();
            }

            $this->_logger->log_warning(
                Mollie_Logger::LOG_CATEGORY_WEBSITE,
                'User tried to access restricted action',
                sprintf(
                    'User needed: %s, had: %s.',
                    implode(', ', $required_privileges),
                    implode(', ', $active_privileges)
                )
            );
        }

        // Only allow access when ALL required privileges are active for this user
        return $isGranted;
    }

    /**
     * TODO: actually use the PSR-7 request object and action args.
     *
     * @param \Core\Http\Request $request
     * @param string             $action_method
     * @param string[]           $action_args
     */
    public function dispatch(Core\Http\Request $request, $action_method, $action_args)
    {
        return $this->dispatchActionName($action_method);
    }

    public function dispatchActionName($action_name)
    {
        if (!$this->preAction($action_name)) {
            return;
        }

        $method = "{$action_name}Action";

        return $this->{$method}();
    }

    // Provided as method so it may be overridden in testcases.
    protected function _getHttpPostBody()
    {
        return file_get_contents('php://input');
    }

    protected function _showInsufficientPrivilegesPage()
    {
        $template = [
            'view_template' => 'login/insufficient_privileges.tpl.php',
        ];

        $this->render($template);
    }

    public function render(array $template)
    {
        $template = array_merge($this->defaultTemplateData(), $template); // has side effect
        require $this->getPageTemplate();
    }

    public function defaultTemplateData()
    {
        $default = [
            'symfony_router' => $this->symfony_router,
            'system'         => [
                'controller' => strtolower(str_replace('Controller_', '', get_class($this))),
            ],
        ];

        if ($this->_getCurrentUser() !== null) {
            $default['system']['user_id']    = $this->_getCurrentUser()->getId();
            $default['system']['user_email'] = $this->_getCurrentUser()->getEmail();
        }

        return $default;
    }

    public function getPageTemplate()
    {
        return MOLLIE_TEMPLATE_PATH . '/default.tpl.php';
    }

    public function url($controller, $action, $extra_data = [])
    {
        $querystring_data = [
            'controller' => $controller,
            'action'     => $action,
        ];

        $querystring_data = array_merge($extra_data, $querystring_data);

        return MOLLIE_HTTPS_URL . '/?' . http_build_query($querystring_data);
    }

    public function show_url($controller, $action, $data = [])
    {
        echo $this->url($controller, $action, $data);
    }

    /**
     * Looks at REQUEST_METHOD to find the real HTTP method.
     *
     * @throws Controller_Exception
     *
     * @return string|null
     */
    public function getHttpMethod()
    {
        $method = @$_SERVER['REQUEST_METHOD'];

        if (!in_array($method, [
            static::METHOD_GET,
            static::METHOD_POST,
            static::METHOD_DELETE,
            static::METHOD_HEAD,
            static::METHOD_OPTIONS,
            null, // Not a HTTP request
        ], true)
        ) {
            throw new Controller_Exception("Invalid server request method \"{$method}\".", static::HTTP_BAD_REQUEST);
        }

        return $method;
    }

    /**
     * Is this a POST request?
     *
     * @return bool
     */
    public function isPostRequest()
    {
        return $this->getHttpMethod() == self::METHOD_POST;
    }

    /**
     * Send an HTTP header.
     *
     * @param $header string The header to send, for example "X-Served-By"
     * @param $value string Value of the header, for example "dc1-web-1.mollie.nl"
     *
     * @return bool
     */
    public function setHttpHeader($header, $value)
    {
        if (PHP_SAPI !== 'cli') {
            $this->response_headers[$header] = $value;

            return true;
        }

        return false;
    }

    public function getResponseHeaders(): array
    {
        return $this->response_headers;
    }

    /**
     * Set the HTTP status code for this response.
     *
     * @param $status_code
     */
    public function setHttpStatus($status_code)
    {
        static::$_status_code = $status_code;
    }

    /**
     * Get the HTTP status code.
     *
     * @return int
     */
    public function getHttpStatus()
    {
        return static::$_status_code;
    }

    /**
     * Redirect user to URL, then terminate request
     *
     * @param $url
     */
    public function redirect($url)
    {
        throw \App\Controller\Legacy\Exception\LegacyRedirectException::create($url);
    }

    /**
     * Return the actual IP address for this request.
     *
     * @return string|null
     */
    public function getRequestIp()
    {
        if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            if (strpos($_SERVER['HTTP_X_FORWARDED_FOR'], ',') !== false) {
                $ip_addresses = array_values(array_filter(array_map("trim", explode(",", $_SERVER['HTTP_X_FORWARDED_FOR']))));

                for ($i = count($ip_addresses) - 1; $i >= 0; $i--) {
                    /* Start at the end, find the first not-private IP */
                    if (filter_var($ip_addresses[$i], FILTER_VALIDATE_IP, MOLLIE_ENV != "development" ? FILTER_FLAG_NO_RES_RANGE : 0) && $ip_addresses[$i] !== "127.0.0.1") {
                        return $ip_addresses[$i];
                    }
                }
            }

            return $_SERVER["HTTP_X_FORWARDED_FOR"];
        }

        if (isset($_SERVER["REMOTE_ADDR"])) {
            return $_SERVER["REMOTE_ADDR"];
        }

        return null;
    }

    /**
     * Get the value of the Host request header.
     *
     * @return string
     */
    public static function getRequestHost()
    {
        // @codeCoverageIgnoreStart
        if (PHP_SAPI === "cli" && MOLLIE_ENV !== "test") {
            return null;
        }
        // @codeCoverageIgnoreEnd

        /*
         * We have a proxy, so see if the proxy forwarded the value of the original Host: header.
         */
        if (!empty($_SERVER["HTTP_X_FORWARDED_HOST"])) {
            return $_SERVER["HTTP_X_FORWARDED_HOST"];
        }

        /*
         * Nothing was forwarded? Check the original Host: header. Unfortunately probably overwritten by common.php.
         */
        if (!empty($_SERVER["HTTP_HOST"])) {
            return $_SERVER["HTTP_HOST"];
        }

        /*
         * Apparently no Host: header was passed, calculate the hostname back.
         */
        return parse_url(MOLLIE_HTTPS_URL, PHP_URL_HOST);
    }

    public function setUserFromSymfony(User $user)
    {
        $this->_user = $user;
    }

    /**
     * @return User|null
     */
    protected function _getCurrentUser()
    {
        return $this->_user;
    }

    protected function allowLongRunning(int $time_limit = 0)
    {
        if (MOLLIE_ENV === 'test') {
            return;
        }

        ignore_user_abort();

        set_time_limit($time_limit);
    }
}
