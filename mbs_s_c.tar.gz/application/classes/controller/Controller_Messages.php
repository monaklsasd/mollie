<?php

use App\Controller\Legacy\LegacyBridgeController;
use App\Repository\UserRepository;
use Core\Pagination\Paginator;
use Helper\DateTime\Now;
use Messages\MessageType;
use Orm\ModelFactory;
use Orm\Repositories\MessageRepository;
use Symfony\Component\Security\Core\Authorization\AuthorizationCheckerInterface;

class Controller_Messages extends Controller_MbsBase
{
    use Now;

    /** @var \Orm\ModelFactory */
    private $model_factory;

    /** @var \Orm\Repositories\MessageRepository */
    private $message_repository;

    public function __construct(
        sql_db $db,
        Mollie_Logger $logger,
        Mollie_FlashMessenger $flash_messenger,
        UserRepository $user_repository,
        LegacyBridgeController $legacy_bridge_controller,
        AuthorizationCheckerInterface $authorization_checker,
        ModelFactory $model_factory,
        MessageRepository $message_repository
    ) {
        parent::__construct($db, $logger, $flash_messenger, $user_repository, $authorization_checker, $legacy_bridge_controller);

        $this->model_factory      = $model_factory;
        $this->message_repository = $message_repository;
    }

    /**
     * Action to create a new message
     */
    public function addAction()
    {
        $template = [
            'view_template' => 'messages/add.tpl.php',
        ];

        if ($this->isPostRequest() && $this->validateFormToken()) {
            if ($_POST['body'] === '') {
                $this->flash_messenger->addMessage('Please fill in a message', Helper_View_MessageBox::ERROR_BOX);
                $this->redirect($this->url('messages', 'add'));

                return;
            }

            /** @var MessageModel $message */
            $message = $this->model_factory->create(MessageModel::class);
            $message->setMessageType(filter_var($_POST['message_type'], FILTER_SANITIZE_STRING));
            $message->setBody(filter_var($_POST['body'], FILTER_SANITIZE_STRING));

            $message->saveOrDie();

            $this->flash_messenger->addMessage('New message has been post', Helper_View_MessageBox::SUCCESS_BOX);

            $this->redirect($this->url('lists', 'overview'));

            return;
        }

        $this->render($template);
    }

    /**
     * List all the messages
     */
    public function listAction()
    {
        $pagination = new Paginator();

        $page_number = isset($_GET[$pagination->getUrlKey()]) ? (int)$_GET[$pagination->getUrlKey()] : 1;
        $pagination->setCurrentPage($page_number);
        $pagination->setItemsPerPage(20);
        $pagination->setTargetLink($_SERVER['REQUEST_URI']);

        $messages = $this->message_repository->findAllPaginated(
            $pagination->getItemsPerPage(),
            $pagination->getCurrentOffset(),
            MessageType::EXCEPTIONAL_TRANSACTIONS,
            $found_rows
        );

        $pagination->setItemTotal($found_rows);

        $template = [
            'view_template' => 'messages/list.tpl.php',
            'messages'      => $messages,
            'pagination'    => $pagination,
        ];

        $this->render($template);
    }

    /**
     * Mark the message as read
     */
    public function readAction()
    {
        if ($this->isPostRequest()) {
            $message = $this->message_repository->findById((int)$_POST['id']);

            $message->setReadAt($this->getNow());
            $message->saveOrDie();

            return;
        }

        $this->setHttpStatus(422);
    }

    public function viewAction()
    {
        $message = $this->message_repository->findById((int)$_GET['id']);

        if ($message == null) {
            $this->setHttpStatus(404);

            return;
        }

        $template = [
            'view_template' => 'messages/view.tpl.php',
            'message'       => $message,
        ];

        $this->render($template);
    }
}
