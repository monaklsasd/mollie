<?php

use App\Controller\Legacy\LegacyBridgeController;
use App\Entity\ExceptionalTransactions\Suspension;
use App\Export\TransactionCsvExporter;
use App\Repository\ExceptionalTransactions\SuspensionRepository;
use App\Repository\UserRepository;
use Bank\Batch\SepaBatchGenerator;
use ExceptionalTransactions\TransactionSuspender;
use Orm\Repositories\BanktransactionRegistrationRepository;
use Orm\Repositories\BanktransactionRepository;
use Orm\Repositories\MessageRepository;
use Symfony\Component\Security\Core\Authorization\AuthorizationCheckerInterface;

/**
 * Controller_Lists offers ways of manipulating lists of Transaction Registrations.
 * Like, unknown iDEAL transactions or non-iDEAL transactions.
 *
 * @author Mathieu Kooiman <mathieu@mollie.nl>
 */
class Controller_Lists extends Controller_MbsBase
{
    /** @var SepaBatchGenerator */
    protected $sepa_batch_generator;

    /** @var MessageRepository */
    private $message_repository;

    /** @var BanktransactionRegistrationRepository */
    private $registration_repository;

    /** @var SuspensionRepository */
    private $suspension_repository;

    /** @var BanktransactionRepository */
    private $banktransaction_repository;

    /** @var TransactionSuspender */
    private $transaction_suspender;

    /** @var TransactionCsvExporter */
    private $transaction_csv_exporter;

    public function __construct(
        sql_db $db,
        Mollie_Logger $logger,
        Mollie_FlashMessenger $flash_messenger,
        UserRepository $user_repository,
        LegacyBridgeController $legacy_bridge_controller,
        AuthorizationCheckerInterface $authorization_checker,
        SepaBatchGenerator $sepa_batch_generator,
        MessageRepository $message_repository,
        BanktransactionRegistrationRepository $registration_repository,
        SuspensionRepository $suspension_repository,
        BanktransactionRepository $banktransaction_repository,
        TransactionSuspender $transaction_suspender,
        TransactionCsvExporter $transaction_csv_exporter
    ) {
        parent::__construct($db, $logger, $flash_messenger, $user_repository, $authorization_checker, $legacy_bridge_controller);

        $this->sepa_batch_generator       = $sepa_batch_generator;
        $this->message_repository         = $message_repository;
        $this->registration_repository    = $registration_repository;
        $this->suspension_repository      = $suspension_repository;
        $this->banktransaction_repository = $banktransaction_repository;
        $this->transaction_suspender      = $transaction_suspender;
        $this->transaction_csv_exporter   = $transaction_csv_exporter;
    }

    /**
     * Defines the basic privileges required for actions. Handled in preAction
     */
    public function getRequiredPrivilegesForAction($action)
    {
        $action_privilege_mapping = [
            'overview'                  => ['lists.view'],
            'unregistertransaction'     => ['lists.change'],
            'generate'                  => ['lists.refund'],
            'export'                    => ['lists.view'],
            'listsuspendedtransactions' => ['lists.view'],
            'suspend'                   => ['lists.change'],
            'unsuspend'                 => ['lists.change'],
        ];

        return isset($action_privilege_mapping[strtolower($action)]) ?
            $action_privilege_mapping[$action] :
            [];
    }

    /**
     * Retrieve the "TYPE" argument from the REQUEST DATA or return $default_value if it's not there.
     *
     * @param null $default_value
     *
     * @return string|null
     */
    protected function _getRegistrationTypeFromRequest($default_value = null)
    {
        $selected_type = isset($_REQUEST['type']) && in_array($_REQUEST['type'], array_keys(Model_TransactionRegistration::getAllRegistrationTypes())) ?
            (string)$_REQUEST['type'] : $default_value;

        return $selected_type;
    }

    protected function _getRegistrationTypesWithCount()
    {
        $supported_types_raw = Model_TransactionRegistration::getAllRegistrationTypes();

        $count_mapping = $this->registration_repository->getRegistrationCountPerType();

        $supported_types = [];

        foreach ($supported_types_raw as $type => $desc) {
            $supported_types[$type] = [
                'desc'  => $desc,
                'count' => $count_mapping[$type] ?? 0,
            ];
        }

        return $supported_types;
    }

    /**
     * Show a list of the transaction we've marked as non-ideal payments, ready to be returned to the issuer.
     */
    public function overviewAction()
    {
        $message_types = [
            'reg_removed' => "The transaction has been removed from the list.",
        ];

        /* Process input */
        $show_msg_type = isset($_REQUEST['msg'], $message_types[$_REQUEST['msg']]) ? $_REQUEST['msg'] : null;
        $message       = $message_types[$show_msg_type] ?? null;
        $messages      = $this->message_repository->findUnreadByType('exceptional_transactions');
        $selected_type = $this->_getRegistrationTypeFromRequest(Model_TransactionRegistration::REGISTRATION_FAILURE_IDEAL);

        /* Collect data */
        $transactions    = $this->banktransaction_repository->findRegisteredTransactions($selected_type, false);
        $transactions    = $this->filterOutSuspendedTransactions($transactions);
        $supported_types = $this->_getRegistrationTypesWithCount();

        /* Render */
        $template = [
            'view_template'                => 'lists/overview.tpl.php',
            'title'                        => 'Exceptional transactions overview',
            'transactions'                 => $transactions,
            'message'                      => $message,
            'messages'                     => $messages,
            'selected_type'                => $selected_type,
            'supported_types'              => $supported_types,
            'always_show_account'          => true,
            'suspended_transactions_count' => $this->suspension_repository->count([]),
            'user_repository'              => $this->user_repository, // temp
            'actions'                      => [
                'generate'              => 'Return payments',
                'suspend'               => 'Suspend',
                'unregisterTransaction' => 'Remove from list',
            ],
        ];

        $this->render($template);
    }

    public function listSuspendedTransactionsAction(): void
    {
        $suspended_transaction_ids = $this->suspension_repository->findSuspendedBankTransactionIds();

        if (count($suspended_transaction_ids) > 0) {
            $transactions = $this->banktransaction_repository->findByIds($suspended_transaction_ids);
        } else {
            $transactions = new Model_Set([]);
        }

        $transactions->filter(function (Model_Banktransaction $banktransaction) {
            return $banktransaction->isHandled() === false;
        });

        $messages        = $this->message_repository->findUnreadByType('exceptional_transactions');
        $supported_types = $this->_getRegistrationTypesWithCount();

        $this->render([
            'view_template'                => 'lists/overview.tpl.php',
            'title'                        => 'Suspended transactions',
            'transactions'                 => $transactions,
            'message'                      => null,
            'messages'                     => $messages,
            'selected_type'                => null,
            'supported_types'              => $supported_types,
            'always_show_account'          => true,
            'suspended_transactions_count' => $this->suspension_repository->count([]),
            'user_repository'              => $this->user_repository, // temp
            'actions'                      => [
                'unsuspend'             => 'Unsuspend',
                'unregisterTransaction' => 'Remove from list',
            ],
        ]);
    }

    /**
     * Remove a transaction from the non-ideal payment list.
     */
    public function unregisterTransactionAction()
    {
        $transaction_ids = $this->getTransactionIdsFromPost();
        $type            = $this->_getRegistrationTypeFromRequest(null);

        if (!is_array($transaction_ids)) {
            $this->redirect($this->url('lists', 'overview'));

            return;
        }

        foreach ($transaction_ids as $id) {
            $registration_obj = new Model_TransactionRegistration($this->_db);

            $criteria = [
                'handled'        => '0',
                'transaction_id' => $id,
            ];

            if ($type !== null) {
                $criteria['registration_type'] = $type;
            }

            $registration_obj->loadBy($criteria);

            $this->transaction_suspender->unsuspendTransaction(
                $registration_obj->banktransaction,
                $this->_getCurrentUser()
            );

            if ($registration_obj->stored()) {
                $registration_obj->delete();
            }
        }

        $this->redirect($this->url('lists', 'overview', ['msg' => 'reg_removed', 'type' => $type]));
    }

    /**
     * @return array|null
     */
    private function getTransactionIdsFromPost()
    {
        return isset($_POST['transaction_id'])
            ? filter_var($_POST['transaction_id'], FILTER_VALIDATE_INT, FILTER_REQUIRE_ARRAY)
            : null;
    }

    public function suspendAction(): void
    {
        $transaction_ids = $this->getTransactionIdsFromPost();
        $type            = $this->_getRegistrationTypeFromRequest(null);
        $reason          = isset($_POST['message']) ? trim(filter_var($_POST['message'], FILTER_SANITIZE_STRING)) : "";

        if (empty($transaction_ids)) {
            $this->addError("No transactions selected");
        }

        if (empty($reason)) {
            $this->addWarning("Transactions are being put on hold without any message");
        }

        if ($this->hasErrors()) {
            $this->redirect($this->url('lists', 'overview', ['type' => $type]));

            return;
        }

        $transactions = $this->banktransaction_repository->findByIds($transaction_ids);

        foreach ($transactions as $transaction) {
            $this->transaction_suspender->putTransactionOnHold($transaction, $this->_getCurrentUser(), $reason);
        }

        $this->addSuccess(sprintf("%d transaction(s) put on hold", $transactions->count()));

        $this->redirect($this->url('lists', 'overview', ['type' => $type]));
    }

    public function unsuspendAction(): void
    {
        $transaction_ids = $this->getTransactionIdsFromPost();

        if (empty($transaction_ids)) {
            $this->addError("No transactions selected");
        }

        if ($this->hasErrors()) {
            $this->redirect($this->url('lists', 'listSuspendedTransactions'));

            return;
        }

        $transactions = $this->banktransaction_repository->findByIds($transaction_ids);

        foreach ($transactions as $transaction) {
            $this->transaction_suspender->unsuspendTransaction($transaction, $this->_getCurrentUser());
        }

        $this->addSuccess(sprintf("%d transaction(s) are put back", $transactions->count()));

        $this->redirect($this->url('lists', 'listSuspendedTransactions'));
    }

    /**
     * Take the currently selected transactions and turn them into payment batches.
     */
    public function generateAction()
    {
        $transaction_ids = $this->getTransactionIdsFromPost();
        $type            = $this->_getRegistrationTypeFromRequest(null);
        $message         = isset($_POST['message']) ? trim(filter_var($_POST['message'], FILTER_SANITIZE_STRING)) : "";
        $batch_message   = isset($_POST['batch_message']) ? trim(filter_var($_POST['batch_message'], FILTER_SANITIZE_STRING)) : "";

        if (!is_array($transaction_ids)) {
            $this->addError("No transactions selected.");
        }

        if ($type === null) {
            $this->addError("No type chosen.");
        }

        if (empty($message)) {
            $this->addError("No statement message entered.");
        }

        if (empty($batch_message)) {
            $this->addError("No batch message entered.");
        }

        if ($this->hasErrors()) {
            $this->redirect($this->url('lists', 'overview', ['type' => $type]));

            return;
        }

        $transactions = $this->banktransaction_repository->findByIds($transaction_ids);
        $transactions = $this->filterOutSuspendedTransactions($transactions);

        if (!count($transactions)) {
            $this->addError("Invalid transactions.");
            $this->redirect($this->url('lists', 'overview', ['type' => $type]));

            return;
        }

        try {
            $warnings = [];
            $this->sepa_batch_generator->setCurrentUser($this->_getCurrentUser());
            $batch_files = $this->sepa_batch_generator->createRefundBatchesForTransactions($transactions, $batch_message, $message, $warnings);

            foreach ($warnings as $warning) {
                $this->addWarning($warning);
            }
            $this->addSuccess(sprintf('%d files created.', count($batch_files)));
        } catch (\BankAccounts\Exceptions\BankAccountNotFoundException $e) {
            $this->addError('Unknown bank account.');
        } catch (\Bank\Batch\Exception\BatchSaveException $e) {
            $this->addError($e->getMessage());
        }

        $this->redirect($this->url('lists', 'overview', ['type' => $type]));
    }

    /**
     * Download CSV export of all transactions
     *
     * @throws Model_Exception
     * @throws \BankAccounts\Exceptions\BankAccountNotFoundException
     */
    public function exportAction()
    {
        $selected_type = $this->_getRegistrationTypeFromRequest(Model_TransactionRegistration::REGISTRATION_FAILURE_IDEAL);
        $transactions  = $this->banktransaction_repository->findRegisteredTransactions($selected_type, false);

        $csv_string_output = $this->transaction_csv_exporter->exportAsString($transactions);

        $this->setHttpHeader('Content-Type', 'text/csv; charset=windows-1252');
        $this->setHttpHeader('Content-Disposition', 'attachment; filename="export-' . time() . '.csv"');
        echo \Core\Strings::iconv($csv_string_output, "UTF-8", "Windows-1252");
    }

    /**
     * @param Model_Banktransaction[] $transactions
     *
     * @return Model_Banktransaction[]
     */
    private function filterOutSuspendedTransactions(Model_Set $transactions): Model_Set
    {
        $transaction_suspensions   = $this->suspension_repository->findByBankTransactions($transactions);
        $suspended_transaction_ids = $transaction_suspensions->map(function (Suspension $suspension) {
            return $suspension->getBankTransactionId();
        });
        $suspended_transaction_ids = $suspended_transaction_ids->toArray();

        $non_suspended_transactions = $transactions->getClone()->filter(
            function (Model_Banktransaction $transaction) use ($suspended_transaction_ids) {
                return !in_array($transaction->id, $suspended_transaction_ids);
            }
        );

        return $non_suspended_transactions;
    }
}
