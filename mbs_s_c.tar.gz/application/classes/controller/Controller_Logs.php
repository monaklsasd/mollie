<?php

use App\Entity\User;

/**
 * View logs
 *
 * @author Mathieu Kooiman <mathieu@mollie.nl>
 * @copyright Copyright (C), Mollie B.V.
 */
class Controller_Logs extends Controller_MbsBase
{
    public function getRequiredPrivilegesForAction($action)
    {
        $action_privilege_mapping = [
            'default' => [
                'logs.view',
            ],
        ];

        return $action_privilege_mapping[$action] ?? [];
    }

    public function defaultAction()
    {
        $selected_types = [
            Model_Log::TYPE_ERROR,
            Model_Log::TYPE_INFO,
            Model_Log::TYPE_WARN,
        ];

        $search_options = null;

        if (isset($_GET['type']) && is_array($_GET['type'])) {
            $selected_types = [];

            foreach ($_GET['type'] as $type) {
                if (in_array($type, Model_Log::KNOWN_TYPES)) {
                    $selected_types[] = $type;
                }
            }

            $search_options['type'] = ['IN', $selected_types];
        }

        $log_obj     = new Model_Log($this->_db);
        $log_entries = $log_obj->findAll($search_options, 'ORDER BY id DESC limit 150');

        /** @var User $user */
        foreach ($this->user_repository->findAll() as $user) {
            $users[$user->getId()] = $user->getEmail();
        }

        $template_data = [
            'users'          => $users,
            'log_entries'    => $log_entries,
            'view_template'  => 'logs/overview.tpl.php',
            'log_types'      => Model_Log::KNOWN_TYPES,
            'selected_types' => $selected_types,
        ];

        $this->render($template_data);
    }
}
