<?php

class Controller_Default extends Controller_MbsBase
{
    protected $_user;
}
