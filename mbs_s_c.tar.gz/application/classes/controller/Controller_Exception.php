<?php

class Controller_Exception extends Mollie_Exception
{
}
