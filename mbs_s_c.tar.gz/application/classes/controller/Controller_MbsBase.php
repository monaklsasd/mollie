<?php

class Controller_MbsBase extends Controller_Base
{
    public function defaultTemplateData()
    {
        $default = parent::defaultTemplateData();

        $default['main-menu'] = [];

        /**
         * Changes made here should also be done in `templates/common/navbar.html.twig`.
         */
        $all_items = [
            ['label' => 'Dashboard',                'url' => $this->url('dashboard', 'overview'),               'privilege' => 'dashboard.view',    'controller' => 'dashboard'],
            ['label' => 'Bank accounts',            'url' => $this->url('bankaccount', 'overview'),             'privilege' => 'bankaccounts.view', 'controller' => 'bankaccount'],
            ['label' => 'Payment orders',           'url' => $this->url('batches', 'overview'),                 'privilege' => 'batches.view',      'controller' => 'batches'],
            ['label' => 'Fees',                     'url' => $this->url('escrowfees', 'overview'),              'privilege' => 'batches.view',      'controller' => 'escrowfees'],
            ['label' => 'Exceptional transactions', 'url' => $this->url('lists', 'overview'),                   'privilege' => 'lists.view',        'controller' => 'lists'],
            ['label' => 'Process',                  'url' => $this->symfony_router->generate('process'),                  'privilege' => 'process.view',      'controller' => null],
            ['label' => 'Logs',                     'url' => $this->url('logs', 'default'),                     'privilege' => 'logs.view',         'controller' => 'logs'],
            ['label' => 'Batch signing keys',       'url' => $this->symfony_router->generate('batch_signing_keys_list'),  'privilege' => 'batch.signing',     'controller' => null],
            ['label' => 'Batch signing users',      'url' => $this->symfony_router->generate('batch_signing_users_list'), 'privilege' => 'users.manage',      'controller' => null],
        ];

        foreach ($all_items as $item) {
            if ($this->userHasPrivileges($item['privilege'])) {
                $default['main-menu'][] = $item;
            }
        }

        return $default;
    }

    /**
     * Get a model mapper.
     *
     * @param string $classname
     * @codeCoverageIgnore
     *
     * @return Model_Base|Model_ORM
     */
    protected function _getMapper($classname)
    {
        return new $classname($this->_db);
    }

    /**
     * Validate the form token. Wrapped in a separate function so that it can be mocked.
     *
     * @codeCoverageIgnore
     *
     * @return bool
     */
    public function validateFormToken()
    {
        return validate_form_token();
    }
}
