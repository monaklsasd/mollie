<?php

class Controller_API_Exception extends Exception
{
}
