<?php

use App\Controller\Legacy\LegacyBridgeController;
use App\Repository\UserRepository;
use Mollie\BankingFiles\Batch\Exception\ReaderException;
use Mollie\BankingFiles\Batch\ReaderFactory;
use Mollie\Xml\Exception\SignatureMismatchException;
use Mollie\Xml\Signature\DocumentVerifier;
use Psr\Log\LoggerAwareInterface;
use Psr\Log\LoggerAwareTrait;
use Psr\Log\NullLogger;
use Symfony\Component\Security\Core\Authorization\AuthorizationCheckerInterface;

/**
 * Uploads batches. Verifies keys. The works.
 */
class Controller_Api_Paymentbatches extends Controller_Base implements LoggerAwareInterface
{
    use LoggerAwareTrait;

    public const BATCH_SUCCESSFULLY_PERSISTED_MSG = 'OK';

    public const BATCH_ALREADY_PERSISTED_MSG = 'ALREADY RECEIVED';

    /** @var Config_Mollie */
    private $mollie_config;

    /** @var ReaderFactory */
    private $batch_reader_factory;

    /** @var DocumentVerifier */
    private $document_verifier;

    public function preAction($action)
    {
        return true; // No Login required.
    }

    public function __construct(
        sql_db $db,
        Mollie_Logger $logger,
        Mollie_FlashMessenger $flash_messenger,
        UserRepository $user_repository,
        LegacyBridgeController $legacy_bridge_controller,
        AuthorizationCheckerInterface $authorization_checker,
        Config_Mollie $mollie_config,
        ReaderFactory $batch_reader_factory,
        DocumentVerifier $document_verifier
    ) {
        parent::__construct($db, $logger, $flash_messenger, $user_repository, $authorization_checker, $legacy_bridge_controller);

        $this->mollie_config        = $mollie_config;
        $this->batch_reader_factory = $batch_reader_factory;
        $this->document_verifier    = $document_verifier;
        $this->logger               = new NullLogger();
    }

    /**
     * Requires JSON data wrapped in XMLSEC
     */
    public function uploadPaymentBatchAction()
    {
        $signed_xml_contents = $this->_getHttpPostBody();
        $rsa_key             = $this->mollie_config->getPublicRsaKey();

        try {
            $raw_xml_data = $this->document_verifier->extractVerifiedXmlContents($rsa_key, $signed_xml_contents);
        } catch (SignatureMismatchException $e) {
            throw new Controller_API_Exception("The given document is incorrect.", 0, $e);
        } catch (Mollie_Testing_Exception $e) {
            throw $e;
        } catch (Exception $e) {
            $this->setHttpStatus(self::HTTP_INTERNAL_SERVER_ERROR);

            apm_log_exception($e, E_ERROR);
            echo "SYSTEMERROR: {$e->getMessage()}";

            return;
        }

        $paymentbatch_data = unserialize(html_entity_decode($raw_xml_data));
        $required_keys     = ['description', 'contents', 'type'];

        if (!is_array($paymentbatch_data)) {
            throw new Controller_API_Exception("The given data is not in the expected serialized PHP format");
        }

        if (count(array_diff($required_keys, array_keys($paymentbatch_data)))) {
            throw new Controller_API_Exception("Given JSON data does not have required fields");
        }

        $paymentbatch_data['contents'] = html_entity_decode($paymentbatch_data['contents']);

        $payment_batch = new Model_BankPaymentBatch($this->_db);

        try {
            $batch_reader = $this->batch_reader_factory->createReaderFromType(
                $paymentbatch_data['type'],
                $paymentbatch_data['contents']
            );

            $payment_batch->initFromTypeAndContents(
                $batch_reader,
                $paymentbatch_data['type'],
                $paymentbatch_data['contents'],
                $this->logger
            );
        } catch (ReaderException $e) {
            throw new Controller_API_Exception("Could not save payment batch to database", 0, $e);
        }

        $payment_batch->description = $paymentbatch_data['description'];
        $payment_batch->created_by  = Model_BankPaymentBatch::SYSTEM_USER;

        try {
            $payment_batch->saveOrDie();
        } catch (Mollie_Database_Exception_Query_DuplicateEntry  $ignored_exception) {
            echo self::BATCH_ALREADY_PERSISTED_MSG;

            return;
        } catch (Model_Exception_Save $e) {
            $this->_logger->log_error(
                Mollie_Logger::LOG_CATEGORY_WEBSITE,
                "Unable to save payment batch",
                sprintf(
                    "Validation errors: %s\nIP: %s\n",
                    var_export($payment_batch->getValidationErrors(), true),
                    $_SERVER['REMOTE_ADDR']
                )
            );

            throw new Controller_API_Exception("Could not save payment batch to database");
        }

        $this->_logger->log_info(
            Mollie_Logger::LOG_CATEGORY_WEBSITE,
            "Saved new payment batch",
            sprintf(
                "IP=%s, TYPE=%s, NUMTRX=%d, TRXAMT=%s",
                $_SERVER['REMOTE_ADDR'],
                $payment_batch->type,
                $payment_batch->num_transactions,
                $payment_batch->total_amount
            )
        );

        echo self::BATCH_SUCCESSFULLY_PERSISTED_MSG;
    }

    public function dispatchActionName($action)
    {
        try {
            return parent::dispatchActionName($action);
        } catch (Controller_API_Exception $e) {
            $this->setHttpStatus(self::HTTP_INTERNAL_SERVER_ERROR);
            apm_log_exception($e, E_ERROR);
            echo "API exception: {$e->getMessage()}";
        } catch (Exception $e) {
            $this->setHttpStatus(self::HTTP_INTERNAL_SERVER_ERROR);
            apm_log_exception($e, E_ERROR);
            echo "System error: {$e->getMessage()}";

            throw $e;
        }
    }
}
