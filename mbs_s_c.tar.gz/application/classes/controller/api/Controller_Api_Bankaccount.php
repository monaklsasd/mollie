<?php

use App\Controller\Legacy\LegacyBridgeController;
use App\Repository\UserRepository;
use BankAccounts\BankAccountRepository;
use Mollie\Xml\Exception\SigningFailedException;
use Mollie\Xml\Signature\DocumentVerifier;
use Symfony\Component\Security\Core\Authorization\AuthorizationCheckerInterface;

class Controller_Api_Bankaccount extends Controller_Base
{
    /** @var Config_Mbs */
    private $mbs_config;

    /** @var BankAccountRepository */
    private $bank_account_repository;

    /** @var DocumentVerifier */
    private $document_verifier;

    public function preAction($action)
    {
        return true; // No Login required.
    }

    public function __construct(
        sql_db $db,
        Mollie_Logger $logger,
        Mollie_FlashMessenger $flash_messenger,
        UserRepository $user_repository,
        AuthorizationCheckerInterface $authorization_checker,
        LegacyBridgeController $legacy_bridge_controller,
        Config_Mbs $mbs_config,
        BankAccountRepository $bank_account_repository,
        DocumentVerifier $document_verifier
    ) {
        parent::__construct($db, $logger, $flash_messenger, $user_repository, $authorization_checker, $legacy_bridge_controller);

        $this->mbs_config              = $mbs_config;
        $this->bank_account_repository = $bank_account_repository;
        $this->document_verifier       = $document_verifier;
    }

    /**
     * Returns IBANs of Mollie's internal bank accounts.
     */
    public function getBankAccountIbansAction(): void
    {
        $ibans    = $this->bank_account_repository->getAllMbsIbans();
        $contents = serialize($ibans);

        $this->setHttpHeader("Content-Type", "text/xml; charset=UTF-8");

        $rsa_key = $this->mbs_config->getPrivateRsaKey();

        try {
            echo $this->document_verifier->createSignedXml($rsa_key, $contents);
        } catch (SigningFailedException  $e) {
            apm_log_exception($e);

            echo "ERROR; XML signing failed";
        }
    }
}
