<?php

class Controller_Escrowfees extends Controller_MbsBase
{
    private const ITEMS_PER_PAGE = 100;

    public function getRequiredPrivilegesForAction($action)
    {
        return ['fees.view'];
    }

    public function overviewAction()
    {
        $fees_obj = new Model_Escrow_Paidfees($this->_db);

        $pagination = new \Core\Pagination\Paginator();
        $pagination->setCurrentPage(filter_input(INPUT_GET, $pagination->getUrlKey(), FILTER_VALIDATE_INT));
        $pagination->setItemsPerPage(self::ITEMS_PER_PAGE);
        $pagination->setTargetLink($_SERVER['REQUEST_URI']);

        $fees = $fees_obj->findAllPaginated($pagination->getItemsPerPage(), $pagination->getCurrentOffset(), $found_rows);

        $pagination->setItemTotal($found_rows);

        $template = [
            'view_template' => 'escrow/overview.tpl.php',
            'pagination'    => $pagination,
            'fees'          => $fees,
        ];

        $this->render($template);
    }
}
