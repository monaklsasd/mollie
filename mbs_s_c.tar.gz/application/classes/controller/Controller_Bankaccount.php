<?php

use App\Controller\Legacy\LegacyBridgeController;
use App\Export\TransactionCsvExporter;
use App\Repository\UserRepository;
use BankAccounts\BankAccount;
use BankAccounts\BankAccountRepository;
use BankAccounts\Smp\AbstractSmpBankAccount;
use Core\Pagination\Paginator;
use Core\Strings;
use Core\Time\TimeZones;
use Helper\DateTime\Utc;
use Mollie\ObjectStorage\BucketInterface;
use Mollie\ObjectStorage\Exception\ObjectNotFoundException;
use Mollie\ObjectStorage\NameValidation;
use Orm\ModelFactory;
use Orm\Repositories\BankPaymentBatchRepository;
use Orm\Repositories\BankstatementRepository;
use Orm\Repositories\BanktransactionRepository;
use Psr\Log\LoggerAwareInterface;
use Psr\Log\LoggerAwareTrait;
use Psr\Log\NullLogger;
use Symfony\Component\Security\Core\Authorization\AuthorizationCheckerInterface;
use TransactionHandlers\TransactionHandlerCoordinator;

class Controller_Bankaccount extends Controller_MbsBase implements LoggerAwareInterface
{
    use Utc;
    use LoggerAwareTrait;

    public const TRANSACTION_AMOUNT_EXACT  = "exact";
    public const TRANSACTION_AMOUNT_CREDIT = "credit";
    public const TRANSACTION_AMOUNT_DEBIT  = "debit";

    /** @var \Orm\ModelFactory */
    protected $model_factory;

    /** @var \BankAccounts\BankAccountRepository */
    protected $bank_account_repository;

    /** @var BankstatementRepository */
    protected $statement_repository;

    /** @var BanktransactionRepository */
    protected $transaction_repository;

    /** @var BankPaymentBatchRepository */
    protected $batch_repository;

    /** @var TransactionHandlerCoordinator */
    protected $transaction_handler_coordinator;

    /** @var Worker_AccountView_ExportBankStatements */
    private $bank_statement_accountview_exporter;

    /** @var TransactionCsvExporter */
    private $transaction_csv_exporter;
    /** @var BucketInterface */
    private $bucket;

    public function __construct(
        sql_db $db,
        Mollie_Logger $logger,
        Mollie_FlashMessenger $flash_messenger,
        UserRepository $user_repository,
        LegacyBridgeController $legacy_bridge_controller,
        AuthorizationCheckerInterface $authorization_checker,
        ModelFactory $model_factory,
        BankAccountRepository $bank_account_repository,
        TransactionHandlerCoordinator $transaction_handler_coordinator,
        BankstatementRepository $statement_repository,
        BanktransactionRepository $transaction_repository,
        BankPaymentBatchRepository $batch_repository,
        Worker_AccountView_ExportBankStatements $bank_statement_accountview_exporter,
        TransactionCsvExporter $transaction_csv_exporter,
        BucketInterface $bucket
    ) {
        parent::__construct($db, $logger, $flash_messenger, $user_repository, $authorization_checker, $legacy_bridge_controller);

        $this->model_factory                       = $model_factory;
        $this->bank_account_repository             = $bank_account_repository;
        $this->transaction_handler_coordinator     = $transaction_handler_coordinator;
        $this->statement_repository                = $statement_repository;
        $this->transaction_repository              = $transaction_repository;
        $this->batch_repository                    = $batch_repository;
        $this->bank_statement_accountview_exporter = $bank_statement_accountview_exporter;
        $this->transaction_csv_exporter            = $transaction_csv_exporter;
        $this->bucket                              = $bucket;
        $this->logger                              = new NullLogger();
    }

    /**
     * Defines the basic privileges required for actions. Handled in preAction
     */
    public function getRequiredPrivilegesForAction($action)
    {
        $privileges = [];

        if ($action === "manuallyqueuestatementinaccountview") {
            $privileges[] = "statements.requeue";
        }

        if ($action === "manuallyrerunnotificationhandler") {
            $privileges[] = "statements.rerun";
        }

        // All the other actions require this privilege.
        return array_merge($privileges, [
            "bankaccounts.view",
        ]);
    }

    /*
     * Actual actions.
     */

    public function addTransactionCommentAction()
    {
        $referer        = filter_input(INPUT_POST, 'referer', FILTER_SANITIZE_STRING);
        $transaction_id = filter_input(INPUT_POST, 'transaction_id', FILTER_VALIDATE_INT);
        $comment        = filter_input(INPUT_POST, 'comment', FILTER_SANITIZE_STRING);

        $transaction = $this->transaction_repository->findById($transaction_id);

        if ($transaction === null) {
            $this->flash_messenger->addMessage("No transaction found with ID #{$transaction_id}.", Helper_View_MessageBox::ERROR_BOX);

            return $this->redirect($referer);
        }

        if (!Helper_Csrf::validate($_POST["_formtoken"], "comment")) {
            $this->flash_messenger->addMessage("The form has expired. Please try again.", Helper_View_MessageBox::ERROR_BOX);

            return $this->redirect($referer);
        }

        $transaction->addComment($comment, $this->_getCurrentUser());

        $this->flash_messenger->addMessage("Comment added.", Helper_View_MessageBox::SUCCESS_BOX);

        return $this->redirect($referer);
    }

    public function balanceAction()
    {
        $account_id = isset($_GET['bank_account_id']) ? (int)$_GET['bank_account_id'] : null;
        $start_date = isset($_GET['start_date']) && !empty($_GET['start_date']) ? self::toDateTime($_GET['start_date'], 'Y-m-d') : null;
        $end_date   = isset($_GET['end_date'])   && !empty($_GET['end_date']) ? self::toDateTime($_GET['end_date'], 'Y-m-d') : null;

        $selected_bank_account = $this->bank_account_repository->getById($account_id);

        if (!$this->hasBankAccountPrivilege($selected_bank_account)) {
            $this->logger->warning(sprintf(
                'User tried to access restricted action, User needed: bankaccounts.%s',
                $selected_bank_account::getIban()
            ));

            $this->_showInsufficientPrivilegesPage();

            return;
        }

        $statements = $this->statement_repository->getByBankAccountAndDates(
            $this->bank_account_repository->getById($account_id),
            $start_date,
            $end_date
        );

        $bank_accounts = $this->bank_account_repository->getAllBankAccounts();

        // Sort for display
        usort($bank_accounts, function (BankAccount $a, BankAccount $b) {
            // show old accounts last.
            if (0 !== $diff = $a::isOldAccount() <=> $b::isOldAccount()) {
                return $diff;
            }

            // show Mollie accounts first.
            if (0 !== $diff = $a instanceof AbstractSmpBankAccount <=> $b instanceof AbstractSmpBankAccount) {
                return $diff;
            }

            return $a::getDescription() <=> $b::getDescription();
        });

        // Remove bankaccounts from list that user is not allowed to view.
        $bank_accounts = array_filter($bank_accounts, function (BankAccount $bank_account): bool {
            return $this->hasBankAccountPrivilege($bank_account);
        });

        $template = [
            'view_template'         => 'bankaccount/balance.tpl.php',
            'bank_accounts'         => $bank_accounts,
            'statements'            => $statements,
            'selected_bank_account' => $selected_bank_account,
            'start_date'            => $start_date,
            'end_date'              => $end_date,
        ];

        $this->render($template);
    }

    public function downloadImportFileAction(): void
    {
        $statement_id = filter_input(INPUT_POST, 'statement_id', FILTER_VALIDATE_INT);

        $statement = new Model_Bankstatement($this->_db, $statement_id);

        if (!$statement->stored()) {
            $this->flash_messenger->addMessage("No bank statement found with ID #{$statement_id}.", Helper_View_MessageBox::ERROR_BOX);
            $this->redirectToBankAccountOverview();

            return;
        }

        $bank_account           = $statement->getBankAccount();
        $has_privilege          = $this->hasBankAccountPrivilege($bank_account);
        $has_download_privilege = $this->userHasPrivileges('download.statement.files');

        if (!$has_privilege || !$has_download_privilege) {
            $this->_logger->log_warning(
                Mollie_Logger::LOG_CATEGORY_WEBSITE,
                'User tried to access restricted action',
                'User needed: bankaccounts.' . $bank_account->getIban()
            );

            $this->_showInsufficientPrivilegesPage();

            return;
        }

        if ($statement->hasFilePath() === false) {
            throw new RuntimeException('File path not found for statement: ' . $statement_id);
        }

        $namespace = NameValidation::splitFullyQualifiedObjectName($statement->getFilePath());

        try {
            $result = $this->bucket->get(...$namespace);
        } catch (ObjectNotFoundException $e) {
            throw new RuntimeException('File not found for statement: ' . $statement_id);
        }

        $this->setHttpHeader('Content-Type', 'application/x-octet-stream');
        $this->setHttpHeader('Content-Disposition', sprintf('attachment; filename="%s"', $result->getName()));

        echo $result->getContents();
    }

    public function statementAction()
    {
        $statement_id = filter_input(INPUT_GET, "statement_id", FILTER_VALIDATE_INT);

        $statement = new Model_Bankstatement($this->_db, $statement_id);

        if (!$statement->stored()) {
            $this->flash_messenger->addMessage("No bank statement found with ID #{$statement_id}.", Helper_View_MessageBox::ERROR_BOX);
            $this->redirectToBankAccountOverview();

            return;
        }

        $bank_account  = $statement->getBankAccount();
        $has_privilege = $this->hasBankAccountPrivilege($bank_account);

        if (!$has_privilege) {
            $this->_logger->log_warning(
                Mollie_Logger::LOG_CATEGORY_WEBSITE,
                "User tried to access restricted action",
                "User needed: bankaccounts.{$bank_account->getIban()}"
            );

            $this->_showInsufficientPrivilegesPage();

            return;
        }

        $paginator = new Paginator();
        $paginator->setTargetLink($this->url("bankaccount", "statement", ["statement_id" => $statement->getPrimaryKey()]) . "#transactions");
        $paginator->setCurrentPage(filter_input(INPUT_GET, "page", FILTER_VALIDATE_INT));
        $paginator->setItemsPerPage(10);
        $paginator->setItemTotal($this->transaction_repository->countAllByStatementIds([(int)$statement->getPrimaryKey()]));

        $jobs                      = $this->transaction_handler_coordinator->getLogForStatement($statement);
        $average_handler_durations = [];

        foreach ($jobs as $job) {
            if (in_array($job->getStatus(), [\TransactionHandlers\Status::QUEUED(), \TransactionHandlers\Status::RUNNING()], false)) {
                $average_handler_durations[$job->getHandlerClassName()] = $this->transaction_handler_coordinator->getAverageDurationForJob(
                    $job->getHandlerClassName(),
                    $bank_account
                );
            }
        }
        $transactions = $this->transaction_repository->findByStatementId(
            (int)$statement->getPrimaryKey(),
            $paginator->getCurrentOffset(),
            $paginator->getItemsPerPage()
        );
        $this->render([
            'view_template'                  => 'bankaccount/statement.tpl.php',
            'statement'                      => $statement,
            'bank_account'                   => $bank_account,
            'transactions'                   => $transactions,
            'paginator'                      => $paginator,
            'can_requeue_statement'          => ($this->userHasPrivileges('statements.requeue') && !$this->isFromAnOutpaymentBankAccount($statement)),
            'can_rerun_transaction_handlers' => $this->userHasPrivileges('statements.rerun'),
            'can_download_import_file'       => $this->userHasPrivileges('download.statement.files'),
            'all_transaction_handlers'       => $bank_account::getTransactionHandlerClasses(),
            'processed_transaction_handlers' => $jobs,
            'user_repository'                => $this->user_repository,
            'average_handler_durations'      => $average_handler_durations,
        ]);
    }

    public function manuallyQueueStatementInAccountViewAction()
    {
        $referer      = filter_input(INPUT_POST, "referer", FILTER_SANITIZE_STRING);
        $statement_id = filter_input(INPUT_POST, "statement_id", FILTER_VALIDATE_INT);

        $statement = $this->statement_repository->findById($statement_id);

        if (!$statement) {
            $this->flash_messenger->addMessage("No bank statement found with ID #{$statement_id}.", Helper_View_MessageBox::ERROR_BOX);

            return $this->redirect($referer ?: '/');
        }

        if ($this->isFromAnOutpaymentBankAccount($statement)) {
            $this->flash_messenger->addMessage(
                "It is not possible to convert this statement again. This is an outpayment account.",
                Helper_View_MessageBox::ERROR_BOX
            );

            return $this->redirect($referer ?: '/');
        }

        if (!Helper_Csrf::validate($_POST["_formtoken"], "requeue")) {
            $this->flash_messenger->addMessage("The form has expired. Please try again.", Helper_View_MessageBox::ERROR_BOX);

            return $this->redirect($referer ?: '/');
        }

        $this->_logger->log_info(
            Mollie_Logger::LOG_CATEGORY_WEBSITE,
            "User requeued statement for AccountView",
            "Statement will be exported and then sent to AccountView immediately."
        );

        $this->bank_statement_accountview_exporter->setDebugMode(false);
        $queue_items = $this->bank_statement_accountview_exporter->exportStatement($statement);

        if (count($queue_items) == 0) {
            $this->flash_messenger->addMessage("Statement does not need to be sent to AccountView (no transactions).");

            return $this->redirect($referer ?: '/');
        }

        $this->flash_messenger->addMessage(
            sprintf('Statement %s has been exported to AccountView XML.', $statement->getStatementReference()),
            Helper_View_MessageBox::SUCCESS_BOX
        );

        return $this->redirect($referer ?: '/');
    }

    public function manuallyRerunTransactionHandlerAction()
    {
        $referer            = filter_input(INPUT_POST, "referer", FILTER_SANITIZE_STRING);
        $statement_id       = filter_input(INPUT_POST, "statement_id", FILTER_VALIDATE_INT);
        $handler_class_name = filter_input(INPUT_POST, "handler_class_name", FILTER_SANITIZE_STRING);

        $statement = $this->statement_repository->findById($statement_id);

        if (!$statement) {
            $this->flash_messenger->addMessage("No bank statement found with ID #{$statement_id}.", Helper_View_MessageBox::ERROR_BOX);

            return $this->redirect($referer ?: '/');
        }

        if (!Helper_Csrf::validate($_POST["_formtoken"], "reruntransactionhandler.{$handler_class_name}")) {
            $this->flash_messenger->addMessage("The form has expired. Please try again.", Helper_View_MessageBox::ERROR_BOX);

            return $this->redirect($referer ?: '/');
        }

        $this->_logger->log_info(
            Mollie_Logger::LOG_CATEGORY_WEBSITE,
            "Transaction handler scheduled to run again for statement",
            "User scheduled transaction handler {$handler_class_name} to be processed again for statement #{$statement_id}."
        );

        $this->transaction_handler_coordinator->rerunHandler($statement, $handler_class_name);

        $this->flash_messenger->addMessage(
            "Transaction handler {$handler_class_name} scheduled to run again within 1 minute.",
            Helper_View_MessageBox::SUCCESS_BOX
        );

        $this->redirect($referer);
    }

    public function notesAction()
    {
        if (!$this->isPostRequest()) {
            $this->redirectToBankAccountOverview();
        }

        $description     = trim(filter_input(INPUT_POST, 'note', FILTER_SANITIZE_STRING));
        $bank_account_id = filter_input(INPUT_POST, 'bank_account_id', FILTER_SANITIZE_NUMBER_INT);

        $note = $this->loadOrCreateBankAccountNote($bank_account_id);

        $note->description = $description;
        $note->save();

        $this->redirectToBankAccountOverview($bank_account_id);
    }

    private function redirectToBankAccountOverview(?int $bank_account_id = null)
    {
        $redirect_url = MOLLIE_HTTPS_URL . '/index.php?controller=bankaccount&action=transactions';

        if ($bank_account_id) {
            $redirect_url .= '&id=' . $bank_account_id;
        }

        $this->redirect($redirect_url);
    }

    public function transactionsAction()
    {
        $action       = trim(filter_input(INPUT_GET, 'paction', FILTER_SANITIZE_STRING));
        $statement_id = trim(filter_input(INPUT_GET, 'statement_id', FILTER_VALIDATE_INT));

        try {
            $mollie_bankaccounts  = $this->getPriviligedBankAccounts();
            $selected_bankaccount = $this->getSelectedBankAccount();
        } catch (\BankAccounts\Exceptions\BankAccountNotFoundException $e) {
            die("System error");
        }

        if ($selected_bankaccount) {
            $has_privilege = $this->hasBankAccountPrivilege($selected_bankaccount);

            if (!$has_privilege) {
                $this->_logger->log_warning(
                    Mollie_Logger::LOG_CATEGORY_WEBSITE,
                    "User tried to access restricted action",
                    "User needed: bankaccounts.{$selected_bankaccount->getIban()}"
                );

                $this->_showInsufficientPrivilegesPage();

                return;
            }
        }

        $pager_extra_data = [
            'statement_id' => $statement_id,
            "amount_type"  => self::TRANSACTION_AMOUNT_EXACT,
        ];

        if ($selected_bankaccount) {
            $pager_extra_data['id'] = $selected_bankaccount::getId();
        }

        if (!$statement_id && $action == 'search') {
            $periode_van = trim(filter_input(INPUT_GET, 'periode_van', FILTER_SANITIZE_STRING));
            $periode_tm  = trim(filter_input(INPUT_GET, 'periode_tm', FILTER_SANITIZE_STRING));

            $bankaccount_nr = trim(filter_input(INPUT_GET, 'bankaccount_nr', FILTER_SANITIZE_STRING));
            $tag            = trim(filter_input(INPUT_GET, 'tag', FILTER_SANITIZE_STRING));
            $amount_type    = trim(filter_input(INPUT_GET, 'amount_type', FILTER_SANITIZE_STRING));

            $description = trim(filter_input(INPUT_GET, 'description', FILTER_SANITIZE_STRING));

            $parent_id = trim(filter_input(INPUT_GET, 'parent_id', FILTER_VALIDATE_INT));

            try {
                $amount = \Core\Numbers::parseFloat(trim(filter_input(INPUT_GET, 'amount')));
            } catch (InvalidArgumentException $e) {
                $this->addError("Invalid amount entered.");
            }

            if ($selected_bankaccount) {
                $search_data = [
                    'bankaccounts' => [$selected_bankaccount::getId() => $selected_bankaccount],
                ];
            } else {
                $search_data = [
                    'bankaccounts' => $mollie_bankaccounts,
                ];
            }

            $include_child_transactions = filter_input(INPUT_GET, 'include_child_transactions', FILTER_VALIDATE_BOOLEAN);

            $pager_extra_data['include_child_transactions'] = $include_child_transactions;
            $pager_extra_data['paction']                    = 'search';
            $pager_extra_data['amount_type']                = $amount_type;

            // Account nr
            if (!empty($bankaccount_nr)) {
                $search_data['bankaccount_nr']      = str_replace([".", " "], "", $bankaccount_nr);
                $pager_extra_data['bankaccount_nr'] = $bankaccount_nr;
            }

            // Soort betaling
            if (!empty($tag) || $tag === "") { /* empty string means: search for no tag */
                $search_data['tags']     = $tag;
                $pager_extra_data['tag'] = $tag;
            } elseif ($tag === "0") { /* "0" means: don't add tag to filter */
                $pager_extra_data['tag'] = $tag;
            }

            // Periode
            if ($periode_van) {
                $search_data['periode_start']    = strtotime($periode_van);
                $pager_extra_data['periode_van'] = $periode_van;

                if ($periode_tm) {
                    $search_data['periode_tm']      = strtotime($periode_tm);
                    $pager_extra_data['periode_tm'] = $periode_tm;
                }
            }

            // Bedrag
            if (!empty($amount) && $amount_type === self::TRANSACTION_AMOUNT_EXACT) {
                $pager_extra_data['amount'] = $search_data['amount'] = $amount;
            } elseif ($amount_type === self::TRANSACTION_AMOUNT_CREDIT) {
                $pager_extra_data['amount'] = $search_data['amount'] = [">", 0];
            } elseif ($amount_type === self::TRANSACTION_AMOUNT_DEBIT) {
                $pager_extra_data['amount'] = $search_data['amount'] = ["<", 0];
            }

            // Omschrijving
            if ($description) {
                $search_data['description']      = $description;
                $pager_extra_data['description'] = $description;
            }

            /* Parent transaction for batches */
            if ($parent_id) {
                $search_data['parent_id']      = $parent_id;
                $pager_extra_data['parent_id'] = $parent_id;
            } elseif (!$include_child_transactions) {
                $search_data['parent_id']      = null;
                $pager_extra_data['parent_id'] = null;
            }
        } else {
            $search_data = [];

            if ($selected_bankaccount) {
                $search_data['bankaccounts'] = [$selected_bankaccount::getId() => $selected_bankaccount];
            } else {
                $search_data['bankaccounts'] = $mollie_bankaccounts;
            }

            if ($statement_id) {
                $search_data['statementimport_id']      = $statement_id;
                $pager_extra_data['statementimport_id'] = $statement_id;
            } else {
                $search_data['periode_tm']       = time();
                $search_data['periode_start']    = strtotime("-1 week");
                $pager_extra_data['periode_tm']  = date('Y-m-d', $search_data['periode_tm']);
                $pager_extra_data['periode_van'] = date('Y-m-d', $search_data['periode_start']);
            }
        }

        $search_data['ledger'] = $this->shouldShowOnlyTransactionsFromLedgerBoardedTransactions() ? true : null;

        $csv_export = filter_input(INPUT_GET, 'csvexport', FILTER_SANITIZE_STRING);

        if ($csv_export) {
            $per_page   = 0;
            $sql_offset = 0;
        } else {
            $paginator = new Paginator();
            $paginator->setCurrentPage(filter_input(INPUT_GET, "page", FILTER_VALIDATE_INT));
            $paginator->setItemsPerPage(20);
            $paginator->setItemTotal($this->transaction_repository->countBySearch($search_data));

            $per_page   = $paginator->getItemsPerPage();
            $sql_offset = $paginator->getCurrentOffset();
        }

        if (!$this->hasErrors()) {
            $transactions = $this->transaction_repository->findBySearch($search_data, $sql_offset, $per_page);
        } else {
            $transactions = new Model_Set();
        }

        if ($csv_export) {
            $this->exportTransactions($transactions);

            return;
        }

        $note_description = '';
        $note_datestamp   = '-';

        if (!empty($selected_bankaccount)) {
            $note = $this->loadOrCreateBankAccountNote($selected_bankaccount::getId());
            $date = $note->getUpdatedAtUtc();

            $note_description = (string)$note->description;
            $note_datestamp   = ($date === null) ? '-' : $date->setTimezone(TimeZones::getDefault())->format('d-m-Y H:i:s');
        }

        if ($this->shouldShowOnlyTransactionsFromLedgerBoardedTransactions()) {
            $pager_extra_data['only_handled_by_ledger_transactions'] = '1';
        }

        $template = [
            'view_template'       => 'bankaccount/transactions.tpl.php',
            'mollie_accounts'     => $mollie_bankaccounts,
            'bank_account'        => $selected_bankaccount,
            'transactions'        => $transactions,
            'paginator'           => $paginator ?? null,
            'show_search_form'    => empty($statement_id),
            'show_statement_btn'  => !empty($statement_id),
            'statement_id'        => $statement_id,
            'search_data'         => $pager_extra_data,
            'tags'                => Model_Banktransaction::getAllTags(),
            'note_description'    => $note_description,
            'note_datestamp'      => $note_datestamp,
            'always_show_account' => $selected_bankaccount === null,
            'user_repository'     => $this->user_repository,
        ];

        return $this->render($template);
    }

    private function shouldShowOnlyTransactionsFromLedgerBoardedTransactions(): bool
    {
        $input_value = $_GET['only_handled_by_ledger_transactions'] ?? null;

        return (int)$input_value === 1;
    }

    private function loadOrCreateBankAccountNote(int $bank_account_id): Model_BankAccount_Note
    {
        $note = $this->model_factory->loadBy(Model_BankAccount_Note::class, ['bank_account_id' => $bank_account_id]);

        if ($note === null) {
            $note                  = $this->model_factory->create(Model_BankAccount_Note::class);
            $note->bank_account_id = $bank_account_id;
        }

        return $note;
    }

    /**
     * @return BankAccount[]
     */
    private function getPriviligedBankAccounts(): array
    {
        $mollie_bank_accounts = $this->bank_account_repository->getAllBankAccounts();

        $allowed_accounts = [];

        foreach ($mollie_bank_accounts as $key => $bank_account) {
            if (!$this->hasBankAccountPrivilege($bank_account)) {
                continue;
            }

            $allowed_accounts[$bank_account::getId()] = $bank_account;
        }

        return $allowed_accounts;
    }

    /**
     * @throws \BankAccounts\Exceptions\BankAccountNotFoundException
     */
    private function getSelectedBankAccount(): ?BankAccount
    {
        $bankaccount_id = trim(filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT));

        if (!$bankaccount_id) {
            return null;
        }

        return $this->bank_account_repository->getById($bankaccount_id);
    }

    private function hasBankAccountPrivilege(BankAccount $bank_account): bool
    {
        $privilege_name = 'bankaccounts.' . $bank_account::getIban();

        if ($this->userHasPrivileges($privilege_name)) {
            return true;
        }

        return false;
    }

    /**
     * @param Model_Banktransaction[]|Model_Set $transactions
     */
    protected function exportTransactions(Model_Set $transactions)
    {
        $csv_string_output = $this->transaction_csv_exporter->exportAsString($transactions);

        $this->setHttpHeader('Content-Type', 'text/csv; charset=windows-1252');
        $this->setHttpHeader('Content-Disposition', 'attachment; filename="export-' . time() . '.csv"');
        echo Strings::iconv($csv_string_output, "UTF-8", "Windows-1252");
    }

    public function transactionAction()
    {
        $transaction_id = filter_input(INPUT_GET, 'transaction_id', FILTER_VALIDATE_INT);

        $transaction = $this->transaction_repository->findById($transaction_id);

        if (!$transaction) {
            $this->flash_messenger->addMessage("No transaction found with ID #{$transaction_id}.", Helper_View_MessageBox::ERROR_BOX);
            $this->redirectToBankAccountOverview();

            return;
        }

        if (!$this->hasBankAccountPrivilege($transaction->getBankAccount())) {
            $this->_logger->log_warning(
                Mollie_Logger::LOG_CATEGORY_WEBSITE,
                "User tried to access restricted action",
                "User needed: bankaccounts.{$transaction->getBankAccount()::getIban()}"
            );

            $this->_showInsufficientPrivilegesPage();

            return;
        }

        $child_transaction_paginator = new Paginator();
        $child_transaction_paginator->setTargetLink($this->url("bankaccount", "transaction", ["transaction_id" => $transaction->getPrimaryKey()]) . "#child_transactions");
        $child_transaction_paginator->setCurrentPage(filter_input(INPUT_GET, "page", FILTER_VALIDATE_INT));
        $child_transaction_paginator->setItemsPerPage(10);
        $child_transaction_paginator->setItemTotal($transaction->countChildTransactions());

        $child_transactions = $this->transaction_repository->findByParentId(
            (int)$transaction->getPrimaryKey(),
            $child_transaction_paginator->getCurrentOffset(),
            $child_transaction_paginator->getItemsPerPage()
        );

        $template = [
            "view_template"    => "bankaccount/transaction.tpl.php",
            "transaction"      => $transaction,
            "bank_account"     => $transaction->getBankAccount(),
            "transactions"     => $child_transactions ?? [],
            "paginator"        => $child_transaction_paginator ?? null,
            "user_repository"  => $this->user_repository,
            "batch_repository" => $this->batch_repository,
        ];

        $this->render($template);
    }

    public function isFromAnOutpaymentBankAccount(Model_Bankstatement $statement): bool
    {
        return $this->bank_account_repository->isOutpaymentBankAccount($statement->getBankAccountId());
    }

    /**
     * @return Model_TransactionComment
     */
    protected function getTransactionComment()
    {
        return new Model_TransactionComment($this->_db);
    }

    public function overviewAction()
    {
        $bank_accounts = [];

        foreach ($this->bank_account_repository->getAllBankAccounts() as $bank_account) {
            $account_holder = $bank_account::getAccountHolder();

            if (!$bank_account::isOldAccount()) {
                $group_name = "Bank accounts " . $bank_account::getBankName();

                // Belfius or KBC
                if ($bank_account::getBankBic() === 'GKCCBEBB' || $bank_account::getBankBic() === 'KREDBEBB' || $bank_account::getBankBic() === 'KREDFRPP') {
                    $group_name .= ' (via ABN Amro)';
                }
            } else {
                $group_name = "Closed bank accounts";
            }

            // Group all accounts by account holder.
            if (!array_key_exists($account_holder, $bank_accounts)) {
                $bank_accounts[$account_holder] = [];
            }

            // Group account holder's accounts by bank name or 'old' keyword.
            if (!array_key_exists($group_name, $bank_accounts[$account_holder])) {
                $bank_accounts[$account_holder][$group_name] = [];
            }

            $bank_accounts[$account_holder][$group_name][$bank_account::getIban()] = $bank_account;
        }

        // Sort accounts by IBAN.
        foreach ($bank_accounts as $account_holder => $grouped_bank_accounts) {
            foreach ($grouped_bank_accounts as $group_name => $bank_account_group) {
                ksort($bank_accounts[$account_holder][$group_name]);
            }
        }

        /* Render template */

        $template = [
            "user"                  => $this->_getCurrentUser(),
            "bank_accounts"         => $bank_accounts,
            "authorization_checker" => [$this, 'userHasPrivileges'],
            "view_template"         => "bankaccount/overview.tpl.php",
        ];

        $this->render($template);
    }
}
