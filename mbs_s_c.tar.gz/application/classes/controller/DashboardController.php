<?php

declare(strict_types=1);

namespace Controller;

use App\Controller\Legacy\LegacyBridgeController;
use App\Repository\UserRepository;
use BankAccounts\BankAccount;
use BankAccounts\BankAccountRepository;
use BankAccounts\Smp\AbstractSmpBankAccount;
use Controller_MbsBase;
use Core\BusinessDayDeterminer;
use Core\Localization\CurrentLocale;
use Core\Time\TimeZones;
use Helper\DateTime\Now;
use Helper\DateTime\Utc;
use Mollie_FlashMessenger;
use Mollie_Logger;
use Orm\Repositories\BankstatementRepository;
use Psr\Log\LoggerAwareInterface;
use Psr\Log\LoggerAwareTrait;
use Psr\Log\NullLogger;
use sql_db;
use Statistics\StatisticRepository;
use Symfony\Component\Security\Core\Authorization\AuthorizationCheckerInterface;
use TransactionHandlers\TransactionHandlerCoordinator;
use function usort;

class DashboardController extends Controller_MbsBase implements LoggerAwareInterface
{
    use LoggerAwareTrait;
    use Now;
    use Utc;

    /** @var BankAccountRepository */
    private $bank_account_repository;

    /** @var StatisticRepository */
    private $statistic_repository;

    /** @var BankstatementRepository */
    private $statement_repository;

    /** @var TransactionHandlerCoordinator */
    private $handler_coordinator;

    public function __construct(
        sql_db $db,
        Mollie_Logger $logger,
        Mollie_FlashMessenger $flash_messenger,
        UserRepository $user_repository,
        LegacyBridgeController $legacy_bridge_controller,
        AuthorizationCheckerInterface $authorization_checker,
        BankAccountRepository $bank_account_repository,
        StatisticRepository $statistic_repository,
        BankstatementRepository $statement_repository,
        TransactionHandlerCoordinator $handler_coordinator
    ) {
        parent::__construct($db, $logger, $flash_messenger, $user_repository, $authorization_checker, $legacy_bridge_controller);

        $this->bank_account_repository = $bank_account_repository;
        $this->statistic_repository    = $statistic_repository;
        $this->statement_repository    = $statement_repository;
        $this->handler_coordinator     = $handler_coordinator;
        $this->logger                  = new NullLogger();
    }

    public function preAction($action)
    {
        $allowed = parent::preAction($action);

        if (!$this->userHasPrivileges('dashboard.view')) {
            $this->redirect($this->url('bankaccount', 'overview'));

            return false;
        }

        return $allowed;
    }

    /**
     * Defines the basic privileges required for actions. Handled in preAction
     */
    public function getRequiredPrivilegesForAction($action)
    {
        return ['dashboard.view'];
    }

    public function defaultTemplateData()
    {
        $data = parent::defaultTemplateData();

        if ($this->flash_messenger->hasMessages()) {
            $data['message'] = $this->flash_messenger->getMessage();
        }

        return $data;
    }

    /**
     * Show all batches
     */
    public function overviewAction()
    {
        $latest_statements = [];

        foreach ($this->statement_repository->getLatestStatementPerBankAccount() as $statement) {
            $latest_statements[] = [
                $statement->getBankAccount(),
                $statement,
            ];
        }

        $expected_last_statement_date = BusinessDayDeterminer::getPreviousDutchBusinessDay(self::getNow()->setTimezone(TimeZones::amsterdam()));

        usort($latest_statements, function (array $bank_and_statement_a, array $bank_and_statement_b) {
            /** @var BankAccount $bank_account_a */
            [$bank_account_a, $statement_a] = $bank_and_statement_a;
            /** @var BankAccount $bank_account_b */
            [$bank_account_b, $statement_b] = $bank_and_statement_b;

            // show old accounts last.
            $diff = $bank_account_a::isOldAccount() <=> $bank_account_b::isOldAccount();

            if ($diff !== 0) {
                return $diff;
            }

            // show Mollie accounts first.
            $diff = $bank_account_a instanceof AbstractSmpBankAccount <=> $bank_account_b instanceof AbstractSmpBankAccount;

            if ($diff !== 0) {
                return $diff;
            }

            // group by bank
            $diff = $bank_account_a::getBankName() <=> $bank_account_b::getBankName();

            if ($diff !== 0) {
                return $diff;
            }

            return $bank_account_a::getIban() <=> $bank_account_b::getIban();
        });

        CurrentLocale::fromString('nl_NL');

        $template = [
            'view_template'                => 'dashboard/overview.tpl.php',
            'latest_statements'            => $latest_statements,
            'expected_last_statement_date' => $expected_last_statement_date,
            'transaction_statistics'       => $this->statistic_repository->getAllBetweenDates(
                BusinessDayDeterminer::getPreviousDutchBusinessDay($expected_last_statement_date),
                self::getNow()
            ),
        ];

        $this->render($template);
    }
}
