<?php

declare(strict_types=1);

namespace Controller;

use App\Controller\Legacy\LegacyBridgeController;
use App\Logger\LogCategory;
use App\Repository\UserRepository;
use App\Supplier\PaymentBatchUploader;
use Bank\Clients\Exceptions\ClientException;
use Controller_Exception;
use Controller_MbsBase;
use Core\Pagination\Paginator;
use Exception;
use Helper_Csrf;
use Helper_View_MessageBox;
use Model_BankPaymentBatch;
use Mollie\BankingFiles\Batch\BatchTransaction;
use Mollie\BankingFiles\Batch\ReaderFactory;
use Mollie\BankingFiles\Batch\Sepa\Pain008\Pain008Reader;
use Mollie\BankingFiles\Batch\Sepa\PainReaderBase;
use Mollie_FlashMessenger;
use Mollie_Logger;
use Orm\Repositories\BankPaymentBatchRepository;
use OutOfBoundsException;
use ParagonIE\HiddenString\HiddenString;
use Psr\Log\LoggerAwareInterface;
use Psr\Log\LoggerAwareTrait;
use Psr\Log\LoggerInterface;
use Psr\Log\NullLogger;
use sql_db;
use Symfony\Component\Security\Core\Authorization\AuthorizationCheckerInterface;

class BatchesController extends Controller_MbsBase implements LoggerAwareInterface
{
    use LoggerAwareTrait {
        setLogger as setLoggerBase;
    }

    private const ITEMS_PER_PAGE = 25;

    /** @var BankPaymentBatchRepository */
    private $payment_batch_repository;

    /** @var PaymentBatchUploader */
    private $payment_batch_uploader;

    public function __construct(
        sql_db $db,
        Mollie_Logger $logger,
        Mollie_FlashMessenger $flash_messenger,
        UserRepository $user_repository,
        LegacyBridgeController $legacy_bridge_controller,
        BankPaymentBatchRepository $payment_batches_repository,
        AuthorizationCheckerInterface $authorization_checker,
        PaymentBatchUploader $payment_batch_uploader
    ) {
        parent::__construct(
            $db,
            $logger,
            $flash_messenger,
            $user_repository,
            $authorization_checker,
            $legacy_bridge_controller
        );

        $this->payment_batch_repository = $payment_batches_repository;
        $this->payment_batch_uploader   = $payment_batch_uploader;
        $this->logger                   = new NullLogger();
    }

    public function setLogger(LoggerInterface $logger)
    {
        $this->setLoggerBase($logger);
    }

    /**
     * Defines the basic privileges required for actions. Handled in preAction
     */
    public function getRequiredPrivilegesForAction($action)
    {
        $action_privilege_mapping = [
            'overview' => [
                'batches.view',
            ],
            'download' => [
                'batches.view',
            ],
            'downloadresults' => [
                'batches.view',
            ],
            'view' => [
                'batches.view',
            ],

            'submit' => [
                'batches.submit',
                'batches.update',
            ],

            'markbatch' => [
                'batches.update',
            ],
        ];

        return $action_privilege_mapping[strtolower($action)] ?? [];
    }

    /*
     * These requests may contain sensitive data. Don't allow logging of context information.
     */
    protected function canPerformSensitiveRequests()
    {
        return true;
    }

    public function defaultTemplateData()
    {
        $data = parent::defaultTemplateData();

        if ($this->flash_messenger->hasMessages()) {
            $data['message'] = $this->flash_messenger->getMessage();
        }

        return $data;
    }

    /**
     * Show all batches
     */
    public function overviewAction()
    {
        $pagination = new Paginator();

        $page_number = isset($_GET[$pagination->getUrlKey()]) ? (int)$_GET[$pagination->getUrlKey()] : null;
        $pagination->setCurrentPage($page_number);
        $pagination->setItemsPerPage(self::ITEMS_PER_PAGE);
        $pagination->setTargetLink($_SERVER['REQUEST_URI']);

        $batches = $this->payment_batch_repository->findAllPerPage(
            $pagination->getItemsPerPage(),
            $pagination->getCurrentOffset()
        );

        $pagination->setItemTotal($this->payment_batch_repository->countBankPaymentBatches());

        $template = [
            'view_template' => 'batch/overview.tpl.php',
            'pagination'    => $pagination,
            'batches'       => $batches,
        ];

        $this->render($template);
    }

    /**
     * Download the batch as a file
     */
    public function downloadAction()
    {
        $id = isset($_GET['id']) ? (int)$_GET['id'] : null;

        try {
            $batch = $this->payment_batch_repository->getById($id);
        } catch (OutOfBoundsException $e) {
            throw new Controller_Exception('Batch not found.');
        }

        $filename = $batch->getFilename();

        $this->setHttpHeader('Content-Type', 'application/x-octet-stream');
        $this->setHttpHeader('Content-Disposition', sprintf('attachment; filename="%s"', $filename));

        echo $batch->contents;
    }

    /**
     * Download the batch as a file
     */
    public function downloadResultsAction()
    {
        $id = isset($_GET['id']) ? (int)$_GET['id'] : null;

        try {
            $batch = $this->payment_batch_repository->getById($id);
        } catch (OutOfBoundsException $e) {
            throw new Controller_Exception('Batch not found.');
        }

        if (empty($batch->result_contents)) {
            throw new Controller_Exception('Results are not yet returned by the bank.');
        }

        $filename = $batch->getFilename() . 'result.txt';

        $this->setHttpHeader('Content-Type', 'application/x-octet-stream');
        $this->setHttpHeader('Content-Disposition', sprintf('attachment; filename="%s"', $filename));

        echo $batch->result_contents;
    }

    /**
     * Have a batch executed by the bank
     */
    public function submitAction()
    {
        $this->allowLongRunning(0);

        $id = isset($_GET['id']) ? (int)$_GET['id'] : null;

        if ($id === null) {
            $this->redirect($this->url('batches', 'overview'));

            return;
        }

        try {
            $batch = $this->payment_batch_repository->getById($id);
        } catch (OutOfBoundsException $e) {
            $this->redirect($this->url('batches', 'overview'));

            return;
        }

        if (!$this->isPostRequest()) {
            $template = [
                'view_template' => 'batch/pay.tpl.php',
                'payment_file'  => $batch,
                'batch_creator' => $this->user_repository->find($batch->created_by),
            ];

            if ($this->flash_messenger->hasMessages()) {
                $template['message'] = $this->flash_messenger->getMessage();
            }

            $this->render($template);

            return;
        }

        if (!$this->validateFormToken()) {
            $this->logFormExpired();
            $this->redirect($this->url('batches', 'overview'));

            return;
        }

        try {
            $signing_password = new HiddenString($_POST['signing_password'] ?? '', true, true);
            unset($_POST['signing_password']); // lower the risk of it begin logged by unsetting before starting the submit.

            $this->payment_batch_uploader->uploadBatch($batch, $this->_getCurrentUser(), $signing_password);

            $this->flash_messenger->addMessage(
                'Payment order has been sent to the bank successfully.',
                Helper_View_MessageBox::SUCCESS_BOX
            );
        } catch (ClientException $e) {
            $this->flash_messenger->addMessage($e->getMessage(), Helper_View_MessageBox::ERROR_BOX);
        } catch (Exception $e) {
            $this->logger->error(
                'Unknown error during payment batch submission.',
                [
                    'category'  => LogCategory::WEBSITE(),
                    'exception' => $e,
                ]
            );
            $this->flash_messenger->addMessage('Unknown system error.', Helper_View_MessageBox::ERROR_BOX);
        }

        $this->redirect($this->url('batches', 'view', ['id' => $batch->id]));
    }

    private function logFormExpired()
    {
        $this->logger->error(
            'The form for sending a payment order has expired.',
            ['category' => LogCategory::SECURITY()]
        );

        $this->flash_messenger->addMessage(
            'The form is expired due to inactivity. Please try again.',
            Helper_View_MessageBox::ERROR_BOX
        );
    }

    /**
     * View one batch
     */
    public function viewAction()
    {
        $id = isset($_GET['id']) ? (int)$_GET['id'] : null;

        try {
            $batch_obj = $this->payment_batch_repository->getById($id);
        } catch (OutOfBoundsException $e) {
            $this->redirect($this->url('batches', 'overview'));
        }

        /* Transform the CLIEOP file into an array of transactions */
        $transactions = $this->getTransactionsInBatch($batch_obj);

        $template = [
            'view_template'           => 'batch/view.tpl.php',
            'payment_file'            => $batch_obj,
            'history_entries'         => $batch_obj->history_entries(null, 'ORDER BY id DESC'),
            'batch_transactions'      => $transactions,
            'user_can_submit_batches' => $this->userHasRequiredPrivilegesForAction('submit'),
            'user_can_mark_batches'   => $this->userHasRequiredPrivilegesForAction('markbatch'),
            'user_repository'         => $this->user_repository,
        ];

        $this->render($template);
    }

    /**
     * @return BatchTransaction[]
     */
    private function getTransactionsInBatch(Model_BankPaymentBatch $batch): array
    {
        /** @var Pain008Reader $reader */
        $reader = (new ReaderFactory())->createReaderFromType($batch->type, $batch->contents);

        $transactions = [];

        if ($reader instanceof PainReaderBase) { // Clieops is not supported by this controller
            foreach ($reader->getBatches() as $sepa_batch) {
                array_push($transactions, ...$sepa_batch->getTransactions());
            }
        }

        $direction = 1;

        if ($batch->getTotalAmount()->isPositive()) {
            /*
             * Flip the order: sort from least to greatest.
             */
            $direction = -1;
        }

        /* Show high transactions on top, sort rest by amount. */
        usort(
            $transactions,
            function (BatchTransaction $a, BatchTransaction $b) use ($batch, $direction): int {
                return $a->getAmount()->compare($b->getAmount()) * $direction;
            }
        );

        return $transactions;
    }

    /**
     * Mark a batch as completed
     */
    public function markBatchAction()
    {
        if (!Helper_Csrf::validate($_POST['_formtoken'], 'mark_batch')) {
            $this->flash_messenger->addMessage('The form has expired. Please try again.', Helper_View_MessageBox::ERROR_BOX);
            $this->redirect($this->url('batches', 'overview'));
        }

        // TODO: looks like it might need a privileges check.

        $id     = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
        $status = filter_input(INPUT_POST, 'status', FILTER_VALIDATE_INT);

        $batch_obj = new Model_BankPaymentBatch($this->_db, $id);

        if ($batch_obj->updateToStatus($status, $this->_getCurrentUser())) {
            $this->flash_messenger->addMessage('Status of payment batch updated.');
        } else {
            $this->flash_messenger->addMessage('Unable to update status of payment batch.');
        }

        $this->redirect($this->url('batches', 'overview'));
    }
}
