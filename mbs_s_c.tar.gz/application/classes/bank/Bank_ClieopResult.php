<?php

use Bank\Statements\Parsers\ClieopResult\ClieopResultParser;
use Mollie\BankingFiles\Bank\Transaction\BankTransfer;
use Money\Currency;
use function Core\Money\money_from_string;

class Bank_ClieopResult
{
    public const REJECTION_AMOUNT               = "Amount";
    public const REJECTION_CURRENCY             = "ISO Currency code payment amount";
    public const REJECTION_DESCRIPTION          = "Payment Information";
    public const REJECTION_TARGET_ACCOUNT_IBAN  = "Counter party account number";
    public const REJECTION_TARGET_ACCOUNT_IBAN2 = "Credit account number";
    public const REJECTION_TARGET_ACCOUNT_NAME  = "Name counter party";
    public const REJECTION_TARGET_ACCOUNT_NAME2 = "Name beneficiary";
    public const REJECTION_TARGET_BANK_BIC      = "Swift address bank counter party";
    public const REJECTION_TARGET_BANK_BIC2     = "Swift address bank beneficiary";
    public const REJECTION_SOURCE_ACCOUNT_IBAN  = "Ordering account number";
    public const REJECTION_SOURCE_ACCOUNT_NAME  = "Name ordering customer";

    protected $_interchange_reference = '';
    protected $_amount_total;
    protected $_amount_failed;
    protected $_full_data;
    protected $_rejected         = false;
    protected $_rejection_reason = '';

    public function getInterchangeReference()
    {
        return $this->_interchange_reference;
    }

    public function setInterchangeReference($r)
    {
        $this->_interchange_reference = $r;

        return $this;
    }

    public function getTotalAmountFailed()
    {
        return $this->_amount_failed;
    }

    public function setTotalAmountFailed($a)
    {
        $this->_amount_failed = $a;

        return $this;
    }

    public function setRejected($flag, $reason)
    {
        $this->_rejected         = $flag;
        $this->_rejection_reason = $reason;
    }

    public function isRejected()
    {
        return $this->_rejected;
    }

    public function getRejectionReason()
    {
        return $this->_rejection_reason;
    }

    public function setRawData($data)
    {
        $this->_full_data = $data;
    }

    public function getRawData()
    {
        return $this->_full_data;
    }

    public function isSuccessful()
    {
        if ($this->_amount_failed === null) {
            throw new LogicException("Cannot check a non-initialized Bank_ClieopResult object for success.");
        }

        $result = $this->_amount_failed == 0;

        return $result && ($this->_rejected == false);
    }

    /**
     * @return BankTransfer[]
     */
    public function getRejectedTransactions()
    {
        if (!preg_match($r = "!At first the concerning payment instruction is listed,followed by the reason\\(s\\) of rejection\\.\r\n" .
            preg_quote(ClieopResultParser::TXT_BATCH_SEPARATOR, "!") . "\\s*(.*)\\s*(?:" .
            preg_quote(ClieopResultParser::TXT_FOOTER_SEPARATOR, "!")
            . "|\$)!s", $this->getRawData(), $matches)) {
            return [];
        }

        $rejections = explode(ClieopResultParser::TXT_FOOTER_SEPARATOR, $matches[1]);

        $bank_transfers = [];

        foreach ($rejections as $rejection) {
            $rejection_details = $this->_parseRejectedTransactionBlock($rejection);

            if (isset($rejection_details["Total number of payments"])) {
                continue;
            }

            $bank_transfer = $this->_rejectionDetailsToBankTransfer($rejection_details);

            $bank_transfers[] = $bank_transfer;
        }

        return $bank_transfers;
    }

    /**
     * Parse a text into an array of key value pairs. Example text:
     *
     * Name counter party                      :SPARK LEADERSHIP ACADEMY FOUNDATION
     * Address counter party                   :N/A
     * City counter party                      :N/A
     * ISO country code counter party          :N/A
     * Ordering account number                 :NL29ABNA0546842291
     *
     * @param $raw_block
     *
     * @return array
     */
    protected function _parseRejectedTransactionBlock($raw_block)
    {
        $result = [];

        $lines = explode("\r\n", $raw_block);

        foreach ($lines as $line) {
            if (strlen($line) >= 40 && $line[40] == ":") {
                [$key, $value]      = explode(":", $line, 2);
                $result[trim($key)] = rtrim($value);
            } else {
                if (empty($line)) {
                    continue;
                }

                if ($line == ClieopResultParser::TXT_BATCH_SEPARATOR) {
                    /*
                     * We have encountered a batch separator, that means that the description for this transfer is over
                     * and that the reason of rejection follows.
                     */
                    break;
                }

                $keys     = array_keys($result);
                $last_key = end($keys);

                $result[$last_key] .= $line;
            }
        }

        return $result;
    }

    /**
     * @return BankTransfer
     */
    protected function _rejectionDetailsToBankTransfer(array $rejection_details)
    {
        $target_bankaccount = new Bank_Account();
        $target_bankaccount->setAccountHolderName(
            isset($rejection_details[self::REJECTION_TARGET_ACCOUNT_NAME]) ? $rejection_details[self::REJECTION_TARGET_ACCOUNT_NAME] : $rejection_details[self::REJECTION_TARGET_ACCOUNT_NAME2]
        );

        $target_bankaccount->setIban(
            isset($rejection_details[self::REJECTION_TARGET_ACCOUNT_IBAN]) ? $rejection_details[self::REJECTION_TARGET_ACCOUNT_IBAN] : $rejection_details[self::REJECTION_TARGET_ACCOUNT_IBAN2]
        );
        $target_bankaccount->setBic(
            isset($rejection_details[self::REJECTION_TARGET_BANK_BIC]) ? $rejection_details[self::REJECTION_TARGET_BANK_BIC] : $rejection_details[self::REJECTION_TARGET_BANK_BIC2]
        );

        $bank_transfer = new BankTransfer();
        $bank_transfer->setAmount(money_from_string(
            strtr($rejection_details[self::REJECTION_AMOUNT], [',' => '.']),
            new Currency($rejection_details[self::REJECTION_CURRENCY])
        ));
        $bank_transfer->setRecipientBankAccount($target_bankaccount);
        $bank_transfer->setMessage($rejection_details[self::REJECTION_DESCRIPTION]);

        return $bank_transfer;
    }
}
