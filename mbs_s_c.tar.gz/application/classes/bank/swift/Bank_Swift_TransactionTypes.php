<?php
/**
 * A list of all known Swift Transaction types.
 */
class Bank_Swift_TransactionTypes
{
    /** iDEAL betaling (can be "iDEAL" or "IDEAL"). */
    public const TYPE_IDEAL = "IDEAL";

    /** Sepa SCT overboeking */
    public const TYPE_OVERBOEKING = "SEPA OVERBOEKING";

    /** Sepa SCT batch */
    public const TYPE_SEPA_BATCH = "SEPA BATCH";

    /** Sepa SCT Salary Batch */
    public const TYPE_SEPA_SCT_SALARY_BATCH = "SEPA BATCH SALARIS";

    /** Sepa SCT Return or Reject */
    public const TYPE_SEPA_SCT_RETURNREJECT_TRX = "SEPA TERUGBOEKING";

    /**
     * Sepa SCT Correction (relatively new alias for Return).
     *
     * @see https://redmine.mollie.nl/issues/21398
     */
    public const TYPE_SEPA_SCT_CORRECTION_TRX = "SEPA CORRECTIEBOEKING";

    /** Sepa SDD Core Batch (incasso) */
    public const TYPE_SEPA_SDD_CORE_BATCH = "SEPA INCASSO BATCH";

    /** Sepa SDD B2B Incasso Batch */
    public const TYPE_SEPA_SDD_B2B_BATCH = "SEPA INCASSO BATCH BEDRIJVEN";

    /** SEPA SDD Transaction (for fees) */
    public const TYPE_SEPA_SDD_FEE = "SEPA INCASSO";

    /** SEPA SDD Transaction (geincasseerde) */
    public const TYPE_SEPA_SDD_TRANSACTION = "SEPA INCASSO ALGEMEEN DOORLOPEND";

    /** SEPA SDD Return (incasseerder). Is RTYP ipv TRTP */
    public const TYPE_SEPA_SDD_RETURN = "SEPA INCASSO TERUGBOEKING";

    /** SEPA SDD Reject (incasseerder. Is RTYP ipv TRTP */
    public const TYPE_SEPA_SDD_REJECT = "SEPA INCASSO NIET UITGEVOERD";

    /** SEPA SCT AcceptGiro */
    public const TYPE_SEPA_SCT_ACCEPTGIRO = "SEPA ACCEPTGIRO";

    /**
     * This is how ABN reports Acceptgiro payments in MT940.
     *
     * @see https://redmine.mollie.nl/issues/12393
     */
    public const TYPE_ACCEPTGIROBETALING = "ACCEPTGIROBETALING";
}
