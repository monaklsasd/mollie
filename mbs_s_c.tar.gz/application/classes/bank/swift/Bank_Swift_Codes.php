<?php
/**
 * A list of all the Swift codes and some methods to help make sense of it all.
 *
 * @author Willem Stuursma <willem@mollie.nl>
 */
class Bank_Swift_Codes implements IteratorAggregate, Countable
{
    /**
     * International SEPA MT940: "The content of electronic reporting regarding bank accounts of
     * ABN AMRO Bank N.V. in Germany, Belgium and United Kingdom will change as of 7 October 2013."
     *
     * "This document describes how SEPA transactions are reported on the MT940, specific for
     *  the ABN AMRO accounts held outside of NL."
     *
     * @see https://redmine.mollie.nl/issues/16056#note-22  PDF attachment
     *      Section "2.2.3 SCT Credit (incoming)"
     * @see /tests/unittests/bank/statementreader/files/belgian.mt940
     */
    public const INTERNATIONAL_SCT_NAME_BENEFICIARY = "NAME BENEFICIARY";
    public const INTERNATIONAL_SCT_IBAN_BENEFICIARY = "IBAN BENEFICIARY";
    public const INTERNATIONAL_SCT_BIC_BENEFICIARY  = "IDENTIFICATION BENEFICIARY";
    public const INTERNATIONAL_SCT_NAME_ORIGINATOR  = "NAME ORIGINATOR";
    public const INTERNATIONAL_SCT_IBAN_ORIGINATOR  = "IBAN ORIGINATOR";
    public const INTERNATIONAL_SCT_BIC_ORIGINATOR   = "IDENTIFICATION ORIGINATOR";
    public const INTERNATIONAL_SCT_OPPOSITE_PARTY   = "OPPOSITE PARTY";
    public const INTERNATIONAL_SCT_REMITTANCE_INFO  = "REMITTANCE INFORMATION";
    public const INTERNATIONAL_SCT_REFERENCE        = "CREDIT TRANSFER REFERENCE";
    public const INTERNATIONAL_BATCH_REFERENCE      = "BATCH REFERENCE";
    public const INTERNATIONAL_BATCH_NUMBER_OF_TRX  = "NUMBER OF TRANSACTIONS";

    /** These tags with slashes are SWIFT SEPA MT940 tags. */
    public const TRANSACTION_TYPE = "/TRTP/";
    public const REVERSAL_TYPE    = "/RTYP/";

    public const ADDRESS_OF_ORIGINATOR = "/ADDR/";
    public const BIC_ORIGINATOR        = "/BIC/";

    public const BENEFICIARY                     = "/BENM/";
    public const BENEFICIARY_IDENTIFICATION_CODE = "/BENM//ID/";
    public const CATEGORY_PURPOSE                = "/CPRP/";
    public const REFERENCE_ORIGINATOR            = "/EREF/";
    public const IBAN_ORIGINATOR                 = "/IBAN/";
    public const COUNTERPARTY_ID                 = "/CNTP/";
    public const SETTLEMENT_DATE                 = "/ISDT/";
    public const UNIQUE_MANDATE_REFERENCE        = "/MARF/";
    public const NAME_ORIGINATOR                 = "/NAME/";
    public const NUMBER_OF_TRANSACTIONS_IN_BATCH = "/NRTX/";
    public const SPECIFIC_REFERENCE              = "/PREF/";
    public const REMITTANCE_INFORMATION          = "/REMI/";
    public const INFORMATION                     = "/INF/";

    /** BC sends these SWIFT codes */
    public const PAYMENT_INFORMATION_ID        = "/KREF/";
    public const ORDERING_PARTY_ID             = "/ORDP//ID/";
    public const ORDERING_PARTY_ACCOUNT_NUMBER = "/ACC/";

    /**
     * ING Belgium.
     *
     * I guess "Customer Reference", you can enter this value in the ING online banking during the Home'Pay payment.
     */
    public const CUSTOMER_REFERENCE = "/CREF/";

    public const EXTERNAL_REJECTION_CODE = "/RTRN/";
    public const PAYMENT_INDICATOR       = "/PIND/"; //bruto/netto
    public const CREDITOR_ID             = "/CSID/";

    public const ORDERING_PARTY = "/ORDP/";

    public const ORIGINATOR_REFERENCE_NAME  = "/ULTD//NAME/";
    public const ORIGINATOR_REFERENCE_ID    = "/ULTD//ID/";
    public const BENEFICIARY_REFERENCE_NAME = "/ULTB//NAME/";
    public const BENEFICIARY_REFERENCE_ID   = "/ULTB//ID/";

    // Source: http://www.bng.nl/smartsite.shtml?id=72848
    public const REASON_CODE_INVALID_IBAN    = 'AC01';
    public const REASON_CODE_ACCOUNT_CLOSED  = 'AC04';
    public const REASON_CODE_ACCOUNT_BLOCKED = 'AC06';
    public const REASON_CODE_INVALID_ACCOUNT = 'AC13';

    public const REASON_CODE_INCASSO_NOT_ALLOWED = 'AG01';
    public const REASON_CODE_INVALID_FORMAT      = 'FF01';

    public const REASON_CODE_INSUFFICIENT_FUNDS   = 'AM04';
    public const REASON_CODE_DUPLICATE_COLLECTION = 'AM05';

    public const REASON_CODE_NAME_ACCOUNT_MISMATCH = 'BE01';

    public const REASON_CODE_NO_MANDATE             = 'MD01';
    public const REASON_CODE_INVALID_MANDATE        = 'MD02';
    public const REASON_CODE_NO_DEBTOR_APPROVAL     = 'MD06';
    public const REASON_CODE_ACCOUNTHOLDER_DECEASED = 'MD07';

    public const REASON_CODE_DEBTOR_SUPPLIED_NO_REASON = 'MS02';
    public const REASON_CODE_BANK_SUPPLIED_NO_REASON   = 'MS03';

    public const REASON_CODE_INVALID_BIC                 = 'RC01';
    public const REASON_CODE_DEBETACCOUNT_MISSING        = 'RR01';
    public const REASON_CODE_NAME_DEBTOR_MISSING         = 'RR02';
    public const REASON_CODE_NAME_CREDITOR_MISSING       = 'RR03';
    public const REASON_CODE_GENERIC                     = 'RR04';
    public const REASON_CODE_SPECIFIC_DEBOT_BANK_SERVICE = 'SL01';

    /** @var string[] */
    protected $codes = [];

    /**
     * Don't use this.
     *
     * @see parse()
     */
    protected function __construct(array $codes)
    {
        $this->codes = $codes;
    }

    /**
     * @interface ArrayIterator
     *
     * @return ArrayIterator|Traversable
     */
    public function getIterator()
    {
        return new ArrayIterator($this->codes);
    }

    /**
     * @interface Countable
     *
     * @return int
     */
    public function count()
    {
        return count($this->getIterator());
    }

    /**
     * Get a code from the parsed object.
     *
     * @param $code
     *
     * @return string|null
     */
    public function getCode($code)
    {
        if (isset($this->codes[$code])) {
            return $this->codes[$code];
        }

        return null;
    }

    /**
     * Get the remittance info, e.g. the message that was included in the bank transfer.
     *
     * @return string|null
     */
    public function getRemittanceInformation()
    {
        $remittance = $this->getCode(self::REMITTANCE_INFORMATION);

        return preg_replace("!^USTD//?!", "", $remittance);
    }

    /**
     * @return string|null
     */
    public function getIbanOriginator()
    {
        if ($this->getCode(self::IBAN_ORIGINATOR)) {
            return $this->getCode(self::IBAN_ORIGINATOR);
        }

        if ($this->getCode(self::COUNTERPARTY_ID)) {
            [$iban, $bic, $name] = explode("/", $this->getCode(self::COUNTERPARTY_ID));

            return trim($iban);
        }

        if ($this->getCode(self::ORDERING_PARTY_ACCOUNT_NUMBER)) {
            return $this->getCode(self::ORDERING_PARTY_ACCOUNT_NUMBER);
        }

        return null;
    }

    /**
     * @return string|null
     */
    public function getBicOriginator()
    {
        if ($this->getCode(self::BIC_ORIGINATOR)) {
            return $this->getCode(self::BIC_ORIGINATOR);
        }

        if ($this->getCode(self::COUNTERPARTY_ID)) {
            [$iban, $bic, $name] = explode("/", $this->getCode(self::COUNTERPARTY_ID));

            return trim($bic);
        }

        return null;
    }

    /**
     * @return string|null
     */
    public function getNameOriginator()
    {
        if ($this->getCode(self::NAME_ORIGINATOR)) {
            return $this->getCode(self::NAME_ORIGINATOR);
        }

        if ($this->getCode(self::COUNTERPARTY_ID)) {
            [$iban, $bic, $name] = explode("/", $this->getCode(self::COUNTERPARTY_ID));

            return trim($name);
        }

        return null;
    }

    /**
     * Get the Mollie Order Number, .e.g M0123456M0AVDDS
     *
     * @return string|null
     */
    public function getMollieOrderNumber()
    {
        if (!($remittance = $this->getRemittanceInformation())) {
            return null;
        }

        return Helper_Banktransaction_Matching::get_purchase_reference($remittance);
    }

    /**
     * Get the acquirer transaction id, e.g. 00300...
     */
    public function getTransactionId(): ?string
    {
        if (!($remittance = $this->getRemittanceInformation())) {
            /* The 00300 code is in the remittance info */
            if (!($remittance = $this->getCode(self::REFERENCE_ORIGINATOR))) {
                /* Alternatively, the code can be in the originator reference */
                return null;
            }
        }

        return Helper_Banktransaction_Matching::getAcquirerTransactionId($remittance);
    }

    /**
     * Get the date the customer did the transaction (e.g. "2012-01-15 14:22:00").
     *
     * @return string|null
     */
    public function getCustomerDate()
    {
        if (!($reference = $this->getCode(self::REFERENCE_ORIGINATOR))) {
            return null;
        }

        // There can be dots if they fall on the beginnin of a MT940 line...
        if (!preg_match('!^(?P<day>\d{2})[-.](?P<month>\d{2})[-.](?P<year>\d{2,4}) (?P<hour>\d{2})[ :](?P<minutes>\d{2})!', $reference, $matches)) {
            return null;
        }

        if (strlen($matches['year']) == 2) {
            /*
             * Thanks, Tridios bank!
             */
            $matches['year'] = "20{$matches['year']}";
        }

        return "{$matches['year']}-{$matches['month']}-{$matches['day']} {$matches['hour']}:{$matches['minutes']}:00";
    }

    /**
     * Get the Belgian Bank Account Number (BBAN) from the international part.
     *
     * @return string|null
     */
    protected static function getBbanFromOppositeParty($opposite_party)
    {
        $opposite_party = preg_replace("!\\s+!", "", $opposite_party);

        if (!preg_match("!^(\\d{12})\\D!", $opposite_party, $matches)) {
            return null;
        }

        if (Bank_AccountHelper::valid_belgium_bban($matches[1])) {
            return $matches[1];
        }

        return null;
    }

    /**
     * @return array
     */
    protected static function getAllSwiftCodes()
    {
        $reflection = new ReflectionClass(__CLASS__);
        $constants  = $reflection->getConstants();

        return array_filter($constants, function ($each) {
            return $each[0] == "/";
        });
    }

    /**
     * @return array
     */
    protected static function getAllInternationalCodes()
    {
        return [
            static::INTERNATIONAL_SCT_OPPOSITE_PARTY,
            static::INTERNATIONAL_SCT_NAME_BENEFICIARY,
            static::INTERNATIONAL_SCT_IBAN_BENEFICIARY,
            static::INTERNATIONAL_SCT_BIC_BENEFICIARY,
            static::INTERNATIONAL_SCT_NAME_ORIGINATOR,
            static::INTERNATIONAL_SCT_IBAN_ORIGINATOR,
            static::INTERNATIONAL_SCT_BIC_ORIGINATOR,
            static::INTERNATIONAL_SCT_REMITTANCE_INFO,
            static::INTERNATIONAL_SCT_REFERENCE,
            static::INTERNATIONAL_BATCH_REFERENCE,
            static::INTERNATIONAL_BATCH_NUMBER_OF_TRX,
        ];
    }

    /**
     * Parse a SEPA string ("/TRTP/...") into components, return an object.
     *
     * @param $string string Input (e.g. from an :86: tag in a M940 file).
     */
    public static function parse(string $string): self
    {
        /*
         * Remove trailing slashes
         */
        $string = rtrim($string, "/");

        /*
         * Remove all newlines, they are not supported in SEPA strings.
         */
        $string = rtrim(implode("", array_map(function ($line) {
            /*
             * A line must be 65 chars wide, if it is less that means that trailing spaces have been removed.
             */
            return str_pad($line, 65, " ", STR_PAD_RIGHT);
        }, explode("\r\n", $string))));

        $string = preg_replace("![\r\n]+!", "", $string);

        if (\Core\Strings::startsWith($string, "/TRCD/0150//RTRN//")) {
            /*
             * This is a little hack for ING Belgium MT940 delivered via ING STP link.
             *
             * There are some extra slashes in those strings.
             */
            foreach (self::getAllSwiftCodes() as $code) {
                $string = str_replace("/{$code}", $code, $string);
            }
        }

        $codes = array_merge(static::getAllInternationalCodes(), static::getAllSwiftCodes());

        /*
         * Concatinate all the codes in a regular expression.
         */
        $regexp = "!(" . implode("|", array_map(function (string $code): string {
            /*
             * It is possible that some spaces dissapeard in the codes during MT940 parsing unfortunately. Make them optional.
             *
             * Let me explain this. The international SEPA identifiers contain spaces, and unfortunately MT940 files are
             * line-chunked to 65 characters per line. In the unfortunate yet very probable case a line starts with a space,
             * that space is left-trimmed. In other words, trailing newlines eat leading spaces. In this particular case in
             * test there is a newline between REMITTANCE and INFORMATION that ate the space that belonged there, so the
             * remittance informatin is NULL. Sadly, we will never know whether there was an eaten space or not. Therefore
             * we consider this an edge-case.
             */
            return '\s?' . str_replace(" ", " ?", preg_quote($code, "!")) . '\s?'; // Trimmed below.
        }, $codes)) . ")!";

        /*
         * Split on this expression
         */
        $splitted = preg_split($regexp, $string, -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY);

        /*
         * All even keys 0, 2, 4... are the codes,
         * All odd keys 1, 3, 5... are the values.
         */
        $result = [];

        for ($i = 0; $i < count($splitted); $i += 2) {
            $code = trim($splitted[$i]);

            if (!in_array($code, $codes)) {
                /* If spaces were removed, check what the original code was */
                foreach ($codes as $alt_code) {
                    if (preg_match("!^" . str_replace(" ", " ?", preg_quote($alt_code, "!")) . "\$!", $code)) {
                        $code = $alt_code;

                        break;
                    }
                }
            }

            $result[$code] = isset($splitted[$i + 1]) ? rtrim($splitted[$i + 1]) : null;
        }

        $result = static::convertInternationalToSwiftSepaCreditTransfer($result);

        return new self($result);
    }

    /**
     * Converts international SEPA Credit Transfer MT940 codes to SWIFT MT940 codes.
     *
     * @return array
     */
    protected static function convertInternationalToSwiftSepaCreditTransfer(array $splitted)
    {
        if (isset($splitted[static::INTERNATIONAL_SCT_OPPOSITE_PARTY])) {
            $bban = self::getBbanFromOppositeParty($splitted[static::INTERNATIONAL_SCT_OPPOSITE_PARTY]);

            if ($bban) {
                $splitted[static::INTERNATIONAL_SCT_IBAN_ORIGINATOR] = Bank_AccountHelper::convert_belgium_to_iban($bban);
            }
        }

        if (empty($splitted[static::TRANSACTION_TYPE]) && empty($splitted[static::REVERSAL_TYPE])) {
            /*
             * Convert to /TRTP/SEPA OVERBOEKING/
             */
            $splitted[static::TRANSACTION_TYPE] = isset($splitted[static::INTERNATIONAL_BATCH_REFERENCE]) ?
                    Bank_Swift_TransactionTypes::TYPE_SEPA_BATCH :
                    Bank_Swift_TransactionTypes::TYPE_OVERBOEKING;
        }

        /*
         * Belgium uses different swift codes of course. Attempt to fix this.
         */
        if (isset($splitted[static::ORDERING_PARTY]) || isset($splitted[static::BENEFICIARY])) {
            $source = isset($splitted[static::ORDERING_PARTY]) ? $splitted[static::ORDERING_PARTY] : $splitted[static::BENEFICIARY];

            if (preg_match("!^(?P<account_number>[A-Z0-9]+)//(?P<bic>[A-Z0-9]{8}(?:XXX)?)(?P<name>.*)\$!", $source, $matches)) {
                if (Bank_AccountHelper::valid_belgium_bban($matches["account_number"])) {
                    $matches["account_number"] = Bank_AccountHelper::convert_belgium_to_iban($matches["account_number"]);
                }

                if (Bank_AccountHelper::valid_iban($matches["account_number"]) && Bank_AccountHelper::valid_bic($matches["bic"])) {
                    unset($splitted[static::ORDERING_PARTY]);
                    $splitted[static::IBAN_ORIGINATOR] = $matches["account_number"];
                    $splitted[static::BIC_ORIGINATOR]  = $matches["bic"];
                    $splitted[static::NAME_ORIGINATOR] = trim($matches["name"]);
                }
            }
        }

        $code_map = [
            static::INTERNATIONAL_SCT_NAME_BENEFICIARY => static::NAME_ORIGINATOR,        // Convert to /NAME/N. KUNSTMAN
            static::INTERNATIONAL_SCT_IBAN_BENEFICIARY => static::IBAN_ORIGINATOR,        // Convert to /IBAN/BE13068891673739
            static::INTERNATIONAL_SCT_BIC_BENEFICIARY  => static::BIC_ORIGINATOR,         // Convert to /BIC/ARSPBE22
            static::INTERNATIONAL_SCT_NAME_ORIGINATOR  => static::NAME_ORIGINATOR,        // Convert to /NAME/N. KUNSTMAN
            static::INTERNATIONAL_SCT_IBAN_ORIGINATOR  => static::IBAN_ORIGINATOR,        // Convert to /IBAN/BE13068891673739
            static::INTERNATIONAL_SCT_BIC_ORIGINATOR   => static::BIC_ORIGINATOR,         // Convert to /BIC/ARSPBE22
            static::INTERNATIONAL_SCT_REFERENCE        => static::REFERENCE_ORIGINATOR,   // Convert to /EREF/moeder-dochterweekend
            static::INTERNATIONAL_SCT_REMITTANCE_INFO  => static::REMITTANCE_INFORMATION, // Convert to /REMI/RF45 0000 0456 1463
            static::INTERNATIONAL_BATCH_REFERENCE      => static::SPECIFIC_REFERENCE,              // Convert to /PREF/77c99b4c290c1c8fbbfc07291546b944
            static::INTERNATIONAL_BATCH_NUMBER_OF_TRX  => static::NUMBER_OF_TRANSACTIONS_IN_BATCH, // Convert to /NRTX/00001
        ];

        foreach ($code_map as $internatial_code => $swift_code) {
            if (!isset($splitted[$internatial_code])) {
                continue;
            }

            if ($swift_code === static::IBAN_ORIGINATOR && empty($splitted[static::BIC_ORIGINATOR])) {
                $splitted[static::BIC_ORIGINATOR] = Bank_AccountHelper::guess_bic($splitted[$internatial_code]); // Convert to /BIC/INGBNL2A/
            }

            $splitted[$swift_code] = $splitted[$internatial_code];
            unset($splitted[$internatial_code]);
        }

        return $splitted;
    }

    public static function reasonCodeToText($reasonCode)
    {
        $mapping = [
            self::REASON_CODE_INVALID_IBAN                => 'Foutieve IBAN',
            self::REASON_CODE_ACCOUNT_CLOSED              => 'Rekening gesloten',
            self::REASON_CODE_ACCOUNT_BLOCKED             => 'Rekening geblokkeerd',
            self::REASON_CODE_INVALID_ACCOUNT             => 'Ongeldig rekeningtype (bijv. spaarrekening)',
            self::REASON_CODE_INCASSO_NOT_ALLOWED         => 'Incasso niet toegestaan door regelgeving',
            self::REASON_CODE_INVALID_FORMAT              => 'Ongeldig formaat, codering',
            self::REASON_CODE_INSUFFICIENT_FUNDS          => 'Saldo ontoereikend',
            self::REASON_CODE_DUPLICATE_COLLECTION        => 'Dubbele collectie',
            self::REASON_CODE_NAME_ACCOUNT_MISMATCH       => 'Ongeldige naam/nummer combinatie',
            self::REASON_CODE_NO_MANDATE                  => 'Geen machtiging',
            self::REASON_CODE_INVALID_MANDATE             => 'Machtigingsinformatie foutief/onvolledig',
            self::REASON_CODE_NO_DEBTOR_APPROVAL          => 'Debiteur niet akkoord',
            self::REASON_CODE_ACCOUNTHOLDER_DECEASED      => 'Rekeninghouder overleden',
            self::REASON_CODE_DEBTOR_SUPPLIED_NO_REASON   => 'Geen reden vermeld door debiteur',
            self::REASON_CODE_BANK_SUPPLIED_NO_REASON     => 'Geen reden vermeld door bank debiteur, administratieve reden',
            self::REASON_CODE_INVALID_BIC                 => 'Foutieve BIC',
            self::REASON_CODE_DEBETACCOUNT_MISSING        => 'Debetrekening ontbreekt (regelgeving)',
            self::REASON_CODE_NAME_DEBTOR_MISSING         => 'Naam/adres debiteur ontbreekt (regelgeving)',
            self::REASON_CODE_NAME_CREDITOR_MISSING       => 'Naam/adres crediteur ontbreekt (regelgeving)',
            self::REASON_CODE_GENERIC                     => 'Algemene reden (regelgeving)',
            self::REASON_CODE_SPECIFIC_DEBOT_BANK_SERVICE => 'Specifieke service debet bank',
        ];

        if (isset($mapping[$reasonCode])) {
            return $mapping[$reasonCode];
        }

        return '(onbekende reden)';
    }

    /**
     * @param string $description
     * @param array  $last_61_tag
     *
     * @return bool
     */
    public static function isSepaDescription($description, ?array $last_61_tag = null)
    {
        if (isset($last_61_tag['additional']) && stripos($last_61_tag['additional'], 'SEPA TRANSACTION') !== false) {
            return true;
        }

        return strlen($description) > 0 && $description[0] == "/";
    }

    public static function isInternationalDescription($description)
    {
        return \Core\Strings::startsWith($description, self::INTERNATIONAL_SCT_OPPOSITE_PARTY) || \Core\Strings::startsWith($description, self::INTERNATIONAL_SCT_NAME_ORIGINATOR);
    }
}
