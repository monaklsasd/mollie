<?php

class Bank_DateUtil
{
    public static function convertYYMMDDToUnixtime($str)
    {
        sscanf($str, "%02d%02d%02d", $year, $month, $day);

        // add the thousands & hundreds of the current year. This will blow up if you try to read MT940 files from dec 2099 on jan 1st, 2100. Sorry bout that.
        // @codeCoverageIgnoreStart
        if (date('Y-m') == "2099-12") {
            throw new Exception("Yeah hi, this is 2010 talking. This code should be updated. It's Y2K all over again. Thank the bank for using outdated formats :(");
        }
        // @codeCoverageIgnoreEnd

        $year += (date('Y') - (date('Y') % 100));

        return strtotime("{$year}-{$month}-{$day}");
    }

    /**
     * Convert a MMDD datestamp found in (e.g.) mt940 files to a usable timestamp including a year, taking into account
     * the other timestamp (YYMMDD) also found in such files.
     *
     * The MMDD date is the value date and the YYMMDD is the entry date. The value date can be one day before
     * (debit transaction) and day ahead (credit transaction) of the entry date. This causes problems when attempting
     * to reconstruct the year of the value date from the year of the entry date, because this could be the previous
     * or the next year.
     *
     * @param $mmdd string
     * @param $reference_unixtime int
     *
     * @return int
     */
    public static function convertMMDDToUnixtime($mmdd, $reference_unixtime)
    {
        sscanf($mmdd, "%02d%02d", $month, $day);
        $year = date('Y', $reference_unixtime);

        /*
         * There are three options. Either it uses the previous year, the current year or the next year.
         *
         * Examples:
         *
         * Refenence (value date): 20111230
         * $str                  :     0102
         *
         * Options:                20100102
         *                         20110102
         *                         20120102 <--- correct one, closest to reference
         */
        $options = [
            strtotime(($year - 1) . "-{$month}-{$day}") => null,
            strtotime(($year + 0) . "-{$month}-{$day}") => null,
            strtotime(($year + 1) . "-{$month}-{$day}") => null,
        ];

        // Calculate difference with reference time for every option.
        foreach ($options as $unix_option => $diff) {
            $options[$unix_option] = abs($reference_unixtime - $unix_option);
        }
        asort($options);

        $keys = array_keys($options);

        return $keys[0];
    }
}
