<?php

class Bank_AccountHelper_Exception extends Mollie_Exception
{
}
