<?php

use Mollie\BankingFiles\Batch\Sepa\Pain001\Pain001V03Writer;

/**
 * SEPA builder
 *
 * Create SEPA XML (ISO20022) version 2 batch files
 */
class Bank_FileGenerator_Sepa3 extends Pain001V03Writer implements Bank_FileGenerator_Interface
{
    public const IBAN_BLACKLIST = [
        /*
         * Banque de la pose. Uses the same IBAN for all of its customers. Belfius does not accept batches with
         * this IBAN in it.
         */
        'BE54000000000097',
    ];

    /**
     * We can only use this generator if we have IBAN and BIC information.
     *
     * @return bool
     */
    public function acceptsTransaction(Model_Banktransaction $transaction)
    {
        if (!Bank_AccountHelper::valid_sepa_iban($transaction->getOffsetAccountNumber())) {
            return false;
        }

        if (in_array($transaction->getOffsetAccountNumber(), static::IBAN_BLACKLIST, true)) {
            return false;
        }

        return true;
    }
}
