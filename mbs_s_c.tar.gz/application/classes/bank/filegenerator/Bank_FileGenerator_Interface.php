<?php

use Mollie\BankingFiles\Batch\WriterInterface;

interface Bank_FileGenerator_Interface extends WriterInterface
{
    /**
     * Check if the generator can use the given bank transaction
     *
     * @return bool
     */
    public function acceptsTransaction(Model_Banktransaction $bank_transaction);
}
