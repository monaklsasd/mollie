<?php

declare(strict_types=1);

namespace Bank\Clients;

use App\Logger\LogCategory;
use App\Supplier\BatchResultProcessor;
use App\Supplier\Rabobank\BatchStatusProcessor;
use Bank\Clients\Exceptions\ClientException;
use Bank\Statements\Exceptions\UnrecognizedStatementFileException;
use Bank\Statements\FileExtension;
use Bank\Statements\FileExtensionDetector;
use Bank\Statements\FileParserFactory;
use Bank\Statements\Parsers\ClieopResult\ClieopResultParser;
use Bank\Statements\Parsers\Exceptions\AbstractException;
use Core\Di\Stateful;
use Domain\Banking\BankToCustomerMessageImporterFactory;
use Domain\Banking\Exception\ImportingException;
use Mollie\ObjectStorage\BucketInterface;
use Mollie\ObjectStorage\Exception\StorageException;
use Mollie\ObjectStorage\ObjectInterface;
use Psr\Log\LoggerAwareInterface;
use Psr\Log\LoggerAwareTrait;
use Psr\Log\NullLogger;
use Throwable;
use function strlen;

/**
 * Accepteert het gegeven bestand, slaat het bestand op op het filesystem, bepaalt
 * het type bestand en verwerkt het bestand vervolgens aan de hand van het gegeven
 * handler type.
 *
 * Implement \Core\Di\Stateful because of setStorageBucket
 *
 * @author    Mathieu Kooiman <mathieu@mollie.nl>
 * @copyright Copyright (C), Mollie B.V.
 */
class FileProcessor implements LoggerAwareInterface, Stateful
{
    use LoggerAwareTrait;

    /** @var FileExtensionDetector */
    private $statement_file_extension_detector;

    /** @var FileParserFactory */
    private $file_parser_factory;

    /** @var ClieopResultParser */
    private $clieop_result_parser;

    /** @var BucketInterface */
    private $storage_bucket;

    /** @var BatchResultProcessor */
    private $batch_result_processor;

    /** @var BatchStatusProcessor */
    private $rdc_batch_status_processor;

    /** @var BankToCustomerMessageImporterFactory */
    private $bank_to_customer_message_importer_factory;

    public function __construct(
        FileExtensionDetector $statement_file_extension_detector,
        FileParserFactory $file_parser_factory,
        ClieopResultParser $clieop_result_parser,
        BatchResultProcessor $batch_result_processor,
        BatchStatusProcessor $rdc_batch_status_processor,
        BankToCustomerMessageImporterFactory $bank_to_customer_message_importer_factory
    ) {
        $this->statement_file_extension_detector         = $statement_file_extension_detector;
        $this->file_parser_factory                       = $file_parser_factory;
        $this->clieop_result_parser                      = $clieop_result_parser;
        $this->batch_result_processor                    = $batch_result_processor;
        $this->rdc_batch_status_processor                = $rdc_batch_status_processor;
        $this->logger                                    = new NullLogger();
        $this->bank_to_customer_message_importer_factory = $bank_to_customer_message_importer_factory;
    }

    /**
     * When this method is removed, implements \Core\Di\Stateful can probably be removed.
     */
    public function setStorageBucket(BucketInterface $storage_bucket): void
    {
        $this->storage_bucket = $storage_bucket;
    }

    public function acceptFile(RemoteFile $document, string $contents): bool
    {
        $extension = $this->statement_file_extension_detector->getFileExtensionForFileContents($contents);

        if ($extension->isBankToCustomerMessage()) {
            return $this->acceptBankToCustomerMessage($document, $contents);
        }

        if ($extension->isBatchResult()) {
            return $this->acceptBatchResultFile($document, $contents, $extension);
        }

        return false;
    }

    private function acceptBatchResultFile(RemoteFile $document, string $contents, FileExtension $extension): bool
    {
        try {
            $file_object = $this->storeFile($document, $contents);
        } catch (ClientException $e) {
            $this->logFileProcessingException($e, $document, 'Could not store file');

            return false;
        }

        switch ($extension) {
            case FileExtension::CLIEOP_RESULT():
                /*
                 * The ClieopResultParser holds an instance of Mollie_StatementHandler_ClieopResult which will be called
                 * with the result.
                 *
                 * This isn't wrapped in a database transaction because it calls the Mollie application after each rejected
                 * transaction it finds. This would mean that performing a rollback after reporting X rejected transactions to
                 * Mollie would leave Mollie in an invalid state.
                 */
                return $this->clieop_result_parser->parseClieopResultFile($file_object);

            case FileExtension::RDC_BATCH_STATUS():
                return $this->rdc_batch_status_processor->processStatus($file_object);

            case FileExtension::PAIN002():
                /*
                 * Rabobank / Deutsche Bank batch result report files in PAIN.002 format.
                 */
                return $this->batch_result_processor->processResult($file_object);
        }

        return false;
    }

    private function acceptBankToCustomerMessage(RemoteFile $document, string $messageContents): bool
    {
        try {
            $this->handleStoredBankToCustomerMessage($this->storeFile($document, $messageContents));
        } catch (ClientException $e) {
            $this->logFileProcessingException($e, $document, 'Could not store file');

            return false;
        } catch (UnrecognizedStatementFileException $e) {
            $this->logFileProcessingException($e, $document, 'The account report file wasn\'t recognized');

            return false;
        } catch (AbstractException $e) {
            $this->logFileProcessingException($e, $document, 'Unable to read account report file');

            return false;
        } catch (ImportingException $exception) {
            $this->logFileProcessingException($exception, $document, 'Cannot import bank to customer message');

            return false;
        }

        return true;
    }

    /**
     * @throws ImportingException                 If importing of message has exceptionally failed
     * @throws UnrecognizedStatementFileException If extension of file cannot be determined.
     */
    public function handleStoredBankToCustomerMessage(ObjectInterface $messageFile): void
    {
        $messageParser = $this->file_parser_factory->getParserForFile($messageFile);
        $parsedMessage = $messageParser->parse($messageFile->getContents());
        $parsedMessage->setFilePath($messageFile->getNamespace() . DIRECTORY_SEPARATOR . $messageFile->getName());

        $this->bank_to_customer_message_importer_factory
            ->getImporterForMessage($parsedMessage)
            ->import($parsedMessage);
    }

    /**
     * @param string $log_title
     */
    private function logFileProcessingException(Throwable $e, RemoteFile $file, $log_title): void
    {
        $this->logger->error(
            sprintf('%s (file %s). %s', $log_title, $file->getFilename(), $e->getMessage()),
            [
                'exception' => $e,
                'category'  => LogCategory::IMPORTS(),
            ]
        );
    }

    /**
     * @throws ClientException
     */
    protected function storeFile(RemoteFile $document, string $file_data): ObjectInterface
    {
        if (empty($file_data)) {
            throw new ClientException(sprintf(
                'File contents are empty for document \'%s\'',
                $document->getFilename()
            ));
        }

        try {
            $extension = $this->statement_file_extension_detector->getFileExtensionForFileContents($file_data);
        } catch (UnrecognizedStatementFileException $e) {
            throw new ClientException(sprintf(
                'Failed to get extension for document \'%s\': %s',
                $document->getFilename(),
                $e->getMessage()
            ), 0, $e);
        }

        /* This check mostly makes sense for ABNAMRO GXS where we get reported a file size through an HTTP API.
         * For ING we perform file transformations, making this information less valuable. */
        if (strlen($file_data) !== $document->getFilesize()) {
            throw new ClientException(
                sprintf(
                    'Invalid file size for %s: expected size %d bytes != actual %d bytes',
                    $document->getFilename(),
                    $document->getFilesize(),
                    strlen($file_data)
                )
            );
        }

        try {
            // Write the file
            $file_object = $this->storage_bucket->add(
                $file_data,
                sprintf('%s.%s', $document->getFilename(), $extension),
                sprintf(
                    '%d/%02d/%02d',
                    $document->getCreatedDateTime()->format('Y'),
                    $document->getCreatedDateTime()->format('m'),
                    $document->getCreatedDateTime()->format('d')
                )
            );
        } catch (StorageException $e) {
            throw new ClientException($e->getMessage(), $e->getCode(), $e);
        }

        $this->logger->info(
            sprintf('File stored: %s/%s', $file_object->getNamespace(), $file_object->getName()),
            ['category' => LogCategory::IMPORTS()]
        );

        return $file_object;
    }
}
