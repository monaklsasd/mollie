<?php

declare(strict_types=1);

namespace Bank\Clients;

use Mollie\Xml\Canonicalizer\CanonicalizerInterface;
use Mollie\Xml\Signature\SignedDocument;

/**
 * Bank_Client_XmlSignedDocument
 *
 * Dit is een uitgebreidde versie van XML_SignedDocument, specifiek voor gebruik met ABNAMRO's ADOL product, die een
 * paar heel erg ranzige dingen doet. Sorry bout that. Wanneer je een namespaced element toevoegt aan een ander
 * namespaced element, begint PHP's DOMXML enigzins te spacen. Er wordt dan een default namespace aangemaakt, like so:
 *
 * <?xml version="1.0" encoding="UTF-8"?>
 * <dsig:Signature xmlns:dsig="http://www.w3.org/2000/09/xmldsig#">
 *  <ggol_xml_payment xmlns:default="urn:pain:001:001:02">
 *      <default:Document xmlns="urn:pain:001:001:02">
 *      </default:Document>
 * </ggol_xml_payment>
 * </dsig:Signature>
 *
 * De default namespace is niet wenselijk op ggol_xml_payment. Echter, ik zie geen weg om hier om heen te komen.
 * Aangezien DOMXML wel nodig is vanwege zijn ondersteuning van de C14N normalisatie, zie ik geen andere weg dan
 * het heel ranzig op te lossen:
 *
 *  - Voeg het SEPA XML document toe aan een dsig:Object argument.
 *  - Verschillende elementen hebben nu een xmlns:default definitie en verschillende tags hebben de default: prefix
 *  - Verwijder deze middels str_replace().
 *  - Laad het resultaat en continue processing.
 *
 * @author Mathieu Kooiman <mathieu@mollie.nl>
 */
class XmlSignedDocument extends SignedDocument
{
    public function addContentObject(string $id): void
    {
        parent::addContentObject($id);

        $xmlString = $this->doc->saveXML();
        $xmlString = strtr($xmlString, [
            ':default='  => '=',
            '<default:'  => '<',
            '</default:' => '</',
        ]);
        $xmlString = preg_replace('~<dsig:Object xmlns="[^"]+"~', '<dsig:Object', $xmlString);
        $xmlString = preg_replace('~<ggol_xml_payment xmlns="[^"]+"~', '<ggol_xml_payment', $xmlString);

        // Reload environment
        $newDoc         = new self($xmlString);
        $this->doc      = $newDoc->doc;
        $this->rootNode = $newDoc->rootNode;
        $this->xPath    = $newDoc->xPath;
    }

    protected function getCanonicalizer(): CanonicalizerInterface
    {
        $canonicalizer = parent::getCanonicalizer();
        $canonicalizer->setRemoveDefaultNamespace(true);

        return $canonicalizer;
    }
}
