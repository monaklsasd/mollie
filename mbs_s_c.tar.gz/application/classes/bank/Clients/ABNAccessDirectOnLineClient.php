<?php

declare(strict_types=1);

namespace Bank\Clients;

use App\Crypto\BatchSigningKeyTag;
use App\Crypto\BatchSigningStrategy;
use App\Supplier\BankDownloadClient;
use App\Supplier\BankUploadClient;
use Bank\Clients\Exceptions\BatchContentException;
use Bank\Clients\Exceptions\ClientConnectionException;
use Bank\Clients\Exceptions\ClientDownloadException;
use Bank\Clients\Exceptions\ClientException;
use Bank\Clients\Exceptions\ClientUploadException;
use Config_Adol;
use DateTimeImmutable;
use DOMDocument;
use GuzzleHttp\Client as GuzzleClient;
use GuzzleHttp\Exception\ConnectException;
use GuzzleHttp\Exception\RequestException;
use GuzzleHttp\RequestOptions;
use Helper\DateTime\Now;
use Model_BankPaymentBatch;
use Mollie\BankingFiles\Batch\BatchFile;
use Psr\Http\Message\ResponseInterface;
use Psr\Log\LoggerAwareTrait;
use Psr\Log\NullLogger;

class ABNAccessDirectOnLineClient implements BankDownloadClient, BankUploadClient
{
    use LoggerAwareTrait;
    use Now;

    public const  TYPE_MAILBOX  = 'mailbox';
    public const  LIST_TYPE_NEW = 'new';

    private const LOCK_NAME = 'send_payment_batch';

    /** @var Config_Adol */
    private $config;

    /** @var GuzzleClient */
    private $guzzle;

    public function __construct(Config_Adol $config, GuzzleClient $guzzle)
    {
        $this->config = $config;
        $this->guzzle = $guzzle;
        $this->logger = new NullLogger();
    }

    /**
     * @throws ClientDownloadException
     *
     * @return RemoteFile[]
     */
    public function getDocumentList($type = self::TYPE_MAILBOX, $list_type = self::LIST_TYPE_NEW, $size = null): array
    {
        try {
            $response = $this->sendRequest('getmailbox', array_filter([
                'type'     => $type,
                'listType' => $list_type,
                'size'     => $size,
            ]));

            return self::parseDocumentList((string)$response->getBody());
        } catch (RequestException $e) {
            throw new ClientDownloadException(
                'An error occurred while fetching the documentlist from the server.'
            );
        }
    }

    public function downloadFile(RemoteFile $file): string
    {
        try {
            return (string)$this->sendRequest('download', ['documentID' => $file->getFilename()])->getBody();
        } catch (RequestException $e) {
            throw new ClientDownloadException(sprintf(
                'An error occurred while downloading %s from the server.',
                $file->getFilename()
            ), 0, $e);
        }
    }

    /**
     * @throws ClientException
     */
    public function uploadPaymentBatch(Model_BankPaymentBatch $batch, BatchSigningStrategy $signingStrategy): void
    {
        $signed_batch_contents = $this->createSignedPaymentBatchDocument($batch, $signingStrategy);

        $filename = str_replace('.', '_', $batch->reference) . '.xml';

        try {
            $response = $this->sendRequest('upload', [
                'receiverid'   => 'ABNNSHTTP',
                'filename'     => $filename,
                'Content-Type' => 'application/HTTPStream',
                'aprf'         => '*BIN',
                'datatype'     => 'BINARY',
            ], 45, $signed_batch_contents);

            $this->logger->info(sprintf(
                'Payment batch "%s" uploaded successfully!',
                $batch->reference
            ), [
                'signing_tag' => $this->getBatchSigningKeyTag()->getValue(),
                'response'    => [
                    'status'  => $response->getStatusCode(),
                    'headers' => $response->getHeaders(),
                    'body'    => (string)$response->getBody(),
                ],
            ]);
        } catch (ConnectException $e) {
            throw new ClientConnectionException(sprintf(
                'Failed to connect to server to upload %s, you may try again.',
                $filename
            ));
        } catch (RequestException $e) {
            throw new ClientUploadException(sprintf(
                'An error occurred while uploading %s to the server. ' .
                'Please verify if the file has been uploaded correctly before trying again.',
                $filename
            ));
        }
    }

    public function getBatchSigningKeyTag(): BatchSigningKeyTag
    {
        return BatchSigningKeyTag::ABNAMRO();
    }

    /**
     * @return RemoteFile[]
     */
    private static function parseDocumentList(string $raw_document_list): array
    {
        $xml       = simplexml_load_string($raw_document_list);
        $documents = [];

        $doc_fields = [
            'DocID',
            'DocTimestamp',
            'TypeName',
            'SenderID',
            'ReceiverID',
            'SenderCorp',
            'SenderUnit',
            'ReceiverCorp',
            'ReceiverUnit',
            'SenderName',
            'ReceiverName',
            'RoutingStatus',
            'UserStatus',
            'NativeID',
            'GroupID',
            'ConversationID',
            'Comments',
            'JobStatus',
            'DocumentError',
            'originalSender',
            'originalReceiver',
        ];

        foreach ($xml->Docs as $raw_document) {
            $document = [];

            foreach ($doc_fields as $field) {
                $document[$field] = (string)$raw_document->{$field};
            }

            foreach ($raw_document->attributes->children() as $element) {
                $attributes[$element->getName()] = (string)$element;
            }

            $document['attributes'] = $attributes;

            $datetime = new DateTimeImmutable($document['DocTimestamp']);
            $doc      = new RemoteFile();

            $doc->setFilename($document['DocID']);
            $doc->setFilesize((int)$attributes['fileSize']);
            $doc->setCreatedDateTime($datetime);

            $documents[] = $doc;
        }

        return $documents;
    }

    private function sendRequest(
        string $action,
        array $headers = [],
        int $timeout = 240,
        ?string $body = null
    ): ResponseInterface {
        $headers += [
            'userid'        => $this->config->getUsername(),
            'password'      => $this->config->getPassword(),
            'Content-Type'  => 'application/HTTPStream',
            'actionrequest' => $action,
        ];

        $method = $body === null ? 'GET' : 'POST';

        return $this->guzzle->request($method, $this->config->getEndpointUrl(), [
            RequestOptions::CONNECT_TIMEOUT => 5,
            RequestOptions::TIMEOUT         => $timeout,
            RequestOptions::ALLOW_REDIRECTS => [
                'strict' => true,
            ],
            RequestOptions::HTTP_ERRORS => true,
            RequestOptions::HEADERS     => $headers,
            RequestOptions::BODY        => $body,
        ]);
    }

    /**
     * Take a payment batch and sign it so it can be executed.
     *
     * @throws BatchContentException
     *
     * @return string Signed document, ready to be uploaded
     */
    private function createSignedPaymentBatchDocument(
        Model_BankPaymentBatch $batch,
        BatchSigningStrategy $signingStrategy
    ): string {
        $document = $this->wrapBatchInEnvelope($batch);

        $custom_doc = new DOMDocument();
        $custom_doc->loadXML($document);

        return $signingStrategy->signXml($custom_doc);
    }

    /**
     * @throws BatchContentException
     *
     * @return string XML Document
     */
    protected function wrapBatchInEnvelope(Model_BankPaymentBatch $batch): string
    {
        if (empty($batch->reference) || empty($batch->num_transactions)) {
            throw new BatchContentException('No reference or no transactions set.');
        }

        switch ($batch->type) {
            case BatchFile::TYPE_LEGACY_SEPA:
            case BatchFile::TYPE_PAIN008:
            case BatchFile::TYPE_PAIN001_V03:
                $payment_tag = 'xml_payment';
                $format      = 'ISO XML';

                break;

            default:
                throw new BatchContentException(sprintf(
                    'Unsupported payment batch type: %s.',
                    $batch->type
                ));
        }

        /*
         * This bit is still pretty ugly but I don't dare to change it because the whitespace in this xml-string
         * Influences the generated signature/digest of the batch file. It might not matter, but that's for
         * someone else to find out.
         */

        $file_creation_date = self::getNow()->format('ymd');
        $file_creation_time = self::getNow()->format('His');

        $envelope = <<< EOX
            <ggol_xml_payment>
            	<cust_payment_header>
            		<sender_id>{$this->config->getSenderId()}</sender_id>
            		<receiver_id>ABNANL2A</receiver_id>
            		<file_creation_date>{$file_creation_date}</file_creation_date>
            		<file_creation_time>{$file_creation_time}</file_creation_time>
            		<transaction_count>{$batch->num_transactions}</transaction_count>
            		<file_ref_nu>{$batch->reference}</file_ref_nu>
            		<format>{$format}</format>
            	</cust_payment_header>
            	<{$payment_tag}></{$payment_tag}>
            </ggol_xml_payment>
            EOX;

        $document                     = new DOMDocument();
        $document->preserveWhiteSpace = true;
        $document->formatOutput       = false;
        $document->loadXML($envelope);

        $payment_node = $document->getElementsByTagName($payment_tag)->item(0);

        switch ($batch->type) {
            case BatchFile::TYPE_LEGACY_SEPA:
            case BatchFile::TYPE_PAIN008:
            case BatchFile::TYPE_PAIN001_V03:
                $sepa_doc               = new DOMDocument();
                $sepa_doc->formatOutput = false;
                $sepa_doc->loadXML($batch->contents);

                $imported_pain_node = $document->importNode($sepa_doc->documentElement, true);
                $payment_node->appendChild($imported_pain_node);

                break;
        }

        return $document->saveXML();
    }
}
