<?php

declare(strict_types=1);

namespace Bank\Clients\Exceptions;

class ClientDownloadException extends ClientException
{
}
