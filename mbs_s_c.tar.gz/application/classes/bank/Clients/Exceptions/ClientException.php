<?php

declare(strict_types=1);

namespace Bank\Clients\Exceptions;

use Exception;

class ClientException extends Exception
{
}
