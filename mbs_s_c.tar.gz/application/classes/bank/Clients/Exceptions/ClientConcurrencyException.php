<?php

declare(strict_types=1);

namespace Bank\Clients\Exceptions;

use Model_BankPaymentBatch;
use Throwable;

class ClientConcurrencyException extends ClientException
{
    public static function cannotAcquireBatchLock(Model_BankPaymentBatch $batch, ?Throwable $previous = null): self
    {
        return new self(sprintf(
            'Could not get batch sending lock for batch %d, it is probably already being sent.',
            $batch->getPrimaryKey()
        ), 0, $previous);
    }
}
