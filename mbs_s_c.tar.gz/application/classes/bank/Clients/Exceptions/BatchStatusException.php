<?php

declare(strict_types=1);

namespace Bank\Clients\Exceptions;

use Model_BankPaymentBatch;

class BatchStatusException extends ClientException
{
    public static function create(Model_BankPaymentBatch $batch): self
    {
        return new self(sprintf(
            'Batch %s has status "%s", not "Pending". Maybe it has already been sent?',
            $batch->reference,
            $batch->statusAsString()
        ));
    }
}
