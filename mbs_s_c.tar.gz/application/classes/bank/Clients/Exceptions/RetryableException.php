<?php

declare(strict_types=1);

namespace Bank\Clients\Exceptions;

interface RetryableException
{
}
