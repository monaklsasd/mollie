<?php

declare(strict_types=1);

namespace Bank\Clients;

use DateTime;
use DateTimeInterface;

final class RemoteFile
{
    /** @var DateTime */
    private $_createdDateTime;

    /** @var string */
    private $_filename;

    /** @var int */
    private $_filesize;

    /** @var string */
    private $_directory = "";

    public function getCreatedDateTime(): DateTimeInterface
    {
        return $this->_createdDateTime;
    }

    public function setCreatedDateTime(DateTimeInterface $createdDateTime): self
    {
        $this->_createdDateTime = $createdDateTime;

        return $this;
    }

    /**
     * Return just the base name, don't store any directory context here.
     */
    public function getFilename(): string
    {
        return $this->_filename;
    }

    public function setFilename($filename): self
    {
        $this->_filename = $filename;

        return $this;
    }

    public function getFilesize(): int
    {
        return $this->_filesize;
    }

    public function setFilesize(int $filesize): self
    {
        $this->_filesize = $filesize;

        return $this;
    }

    public function getDirectory(): string
    {
        return $this->_directory;
    }

    public function setDirectory(string $directory): self
    {
        $this->_directory = $directory;

        return $this;
    }
}
