<?php

use Core\Strings;
use League\Csv\Reader;

/**
 * Provides various operations on Bank Account numbers. The class
 * handles:
 *  - Regular Dutch accounts
 *  - IBAN/BIC accounts
 *  - International bank accounts
 */
class Bank_AccountHelper
{
    /**
     * Array of expected lengths of IBAN numbers by country.
     *
     * @const int[]
     *
     * @see https://www.nordea.com/Our+services/Cash+Management/Products+and+services/IBAN+countries/908462.html
     */
    public const IBAN_LENGTHS = [
        self::BELGIUM     => 16,
        self::GERMANY     => 22,
        self::NETHERLANDS => 18,
    ];

    /**
     * We can't add the following 4 countries to this untrusted list, because they don't have their own country code:
     * - Åland Islands   (FI - Finland)
     * - Azores          (PT - Portugal)
     * - Canary Islands  (ES - Spain)
     * - Madeira         (PT - Portugal)
     *
     * @see https://redmine.mollie.nl/issues/16922
     */
    public const UNTRUSTED_SEPA_COUNTRY_LIST_IBAN = [
        "GF", // French Guinea
        "GI", // Gibraltar
        "GP", // Guadeloupe
        "MQ", // Martinique
        "YT", // Mayotte
        "RE", // Réunion
        "RO", // Romania
        "BL", // Saint Barthélemy
        "MF", // Saint Martin (French part)
        "PM", // Saint Pierre and Miquelon
    ];

    /**
     * List from EPC List of SEPA Scheme Countries (v2.1 - june 2015) see link.
     *
     * @const array
     *
     * @see http://www.europeanpaymentscouncil.eu/index.cfm/knowledge-bank/epc-documents/epc-list-of-sepa-scheme-countries/epc409-09-epc-list-of-sepa-scheme-countries-v21-june-2015pdf/
     */
    public const FULL_SEPA_COUNTRY_LIST_IBAN = [
        "FI", // Åland Islands
        "AT", // Austria
        "PT", // Azores
        "BE", // Belgium
        "BG", // Bulgaria
        "ES", // Canary Islands
        "HR", // Croatia
        "CY", // Cyprus
        "CZ", // Czech Republic
        "DK", // Denmark
        "EE", // Estiona
        "FI", // Finland
        "FR", // France
        "GF", // French Guinea
        "DE", // Germany
        "GI", // Gibraltar
        "GR", // Greece
        "GP", // Guadeloupe
        "HU", // Hugary
        "IS", // Iceland
        "IE", // Ireland
        "IT", // Italy
        "LV", // Latvia
        "LI", // Liechtenstein
        "LT", // Lithuania
        "LU", // Luxembourgh
        "PT", // Madeira
        "MT", // Malta
        "MQ", // Martinique
        "YT", // Mayotte
        "MC", // Monaco
        "NL", // Netherlands
        "NO", // Norway
        "PL", // Poland
        "PT", // Portugal
        "RE", // Réunion
        "RO", // Romania
        "BL", // Saint Barthélemy
        "MF", // Saint Martin (French part)
        "PM", // Saint Pierre and Miquelon
        "SM", // San Marino
        "SK", // Slovakia
        "SI", // Slovenia
        "ES", // Spain
        "SE", // Sweden
        "CH", // Switzerland
        "GB", // United Kingdom
    ];

    /**
     * @see http://www.nbb.be/pub/09_00_00_00_00/09_06_00_00_00/09_06_02_00_00.htm
     * @see http://www.betaalvereniging.nl/wp-uploads/2013/07/BIC-lijst-NL.pdf
     *
     * BIC code 'DEUTNL2A' is added manually, see https://www.deutschebank.nl/nl/content/producten_en_services_services_iban_bic.html
     */
    public const BIC_CODES = [
        self::BELGIUM => [
            /** @see https://www.nbb.be/doc/be/be/protocol/r_list_of_codes_current.pdf */
            "AARBBEB1", //      Aareal Bank - Brussels Branch
            "ABERBE21", //      ABK Bank (@issue 20048)
            "ABERBE22", //      ABK Bank
            "ABNABE2A", //      ABN AMRO Bank N.V.
            "ABNABEBR", //      The Royal Bank of Scotland Plc, Belgium branch
            "ADIABE22", //      KBC Bank N.V . Business Center
            "ARSPBE22", //      Argenta Spaarbank (ASPA)
            "AXABBE22", //      AXA Bank Europe
            "BARBBEBB", //      Bank of Baroda
            "BBRUBEBB", //      ING België
            "BCDMBEBB", //      Banque Chaabi du Maroc
            "BCMCBEBB", //      Bancontact - Mister Cash NV/SA
            "BIBLBE21", //      BinckBank
            "BILLBEBB", //      Banque Internationale à Luxembourg
            "BKCHBEBB", //      Bank of China (Luxembourg) S.A., Brussels Branch
            "BKCPBEBB", //      BKCP BANK
            "BKIDBE22", //      Bank of India
            "BLUXBE41", //      Banque de Luxembourg
            "BMPBBEBB", //      Banca Monte Paschi Belgio
            "BNAGBEBB", //      Bank Nagelmackers
            "BNPABEBB", //      BNP Paribas
            "BNYMBEBB", //      The Bank of New York Mellon
            "BOFABE3X", //      Bank of America, National Association
            "BOTKBEBX", //      The Bank of Tokyo-Mitsubishi
            "BPOTBEB1", //      bpost bank
            "BSCHBEBB", //      Santander Benelux
            "BSCHBEBR", //      Banco Santander
            "BYBBBEBB", //      Byblos Bank Europe
            "CEKVBE81", //      Centrale Kredietverlening (C.K.V.)
            "CFFRBEB1", //      Crédit Foncier de France
            "CHASBEBX", //      JP Morgan Chase Bank
            "CITIBEBX", //      Citibank Europe Plc - Belgium Branch
            "CLIQBEB1", //      Banque Centrale de Compensation (Clearnet)
            "CMCIBEB1", //      Banque Transatlantique Belgium
            "COBABEBX", //      Commerzbank
            "CPHBBE75", //      Banque CPH
            "CREGBEBB", //      CBC Banque et Assurances
            "CRLYBEBB", //      Crédit Agricole Corporate & Investment Bank
            "CTBKBEBX", //      Beobank
            "CVMCBEBB", //      C A Indosuez Wealth (Europe)
            "DEGRBEBB", //      Banque Degroof Luxembourg
            "DELEBE22", //      Delen Private Bank
            "DEUTBEBE", //      Deutsche Bank AG
            "DHBNBEBB", //      Demir-Halk Bank (Nederland) (DHB)
            "DIERBE21", //      Dierickx, Leys & Cie Effectenbank
            "DNIBBE21", //      NIBC BANK
            "ENIBBEBB", //      Banque Eni
            "EPBFBEBB", //      EPBF
            "ETHIBEBB", //      OPTIMA BANK
            "EURBBE99", //      Europabank
            "FBHLBE22", //      CREDIT EUROPE BANK NV
            "FORDBE21", //      FCE Bank
            "FTNOBEB1", //      FORTUNEO BELGIUM
            "FTSBBE22", //      ABN AMRO Bank N.V.
            "FVLBBE2E", //      F. van Lanschot Bankiers
            "FVLBBE22", //      F. van Lanschot Bankiers
            "FXBBBEBB", //      FX4BIZ
            "GEBABEBB", //      BNP Paribas Fortis
            "GKCCBEBB", //      BELFIUS BANK
            "HABBBEBB", //      Habib Bank
            "HBKABE22", //      Record Bank
            "HSBCBEBB", //      HSBC Bank
            "ICBKBEBB", //      Industrial and Commercial Bank of China (Europe)
            "IRVTBEBB", //      The Bank of New York Mellon NV/SA
            "JPMGBEBB", //      J.P. Morgan International Bank Limited
            "JVBABE22", //      Bank J. V an Breda & C°
            "KEYTBEBB", //      Keytrade Bank
            "KREDBEBB", //      KBC Bank
            "LOCYBEBB", //      Lombard Odier (Europe)
            "MBWMBEBB", //      MeDirect Bank S.A.
            "MGTCBEBE", //      Euroclear Bank
            "MHCBBEBB", //      Mizuho Bank Nederland N.V. Brussels Branch
            "NBBEBEBB", //      Nationale Bank van België
            "NICABEBB", //      Crelan
            "PARBBEBZ", //      BNP Paribas Securities Services
            "PCHQBEBB", //      bpost
            "PRIBBEBB", //      Edmond de Rothschild (Europe)
            "PSABBEB1", //      PSA Finance
            "PUILBEBB", //      Puilaetco Dewaay Private Bankers
            "RABOBE22", //      Rabobank.be
            "RABOBE23", //      Coöperatieve Rabobank U.A.
            "RCBPBEBB", //      Rothschild & Cie Banque GCV
            "SBINBE2X", //      State Bank of India
            "SGABBEB2", //      Société Générale (Paris)
            "SGPBBE99", //      Société Générale Private Banking
            "SHIZBEBB", //      Shizuoka Bank (Europe)
            "SMBCBEBB", //      Sumitomo Mitsui Banking Corporation (SMBC)
            "SPAABE22", //      Crelan
            "TRIOBEBB", //      Triodos Bank
            "TUNZBEB1", //      Inogenico Financial Solutions
            "UBINBE22", //      Union Bank of India
            "UTWBBEBB", //      United Taiwan Bank
            "VDSPBE91", //      Volksdepositokas Spaarbank (VDK Spaarbank)
            "WAFABEBB", //      Attijariwafa bank Europe
        ],

        self::NETHERLANDS => [
            "ABNANL2A", //      ABN AMRO BANK N.V
            "AEGONL2U", //      AEGON BANK NV
            "ANAANL21", //      ALLIANZ NEDERLAND ASSET MANAGEMENT
            "ANDLNL2A", //      ANADOLUBANK NEDERLAND NV
            "ARBNNL22", //      ACHMEA RETAIL BANK N.V.
            "ARSNNL21", //      ARGENTA SPAARBANK NV
            "ARTENL2A", //      GE ARTESIA BANK
            "ASNBNL21", //      ASN BANK
            "ASRBNL2R", //      ASR BANK N.V.
            "ATBANL2A", //      AMSTERDAM TRADE BANK N.V
            "BBRUNL2X", //      ING BELGIE NV, BREDA BRANCH
            "BCDMNL22", //      BANQUE CHAABI DU MAROC
            "BCITNL2A", //      INTESA SANPAOLO S.P.A
            "BICKNL2A", //      BINCKBANK N.V.
            "BINKNL21", //      BINCKBANK N.V. PROF
            "BKCHNL2R", //      BANK OF CHINA
            "BKMGNL2A", //      BANK MENDES GANS N.V.
            "BLGWNL21", //      BLG WONEN
            "BNGHNL2G", //      NV BANK NEDERLANDSE GEMEENTEN
            "BNPANL2A", //      BNP PARIBAS S.A. THE NETH. BRANCH
            "BOFANLNX", //      BANK OF AMERICA N.A.
            "BOFSNL21", //      BANK OF SCOTLAND PCC AMSTERDAM BRANCH
            "BOTKNL2X", //      BANK OF TOKYO-MITSUBISHI UFJ
            "BUNQNL2A", //      BUNQ
            "CHASNL2X", //      JPMORGAN CHASE
            "CITCNL2A", //      CITCO BANK NEDERLAND
            "CITINL2X", //      CITIBANK INTERNATIONAL PLC
            "COBANL2X", //      COMMERZBANK AG
            "DEUTNL2N", //      DEUTSCHE BANK Nederland N.V.
            "DHBNNL2R", //      DEMIR-HALK BANK (NEDERLAND) N.V.
            "DLBKNL2A", //      DELTA LLOYD BANK NV
            "DNIBNL2G", //      NIBC BANK NV
            "FBHLNL2A", //      CREDIT EUROPE BANK N.V
            "FLORNL2A", //      DE NEDERLANDSCHE BANK N.V.
            "FRBKNL2L", //      FRIESLAND BANK N.V.
            "FRGHNL21", //      FRIESCH GRONINGSE HYPOTHEEK BANK
            "ABNANL2A", //      ABN AMRO BANK N.V. voormalig FORTIS BANK NEDERLAND N.V.
            "FVLBNL22", //      F.VAN LANSCHOT BANKIERS N.V.
            "GILLNL2A", //      THEODOOR GILISSEN N.V.
            "HANDNL2A", //      (SVENSKA) HANDELSBANKEN AB
            "HHBANL22", //      HOF HOORNEMAN BANKIERS
            "HSBCNL2A", //      HSBC BANK PLC.
            "ICBKNL2A", //      INDUSTRIAL AND COMMERCIAL BANK OF CHINA
            "INGBNL2A", //      ING BANK N.V.
            "INSINL2A", //      INSINGER DE BEAUFORT NV
            "ISBKNL2A", //      ISBANK
            "KABANL2A", //      YAPI KREDI BANK NEDERLAND NV
            "KASANL2A", //      KAS BANK N.V.
            "KNABNL2H", //      KNAB
            "KOEXNL2A", //      KOREA EXCHANGE BANK
            "KREDNL2X", //      KBC BANK NEDERLAND N.V.
            "LOCYNL2A", //      LOMBARD ODIER DARIER HENTSCH & CIE
            "LOYDNL2A", //      LLOYDS TSB BANK PLC
            "LPLNNL2F", //      LEASEPLAN CORPORATION NV
            "MLLENL21", //      MOLLIE BANK B.V.
            "MHCBNL2A", //      MIZUHO CORPORATE BANK NEDERLAND N.V
            "NNBANL2G", //      NATIONALE-NEDERLANDEN BANK N.V.
            "NWABNL2G", //      NEDERLANDSE WATERSCHAPSBANK N.V.
            "OVBNNL22", //      LEVOB BANK N.V.
            "RABONL2U", //      RABOBANK GROEP
            "RBOSNL2A", //      ROYAL BANK OF SCOTLAND
            "RBRBNL21", //      REGIOBANK
            "SNSBNL2A", //      SNS BANK N.V
            "SOGENL2A", //      SOCIETE GENERALE
            "STALNL2G", //      STAALBANKIERS N.V
            "TEBUNL2A", //      THE ECONOMY BANK N.V.
            "TRIONL2U", //      TRIODOS BANK N.V
            "UBSWNL2A", //      UBS BANK (NETHERLANDS) BV
            "UGBINL2A", //      GARANTIBANK INTERNATIONAL N.V.
            "VOWANL21", //      VOLKSWAGEN BANK
            "ZWLBNL21", //      ZWITSERLEVENBANK

            /*
             * Should be below DEUTNL2N, because self::guess_bic_nl() loops over all BIC's from top to bottom, and DEUTNL2N is the correct BIC.
             */
            "DEUTNL2A", //      DEUTSCHE BANK AG
        ],
    ];

    /**
     * You suck banks!
     *
     * @const string[]
     */
    public const BLACKLISTED_SEPA_BIC_CODES = [
        "BDCHBE22", // Deutsche Bank wordt Deutsche Bank (DEUTBEBE). https://www.deutschebank.be/nl/news-db-2-entiteiten-belgie-fuseren.html (26-11-2012)
        "CIMMCHGG", // C.I.M. Banque te GENEVA
        "ESBCHR22", // ERSTE&STEIERMÄRKISCHE BANK D.D te CROATIA
        "FRBKNL2L", // FRIESLAND BANK (acquired by Rabobank April 2012).
        "PSTBNL21", // POSTBANK N.V. (SUBSIDIARY OF ING BANK N.V.) (moet omgezet worden naar INGBNL2A)
        "BKCPBEB1BKB", // CREDIT PROFESSIONNEL SA BEROEPSKREDIET NV (Geldig tot 22 september 2014. https://www.bkcpbank.be/faq/sepa)
    ];

    /**
     * Database with the Belgian BICs by BBAN prefix.
     *
     * @see https://www.nbb.be/nl/betalingssystemen/betalingsstandaarden/bankidentificatiecodes
     */
    public const BELGIAN_BBAN_BIC_LOOKUP_FILE = MOLLIE_RESOURCE_PATH . "/bank/belgium_bban_bic_lookup.csv";
    private const BELGIUM                     = 'BE';
    private const GERMANY                     = 'DE';
    private const NETHERLANDS                 = 'NL';

    /** @var array|null */
    private static $belgium_bban_bic_lookup;

    /**
     * Nicely format an IBAN number.
     *
     * @param $iban string
     *
     * @return string
     */
    public static function format_iban($iban)
    {
        if (empty($iban)) {
            return "";
        }

        // Cut in blocks of four, upper everything.
        $iban = mb_strtoupper($iban);

        return implode(' ', str_split($iban, 4));
    }

    /**
     * Validate the given IBAN bank account number. Does not guarantee that the
     * given IBAN bank acccount actually exists, only that the given number is valid.
     *
     * A valid IBAN consists of:
     *    - maximum of 32 characters
     *    - A valid country code
     *    - Two valid checksum digits
     *    - A so-called BBAN
     *
     * More info at http://en.wikipedia.org/wiki/International_Bank_Account_Number#Validating_the_IBAN
     *
     * @param Model_Customer_Bankaccount|string $iban
     *
     * @return bool
     */
    public static function valid_iban($iban)
    {
        $iban = mb_strtoupper((string)$iban);

        if (!preg_match('~^(?P<country_code>[A-Z]{2})(?P<check_digits>[0-9]){2}~', $iban, $matches)) {
            return false;
        }

        if (!Helper_Iso_7064::validate($iban)) {
            // Checksum mismatch
            return false;
        }

        /*
         * Finally, the length should match the expected length.
         *
         * @issue 16127
         */
        if (array_key_exists($matches['country_code'], self::IBAN_LENGTHS) && strlen($iban) != self::IBAN_LENGTHS[$matches['country_code']]) {
            return false;
        }

        return true;
    }

    /**
     * Is the IBAN part of SEPA?
     *
     * @param $iban
     *
     * @return bool
     */
    public static function valid_sepa_iban($iban)
    {
        if (!self::valid_iban($iban)) {
            return false;
        }

        return in_array(static::get_country_from_iban($iban), static::FULL_SEPA_COUNTRY_LIST_IBAN);
    }

    /**
     * Extract the country code from the IBAN. Returns an ISO 3166-1 alpha-2 code.
     *
     * @param string $iban
     *
     * @return string|null
     */
    public static function get_country_from_iban($iban)
    {
        if (!self::valid_iban($iban)) {
            return null;
        }

        return mb_strtoupper(mb_substr($iban, 0, 2));
    }

    /**
     * @param string $iban_number
     *
     * @return string|null
     */
    public static function guess_bic($iban_number)
    {
        if ($bic = static::guess_bic_nl($iban_number)) {
            return $bic;
        }

        if ($bic = static::guess_bic_be($iban_number)) {
            return $bic;
        }

        return null;
    }

    /**
     * Try to guess the BIC code from an IBAN number. Works only for Dutch IBAN numbers.
     *
     * @param $iban_number
     *
     * @return string|null
     */
    public static function guess_bic_nl($iban_number)
    {
        if (stripos($iban_number, self::NETHERLANDS) !== 0) {
            return null;
        }

        foreach (self::BIC_CODES[self::NETHERLANDS] as $bic_code) {
            $bic_data   = self::expand_bic_data($bic_code);
            $iban_regex = "!^" . preg_quote($bic_data["country_code"], "!") . "\\d{2}" . preg_quote($bic_data["bank_code"], "!") . "!i";

            if (preg_match($iban_regex, $iban_number) && self::valid_bic($bic_code)) {
                return $bic_code;
            }
        }

        return null;
    }

    /**
     * Try to guess the BIC code from an IBAN number. Works only for Belgian IBAN numbers.
     *
     * @param $iban_number
     *
     * @return string|null
     */
    public static function guess_bic_be($iban_number)
    {
        if (stripos($iban_number, self::BELGIUM) !== 0) {
            return null;
        }

        // IBAN:   BE54719400092697
        // prefix: ----^^^---------
        $prefix = substr($iban_number, 4, 3);

        return static::get_belgian_bic_by_prefix($prefix);
    }

    /**
     * Validate the given BIC code. Does not guarantuee the given BIC code actually
     * corresponds to a valid bank, only that the BIC code matches the defined pattern.
     *
     * @param string $bic
     *
     * @return bool
     */
    public static function valid_bic($bic)
    {
        return self::expand_bic_data($bic) !== false;
    }

    /**
     * Is a BIC code accepted for a SEPA transfer?
     *
     * @param $bic
     *
     * @return bool
     */
    public static function valid_sepa_bic($bic)
    {
        if (!$expanded = self::expand_bic_data($bic)) {
            return false;
        }

        if (!in_array($expanded["country_code"], self::FULL_SEPA_COUNTRY_LIST_IBAN)) {
            return false;
        }

        if (in_array(mb_strtoupper($bic), self::BLACKLISTED_SEPA_BIC_CODES)) {
            return false;
        }

        return true;
    }

    /**
     * Returns TRUE if the BIC matches the account number and both are valid (according to valid_bic and valid_iban).
     *
     * @param string $bic
     * @param string $iban
     *
     * @return bool
     */
    public static function check_bic_matches_iban($bic, $iban)
    {
        // Check for valid BIC and IBAN
        if (!self::valid_bic($bic) || !self::valid_iban($iban)) {
            return false;
        }

        // Check country matches
        $iban_country = mb_strtoupper(mb_substr($iban, 0, 2));
        $bic_data     = self::expand_bic_data($bic);

        if ($bic_data['country_code'] !== $iban_country) {
            return false;
        }

        // Check if given BIC matches guessed BIC, ignore branch codes (optional last 3 characters)
        $guessed_bic = self::guess_bic($iban);

        if ($guessed_bic && $guessed_bic !== substr($bic, 0, 8)) {
            return false;
        }

        return true;
    }

    /**
     * Validate the given BIC code. Returns components of BIC components (including ISO 3166-1 alpha 2 country code)
     *
     * @param string $bic
     *
     * @return array with BIC components: bank_code, country_code,
     *               location_code, branch_code(optional) or FALSE
     */
    public static function expand_bic_data($bic)
    {
        $bic = mb_strtoupper($bic);

        $match_result = preg_match(
            '~^
				(?P<bank_code>[A-Z]{4})
				(?P<country_code>[A-Z]{2})
				(?P<location_code>[A-Z2-9][A-NP-Z0-9])
				(?P<branch_code>[A-Z0-9]{3})?
			$~ix',
            $bic,
            $matches
        );

        if ($match_result == 0) {
            return false;
        }

        // It should translate the code to the name of the region, if it returns the same, it's invalid.
        if (Locale::getDisplayRegion('-' . $matches['country_code'], 'en') === $matches['country_code']) {
            return false;
        }

        // Validate without the branch code. Branch code is optional 'XXX' for primary office.
        if (array_key_exists($matches['country_code'], self::BIC_CODES)) {
            $without_branch_code = "{$matches['bank_code']}{$matches['country_code']}{$matches['location_code']}";

            if (!in_array($without_branch_code, self::BIC_CODES[$matches['country_code']])) {
                return false;
            }
        }

        return [
            'bank_code'     => $matches['bank_code'],
            'country_code'  => $matches['country_code'],
            'location_code' => $matches['location_code'],
            'branch_code'   => $matches['branch_code'] ?? '',
        ];
    }

    /**
     * Convert an IBAN number to a domestic number. Works only for Dutch bank accounts.
     *
     * @param $iban_number
     *
     * @return string|null
     */
    public static function iban_to_domestic($iban_number)
    {
        if (self::get_country_from_iban($iban_number) != \Core\Country::NETHERLANDS) {
            /*
             * Not a Dutch bank account.
             */
            return null;
        }

        return ltrim(substr($iban_number, -9), "0");
    }

    /**
     * Check if the given domestic number and IBAN number are for the same bank account. Works only for Dutch bank accounts.
     *
     * @param $domestic_number
     * @param $iban_number
     *
     * @return bool
     */
    public static function domestic_equals_iban($domestic_number, $iban_number)
    {
        if (self::get_country_from_iban($iban_number) != \Core\Country::NETHERLANDS) {
            /*
             * Not a Dutch bank account.
             */
            return false;
        }

        $domestic_number = preg_quote($domestic_number, "/");

        return preg_match("/^NL\\d{2}[A-Z]{4}0*{$domestic_number}$/i", $iban_number);
    }

    /**
     * Convert a Belgium bank account number to an IBAN number.
     *
     * @param $bban
     *
     * @return string
     */
    public static function convert_belgium_to_iban($bban)
    {
        if (!self::valid_belgium_bban($bban)) {
            return null;
        }

        $bban = sprintf("%012d", ltrim($bban, "0"));

        return Helper_Iso_7064::generate(self::BELGIUM, $bban);
    }

    /**
     * Get the BIC code for a Belgium ba
     *
     * @param $bban
     *
     * @return string|null
     */
    public static function get_bic_code_from_belgium($bban)
    {
        if (!self::valid_belgium_bban($bban)) {
            return null;
        }

        $prefix = substr($bban, 0, 3);

        return static::get_belgian_bic_by_prefix($prefix);
    }

    public static function get_belgian_bic_by_prefix(string $prefix): ?string
    {
        if (empty(self::$belgium_bban_bic_lookup)) {
            $reader = Reader::createFromPath(self::BELGIAN_BBAN_BIC_LOOKUP_FILE);

            foreach ($reader->getRecords() as $record) {
                self::$belgium_bban_bic_lookup[] = $record;
            }
        }

        $offset = (int)$prefix + 2;

        if (!isset(self::$belgium_bban_bic_lookup[$offset][0]) || self::$belgium_bban_bic_lookup[$offset][0] !== $prefix) {
            /* WTF? The datafile is correctly indexed, this should not happen. */
            return null;
        }

        $bic = preg_replace('/\s+/', '', self::$belgium_bban_bic_lookup[$offset][1]);
        $bic = Strings::removeSuffix($bic, 'XXX');

        if (self::valid_bic($bic)) {
            return $bic;
        }

        return null;
    }

    /**
     * Een Belgisch rekeningnummer (Basic Bank Account Number of BBAN) bestaat uit 12 cijfers, verdeeld in drie groepen
     * gescheiden door liggende streepjes: een groep van 3 cijfers, een groep van 7 cijfers en een groep van 2 cijfers,
     * bijvoorbeeld 091-0122401-16:
     *
     * * het protocolnummer: een eerste blok van drie cijfers, die informatie geven over de bank (zo geeft de Bank van
     *   de Post rekeningnummers uit die beginnen met 000).
     * * een blok van zeven cijfers, het eigenlijke rekeningnummer bij die bank.
     * * een laatste blok met twee controlecijfers, deze twee cijfers zijn de rest (modulo) bij deling door 97 van het
     *   getal dat gevormd wordt door de 10 voorafgaande cijfers. (indien de rest 0 is, wordt 97 als controlegetal
     *   gebruikt).
     *
     * @param $bban
     *
     * @return bool
     */
    public static function valid_belgium_bban($bban)
    {
        $bban = (string)$bban;

        if (strlen($bban) !== 12 || !ctype_digit($bban)) {
            return false;
        }

        $check_digits   = substr($bban, -2);
        $account_number = substr($bban, 0, -2);

        // TODO: replace round with third argument (scale = 0) after update to PHP 7.3
        $expected_check_digit = sprintf('%02d', round(bcmod($account_number, 97)) ?: 97);

        return $check_digits === $expected_check_digit;
    }

    /**
     * Validate the given foreign bank account number. Does not guarantuee the given account number does actually
     * exist, only that it is a reasonable number.
     * Currently, we only check the length (> 0) and characters (numeric) of the bank account.
     *
     * @param string $foreign_number
     *
     * @return bool
     */
    public static function valid_foreign($foreign_number)
    {
        if (strlen($foreign_number) === 0) {
            return false;
        }

        if (preg_match('/[^\d]+/', $foreign_number)) {
            return false;
        }

        return true;
    }
}
