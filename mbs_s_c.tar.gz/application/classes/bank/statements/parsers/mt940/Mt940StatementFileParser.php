<?php

namespace Bank\Statements\Parsers\Mt940;

use Bank\Statements\Balance;
use Bank\Statements\BankToCustomerMessage;
use Bank\Statements\Exceptions\InvalidBalanceCurrencyException;
use Bank\Statements\Exceptions\InvalidBalanceDateExceptions;
use Bank\Statements\Parsers\Exceptions\CannotOpenFileException;
use Bank\Statements\Parsers\Mt940\Exceptions\InvalidTagException;
use Bank\Statements\Parsers\Mt940\Exceptions\InvalidTagOrderException;
use Bank\Statements\StatementFileParser;
use Bank\Statements\StatementHeader;
use Bank\Statements\StatementMessage;
use Bank\Statements\StatementTransaction;
use Bank\Statements\StatementTransactionBuilder;
use Bank_AccountHelper;
use Bank_DateUtil;
use Bank_Swift_Codes;
use Bank_Swift_TransactionTypes;
use BankAccounts\BankAccountRepository;
use Core\Country;
use Core\Time\Clock;
use Exception;
use Generator;
use Helper_Banktransaction_Matching;
use Model\Transaction\TransactionTags;
use Money\Currency;
use Psr\Http\Message\StreamInterface;
use function Core\Money\money_from_string;
use function GuzzleHttp\Psr7\readline;
use function strlen;

/**
 * Due to memory concerns, this object does not build a stateful Statement object. This is because the Statement
 * object will then be holding over 100k transactions at once. Therefore, this class acts as a Statement object itself
 * by implementing the Statement interface. It work as follows:
 *
 * 1. Upon creation, this class performs a first pass scan of the MT940 file (passed in the constructor).
 * 2. This first pass stores the file offsets to the Header (always 0), opening balance, first transaction and closing
 *    balance.
 * 3. Then the header, opening balance and closing balance are stored.
 * 4. The yieldTransactions method is implemented by opening the file at the stored offset to the first transaction
 *    and then yielding each transaction as it is found in the file.
 *
 * @used-by \Bank\Statements\FileParserFactory
 */
class Mt940StatementFileParser implements StatementFileParser
{
    public const FILE_POINTER_OFFSET_HEADER          = 'header_offset';
    public const FILE_POINTER_OFFSET_OPENING_BALANCE = 'opening_balance_offset';
    public const FILE_POINTER_OFFSET_TRANSACTIONS    = 'transactions_offset';
    public const FILE_POINTER_OFFSET_CLOSING_BALANCE = 'closing_balance_offset';

    /** @var StatementTransactionBuilder */
    private $statement_transaction_builder;

    /** @var StreamInterface */
    private $mt940_stream;

    /** @var StatementHeader */
    private $statement_header;

    /** @var Balance */
    private $opening_balance;

    /** @var Balance */
    private $closing_balance;

    /** @var Currency */
    private $currency;

    /**
     * Holds the offsets for the header, opening balance, transactions and closing balance.
     * key: FILE_POINTER_OFFSET_...
     * value: offset (int)
     *
     * @var int[]
     */
    private $file_pointer_offsets = [
        self::FILE_POINTER_OFFSET_HEADER => 0, // Header is always at the beginning of the file
    ];

    /** @var BankAccountRepository */
    private $bank_account_repository;

    public function __construct(
        StatementTransactionBuilder $statement_transaction_builder,
        BankAccountRepository $bank_account_repository
    ) {
        $this->statement_transaction_builder = $statement_transaction_builder;
        $this->bank_account_repository       = $bank_account_repository;
    }

    /**
     * @throws CannotOpenFileException
     * @throws InvalidBalanceCurrencyException
     * @throws InvalidBalanceDateExceptions
     * @throws InvalidTagException
     * @throws \BankAccounts\Exceptions\BankAccountNotFoundException
     */
    public function parse(StreamInterface $fileStream): BankToCustomerMessage
    {
        $this->mt940_stream = $fileStream;

        $this->scanFileForTagOffsets();
        $this->verifyTagOffsetsHaveBeenSet();

        $this->statement_header = $this->readStatementHeader();
        $this->opening_balance  = $this->readOpeningBalance();
        $this->closing_balance  = $this->readClosingBalance();
        $this->currency         = $this->opening_balance->getAmount()->getCurrency();

        if ($this->opening_balance->getBalanceDateUnixTimestamp() > $this->closing_balance->getBalanceDateUnixTimestamp()) {
            throw new InvalidBalanceDateExceptions();
        }

        $closing_currency = $this->closing_balance->getAmount()->getCurrency();

        if (!$this->currency->equals($closing_currency)) {
            throw new InvalidBalanceCurrencyException(
                sprintf(
                    'The start balance currency "%s" differs from the closing balance currency "%s"',
                    $this->currency->getCode(),
                    $closing_currency->getCode()
                )
            );
        }

        $bankAccount = $this->bank_account_repository->getByIbanOrAccountNumber(
            $this->statement_header->getAccountNumber()
        );

        $statementDate = Clock::createDateTimeFromTimestamp(
            $this->closing_balance->getBalanceDateUnixTimestamp()
        );

        return new StatementMessage(
            $this->statement_header->getStatementNumber(),
            $this->statement_header->getSequenceNumber(),
            $this->opening_balance,
            $this->closing_balance,
            $this->statement_header->getReference(),
            $statementDate,
            $bankAccount,
            $this->yieldTransactions()
        );
    }

    /**
     * @throws CannotOpenFileException
     * @throws InvalidTagException
     */
    private function scanFileForTagOffsets()
    {
        $this->mt940_stream->rewind();

        while (!$this->mt940_stream->eof()) {
            [$tag, $tag_offset] = $this->scanNextTag();

            $this->rememberTagOffset($tag, $tag_offset);
        }
    }

    /**
     * Try to read a complete MT940 tag from the stream (can be multi-line)
     *
     * @throws Exception
     */
    private function readNextTag(): Tag
    {
        [$tag, $tag_offset] = $this->scanNextTag();

        return $tag;
    }

    /**
     * Returns an array containing the tag at the first position and the offset to the tag
     * in the second position.
     *
     * @throws InvalidTagException
     */
    private function scanNextTag(): array
    {
        $tag_offset = $this->mt940_stream->tell();

        /* Read the first line, this contains the Tag (":61:" et cetera). */
        $buffer = readline($this->mt940_stream);

        while (!$this->mt940_stream->eof() && $line = readline($this->mt940_stream)) {
            if (preg_match("!^:(\\d{2}[a-z]?):(.*)!si", $line)) { // Check if this is a new tag.
                /* Move back, just read line is a new tag! */
                $this->mt940_stream->seek($this->mt940_stream->tell() - strlen($line));

                break;
            }
            $buffer .= $line;
        }

        if (preg_match("!^:(\\d{2}[a-z]?):(.*)!si", $buffer, $matches)) {
            $tag = new Tag($matches[1], rtrim($matches[2], "\r\n"));

            return [$tag, $tag_offset];
        }

        throw new InvalidTagException("I don't know what happened! Buffer was: \"{$buffer}\".");
    }

    /**
     * Stores the offset from the start of the file to the first occurrence of the tag.
     *
     * @param int $tag_offset
     *
     * @throws InvalidTagOrderException
     */
    private function rememberTagOffset(Tag $tag, $tag_offset)
    {
        $file_pointer_offset_constant = $this->getFilePointerOffsetConstantForTagCode($tag->getCode());

        if ($tag->hasCode(Tag::TRANSACTION_DESCRIPTION) && !$this->firstTransactionHasBeenFound()) {
            /*
             * We've encountered a TRANSACTION_DESCRIPTION (86) tag before we've seen any
             * TRANSACTION (61) tags. That's not supposed to happen
             */
            throw new InvalidTagOrderException("Tag 86 discovered without preceding Tag 61");
        }

        if ($file_pointer_offset_constant === null) {
            return;
        }

        if (isset($this->file_pointer_offsets[$file_pointer_offset_constant])) {
            return;
        }

        $this->file_pointer_offsets[$file_pointer_offset_constant] = $tag_offset;
    }

    /**
     * @param string $tag_code
     *
     * @return int|null
     */
    private function getFilePointerOffsetConstantForTagCode($tag_code)
    {
        switch ($tag_code) {
            case Tag::OPENING_BALANCE:
                return self::FILE_POINTER_OFFSET_OPENING_BALANCE;

            case Tag::CLOSING_BALANCE:
                return self::FILE_POINTER_OFFSET_CLOSING_BALANCE;

            case Tag::TRANSACTION:
                return self::FILE_POINTER_OFFSET_TRANSACTIONS;
        }

        return null;
    }

    private function firstTransactionHasBeenFound()
    {
        return isset($this->file_pointer_offsets[self::FILE_POINTER_OFFSET_TRANSACTIONS]);
    }

    private function verifyTagOffsetsHaveBeenSet()
    {
        if (!isset($this->file_pointer_offsets[self::FILE_POINTER_OFFSET_OPENING_BALANCE])) {
            throw new InvalidBalanceDateExceptions("No opening balance tag found");
        }

        if (!isset($this->file_pointer_offsets[self::FILE_POINTER_OFFSET_CLOSING_BALANCE])) {
            throw new InvalidBalanceDateExceptions("No closing balance tag found");
        }
    }

    /**
     * @throws InvalidTagException
     *
     * @return StatementHeader
     */
    private function readStatementHeader()
    {
        $this->setFilePointerOffset(self::FILE_POINTER_OFFSET_HEADER);

        $statement_header = new StatementHeader();

        $this->skipInternetBankierenHeaders();

        // Should be in this order: 20, 25, 28.
        while (!$this->mt940_stream->eof()) {
            $tag = $this->readNextTag();

            switch ($tag->getCode()) {
                case Tag::HEADER_REFERENCE:
                    $statement_header->setReference($tag->getValue());

                    break;

                case Tag::HEADER_ACCOUNT_NUMBER:
                    $statement_header->setAccountNumber($this->getBankaccountFromAccountNumberTag($tag->getValue()));

                    break;

                case Tag::HEADER_STATEMENT_AND_SEQUENCE_NUMBER:
                case Tag::HEADER_STATEMENT_AND_SEQUENCE_NUMBER_ALT:
                    $statement_and_sequence_number = explode("/", $tag->getValue(), 2);
                    $statement_number              = $statement_and_sequence_number[0];
                    $sequence_number               = $statement_and_sequence_number[1] ?? "0";

                    $statement_header->setStatementNumber($statement_number);
                    $statement_header->setSequenceNumber($sequence_number);

                    break 2;
            }
        }

        return $statement_header;
    }

    /**
     * @param int $file_pointer_offset_constant
     */
    private function setFilePointerOffset($file_pointer_offset_constant)
    {
        if (!isset($this->file_pointer_offsets[$file_pointer_offset_constant])) {
            return;
        }

        $offset = $this->file_pointer_offsets[$file_pointer_offset_constant];

        $this->mt940_stream->seek($offset);
    }

    /**
     * Forward the position of the file pointer to past the headers of Internet Bankieren. MT940 files can also be
     * downloaded from Internet Bankieren instead of transferred through ADOL. We must support these files too.
     */
    private function skipInternetBankierenHeaders()
    {
        foreach ([
            "ABNANL2A\r\n940\r\nABNANL2A\r\n",
            "0000 01INGBNL2AXXXX00001\r\n0000 01INGBNL2AXXXX00001\r\n940 00\r\n",
        ] as $ib_headers) {
            $first_bytes = $this->mt940_stream->read(strlen($ib_headers));

            if ($first_bytes !== $ib_headers) {
                /* Headers encountered were not from Internet Bankieren, redirect back to beginning of file. */
                $this->mt940_stream->rewind();
            } else {
                return;
            }
        }
    }

    /**
     * @param string $value
     *
     * @return string
     */
    private function getBankaccountFromAccountNumberTag($value)
    {
        if (substr($value, -3) === "EUR") {
            /*
             * In case of ING, the :25: tag can contain the currency as well.
             */
            return substr($value, 0, -3);
        }

        return $value;
    }

    /**
     * Due to memory performance issues with building a Statement object with 100k+ StatementTransaction objects, there
     * is only a yieldTransactions method defined on this interface. This allows FileParserFactory classes
     *
     * @return Generator|StatementTransaction[]
     */
    private function yieldTransactions(): Generator
    {
        $this->setFilePointerOffset(self::FILE_POINTER_OFFSET_TRANSACTIONS);

        $transaction_data = [];

        while (!$this->mt940_stream->eof()) {
            $tag = $this->readNextTag();

            switch ($tag->getCode()) {
                case Tag::TRANSACTION:
                    $transaction_data = $this->processTransactionTag($tag->getValue());

                    $account_number = $this->statement_header->getAccountNumber();

                    if ($transaction_data['amount'] === 0.0 && \Core\Strings::startsWith($account_number, Country::BELGIUM) && substr($account_number, 4, 3) == "363") {
                        /*
                         * ING Belgium bank accounts statments contain a line that is € 0 and contains some text to
                         * indicate the last value.
                         *
                         * 363 is one of the ING Belgium B.V. BBAN prefixes.
                         */
                        $this->readNextTag(); // Skip the description, then break.
                        break;
                    }

                    break;

                case Tag::TRANSACTION_DESCRIPTION:
                    $transaction      = $this->processTransactionDescriptionTag($tag->getValue(), $transaction_data);
                    $transaction_data = [];

                    yield $transaction;

                    break;

                default:
                    break 2; // Break from the while loop, we've read all the transaction
            }
        }
    }

    /**
     * @throws InvalidTagException
     */
    private function processTransactionTag(string $line): array
    {
        $result = preg_match(
            "~
			^(?<value_date>[0-9]{6})
			 (?<entry_date>[0-9]{4})? # Apparently optional with, logical as statement date is already included at the top of the file
			 (?<debit_ind>C|D|RC|RD)
			 (?<funds_code>[a-z])?
			 (?<amount>[0-9,]{1,15})
			 (?<bai_code>[NSF])
			 (?<mutation_code>[0-9a-z]{3})
			 (?<additional>[a-z0-9 :\r\n/-]{0,66})
			~ix",
            $line,
            $line_items
        );

        // Our regexp didn't match. Panic.
        if (!$result) {
            throw new InvalidTagException("This TAG61 seems malformed: " . $line);
        }

        $amount = str_replace(',', '.', $line_items['amount']);
        $amount *= ($line_items['debit_ind'] == 'D') ? -1 : 1;

        $value_date_unix = Bank_DateUtil::convertYYMMDDToUnixtime($line_items['value_date']);

        /*
         * ING MT940 files miss explicit entry dates for each transaction. Copy from the value date.
         */
        $entry_date_unix = $line_items['entry_date'] ? Bank_DateUtil::convertMMDDToUnixtime($line_items['entry_date'], $value_date_unix) : $value_date_unix;

        $transaction_data = [
            'value_date_unix' => $value_date_unix,
            'entry_date_unix' => $entry_date_unix,
            'debit_ind'       => $line_items['debit_ind'],
            'funds_code'      => $line_items['funds_code'],
            'amount'          => $amount,
            'bai_code'        => $line_items['bai_code'],
            'mutation_code'   => $line_items['mutation_code'],
            'additional'      => $line_items['additional'],

            // To be filled in by 86 tag data:
            'bankaccount' => '',
            'description' => '',
        ];

        $transaction_data["additional"] = preg_replace("!\\s*NONREF\\s*!", "", $transaction_data["additional"]);

        if ($transaction_data["additional"] === "EREF") {
            $transaction_data["additional"] = null;
        }

        return $transaction_data;
    }

    private function processTransactionDescriptionTag(string $line, array $previous_transaction_data): StatementTransaction
    {
        if (empty($previous_transaction_data)) {
            throw new InvalidTagOrderException(sprintf(
                "Can't have a 86 tag without a preceeding 61 tag (on position %d, line was: \"%s\").",
                $this->mt940_stream->tell(),
                $line
            ));
        }

        $transaction_data = $previous_transaction_data;

        /* The 86 tag has multiple lines. Usually in this order:
         *
         * :86: [BANK ACCOUNT NR] [ACCOUNT HOLDER NAME]
         * [ACCOUNT HOLDER ADDRESS STREET]
         * [ACCOUNT HOLDER ADDRESS POSTALCODE] [ACCOUNT HOLDER ADDRESS CITY]
         * [FURTHER DESCRIPTION]
         *
         * However, there are many variants on what lines are be available.
         */

        $description = $line;

        if (!count(explode("\r\n", $line))) {
            throw new InvalidTagException("Invalid date for TAG_86");
        }

        /*
         * Parse bank account number
         */
        if (preg_match('~^(GIRO)?\s*([0-9\.]+)~i', $line, $bankaccount_matches)) {
            $transaction_data['bankaccount'] = (!empty($bankaccount_matches[1]) ? 'P' : '') . $bankaccount_matches[2];
            $transaction_data['bankaccount'] = str_replace('.', '', $transaction_data['bankaccount']);

            $description = trim(substr($description, strlen($bankaccount_matches[0])));
            $lines       = explode("\r\n", $description);

            /*
             * Convert Belgian bank account numbers to IBAN + BIC here. Note that the original number can be recovered
             * by throwing away the "BE" + two check digits from the IBAN.
             */
            if (Bank_AccountHelper::valid_belgium_bban($transaction_data["bankaccount"])) {
                $belgian_iban = Bank_AccountHelper::convert_belgium_to_iban($transaction_data["bankaccount"]);
                $belgian_bic  = Bank_AccountHelper::get_bic_code_from_belgium($transaction_data["bankaccount"]);

                if ($belgian_bic && $belgian_iban) {
                    $transaction_data["bankaccount"] = $belgian_iban;
                    $transaction_data["bic"]         = $belgian_bic;
                }
            }

            /*
             * The first line is usually the account name, split it of and save separately. Second line is then consumer
             * location, then the real description starts.
             *
             * Do not apply this to Mister Cash transfers from the BE66719400067843 account.
             */
            if (count($lines) >= 3 && strpos($lines[0], ", BANKSYS") === false) {
                $transaction_data['account_name'] = trim(array_shift($lines));
                $description                      = implode("\r\n", $lines);
            }
        }

        /*
         * Check for Cash Pooling Transactions.
         */
        if (empty($transaction_data["bankaccount"]) && preg_match(
            "!^CBTB.*FROM\\s+(?P<from_account>[A-Z0-9]+)\\s+EUR\\s+TO\\s+(?P<to_account>[A-Z0-9]+)\\s+EUR!s",
            $description,
            $matches
        )
        ) {
            if ($transaction_data["amount"] < 0) {
                $transaction_data["bankaccount"] = $matches["to_account"];
            } else {
                $transaction_data["bankaccount"] = $matches["from_account"];
            }
            $transaction_data["bic"] = Bank_AccountHelper::guess_bic($transaction_data["bankaccount"]);
        }

        /*
         * STG MOLLIE PAYMENTS
         * REKNR BEGUNSTIGDE VERVALLEN      OORSPR. NUMMER CREDIT 0130904724
         * WEBWINKEL                        CREDITNOTA 2012.38536
         * KLANT ID 633827
         */
        if (preg_match('~OORSPR\. NUMMER CREDIT 0*(?P<accountnumber>\d+)~', $line, $bankaccount_matches)) {
            // In this case, tegenrekening is empty or is set to one of our own accounts.
            if (empty($transaction_data["bankaccount"]) || in_array(
                $transaction_data["bankaccount"],
                \BankAccounts\BankAccountRepository::getInstance()->getAllMollieRelatedIbansAndAccountNumbers()
            )
            ) {
                $transaction_data['bankaccount'] = $bankaccount_matches["accountnumber"];
            }
        }

        $this->parseDescription($description, $transaction_data);

        /*
         * SWIFT payments are marked up strangely in MT940, fix here.
         */
        if ($transaction_data["additional"] == "Outward Payment") {
            if (empty($transaction_data["bankaccount"])) {
                if (preg_match(
                    "!^(?P<account_number>NL\\d{2}[A-Z\\d]{14})!",
                    $transaction_data["description"],
                    $matches
                )) {
                    $transaction_data["bankaccount"] = $matches["account_number"];
                    $transaction_data["bic"]         = Bank_AccountHelper::guess_bic_nl($matches["account_number"]);
                }
            }
        }

        /*
         * If there is anything in the additional field, append it to the description. See 2014/10/02-m1mggc00938un1ok00dreqpk.mt940 (CHARGES EUR 20.00) charge.
         */
        if (!empty($transaction_data["additional"])) {
            $transaction_data["description"] .= " ({$transaction_data["additional"]})";
        }

        return $this->createTransactionFromArray($transaction_data);
    }

    /**
     * Parse the description in components. Modifies $transaction_data
     *
     * @param       $description
     * @param array &$transaction_data
     *
     * @throws Exception
     */
    protected function parseDescription($description, array &$transaction_data)
    {
        if (!Bank_Swift_Codes::isSepaDescription($description, $transaction_data) && !Bank_Swift_Codes::isInternationalDescription($description)) {
            $transaction_data['description'] = $description;

            if (empty($transaction_data['bankaccount'])) {
                /*
                 * Check if it is a wereldoverboeking, in that case try to get the IBAN and account holder name from
                 * the description.
                 */
                $result = Helper_Banktransaction_Matching::get_original_transaction_details($description);

                if ($result !== null) {
                    [$transaction_data['bankaccount'], $transaction_data['account_name']] = $result;

                    if ($guessed_bic = Bank_AccountHelper::guess_bic_nl($transaction_data['bankaccount'])) {
                        $transaction_data['bic'] = $guessed_bic;
                    }
                }
            }

            return;
        }

        // Is this a Belfius batch?
        if (stripos($description, "UITVOERING VAN UW BESTAND") !== false) {
            /*
             * Belfius reports the batch reference in the :61-tag, so the reference is currently available in the
             * 'additional' key of $transaction_data.
             * However, Bank_Swift_Codes::parse() below doesn't have access to this data, so we add the batch reference
             * and transaction type to the description.
             */
            $description .= Bank_Swift_Codes::TRANSACTION_TYPE . Bank_Swift_TransactionTypes::TYPE_SEPA_BATCH;
            $description .= Bank_Swift_Codes::SPECIFIC_REFERENCE . trim(explode("\n", $transaction_data['additional'])[1]);

            $transaction_data['additional'] = '';
        }

        $result = Bank_Swift_Codes::parse($description);

        $transaction_data['type']        = $result->getCode(Bank_Swift_Codes::TRANSACTION_TYPE);
        $transaction_data['description'] = $result->getRemittanceInformation();
        $transaction_data['swift_codes'] = iterator_to_array($result->getIterator());

        // REMI code is empty
        if (empty($transaction_data['description'])) {
            // Use EREF code as description
            $transaction_data['description'] = $result->getCode(Bank_Swift_Codes::REFERENCE_ORIGINATOR);
        }

        if ($result->getIbanOriginator()) {
            $transaction_data['bankaccount']  = $result->getIbanOriginator();
            $transaction_data['bic']          = $result->getBicOriginator();
            $transaction_data['account_name'] = $result->getNameOriginator();
        }

        // Do we have /TRTP/ present? It's a transaction
        if ($transaction_data['type']) {
            $this->parseSepaTransactionDescription($result, $transaction_data);

            return;
        }

        // Do we have /RTYP/ present? It's a reversal/rejection/refund.
        $reversal_type = $result->getCode(Bank_Swift_Codes::REVERSAL_TYPE);

        if ($reversal_type) {
            $this->parseSepaReversalTransactionDescription($result, $transaction_data);

            return;
        }

        throw new Exception("Did not find expected RTYP or TRTP transaction");
    }

    protected function parseSepaTransactionDescription(Bank_Swift_Codes $result, array &$transaction_data)
    {
        $transaction_type = $result->getCode(Bank_Swift_Codes::TRANSACTION_TYPE);
        $transaction_type = mb_strtoupper($transaction_type);

        switch ($transaction_type) {
            /*
             * SCT iDEAL Transaction
             * Example: /TRTP/IDEAL/IBAN/NL22FRBK0299821072/BIC/FRBKNL2L/NAME/MEVROUW S.P. DIJKSTRA/REMI/M0307265M105KTQK 0030000426172932 XBOXLIVEKAARTEN.NL - 93859 XBOX LIVE KAARTEN.NL/EREF/26-11-2012 15 01 0030000426172932
             * Example: /TRTP/iDEAL/IBAN/NL63ABNA0804844607/BIC/ABNANL2A/NAME/TANG J R/REMI/M1604081M10BA0QJ 0030000981842213 10718-590251 Final Fantasy XIV 6 Xatonax Limited/EREF/10-11-2014 22:02 0030000981842213
             */
            case Bank_Swift_TransactionTypes::TYPE_IDEAL:
                $transaction_data['customer_date']  = $result->getCustomerDate();
                $transaction_data['order_number']   = $result->getMollieOrderNumber();
                $transaction_data['transaction_id'] = $result->getTransactionId();

                break;
            /*
             * SCT Transaction (incoming/outgoing)
             * Example: /TRTP/SEPA OVERBOEKING/IBAN/NL47ABNA0462999726/BIC/ABNANL2A/NAME/BETER BED B.V./REMI//INV/2012.20830 1.2.2012/EREF/200009793
             */
            case Bank_Swift_TransactionTypes::TYPE_OVERBOEKING:
                /*
                 * Naughty banks such as ABN AMRO.
                 */
                $transaction_data['customer_date'] = $result->getCustomerDate();

                if ($transaction_data['mutation_code'] == TransactionTags::MUTATIECODE_IDEAL) {
                    $transaction_data['transaction_id'] = $result->getTransactionId();
                }

                break;

            case Bank_Swift_TransactionTypes::TYPE_SEPA_BATCH:
                $transaction_data['description'] = "SEPA BATCH " . $result->getCode(Bank_Swift_Codes::SPECIFIC_REFERENCE);

                if ($result->getCode(Bank_Swift_Codes::NUMBER_OF_TRANSACTIONS_IN_BATCH)) {
                    $transaction_data['description'] .= " (" . ltrim($result->getCode(Bank_Swift_Codes::NUMBER_OF_TRANSACTIONS_IN_BATCH), 0) . " transacties)";
                }

                break;
            /*
             * SCT Salary batch
             * Example: /TRTP/SEPA BATCH SALARIS/PREF/109180/NRTX/162
             */
            case Bank_Swift_TransactionTypes::TYPE_SEPA_SCT_SALARY_BATCH:
                $transaction_data['description'] = "SEPA SALARIS BATCH: " . $result->getCode(Bank_Swift_Codes::SPECIFIC_REFERENCE) . " (" . ltrim($result->getCode(Bank_Swift_Codes::NUMBER_OF_TRANSACTIONS_IN_BATCH), 0) . " transacties)";

                break;
            /*
             * SCT Return or Reject transaction
             * Example: /TRTP/SEPA TERUGBOEKING/IBAN/NL89ABNA1234567890/BIC/ABNANL2A/NAME/M. GRSSUGE/RTRN/MS02/REMI/DIT IS EEN TESTBETALING OM TE KIJKEN OF DE BIC WEL GOED AFGEVANGEN WORDT/EREF/TESTBIC
             */
            case Bank_Swift_TransactionTypes::TYPE_SEPA_SCT_RETURNREJECT_TRX:
                $transaction_data['description'] = sprintf(
                    "SEPA TERUGBOEKING:%s:%s: %s",
                    $result->reasonCodeToText($result->getCode(Bank_Swift_Codes::EXTERNAL_REJECTION_CODE)),
                    $result->getCode(Bank_Swift_Codes::EXTERNAL_REJECTION_CODE),
                    $result->getRemittanceInformation()
                );

                break;
            /*
             * SCT Correction transaction
             * Example: /TRTP/SEPA correctieboeking/IBAN/NL84RABO0156239450/BIC/RABONL2U/NAME/CREATIEF BUREAU NEDERLAND/RTRN/AC04/REMI/REF 322515.1608.01 IDEAL/EREF/5531579f0bdc0e0877.92855146
             */
            case Bank_Swift_TransactionTypes::TYPE_SEPA_SCT_CORRECTION_TRX:
                $transaction_data['description'] = sprintf(
                    "SEPA CORRECTIEBOEKING:%s:%s: %s",
                    $result->reasonCodeToText($result->getCode(Bank_Swift_Codes::EXTERNAL_REJECTION_CODE)),
                    $result->getCode(Bank_Swift_Codes::EXTERNAL_REJECTION_CODE),
                    $result->getRemittanceInformation()
                );

                break;
            /*
             * SDD core batch
             * Example: /TRTP/SEPA Incasso batch bedrijven/PREF/109180-911/NRTX/162/PIND/BRUTO
             */
            case Bank_Swift_TransactionTypes::TYPE_SEPA_SDD_CORE_BATCH:
                $transaction_data['description'] = sprintf(
                    "SEPA INCASSO BATCH: %s (%d transacties) %s",
                    $result->getCode(Bank_Swift_Codes::SPECIFIC_REFERENCE),
                    $result->getCode(Bank_Swift_Codes::NUMBER_OF_TRANSACTIONS_IN_BATCH),
                    $result->getCode(Bank_Swift_Codes::PAYMENT_INDICATOR)
                );

                break;
            /*
             * SDD b2b batch
             * Example: /TRTP/SEPA Incasso batch bedrijven/PREF/109180-911/NRTX/162/PIND/BRUTO
             */
            case Bank_Swift_TransactionTypes::TYPE_SEPA_SDD_B2B_BATCH:
                $transaction_data['description'] = sprintf(
                    "SEPA INCASSO BATCH (B2B): %s (%d transacties) %s",
                    $result->getCode(Bank_Swift_Codes::SPECIFIC_REFERENCE),
                    $result->getCode(Bank_Swift_Codes::NUMBER_OF_TRANSACTIONS_IN_BATCH),
                    $result->getCode(Bank_Swift_Codes::PAYMENT_INDICATOR)
                );

                break;
            /*
             * SDD transaction
             * Example: /TRTP/SEPA Incasso algemeen doorlopend/CSID/NL13ZZZ060605780000/NAME/Electriciteit leverancier BV/MARF/123456789XXmandaat/REMI/Omschrijving hier/IBAN/NL66ABNA1234567890/BIC/ABNANL2A/EREF/1234567X908303803
             */
            case Bank_Swift_TransactionTypes::TYPE_SEPA_SDD_TRANSACTION:
                $transaction_data['description'] = sprintf(
                    "SEPA INCASSO: %s (mandate: %s)",
                    $result->getRemittanceInformation(),
                    $result->getCode(Bank_Swift_Codes::UNIQUE_MANDATE_REFERENCE)
                );

                break;

            case Bank_Swift_TransactionTypes::TYPE_SEPA_SDD_FEE:
                $transaction_data['description'] = sprintf(
                    "SEPA INCASSO: %s %s",
                    $result->getCode(Bank_Swift_Codes::INFORMATION),
                    $result->getCode(Bank_Swift_Codes::CUSTOMER_REFERENCE)
                );

                break;
            /*
             * SCT Acceptgiro
             * Example: /TRTP/SEPA ACCEPTGIRO/IBAN/NL02ABNA0123456789/BIC/ABNANL2A/NAME/Naam/REMI/Issuer: CUR Ref: 1234567812345678/EREF/NOTPROVIDED
             *
             * ABN Acceptgiro
             * Example: /TRTP/ACCEPTGIROBETALING/IBAN/NL86INGB0002445588/BIC/INGBNL2A/NAME/Naam/REMI/ISSUER CUR REF 6583909408101120/EREF/999939091V400112 ABCRACADABRA/ORDP//ID/117279331
             */
            case Bank_Swift_TransactionTypes::TYPE_SEPA_SCT_ACCEPTGIRO:
            case Bank_Swift_TransactionTypes::TYPE_ACCEPTGIROBETALING:
                $transaction_data['description'] = trim(sprintf(
                    "%s: %s %s",
                    $transaction_type,
                    $result->getRemittanceInformation(),
                    str_replace('NOTPROVIDED', '', $result->getCode(Bank_Swift_Codes::REFERENCE_ORIGINATOR))
                ));

                break;
        }
    }

    /**
     * @param array &$transaction_data
     */
    protected function parseSepaReversalTransactionDescription(Bank_Swift_Codes $result, &$transaction_data)
    {
        $transaction_type = $result->getCode(Bank_Swift_Codes::REVERSAL_TYPE);

        $transaction_data['description'] = sprintf(
            "%s (redencode: %s): %s (mandate: %s)",
            $transaction_type,
            $result->getCode(Bank_Swift_Codes::EXTERNAL_REJECTION_CODE),
            $result->getRemittanceInformation(),
            $result->getCode(Bank_Swift_Codes::UNIQUE_MANDATE_REFERENCE)
        );

        $transaction_data['reason_code'] = mb_strtoupper($result->getCode(Bank_Swift_Codes::EXTERNAL_REJECTION_CODE)) ?: null;
    }

    private function createTransactionFromArray(array $transaction_data): StatementTransaction
    {
        $amount        = money_from_string($transaction_data['amount'], $this->currency);
        $customer_date = $transaction_data['customer_date'] ?? null;

        return $this->statement_transaction_builder
            ->setValueDateUnixTimestamp($transaction_data['value_date_unix'] ?? null)
            ->setEntryDateUnixTimestamp($transaction_data['entry_date_unix'] ?? null)
            ->setAmount($amount ?? null)
            ->setOriginalAmount($amount ?? null)
            ->setMutationCode($transaction_data['mutation_code'] ?? null)
            ->setDescription($transaction_data['description'] ?? null)
            ->setBankAccountNumber($transaction_data['bankaccount'] ?? null)
            ->setBankAccountName($transaction_data['account_name'] ?? null)
            ->setBic($transaction_data['bic'] ?? null)
            ->setSwiftCodes($transaction_data['swift_codes'] ?? [])
            ->setCustomerDateUnixTimestamp(strtotime($customer_date))
            ->build();
    }

    /**
     * @return Balance
     */
    private function readOpeningBalance()
    {
        $this->setFilePointerOffset(self::FILE_POINTER_OFFSET_OPENING_BALANCE);

        $opening_balance_tag = $this->readNextTag();

        preg_match(
            '~^
			(?P<balance_type>C|D)
			(?P<book_date>[0-9]{6})
			(?P<currency_code>[a-zA-Z]{1,3})
			(?P<amount>[0-9,]{0,15})
			~x',
            $opening_balance_tag->getValue(),
            $matches
        );

        $amount = str_replace(',', '.', $matches['amount']);
        $amount *= ($matches['balance_type'] == 'D') ? -1 : 1;
        $currency                    = new Currency($matches['currency_code']);
        $opening_date_unix_timestamp = Bank_DateUtil::convertYYMMDDToUnixtime($matches['book_date']);

        return new Balance(money_from_string($amount, $currency), $opening_date_unix_timestamp);
    }

    /**
     * @return Balance
     */
    private function readClosingBalance()
    {
        $this->setFilePointerOffset(self::FILE_POINTER_OFFSET_CLOSING_BALANCE);

        $closing_balance_tag = $this->readNextTag();

        preg_match(
            '~^
			(?P<balance_type>C|D)
			(?P<book_date>[0-9]{6})
			(?P<currency_code>[a-zA-Z]{1,3})
			(?P<amount>[0-9,]{0,15})
			~x',
            $closing_balance_tag->getValue(),
            $matches
        );

        $amount = str_replace(',', '.', $matches['amount']);
        $amount *= ($matches['balance_type'] == 'D') ? -1 : 1;
        $currency                    = new Currency($matches['currency_code']);
        $closing_date_unix_timestamp = Bank_DateUtil::convertYYMMDDToUnixtime($matches['book_date']);

        return new Balance(money_from_string($amount, $currency), $closing_date_unix_timestamp);
    }
}
