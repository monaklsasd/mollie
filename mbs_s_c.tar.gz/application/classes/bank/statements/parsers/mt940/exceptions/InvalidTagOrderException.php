<?php

namespace Bank\Statements\Parsers\Mt940\Exceptions;

class InvalidTagOrderException extends AbstractException
{
}
