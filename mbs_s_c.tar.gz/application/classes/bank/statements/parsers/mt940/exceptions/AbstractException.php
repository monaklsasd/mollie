<?php

namespace Bank\Statements\Parsers\Mt940\Exceptions;

class AbstractException extends \Bank\Statements\Parsers\Exceptions\AbstractException
{
}
