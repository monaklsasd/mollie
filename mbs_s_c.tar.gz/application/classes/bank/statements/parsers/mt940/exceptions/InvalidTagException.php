<?php

namespace Bank\Statements\Parsers\Mt940\Exceptions;

class InvalidTagException extends AbstractException
{
}
