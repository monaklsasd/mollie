<?php

namespace Bank\Statements\Parsers\Mt940;

final class Tag
{
    /** Note that all tags are normalized in lowercase. */
    public const HEADER_REFERENCE                         = '20';
    public const HEADER_ACCOUNT_NUMBER                    = '25';
    public const HEADER_STATEMENT_AND_SEQUENCE_NUMBER     = '28';
    public const HEADER_STATEMENT_AND_SEQUENCE_NUMBER_ALT = '28c';

    public const OPENING_BALANCE         = '60f';
    public const TRANSACTION             = '61';
    public const TRANSACTION_DESCRIPTION = '86';
    public const CLOSING_BALANCE         = '62f';

    /** @var string */
    private $code;

    /** @var string */
    private $value;

    public function __construct(string $code, string $value)
    {
        $this->code  = strtolower($code);
        $this->value = $value;
    }

    /**
     * Get the code, is in lowercase. Compare with one of the constants of this class.
     */
    public function getCode(): string
    {
        return $this->code;
    }

    public function getValue(): string
    {
        return $this->value;
    }

    public function hasCode(string $code): bool
    {
        return $this->code === strtolower($code);
    }
}
