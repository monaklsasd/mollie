<?php

namespace Bank\Statements\Parsers\CashManagement;

use Bank\Statements\Parsers\CashManagement\Exceptions\UnrecognizedTransactionDetailsException;
use Bank\Statements\StatementTransaction;
use Money\Currency;
use Money\Money;
use SimpleXMLElement;
use function Core\Money\money_from_string;

trait CamtParsing
{
    private static function getBankAccountIdentifierFromParsedAcctNode(SimpleXMLElement $parsedAcctNode): string
    {
        return (string)$parsedAcctNode->Id->IBAN;
    }

    /**
     * Determine whether given Ntry node represents a negative transaction from Mollie's (as account owner) perspective.
     */
    private static function representsNegativeTransaction(SimpleXMLElement $parsedNtryNode): bool
    {
        $debitCreditIndicator = (string)$parsedNtryNode->CdtDbtInd;

        if ($debitCreditIndicator === 'D' || $debitCreditIndicator === 'DBIT') {
            return true;
        }

        return false;
    }

    /**
     * Returns a Money instance representing the amount of transaction in given Ntry node. It can be a negative amount
     * if the Ntry node represents a debit transaction.
     *
     * @throws UnrecognizedTransactionDetailsException
     */
    private static function getAmountOfParsedEntryNode(SimpleXMLElement $parsedNtryNode): Money
    {
        $currencyValue = (string)$parsedNtryNode->Amt->attributes()->Ccy;
        $amountValue   = (string)$parsedNtryNode->Amt;

        if (empty($amountValue) || empty($currencyValue)) {
            throw UnrecognizedTransactionDetailsException::noAmountDefined((string)$parsedNtryNode->NtryRef);
        }

        $amount = money_from_string($amountValue, new Currency($currencyValue));

        if (self::representsNegativeTransaction($parsedNtryNode)) {
            $amount = $amount->negative();
        }

        return $amount;
    }

    private static function getTransactionDescriptionOfParsedEntryNode(SimpleXMLElement $parsedNtryNode): string
    {
        $description = '';

        // Note: NtryDtls is actually not required to exist
        // Ntry -> NtryDtls -> TxDtls -> RmtInf{0,1}
        if (isset($parsedNtryNode->NtryDtls->TxDtls->RmtInf->Ustrd)) {
            $description = (string)$parsedNtryNode->NtryDtls->TxDtls->RmtInf->Ustrd;
        }
        // Ntry -> NtryDtls -> TxDtls -> AddtlTxInf{0,1}: This is used by ING to describe withdrawn bank costs.
        elseif (isset($parsedNtryNode->NtryDtls->TxDtls->AddtlTxInf)) {
            $description = (string)$parsedNtryNode->NtryDtls->TxDtls->AddtlTxInf;
        } elseif (isset($parsedNtryNode->NtryDtls->Btch->PmtInfId)) {
            /*
             * It's a SEPA batch. This format is understood by other functions in MBS.
             *
             * @see \Model_Banktransaction::getSepaBatchReference()
             */
            $description = "SEPA BATCH {$parsedNtryNode->NtryDtls->Btch->PmtInfId}";
        }

        return $description;
    }

    /**
     * @throws UnrecognizedTransactionDetailsException
     */
    private static function getBankAccountIdentifierOfParsedEntryNode(SimpleXMLElement $parsedNtryNode): ?string
    {
        /*
         * Ntry -> NtryDtls -> TxDtls -> RtldPties is optional, DbtrAcct is optional, etc.
         */
        if (!isset($parsedNtryNode->NtryDtls->TxDtls->RltdPties)) {
            return null;
        }

        if (self::representsNegativeTransaction($parsedNtryNode)) {
            // When bank withdraws funds they don't tell us who they are. Allow this to happen.
            if (isset($parsedNtryNode->NtryDtls->TxDtls->RltdPties->CdtrAcct->Id->IBAN)) {
                return (string)$parsedNtryNode->NtryDtls->TxDtls->RltdPties->CdtrAcct->Id->IBAN;
            }

            return (string)$parsedNtryNode->NtryDtls->TxDtls->RltdPties->CdtrAcct->Id->Othr->Id;
        }

        if (!empty($parsedNtryNode->NtryDtls->TxDtls->RltdPties->DbtrAcct->Id->IBAN)) {
            return (string)$parsedNtryNode->NtryDtls->TxDtls->RltdPties->DbtrAcct->Id->IBAN;
        }

        /* Not an IBAN, still save account number */
        return (string)$parsedNtryNode->NtryDtls->TxDtls->RltdPties->DbtrAcct->Id->Othr->Id;
    }

    /**
     * @throws UnrecognizedTransactionDetailsException
     */
    private static function getBankAccountNameOfParsedEntryNode(SimpleXMLElement $parsedNtryNode): ?string
    {
        /*
         * Ntry -> NtryDtls -> TxDtls -> RtldPties is optional, DbtrAcct is optional, etc.
         * I'm gonna make an assumption here and just use the info now we know the TxDtls is there.
         */
        if (self::representsNegativeTransaction($parsedNtryNode)) {
            if (isset($parsedNtryNode->NtryDtls->TxDtls->RltdPties->Cdtr->Nm)) {
                return (string)$parsedNtryNode->NtryDtls->TxDtls->RltdPties->Cdtr->Nm;
            }
        } else {
            return (string)$parsedNtryNode->NtryDtls->TxDtls->RltdPties->Dbtr->Nm;
        }

        return null;
    }

    /**
     * @throws UnrecognizedTransactionDetailsException
     */
    private static function getBicValueOfParsedEntryNode(SimpleXMLElement $parsedNtryNode): ?string
    {
        if (!empty($parsedNtryNode->NtryDtls->TxDtls->RltdAgts->DbtrAgt->FinInstnId->BIC)) {
            return (string)$parsedNtryNode->NtryDtls->TxDtls->RltdAgts->DbtrAgt->FinInstnId->BIC;
        }

        if (!empty($parsedNtryNode->NtryDtls->TxDtls->RltdPties->Dbtr->Id->OrgId->BICOrBEI)) {
            return (string)$parsedNtryNode->NtryDtls->TxDtls->RltdPties->Dbtr->Id->OrgId->BICOrBEI;
        }

        if (!empty($parsedNtryNode->NtryDtls->TxDtls->RltdAgts->CdtrAgt->FinInstnId->BIC)) {
            return (string)$parsedNtryNode->NtryDtls->TxDtls->RltdAgts->CdtrAgt->FinInstnId->BIC;
        }

        return null;
    }

    /**
     * @throws UnrecognizedTransactionDetailsException
     */
    private static function getMutationCodeOfParsedEntryNode(SimpleXMLElement $parsedNtryNode): string
    {
        $mutation_code = null;

        // Ntry -> BkTxCd -> Domn -> [ Cd & Fmly -> [ Cd & SubFmly ] ]
        if (isset($parsedNtryNode->BkTxCd->Domn)) {
            $mutation_code .= (string)$parsedNtryNode->BkTxCd->Domn->Cd . '/';
            $mutation_code .= (string)$parsedNtryNode->BkTxCd->Domn->Fmly->Cd . '/';
            $mutation_code .= (string)$parsedNtryNode->BkTxCd->Domn->Fmly->SubFmlyCd;
        }

        $mutation_code .= '|';

        // Ntry -> BkTxCd -> Prtry -> [ Cd, Issr{0,1} ]
        if (isset($parsedNtryNode->BkTxCd->Prtry)) {
            // Issuer may be empty.
            if (isset($parsedNtryNode->BkTxCd->Prtry->Issr)) {
                $mutation_code .= (string)$parsedNtryNode->BkTxCd->Prtry->Issr;
            }

            $mutation_code .= ':';
            $mutation_code .= (string)$parsedNtryNode->BkTxCd->Prtry->Cd;
        }

        if ($mutation_code === null) {
            throw UnrecognizedTransactionDetailsException::noMutationCodeFound((string)$parsedNtryNode->NtryRef);
        }

        return $mutation_code;
    }

    private static function getValueTimestampOfParsedEntryNode(SimpleXMLElement $parsedNtryNode): ?int
    {
        if (!isset($parsedNtryNode->ValDt->Dt)) {
            return null;
        }

        return strtotime($parsedNtryNode->ValDt->Dt);
    }

    /**
     * @throws UnrecognizedTransactionDetailsException
     */
    private static function getBookingTimestampOfParsedEntryNode(SimpleXMLElement $parsedNtryNode): int
    {
        if (!isset($parsedNtryNode->BookgDt->Dt)) {
            throw UnrecognizedTransactionDetailsException::noBookingDate((string)$parsedNtryNode->NtryRef);
        }

        return strtotime($parsedNtryNode->BookgDt->Dt);
    }

    private static function getCustomerTimestampOfParsedEntryNode(SimpleXMLElement $parsedNtryNode): ?int
    {
        if (isset($parsedNtryNode->NtryDtls->TxDtls->RltdDts->TxDtTm)) {
            return strtotime($parsedNtryNode->NtryDtls->TxDtls->RltdDts->TxDtTm);
        }

        if (isset($parsedNtryNode->NtryDtls->TxDtls->RltdDts->AccptncDtTm)) {
            return strtotime($parsedNtryNode->NtryDtls->TxDtls->RltdDts->AccptncDtTm);
        }

        return null;
    }

    /**
     * @throws UnrecognizedTransactionDetailsException
     */
    private static function buildStatementTransactionFromParsedEntryNode(
        SimpleXMLElement $parsedNode
    ): StatementTransaction {
        $statementTransaction = new StatementTransaction();

        $statementTransaction->setAmount(self::getAmountOfParsedEntryNode($parsedNode));
        $statementTransaction->setOriginalAmount(self::getAmountOfParsedEntryNode($parsedNode));
        $statementTransaction->setDescription(self::getTransactionDescriptionOfParsedEntryNode($parsedNode));
        $statementTransaction->setBankAccountNumber(self::getBankAccountIdentifierOfParsedEntryNode($parsedNode));
        $statementTransaction->setBankAccountName(self::getBankAccountNameOfParsedEntryNode($parsedNode));
        $statementTransaction->setBic(self::getBicValueOfParsedEntryNode($parsedNode));
        $statementTransaction->setMutationCode(self::getMutationCodeOfParsedEntryNode($parsedNode));
        $statementTransaction->setValueDateUnixTimestamp(self::getValueTimestampOfParsedEntryNode($parsedNode));
        $statementTransaction->setEntryDateUnixTimestamp(self::getBookingTimestampOfParsedEntryNode($parsedNode));
        $statementTransaction->setCustomerDateUnixTimestamp(self::getCustomerTimestampOfParsedEntryNode($parsedNode));

        return $statementTransaction;
    }
}
