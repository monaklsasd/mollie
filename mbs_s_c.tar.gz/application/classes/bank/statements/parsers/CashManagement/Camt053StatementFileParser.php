<?php

namespace Bank\Statements\Parsers\CashManagement;

use Bank\Statements\Balance;
use Bank\Statements\BankToCustomerMessage;
use Bank\Statements\Exceptions\InvalidBalanceDateExceptions;
use Bank\Statements\Parsers\CashManagement\Exceptions\InvalidStatementCountException;
use Bank\Statements\Parsers\CashManagement\Exceptions\MissingCurrencyException;
use Bank\Statements\Parsers\CashManagement\Exceptions\MissingTransactionAmountException;
use Bank\Statements\Parsers\CashManagement\Exceptions\MissingTransactionCodeException;
use Bank\Statements\Parsers\CashManagement\Exceptions\UnknownDebitCreditIndicatorException;
use Bank\Statements\Parsers\CashManagement\Exceptions\UnknownTransactionStatusException;
use Bank\Statements\Parsers\CashManagement\Exceptions\UnrecognizedTransactionDetailsException;
use Bank\Statements\Parsers\Exceptions\InvalidStatementFileException;
use Bank\Statements\StatementFileParser;
use Bank\Statements\StatementHeader;
use Bank\Statements\StatementMessage;
use Bank\Statements\StatementTransaction;
use Bank\Statements\StatementTransactionBuilder;
use BankAccounts\BankAccountRepository;
use Core\Time\Clock;
use Generator;
use Mollie\Xml\Exception\XmlException;
use Mollie\Xml\XmlObject;
use Money\Currency;
use Money\Money;
use Psr\Http\Message\StreamInterface;
use SimpleXMLElement;
use function Core\Money\money_from_string;

/**
 * This implementation does provide the yield functionality from the StatementFileParser interface, but does so by storing all of
 * the transactions in an array. To make this CAMT053 parser implementation more memory efficient, the yieldTransactions
 * would need to be implemented without holding a copy of all the transactions.
 *
 * @used-by \Bank\Statements\FileParserFactory
 */
class Camt053StatementFileParser implements StatementFileParser
{
    public const CODE_PREVIOUSLY_CLOSED_BOOKED_BALANCE = 'PRCD'; // Previously Closed Booked balance
    public const CODE_OPENING_BOOKED_BALANCE           = 'OPBD'; // Opening Booked balance
    public const CODE_CLOSING_BOOKED_BALANCE           = 'CLBD'; // Closing Booked balance
    public const CODE_INTERIM_BOOKED_BALANCE           = 'ITBD'; // Interim Booked balance
    public const CODE_CLOSING_AVAILABLE_BALANCE        = 'CLAV'; // Closing Available balance
    public const CODE_FORWARD_AVAILABLE_BALANCE        = 'FWAV'; // Forward Available balance

    public const CAMT053_STATUS_BOOKED    = 'BOOK';
    public const CAMT053_INDICATOR_DEBIT  = 'DBIT';
    public const CAMT053_INDICATOR_CREDIT = 'CRDT';

    public const MBS_INDICATOR_CREDIT = 'C';
    public const MBS_INDICATOR_DEBIT  = 'D';

    /** @var StatementTransactionBuilder */
    private $statement_transaction_builder;

    /** @var StatementHeader */
    private $statement_header;

    /** @var Balance */
    private $opening_balance;

    /** @var Balance */
    private $closing_balance;

    /** @var StatementTransaction[] */
    private $transactions = [];

    /** @var BankAccountRepository */
    private $bankAccountRepository;

    public function __construct(
        StatementTransactionBuilder $statement_transaction_builder,
        BankAccountRepository $bankAccountRepository
    ) {
        $this->statement_transaction_builder = $statement_transaction_builder;
        $this->bankAccountRepository         = $bankAccountRepository;
    }

    /**
     * @throws InvalidStatementCountException
     * @throws MissingCurrencyException
     * @throws InvalidBalanceDateExceptions
     * @throws MissingTransactionCodeException
     * @throws MissingTransactionAmountException
     * @throws UnknownDebitCreditIndicatorException
     * @throws UnknownTransactionStatusException
     * @throws UnrecognizedTransactionDetailsException
     * @throws InvalidStatementFileException
     * @throws \BankAccounts\Exceptions\BankAccountNotFoundException
     */
    public function parse(StreamInterface $camt053_stream): BankToCustomerMessage
    {
        $this->processStatementFile($camt053_stream);

        $bankAccount = $this->bankAccountRepository->getByIbanOrAccountNumber(
            $this->statement_header->getAccountNumber()
        );

        $statementDate = Clock::createDateTimeFromTimestamp(
            $this->closing_balance->getBalanceDateUnixTimestamp()
        );

        return new StatementMessage(
            $this->statement_header->getStatementNumber(),
            $this->statement_header->getSequenceNumber(),
            $this->opening_balance,
            $this->closing_balance,
            $this->statement_header->getReference(),
            $statementDate,
            $bankAccount,
            $this->yieldTransactions()
        );
    }

    /**
     * @throws InvalidStatementCountException
     * @throws MissingCurrencyException
     * @throws InvalidBalanceDateExceptions
     * @throws MissingTransactionCodeException
     * @throws MissingTransactionAmountException
     * @throws UnknownDebitCreditIndicatorException
     * @throws UnknownTransactionStatusException
     * @throws UnrecognizedTransactionDetailsException
     * @throws InvalidStatementFileException
     */
    private function processStatementFile(StreamInterface $stream): void
    {
        $booking_to_customer_statement = $this->convertStreamToXml($stream);

        if (count($booking_to_customer_statement->Stmt) > 1) {
            throw new InvalidStatementCountException('We expect statements to be 1 statement per file.');
        }

        $this->processStatementHeader($booking_to_customer_statement);
        $this->processBalances($booking_to_customer_statement);
        $this->processTransactions($booking_to_customer_statement);
    }

    /**
     * A CAMT053 file with ~28.000 transactions uses up ~45M file storage space and ~ 300M of memory using these
     * settings for SimpleXML.
     *
     * @throws InvalidStatementFileException
     *
     * @return SimpleXMLElement
     */
    private function convertStreamToXml(StreamInterface $stream)
    {
        try {
            return XmlObject::fromString((string)$stream)->BkToCstmrStmt[0];
        } catch (XmlException $e) {
            throw new InvalidStatementFileException("Couldn't parse XML file", 0, $e);
        }
    }

    private function processStatementHeader(SimpleXMLElement $BkToCstmrStmt)
    {
        $this->statement_header = new StatementHeader();

        $this->statement_header->setReference($BkToCstmrStmt->Stmt->Id);
        $this->statement_header->setAccountNumber($BkToCstmrStmt->Stmt->Acct->Id->IBAN);
        $this->statement_header->setStatementNumber(0);
        $this->statement_header->setSequenceNumber($BkToCstmrStmt->Stmt->ElctrncSeqNb);
    }

    private function processBalances(SimpleXMLElement $BkToCstmrStmt)
    {
        // Expect Stmt->Bal{0..n} to exist.
        foreach ($BkToCstmrStmt->Stmt->Bal as $balance_node) {
            // For now we'll only support standard balances
            if (!isset($balance_node->Tp->CdOrPrtry->Cd)) {
                continue;
            }

            $debit_credit_indicator = $this->getDebitCreditIndicator((string)$balance_node->CdtDbtInd);

            $amount       = $this->getAmountFromAmtNode($balance_node->Amt, $debit_credit_indicator);
            $balance_date = strtotime((string)$balance_node->Dt->Dt);

            $code = (string)$balance_node->Tp->CdOrPrtry->Cd;

            if ($code == self::CODE_OPENING_BOOKED_BALANCE) {
                $this->opening_balance = new Balance($amount, $balance_date);
            } elseif ($code == self::CODE_CLOSING_BOOKED_BALANCE) {
                $this->closing_balance = new Balance($amount, $balance_date);
            }
        }

        $this->verifyBalancesAreSetCorrectly();
    }

    /**
     * @param string $camt053_credit_debit_indicator
     *
     * @throws UnknownDebitCreditIndicatorException
     *
     * @return string
     */
    private function getDebitCreditIndicator($camt053_credit_debit_indicator)
    {
        if ($camt053_credit_debit_indicator == self::CAMT053_INDICATOR_CREDIT) {
            return StatementTransaction::INDICATOR_CREDIT;
        }

        if ($camt053_credit_debit_indicator == self::CAMT053_INDICATOR_DEBIT) {
            return StatementTransaction::INDICATOR_DEBIT;
        }

        throw new UnknownDebitCreditIndicatorException("Unknown credit/debit indicator: {$camt053_credit_debit_indicator}");
    }

    /**
     * @param string $debit_credit_indicator
     *
     * @throws MissingCurrencyException
     */
    protected function getAmountFromAmtNode(SimpleXMLElement $node, $debit_credit_indicator): Money
    {
        $amount_attr = $node->attributes();

        if (!isset($amount_attr['Ccy'])) {
            throw new MissingCurrencyException("Transaction has no currency defined");
        }

        $currency = new Currency((string)$amount_attr['Ccy']);
        $amount   = money_from_string((string)$node, $currency);

        if ($debit_credit_indicator == StatementTransaction::INDICATOR_DEBIT) {
            $amount = $amount->negative();
        }

        return $amount;
    }

    private function verifyBalancesAreSetCorrectly()
    {
        if (!isset($this->opening_balance)) {
            throw new InvalidBalanceDateExceptions("Opening balance and date need to be set");
        }

        if (!isset($this->closing_balance)) {
            throw new InvalidBalanceDateExceptions("Closing balance and date need to be set");
        }

        $opening_date_unix_timestamp = $this->opening_balance->getBalanceDateUnixTimestamp();
        $closing_date_unix_timestamp = $this->closing_balance->getBalanceDateUnixTimestamp();

        if ($closing_date_unix_timestamp < $opening_date_unix_timestamp) {
            throw new InvalidBalanceDateExceptions(
                "Closing date ({$closing_date_unix_timestamp}) cannot precede the opening date ({$opening_date_unix_timestamp})"
            );
        }
    }

    /**
     * @throws MissingTransactionAmountException
     * @throws MissingTransactionCodeException
     * @throws UnknownDebitCreditIndicatorException
     * @throws UnknownTransactionStatusException
     * @throws UnrecognizedTransactionDetailsException
     */
    private function processTransactions(SimpleXMLElement $BkToCstmrStmt)
    {
        $index = 0;

        foreach ($BkToCstmrStmt->Stmt->Ntry as $entry) {
            $this->processTransaction($index, $entry);

            $index++;
        }
    }

    /**
     * According to the spec these fields are required:
     *
     * Ntry => [ ValDt -> [ Dt ] & BookDt -> [ Dt] & CdtDbtInd & Sts & Amt & BkTxCd ]
     *
     * @param int $index
     *
     * @throws MissingTransactionAmountException
     * @throws MissingTransactionCodeException
     * @throws UnknownDebitCreditIndicatorException
     * @throws UnknownTransactionStatusException
     * @throws UnrecognizedTransactionDetailsException
     *
     * @return StatementTransaction
     */
    protected function processTransaction($index, SimpleXMLElement $entry)
    {
        if ((string)$entry->Sts !== self::CAMT053_STATUS_BOOKED) {
            throw new UnknownTransactionStatusException("Transaction #{$index} has unknown status: " . $entry->Sts);
        }

        if (!isset($entry->CdtDbtInd)) {
            throw new UnknownDebitCreditIndicatorException("Transaction #{$index} has no credit/debit indicator");
        }

        $this->processTransactionAmountForEntry($entry);
        $this->processTransactionDescriptionForEntry($entry);
        $this->processTransactionBankAccountForEntry($entry, $index);
        $this->processTransactionMutationCodeForEntry($entry, $index);

        $this->processTransactionValueDateForEntry($entry);
        $this->processTransactionBookingDateForEntry($entry);
        $this->processTransactionCustomerDateForEntry($entry);

        $this->transactions[] = $this->statement_transaction_builder->build();
    }

    /**
     * @param int $index
     *
     * @throws UnrecognizedTransactionDetailsException
     */
    private function processTransactionBankAccountForEntry(SimpleXMLElement $entry, $index): void
    {
        $debit_indicator = $this->getDebitCreditIndicator((string)$entry->CdtDbtInd);

        if (!isset($entry->NtryDtls->TxDtls) || count($entry->NtryDtls->TxDtls) != 1) {
            if (!isset($entry->NtryDtls->Btch)) {
                throw new UnrecognizedTransactionDetailsException(
                    "Transaction #{$index} has transaction details I don't understand"
                );
            }
        }

        /*
         * Ntry -> NtryDtls -> TxDtls -> RtldPties is optional, DbtrAcct is optional, etc.
         * I'm gonna make an assumption here and just use the info now we know the TxDtls is there.
         */
        if ($debit_indicator == StatementTransaction::INDICATOR_DEBIT) {
            // When bank withdraws funds they don't tell us who they are. Allow this to happen.
            if (isset($entry->NtryDtls->TxDtls->RltdPties->CdtrAcct->Id->IBAN)) {
                $bank_account_number = (string)$entry->NtryDtls->TxDtls->RltdPties->CdtrAcct->Id->IBAN;
                $this->statement_transaction_builder->setBankAccountNumber($bank_account_number);
            }

            if (isset($entry->NtryDtls->TxDtls->RltdPties->Cdtr->Nm)) {
                $bank_account_name = (string)$entry->NtryDtls->TxDtls->RltdPties->Cdtr->Nm;
                $this->statement_transaction_builder->setBankAccountName($bank_account_name);
            }
        } else {
            if (!empty($entry->NtryDtls->TxDtls->RltdPties->DbtrAcct->Id->IBAN)) {
                $bank_account = (string)$entry->NtryDtls->TxDtls->RltdPties->DbtrAcct->Id->IBAN;
            } else {
                /* Not an IBAN, still save account number */
                $bank_account = (string)$entry->NtryDtls->TxDtls->RltdPties->DbtrAcct->Id->Othr->Id;
            }

            $bank_account_name = (string)$entry->NtryDtls->TxDtls->RltdPties->Dbtr->Nm;

            $this->statement_transaction_builder->setBankAccountNumber($bank_account);
            $this->statement_transaction_builder->setBankAccountName($bank_account_name);
        }

        if (!empty($entry->NtryDtls->TxDtls->RltdAgts->DbtrAgt->FinInstnId->BIC)) {
            $this->statement_transaction_builder->setBic((string)$entry->NtryDtls->TxDtls->RltdAgts->DbtrAgt->FinInstnId->BIC);
        } elseif (!empty($entry->NtryDtls->TxDtls->RltdPties->Dbtr->Id->OrgId->BICOrBEI)) {
            $this->statement_transaction_builder->setBic((string)$entry->NtryDtls->TxDtls->RltdPties->Dbtr->Id->OrgId->BICOrBEI);
        } elseif (!empty($entry->NtryDtls->TxDtls->RltdAgts->CdtrAgt->FinInstnId->BIC)) {
            $this->statement_transaction_builder->setBic((string)$entry->NtryDtls->TxDtls->RltdAgts->CdtrAgt->FinInstnId->BIC);
        }
    }

    /**
     * Only supports the <Ustrd> (Unstructured) and <AddtlTxInf> (Additional Transaction Information) tags for
     * retrieving a description.
     *
     * @return string|null
     */
    private function processTransactionDescriptionForEntry(SimpleXMLElement $entry)
    {
        // Note: NtryDtls is actually not required to exist
        // Ntry -> NtryDtls -> TxDtls -> RmtInf{0,1}
        if (isset($entry->NtryDtls->TxDtls->RmtInf->Ustrd)) {
            $description = (string)$entry->NtryDtls->TxDtls->RmtInf->Ustrd;
            $this->statement_transaction_builder->setDescription($description);
        }
        // Ntry -> NtryDtls -> TxDtls -> AddtlTxInf{0,1}: This is used by ING to describe withdrawn bank costs.
        elseif (isset($entry->NtryDtls->TxDtls->AddtlTxInf)) {
            $description = (string)$entry->NtryDtls->TxDtls->AddtlTxInf;
            $this->statement_transaction_builder->setDescription($description);
        } elseif (isset($entry->NtryDtls->Btch->PmtInfId)) {
            /*
             * It's a SEPA batch. This format is understood by other functions in MBS.
             *
             * @see \Model_Banktransaction::getSepaBatchReference()
             */
            $description = "SEPA BATCH {$entry->NtryDtls->Btch->PmtInfId}";
            $this->statement_transaction_builder->setDescription($description);
        }
    }

    private function processTransactionValueDateForEntry(SimpleXMLElement $entry)
    {
        if (isset($entry->ValDt->Dt)) {
            $this->statement_transaction_builder->setValueDateUnixTimestamp(strtotime($entry->ValDt->Dt));
        }
    }

    private function processTransactionBookingDateForEntry(SimpleXMLElement $entry)
    {
        if (isset($entry->BookgDt->Dt)) {
            $this->statement_transaction_builder->setEntryDateUnixTimestamp(strtotime($entry->BookgDt->Dt));
        }
    }

    private function processTransactionCustomerDateForEntry(SimpleXMLElement $entry)
    {
        // Ntry -> NtryDlts -> RtldDts -> TxDtTm{0,1}
        if (isset($entry->NtryDtls->TxDtls->RltdDts->TxDtTm)) {
            $customer_date_unix_timestamp = strtotime((string)$entry->NtryDtls->TxDtls->RltdDts->TxDtTm);
            $this->statement_transaction_builder->setCustomerDateUnixTimestamp($customer_date_unix_timestamp);
        }
    }

    private function processTransactionAmountForEntry(SimpleXMLElement $entry)
    {
        if (isset($entry->Amt)) {
            $debit_indicator = $this->getDebitCreditIndicator((string)$entry->CdtDbtInd);

            $amount = $this->getAmountFromAmtNode($entry->Amt[0], $debit_indicator);
            $this->statement_transaction_builder->setAmount($amount);
            $this->statement_transaction_builder->setOriginalAmount($amount);
        }
    }

    /**
     * BkTxCd is the bank transaction code. It exists out of a standard code ( Domain ) and possibly an issuer specific
     * code ( Proprietary ).
     *
     * We currently just have one mutation_code field and we do not seem to have a specific use case to
     * seperate this out any further so we'll store it in mutation code in a specific form:
     *
     * $Domn->Cd / $Domn->Fmly->Cd / $Domn->Fmly->SubFmly | $Prtry->Issr : $Prtry->Cd
     *
     * For example:
     *
     * PMNT/RCDT/RRTN|INGGroup:00190
     *
     * @param int $index
     *
     * @throws MissingTransactionCodeException
     */
    private function processTransactionMutationCodeForEntry(SimpleXMLElement $entry, $index)
    {
        $mutation_code = '';

        // Ntry -> BkTxCd -> [ Domn,  Prtry{0,1} ]
        if (!isset($entry->BkTxCd->Domn) && !isset($entry->BkTxCd->Prtry)) {
            throw new MissingTransactionCodeException("Transaction #{$index} has no valid bank transaction code defined");
        }

        // Ntry -> BkTxCd -> Domn -> [ Cd & Fmly -> [ Cd & SubFmly ] ]
        if (isset($entry->BkTxCd->Domn)) {
            $mutation_code .= (string)$entry->BkTxCd->Domn->Cd . '/';
            $mutation_code .= (string)$entry->BkTxCd->Domn->Fmly->Cd . '/';
            $mutation_code .= (string)$entry->BkTxCd->Domn->Fmly->SubFmlyCd;
        }

        $mutation_code .= '|';

        // Ntry -> BkTxCd -> Prtry -> [ Cd, Issr{0,1} ]
        if (isset($entry->BkTxCd->Prtry)) {
            // Issuer may be empty.
            if (isset($entry->BkTxCd->Prtry->Issr)) {
                $mutation_code .= (string)$entry->BkTxCd->Prtry->Issr;
            }

            $mutation_code .= ':';
            $mutation_code .= (string)$entry->BkTxCd->Prtry->Cd;
        }

        $this->statement_transaction_builder->setMutationCode($mutation_code);
    }

    /**
     * @return Generator|StatementTransaction[]
     */
    private function yieldTransactions()
    {
        foreach ($this->transactions as $transaction) {
            yield $transaction;
        }
    }
}
