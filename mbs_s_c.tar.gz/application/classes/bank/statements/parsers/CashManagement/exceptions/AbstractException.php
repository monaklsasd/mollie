<?php

namespace Bank\Statements\Parsers\CashManagement\Exceptions;

abstract class AbstractException extends \Bank\Statements\Parsers\Exceptions\AbstractException
{
}
