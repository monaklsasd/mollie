<?php

namespace Bank\Statements\Parsers\CashManagement\Exceptions;

class UnrecognizedTransactionDetailsException extends AbstractException
{
    public static function noMutationCodeFound(string $transactionReference): self
    {
        return new self("Cannot find mutation code for transaction: " . $transactionReference);
    }

    public static function noAmountDefined(string $transactionReference): self
    {
        return new self("Cannot find amount of transaction: " . $transactionReference);
    }

    public static function noBookingDate(string $transactionReference): self
    {
        return new self("Cannot find booking date of transaction: " . $transactionReference);
    }

    public static function missingNode(string $nodeName): self
    {
        return new self(sprintf("Expected to find node: %s, but it's missing", $nodeName));
    }
}
