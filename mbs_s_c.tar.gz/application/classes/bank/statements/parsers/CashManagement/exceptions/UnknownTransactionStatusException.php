<?php

namespace Bank\Statements\Parsers\CashManagement\Exceptions;

class UnknownTransactionStatusException extends AbstractException
{
}
