<?php

namespace Bank\Statements\Parsers\CashManagement\Exceptions;

class UnknownDebitCreditIndicatorException extends AbstractException
{
}
