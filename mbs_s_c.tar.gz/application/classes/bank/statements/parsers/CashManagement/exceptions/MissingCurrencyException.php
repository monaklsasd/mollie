<?php

namespace Bank\Statements\Parsers\CashManagement\Exceptions;

class MissingCurrencyException extends AbstractException
{
}
