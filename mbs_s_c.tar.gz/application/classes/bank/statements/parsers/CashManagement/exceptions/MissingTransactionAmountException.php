<?php

namespace Bank\Statements\Parsers\CashManagement\Exceptions;

class MissingTransactionAmountException extends AbstractException
{
}
