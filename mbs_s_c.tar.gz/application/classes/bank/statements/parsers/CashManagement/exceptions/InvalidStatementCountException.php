<?php

namespace Bank\Statements\Parsers\CashManagement\Exceptions;

class InvalidStatementCountException extends AbstractException
{
}
