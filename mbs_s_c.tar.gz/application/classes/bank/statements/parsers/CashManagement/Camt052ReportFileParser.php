<?php

namespace Bank\Statements\Parsers\CashManagement;

use Bank\Statements\BankToCustomerMessage;
use Bank\Statements\Parsers\CashManagement\Exceptions\UnrecognizedTransactionDetailsException;
use Bank\Statements\ReportMessage;
use Bank\Statements\StatementFileParser;
use BankAccounts\BankAccountRepository;
use BankAccounts\Exceptions\BankAccountNotFoundException;
use Core\Time\TimeZones;
use Generator;
use Mollie\Xml\Element;
use Mollie\Xml\Parsing\XmlStreamParserInterface;
use Psr\Http\Message\StreamInterface;

class Camt052ReportFileParser implements StatementFileParser
{
    use CamtParsing;

    /** @var XmlStreamParserInterface */
    private $xmlParser;

    /** @var BankAccountRepository */
    private $bankAccountRepository;

    public function __construct(XmlStreamParserInterface $xmlParser, BankAccountRepository $bankAccountRepository)
    {
        $this->xmlParser             = $xmlParser;
        $this->bankAccountRepository = $bankAccountRepository;
    }

    /**
     * @throws Exceptions\UnrecognizedTransactionDetailsException
     * @throws BankAccountNotFoundException
     */
    public function parse(StreamInterface $fileStream): BankToCustomerMessage
    {
        $accountNumber = self::getBankAccountIdentifierFromParsedAcctNode(
            $this->findFirstNode($fileStream, "Acct")
        );

        $bankAccount = $this->bankAccountRepository->getByIbanOrAccountNumber($accountNumber);

        $reportDate = \DateTimeImmutable::createFromFormat(
            'Y-m-d\TH:i:s\Z',
            (string)$this->xmlParser->generateParsedNodes($fileStream, "CreDtTm")->current(),
            TimeZones::UTC()
        );

        $messageReference = (string)$this->findFirstNode($fileStream, "Id");
        $transactions     = $this->yieldTransactionsFromReportStream($fileStream);

        return new ReportMessage($messageReference, $bankAccount, $reportDate, $transactions);
    }

    /**
     * @throws UnrecognizedTransactionDetailsException In case no node can be found by given name.
     */
    public function findFirstNode(StreamInterface $fileStream, string $nodeName): Element
    {
        $node = $this->xmlParser->generateParsedNodes($fileStream, $nodeName)->current();

        if ($node === false) {
            throw UnrecognizedTransactionDetailsException::missingNode($nodeName);
        }

        return $node;
    }

    /**
     * @throws Exceptions\UnrecognizedTransactionDetailsException
     */
    private function yieldTransactionsFromReportStream(StreamInterface $stream): Generator
    {
        foreach ($this->xmlParser->generateParsedNodes($stream, "Ntry") as $entryNode) {
            yield self::buildStatementTransactionFromParsedEntryNode($entryNode);
        }
    }
}
