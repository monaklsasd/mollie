<?php

namespace Bank\Statements\Parsers\Exceptions;

class InvalidStatementFileException extends AbstractException
{
}
