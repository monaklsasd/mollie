<?php

namespace Bank\Statements\Parsers\Exceptions;

abstract class AbstractException extends \Bank\Statements\Exceptions\AbstractException
{
}
