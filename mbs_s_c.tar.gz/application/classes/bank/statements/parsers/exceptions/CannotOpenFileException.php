<?php

namespace Bank\Statements\Parsers\Exceptions;

class CannotOpenFileException extends AbstractException
{
}
