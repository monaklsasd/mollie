<?php

namespace Bank\Statements\Parsers\ClieopResult;

use Bank_ClieopResult;
use Core\Numbers;
use Mollie\ObjectStorage\ObjectInterface;
use RuntimeException;
use StatementHandlers\ClieopResultHandler;
use function is_array;

/**
 * This class parses a ClieopResult (.hr) file to construct a ClieopResult file and then calls the
 * Mollie_StatementHandler_ClieopResult callback to perform the required database actions.
 *
 * TODO: Appropriately split up this class from the Statements\Parsers namespace, as it doesn't parse statements
 */
class ClieopResultParser
{
    public const STATE_DEFAULT = 0;
    public const STATE_HEADER  = 1;
    public const STATE_BLOCKS  = 2;
    public const STATE_FOOTER  = 3;

    public const BLOCK_BATCH     = 'batch';
    public const BLOCK_REJECTION = 'rejection';

    public const TXT_BATCH_SEPARATOR  = '--------------------------------------------------------------------------------';
    public const TXT_FOOTER_SEPARATOR = '================================================================================';

    public const REPORT_TYPE_BATCH       = "BATCH REPORT";
    public const REPORT_TYPE_TRANSACTION = "TRANSACTION REPORT";

    protected $_result = [];

    /** @var string */
    protected $report_type;

    /** @var ClieopResultHandler */
    private $clieop_result_statement_handler;

    public function __construct(ClieopResultHandler $clieop_result_statement_handler)
    {
        // TODO: Bart: I feel this should not be a dependency. This files only scope is the statement file, not the mollie structure.
        $this->clieop_result_statement_handler = $clieop_result_statement_handler;
    }

    protected function _readTag($line)
    {
        if (preg_match('~([^:]+):(.*?)$~i', $line, $matches)) {
            return [
                'tag'   => trim($matches[1]),
                'value' => trim($matches[2]),
            ];
        }

        return false;
    }

    /**
     * @throws RuntimeException
     */
    public function parseClieopResultFile(ObjectInterface $file_object): bool
    {
        $this->reset();

        $state = self::STATE_DEFAULT;

        $block_type = null;

        $contents = $file_object->getContents();
        $contents->rewind();

        while ($line = \GuzzleHttp\Psr7\readline($contents)) {
            $line = trim($line);

            switch ($state) {
                case self::STATE_DEFAULT:
                    if (preg_match($this->getMatchingRegexp(), $line, $matches)) {
                        $this->_result['header']     = [];
                        $this->_result['batch_date'] = $matches[2] . ' ' . $matches[3];

                        $this->report_type = $matches[1];

                        $state = self::STATE_HEADER;

                        continue 2;
                    }

                    throw new RuntimeException(sprintf(
                        '"%s%s" turned out not to be a clieopresult.',
                        $file_object->getNamespace() ? $file_object->getNamespace() . '/' : '',
                        $file_object->getName()
                    ));

                    break;

                case self::STATE_HEADER:
                    if ($line === self::TXT_BATCH_SEPARATOR) {
                        $state      = self::STATE_BLOCKS;
                        $block_type = null;

                        continue 2;
                    }

                    $tag_data = $this->_readTag($line);

                    if ($tag_data !== false) {
                        $this->_result['header'][$tag_data['tag']] = $tag_data['value'];
                    }

                    break;

                case self::STATE_BLOCKS:
                    // Eat empty line;
                    if ($block_type === null) {
                        if ($line === '') {
                            continue 2;
                        }

                        $block_type = $this->_detect_block_type($line);

                        // Stop parsing this type of Human-Readable. We do not rely on it, but rather act on the actual transactions.
                        if ($block_type === self::BLOCK_REJECTION
                            && $this->getReportType() === static::REPORT_TYPE_TRANSACTION
                        ) {
                            // Break out of switch() and while().
                            break 2;
                        }

                        if (isset($this->_result[$block_type])) {
                            throw new RuntimeException(sprintf(
                                'This parser currently only accepts one block per block type. Block with block type "%s" already processed in "%s%s".',
                                $block_type,
                                $file_object->getNamespace() ? $file_object->getNamespace() . '/' : '',
                                $file_object->getName()
                            ));
                        }

                        $this->_result[$block_type] = [];

                        // Eat a line
                        if ($block_type === self::BLOCK_REJECTION) {
                            continue 2;
                        }
                    }

                    if ($line === self::TXT_BATCH_SEPARATOR) {
                        $block_type = null;

                        continue 2;
                    }

                    if ($line === self::TXT_FOOTER_SEPARATOR) {
                        $this->_result['footer'] = [];
                        $state                   = self::STATE_FOOTER;

                        continue 2;
                    }

                    switch ($block_type) {
                        case self::BLOCK_BATCH:
                            $this->_batch_block_read_line($line);

                            break;

                        case self::BLOCK_REJECTION:
                            $this->_rejection_block_read_line($line);

                            break;

                        default:
                            throw new RuntimeException(sprintf(
                                'Unknown blocktype "%s" in file "%s%s"',
                                $block_type,
                                $file_object->getNamespace() ? $file_object->getNamespace() . '/' : '',
                                $file_object->getName()
                            ));
                    }

                    break;

                case self::STATE_FOOTER:
                    $tag_data = $this->_readTag($line);

                    if ($tag_data !== false) {
                        $this->_result['footer'][$tag_data['tag']] = $tag_data['value'];
                    }

                    break;
            }
        }

        $result_is_valid = true;
        $required_fields = ['header', 'batch']; // 'footer' is optional

        foreach ($required_fields as $field) {
            if (!isset($this->_result[$field]) || !is_array($this->_result[$field]) || !count($this->_result[$field])) {
                $result_is_valid = false;

                break;
            }
        }

        if (!$result_is_valid) {
            return false;
        }

        $clieop_result = new Bank_ClieopResult();
        $clieop_result->setInterchangeReference($this->_result['header']['Interchange Reference']);

        if (!empty($this->_result['footer'])) {
            $clieop_result->setTotalAmountFailed(Numbers::parseFloat($this->_result['footer']['Total amount rejected payments']));
        } else {
            $clieop_result->setTotalAmountFailed(Numbers::parseFloat($this->_result['batch']['Amount']));
        }

        $clieop_result->setRawData((string)$file_object->getContents());

        /**
         * It's OK to ignore SEPA Direct Debit Human-Readable TRANSACTION REPORT with rejections.
         */
        if ($this->getReportType() === static::REPORT_TYPE_TRANSACTION
            && $clieop_result->getTotalAmountFailed()
            && isset($this->_result["header"]["Payment Type"])
            && $this->_result["header"]["Payment Type"] === "SEPA DIRECT DEBITS"
        ) {
            return true;
        }

        if (isset($this->_result[self::BLOCK_REJECTION])) {
            $clieop_result->setRejected(true, $this->_result[self::BLOCK_REJECTION]['reason']);
        }

        if (isset($this->clieop_result_statement_handler)
            && !$this->clieop_result_statement_handler->callbackResults($clieop_result)) {
            return false;
        }

        return $result_is_valid;
    }

    private function reset()
    {
        $this->_result = [];
    }

    private function getMatchingRegexp()
    {
        $report_types = implode("|", [static::REPORT_TYPE_BATCH, static::REPORT_TYPE_TRANSACTION]);

        return '~^(' . $report_types . ') ON (\d{2}/\d{2}/\d{2}) AT (\d{2}:\d{2}:\d{2})\r*$~im';
    }

    /**
     * Read a line from a rejection block
     */
    protected function _rejection_block_read_line($line)
    {
        if (!isset($this->_result[self::BLOCK_REJECTION]['reason'])) {
            $this->_result[self::BLOCK_REJECTION]['reason'] = '';
        }

        $this->_result[self::BLOCK_REJECTION]['reason'] .= $line;
    }

    /**
     * Read a line from a batch block
     */
    protected function _batch_block_read_line($line)
    {
        $tag_data = $this->_readTag($line);

        if ($tag_data !== false) {
            $this->_result[self::BLOCK_BATCH][$tag_data['tag']] = $tag_data['value'];
        }
    }

    protected function _detect_block_type($line)
    {
        if (preg_match('~^payment sequence number~i', $line)) {
            return self::BLOCK_BATCH;
        }

        if (preg_match('~^reason\(s\) rejection:~i', $line)) {
            return self::BLOCK_REJECTION;
        }

        return null;
    }

    /**
     * @return string
     */
    private function getReportType()
    {
        return $this->report_type;
    }
}
