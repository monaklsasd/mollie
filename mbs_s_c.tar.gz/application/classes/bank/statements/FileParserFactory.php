<?php

namespace Bank\Statements;

use App\Util\Stream\TracelessReadStream;
use Bank\Statements\Exceptions\UnrecognizedStatementFileException;
use Bank\Statements\Parsers\CashManagement\Camt052ReportFileParser;
use Bank\Statements\Parsers\CashManagement\Camt053StatementFileParser;
use Bank\Statements\Parsers\Mt940\Mt940StatementFileParser;
use BankAccounts\BankAccountRepository;
use Mollie\ObjectStorage\ObjectInterface;

/**
 * This class detects which parser should be used to parse a given statement based on the file contents and then lets
 * that parser parse the file.
 */
class FileParserFactory
{
    /** @var FileExtensionDetector */
    private $file_extension_detector;

    /** @var StatementTransactionBuilder */
    private $statement_transaction_builder;

    /** @var Camt052ReportFileParser */
    private $camt052_parser;

    /** @var BankAccountRepository */
    private $bank_account_repository;

    public function __construct(
        StatementTransactionBuilder $statement_transaction_builder,
        FileExtensionDetector $file_extension_detector,
        Camt052ReportFileParser $camt052_parser,
        BankAccountRepository $bank_account_repository
    ) {
        $this->statement_transaction_builder = $statement_transaction_builder;
        $this->file_extension_detector       = $file_extension_detector;
        $this->camt052_parser                = $camt052_parser;
        $this->bank_account_repository       = $bank_account_repository;
    }

    /**
     * The CAMT053 and MT940 parsers also implement the StatementFileParser interface, so they can simply be returned
     * here.
     *
     * @throws UnrecognizedStatementFileException
     */
    public function getParserForFile(ObjectInterface $file_object): StatementFileParser
    {
        $first_50_kb = $this->readFirst50KbOfFile($file_object);

        $file_extension = $this->file_extension_detector->getFileExtensionForFileContents($first_50_kb);

        switch ($file_extension) {
            case FileExtension::CAMT052():
                return $this->camt052_parser;

            case FileExtension::CAMT053():
                return new Camt053StatementFileParser(
                    $this->statement_transaction_builder,
                    $this->bank_account_repository
                );

            case FileExtension::MT940():
                return new Mt940StatementFileParser(
                    $this->statement_transaction_builder,
                    $this->bank_account_repository
                );
        }

        throw new UnrecognizedStatementFileException(
            "No parser found for statement file with file extension '{$file_extension}'"
        );
    }

    private function readFirst50KbOfFile(ObjectInterface $file_object): string
    {
        $read_stream = new TracelessReadStream($file_object->getContents());
        $read_stream->rewind();

        return $read_stream->read(50 * 1024);
    }
}
