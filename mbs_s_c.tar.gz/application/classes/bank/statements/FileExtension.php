<?php

declare(strict_types=1);

namespace Bank\Statements;

use MyCLabs\Enum\Enum;

/**
 * @method static FileExtension CAMT052()
 * @method static FileExtension CAMT053()
 * @method static FileExtension CLIEOP_RESULT()
 * @method static FileExtension MT940()
 * @method static FileExtension PAIN002()
 * @method static FileExtension RDC_BATCH_STATUS()
 */
final class FileExtension extends Enum
{
    private const CAMT052          = 'camt052';
    private const CAMT053          = 'camt053';
    private const CLIEOP_RESULT    = 'hr';
    private const MT940            = 'mt940';
    private const PAIN002          = 'pain002';
    private const RDC_BATCH_STATUS = 'rdc_status';

    public function isBankToCustomerMessage(): bool
    {
        return in_array($this, [
            self::CAMT052(),
            self::CAMT053(),
            self::MT940(),
        ]);
    }

    public function isBatchResult(): bool
    {
        return in_array($this, [
            self::CLIEOP_RESULT(),
            self::PAIN002(),
            self::RDC_BATCH_STATUS(),
        ]);
    }
}
