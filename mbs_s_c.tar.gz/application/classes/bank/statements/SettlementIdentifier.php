<?php

namespace Bank\Statements;

use Bank\Statements\Exceptions\AmbiguousSettlementTypeException;
use Bank\Statements\Exceptions\UnidentifiedSettlementException;

class SettlementIdentifier
{
    public const SETTLEMENT_PPRO = 'settlement_ppro';

    private const SETTLEMENT_ID_PATTERN_MAP = [
        '(1-143-[DWM]-2\d{3}-\d{1,3})' => self::SETTLEMENT_PPRO,
    ];

    /**
     * @param string $subject
     * @param string $settlement_type_id One of the settlement constants defined in this class.
     *
     * @throws AmbiguousSettlementTypeException
     * @throws UnidentifiedSettlementException
     */
    public function getSettlementIdentifier(?string $subject, string $settlement_type_id): string
    {
        if ($subject === null) {
            throw new UnidentifiedSettlementException(
                'No settlement identifier pattern found for settlement type: ' . $settlement_type_id
            );
        }

        $pattern = array_search($settlement_type_id, self::SETTLEMENT_ID_PATTERN_MAP);

        if ($pattern === false) {
            throw new UnidentifiedSettlementException(
                'No settlement identifier pattern found for settlement type: ' . $settlement_type_id
            );
        }

        preg_match_all($pattern, $subject, $matches);
        $settlement_ids = $matches[0];

        if (empty($settlement_ids)) {
            throw new UnidentifiedSettlementException(
                sprintf('Could not match pattern (%s) with given string: %s', $pattern, $subject)
            );
        }

        if (count($settlement_ids) > 1) {
            throw new AmbiguousSettlementTypeException(
                sprintf(
                    'Found %d settlement identifiers: %s',
                    count($settlement_ids),
                    implode(', ', $settlement_ids)
                )
            );
        }

        return $settlement_ids[0];
    }
}
