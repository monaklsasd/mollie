<?php

namespace Bank\Statements;

use Psr\Http\Message\StreamInterface;

interface StatementFileParser
{
    public function parse(StreamInterface $fileStream): BankToCustomerMessage;
}
