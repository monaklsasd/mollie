<?php

namespace Bank\Statements;

use Bank\Statements\Exceptions\UnrecognizedStatementFileException;

class FileExtensionDetector
{
    private const CAMT052_FILE_REGEX       = "~^\\<\\?xml.*?\\?>\\s*<Document[^>]*>\\s*<BkToCstmrAcctRpt>~im";
    private const CAMT053_FILE_REGEX       = "~^\\<\\?xml.*?\\?>\\s*<Document[^>]*>\\s*<BkToCstmrStmt>~im";
    private const MT940_FILE_REGEX         = "~^(?:ABNANL2A\r\n940\r\nABNANL2A\r\n|(?:0000[^\r]*\r\n)+940 00\r\n)?:20:~";
    private const CLIEOP_RESULT_FILE_REGEX = '~^(BATCH REPORT|TRANSACTION REPORT) ON (\d{2}/\d{2}/\d{2}) AT (\d{2}:\d{2}:\d{2})\r*$~im';
    private const RDC_BATCH_STATUS_REGEX   = '~RDCInitiationReply~im';
    private const PAIN002_FILE_REGEX       = '~Document[^>]*>\s*<CstmrPmtStsRpt>~im';

    /**
     * @throws UnrecognizedStatementFileException
     */
    public function getFileExtensionForFileContents(string $file_contents): FileExtension
    {
        foreach ($this->getRecognizedStatementFileRegexes() as $regex) {
            if (preg_match($regex, $file_contents)) {
                return $this->getFileTypeForRegex($regex);
            }
        }

        throw new UnrecognizedStatementFileException("Unable to create reader for specified file contents");
    }

    /**
     * @return string[]
     */
    private function getRecognizedStatementFileRegexes(): array
    {
        return [
            self::CAMT052_FILE_REGEX,
            self::CAMT053_FILE_REGEX,
            self::MT940_FILE_REGEX,
            self::CLIEOP_RESULT_FILE_REGEX,
            self::RDC_BATCH_STATUS_REGEX,
            self::PAIN002_FILE_REGEX,
        ];
    }

    /**
     * @throws UnrecognizedStatementFileException
     */
    private function getFileTypeForRegex(string $regex): FileExtension
    {
        switch ($regex) {
            case self::MT940_FILE_REGEX:
                return FileExtension::MT940();

            case self::CAMT052_FILE_REGEX:
                return FileExtension::CAMT052();

            case self::CAMT053_FILE_REGEX:
                return FileExtension::CAMT053();

            case self::CLIEOP_RESULT_FILE_REGEX:
                return FileExtension::CLIEOP_RESULT();

            case self::RDC_BATCH_STATUS_REGEX:
                return FileExtension::RDC_BATCH_STATUS();

            case self::PAIN002_FILE_REGEX:
                return FileExtension::PAIN002();
        }

        throw new UnrecognizedStatementFileException("No file extension found for the regex '{$regex}'");
    }
}
