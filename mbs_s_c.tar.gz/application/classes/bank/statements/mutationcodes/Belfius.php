<?php

namespace Bank\Statements\MutationCodes;

/**
 * These mutation codes are specific for the Belfius bank. Other banks use other mutation codes.
 */
final class Belfius
{
    /**
     * This mutation code indicates that a transaction is part of a batch and should be skipped.
     *
     * @const string
     */
    public const MUTATION_CODE_DETAIL = 'DET';

    /**
     * This mutation code indicates that a transaction is a batch.
     *
     * @const string
     */
    public const MUTATION_CODE_COLLECTION = 'COL';

    /**
     * This mutation code indicates that a transaction was initiated manually in the web interface.
     *
     * @const string
     */
    public const MUTATION_CODE_MISCELLANEOUS = 'MSC';

    /**
     * This mutation code indicates that a transaction was received.
     *
     * @const string
     */
    public const MUTATION_CODE_TRANSFER = 'TRF';

    private function __construct()
    {
    }
}
