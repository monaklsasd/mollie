<?php

namespace Bank\Statements\Exceptions;

use Mollie_Exception;

class UnidentifiedSettlementException extends Mollie_Exception
{
}
