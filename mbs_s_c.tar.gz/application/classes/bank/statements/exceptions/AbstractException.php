<?php

namespace Bank\Statements\Exceptions;

use Bank_Exception;

abstract class AbstractException extends Bank_Exception
{
}
