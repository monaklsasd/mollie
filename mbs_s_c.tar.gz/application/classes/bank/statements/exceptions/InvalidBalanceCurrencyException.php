<?php

namespace Bank\Statements\Exceptions;

class InvalidBalanceCurrencyException extends AbstractException
{
}
