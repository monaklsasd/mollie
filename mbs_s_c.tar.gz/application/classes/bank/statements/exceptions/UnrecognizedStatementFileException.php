<?php

namespace Bank\Statements\Exceptions;

class UnrecognizedStatementFileException extends AbstractException
{
}
