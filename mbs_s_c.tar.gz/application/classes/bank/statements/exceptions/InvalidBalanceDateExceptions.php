<?php

namespace Bank\Statements\Exceptions;

class InvalidBalanceDateExceptions extends AbstractException
{
}
