<?php

namespace Bank\Statements\Exceptions;

class AmbiguousSettlementTypeException extends UnidentifiedSettlementException
{
}
