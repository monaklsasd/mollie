<?php

namespace Bank\Statements;

use Money\Money;

class Balance
{
    /** @var Money */
    private $amount;
    /** @var int */
    private $balance_date_unix_timestamp;

    /**
     * @param int $balance_date_unix_timestamp
     */
    public function __construct(Money $amount, $balance_date_unix_timestamp)
    {
        $this->amount                      = $amount;
        $this->balance_date_unix_timestamp = $balance_date_unix_timestamp;
    }

    public function getAmount(): Money
    {
        return $this->amount;
    }

    /**
     * @return int
     */
    public function getBalanceDateUnixTimestamp()
    {
        return $this->balance_date_unix_timestamp;
    }
}
