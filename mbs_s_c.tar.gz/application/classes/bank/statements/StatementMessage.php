<?php

namespace Bank\Statements;

use BankAccounts\BankAccount;
use DateTimeImmutable;
use Generator;

class StatementMessage implements BankToCustomerMessage
{
    /** @var int */
    private $statementNumber;

    /** @var int */
    private $sequenceNumber;

    /** @var Balance */
    private $openingBalance;

    /** @var Balance */
    private $closingBalance;

    /** @var string */
    private $filePath;

    /** @var string */
    private $reference;

    /** @var BankAccount */
    private $bankAccount;

    /** @var StatementTransaction[] */
    private $transactions = [];

    /** @var DateTimeImmutable */
    private $statementDate;

    public function __construct(
        int $statementNumber,
        int $sequenceNumber,
        Balance $openingBalance,
        Balance $closingBalance,
        string $reference,
        DateTimeImmutable $statementDate,
        BankAccount $account,
        Generator $transactions
    ) {
        $this->statementNumber = $statementNumber;
        $this->sequenceNumber  = $sequenceNumber;
        $this->openingBalance  = $openingBalance;
        $this->closingBalance  = $closingBalance;
        $this->reference       = $reference;
        $this->bankAccount     = $account;
        $this->transactions    = $transactions;
        $this->statementDate   = $statementDate;
    }

    // @todo: To be removed when interruptibility for FileProcessor is implemented.
    public function setFilePath(string $filePath): void
    {
        $this->filePath = $filePath;
    }

    // @todo: To be removed when interruptibility for FileProcessor is implemented.
    public function getFilePath(): string
    {
        return $this->filePath;
    }

    public function getReference(): string
    {
        return $this->reference;
    }

    public function getBankAccount(): BankAccount
    {
        return $this->bankAccount;
    }

    /**
     * {@inheritdoc}
     */
    public function yieldTransactions(): Generator
    {
        yield from $this->transactions;
    }

    public function getStatementNumber(): int
    {
        return $this->statementNumber;
    }

    public function getSequenceNumber(): int
    {
        return $this->sequenceNumber;
    }

    public function getOpeningBalance(): Balance
    {
        return $this->openingBalance;
    }

    public function getClosingBalance(): Balance
    {
        return $this->closingBalance;
    }

    public function getDate(): DateTimeImmutable
    {
        return $this->statementDate;
    }
}
