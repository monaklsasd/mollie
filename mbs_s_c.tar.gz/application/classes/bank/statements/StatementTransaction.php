<?php

namespace Bank\Statements;

use Money\Money;

class StatementTransaction
{
    public const INDICATOR_CREDIT = 'C';
    public const INDICATOR_DEBIT  = 'D';

    /** @var Money|null */
    private $amount;

    /** @var Money */
    private $original_amount;

    /** @var string|null */
    private $bank_account_number;

    /** @var string|null */
    private $bic;

    /** @var string|null */
    private $description;

    /** @var int|null */
    private $entry_date_unix_timestamp;

    /** @var int|null */
    private $value_date_unix_timestamp;

    /** @var int|null */
    private $customer_date_unix_timestamp;

    /** @var string|null */
    private $bank_account_name;

    /** @var string|null */
    private $mutation_code;

    /**
     * TODO: This object shouldn't hold a list of all the SWIFT codes.
     *       These are kept here because the Mollie_StatementHandler_... classes rely on the SWIFT codes and refactoring
     *       those is out of scope for now.
     *
     * Key: The SWIFT code constant
     * Value: The value for the SWIFT code
     *
     * @var string[]
     */
    private $swift_codes = [];

    /**
     * @return int
     */
    public function getEntryDateUnixTimestamp()
    {
        return $this->entry_date_unix_timestamp;
    }

    /**
     * @param int $entry_date_unix_timestamp
     */
    public function setEntryDateUnixTimestamp($entry_date_unix_timestamp)
    {
        $this->entry_date_unix_timestamp = $entry_date_unix_timestamp;
    }

    /**
     * @return int
     */
    public function getValueDateUnixTimestamp()
    {
        return $this->value_date_unix_timestamp;
    }

    /**
     * @param int $value_date_unix_timestamp
     */
    public function setValueDateUnixTimestamp($value_date_unix_timestamp)
    {
        $this->value_date_unix_timestamp = $value_date_unix_timestamp;
    }

    /**
     * @return int|null
     */
    public function getCustomerDateUnixTimestamp()
    {
        return $this->customer_date_unix_timestamp;
    }

    /**
     * @param int|null $customer_date_unix_timestamp
     */
    public function setCustomerDateUnixTimestamp($customer_date_unix_timestamp)
    {
        $this->customer_date_unix_timestamp = $customer_date_unix_timestamp;
    }

    public function getAmount(): Money
    {
        return $this->amount;
    }

    public function setAmount(Money $amount): void
    {
        $this->amount = $amount;
    }

    public function getOriginalAmount(): Money
    {
        return $this->original_amount;
    }

    public function setOriginalAmount(Money $original_amount): void
    {
        $this->original_amount = $original_amount;
    }

    /**
     * @return string
     */
    public function getBankAccountNumber()
    {
        return $this->bank_account_number;
    }

    /**
     * @param string $bank_account_number
     */
    public function setBankAccountNumber($bank_account_number)
    {
        $this->bank_account_number = (string)$bank_account_number;
    }

    /**
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * @param string $description
     */
    public function setDescription($description)
    {
        $this->description = (string)$description;
    }

    /**
     * @return string
     */
    public function getBic()
    {
        return $this->bic;
    }

    /**
     * @param string $bic
     */
    public function setBic($bic)
    {
        $this->bic = (string)$bic;
    }

    /**
     * @return string
     */
    public function getBankAccountName()
    {
        return $this->bank_account_name;
    }

    /**
     * @param string $bank_account_name
     */
    public function setBankAccountName($bank_account_name)
    {
        $this->bank_account_name = (string)$bank_account_name;
    }

    /**
     * @return string
     */
    public function getMutationCode()
    {
        return $this->mutation_code;
    }

    /**
     * @param string $mutation_code
     */
    public function setMutationCode($mutation_code)
    {
        $this->mutation_code = (string)$mutation_code;
    }

    public function setSwiftCodes(array $swift_codes)
    {
        $this->swift_codes = $swift_codes;
    }

    public function hasSwiftCode(string $swift_code): bool
    {
        return isset($this->swift_codes[$swift_code]);
    }

    public function getSwiftCodeValue($swift_code): ?string
    {
        if (!$this->hasSwiftCode($swift_code)) {
            return null;
        }

        return $this->swift_codes[$swift_code];
    }
}
