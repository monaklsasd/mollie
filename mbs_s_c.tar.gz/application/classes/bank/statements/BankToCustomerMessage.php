<?php

namespace Bank\Statements;

use BankAccounts\BankAccount;

interface BankToCustomerMessage
{
    // @todo: To be removed when interruptibility for FileProcessor is implemented.
    public function getFilePath(): string;

    public function setFilePath(string $filePath): void;

    public function getReference(): string;

    public function getBankAccount(): BankAccount;

    /**
     * @return StatementTransaction[]
     */
    public function yieldTransactions(): \Generator;

    /**
     * Returns the date this message concerns.
     */
    public function getDate(): \DateTimeImmutable;
}
