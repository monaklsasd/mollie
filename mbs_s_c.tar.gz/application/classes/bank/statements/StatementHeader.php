<?php

namespace Bank\Statements;

class StatementHeader
{
    /** @var string */
    private $reference;

    /** @var string */
    private $account_number;

    /** @var string */
    private $statement_number;

    /** @var string */
    private $sequence_number;

    /**
     * @return string
     */
    public function getReference()
    {
        return $this->reference;
    }

    /**
     * @param string $reference
     */
    public function setReference($reference)
    {
        $this->reference = (string)$reference;
    }

    /**
     * @return string
     */
    public function getAccountNumber()
    {
        return $this->account_number;
    }

    /**
     * @param string $account_number
     */
    public function setAccountNumber($account_number)
    {
        $this->account_number = (string)$account_number;
    }

    /**
     * @return int|null
     */
    public function getStatementNumber()
    {
        return $this->statement_number;
    }

    /**
     * @param int $statement_number
     */
    public function setStatementNumber($statement_number)
    {
        $this->statement_number = (int)$statement_number;
    }

    /**
     * @return int|null
     */
    public function getSequenceNumber()
    {
        return $this->sequence_number;
    }

    /**
     * @param int $sequence_number
     */
    public function setSequenceNumber($sequence_number)
    {
        $this->sequence_number = (int)$sequence_number;
    }
}
