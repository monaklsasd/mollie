<?php

namespace Bank\Statements;

use Bank\Statements\Parsers\CashManagement\Exceptions\MissingTransactionAmountException;
use Bank\Statements\Parsers\CashManagement\Exceptions\MissingTransactionDateException;
use Money\Money;

class StatementTransactionBuilder
{
    /** @var Money|null */
    private $amount;

    /** @var Money */
    private $original_amount;

    /** @var string|null */
    private $bank_account_number;

    /** @var string|null */
    private $bic;

    /** @var string|null */
    private $description;

    /** @var int|null */
    private $entry_date_unix_timestamp;

    /** @var int|null */
    private $value_date_unix_timestamp;

    /** @var int|null */
    private $customer_date_unix_timestamp;

    /** @var string|null */
    private $bank_account_name;

    /** @var string|null */
    private $mutation_code;

    /** @var string[] */
    private $swift_codes = [];

    /**
     * @param Money|null $amount
     *
     * @return $this
     */
    public function setAmount(Money $amount)
    {
        $this->amount = $amount;

        return $this;
    }

    /**
     * @return $this
     */
    public function setOriginalAmount(Money $original_amount)
    {
        $this->original_amount = $original_amount;

        return $this;
    }

    /**
     * @param string $bank_account_number
     *
     * @return $this
     */
    public function setBankAccountNumber($bank_account_number)
    {
        $this->bank_account_number = (string)$bank_account_number;

        return $this;
    }

    /**
     * @param string $bic
     *
     * @return $this
     */
    public function setBic($bic)
    {
        $this->bic = (string)$bic;

        return $this;
    }

    /**
     * @param string $description
     *
     * @return $this
     */
    public function setDescription($description)
    {
        $this->description = (string)$description;

        return $this;
    }

    /**
     * @param int $entry_date_unix_timestamp
     *
     * @return $this
     */
    public function setEntryDateUnixTimestamp($entry_date_unix_timestamp)
    {
        $this->entry_date_unix_timestamp = (int)$entry_date_unix_timestamp;

        return $this;
    }

    /**
     * @param int $value_date_unix_timestamp
     *
     * @return $this
     */
    public function setValueDateUnixTimestamp($value_date_unix_timestamp)
    {
        $this->value_date_unix_timestamp = (int)$value_date_unix_timestamp;

        return $this;
    }

    /**
     * @param int $customer_date_unix_timestamp
     *
     * @return $this
     */
    public function setCustomerDateUnixTimestamp($customer_date_unix_timestamp)
    {
        $this->customer_date_unix_timestamp = (int)$customer_date_unix_timestamp;

        return $this;
    }

    /**
     * @param string $bank_account_name
     *
     * @return $this
     */
    public function setBankAccountName($bank_account_name)
    {
        $this->bank_account_name = (string)$bank_account_name;

        return $this;
    }

    /**
     * @param string $mutation_code
     *
     * @return $this
     */
    public function setMutationCode($mutation_code)
    {
        $this->mutation_code = (string)$mutation_code;

        return $this;
    }

    /**
     * @return $this
     */
    public function setSwiftCodes(array $swift_codes)
    {
        $this->swift_codes = $swift_codes;

        return $this;
    }

    public function build(): StatementTransaction
    {
        $this->validateBuildParameters();

        $statement = new StatementTransaction();

        $statement->setAmount($this->amount);
        $statement->setOriginalAmount($this->original_amount);
        $statement->setDescription($this->description);
        $statement->setBankAccountNumber($this->bank_account_number);
        $statement->setBankAccountName($this->bank_account_name);
        $statement->setBic($this->bic);
        $statement->setMutationCode($this->mutation_code);
        $statement->setValueDateUnixTimestamp($this->value_date_unix_timestamp);
        $statement->setEntryDateUnixTimestamp($this->entry_date_unix_timestamp);
        $statement->setCustomerDateUnixTimestamp($this->customer_date_unix_timestamp);
        $statement->setSwiftCodes($this->swift_codes);

        $this->resetBuildParameters();

        return $statement;
    }

    private function validateBuildParameters()
    {
        if (!$this->amount) {
            throw new MissingTransactionAmountException();
        }

        if (empty($this->entry_date_unix_timestamp)) {
            throw new MissingTransactionDateException("No entry date set for transaction");
        }

        if (empty($this->value_date_unix_timestamp)) {
            throw new MissingTransactionDateException("No value date set for transaction");
        }
    }

    private function resetBuildParameters()
    {
        $this->amount                       = null;
        $this->original_amount              = null;
        $this->description                  = null;
        $this->bank_account_number          = null;
        $this->bank_account_name            = null;
        $this->bic                          = null;
        $this->mutation_code                = null;
        $this->value_date_unix_timestamp    = null;
        $this->entry_date_unix_timestamp    = null;
        $this->customer_date_unix_timestamp = null;
        $this->swift_codes                  = [];
    }
}
