<?php

namespace Bank\Statements;

use BankAccounts\BankAccount;
use DateTimeImmutable;
use Generator;

class ReportMessage implements BankToCustomerMessage
{
    /** @var string */
    private $filePath;

    /** @var string */
    private $reference;

    /** @var BankAccount */
    private $bankAccount;

    /** @var Generator */
    private $transactions;

    /** @var DateTimeImmutable */
    private $date;

    public function __construct(
        string $reference,
        BankAccount $account,
        DateTimeImmutable $date,
        Generator $transactions
    ) {
        $this->reference    = $reference;
        $this->bankAccount  = $account;
        $this->date         = $date;
        $this->transactions = $transactions;
    }

    // @todo: To be removed when interruptibility for FileProcessor is implemented.
    public function setFilePath(string $filePath): void
    {
        $this->filePath = $filePath;
    }

    // @todo: To be removed when interruptibility for FileProcessor is implemented.
    public function getFilePath(): string
    {
        return $this->filePath;
    }

    public function getReference(): string
    {
        return $this->reference;
    }

    public function getBankAccount(): BankAccount
    {
        return $this->bankAccount;
    }

    /**
     * @return StatementTransaction[]
     */
    public function yieldTransactions(): Generator
    {
        yield from $this->transactions;
    }

    public function getDate(): DateTimeImmutable
    {
        return $this->date;
    }
}
