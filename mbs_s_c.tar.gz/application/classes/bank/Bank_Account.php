<?php

declare(strict_types=1);

use Mollie\BankingFiles\Bank\Account;

class Bank_Account extends Account
{
    public static function createFromModelBankTransaction(Model_Banktransaction $model_bank_transaction): Bank_Account
    {
        $bank_account = new static();
        $bank_account->setAccountHolderName($model_bank_transaction->getOffsetAccountName() ?? 'Unknown consumer');
        $bank_account->setNumber($model_bank_transaction->getOffsetAccountNumber());
        $bank_account->setIban($model_bank_transaction->getOffsetAccountNumber());
        $bank_account->setBic($model_bank_transaction->getOffsetAccountBic());

        return $bank_account;
    }

    public function getCountryCode(): ?string
    {
        if (parent::getCountryCode()) {
            return parent::getCountryCode();
        }

        $iban = $this->getIban();

        if ($iban === null) {
            return null;
        }

        return substr($iban, 0, 2);
    }
}
