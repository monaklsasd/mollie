<?php

class Bank_Transfer_Exception extends Bank_Exception
{
}
