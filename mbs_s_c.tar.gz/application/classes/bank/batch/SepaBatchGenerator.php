<?php

declare(strict_types=1);

namespace Bank\Batch;

use App\Entity\User;
use Bank\Batch\Exception\BatchSaveException;
use Bank_Account;
use Bank_FileGenerator_Interface;
use Bank_FileGenerator_Sepa3;
use BankAccounts\BankAccountRepository;
use BankAccounts\Exceptions\BankAccountNotFoundException;
use Log\DatabaseLogger;
use Model_BankPaymentBatch;
use Model_Banktransaction;
use Mollie\BankingFiles\Bank\Transaction\BankTransfer;
use Mollie_Database_Exception;
use Mollie_Database_Exception_Query_DuplicateEntry;
use Mollie_Database_Exception_Query_Lock;
use sql_db;

class SepaBatchGenerator
{
    public const BATCH_GENERATION_LOCK = "Batch_Generation_Lock";

    /** @var BankAccountRepository */
    protected $bank_account_repository;

    /** @var sql_db */
    private $_db;

    /** @var User */
    private $_current_user;

    /** @var DatabaseLogger */
    private $_logger;

    public function __construct(
        sql_db $db,
        BankAccountRepository $bank_account_repository,
        DatabaseLogger $logger
    ) {
        $this->_db                     = $db;
        $this->bank_account_repository = $bank_account_repository;
        $this->_logger                 = $logger;
    }

    public function getCurrentUser(): User
    {
        return $this->_current_user;
    }

    public function setCurrentUser(User $user): void
    {
        $this->_current_user = $user;
    }

    /**
     * @param iterable|Model_Banktransaction[] $transactions
     * @param string[]                         $warnings
     *
     * @throws BankAccountNotFoundException
     * @throws BatchSaveException
     * @throws Mollie_Database_Exception
     * @throws Mollie_Database_Exception_Query_DuplicateEntry
     * @throws Mollie_Database_Exception_Query_Lock
     * @throws \Mollie\BankingFiles\Batch\Exception\WriterException
     *
     * @return Model_BankPaymentBatch[]
     */
    public function createRefundBatchesForTransactions(
        iterable $transactions,
        string $batch_message,
        string $transaction_message,
        array &$warnings
    ): array {
        $bank_file_generators = [];
        $bank_accounts        = []; //for adding descriptions to batch messages

        if (!\is_array($transactions)) {
            $transactions = iterator_to_array($transactions);
        }

        $bankaccount_ids = array_unique(array_map(function (Model_Banktransaction $transaction) {
            return $transaction->getBankAccountId();
        }, $transactions));

        foreach ($bankaccount_ids as $bankaccount_id) {
            $bank_account = $this->bank_account_repository->getById($bankaccount_id);
            $source       = new Bank_Account();
            $source->setAccountHolderName("STICHTING MOLLIE PAYMENTS");
            $source->setBankCity("AMSTERDAM");
            $source->setIban($bank_account::getIban());
            $source->setBic($bank_account::getBankBic());
            $source->setCurrency($bank_account::getCurrency());

            $bank_accounts[$bankaccount_id]        = $bank_account;
            $bank_file_generators[$bankaccount_id] = new Bank_FileGenerator_Sepa3($source);
        }

        try {
            $this->_db->getLock(self::BATCH_GENERATION_LOCK);

            /** @var int[] $ignored_transaction_ids */
            $ignored_transaction_ids = [];

            /** @var int[][] $handled_transaction_ids - bankaccount_id => [transaction ids] */
            $handled_transaction_ids = [];

            /** @var Model_Banktransaction[] $transactions */
            foreach ($transactions as $transaction) {
                /*
                 * Only add the transaction if it hasn't been handled yet. This could have happened in another request, for
                 * example by double clicking the button. This prevents the transactions from ending up in two batches.
                 * The lock, which was previously acquired, ensures that there are no race conditions between two requests.
                 * @issue 20124
                 */
                $generator_sepa = $bank_file_generators[$transaction->getBankAccountId()];

                if (!$generator_sepa->acceptsTransaction($transaction) || $transaction->isHandled()) {
                    $ignored_transaction_ids[] = (int)$transaction->getPrimaryKey();

                    continue;
                }

                $bank_transfer = new BankTransfer();
                $bank_transfer->setAmount($transaction->getAmount());
                $bank_transfer->setInternalReference((string)$transaction->getPrimaryKey());
                $bank_transfer->setRecipientBankAccount(Bank_Account::createFromModelBankTransaction($transaction));
                $bank_transfer->setMessage(sprintf(
                    '%s' . PHP_EOL . 'TR.DATUM %s',
                    mb_substr($transaction_message, 0, 110),
                    ($transaction->getCustomerDate() ?? $transaction->getEntryDate())->format('Y-m-d')
                ));

                $generator_sepa->addTransaction($bank_transfer);

                /*
                 * Group transactions by bank account for correct batch registration id.
                 */
                if (!isset($handled_transaction_ids[$transaction->getBankAccountId()])) {
                    $handled_transaction_ids[$transaction->getBankAccountId()] = [];
                }

                $handled_transaction_ids[$transaction->getBankAccountId()][] = (int)$transaction->getPrimaryKey();
            }

            if (count($ignored_transaction_ids) > 0) {
                $warnings[] = count($ignored_transaction_ids) . ' payments ignored.';
            }

            if (count($handled_transaction_ids) === 0) {
                return [];
            }

            $payment_files = [];
            /** @var Bank_FileGenerator_Interface $generator */
            foreach ($bank_file_generators as $bankaccount_id => $generator) {
                foreach ($generator->generate() as $batch_file) {
                    if ($batch_file->count === 0) {
                        continue; //file contains no transactions
                    }

                    $payment_file = new Model_BankPaymentBatch($this->_db);
                    $payment_file->initFromBatchFile($batch_file, $this->_logger);

                    //only add bank name to batch description for multi-batch jobs
                    $bank_description = '';

                    if (count($bank_file_generators) > 1) {
                        $bank_description = sprintf(
                            ' %s %s',
                            $bank_accounts[$bankaccount_id]::getBankName(),
                            $bank_accounts[$bankaccount_id]::getDescription()
                        );
                    }

                    $payment_file->created_by  = $this->_current_user->getId();
                    $payment_file->description = sprintf(
                        '%s (%s%s)',
                        $batch_message,
                        date('Y-m-d'),
                        $bank_description
                    );

                    if (!$payment_file->save()) {
                        throw new BatchSaveException(sprintf(
                            'Unable to save batches: %s.',
                            implode(', ', $payment_file->getValidationErrors())
                        ));
                    }

                    foreach ($transactions as $transaction) {
                        if ($transaction->getBankAccountId() === $bankaccount_id
                            && in_array(
                                (int)$transaction->getPrimaryKey(),
                                $handled_transaction_ids[$bankaccount_id],
                                true
                            )
                        ) {
                            foreach ($transaction->getRegistrations() as $registration) {
                                $registration->markAsHandledInBatch($payment_file);
                                $registration->saveOrDie();
                            }

                            $batch_url = $this->getBatchUrl($payment_file->id);
                            $transaction->addComment('Added to batch "' .
                                h($payment_file->description) .
                                '":' .
                                $batch_url, $this->_current_user);
                        }
                    }

                    $payment_files[] = $payment_file;
                }
            }

            return $payment_files;
        } finally {
            $this->_db->releaseLock(self::BATCH_GENERATION_LOCK);
        }
    }

    public function getBatchUrl(int $id): string
    {
        $querystring_data = [
            'controller' => 'batches',
            'action'     => 'view',
            'id'         => $id,
        ];

        return MOLLIE_HTTPS_URL . '/?' . http_build_query($querystring_data);
    }
}
