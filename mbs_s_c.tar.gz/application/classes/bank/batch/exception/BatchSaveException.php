<?php

namespace Bank\Batch\Exception;

use Mollie_Exception;

class BatchSaveException extends Mollie_Exception
{
}
