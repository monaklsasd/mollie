<?php

class Bank_Exception extends Mollie_Exception
{
}
