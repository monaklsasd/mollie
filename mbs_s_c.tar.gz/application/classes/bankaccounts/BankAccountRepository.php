<?php

declare(strict_types=1);

namespace BankAccounts;

use Core\Traits\Singleton;
use InvalidArgumentException;
use Webmozart\Assert\Assert;
use function count;

/**
 * Provides easy access to all bank account classes.
 */
class BankAccountRepository
{
    use Singleton;

    /**
     * List of all bank accounts. Please keep this list in alphabetical order.
     *
     * @var string[]
     */
    private const ALL_ACCOUNT_CLASSES = [
        Mollie\CheckingAccount::class,
        Mollie\DepositAccount::class,
        Mollie\DeutscheBankCostsGbpAccount::class,
        Mollie\DeutscheBankCostsUsdAccount::class,
        Mollie\DeutscheBankDepositAccount::class,
        Mollie\DeutscheBankDirectDebitAccount::class,
        Mollie\DeutscheBankDutchCheckingAccount::class,
        Mollie\DeutscheBankGermanCheckingAccount::class,
        Mollie\DeutscheBankFrenchCheckingAccount::class,
        Mollie\DeutscheBankPolishCheckingAccount::class,
        Mollie\DeutscheBankPolishVatAccount::class,
        Mollie\DirectDebitAccount::class,
        Mollie\OldIdealAccount::class,
        Mollie\OldOutpaymentsAccount::class,
        Mollie\RabobankCheckingAccount::class,
        Smp\AbnAmroOutpaymentsAccount::class,
        Smp\AmexAccount::class,
        Smp\BancontactAccount::class,
        Smp\BelfiusDirectNetAccount::class,
        Smp\BelgianBankTransferAccount::class,
        Smp\BitcoinAccount::class,
        Smp\ConsumerRefundsAccount::class,
        Smp\DepositAccount::class,
        Smp\DepositInterestAccount::class,
        Smp\DeutscheBankAmexAccount::class,
        Smp\DeutscheBankBelgiumOutpaymentsAccount::class,
        Smp\DeutscheBankCreditCardAccount::class,
        Smp\DeutscheBankCurrencyDkkAccount::class,
        Smp\DeutscheBankCurrencyGbpAccount::class,
        Smp\DeutscheBankCurrencyNokAccount::class,
        Smp\DeutscheBankCurrencyPlnAccount::class,
        Smp\DeutscheBankCurrencySekAccount::class,
        Smp\DeutscheBankCurrencyUsdAccount::class,
        Smp\DeutscheBankDutchBankTransferAccount::class,
        Smp\DeutscheBankDutchDirectDebitAccount::class,
        Smp\DeutscheBankDutchOutpaymentsAccount::class,
        Smp\DeutscheBankFrenchOutpaymentsAccount::class,
        Smp\DeutscheBankFrenchDirectDebitAccount::class,
        Smp\DeutscheBankFrenchBankTransferAccount::class,
        Smp\DeutscheBankGermanBankTransferAccount::class,
        Smp\DeutscheBankGermanDirectDebitAccount::class,
        Smp\DeutscheBankGermanOutpaymentsAccount::class,
        Smp\DeutscheBankGermanRtpAccount::class,
        Smp\DeutscheBankIdealAccount::class,
        Smp\DeutscheBankKlarnaAccount::class,
        Smp\DeutscheBankMiscellaneousAccount::class,
        Smp\DeutscheBankPolishAcquirersAccount::class,
        Smp\DeutscheBankPolishOutpaymentsAccount::class,
        Smp\DeutscheBankPolishVatAccount::class,
        Smp\DeutscheBankPproAccount::class,
        Smp\DeutscheBankRefundsAccount::class,
        Smp\DeutscheBankSofortAccount::class,
        Smp\DirectDebitAbnAccount::class,
        Smp\DirectDebitIngAccount::class,
        Smp\DirectDebitRabobankAccount::class,
        Smp\DutchBankTransferAccount::class,
        Smp\FrenchBankTransferAccount::class,
        Smp\FutureDepositAccount::class,
        Smp\GermanBankTransferAccount::class,
        Smp\INGHomePayAccount::class,
        Smp\IdealAbnAccount::class,
        Smp\IdealIngAccount::class,
        Smp\IdealRabobankAccount::class,
        Smp\KbcAccount::class,
        Smp\KlarnaAccount::class,
        Smp\OldBancontactAccount::class,
        Smp\OldBelgianBankTransferAccount::class,
        Smp\OldDirectDebitAccount::class,
        Smp\OldSofortAccount::class,
        Smp\PproEurSettlementAccount::class,
        Smp\PproPlnSettlementAccount::class,
        Smp\RabobankOutpaymentsAccount::class,
        Smp\SofortAccount::class,
        Smp\SofortStartselectAccount::class,
        Smp\ValitorAccount::class,
    ];

    /**
     * Get all available bank accounts.
     *
     * @return BankAccount[]
     */
    public function getAllBankAccounts(): array
    {
        Assert::eq(
            count(self::ALL_ACCOUNT_CLASSES),
            count(array_unique(self::ALL_ACCOUNT_CLASSES)),
            'self::ALL_ACCOUNT_CLASSES contains duplicate entries.'
        );

        $all_accounts = [];

        foreach (self::ALL_ACCOUNT_CLASSES as $bank_account_class) {
            $all_accounts[] = $bank_account_class::getInstance();
        }

        return $all_accounts;
    }

    /**
     * @return BankAccount[]
     */
    public function getOutpaymentBankAccounts(): array
    {
        return [
            Smp\AbnAmroOutpaymentsAccount::getInstance(),
            Smp\RabobankOutpaymentsAccount::getInstance(),
            Smp\DeutscheBankGermanOutpaymentsAccount::getInstance(),
            Smp\DeutscheBankDutchOutpaymentsAccount::getInstance(),
            Smp\DeutscheBankPolishOutpaymentsAccount::getInstance(),
            Smp\DeutscheBankBelgiumOutpaymentsAccount::getInstance(),
            Smp\DeutscheBankFrenchOutpaymentsAccount::getInstance(),
        ];
    }

    public function isOutpaymentBankAccount(int $bankAccountId): bool
    {
        foreach ($this->getOutpaymentBankAccounts() as $bankAccount) {
            if ($bankAccount::getId() === $bankAccountId) {
                return true;
            }
        }

        return false;
    }

    /**
     * Get the IBANs and account numbers of all bank accounts defined in MBS as an array of strings.
     *
     * @return string[]
     */
    public function getAllMbsIbansAndAccountNumbers(): array
    {
        $mbs_ibans_and_account_numbers = [];

        foreach (self::ALL_ACCOUNT_CLASSES as $bank_account_class) {
            $mbs_ibans_and_account_numbers[] = $bank_account_class::getIban();
            $mbs_ibans_and_account_numbers[] = $bank_account_class::getAccountNumber();
        }

        return $mbs_ibans_and_account_numbers;
    }

    /**
     * Get the IBANs of all bank accounts defined in MBS as an array
     */
    public function getAllMbsIbans(): array
    {
        $mbs_ibans_and_account_numbers = [];

        foreach (self::ALL_ACCOUNT_CLASSES as $bank_account_class) {
            $mbs_ibans_and_account_numbers[] = $bank_account_class::getIban();
        }

        return $mbs_ibans_and_account_numbers;
    }

    /**
     * Get all IBANs and account numbers related to Mollie.
     *
     * This list will include IBANs and account numbers that are not defined in MBS (either because they have been
     * removed from MBS, or because they are not managed by MBS).
     *
     * This list is provided to easily recognize an account as a Mollie related account in various processes.
     *
     * @return string[]
     */
    public function getAllMollieRelatedIbansAndAccountNumbers(): array
    {
        $mbs_ibans_and_account_numbers = $this->getAllMbsIbansAndAccountNumbers();

        $non_mbs_ibans_and_account_numbers = [
            '127768017',          // Stichting Mollie Payments account at Rabobank
            'NL89RABO0127768017', // + IBAN
            'NL74RABO3314381247', // + IBAN
            '416051995',          // Stichting Mollie Payments account at ABN Amro
        ];

        return array_merge(
            $mbs_ibans_and_account_numbers,
            $non_mbs_ibans_and_account_numbers
        );
    }

    /**
     * Look up a bank account by its unique ID.
     *
     * @param int $bank_account_id (no strict type yet, it's called way to many times from stringly typed model data)
     *
     * @throws Exceptions\BankAccountNotFoundException
     */
    public function getById($bank_account_id): BankAccount
    {
        try {
            $bank_account_class = BankAccountId::getClassName((int)$bank_account_id);
        } catch (InvalidArgumentException $e) {
            throw new Exceptions\BankAccountNotFoundException(sprintf(
                'No bank account with ID %d found.',
                $bank_account_id
            ));
        }

        return $bank_account_class::getInstance();
    }

    /**
     * Look up a bank account by bank account number or IBAN.
     * If a string of digits is given, the first bank account with a matching IBAN is returned.
     *
     * @throws Exceptions\BankAccountNotFoundException
     */
    public function getByIbanOrAccountNumber(string $bank_account_number): BankAccount
    {
        $bank_account_number = preg_replace('/[^A-Z0-9]/', '', mb_strtoupper($bank_account_number));

        $is_iban = !ctype_digit($bank_account_number);

        foreach (self::ALL_ACCOUNT_CLASSES as $bank_account_class) {
            if ($is_iban && $bank_account_class::getIban() === $bank_account_number) {
                return $bank_account_class::getInstance();
            }

            if (!$is_iban && $bank_account_class::getAccountNumber() === $bank_account_number) {
                return $bank_account_class::getInstance();
            }
        }

        throw new Exceptions\BankAccountNotFoundException(sprintf(
            'No bank account found with IBAN or account number "%s".',
            $bank_account_number
        ));
    }
}
