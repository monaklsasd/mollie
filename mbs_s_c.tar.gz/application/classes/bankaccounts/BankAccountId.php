<?php

declare(strict_types=1);

namespace BankAccounts;

use Webmozart\Assert\Assert;
use function array_search;

class BankAccountId
{
    /**
     * Make sure to update the `privileges` and `user_privilege_link`
     * database tables when adding a new bank account.
     */
    private const IDS = [
        Mollie\OldIdealAccount::class                    => 1,
        Smp\IdealAbnAccount::class                       => 7,
        Mollie\CheckingAccount::class                    => 8,
        Smp\AbnAmroOutpaymentsAccount::class             => 9,
        Mollie\DepositAccount::class                     => 10,
        Mollie\OldOutpaymentsAccount::class              => 11,
        Smp\DepositAccount::class                        => 12,
        Mollie\DirectDebitAccount::class                 => 13,
        Smp\ValitorAccount::class                        => 14,
        Smp\OldBancontactAccount::class                  => 15,
        Smp\OldDirectDebitAccount::class                 => 16,
        Smp\DutchBankTransferAccount::class              => 17,
        Smp\ConsumerRefundsAccount::class                => 18,
        Smp\BitcoinAccount::class                        => 19,
        Smp\OldSofortAccount::class                      => 20,
        Smp\OldBelgianBankTransferAccount::class         => 21,
        Smp\DirectDebitAbnAccount::class                 => 22,
        Smp\BelfiusDirectNetAccount::class               => 23,
        Smp\BancontactAccount::class                     => 24,
        Smp\IdealIngAccount::class                       => 25,
        Smp\DepositInterestAccount::class                => 26,
        Smp\BelgianBankTransferAccount::class            => 27,
        Smp\DirectDebitIngAccount::class                 => 28,
        Smp\KbcAccount::class                            => 29,
        Smp\AmexAccount::class                           => 30,
        Smp\SofortAccount::class                         => 31,
        Smp\PproEurSettlementAccount::class              => 32,
        Smp\GermanBankTransferAccount::class             => 33,
        Smp\FrenchBankTransferAccount::class             => 34,
        Smp\SofortStartselectAccount::class              => 35,
        Smp\INGHomePayAccount::class                     => 36,
        Smp\FutureDepositAccount::class                  => 37,
        Smp\KlarnaAccount::class                         => 38,
        Smp\RabobankOutpaymentsAccount::class            => 39,
        Smp\IdealRabobankAccount::class                  => 40,
        Smp\DirectDebitRabobankAccount::class            => 41,
        Mollie\RabobankCheckingAccount::class            => 42,
        Smp\PproPlnSettlementAccount::class              => 43,
        Mollie\DeutscheBankGermanCheckingAccount::class  => 44,
        Smp\DeutscheBankGermanBankTransferAccount::class => 45,
        Smp\DeutscheBankGermanDirectDebitAccount::class  => 46,
        Smp\DeutscheBankGermanOutpaymentsAccount::class  => 47,
        Mollie\DeutscheBankDutchCheckingAccount::class   => 48,
        Mollie\DeutscheBankPolishCheckingAccount::class  => 49,
        Mollie\DeutscheBankDirectDebitAccount::class     => 50,
        Mollie\DeutscheBankDepositAccount::class         => 51,
        Mollie\DeutscheBankCostsGbpAccount::class        => 52,
        Mollie\DeutscheBankCostsUsdAccount::class        => 53,
        Mollie\DeutscheBankPolishVatAccount::class       => 54,
        Smp\DeutscheBankDutchOutpaymentsAccount::class   => 55,
        Smp\DeutscheBankDutchBankTransferAccount::class  => 56,
        Smp\DeutscheBankGermanRtpAccount::class          => 57,
        Smp\DeutscheBankPolishOutpaymentsAccount::class  => 58,
        Smp\DeutscheBankFrenchOutpaymentsAccount::class  => 59,
        Smp\DeutscheBankBelgiumOutpaymentsAccount::class => 60,
        Smp\DeutscheBankDutchDirectDebitAccount::class   => 61,
        Smp\DeutscheBankCreditCardAccount::class         => 62,
        Smp\DeutscheBankRefundsAccount::class            => 63,
        Smp\DeutscheBankSofortAccount::class             => 65,
        Smp\DeutscheBankPproAccount::class               => 66,
        Smp\DeutscheBankKlarnaAccount::class             => 67,
        Smp\DeutscheBankIdealAccount::class              => 68,
        Smp\DeutscheBankAmexAccount::class               => 69,
        Smp\DeutscheBankMiscellaneousAccount::class      => 70,
        Smp\DeutscheBankPolishAcquirersAccount::class    => 71,
        Smp\DeutscheBankPolishVatAccount::class          => 72,
        Smp\DeutscheBankCurrencyDkkAccount::class        => 73,
        Smp\DeutscheBankCurrencyNokAccount::class        => 74,
        Smp\DeutscheBankCurrencySekAccount::class        => 75,
        Smp\DeutscheBankCurrencyUsdAccount::class        => 76,
        Smp\DeutscheBankCurrencyGbpAccount::class        => 77,
        Smp\DeutscheBankCurrencyPlnAccount::class        => 78,
        Mollie\DeutscheBankFrenchCheckingAccount::class  => 79,
        Smp\DeutscheBankFrenchDirectDebitAccount::class  => 80,
        Smp\DeutscheBankFrenchBankTransferAccount::class => 81,
    ];

    public static function getId(string $className): int
    {
        Assert::keyExists(self::IDS, $className, 'Please add an unique ID for bank account "%s"');

        return self::IDS[$className];
    }

    public static function getClassName(int $id): string
    {
        $className = array_search($id, self::IDS, true);
        Assert::notEq(false, $className, sprintf('No bankaccount with ID %d found.', $id));

        return $className;
    }
}
