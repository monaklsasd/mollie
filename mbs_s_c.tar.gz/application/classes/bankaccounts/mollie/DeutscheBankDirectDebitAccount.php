<?php

declare(strict_types=1);

namespace BankAccounts\Mollie;

use StatementHandlers\MollieAccountStatementHandler;
use TransactionHandlers\Misc\AccountingStatusFinalizer;

class DeutscheBankDirectDebitAccount extends AbstractMollieBankAccount
{
    public static function getIban(): string
    {
        return 'NL23DEUT0265000580';
    }

    public static function getBankBic(): string
    {
        return 'DEUTNL2A';
    }

    public static function getBankName(): string
    {
        return 'Deutsche Bank NL';
    }

    public static function getDescription(): string
    {
        return 'Mollie - Deutsche Bank SDD / Incasso rekening';
    }

    public static function getStatementHandlerClass(): string
    {
        return MollieAccountStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [AccountingStatusFinalizer::class];
    }

    public static function getBankTag(): string
    {
        return 'D06';
    }
}
