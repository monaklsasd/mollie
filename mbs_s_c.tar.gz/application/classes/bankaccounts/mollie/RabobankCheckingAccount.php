<?php

declare(strict_types=1);

namespace BankAccounts\Mollie;

use StatementHandlers\MollieAccountStatementHandler;
use TransactionHandlers\Misc\AccountingStatusFinalizer;

/**
 * Our company's general checking account at Rabobank.
 */
class RabobankCheckingAccount extends AbstractMollieBankAccount
{
    public static function getIban(): string
    {
        return 'NL19RABO0340898356';
    }

    public static function getBankBic(): string
    {
        return 'RABONL2U';
    }

    public static function getBankName(): string
    {
        return 'Rabobank';
    }

    public static function getDescription(): string
    {
        return 'Mollie - Rabobank betaalrekening';
    }

    public static function getStatementHandlerClass(): string
    {
        return MollieAccountStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [AccountingStatusFinalizer::class];
    }

    public static function getBankTag(): string
    {
        return 'RA4';
    }
}
