<?php

declare(strict_types=1);

namespace BankAccounts\Mollie;

use StatementHandlers\MollieAccountStatementHandler;
use TransactionHandlers\Misc\AccountingStatusFinalizer;

/**
 * Our company's deposit account at ABN Amro.
 */
class DepositAccount extends AbstractMollieBankAccount
{
    public static function getIban(): string
    {
        return 'NL24ABNA0526449004';
    }

    public static function getBankBic(): string
    {
        return 'ABNANL2A';
    }

    public static function getBankName(): string
    {
        return 'ABN Amro';
    }

    public static function getDescription(): string
    {
        return 'Mollie - Deposito';
    }

    public static function getStatementHandlerClass(): string
    {
        return MollieAccountStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [AccountingStatusFinalizer::class];
    }

    public static function getBankTag(): string
    {
        return 'BK4';
    }
}
