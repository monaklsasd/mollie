<?php

declare(strict_types=1);

namespace BankAccounts\Mollie;

use Core\Money\Currencies;
use Money\Currency;
use StatementHandlers\MollieAccountStatementHandler;
use TransactionHandlers\Misc\AccountingStatusFinalizer;

/**
 * It is mandatory to have a separate VAT account in Poland.
 */
class DeutscheBankPolishVatAccount extends AbstractMollieBankAccount
{
    public static function getIban(): string
    {
        return 'PL37188000090000001150880001';
    }

    public static function getBankBic(): string
    {
        return 'DEUTPLPX';
    }

    public static function getBankName(): string
    {
        return 'Deutsche Bank PL';
    }

    public static function getDescription(): string
    {
        return 'Mollie - Deutsche Bank PL VAT';
    }

    public static function getStatementHandlerClass(): string
    {
        return MollieAccountStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [
            AccountingStatusFinalizer::class,
        ];
    }

    public static function getCurrency(): Currency
    {
        return Currencies::PLN();
    }

    public static function getBankTag(): string
    {
        return 'D08';
    }
}
