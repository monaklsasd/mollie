<?php

declare(strict_types=1);

namespace BankAccounts\Mollie;

use BankAccounts\AbstractBankAccount;

/**
 * If you add any new Mollie B.V. accounts, make sure to update
 * \Accounting\Twinfield\Transformers\BankStatementTransformer::getOrganization() in the twinfield package.
 */
abstract class AbstractMollieBankAccount extends AbstractBankAccount
{
    final public static function getAccountHolder(): string
    {
        return 'Mollie B.V.';
    }

    public static function shouldBeAggregatedForExport(): bool
    {
        return false;
    }
}
