<?php

declare(strict_types=1);

namespace BankAccounts\Mollie;

use StatementHandlers\DefaultStatementHandler;
use TransactionHandlers\Misc\AccountingStatusFinalizer;

/**
 * The old Mollie account at ABN Amro we used to draw outpayments for our merchants from.
 */
class OldOutpaymentsAccount extends AbstractMollieBankAccount
{
    public static function getIban(): string
    {
        return 'NL64ABNA0492919070';
    }

    public static function getBankBic(): string
    {
        return 'ABNANL2A';
    }

    public static function getBankName(): string
    {
        return 'ABN Amro';
    }

    public static function getDescription(): string
    {
        return 'Mollie - Uitbetaalrekening';
    }

    public static function getStatementHandlerClass(): string
    {
        return DefaultStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [AccountingStatusFinalizer::class];
    }

    public static function getBankTag(): string
    {
        return 'BK3';
    }

    public static function isOldAccount(): bool
    {
        return true;
    }
}
