<?php

declare(strict_types=1);

namespace BankAccounts\Mollie;

use StatementHandlers\MollieAccountStatementHandler;
use TransactionHandlers\Misc\AccountingStatusFinalizer;

class DeutscheBankFrenchCheckingAccount extends AbstractMollieBankAccount
{
    public static function getIban(): string
    {
        return 'FR7617789000011055058700053';
    }

    public static function getBankBic(): string
    {
        return 'DEUTFRPP';
    }

    public static function getBankName(): string
    {
        return 'Deutsche Bank FR';
    }

    public static function getDescription(): string
    {
        return 'Mollie - Deutsche Bank FR betaalrekening';
    }

    public static function getStatementHandlerClass(): string
    {
        return MollieAccountStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [AccountingStatusFinalizer::class];
    }

    public static function getBankTag(): string
    {
        return 'D35';
    }
}
