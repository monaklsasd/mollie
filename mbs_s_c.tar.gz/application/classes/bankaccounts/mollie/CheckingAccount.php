<?php

declare(strict_types=1);

namespace BankAccounts\Mollie;

use StatementHandlers\MollieCheckingAccountStatementHandler;
use TransactionHandlers\Misc\AccountingStatusFinalizer;
use TransactionHandlers\Reporting\IncomingLedgerInvoicePaymentReporter;
use TransactionHandlers\Reporting\PrepaymentSettlementReporter;
use TransactionHandlers\Reporting\ReturnedPrepaymentSettlementReporter;

/**
 * Our company's general checking account at ABN Amro.
 */
class CheckingAccount extends AbstractMollieBankAccount
{
    public static function getIban(): string
    {
        return 'NL31ABNA0447075233';
    }

    public static function getBankBic(): string
    {
        return 'ABNANL2A';
    }

    public static function getBankName(): string
    {
        return 'ABN Amro';
    }

    public static function getDescription(): string
    {
        return 'Mollie - Betaalrekening';
    }

    public static function getStatementHandlerClass(): string
    {
        return MollieCheckingAccountStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [
            PrepaymentSettlementReporter::class,
            ReturnedPrepaymentSettlementReporter::class,
            IncomingLedgerInvoicePaymentReporter::class,
            AccountingStatusFinalizer::class,
        ];
    }

    public static function getBankTag(): string
    {
        return 'BNK';
    }
}
