<?php

declare(strict_types=1);

namespace BankAccounts\Mollie;

use StatementHandlers\MollieAccountStatementHandler;
use TransactionHandlers\Misc\AccountingStatusFinalizer;

class DeutscheBankGermanCheckingAccount extends AbstractMollieBankAccount
{
    public static function getIban(): string
    {
        return 'DE97500700100176170900';
    }

    public static function getBankBic(): string
    {
        return 'DEUTDEFF';
    }

    public static function getBankName(): string
    {
        return 'Deutsche Bank DE';
    }

    public static function getDescription(): string
    {
        return 'Mollie - Deutsche Bank DE betaalrekening';
    }

    public static function getStatementHandlerClass(): string
    {
        return MollieAccountStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [AccountingStatusFinalizer::class];
    }

    public static function getBankTag(): string
    {
        return 'D05';
    }
}
