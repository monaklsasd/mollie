<?php

declare(strict_types=1);

namespace BankAccounts\Mollie;

use StatementHandlers\OrderStatementHandler;

/**
 * The old Mollie account at ABN Amro we used to receive iDEAL payments on.
 */
class OldIdealAccount extends AbstractMollieBankAccount
{
    public static function getIban(): string
    {
        return 'NL88ABNA0424612984';
    }

    public static function getBankBic(): string
    {
        return 'ABNANL2A';
    }

    public static function getBankName(): string
    {
        return 'ABN Amro';
    }

    public static function getDescription(): string
    {
        return 'Mollie - Ontvangsten iDEAL';
    }

    public static function getStatementHandlerClass(): string
    {
        return OrderStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [];
    }

    public static function getBankTag(): string
    {
        return 'BK2';
    }

    public static function isOldAccount(): bool
    {
        return true;
    }
}
