<?php

declare(strict_types=1);

namespace BankAccounts;

use Core\Money\Currencies;
use Core\Traits\Singleton;
use Money\Currency;

/**
 * An abstract bank account for all bank accounts to extend.
 */
abstract class AbstractBankAccount implements BankAccount
{
    use Singleton;

    /**
     * @throws Exceptions\UndefinedAccountNumberException
     */
    public static function getAccountNumber(): string
    {
        $iban = static::getIban();

        if (preg_match('/^NL[0-9]{2}[A-Z]{4}/', $iban)) {
            return ltrim(mb_substr($iban, 8), '0');
        }

        if (preg_match('/^[A-Z]{2}[0-9]+$/', $iban)) {
            return mb_substr($iban, 4);
        }

        throw new Exceptions\UndefinedAccountNumberException(sprintf(
            'Account number for bank account %d has not been defined.',
            static::getId()
        ));
    }

    /**
     * Accounts are not considered old by default.
     */
    public static function isOldAccount(): bool
    {
        return false;
    }

    public static function getCurrency(): Currency
    {
        return Currencies::EUR();
    }

    final public static function getId(): int
    {
        return BankAccountId::getId(static::class);
    }
}
