<?php

declare(strict_types=1);

namespace BankAccounts;

use Money\Currency;

/**
 * A Mollie bank account for which MBS retrieves statements and performs reconciliation tasks.
 */
interface BankAccount
{
    /**
     * The bank account's unique ID.
     */
    public static function getId(): int;

    /**
     * The bank account's unique IBAN.
     */
    public static function getIban(): string;

    /**
     * The legacy (i.e. before IBAN) account number.
     */
    public static function getAccountNumber(): string;

    /**
     * The name of the bank account holder, e.g. 'Mollie B.V.' or 'Stichting Mollie Payments'.
     */
    public static function getAccountHolder(): string;

    /**
     * The BIC of the bank that issued the bank account.
     */
    public static function getBankBic(): string;

    /**
     * The name of the bank that issued the bank account.
     */
    public static function getBankName(): string;

    /**
     * A description of the bank account, for UI purposes.
     */
    public static function getDescription(): string;

    /**
     * Returns the currency of the BankAccount
     */
    public static function getCurrency(): Currency;

    /**
     * The class name of the statement handler that handles this bank account's statements.
     */
    public static function getStatementHandlerClass(): string;

    /**
     * Return all transaction handlers that need to run for this bankaccount.
     *
     * @return string[]
     */
    public static function getTransactionHandlerClasses(): array;

    /**
     * Return whether it should group transactions by type when exporting to Twinfield.
     */
    public static function shouldBeAggregatedForExport(): bool;

    /**
     * The banking tag Finance uses to reference this account.
     */
    public static function getBankTag(): string;

    /**
     * Should return true if the account is no longer in use, for example because it has been superseded.
     */
    public static function isOldAccount(): bool;
}
