<?php

declare(strict_types=1);

namespace BankAccounts;

use BankAccounts\Exceptions\BankAccountNotFoundException;
use BankAccounts\Smp\DepositAccount;
use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use function in_array;

class InternalTransactionDetector
{
    /** @var BankAccountRepository */
    private $repository;

    public function __construct(BankAccountRepository $repository)
    {
        $this->repository = $repository;
    }

    public function getInternalTransactionTag(Model_Banktransaction $transaction): ?string
    {
        $target_bankaccount = $this->getTargetBankAccount($transaction);

        if ($target_bankaccount === null) {
            /*
             * It is not an internal bank account that is registered here.
             */
            if (in_array($transaction->getOffsetAccountNumber(), $this->repository->getAllMollieRelatedIbansAndAccountNumbers(), true)) {
                /*
                 * Okay so it is not managed by MBS, well just tag as internal.
                 */
                return TransactionTags::TAG_INTERNAL;
            }

            /*
             * Not an account owned by Mollie B.V. or Stichting Mollie Payments.
             */
            return null;
        }

        if ($transaction->getBankAccount()::getAccountHolder() !== $target_bankaccount::getAccountHolder()) {
            return TransactionTags::TAG_INTRA_COMPANY;
        }

        return TransactionTags::TAG_INTERNAL;
    }

    private function getTargetBankAccount(Model_Banktransaction $transaction): ?BankAccount
    {
        /*
         * Automatisch afromen naar deposito (#10605)
         */
        if ($transaction->getDescription() !== null && stripos($transaction->getDescription(), 'DUTCH TARGET BALANCING') !== false) {
            return DepositAccount::getInstance();
        }

        if ($transaction->getOffsetAccountNumber() === null) {
            return null; // for SEPA transfers, the bankaccount_nr is empty.
        }

        try {
            return $this->repository->getByIbanOrAccountNumber($transaction->getOffsetAccountNumber());
        } catch (BankAccountNotFoundException $e) {
            return null;
        }
    }
}
