<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use Core\Money\Currencies;
use Money\Currency;
use StatementHandlers\PProStatementHandler;
use TransactionHandlers\Expanding\PProBatchExpander;
use TransactionHandlers\Misc\AccountingStatusFinalizer;
use TransactionHandlers\Reporting\PproPrzelewy24Reporter;

class PproPlnSettlementAccount extends AbstractSmpBankAccount
{
    /**
     * The bank account's unique IBAN.
     */
    public static function getIban(): string
    {
        return 'NL51ABNA0833178717';
    }

    /**
     * The BIC of the bank that issued the bank account.
     */
    public static function getBankBic(): string
    {
        return 'ABNANL2A';
    }

    /**
     * The name of the bank that issued the bank account.
     */
    public static function getBankName(): string
    {
        return 'ABN Amro';
    }

    /**
     * A description of the bank account, for UI purposes.
     */
    public static function getDescription(): string
    {
        return 'SMP - Ontvangsten PPRO in Zloty';
    }

    public static function getCurrency(): Currency
    {
        return Currencies::PLN();
    }

    /**
     * The class name of the statement handler that handles this bank account's statements.
     */
    public static function getStatementHandlerClass(): string
    {
        return PProStatementHandler::class;
    }

    /**
     * Return all transaction handlers that need to run for this bankaccount.
     *
     * @return string[]
     */
    public static function getTransactionHandlerClasses(): array
    {
        return [
            PProBatchExpander::class,
            PproPrzelewy24Reporter::class,
            AccountingStatusFinalizer::class,
        ];
    }

    /**
     * The banking tag Finance uses to reference this account.
     */
    public static function getBankTag(): string
    {
        return 'MF4';
    }
}
