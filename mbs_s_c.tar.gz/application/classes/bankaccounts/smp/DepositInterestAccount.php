<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use StatementHandlers\DefaultStatementHandler;
use TransactionHandlers\Misc\AccountingStatusFinalizer;

/**
 * The 'Stichting Mollie Payments' escrow account at ABN Amro we receive our quarterly deposit interest on.
 */
class DepositInterestAccount extends AbstractSmpBankAccount
{
    public static function getIban(): string
    {
        return 'NL93ABNA0625818830';
    }

    public static function getBankBic(): string
    {
        return 'ABNANL2A';
    }

    public static function getBankName(): string
    {
        return 'ABN Amro';
    }

    public static function getDescription(): string
    {
        return 'SMP - Kwartaalrente deposito';
    }

    public static function getStatementHandlerClass(): string
    {
        return DefaultStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [AccountingStatusFinalizer::class];
    }

    public static function shouldBeAggregatedForExport(): bool
    {
        return false;
    }

    public static function getBankTag(): string
    {
        return 'S05';
    }
}
