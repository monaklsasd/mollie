<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use StatementHandlers\OutpaymentStatementHandler;
use TransactionHandlers\Expanding\OutpaymentBatchExpander;
use TransactionHandlers\Misc\AccountingStatusFinalizer;
use TransactionHandlers\Reporting\ReturnedOutpaymentReporter;
use TransactionHandlers\Reporting\ReturnedTransferReporter;
use TransactionHandlers\Reporting\TransferReporter;
use TransactionHandlers\Statistics\GeneralStatementStatisticReporter;

/**
 * The 'Stichting Mollie Payments' escrow account at Rabobank for outpayments to our merchants.
 */
class RabobankOutpaymentsAccount extends AbstractSmpBankAccount
{
    public static function getIban(): string
    {
        return 'NL80RABO0340146575';
    }

    public static function getBankBic(): string
    {
        return 'RABONL2U';
    }

    public static function getBankName(): string
    {
        return 'Rabobank';
    }

    public static function getDescription(): string
    {
        return 'SMP - Rabobank uitbetaalrekening';
    }

    public static function getStatementHandlerClass(): string
    {
        return OutpaymentStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [
            OutpaymentBatchExpander::class,
            ReturnedOutpaymentReporter::class,
            AccountingStatusFinalizer::class,
            GeneralStatementStatisticReporter::class,
            TransferReporter::class,
            ReturnedTransferReporter::class,
        ];
    }

    public static function shouldBeAggregatedForExport(): bool
    {
        return false;
    }

    /**
     * This bank tag was set in the Accountview accounting software.
     * So for the new bank accounts this is just a dummy tag.
     */
    public static function getBankTag(): string
    {
        return 'RA2';
    }
}
