<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use StatementHandlers\IngHomePayStatementHandler;
use TransactionHandlers\Misc\AccountingStatusFinalizer;
use TransactionHandlers\Reporting\IngHomePayReporter;
use TransactionHandlers\Statistics\GeneralStatementStatisticReporter;

/**
 * The 'Stichting Mollie Payments' Belgian ING account we receive Home'Pay payments on.
 */
class INGHomePayAccount extends AbstractSmpBankAccount
{
    public static function getIban(): string
    {
        return 'BE91363062267976';
    }

    public static function getBankBic(): string
    {
        return 'BBRUBEBB';
    }

    public static function getBankName(): string
    {
        return 'ING';
    }

    public static function getDescription(): string
    {
        return 'SMP - Ontvangsten ING Home\'Pay';
    }

    public static function getStatementHandlerClass(): string
    {
        return IngHomePayStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [
            IngHomePayReporter::class,
            AccountingStatusFinalizer::class,
            GeneralStatementStatisticReporter::class,
        ];
    }

    public static function getBankTag(): string
    {
        return 'SM5';
    }
}
