<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use StatementHandlers\IdealStatementHandler;
use TransactionHandlers\Misc\AccountingStatusFinalizer;
use TransactionHandlers\Reporting\IdealReporter;
use TransactionHandlers\Statistics\GeneralStatementStatisticReporter;

class DeutscheBankIdealAccount extends AbstractSmpBankAccount
{
    public static function getIban(): string
    {
        return 'NL51DEUT0265262461';
    }

    public static function getBankBic(): string
    {
        return 'DEUTNL2A';
    }

    public static function getBankName(): string
    {
        return 'Deutsche Bank NL';
    }

    public static function getDescription(): string
    {
        return 'SMP - Deutsche Bank iDEAL account';
    }

    public static function getStatementHandlerClass(): string
    {
        return IdealStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [
            IdealReporter::class,
            AccountingStatusFinalizer::class,
            GeneralStatementStatisticReporter::class,
        ];
    }

    public static function getBankTag(): string
    {
        return 'D24';
    }
}
