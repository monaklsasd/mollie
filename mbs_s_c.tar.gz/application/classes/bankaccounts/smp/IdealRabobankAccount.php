<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use StatementHandlers\IdealStatementHandler;
use TransactionHandlers\Misc\AccountingStatusFinalizer;
use TransactionHandlers\Reporting\IdealReporter;
use TransactionHandlers\Statistics\GeneralStatementStatisticReporter;

/**
 * The 'Stichting Mollie Payments' escrow account at Rabobank we receive iDEAL payments on.
 */
class IdealRabobankAccount extends AbstractSmpBankAccount
{
    public static function getIban(): string
    {
        return 'NL70RABO0115600000';
    }

    public static function getBankBic(): string
    {
        return 'RABONL2U';
    }

    public static function getBankName(): string
    {
        return 'Rabobank';
    }

    public static function getDescription(): string
    {
        return 'SMP - Rabobank ontvangsten iDEAL';
    }

    public static function getStatementHandlerClass(): string
    {
        return IdealStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [
            IdealReporter::class,
            AccountingStatusFinalizer::class,
            GeneralStatementStatisticReporter::class,
        ];
    }

    /**
     * This bank tag was set in the Accountview accounting software.
     * So for the new bank accounts this is just a dummy tag.
     */
    public static function getBankTag(): string
    {
        return 'RA1';
    }
}
