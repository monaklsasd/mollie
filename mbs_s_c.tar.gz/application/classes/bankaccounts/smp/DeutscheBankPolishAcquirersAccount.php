<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use Core\Money\Currencies;
use Money\Currency;
use StatementHandlers\DefaultStatementHandler;
use TransactionHandlers\Misc\AccountingStatusFinalizer;

class DeutscheBankPolishAcquirersAccount extends AbstractSmpBankAccount
{
    public static function getIban(): string
    {
        return 'PL71188000090000001150879001';
    }

    public static function getBankBic(): string
    {
        return 'DEUTPLPX';
    }

    public static function getBankName(): string
    {
        return 'Deutsche Bank PL';
    }

    public static function getDescription(): string
    {
        return 'SMP - Deutsche Bank PL Acquirers';
    }

    public static function getStatementHandlerClass(): string
    {
        return DefaultStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [
            AccountingStatusFinalizer::class,
        ];
    }

    public static function getCurrency(): Currency
    {
        return Currencies::PLN();
    }

    public static function shouldBeAggregatedForExport(): bool
    {
        return false;
    }

    public static function getBankTag(): string
    {
        return 'D27';
    }
}
