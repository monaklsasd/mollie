<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use StatementHandlers\DefaultStatementHandler;
use TransactionHandlers\Misc\AccountingStatusFinalizer;

/**
 * DB Instant payments
 */
class DeutscheBankGermanRtpAccount extends AbstractSmpBankAccount
{
    public static function getIban(): string
    {
        return 'DE78500700100176172503';
    }

    public static function getBankBic(): string
    {
        return 'DEUTDEFF';
    }

    public static function getBankName(): string
    {
        return 'Deutsche Bank DE';
    }

    public static function getDescription(): string
    {
        return 'SMP - Deutsche Bank RTP';
    }

    public static function getStatementHandlerClass(): string
    {
        return DefaultStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [
            AccountingStatusFinalizer::class,
        ];
    }

    public static function getBankTag(): string
    {
        return 'D14';
    }
}
