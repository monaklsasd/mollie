<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use BankAccounts\AbstractBankAccount;

abstract class AbstractSmpBankAccount extends AbstractBankAccount
{
    final public static function getAccountHolder(): string
    {
        return 'Stichting Mollie Payments';
    }

    public static function shouldBeAggregatedForExport(): bool
    {
        return true;
    }
}
