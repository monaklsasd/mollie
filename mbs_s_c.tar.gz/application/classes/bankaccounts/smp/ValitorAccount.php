<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use StatementHandlers\CreditcardStatementHandler;
use TransactionHandlers\Expanding\CreditcardBatchExpander;
use TransactionHandlers\Misc\AccountingStatusFinalizer;
use TransactionHandlers\Reporting\CreditcardReporter;
use TransactionHandlers\Splitting\MultiCurrencyTransactionSplitter;
use TransactionHandlers\Statistics\GeneralStatementStatisticReporter;

/**
 * The 'Stichting Mollie Payments' escrow account at ABN Amro we receive Valitor credit card settlements on.
 */
class ValitorAccount extends AbstractSmpBankAccount
{
    public static function getIban(): string
    {
        return 'NL72ABNA0624807304';
    }

    public static function getBankBic(): string
    {
        return 'ABNANL2A';
    }

    public static function getBankName(): string
    {
        return 'ABN Amro';
    }

    public static function getDescription(): string
    {
        return 'SMP - Ontvangsten Valitor';
    }

    public static function getStatementHandlerClass(): string
    {
        return CreditcardStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [
            CreditcardBatchExpander::class,
            CreditcardReporter::class,
            MultiCurrencyTransactionSplitter::class,
            AccountingStatusFinalizer::class,
            GeneralStatementStatisticReporter::class,
        ];
    }

    public static function getBankTag(): string
    {
        return 'ST3';
    }
}
