<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use StatementHandlers\DirectDebitStatementHandler;
use TransactionHandlers\Misc\AccountingStatusFinalizer;

/**
 * The 'Stichting Mollie Payments' escrow account at ING we receive SEPA Direct Debit settlements on.
 */
class DirectDebitIngAccount extends AbstractSmpBankAccount
{
    public static function getIban(): string
    {
        return 'NL60INGB0007191975';
    }

    public static function getBankBic(): string
    {
        return 'INGBNL2A';
    }

    public static function getBankName(): string
    {
        return 'ING';
    }

    public static function getDescription(): string
    {
        return 'SMP - Ontvangsten SEPA Direct Debit';
    }

    public static function getStatementHandlerClass(): string
    {
        return DirectDebitStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [AccountingStatusFinalizer::class];
    }

    public static function getBankTag(): string
    {
        return 'S07';
    }
}
