<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use StatementHandlers\DirectDebitStatementHandler;
use TransactionHandlers\Expanding\DirectDebitBatchExpander;
use TransactionHandlers\Misc\AccountingStatusFinalizer;
use TransactionHandlers\Misc\DirectDebitEuCostsCharger;
use TransactionHandlers\Reporting\DirectDebitFailureReporter;
use TransactionHandlers\Reporting\DirectDebitReporter;
use TransactionHandlers\Statistics\GeneralStatementStatisticReporter;

/**
 * The 'Stichting Mollie Payments' escrow account at ABN Amro we receive SEPA Direct Debit and SOFORT Banking
 * settlements on.
 */
class DirectDebitAbnAccount extends AbstractSmpBankAccount
{
    public static function getIban(): string
    {
        return 'NL44ABNA0428063969';
    }

    public static function getBankBic(): string
    {
        return 'ABNANL2A';
    }

    public static function getBankName(): string
    {
        return 'ABN Amro';
    }

    public static function getDescription(): string
    {
        return 'SMP - Ontvangsten SEPA Direct Debit';
    }

    public static function getStatementHandlerClass(): string
    {
        return DirectDebitStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [
            DirectDebitBatchExpander::class,
            DirectDebitReporter::class,
            DirectDebitFailureReporter::class,
            DirectDebitEuCostsCharger::class,
            AccountingStatusFinalizer::class,
            GeneralStatementStatisticReporter::class,
        ];
    }

    public static function getBankTag(): string
    {
        return 'S01';
    }
}
