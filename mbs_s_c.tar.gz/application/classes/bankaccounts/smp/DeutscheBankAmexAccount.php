<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use StatementHandlers\AmexStatementHandler;
use TransactionHandlers\Expanding\AmexBatchExpander;
use TransactionHandlers\Misc\AccountingStatusFinalizer;
use TransactionHandlers\Reporting\AmexReporter;
use TransactionHandlers\Splitting\MultiCurrencyTransactionSplitter;
use TransactionHandlers\Statistics\GeneralStatementStatisticReporter;

class DeutscheBankAmexAccount extends AbstractSmpBankAccount
{
    public static function getIban(): string
    {
        return 'NL20DEUT0265262534';
    }

    public static function getBankBic(): string
    {
        return 'DEUTNL2A';
    }

    public static function getBankName(): string
    {
        return 'Deutsche Bank NL';
    }

    public static function getDescription(): string
    {
        return 'SMP - Deutsche Bank AMEX account';
    }

    public static function getStatementHandlerClass(): string
    {
        return AmexStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [
            AmexBatchExpander::class,
            AmexReporter::class,
            MultiCurrencyTransactionSplitter::class,
            AccountingStatusFinalizer::class,
            GeneralStatementStatisticReporter::class,
        ];
    }

    public static function getBankTag(): string
    {
        return 'D25';
    }
}
