<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use Core\Money\Currencies;
use Money\Currency;
use StatementHandlers\DefaultStatementHandler;
use TransactionHandlers\Misc\AccountingStatusFinalizer;

class DeutscheBankCurrencyUsdAccount extends AbstractSmpBankAccount
{
    public static function getIban(): string
    {
        return 'NL30DEUT0265095514';
    }

    public static function getBankBic(): string
    {
        return 'DEUTNL2A';
    }

    public static function getBankName(): string
    {
        return 'Deutsche Bank NL';
    }

    public static function getDescription(): string
    {
        return 'SMP - Deutsche Bank USD';
    }

    public static function getStatementHandlerClass(): string
    {
        return DefaultStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [
            AccountingStatusFinalizer::class,
        ];
    }

    public static function getCurrency(): Currency
    {
        return Currencies::USD();
    }

    public static function getBankTag(): string
    {
        return 'D32';
    }
}
