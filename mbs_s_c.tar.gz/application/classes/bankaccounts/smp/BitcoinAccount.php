<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use StatementHandlers\BitcoinStatementHandler;
use TransactionHandlers\Misc\AccountingStatusFinalizer;
use TransactionHandlers\Statistics\GeneralStatementStatisticReporter;

/**
 * The 'Stichting Mollie Payments' escrow account at ABN Amro we receive Bitcoin settlements on.
 */
class BitcoinAccount extends AbstractSmpBankAccount
{
    public static function getIban(): string
    {
        return 'NL56ABNA0486819272';
    }

    public static function getBankBic(): string
    {
        return 'ABNANL2A';
    }

    public static function getBankName(): string
    {
        return 'ABN Amro';
    }

    public static function getDescription(): string
    {
        return 'SMP - Ontvangsten Bitcoin';
    }

    public static function getStatementHandlerClass(): string
    {
        return BitcoinStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [
            AccountingStatusFinalizer::class,
            GeneralStatementStatisticReporter::class,
        ];
    }

    public static function shouldBeAggregatedForExport(): bool
    {
        return false;
    }

    public static function getBankTag(): string
    {
        return 'ST8';
    }
}
