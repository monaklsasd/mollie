<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use StatementHandlers\RefundsStatementHandler;
use TransactionHandlers\Expanding\RefundsBatchExpander;
use TransactionHandlers\Misc\AccountingStatusFinalizer;
use TransactionHandlers\Reporting\RefundReporter;
use TransactionHandlers\Reporting\ReturnedRefundReporter;
use TransactionHandlers\Splitting\MultiCurrencyTransactionSplitter;
use TransactionHandlers\Statistics\GeneralStatementStatisticReporter;

/**
 * The 'Stichting Mollie Payments' escrow account at ABN Amro we use for outgoing refunds to consumers.
 */
class ConsumerRefundsAccount extends AbstractSmpBankAccount
{
    public static function getIban(): string
    {
        return 'NL80ABNA0627562930';
    }

    public static function getBankBic(): string
    {
        return 'ABNANL2A';
    }

    public static function getBankName(): string
    {
        return 'ABN Amro';
    }

    public static function getDescription(): string
    {
        return 'SMP - Refunds aan consumenten';
    }

    public static function getStatementHandlerClass(): string
    {
        return RefundsStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [
            RefundsBatchExpander::class,
            ReturnedRefundReporter::class,
            RefundReporter::class,
            MultiCurrencyTransactionSplitter::class,
            AccountingStatusFinalizer::class,
            GeneralStatementStatisticReporter::class,
        ];
    }

    public static function getBankTag(): string
    {
        return 'ST7';
    }
}
