<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use StatementHandlers\BanktransferStatementHandler;
use TransactionHandlers\Misc\AccountingStatusFinalizer;
use TransactionHandlers\Reporting\BanktransferReporter;
use TransactionHandlers\Splitting\BanktransferSettlementSplitter;
use TransactionHandlers\Statistics\GeneralStatementStatisticReporter;

/**
 * The 'Stichting Mollie Payments' escrow account at ABN Amro we receive Belgian SEPA Credit Transfers on as per our
 * 'Bank transfer' payment method.
 */
class GermanBankTransferAccount extends AbstractSmpBankAccount
{
    public static function getIban(): string
    {
        return 'DE35500210000010138147';
    }

    public static function getBankBic(): string
    {
        return 'INGBDEFF';
    }

    public static function getBankName(): string
    {
        return 'ING';
    }

    public static function getDescription(): string
    {
        return 'SMP - Ontvangsten overboeking Duitsland (SEPA Credit Transfer)';
    }

    public static function getStatementHandlerClass(): string
    {
        return BanktransferStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [
            BanktransferReporter::class,
            BanktransferSettlementSplitter::class,
            AccountingStatusFinalizer::class,
            GeneralStatementStatisticReporter::class,
        ];
    }

    public static function getBankTag(): string
    {
        return 'SM3';
    }
}
