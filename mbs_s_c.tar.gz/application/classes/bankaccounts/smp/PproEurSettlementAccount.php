<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use StatementHandlers\PProStatementHandler;
use TransactionHandlers\Expanding\PProBatchExpander;
use TransactionHandlers\Misc\AccountingStatusFinalizer;
use TransactionHandlers\Reporting\PproBancontactReporter;
use TransactionHandlers\Reporting\PproEpsReporter;
use TransactionHandlers\Reporting\PproGiropayReporter;
use TransactionHandlers\Reporting\PproIdealReporter;
use TransactionHandlers\Reporting\PproMyBankReporter;
use TransactionHandlers\Reporting\PproPrzelewy24Reporter;
use TransactionHandlers\Statistics\GeneralStatementStatisticReporter;

/**
 * The alternative 'Stichting Mollie Payments' escrow account at ABN Amro we receive PPro Transfers for various
 * Payment Methods, but for this time only
 */
class PproEurSettlementAccount extends AbstractSmpBankAccount
{
    public static function getIban(): string
    {
        return 'NL88ABNA0524551987';
    }

    public static function getBankBic(): string
    {
        return 'ABNANL2A';
    }

    public static function getBankName(): string
    {
        return 'ABN Amro';
    }

    public static function getDescription(): string
    {
        return 'SMP - Ontvangsten PPRO in euro';
    }

    public static function getStatementHandlerClass(): string
    {
        return PProStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [
            PProBatchExpander::class,
            PproBancontactReporter::class,
            PproEpsReporter::class,
            PproGiropayReporter::class,
            PproIdealReporter::class,
            PproMyBankReporter::class,
            PproPrzelewy24Reporter::class,
            AccountingStatusFinalizer::class,
            GeneralStatementStatisticReporter::class,
        ];
    }

    public static function getBankTag(): string
    {
        return 'SM2';
    }
}
