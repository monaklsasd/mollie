<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use StatementHandlers\BanktransferStatementHandler;
use TransactionHandlers\Expanding\SepaBatchExpander;
use TransactionHandlers\Misc\AccountingStatusFinalizer;
use TransactionHandlers\Reporting\BanktransferReporter;
use TransactionHandlers\Splitting\BanktransferSettlementSplitter;
use TransactionHandlers\Statistics\GeneralStatementStatisticReporter;

/**
 * The old 'Stichting Mollie Payments' escrow account at ABN Amro we used to receive Belgian SEPA Credit Transfers on as
 * per our 'Bank transfer' payment method.
 */
class OldBelgianBankTransferAccount extends AbstractSmpBankAccount
{
    public static function getIban(): string
    {
        return 'BE54719400092697';
    }

    public static function getBankBic(): string
    {
        return 'FTSBBE22';
    }

    public static function getBankName(): string
    {
        return 'ABN Amro';
    }

    public static function getDescription(): string
    {
        return 'SMP - Ontvangsten overboeking België (SEPA Credit Transfer)';
    }

    public static function getStatementHandlerClass(): string
    {
        return BanktransferStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [
            SepaBatchExpander::class,
            BanktransferReporter::class,
            BanktransferSettlementSplitter::class,
            AccountingStatusFinalizer::class,
            GeneralStatementStatisticReporter::class,
        ];
    }

    public static function getBankTag(): string
    {
        return 'ST0';
    }

    public static function isOldAccount(): bool
    {
        return true;
    }
}
