<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use StatementHandlers\KlarnaStatementHandler;
use TransactionHandlers\Expanding\KlarnaBatchExpander;
use TransactionHandlers\Misc\AccountingStatusFinalizer;
use TransactionHandlers\Reporting\KlarnaReporter;
use TransactionHandlers\Splitting\KlarnaFeeSplitter;
use TransactionHandlers\Statistics\GeneralStatementStatisticReporter;

/**
 * The 'Stichting Mollie Payments' escrow account at ABN Amro we receive Klarna payments on
 */
class KlarnaAccount extends AbstractSmpBankAccount
{
    public static function getIban(): string
    {
        return 'NL56ABNA0824000196';
    }

    public static function getBankBic(): string
    {
        return 'ABNANL2A';
    }

    public static function getBankName(): string
    {
        return 'ABN Amro';
    }

    public static function getDescription(): string
    {
        return 'SMP - Ontvangsten Klarna';
    }

    public static function getStatementHandlerClass(): string
    {
        return KlarnaStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [
            KlarnaBatchExpander::class,
            KlarnaReporter::class,
            KlarnaFeeSplitter::class,
            AccountingStatusFinalizer::class,
            GeneralStatementStatisticReporter::class,
        ];
    }

    public static function getBankTag(): string
    {
        return 'SM8';
    }
}
