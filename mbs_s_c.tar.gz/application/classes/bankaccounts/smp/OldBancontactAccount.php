<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use StatementHandlers\MisterCashStatementHandler;
use TransactionHandlers\Misc\AccountingStatusFinalizer;
use TransactionHandlers\Reporting\BancontactReporter;
use TransactionHandlers\Statistics\GeneralStatementStatisticReporter;

/**
 * The old 'Stichting Mollie Payments' escrow account at ABN Amro we used to receive Bancontact settlements on.
 */
class OldBancontactAccount extends AbstractSmpBankAccount
{
    public static function getIban(): string
    {
        return 'BE66719400067843';
    }

    public static function getBankBic(): string
    {
        return 'FTSBBE22';
    }

    public static function getBankName(): string
    {
        return 'ABN Amro';
    }

    public static function getDescription(): string
    {
        return 'SMP - Ontvangsten Bancontact';
    }

    public static function getStatementHandlerClass(): string
    {
        return MisterCashStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [
            BancontactReporter::class,
            AccountingStatusFinalizer::class,
            GeneralStatementStatisticReporter::class,
        ];
    }

    public static function getBankTag(): string
    {
        return 'ST4';
    }

    public static function isOldAccount(): bool
    {
        return true;
    }
}
