<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use StatementHandlers\CreditcardStatementHandler;
use TransactionHandlers\Expanding\CreditcardBatchExpander;
use TransactionHandlers\Misc\AccountingStatusFinalizer;
use TransactionHandlers\Reporting\CreditcardReporter;
use TransactionHandlers\Splitting\MultiCurrencyTransactionSplitter;
use TransactionHandlers\Statistics\GeneralStatementStatisticReporter;

class DeutscheBankCreditCardAccount extends AbstractSmpBankAccount
{
    public static function getIban(): string
    {
        return 'NL48DEUT0265262321';
    }

    public static function getBankBic(): string
    {
        return 'DEUTNL2A';
    }

    public static function getBankName(): string
    {
        return 'Deutsche Bank NL';
    }

    public static function getDescription(): string
    {
        return 'SMP - Deutsche Bank Credit Card account';
    }

    public static function getStatementHandlerClass(): string
    {
        return CreditcardStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [
            CreditcardBatchExpander::class,
            CreditcardReporter::class,
            MultiCurrencyTransactionSplitter::class,
            AccountingStatusFinalizer::class,
            GeneralStatementStatisticReporter::class,
        ];
    }

    public static function getBankTag(): string
    {
        return 'D19';
    }
}
