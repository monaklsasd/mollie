<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use StatementHandlers\DefaultStatementHandler;
use TransactionHandlers\Misc\AccountingStatusFinalizer;

/**
 * Will be used to replace the current Deposit bank account in the future
 */
class FutureDepositAccount extends AbstractSmpBankAccount
{
    public static function getIban(): string
    {
        return 'NL68ABNA0817772871';
    }

    public static function getBankBic(): string
    {
        return 'ABNANL2A';
    }

    public static function getBankName(): string
    {
        return 'ABN Amro';
    }

    public static function getDescription(): string
    {
        return 'SMP - Cash Pool';
    }

    public static function getStatementHandlerClass(): string
    {
        return DefaultStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [AccountingStatusFinalizer::class];
    }

    public static function shouldBeAggregatedForExport(): bool
    {
        return false;
    }

    public static function getBankTag(): string
    {
        return 'SM7';
    }
}
