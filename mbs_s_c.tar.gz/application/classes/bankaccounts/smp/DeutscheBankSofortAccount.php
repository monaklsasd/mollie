<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use StatementHandlers\SofortStatementHandler;
use TransactionHandlers\Misc\AccountingStatusFinalizer;
use TransactionHandlers\Reporting\SofortReporter;
use TransactionHandlers\Statistics\GeneralStatementStatisticReporter;

class DeutscheBankSofortAccount extends AbstractSmpBankAccount
{
    public static function getIban(): string
    {
        return 'NL98DEUT0265262488';
    }

    public static function getBankBic(): string
    {
        return 'DEUTNL2A';
    }

    public static function getBankName(): string
    {
        return 'Deutsche Bank NL';
    }

    public static function getDescription(): string
    {
        return 'SMP - Deutsche Bank Sofort account';
    }

    public static function getStatementHandlerClass(): string
    {
        return SofortStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [
            SofortReporter::class,
            AccountingStatusFinalizer::class,
            GeneralStatementStatisticReporter::class,
        ];
    }

    public static function getBankTag(): string
    {
        return 'D21';
    }
}
