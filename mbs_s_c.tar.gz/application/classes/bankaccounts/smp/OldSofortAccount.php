<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use StatementHandlers\SofortStatementHandler;
use TransactionHandlers\Misc\AccountingStatusFinalizer;
use TransactionHandlers\Reporting\SofortReporter;
use TransactionHandlers\Statistics\GeneralStatementStatisticReporter;

/**
 * The old 'Stichting Mollie Payments' escrow account at ABN Amro we used to receive SOFORT Banking settlements on.
 */
class OldSofortAccount extends AbstractSmpBankAccount
{
    public static function getIban(): string
    {
        return 'NL98ABNA0428105580';
    }

    public static function getBankBic(): string
    {
        return 'ABNANL2A';
    }

    public static function getBankName(): string
    {
        return 'ABN Amro';
    }

    public static function getDescription(): string
    {
        return 'SMP - Ontvangsten SOFORT Banking';
    }

    public static function getStatementHandlerClass(): string
    {
        return SofortStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [
            SofortReporter::class,
            AccountingStatusFinalizer::class,
            GeneralStatementStatisticReporter::class,
        ];
    }

    public static function getBankTag(): string
    {
        return 'ST9';
    }

    public static function isOldAccount(): bool
    {
        return true;
    }
}
