<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use StatementHandlers\DefaultStatementHandler;
use TransactionHandlers\Misc\AccountingStatusFinalizer;

/**
 * The 'Stichting Mollie Payments' escrow deposit account at ABN Amro.
 */
class DepositAccount extends AbstractSmpBankAccount
{
    public static function getIban(): string
    {
        return 'NL07ABNA0531185141';
    }

    public static function getBankBic(): string
    {
        return 'ABNANL2A';
    }

    public static function getBankName(): string
    {
        return 'ABN Amro';
    }

    public static function getDescription(): string
    {
        return 'SMP - Deposito';
    }

    public static function getStatementHandlerClass(): string
    {
        return DefaultStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [AccountingStatusFinalizer::class];
    }

    public static function shouldBeAggregatedForExport(): bool
    {
        return false;
    }

    public static function getBankTag(): string
    {
        return 'BK0';
    }
}
