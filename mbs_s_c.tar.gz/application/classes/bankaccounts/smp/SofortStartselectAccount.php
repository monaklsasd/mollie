<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use StatementHandlers\SofortStatementHandler;
use TransactionHandlers\Misc\AccountingStatusFinalizer;
use TransactionHandlers\Reporting\SofortReporter;
use TransactionHandlers\Statistics\GeneralStatementStatisticReporter;

/**
 * The 'Stichting Mollie Payments' escrow account at ABN Amro we receive SOFORT Banking settlements on for our prepaid
 * service merchant Startselect.
 */
class SofortStartselectAccount extends AbstractSmpBankAccount
{
    public static function getIban(): string
    {
        return 'NL80ABNA0543136167';
    }

    public static function getBankBic(): string
    {
        return 'ABNANL2A';
    }

    public static function getBankName(): string
    {
        return 'ABN Amro';
    }

    public static function getDescription(): string
    {
        return 'SMP - Ontvangsten SOFORT Banking voor merchant Startselect';
    }

    public static function getStatementHandlerClass(): string
    {
        return SofortStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [
            SofortReporter::class,
            AccountingStatusFinalizer::class,
            GeneralStatementStatisticReporter::class,
        ];
    }

    public static function getBankTag(): string
    {
        return 'SM6';
    }
}
