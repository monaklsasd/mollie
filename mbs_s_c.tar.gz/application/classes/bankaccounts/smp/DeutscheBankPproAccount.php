<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use StatementHandlers\PProStatementHandler;
use TransactionHandlers\Expanding\PProBatchExpander;
use TransactionHandlers\Misc\AccountingStatusFinalizer;
use TransactionHandlers\Reporting\PproBancontactReporter;
use TransactionHandlers\Reporting\PproEpsReporter;
use TransactionHandlers\Reporting\PproGiropayReporter;
use TransactionHandlers\Reporting\PproIdealReporter;
use TransactionHandlers\Reporting\PproMyBankReporter;
use TransactionHandlers\Reporting\PproPrzelewy24Reporter;
use TransactionHandlers\Statistics\GeneralStatementStatisticReporter;

class DeutscheBankPproAccount extends AbstractSmpBankAccount
{
    public static function getIban(): string
    {
        return 'NL76DEUT0265262496';
    }

    public static function getBankBic(): string
    {
        return 'DEUTNL2A';
    }

    public static function getBankName(): string
    {
        return 'Deutsche Bank NL';
    }

    public static function getDescription(): string
    {
        return 'SMP - Deutsche Bank PPRO account';
    }

    public static function getStatementHandlerClass(): string
    {
        return PProStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [
            PProBatchExpander::class,
            PproBancontactReporter::class,
            PproEpsReporter::class,
            PproGiropayReporter::class,
            PproIdealReporter::class,
            PproMyBankReporter::class,
            PproPrzelewy24Reporter::class,
            AccountingStatusFinalizer::class,
            GeneralStatementStatisticReporter::class,
        ];
    }

    public static function getBankTag(): string
    {
        return 'D22';
    }
}
