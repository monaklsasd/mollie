<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use StatementHandlers\OutpaymentStatementHandler;
use TransactionHandlers\Expanding\OutpaymentBatchExpander;
use TransactionHandlers\Misc\AccountingStatusFinalizer;
use TransactionHandlers\Reporting\ReturnedOutpaymentReporter;
use TransactionHandlers\Reporting\ReturnedTransferReporter;
use TransactionHandlers\Reporting\TransferReporter;
use TransactionHandlers\Statistics\GeneralStatementStatisticReporter;

class DeutscheBankDutchOutpaymentsAccount extends AbstractSmpBankAccount
{
    public static function getIban(): string
    {
        return 'NL92DEUT0265262305';
    }

    public static function getBankBic(): string
    {
        return 'DEUTNL2A';
    }

    public static function getBankName(): string
    {
        return 'Deutsche Bank NL';
    }

    public static function getDescription(): string
    {
        return 'SMP - Deutsche Bank NL uitbetaalrekening';
    }

    public static function getStatementHandlerClass(): string
    {
        return OutpaymentStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [
            OutpaymentBatchExpander::class,
            ReturnedOutpaymentReporter::class,
            AccountingStatusFinalizer::class,
            GeneralStatementStatisticReporter::class,
            TransferReporter::class,
            ReturnedTransferReporter::class,
        ];
    }

    public static function shouldBeAggregatedForExport(): bool
    {
        return false;
    }

    public static function getBankTag(): string
    {
        return 'D13';
    }
}
