<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use StatementHandlers\BanktransferStatementHandler;
use TransactionHandlers\Misc\AccountingStatusFinalizer;
use TransactionHandlers\Reporting\BanktransferReporter;
use TransactionHandlers\Splitting\BanktransferSettlementSplitter;
use TransactionHandlers\Statistics\GeneralStatementStatisticReporter;

/**
 * The 'Stichting Mollie Payments' escrow account at Deutsche Bank we receive Dutch SEPA Credit Transfers on as per our
 * 'Bank transfer' payment method.
 */
class DeutscheBankDutchBankTransferAccount extends AbstractSmpBankAccount
{
    public static function getIban(): string
    {
        return 'NL70DEUT0265262313';
    }

    public static function getBankBic(): string
    {
        return 'DEUTNL2A';
    }

    public static function getBankName(): string
    {
        return 'Deutsche Bank NL';
    }

    public static function getDescription(): string
    {
        return 'SMP - Ontvangsten overboeking NL (SCT/DB)';
    }

    public static function getStatementHandlerClass(): string
    {
        return BanktransferStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [
            BanktransferReporter::class,
            BanktransferSettlementSplitter::class,
            AccountingStatusFinalizer::class,
            GeneralStatementStatisticReporter::class,
        ];
    }

    public static function getBankTag(): string
    {
        return 'D12';
    }
}
