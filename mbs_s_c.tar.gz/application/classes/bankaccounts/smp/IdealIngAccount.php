<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use StatementHandlers\IdealStatementHandler;
use TransactionHandlers\Misc\AccountingStatusFinalizer;
use TransactionHandlers\Reporting\IdealReporter;
use TransactionHandlers\Statistics\GeneralStatementStatisticReporter;

/**
 * The 'Stichting Mollie Payments' escrow account at ING we receive iDEAL payments on.
 */
class IdealIngAccount extends AbstractSmpBankAccount
{
    public static function getIban(): string
    {
        return 'NL77INGB0006917450';
    }

    public static function getBankBic(): string
    {
        return 'INGBNL2A';
    }

    public static function getBankName(): string
    {
        return 'ING';
    }

    public static function getDescription(): string
    {
        return 'SMP - Ontvangsten iDEAL';
    }

    public static function getStatementHandlerClass(): string
    {
        return IdealStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [
            IdealReporter::class,
            AccountingStatusFinalizer::class,
            GeneralStatementStatisticReporter::class,
        ];
    }

    public static function getBankTag(): string
    {
        return 'S04';
    }
}
