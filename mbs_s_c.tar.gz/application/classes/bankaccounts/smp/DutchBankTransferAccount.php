<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use StatementHandlers\BanktransferStatementHandler;
use TransactionHandlers\Misc\AccountingStatusFinalizer;
use TransactionHandlers\Reporting\BanktransferReporter;
use TransactionHandlers\Splitting\BanktransferSettlementSplitter;
use TransactionHandlers\Statistics\GeneralStatementStatisticReporter;

/**
 * The 'Stichting Mollie Payments' escrow account at ABN Amro we receive SEPA Credit Transfers on as per our 'Bank
 * transfer' payment method.
 */
class DutchBankTransferAccount extends AbstractSmpBankAccount
{
    public static function getIban(): string
    {
        return 'NL53ABNA0627535577';
    }

    public static function getBankBic(): string
    {
        return 'ABNANL2A';
    }

    public static function getBankName(): string
    {
        return 'ABN Amro';
    }

    public static function getDescription(): string
    {
        return 'SMP - Ontvangsten overboeking (SEPA Credit Transfer)';
    }

    public static function getStatementHandlerClass(): string
    {
        return BanktransferStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [
            BanktransferReporter::class,
            BanktransferSettlementSplitter::class,
            AccountingStatusFinalizer::class,
            GeneralStatementStatisticReporter::class,
        ];
    }

    public static function getBankTag(): string
    {
        return 'ST6';
    }
}
