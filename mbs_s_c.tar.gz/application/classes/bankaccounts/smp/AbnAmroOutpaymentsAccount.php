<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use StatementHandlers\AbnAmroOutpaymentStatementHandler;
use TransactionHandlers\Expanding\OutpaymentBatchExpander;
use TransactionHandlers\Misc\AccountingStatusFinalizer;
use TransactionHandlers\Reporting\PrepaymentSettlementReporter;
use TransactionHandlers\Reporting\ReturnedOutpaymentReporter;
use TransactionHandlers\Reporting\ReturnedPrepaymentSettlementReporter;
use TransactionHandlers\Reporting\ReturnedTransferReporter;
use TransactionHandlers\Reporting\TransferReporter;
use TransactionHandlers\Statistics\GeneralStatementStatisticReporter;

/**
 * The 'Stichting Mollie Payments' escrow account at ABN Amro for outpayments to our merchants.
 */
class AbnAmroOutpaymentsAccount extends AbstractSmpBankAccount
{
    public static function getIban(): string
    {
        return 'NL29ABNA0546842291';
    }

    public static function getBankBic(): string
    {
        return 'ABNANL2A';
    }

    public static function getBankName(): string
    {
        return 'ABN Amro';
    }

    public static function getDescription(): string
    {
        return 'SMP - ABN Amro uitbetaalrekening';
    }

    public static function getStatementHandlerClass(): string
    {
        return AbnAmroOutpaymentStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [
            OutpaymentBatchExpander::class,
            ReturnedOutpaymentReporter::class,
            TransferReporter::class,
            ReturnedTransferReporter::class,
            PrepaymentSettlementReporter::class,
            ReturnedPrepaymentSettlementReporter::class,
            AccountingStatusFinalizer::class,
            GeneralStatementStatisticReporter::class,
        ];
    }

    public static function shouldBeAggregatedForExport(): bool
    {
        return false;
    }

    public static function getBankTag(): string
    {
        return 'ST1';
    }
}
