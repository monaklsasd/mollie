<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use StatementHandlers\MisterCashStatementHandler;
use TransactionHandlers\Expanding\SepaBatchExpander;
use TransactionHandlers\Misc\AccountingStatusFinalizer;
use TransactionHandlers\Reporting\BancontactReporter;
use TransactionHandlers\Statistics\GeneralStatementStatisticReporter;

/**
 * The 'Stichting Mollie Payments' escrow account at Belfius we receive Belfius Direct Net settlements on.
 */
class BancontactAccount extends AbstractSmpBankAccount
{
    public static function getIban(): string
    {
        return 'BE55068902363644';
    }

    public static function getBankBic(): string
    {
        return 'GKCCBEBB';
    }

    public static function getBankName(): string
    {
        return 'Belfius';
    }

    public static function getDescription(): string
    {
        return 'SMP - Ontvangsten Bancontact';
    }

    public static function getStatementHandlerClass(): string
    {
        return MisterCashStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [
            SepaBatchExpander::class,
            BancontactReporter::class,
            AccountingStatusFinalizer::class,
            GeneralStatementStatisticReporter::class,
        ];
    }

    public static function getBankTag(): string
    {
        return 'S03';
    }
}
