<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use StatementHandlers\KlarnaStatementHandler;
use TransactionHandlers\Expanding\KlarnaBatchExpander;
use TransactionHandlers\Misc\AccountingStatusFinalizer;
use TransactionHandlers\Reporting\KlarnaReporter;
use TransactionHandlers\Splitting\KlarnaFeeSplitter;
use TransactionHandlers\Statistics\GeneralStatementStatisticReporter;

class DeutscheBankKlarnaAccount extends AbstractSmpBankAccount
{
    public static function getIban(): string
    {
        return 'NL42DEUT0265262526';
    }

    public static function getBankBic(): string
    {
        return 'DEUTNL2A';
    }

    public static function getBankName(): string
    {
        return 'Deutsche Bank NL';
    }

    public static function getDescription(): string
    {
        return 'SMP - Deutsche Bank Klarna account';
    }

    public static function getStatementHandlerClass(): string
    {
        return KlarnaStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [
            KlarnaBatchExpander::class,
            KlarnaReporter::class,
            KlarnaFeeSplitter::class,
            AccountingStatusFinalizer::class,
            GeneralStatementStatisticReporter::class,
        ];
    }

    public static function getBankTag(): string
    {
        return 'D23';
    }
}
