<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use StatementHandlers\OutpaymentStatementHandler;
use TransactionHandlers\Expanding\OutpaymentBatchExpander;
use TransactionHandlers\Misc\AccountingStatusFinalizer;
use TransactionHandlers\Reporting\ReturnedOutpaymentReporter;
use TransactionHandlers\Reporting\ReturnedTransferReporter;
use TransactionHandlers\Reporting\TransferReporter;
use TransactionHandlers\Statistics\GeneralStatementStatisticReporter;

class DeutscheBankFrenchOutpaymentsAccount extends AbstractSmpBankAccount
{
    public static function getIban(): string
    {
        return 'FR7617789000011055058500039';
    }

    public static function getBankBic(): string
    {
        return 'DEUTFRPP';
    }

    public static function getBankName(): string
    {
        return 'Deutsche Bank FR';
    }

    public static function getDescription(): string
    {
        return 'SMP - Deutsche Bank FR uitbetaalrekening';
    }

    public static function getStatementHandlerClass(): string
    {
        return OutpaymentStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [
            OutpaymentBatchExpander::class,
            ReturnedOutpaymentReporter::class,
            AccountingStatusFinalizer::class,
            GeneralStatementStatisticReporter::class,
            TransferReporter::class,
            ReturnedTransferReporter::class,
        ];
    }

    public static function shouldBeAggregatedForExport(): bool
    {
        return false;
    }

    public static function getBankTag(): string
    {
        return 'D16';
    }
}
