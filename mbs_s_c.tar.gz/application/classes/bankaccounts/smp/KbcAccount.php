<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use StatementHandlers\KbcStatementHandler;
use TransactionHandlers\Misc\AccountingStatusFinalizer;
use TransactionHandlers\Reporting\KbcReporter;
use TransactionHandlers\Statistics\GeneralStatementStatisticReporter;

/**
 * The 'Stichting Mollie Payments' escrow account at ABN Amro we receive KBC settlements on.
 */
class KbcAccount extends AbstractSmpBankAccount
{
    public static function getIban(): string
    {
        return 'BE66736027167643';
    }

    public static function getBankBic(): string
    {
        return 'KREDBEBB';
    }

    public static function getBankName(): string
    {
        return 'KBC';
    }

    public static function getDescription(): string
    {
        return 'SMP - Ontvangsten KBC';
    }

    public static function getStatementHandlerClass(): string
    {
        return KbcStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [
            KbcReporter::class,
            AccountingStatusFinalizer::class,
            GeneralStatementStatisticReporter::class,
        ];
    }

    public static function getBankTag(): string
    {
        return 'S08';
    }
}
