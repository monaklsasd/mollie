<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use StatementHandlers\DirectDebitStatementHandler;
use TransactionHandlers\Misc\AccountingStatusFinalizer;

/**
 * The 'Stichting Mollie Payments' escrow account at Deutsche Bank we receive SEPA Direct Debit settlements on.
 */
class DeutscheBankDutchDirectDebitAccount extends AbstractSmpBankAccount
{
    public static function getIban(): string
    {
        return 'NL73DEUT0265262453';
    }

    public static function getBankBic(): string
    {
        return 'DEUTNL2A';
    }

    public static function getBankName(): string
    {
        return 'Deutsche Bank NL';
    }

    public static function getDescription(): string
    {
        return 'SMP - Ontvangsten SEPA Direct Debit (SDD/DB - NL)';
    }

    public static function getStatementHandlerClass(): string
    {
        return DirectDebitStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [AccountingStatusFinalizer::class];
    }

    public static function getBankTag(): string
    {
        return 'D18';
    }
}
