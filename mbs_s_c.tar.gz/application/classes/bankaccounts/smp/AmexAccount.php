<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use StatementHandlers\AmexStatementHandler;
use TransactionHandlers\Expanding\AmexBatchExpander;
use TransactionHandlers\Misc\AccountingStatusFinalizer;
use TransactionHandlers\Reporting\AmexReporter;
use TransactionHandlers\Splitting\MultiCurrencyTransactionSplitter;
use TransactionHandlers\Statistics\GeneralStatementStatisticReporter;

/**
 * The 'Stichting Mollie Payments' escrow account at ABN Amro we receive American Express credit card settlements on.
 */
class AmexAccount extends AbstractSmpBankAccount
{
    public static function getIban(): string
    {
        return 'NL27ABNA0409067989';
    }

    public static function getBankBic(): string
    {
        return 'ABNANL2A';
    }

    public static function getBankName(): string
    {
        return 'ABN Amro';
    }

    public static function getDescription(): string
    {
        return 'SMP - Ontvangsten Amex';
    }

    public static function getStatementHandlerClass(): string
    {
        return AmexStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [
            AmexBatchExpander::class,
            AmexReporter::class,
            MultiCurrencyTransactionSplitter::class,
            AccountingStatusFinalizer::class,
            GeneralStatementStatisticReporter::class,
        ];
    }

    public static function getBankTag(): string
    {
        return 'S09';
    }
}
