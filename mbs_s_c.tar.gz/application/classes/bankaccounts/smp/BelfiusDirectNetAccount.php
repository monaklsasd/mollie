<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use StatementHandlers\BelfiusStatementHandler;
use TransactionHandlers\Expanding\SepaBatchExpander;
use TransactionHandlers\Misc\AccountingStatusFinalizer;
use TransactionHandlers\Reporting\BelfiusReporter;
use TransactionHandlers\Statistics\GeneralStatementStatisticReporter;

/**
 * The 'Stichting Mollie Payments' escrow account at Belfius we receive Belfius Direct Net settlements on.
 */
class BelfiusDirectNetAccount extends AbstractSmpBankAccount
{
    public static function getIban(): string
    {
        return 'BE42068902093054';
    }

    public static function getBankBic(): string
    {
        return 'GKCCBEBB';
    }

    public static function getBankName(): string
    {
        return 'Belfius';
    }

    public static function getDescription(): string
    {
        return 'SMP - Ontvangsten Belfius Direct Net';
    }

    public static function getStatementHandlerClass(): string
    {
        return BelfiusStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [
            SepaBatchExpander::class,
            BelfiusReporter::class,
            AccountingStatusFinalizer::class,
            GeneralStatementStatisticReporter::class,
        ];
    }

    public static function getBankTag(): string
    {
        return 'S02';
    }
}
