<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use StatementHandlers\BanktransferStatementHandler;
use TransactionHandlers\Misc\AccountingStatusFinalizer;
use TransactionHandlers\Reporting\BanktransferReporter;
use TransactionHandlers\Splitting\BanktransferSettlementSplitter;
use TransactionHandlers\Statistics\GeneralStatementStatisticReporter;

/**
 * The 'Stichting Mollie Payments' escrow account at KBC France we receive SCT transfer for the French Bank account.
 *
 * Transfers are sent in via an MT940 link with ABN AMRO.
 */
class FrenchBankTransferAccount extends AbstractSmpBankAccount
{
    final public static function getIban(): string
    {
        return 'FR7627800400010261065030117';
    }

    final public static function getBankBic(): string
    {
        return 'KREDFRPP';
    }

    final public static function getBankName(): string
    {
        return 'KBC';
    }

    final public static function getDescription(): string
    {
        return 'SMP - Ontvangsten overboeking Frankrijk (SEPA Credit Transfer)';
    }

    final public static function getStatementHandlerClass(): string
    {
        return BanktransferStatementHandler::class;
    }

    final public static function getTransactionHandlerClasses(): array
    {
        return [
            BanktransferReporter::class,
            BanktransferSettlementSplitter::class,
            AccountingStatusFinalizer::class,
            GeneralStatementStatisticReporter::class,
        ];
    }

    final public static function getBankTag(): string
    {
        return 'SM4';
    }
}
