<?php

declare(strict_types=1);

namespace BankAccounts\Smp;

use StatementHandlers\IdealStatementHandler;
use TransactionHandlers\Misc\AccountingStatusFinalizer;
use TransactionHandlers\Reporting\IdealReporter;
use TransactionHandlers\Statistics\GeneralStatementStatisticReporter;

/**
 * The 'Stichting Mollie Payments' escrow account at ABN Amro we receive iDEAL payments on.
 */
class IdealAbnAccount extends AbstractSmpBankAccount
{
    public static function getIban(): string
    {
        return 'NL30ABNA0524590958';
    }

    public static function getBankBic(): string
    {
        return 'ABNANL2A';
    }

    public static function getBankName(): string
    {
        return 'ABN Amro';
    }

    public static function getDescription(): string
    {
        return 'SMP - ABN Amro Ontvangsten iDEAL';
    }

    public static function getStatementHandlerClass(): string
    {
        return IdealStatementHandler::class;
    }

    public static function getTransactionHandlerClasses(): array
    {
        return [
            IdealReporter::class,
            AccountingStatusFinalizer::class,
            GeneralStatementStatisticReporter::class,
        ];
    }

    public static function getBankTag(): string
    {
        return 'BK8';
    }
}
