<?php

declare(strict_types=1);

namespace BankAccounts\Exceptions;

use Mollie_Exception;

abstract class AbstractException extends Mollie_Exception
{
}
