<?php

namespace Determination;

use Model_Banktransaction;

interface BankTransactionDeterminer
{
    public function isRefundedOutpayment(Model_Banktransaction $bank_transaction, ?string $outpayment_reference): bool;
}
