<?php

namespace Determination;

use Model_Banktransaction;
use Orm\ModelFactory;
use sql_db;
use function Core\Money\money_to_string;

class LegacyBankTransactionDeterminer implements BankTransactionDeterminer
{
    /** @var sql_db */
    private $db;

    /** @var ModelFactory */
    private $model_factory;

    public function __construct(sql_db $db, ModelFactory $model_factory)
    {
        $this->db            = $db;
        $this->model_factory = $model_factory;
    }

    /**
     * Is this transaction an outpayment, that has been returned to our bank account.
     *
     * @return bool Returns TRUE if we are quite sure, that this transaction is a returned outpayment.
     */
    public function isRefundedOutpayment(Model_Banktransaction $bank_transaction, ?string $outpayment_reference): bool
    {
        if ($bank_transaction->isDebited()) {
            return false;
        }

        if ($bank_transaction->isReturnedTransaction()) {
            return true;
        }

        $inverse = $this->model_factory->findAll(
            Model_Banktransaction::class,
            [
                'bankaccount_id'     => $bank_transaction->getBankAccountId(),
                'statementimport_id' => ['<', $bank_transaction->getStatement()->getPrimaryKey()],
                'bankaccount_nr'     => $bank_transaction->getOffsetAccountNumber(),
                'amount'             => money_to_string($bank_transaction->getAmount()->negative()),
                'description'        => ['LIKE', '%' . $this->db->sql_escape_like_string($outpayment_reference) . '%'],
            ],
            'LIMIT 1'
        );

        // $inverse can be null in unittests, test for this until we get a nice repository that's easily mocked.
        if ($inverse !== null && count($inverse)) {
            return true;
        }

        if ($bank_transaction->getOffsetAccountBic() === 'RABONL2U') {
            /*
             * @issue 21789
             */
            if (strpos($bank_transaction->getDescription(), 'REF ' . $outpayment_reference) === 0) {
                return true;
            }
        }

        return false;
    }
}
