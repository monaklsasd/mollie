<?php

use League\Plates\Engine;
use League\Plates\Extension\ExtensionInterface;

/**
 * Provide access to an already configured Plates templating engine.
 */
class TemplateEngine
{
    /** @var Engine */
    private $plates;

    public function __construct()
    {
        $this->plates = new Engine(rtrim(MOLLIE_VIEW_PATH, "/"), null);
    }

    public function loadExtension(ExtensionInterface $extension): void
    {
        $this->plates->loadExtension($extension);
    }

    public function renderTemplate(string $template_path, array $data): string
    {
        $template_path = trim($template_path, "/");

        return $this->plates->render("/{$template_path}", $data);
    }

    public function renderTemplateWithLayout(
        string $template_path,
        array $data,
        string $layout_path,
        array $layout_data
    ): string {
        $template_path = trim($template_path, "/");
        $layout_path   = trim($layout_path, "/");

        $template = $this->plates->make("/{$template_path}");
        $template->layout("/{$layout_path}", $layout_data);

        return $template->render($data);
    }
}
