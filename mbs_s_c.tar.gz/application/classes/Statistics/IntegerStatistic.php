<?php

declare(strict_types=1);

namespace Statistics;

abstract class IntegerStatistic extends Statistic
{
    public function getValue(): int
    {
        return (int)$this->value;
    }

    protected static function combineValues($value1, $value2)
    {
        return $value1 + $value2;
    }
}
