<?php

declare(strict_types=1);

namespace Statistics;

use DateTimeImmutable;
use Helper\DateTime\Utc;
use function count;
use function get_class;

class StatisticCollection
{
    use Utc;
    protected const DATE_FORMAT = 'Y-m-d';

    /** @var Statistic[] */
    protected $statistics;

    /**
     * indexed: payment_method -> date -> class_name
     *
     * @var Statistic[][][]
     */
    protected $indexed = [];

    /** @var DateTimeImmutable[] */
    protected $dates_cache;

    /** @var string[] */
    protected $types_cache;

    public function __construct(Statistic ...$statistics)
    {
        $this->statistics = array_values($statistics);
        $this->indexed    = static::buildIndexedAndCombinedTree(...$this->statistics);
    }

    protected static function buildIndexedAndCombinedTree(Statistic ...$statistics): array
    {
        $indexed = [];

        foreach ($statistics as $statistic) {
            if (!isset($indexed[$statistic->getPaymentMethod()])) {
                $indexed[$statistic->getPaymentMethod()] = [];
            }
            $level1 = &$indexed[$statistic->getPaymentMethod()];

            if (!isset($level1[$statistic->getDate()->format(static::DATE_FORMAT)])) {
                $level1[$statistic->getDate()->format(static::DATE_FORMAT)] = [];
            }
            $level2 = &$level1[$statistic->getDate()->format(static::DATE_FORMAT)];

            if (!isset($level2[get_class($statistic)])) {
                $level2[get_class($statistic)] = $statistic;
            } else {
                $level2[get_class($statistic)] = $level2[get_class($statistic)]->combine($statistic);
            }
        }

        ksort($indexed);

        // move outpayments to bottom.
        if ($outpayments = $indexed['outpayment'] ?? null) {
            unset($indexed['outpayment']);
            $indexed['outpayment'] = $outpayments;
        }

        // move empty payment_method (only used for fees) to the bottom.
        if (key($indexed) === '') {
            $indexed[''] = array_shift($indexed);
        }

        return $indexed;
    }

    /**
     * @return Statistic[]
     */
    public function getAll(): array
    {
        return $this->statistics;
    }

    public function getStatistic(string $payment_method, DateTimeImmutable $date, string $class_name): ?Statistic
    {
        return $this->indexed[$payment_method][$date->format(static::DATE_FORMAT)][$class_name] ?? null;
    }

    public function getSettlementCountForStatistic(Statistic $statistic): ?int
    {
        $total_count = $this->indexed[$statistic->getPaymentMethod()][$statistic->getDate()->format(static::DATE_FORMAT)][TotalSettlementCount::class] ?? null;

        if ($total_count === null) {
            return null;
        }

        return $total_count->getValue();
    }

    /**
     * @return string[]
     */
    public function getPaymentMethods(): array
    {
        return array_keys($this->indexed);
    }

    /**
     * @return DateTimeImmutable[]
     */
    public function getDatesSortedNewToOld(): array
    {
        if ($this->dates_cache === null) {
            $this->dates_cache = $this->extractUniqueDatesFromStatistics();
            rsort($this->dates_cache);
        }

        return $this->dates_cache;
    }

    private function extractUniqueDatesFromStatistics(): array
    {
        $dates = [];
        /** @var Statistic $statistic */
        foreach ($this->statistics as $statistic) {
            $dates[$statistic->getDate()->format(self::DATE_FORMAT)] = $statistic->getDate();
        }

        return array_values($dates);
    }

    /**
     * @return string[]
     */
    public function getStatisticTypes(): array
    {
        if ($this->types_cache === null) {
            if (count($this->statistics) === 0) {
                $this->types_cache = [];
            } else {
                $this->types_cache = array_keys(array_merge_recursive(
                    ...array_values(array_merge_recursive(
                        ...array_values($this->indexed)
                    ))
                ));
            }
        }

        return $this->types_cache;
    }
}
