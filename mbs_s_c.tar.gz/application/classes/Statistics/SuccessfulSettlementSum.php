<?php

declare(strict_types=1);

namespace Statistics;

class SuccessfulSettlementSum extends MoneyStatistic
{
}
