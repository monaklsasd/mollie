<?php

declare(strict_types=1);

namespace Statistics;

use Model\Transaction\TransactionTags;
use Psr\Log\LogLevel;

class UnknownSettlementCount extends IntegerStatistic
{
    public function getLevel(int $total_settlement_count): string
    {
        $ratio = $this->getValue() / $total_settlement_count;

        if ($this->payment_method === TransactionTags::TAG_BANKTRANSFER) {
            if ($ratio > 0.1) {
                return LogLevel::ALERT;
            }

            if ($ratio > 0.05) {
                return LogLevel::WARNING;
            }
        } else {
            if ($ratio > 0.01) {
                return LogLevel::ALERT;
            }

            if ($ratio > 0.005) {
                return LogLevel::WARNING;
            }
        }

        return LogLevel::INFO;
    }
}
