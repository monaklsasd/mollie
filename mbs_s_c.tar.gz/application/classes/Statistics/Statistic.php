<?php

declare(strict_types=1);

namespace Statistics;

use DateTimeImmutable;
use Helper\DateTime\Utc;
use LogicException;
use Model_Bankstatement;
use Psr\Log\LogLevel;
use function get_class;
use function gettype;
use function is_object;
use function is_scalar;

abstract class Statistic
{
    use Utc;

    /** @var int */
    protected $statement_id;

    /** @var DateTimeImmutable */
    protected $date;

    /** @var string */
    protected $payment_method;

    /** @var string */
    protected $value;

    public function __construct(
        int $statement_id,
        DateTimeImmutable $date,
        ?string $payment_method,
        $value
    ) {
        if ($payment_method !== null && '' === $payment_method = trim($payment_method)) {
            $payment_method = null;
        }

        $this->statement_id   = $statement_id;
        $this->date           = $date;
        $this->payment_method = $payment_method;
        $this->setValue($value);
    }

    public static function createFromStatement(
        Model_Bankstatement $statement,
        ?string $payment_method,
        $value
    ) {
        return new static(
            (int)$statement->getPrimaryKey(),
            $statement->getStatementDate(),
            $payment_method,
            $value
        );
    }

    public function getStatementId(): int
    {
        return $this->statement_id;
    }

    public function getDate(): DateTimeImmutable
    {
        return $this->date;
    }

    public function getPaymentMethod(): ?string
    {
        return $this->payment_method;
    }

    public function getValueAsString(): string
    {
        return $this->value;
    }

    /**
     * Returns a LogLevel constant to indicate if if the value is reason for concern.
     * Requires the total settlement count of the day to be determined.
     */
    public function getLevel(int $total_settlement_count): string
    {
        return LogLevel::INFO;
    }

    public function combine(Statistic $statistic): Statistic
    {
        if (static::class !== get_class($statistic)) {
            throw new LogicException(sprintf(
                'Statics of different kindscannot be combined. Had %s, got %s.',
                static::class,
                get_class($statistic)
            ));
        }

        if ($this->getDate()->format('Y-m-d') !== $statistic->getDate()->format('Y-m-d')) {
            throw new LogicException(sprintf(
                'Statics of different dates can not be combined. Had %s, got %s.',
                $this->getDate()->format('Y-m-d'),
                $statistic->getDate()->format('Y-m-d')
            ));
        }

        return new static(
            $this->getStatementId() === $statistic->getStatementId() ? $this->getStatementId() : 0,
            $this->getDate(),
            $this->getPaymentMethod() === $statistic->getPaymentMethod() ? $this->getPaymentMethod() : null,
            static::combineValues($this->getValue(), $statistic->getValue())
        );
    }

    protected function setValue($value): void
    {
        if (!is_scalar($value)) {
            throw new LogicException(sprintf(
                'Please override %s::setValue, the passed is not scalar, but %s and has to be converted to a string.',
                static::class,
                is_object($value) ? get_class($value) : gettype($value)
            ));
        }

        $this->value = (string)$value;
    }

    abstract public function getValue();

    abstract protected static function combineValues($value1, $value2);
}
