<?php

declare(strict_types=1);

namespace Statistics;

use Model\Transaction\TransactionTags;
use Psr\Log\LogLevel;
use function in_array;

class FailedSettlementCount extends IntegerStatistic
{
    public function getLevel(int $total_settlement_count): string
    {
        $ratio = $this->getValue() / $total_settlement_count;

        if (in_array($this->payment_method, [TransactionTags::TAG_DIRECTDEBIT, TransactionTags::TAG_BELFIUS], true)) {
            if ($ratio > 0.02) {
                return LogLevel::ALERT;
            }

            if ($ratio > 0.01) {
                return LogLevel::WARNING;
            }
        } else {
            if ($ratio > 0.01) {
                return LogLevel::ALERT;
            }

            if ($ratio > 0.005) {
                return LogLevel::WARNING;
            }
        }

        return LogLevel::INFO;
    }
}
