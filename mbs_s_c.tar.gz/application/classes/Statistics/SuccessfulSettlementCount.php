<?php

declare(strict_types=1);

namespace Statistics;

class SuccessfulSettlementCount extends IntegerStatistic
{
}
