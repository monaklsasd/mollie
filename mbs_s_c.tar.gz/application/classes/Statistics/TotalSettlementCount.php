<?php

declare(strict_types=1);

namespace Statistics;

class TotalSettlementCount extends IntegerStatistic
{
}
