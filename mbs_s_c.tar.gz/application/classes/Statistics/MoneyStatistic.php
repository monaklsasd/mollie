<?php

declare(strict_types=1);

namespace Statistics;

use Core\Json;
use InvalidArgumentException;
use Money\Currency;
use Money\Money;
use Webmozart\Assert\Assert;
use function Core\Money\money_from_string;
use function Core\Money\money_to_array;
use function get_class;
use function gettype;
use function is_object;
use function is_string;

abstract class MoneyStatistic extends Statistic
{
    protected function setValue($value): void
    {
        if ($value instanceof Money) {
            parent::setValue(Json::encode(money_to_array($value)));

            return;
        }

        if (is_string($value) && Json::decodeAssociative($value)) {
            parent::setValue($value);

            return;
        }

        throw new InvalidArgumentException(sprintf(
            'Invalid value type given for statistic: %s, expected Money or (json) string.',
            is_object($value) ? get_class($value) : gettype($value)
        ));
    }

    public function getValue(): Money
    {
        $data = Json::decodeAssociative($this->value);

        return money_from_string($data['value'], new Currency($data['currency']));
    }

    /**
     * @param mixed|Money $value1
     * @param mixed|Money $value2
     *
     * @return Money
     */
    protected static function combineValues($value1, $value2)
    {
        Assert::isInstanceOf($value1, Money::class);
        Assert::isInstanceOf($value2, Money::class);

        return $value1->add($value2);
    }
}
