<?php

declare(strict_types=1);

namespace Statistics;

use BankAccounts\BankAccountRepository;
use DateTimeImmutable;
use Helper\DateTime\Now;
use Helper\DateTime\Utc;
use Orm\Repositories\BankstatementRepository;
use ReflectionClass;
use sql_db;

class StatisticRepository
{
    use Now;
    use Utc;

    /** @var sql_db */
    protected $db;

    /** @var BankAccountRepository */
    protected $bank_account_repository;

    /** @var BankstatementRepository */
    protected $bank_statement_repository;

    /** @var string */
    protected static $stat_ns;

    public function __construct(
        sql_db $db,
        BankAccountRepository $bank_account_repository,
        BankstatementRepository $bank_statement_repository
    ) {
        $this->db                        = $db;
        $this->bank_account_repository   = $bank_account_repository;
        $this->bank_statement_repository = $bank_statement_repository;
    }

    public function save(Statistic ...$statistics): void
    {
        foreach ($statistics as $statistic) {
            $this->db->sql_safe_query(
                '
                INSERT INTO `import_statistics` 
                    (`statementimport_id`, `date`, `payment_method`, `name`, `value`)
                VALUES
                    (^1, $2, $3, $4, $5)
                ON DUPLICATE KEY UPDATE `value` = $5
                ',
                $statistic->getStatementId(),
                $statistic->getDate()->format('Y-m-d'),
                $statistic->getPaymentMethod(),
                (new ReflectionClass($statistic))->getShortName(),
                $statistic->getValueAsString()
            );
        }
    }

    public function getAllBetweenDates(DateTimeImmutable $start, DateTimeImmutable $end): StatisticCollection
    {
        $result = $this->db->sql_fetchquery('
            SELECT 
                `statementimport_id`,
                `date`,
                `payment_method`,
                `value`,
                `name`
            FROM
              `import_statistics`
            WHERE
              `date` BETWEEN $1 AND $2
        ', [
            $start->format('Y-m-d'),
            $end->format('Y-m-d'),
        ]);

        return new StatisticCollection(...array_map('self::statisticFromArray', $result));
    }

    public function getForDate(?DateTimeImmutable $date = null): StatisticCollection
    {
        $date = $date ?? self::getNow();

        $result = $this->db->sql_fetchquery('
            SELECT 
                `statementimport_id`,
                `date`,
                `payment_method`,
                `value`,
                `name`
            FROM
              `import_statistics`
            WHERE
              `date` = $1
        ', [$date->format('Y-m-d')]);

        return new StatisticCollection(...array_map('self::statisticFromArray', $result));
    }

    private static function statisticFromArray(array $statistic): Statistic
    {
        $class_name = sprintf(
            '%s\%s',
            self::getStatisticsNamespace(),
            $statistic['name']
        );

        return new $class_name(
            (int)$statistic['statementimport_id'],
            self::toDateTime($statistic['date'] ?? null, '!Y-m-d'),
            $statistic['payment_method'],
            $statistic['value']
        );
    }

    private static function getStatisticsNamespace(): string
    {
        return self::$stat_ns = self::$stat_ns ?? (new ReflectionClass(Statistic::class))->getNamespaceName();
    }
}
