<?php

declare(strict_types=1);

namespace Log;

use App\Logger\LogCategory;
use Core\Json;
use DateTime;
use DateTimeInterface;
use Helper\DateTime\Now;
use Helper\DateTime\Utc;
use Model_Exception_Save;
use Model_Log;
use Mollie_Logger;
use Orm\ModelFactory;
use Psr\Log\AbstractLogger;
use Psr\Log\InvalidArgumentException;
use Psr\Log\LoggerInterface;
use Psr\Log\LogLevel;
use ReflectionClass;
use RuntimeException;
use Throwable;
use Worker_Base;
use function array_reverse;
use function count;
use function get_class;
use function gettype;
use function in_array;
use function is_int;
use function is_object;
use function is_subclass_of;
use function mb_strlen;
use function mb_substr;
use function method_exists;

/**
 * This is a PSR-3 compliant replacement for Mollie_Logger
 *
 * A log message with all available (original) options set looks like this:
 *
 * $this->warning('message', [
 *     'exception' => $e,
 *     'category' => LogCategory::SYSTEM(),
 *     'user_id' => 1,
 *     'ip' => '127.0.0.1'
 *     'request_id' => 'worker-decafbad'
 * ]);
 *
 * Any other keys in the 'context' will be json-encoded and logged to the message field.
 *
 * If any of the keys are not filled, the logger will try to fill them from globals.
 *
 * The main log message is logged to a 255 char field. If the supplied message is too long, it will be truncated, and
 * the full message will be added to the context field as 'full_message'.
 */
class DatabaseLogger extends AbstractLogger
{
    use Now;
    use Utc;

    private const LOG_LEVEL_MAP = [
        LogLevel::EMERGENCY => E_ERROR,
        LogLevel::ALERT     => E_ERROR,
        LogLevel::CRITICAL  => E_ERROR,
        LogLevel::ERROR     => E_ERROR,
        LogLevel::WARNING   => E_WARNING,
        LogLevel::NOTICE    => E_NOTICE,
        LogLevel::INFO      => null,
        LogLevel::DEBUG     => null,
    ];
    /** Used for backward compatibility with mollie_logger */
    private const LOG_TYPES = [
        LogLevel::EMERGENCY => Mollie_Logger::ERROR,
        LogLevel::ALERT     => Mollie_Logger::ERROR,
        LogLevel::CRITICAL  => Mollie_Logger::ERROR,
        LogLevel::ERROR     => Mollie_Logger::ERROR,
        LogLevel::WARNING   => Mollie_Logger::WARNING,
        LogLevel::NOTICE    => Mollie_Logger::INFO,
        LogLevel::INFO      => Mollie_Logger::INFO,
        LogLevel::DEBUG     => Mollie_Logger::DEBUG,
    ];

    /** @var ModelFactory */
    protected $model_factory;

    /** @var int */
    protected $min_log_level_index;

    public function __construct(ModelFactory $model_factory)
    {
        $this->model_factory = $model_factory;
        $this->setMinimumLogLevel(LogLevel::INFO);
    }

    public function setMinimumLogLevel(string $min_log_level): void
    {
        if (!array_key_exists($min_log_level, self::LOG_LEVEL_MAP)) {
            throw new InvalidArgumentException(sprintf(
                'Invalid minimum log level "%s", should be one of: %s.',
                $min_log_level,
                implode(',', array_keys(self::LOG_LEVEL_MAP))
            ));
        }

        $this->min_log_level_index = array_search($min_log_level, array_keys(self::LOG_LEVEL_MAP), true);
    }

    public function log($level, $message, array $context = []): void
    {
        // Don't log this, doesn't meet minimum level requirement
        if (array_search($level, array_keys(self::LOG_LEVEL_MAP), true) > $this->min_log_level_index) {
            return;
        }

        // Level
        if (!array_key_exists($level, self::LOG_LEVEL_MAP)) {
            throw new InvalidArgumentException(sprintf(
                'Invalid log level "%s", should be one of: %s.',
                is_object($level) ? get_class($level) : $level,
                implode(',', array_keys(self::LOG_LEVEL_MAP))
            ));
        }

        // Exception
        if (array_key_exists('exception', $context) && !($context['exception'] instanceof Throwable)) {
            throw new InvalidArgumentException(sprintf(
                '$context[\'exception\'] is not Throwable but %s.',
                is_object($context['exception']) ? get_class($context['exception']) : gettype($context['exception'])
            ));
        }

        if (array_key_exists('exception', $context)
            && $context['exception'] !== null
            && self::LOG_LEVEL_MAP[$level] !== null
        ) {
            $this->logException($context['exception'], self::LOG_LEVEL_MAP[$level]);
        }

        // Category
        if (array_key_exists('category', $context)) {
            if (!($context['category'] instanceof LogCategory)) {
                throw new InvalidArgumentException(sprintf(
                    '$context[\'category\'] is not instanceof of LogLevel but %s.',
                    is_object($context['category']) ? get_class($context['category']) : gettype($context['category'])
                ));
            }
            $category = $context['category'];
        }

        if (!isset($category)) {
            $category = self::getCategory();
        }

        // UserID
        if (array_key_exists('user_id', $context)) {
            if (!is_int($context['user_id'])) {
                throw new InvalidArgumentException(sprintf(
                    '$context[\'user_id\'] is not and int but %s.',
                    is_object($context['user_id']) ? get_class($context['user_id']) : gettype($context['user_id'])
                ));
            }
            $user_id = $context['user_id'];
        }

        if (!isset($user_id)) {
            $user_id = $this->getUserId();
        }

        // IPAddress
        if (array_key_exists('ip', $context)) {
            if (!filter_var($context['ip'], FILTER_VALIDATE_IP)) {
                throw new InvalidArgumentException(sprintf(
                    '$context[\'ip\'] is not a valid IP address %s.',
                    is_object($context['ip']) ? get_class($context['ip']) : gettype($context['ip'])
                ));
            }
            $ip = $context['ip'];
        }

        if (!isset($ip)) {
            $ip = $this->getIpAddress();
        }

        // RequestID
        $request_id = $context['request_id'] ?? '';

        if (trim($request_id) === '') {
            $request_id = null;
        }

        $call_site = static::getCallSite();
        $model     = $this->createModel($level, $message, $category, $user_id, $ip, $request_id, $call_site, $context);
        $this->logModel($model);

        /*
         * If running from the cli, try to log to stderr (handy for workers)
         * No need to include context here because the details are also logged to db and probably apm
         */
        if (PHP_SAPI === 'cli') {
            $this->logLine(
                static::createLine($level, $message, $category, $user_id, $ip, $request_id, $call_site, $context)
            );
        }
    }

    protected function logException(Throwable $throwable, int $level): void
    {
        if (!apm_log_exception($throwable, $level)) {
            throw new RuntimeException('Failed to write APM log entry.');
        }
    }

    protected function logModel(Model_Log $model): void
    {
        // This is a separate method so we can easily
        try {
            $model->saveOrDie();
        } catch (Model_Exception_Save $e) {
            throw new RuntimeException('Failed to write Model_Log log entry.', $e->getCode(), $e);
        }
    }

    protected function logLine(string $line): void
    {
        if (fwrite(STDERR, str_replace("\x00", '', $line)) . PHP_EOL === false) {
            throw new RuntimeException('Failed to write log line to STDERR');
        }
    }

    protected function createModel(
        string $level,
        string $message,
        LogCategory $category,
        ?int $user_id,
        ?string $ip,
        ?string $request_id,
        string $call_site,
        array $context = []
    ): Model_Log {
        $title = mb_substr($message, 0, 255);

        if (mb_strlen($message) > 255) {
            $context['full_message'] = $message;
        }

        $log             = $this->model_factory->create(Model_Log::class);
        $log->type       = self::LOG_TYPES[$level];
        $log->title      = $title;
        $log->category   = $category->getValue();
        $log->user_id    = $user_id;
        $log->ip_address = $ip;
        $log->request_id = $request_id;

        $clean_context = static::cleanContextForLogModel($context);
        $log->message  = sprintf(
            "%s\n\n%s",
            $call_site,
            count($clean_context) > 0 ? Json::encode($clean_context) : ''
        );

        /*
         * Anonymous class names contain nul bytes in the name, we don't want those in the db.
         * That's what the str_replace is for.
         *
         * Trim is used to remove the line breaks in case no context was added.
         */
        $log->message = trim(str_replace("\x00", '', $log->message));

        // If we couldn't determine the call-site and no context was added, just null this field.
        if ($log->message === '') {
            $log->message = null;
        }

        return $log;
    }

    protected static function createLine(
        string $level,
        string $message,
        LogCategory $category,
        ?int $user_id,
        ?string $ip,
        ?string $request_id,
        string $call_site,
        array $context = []
    ): string {
        return sprintf(
            '[%s] %s %s %s - %s',
            self::getNow()->format(DateTime::RFC3339_EXTENDED),
            static::getWorkerName(),
            $category->getValue(),
            $level,
            $message
        );
    }

    protected static function cleanContextForLogModel(array $context = []): array
    {
        unset(
            $context['category'],
            $context['user_id'],
            $context['ip'],
            $context['request_id'],
            $context['request_id']
        );

        if (array_key_exists('exception', $context)) {
            $context['exception'] = (string)$context['exception'];
        }

        array_walk_recursive($context, function (&$value) {
            if (!is_object($value)) {
                return;
            }

            if (method_exists($value, '__toString')) {
                $value = (string)$value;

                return;
            }

            if ($value instanceof DateTimeInterface) {
                $value = $value->format(DateTime::ATOM);

                return;
            }

            // Could not be converted to string, clear value.
            $value = '-';
        });

        return $context;
    }

    protected static function getCategory(): LogCategory
    {
        return PHP_SAPI === 'cli' ? LogCategory::SYSTEM() : LogCategory::WEBSITE();
    }

    protected function getUserId(): ?int
    {
        if (PHP_SAPI !== 'cli' && isset($_SESSION['user_id']) && is_numeric($_SESSION['user_id'])) {
            return (int)$_SESSION['user_id'];
        }

        return null;
    }

    protected function getIpAddress(): ?string
    {
        if (PHP_SAPI === 'cli') {
            return $_SERVER['SERVER_ADDR'] ?? null;
        }

        $ips = array_merge(
            [$_SERVER['REMOTE_ADDR'] ?? ''],
            explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'] ?? '')
        );

        // Strip out empty entries.
        $ips = array_filter(array_map('trim', $ips));

        // Walk through IPs in reverse, and find the first (non-local) valid ip.
        foreach (array_reverse($ips) as $ip) {
            if (filter_var(
                $ip,
                FILTER_VALIDATE_IP,
                in_array(MOLLIE_ENV, ['development', 'test'], true) ? 0 : FILTER_FLAG_NO_RES_RANGE
            )) {
                return $ip;
            }
        }

        // No valid IP found.
        return null;
    }

    protected static function getCallSite(): string
    {
        $last_trace = null;

        foreach (debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS) as $trace) {
            /*
             * We want the trace that has the invocation of this logger class.
             * This means getting the path of the last trace that has a LoggerInterface as the class.
             */
            if (!is_a($trace['class'], LoggerInterface::class, true)) {
                return sprintf(
                    '%s:%d',
                    str_replace(realpath(MOLLIE_APPDIR) . '/', '', $last_trace['file']),
                    $last_trace['line']
                );
            }
            $last_trace = $trace;
        }

        return '';
    }

    protected static function getWorkerName(): ?string
    {
        // Get the name of the worker
        $stack_trace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS);

        foreach ($stack_trace as $trace) {
            if (is_subclass_of($trace['class'] ?? '', Worker_Base::class, true)) {
                return (new ReflectionClass($trace['class']))->getShortName();
            }
        }

        /*
         * If no worker was found, get the basename of the calling class / file.
         * See self::getCallSite for description of 'last_trace' logic.
         * The call-site class we want is in the 'current' trace, the call-site  file is in the last_trace.
         */
        $last_trace = null;

        foreach ($stack_trace as $trace) {
            if (!is_a($trace['class'], LoggerInterface::class, true)) {
                $name = $trace['class'] ?? $last_trace['file'];

                return substr($name, strrpos($name, '\\') + 1);
            }
            $last_trace = $trace;
        }

        return '';
    }
}
