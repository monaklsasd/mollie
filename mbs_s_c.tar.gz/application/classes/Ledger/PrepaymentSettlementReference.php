<?php

namespace Ledger\PrepaymentSettlements;

use DateTimeImmutable;
use InvalidArgumentException;
use Ledger\Journal;
use Webmozart\Assert\Assert;

class PrepaymentSettlementReference
{
    /** @var int */
    private $prepayment_settlement_id;

    /** @var Journal */
    private $source_journal;

    /** @var DateTimeImmutable */
    private $date;

    public function __construct(
        int $prepayment_settlement_id,
        Journal $source_journal,
        DateTimeImmutable $date
    ) {
        $this->prepayment_settlement_id = $prepayment_settlement_id;
        $this->source_journal           = $source_journal;
        $this->date                     = $date;
    }

    public function getPrepaymentSettlementId(): int
    {
        return $this->prepayment_settlement_id;
    }

    public function getSourceJournal(): Journal
    {
        return $this->source_journal;
    }

    public function getDate(): DateTimeImmutable
    {
        return $this->date;
    }

    public function getReference(): string
    {
        return sprintf(
            '%08d.%02d.%06d',
            $this->getPrepaymentSettlementId(),
            $this->getSourceJournal()->getValue(),
            $this->getDate()->format('ymd')
        );
    }

    public function __toString(): string
    {
        return $this->getReference();
    }

    public static function fromString(string $reference): self
    {
        /*
         * Remove the prefix to the reference string for reconstructing object.
         */
        $reference = str_replace("Prepayment Settlement ", "", $reference);

        [$prepayment_settlement_id, $source_journal, $date_string] = self::parseReferenceString($reference);

        $date = DateTimeImmutable::createFromFormat('ymd', $date_string);

        return new self(
            (int)$prepayment_settlement_id,
            new Journal((int)$source_journal),
            $date
        );
    }

    private static function parseReferenceString(string $reference): array
    {
        $reference_parts = explode('.', $reference);

        if (count($reference_parts) !== 3) {
            throw new InvalidArgumentException(
                sprintf(
                    'Prepayment settlement reference string should be in the following format: "Prepayment Settlement xxxxxxxx.yy.zzzzzz", got %s',
                    $reference
                )
            );
        }

        Assert::length($reference_parts[0], 8, 'First part should be 8 digit prepayment settlement id');
        Assert::length($reference_parts[1], 2, 'Second part should be 2 digit journal integer');
        Assert::length(
            $reference_parts[2],
            6,
            'Third part should be a 6 digit "ymd" (year, month, day) formatted string'
        );

        return $reference_parts;
    }
}
