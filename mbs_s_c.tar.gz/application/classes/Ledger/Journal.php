<?php

namespace Ledger;

use BankAccounts\Mollie\CheckingAccount;
use BankAccounts\Smp\AbnAmroOutpaymentsAccount;
use LogicException;
use MyCLabs\Enum\Enum;

/**
 * These values should exactly match those of the `\Ledger\Ledgers\Journal` class in Mollie Platform.
 *
 * @method static Journal STICHTING_MOLLIE_PAYMENTS()
 * @method static Journal MOLLIE_BV()
 */
class Journal extends Enum
{
    public const STICHTING_MOLLIE_PAYMENTS = 0;
    public const MOLLIE_BV                 = 1;

    public function getOpposingJournal(): Journal
    {
        if ($this->getValue() === self::STICHTING_MOLLIE_PAYMENTS) {
            return Journal::MOLLIE_BV();
        }

        if ($this->getValue() === self::MOLLIE_BV) {
            return Journal::STICHTING_MOLLIE_PAYMENTS();
        }

        throw new LogicException("No opposing journal for current value");
    }

    public static function fromBankAccountId(int $bank_account_id): Journal
    {
        switch ($bank_account_id) {
            case AbnAmroOutpaymentsAccount::getId():
                return Journal::STICHTING_MOLLIE_PAYMENTS();

            case CheckingAccount::getId():
                return Journal::MOLLIE_BV();

            default:
                throw new LogicException("No journal configured for bank account id provided");
        }
    }
}
