<?php

namespace Fees\Collectors;

use Model_Banktransaction;

interface FeeCollectorInterface
{
    /**
     * May only return source transactions with amounts less than €0.00.
     *
     * @return iterable|Model_Banktransaction[]
     */
    public function getSourceTransactions(string $entry_date): iterable;
}
