<?php

namespace Fees\Collectors;

use Model\Transaction\TransactionTags;

class AmexFeeCollector extends AbstractFeeCollector
{
    final public function getTags(): array
    {
        return [TransactionTags::TAG_AMEX_FEE_VARIABLE];
    }
}
