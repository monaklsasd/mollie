<?php

namespace Fees\Collectors;

use Model\Transaction\TransactionTags;
use Model_Banktransaction;
use function in_array;

class ValitorFeeCollector extends AbstractFeeCollector
{
    public function getTags(): array
    {
        return [TransactionTags::TAG_VALITOR_DETAIL];
    }

    public function getSourceTransactions(string $entry_date): iterable
    {
        /** @var Model_Banktransaction $transaction */
        foreach (parent::getSourceTransactions($entry_date) as $transaction) {
            if (in_array($transaction->getTagData()['settlement_key'], ['BUMERC', 'CHBFAG', 'SWIFTF'], true)) {
                yield $transaction;
            }
        }
    }
}
