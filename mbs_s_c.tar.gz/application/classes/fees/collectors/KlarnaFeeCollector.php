<?php

namespace Fees\Collectors;

use Model\Transaction\TransactionTags;

class KlarnaFeeCollector extends AbstractFeeCollector
{
    protected function getTags(): array
    {
        $possible_tag_combinations = [];

        foreach (TransactionTags::KLARNA_SUBTYPE_TAGS as $subtype_tag) {
            $separator = TransactionTags::TAG_SEPARATOR;
            $tags      = [$subtype_tag, TransactionTags::TAG_KLARNA_FEE];

            $possible_tag_combinations[] = implode($separator, $tags);
            $possible_tag_combinations[] = implode($separator, array_reverse($tags));
        }

        return $possible_tag_combinations;
    }
}
