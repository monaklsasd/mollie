<?php

namespace Fees\Collectors;

use Model\Transaction\TransactionTags;

/**
 * Collects all transactions with the tag "bank" (which is pretty common).
 */
class BankingFeeCollector extends AbstractFeeCollector
{
    final public function getTags(): array
    {
        return [TransactionTags::TAG_BANK];
    }
}
