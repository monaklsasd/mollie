<?php

namespace Fees\Collectors;

use Model\Transaction\TransactionTags;

class PProFeeCollector extends AbstractFeeCollector
{
    final public function getTags(): array
    {
        return [
            TransactionTags::PPRO_VARIABLE_FEE_TAGS,
            TransactionTags::TAG_BANK_PPRO,
        ];
    }
}
