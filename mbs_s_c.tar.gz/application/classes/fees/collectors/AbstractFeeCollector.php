<?php

namespace Fees\Collectors;

use BankAccounts\BankAccount;
use DateTimeImmutable;
use Orm\Repositories\BanktransactionRepository;

abstract class AbstractFeeCollector implements FeeCollectorInterface
{
    /** @var BankAccount */
    private $bank_account;

    /** @var BanktransactionRepository */
    private $banktransaction_repository;

    public function __construct(BankAccount $bank_account, BanktransactionRepository $banktransaction_repository)
    {
        $this->bank_account               = $bank_account;
        $this->banktransaction_repository = $banktransaction_repository;
    }

    public function getSourceTransactions(string $entry_date): iterable
    {
        return $this->banktransaction_repository->findDebitByEntryDate(
            DateTimeImmutable::createFromFormat('!Y-m-d', $entry_date),
            $this->getTags(),
            $this->bank_account
        );
    }

    abstract protected function getTags(): array;
}
