<?php

class File_Transformer_VerifyException extends File_Transformer_Exception
{
}
