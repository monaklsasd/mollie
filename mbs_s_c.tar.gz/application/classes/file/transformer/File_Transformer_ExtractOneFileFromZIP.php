<?php

/**
 * Extract the one (and only one) file from a given ZIP. Error if the ZIP file has more than one file.
 */
class File_Transformer_ExtractOneFileFromZIP extends File_Transformer
{
    /**
     * @throws File_Transformer_Exception
     */
    public function performTransform(string $sourceFile): string
    {
        $zip        = new ZipArchive();
        $openResult = $zip->open($sourceFile);

        if ($openResult !== true) {
            throw new File_Transformer_Exception("Couldn't open {$sourceFile} as ZIP file", $openResult);
        }

        // We only ever should receive one file in an archive. Banks being banks, better check.
        if ($zip->numFiles > 1) {
            throw new File_Transformer_Exception("{$sourceFile} has {$zip->numFiles} files. I only know how to handle 1 file in an archive.");
        }

        $targetFile = $this->createTemporaryFile();

        $filename      = $zip->getNameIndex(0);
        $extractResult = copy("zip://" . $sourceFile . "#" . $filename, $targetFile);

        if (!$extractResult) {
            throw new File_Transformer_Exception("Couldn't extract {$filename} from {$sourceFile}");
        }

        return $targetFile;
    }
}
