<?php

/**
 * Extract the one (and only one) file from a given GZIP.
 */
class File_Transformer_ExtractOneFileFromGZIP extends File_Transformer
{
    public function performTransform(string $sourceFile): string
    {
        $targetFile = $this->createTemporaryFile();

        copy("compress.zlib://" . $sourceFile, $targetFile);

        return $targetFile;
    }
}
