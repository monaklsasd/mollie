<?php

/**
 * Decrypt and verify a signed PKCS7 envelope.
 */
class File_Transformer_DecryptAndVerifyPKCS7Data extends File_Transformer
{
    /** @var string */
    private $_certData;

    /** @var array */
    private $_privateKey;

    /** @var string */
    private $_caFile;

    /**
     * @param string $certData   certificate contents
     * @param array  $privateKey [ pkey contents, pkey passphrase ]
     * @param string $caFile     File to CA
     */
    public function __construct($certData, array $privateKey, $caFile)
    {
        $this->_certData   = $certData;
        $this->_privateKey = $privateKey;
        $this->_caFile     = $caFile;
    }

    /**
     * Perform the actual transformation
     *
     * @throws File_Transformer_Exception
     */
    public function performTransform(string $sourceFile): string
    {
        // The file is encrypted, decrypt using our private key
        $tmpFile1 = $this->pkcs7Decrypt($sourceFile);

        // Once it is decrypted, verify it's signed by who we expect it be signed by. Also unpack from PKCS7 structure.
        return $this->pcks7Verify($tmpFile1);
    }

    /**
     * Turn the given file into a SMIME message file in PEM format by adding a content-type header and
     * base64_encoding the contents of the given file.
     *
     * @throws File_Transformer_Exception
     * @throws Throwable
     */
    protected function _makeSMIMEMessageFile(string $file): string
    {
        $workFile = $this->createTemporaryFile();

        $sourceFp = fopen($file, "r");

        if (!$sourceFp) {
            throw new File_Transformer_Exception("Could not read source file: " . $file);
        }

        $targetFp = fopen($workFile, "a+");

        if ($targetFp === false) {
            throw new File_Transformer_Exception("Could not open target file: " . $file);
        }

        /* openssl_pkcs7_verify and openssl_pkcs7_decrypt require a SMIME content-header. It's kinda weird, but there you go */
        fwrite($targetFp, "Content-Type: application/x-pkcs7-mime; smime-type=enveloped-data; name=\"smime.p7m\"" . PHP_EOL . PHP_EOL);

        /* The file supplied by ING is DER encoded (binary) but openssl_pkcs7_* expects PEM, so convert to PEM (base64'ed DER): */
        $param = ['line-length' => 64];
        stream_filter_append($targetFp, "convert.base64-encode", STREAM_FILTER_WRITE, $param);

        try {
            stream_copy_to_stream($sourceFp, $targetFp);
        } finally {
            fclose($sourceFp);
            fclose($targetFp);
        }

        return $workFile;
    }

    /**
     * Decrypt the given sourcefile with openssl_pkcs7_decrypt()
     *
     * @throws File_Transformer_Exception
     *
     * @return string Returns another file
     */
    private function pkcs7Decrypt(string $sourceFile): string
    {
        $workFile = $this->_makeSMIMEMessageFile($sourceFile);

        $tmpFile = $this->createTemporaryFile();

        $decryptResult = openssl_pkcs7_decrypt(
            $workFile,
            $tmpFile,
            $this->_certData,
            $this->_privateKey
        );

        if ($decryptResult !== true) {
            throw new File_Transformer_Exception("Failed to decrypt:" .
                PHP_EOL .
                $this->_getOpenSSLErrorMessages());
        }

        return $tmpFile;
    }

    /**
     * Collect all errors up to now and return as a newline separated string
     */
    protected function _getOpenSSLErrorMessages(): string
    {
        $message = '';

        while (($errorMessage = openssl_error_string()) !== false) {
            $message .= $errorMessage . PHP_EOL;
        }

        return $message;
    }

    /**
     * Check that the given file is signed by a trusted party and that the contents are intact.
     *
     * @param $sourceFile
     *
     * @throws File_Transformer_Exception
     *
     * @return string New file name
     */
    private function pcks7Verify(string $sourceFile): string
    {
        // Output of openssl_pkcs7_decrypt is DER. We need PEM again for openssl_pkcs7_verify.
        $workFile = $this->_makeSMIMEMessageFile($sourceFile);

        $verifyResult = openssl_pkcs7_verify(
            $workFile,
            0,                 // no special options
            '/dev/null',       // we don't want to store the signing certificate
            [$this->_caFile],
            $this->_caFile,
            $workFile
        );

        if ($verifyResult !== true) {
            throw new \File_Transformer_Exception("Failed to verify:" . PHP_EOL . $this->_getOpenSSLErrorMessages());
        }

        return $workFile;
    }
}
