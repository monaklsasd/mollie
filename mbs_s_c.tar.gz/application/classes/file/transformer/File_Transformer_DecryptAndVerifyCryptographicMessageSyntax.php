<?php

use Core\RandomnessGenerator;
use Mollie\Cryptography\RsaKey;
use ParagonIE\HiddenString\HiddenString;
use Symfony\Component\Process\Process;

class File_Transformer_DecryptAndVerifyCryptographicMessageSyntax extends File_Transformer
{
    /** @var string */
    private $certificate_file;

    /** @var string */
    private $private_key_file;

    /** @var \ParagonIE\HiddenString\HiddenString */
    private $random_passphrase;

    /** @var RsaKey */
    private $private_key;

    /**
     * @throws File_Transformer_WriteToTempException
     */
    public function __construct(RsaKey $private_key, string $certificate_file)
    {
        $this->certificate_file = $certificate_file;
        $this->private_key      = $private_key;
    }

    /**
     * @throws File_Transformer_DecryptException
     * @throws File_Transformer_VerifyException
     * @throws File_Transformer_WriteToTempException
     */
    public function performTransform(string $source_file): string
    {
        if ($this->private_key_file === null) {
            $this->private_key_file = $this->createTemporaryFile();

            /*
             * Generate a random passphrase that will protect the private key while it is resting on the file system.
             */
            $this->random_passphrase = new HiddenString(RandomnessGenerator::generateRandomHexadecimalString(64), true, true);

            if (@file_put_contents($this->private_key_file, $this->private_key->export($this->random_passphrase)) === false) {
                throw new File_Transformer_WriteToTempException("Failed storing a copy of the private file on the file system");
            }
        }

        $decrypted_output = $this->decrypt($source_file);
        $output_data      = $this->verify($decrypted_output);

        $output_file_path = $this->createTemporaryFile();

        if (file_put_contents($output_file_path, $output_data) === false) {
            throw new File_Transformer_WriteToTempException("Error writing verified data to a temporary file");
        }

        return $output_file_path;
    }

    /**
     * @throws File_Transformer_DecryptException
     */
    private function decrypt(string $source_file): string
    {
        $decrypt_process = new Process([
            "openssl",
            "cms",
            "-decrypt", // http://openssl.cs.utah.edu/docs/apps/cms.html
            "-in",
            $source_file,
            "-inform",
            "der",
            "-inkey",
            $this->private_key_file,
            "-passin", // http://openssl.cs.utah.edu/docs/apps/openssl.html
            "stdin",
        ], null, null, $this->random_passphrase->getString());

        $decrypt_process->run();

        if ($decrypt_process->getExitCode() !== 0) {
            throw new File_Transformer_DecryptException("Could not decrypt file: {$decrypt_process->getErrorOutput()}");
        }

        return $decrypt_process->getOutput();
    }

    /**
     * @throws File_Transformer_VerifyException
     */
    private function verify(string $file_output): string
    {
        $verify_process = new Process([
            "openssl",
            "cms",
            "-verify",
            "-inform",
            "der",
            "-CAfile",
            $this->certificate_file,
        ], null, null, $file_output);

        $verify_process->run();

        if ($verify_process->getExitCode() !== 0) {
            throw new File_Transformer_VerifyException("Could not verify file: {$verify_process->getErrorOutput()}");
        }

        return $verify_process->getOutput();
    }
}
