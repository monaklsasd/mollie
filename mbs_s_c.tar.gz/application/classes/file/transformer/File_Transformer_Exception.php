<?php

class File_Transformer_Exception extends Exception
{
}
