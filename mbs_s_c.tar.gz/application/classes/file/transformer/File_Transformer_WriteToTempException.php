<?php

class File_Transformer_WriteToTempException extends File_Transformer_Exception
{
}
