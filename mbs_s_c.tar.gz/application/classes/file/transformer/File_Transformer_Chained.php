<?php

/**
 * Perform multiple transforms in one go. First transform to be added to the group is the first
 * transform to be executed. Provides callbacks on completion and exception events.
 *
 * Example usage:
 *
 * <code>
 * $unzipTransform = new File_Transformer_ExtractOneFileFromZip();
 * $groupTransform = new File_Transformer_Group();
 * $groupTransform
 *      ->addTransformer($unzipTransform)
 *
 *  $groupTransform->performTransform('/path/to/my/zipfile');
 * </code>
 */
class File_Transformer_Chained extends File_Transformer
{
    /** @var File_Transformer[] */
    protected $_transformers = [];

    public function __construct(File_Transformer ...$transformers)
    {
        $this->_transformers = $transformers;
    }

    /**
     * @throws Exception
     */
    public function performTransform(string $sourceFile): string
    {
        $file = $sourceFile;

        foreach ($this->_transformers as $transformer) {
            $tmpFile = $transformer->performTransform($file);
            $file    = $tmpFile;
        }

        return $file;
    }
}
