<?php

class File_Transformer_DecryptException extends File_Transformer_Exception
{
}
