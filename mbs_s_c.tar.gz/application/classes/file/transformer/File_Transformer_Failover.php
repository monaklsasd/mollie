<?php

use Webmozart\Assert\Assert;

class File_Transformer_Failover extends File_Transformer
{
    /** @var File_Transformer[] */
    private $transformers;

    public function __construct(File_Transformer ...$transformers)
    {
        Assert::greaterThan(count($transformers), 0);

        $this->transformers = $transformers;
    }

    /**
     * @throws File_Transformer_Exception
     */
    public function performTransform(string $sourceFile): string
    {
        foreach ($this->transformers as $transformer) {
            try {
                return $transformer->performTransform($sourceFile);
            } catch (File_Transformer_Exception $e) {
                /*
                 * Oh noes! Something went terribly wrong. Let's try to run the next transformer and see if that one
                 * is able to complete the transformation.
                 */
            }
        }

        /** @var File_Transformer_Exception $e */
        throw $e;
    }
}
