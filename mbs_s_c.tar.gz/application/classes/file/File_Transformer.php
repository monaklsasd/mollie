<?php

/**
 * Note that all temporary files are automatically removed when the transformer goes out of scope.
 */
abstract class File_Transformer
{
    /** @var array|resource[] */
    private $temporary_files = [];

    /**
     * Actually perform the transform. Implemented in child classes like File_Transformer_DecryptAndVerifyPKCS7Data.
     *
     * @return string The new file
     */
    abstract public function performTransform(string $sourceFile): string;

    /**
     * Create a temporary file. Will be automatically cleaned up by PHP.
     *
     * @see https://github.com/PayU/apple-pay/blob/master/src/ApplePay/Decoding/TemporaryFile/TemporaryFile.php
     */
    protected function createTemporaryFile(): string
    {
        $handle = tmpfile();

        $this->temporary_files[] = $handle;

        $fileMetadata = stream_get_meta_data($handle);

        return $fileMetadata['uri'];
    }
}
