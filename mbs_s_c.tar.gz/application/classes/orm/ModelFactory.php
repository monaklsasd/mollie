<?php

namespace Orm;

use Generator;
use Model_Base;
use Model_Exception;
use Model_ORM;
use Model_Set;
use Orm\Exceptions\InvalidModelClassException;
use sql_db;

class ModelFactory
{
    /** @var sql_db */
    protected $db;

    /** @var Model_Base[] */
    protected $mappers = [];

    public function __construct(sql_db $db)
    {
        $this->db = $db;
    }

    /**
     * Returns a new instance of the specified model class name.
     *
     * @param $model_class_name
     *
     * @throws InvalidModelClassException
     *
     * @return Model_Base|Model_ORM
     */
    public function create($model_class_name)
    {
        if (!is_subclass_of($model_class_name, Model_Base::class)) {
            throw new InvalidModelClassException();
        }

        return new $model_class_name($this->db);
    }

    /**
     * @param string             $model_classname
     * @param int|mixed[]|string $where
     * @param int|mixed[]|string $options
     * @param mixed[]            $config
     *
     * @return int
     */
    public function countAll($model_classname, $where = "1", $options = null, array $config = [])
    {
        $model = $this->getMapper($model_classname);

        return $model->countAll($where, $options, $config);
    }

    /**
     * @param string             $model_classname
     * @param int|mixed[]|string $where
     * @param int|mixed[]|string $options
     * @param mixed[]            $config
     *
     * @throws Model_Exception
     *
     * @return Model_Set|null
     */
    public function findAll($model_classname, $where = "1", $options = null, array $config = [])
    {
        $model = $this->getMapper($model_classname);

        return $model->findAll($where, $options, $config);
    }

    /**
     * @param string  $model_classname
     * @param string  $query
     * @param mixed[] $arguments
     * @param mixed[] $config
     *
     * @throws Model_Exception
     *
     * @return Model_Set
     */
    public function findAllSql($model_classname, $query, array $arguments = [], array $config = [])
    {
        $model = $this->getMapper($model_classname);

        return $model->findAllSql($query, $arguments, $config);
    }

    /**
     * @param string $model_classname
     * @param string $where
     * @param null   $options
     *
     * @return Generator|Model_Base[]
     */
    public function yieldAll($model_classname, $where = "1", $options = null)
    {
        $model = $this->getMapper($model_classname);

        return $model->yieldAll($where, $options);
    }

    /**
     * @param string  $model_classname
     * @param string  $query
     * @param mixed[] $arguments
     *
     * @return Generator|Model_Base[]
     */
    public function yieldAllSql($model_classname, $query, array $arguments = [])
    {
        $model = $this->getMapper($model_classname);

        return $model->yieldAllSql($query, $arguments);
    }

    /**
     * @param $model_classname
     *
     * @return Model_Base
     */
    protected function getMapper($model_classname)
    {
        if (empty($this->mappers[$model_classname])) {
            $this->mappers[$model_classname] = $this->create($model_classname);
        }

        return $this->mappers[$model_classname];
    }

    /**
     * @param string    $model_classname
     * @param int|int[] $model_id
     *
     * @return Model_Base|null
     */
    public function loadById($model_classname, $model_id)
    {
        /** @var Model_Base $model */
        $model = $this->create($model_classname);

        if ($model->load($model_id)) {
            return $model;
        }

        return null;
    }

    /**
     * @param string  $model_classname
     * @param mixed[] $where
     * @param int     $options
     *
     * @return Model_Base|null
     */
    public function loadBy($model_classname, array $where, $options = 1)
    {
        /** @var Model_Base $model */
        $model = $this->create($model_classname);

        if ($model->loadBy($where, $options)) {
            return $model;
        }

        return null;
    }
}
