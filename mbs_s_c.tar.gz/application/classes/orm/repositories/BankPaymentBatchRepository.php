<?php

declare(strict_types=1);

namespace Orm\Repositories;

use Model_BankPaymentBatch;
use Model_Exception;
use Mollie\BankingFiles\Batch\BatchFile;
use Mollie_Database_Exception;
use Orm\Exceptions\InvalidModelClassException;
use Orm\ModelFactory;
use OutOfBoundsException;
use sql_db;
use function strlen;

class BankPaymentBatchRepository
{
    /** @var ModelFactory */
    private $model_factory;

    /** @var sql_db */
    private $db;

    public function __construct(sql_db $db, ModelFactory $model_factory)
    {
        $this->model_factory = $model_factory;
        $this->db            = $db;
    }

    /**
     * @throws OutOfBoundsException
     */
    public function getById(int $id): Model_BankPaymentBatch
    {
        $batch = $this->model_factory->loadById(Model_BankPaymentBatch::class, $id);

        if ($batch === null) {
            throw new OutOfBoundsException(sprintf('No batch found with id %d', $id));
        }

        return $batch;
    }

    /**
     * @throws OutOfBoundsException
     */
    public function getByReference(string $reference): Model_BankPaymentBatch
    {
        $batch = $this->model_factory->loadBy(Model_BankPaymentBatch::class, ['reference' => $reference]);

        if ($batch === null) {
            throw new OutOfBoundsException(sprintf('No batch found with reference "%s"', $reference));
        }

        return $batch;
    }

    /**
     * Finds and returns a SEPA payment batch that contains the specified end to end id.
     *
     * @param string $payment_info_id Something that looks like an MD5 hash, lives in SEPA XML > PmtInf > PmtInfId.
     */
    public function findBySepaPaymentInfoId(?string $payment_info_id): ?Model_BankPaymentBatch
    {
        if ($payment_info_id === null) {
            return null;
        }

        $payment_info_id = trim($payment_info_id);

        // End to end ids are MD5 hash like, so they're at least 32 characters long
        if (strlen($payment_info_id) < 32) {
            return null;
        }

        return $this->model_factory->findAll(
            Model_BankPaymentBatch::class,
            [
                'type' => [
                    'IN',
                    [BatchFile::TYPE_LEGACY_SEPA, BatchFile::TYPE_PAIN008, BatchFile::TYPE_PAIN001_V03],
                ],
                'contents' => [
                    'LIKE',
                    sprintf('%%<PmtInfId>%s</PmtInfId>%%', $this->db->sql_escape_like_string($payment_info_id)),
                ],
            ],
            [
                'ORDER BY' => 'id DESC', // Start searching from the the latest batches
                'LIMIT'    => '1',       // Stop immediately when the batch is found
            ]
        )->at(0);
    }

    /**
     * We leave out contents & result_contents columns because they might be large in size.
     *
     * We order by status 'Pending', then 'Sending ...', then 'Successfully sent ...', then the rest,
     * and then sort each of these groups by date.
     *
     * @throws Model_Exception
     * @throws Mollie_Database_Exception
     * @throws InvalidModelClassException
     *
     * @return Model_BankPaymentBatch[]
     */
    public function findAllPerPage(int $limit, int $offset): array
    {
        $model = $this->model_factory->create(Model_BankPaymentBatch::class);

        $columns = array_diff($model->getColumns(), ['contents', 'result_contents']);

        return $this->model_factory->findAllSql(
            Model_BankPaymentBatch::class,
            "SELECT ^1 
             FROM ^2 
             ORDER BY 
                CASE completed 
                  WHEN 0 THEN 0
                  WHEN 7 THEN 1
                  WHEN 1 THEN 2 
                  ELSE 3 
                END ASC, 
                created_at DESC 
             LIMIT ^3, ^4",
            [
                implode(', ', $columns),
                $model->getTableName(),
                $offset,
                $limit,
            ]
        )->getArrayCopy();
    }

    public function countBankPaymentBatches()
    {
        return $this->model_factory->countAll(Model_BankPaymentBatch::class);
    }
}
