<?php

namespace Orm\Repositories;

use BankAccounts\BankAccount;
use DateTimeImmutable;
use Generator;
use Model\Transaction\TransactionTags;
use Model_BankPaymentBatch;
use Model_Banktransaction;
use Model_Exception;
use Model_Set;
use Orm\ModelFactory;
use OutOfBoundsException;
use sql_db;
use Webmozart\Assert\Assert;

class BanktransactionRepository
{
    /** @var ModelFactory */
    private $model_factory;

    /** @var sql_db */
    private $db;

    public function __construct(ModelFactory $model_factory, sql_db $db)
    {
        $this->model_factory = $model_factory;
        $this->db            = $db;
    }

    public function findById(int $transaction_id): ?Model_Banktransaction
    {
        return $this->model_factory->loadById(Model_Banktransaction::class, $transaction_id);
    }

    public function getById(int $transaction_id): Model_Banktransaction
    {
        $transaction = $this->findById($transaction_id);

        if ($transaction === null) {
            throw new OutOfBoundsException(sprintf('No transaction found with id %d', $transaction_id));
        }

        return $transaction;
    }

    /**
     * @return Generator|iterable|Model_Banktransaction[]
     */
    public function yieldAll(int $start_id = 0, int $chunk_size = 100): iterable
    {
        $last_id = $start_id;

        do {
            $start_id     = $last_id;
            $transactions = $this->model_factory->yieldAll(
                Model_Banktransaction::class,
                ['id' => ['>', $start_id]],
                sprintf('ORDER BY id ASC LIMIT %d, %d', $start_id, $chunk_size)
            );

            foreach ($transactions as $transaction) {
                $last_id = (int)$transaction->getPrimaryKey();

                yield $transaction;
            }
        } while ($last_id > $start_id);
    }

    /**
     * @param int[] $transaction_ids
     *
     * @return Model_Banktransaction[]
     */
    public function findByIds(array $transaction_ids): Model_Set
    {
        Assert::allInteger($transaction_ids);

        return $this->model_factory->findAll(Model_Banktransaction::class, ["id" => ["IN", $transaction_ids]]);
    }

    /**
     * @return Generator|iterable|Model_Banktransaction[]
     */
    public function yieldAllByStatementId(int $bank_statement_id): iterable
    {
        return $this->model_factory->yieldAll(
            Model_Banktransaction::class,
            [
                'statementimport_id' => $bank_statement_id,
            ]
        );
    }

    /**
     * @return Generator|iterable|Model_Banktransaction[]
     */
    public function yieldTopLevelTransactionsByStatementId(int $bank_statement_id): iterable
    {
        return $this->model_factory->yieldAll(
            Model_Banktransaction::class,
            [
                'statementimport_id' => $bank_statement_id,
                'parent_id'          => null,
            ]
        );
    }

    /**
     * @return Generator|iterable|Model_Banktransaction[]
     */
    public function yieldInnerMostTransactionsByStatementId(int $bank_statement_id): iterable
    {
        return $this->model_factory->yieldAllSql(
            Model_Banktransaction::class,
            "
                SELECT bank_transactions.*
                FROM bank_transactions
                LEFT JOIN bank_transactions AS child ON bank_transactions.id = child.parent_id
                WHERE child.id IS NULL AND bank_transactions.statementimport_id = ^1;
               ",
            [$bank_statement_id]
        );
    }

    /**
     * @return Model_Banktransaction[]|Model_Set
     */
    public function findByStatementId(int $statement_id, ?int $offset = null, ?int $limit = null): Model_Set
    {
        return $this->model_factory->findAll(
            Model_Banktransaction::class,
            [
                'statementimport_id' => $statement_id,
            ],
            $limit === null ? null : sprintf('LIMIT %d, %d', $offset, $limit)
        );
    }

    /**
     * @return Model_Banktransaction[]|Model_Set
     */
    public function findByParentId(int $parent_id, ?int $offset = null, ?int $limit = null): Model_Set
    {
        return $this->model_factory->findAll(
            Model_Banktransaction::class,
            [
                'parent_id' => $parent_id,
            ],
            $limit === null ? null : sprintf('LIMIT %d, %d', $offset, $limit)
        );
    }

    public function countAllByStatementId(int $bank_statement_id): int
    {
        return $this->countAllByStatementIds([$bank_statement_id]);
    }

    /**
     * @param int[] $bank_statement_ids
     */
    public function countAllByStatementIds(array $bank_statement_ids): int
    {
        return $this->model_factory->countAll(
            Model_Banktransaction::class,
            [
                'statementimport_id' => ['IN', $bank_statement_ids],
            ]
        );
    }

    /**
     * @return Model_Banktransaction[]|Model_Set
     */
    public function findByBatchRegistration(Model_BankPaymentBatch $batch, ?int $limit): Model_Set
    {
        $transaction_ids = $this->db->sql_fetchcol(sprintf(
            "SELECT transaction_id 
            FROM bank_transaction_registrations 
            WHERE registered_id = %d
            %s;",
            $batch->getPrimaryKey(),
            ($limit !== null) ? "LIMIT {$limit}" : ""
        ));

        if (!$transaction_ids) {
            return new Model_Set();
        }

        return $this->model_factory->findAllSql(
            Model_Banktransaction::class,
            sprintf(
                "SELECT * FROM bank_transactions  
                 WHERE id IN (%s)",
                implode(",", $transaction_ids)
            )
        );
    }

    public function findDebitByEntryDate(DateTimeImmutable $entry_date, array $tags, ?BankAccount $account = null)
    {
        $query = [
            'amount'     => ['<', 0],
            'entry_date' => $entry_date->format('Y-m-d'),
            'tags'       => ['IN', $tags],
        ];

        if ($account !== null) {
            $query['bankaccount_id'] = $account::getId();
        }

        return $this->model_factory->findAll(Model_Banktransaction::class, $query);
    }

    /**
     * Registered transactions (a.k.a. exceptional transactions) are transactions that need to be used for some specific goal.
     * For instance, every day a cronjob finds nonideal transactions on the iDEAL bank account and registers them. Then another
     * process can go and take all those transaction and turn them into a CLIEOP03 file to return the funds to their owner.
     *
     * @return Model_Banktransaction[]|Model_Set
     */
    public function findRegisteredTransactions(string $type, bool $handled): Model_Set
    {
        return $this->model_factory->findAllSql(
            Model_Banktransaction::class,
            'SELECT bank_transactions.* FROM bank_transactions 
              INNER JOIN bank_transaction_registrations ON (bank_transactions.id = bank_transaction_registrations.transaction_id)
              WHERE bank_transaction_registrations.registration_type = $1 AND bank_transaction_registrations.handled = $2
              ORDER BY bank_transactions.entry_date DESC',
            [$type, (int)$handled]
        );
    }

    /**
     * @return Model_Banktransaction[]|Model_Set
     */
    public function findBySearch(array $search_data, int $offset = 0, int $limit = 0): Model_Set
    {
        if ($offset !== 0 || $limit !== 0) {
            $query = sprintf(
                '%s LIMIT %d, %d',
                $this->getSearchQueryBase($search_data, false),
                $offset,
                $limit
            );
        } else {
            $query = $this->getSearchQueryBase($search_data, false);
        }

        return $this->model_factory->findAllSql(Model_Banktransaction::class, $query);
    }

    public function countBySearch(array $search_data): int
    {
        return $this->db->sql_fetchone($this->getSearchQueryBase($search_data, true));
    }

    /**
     * @return Model_Banktransaction[]|Model_Set
     */
    private function getSearchQueryBase(array $search_data, bool $count = false): string
    {
        if (!isset($search_data['bankaccounts']) || count($search_data['bankaccounts']) === 0) {
            throw new Model_Exception("Bankaccounts cannot be empty due to privileges");
        }

        /* Fields that need special handling in the SQL query. They are moved to a local variable
         * and removed from the array that is turned into SQL elements automatically. Later those
         * variables are added to the sql elements. */
        $periode_start = 0;
        $description   = '';
        $tags          = null;
        $ledger        = null;

        $bankaccounts = $search_data['bankaccounts'];
        unset($search_data['bankaccounts']);

        if (isset($search_data['periode_start'])) {
            $periode_start = $search_data['periode_start'];
            unset($search_data['periode_start']);
        }

        if (isset($search_data['periode_tm'])) {
            $periode_end = $search_data['periode_tm'];
            unset($search_data['periode_tm']);
        } else {
            $periode_end = time();
        }

        if (isset($search_data['description'])) {
            $description = $search_data['description'];
            unset($search_data['description']);
        }

        if (isset($search_data['tags'])) {
            $tags = $search_data['tags'];
            unset($search_data['tags']);
        }

        if (isset($search_data['ledger'])) {
            $ledger = true;
        }
        unset($search_data['ledger']);

        /* Build the query */
        $search_data_sql = $this->db->sql_columns_from_array_for_where($search_data);

        $account_ids       = implode(",", array_keys($bankaccounts));
        $search_data_sql[] = "bankaccount_id IN ({$account_ids})";

        if ($periode_start > 0) {
            $search_data_sql[] = "(entry_date BETWEEN '" . date('Y-m-d', $periode_start) . "' AND '" . date('Y-m-d', $periode_end) . "')";
        }

        if ($description) {
            $search_data_sql[] = "(description LIKE '%" . $this->db->sql_escape_like_string($description) . "%' OR bankaccount_name LIKE '%" . $this->db->sql_escape_like_string($description) . "%')";
        }

        if ($ledger) {
            $search_data_sql[] = "handled_by_ledger = 1";
        }

        if ($tags !== null) {
            if ($tags === "") {
                $search_data_sql[] = "(tags IS NULL)";
            } else {
                $search_data_sql[] = "(tags = {$this->db->value_to_sql_field($tags)} OR tags LIKE \"%{$this->db->sql_escape_like_string($tags)}" . TransactionTags::TAG_SEPARATOR . "%\" OR tags LIKE \"%" . TransactionTags::TAG_SEPARATOR . "{$this->db->sql_escape_like_string($tags)}%\")";
            }
            unset($search_data["tags"]);
        }

        return sprintf(
            'SELECT %s FROM bank_transactions WHERE %s ORDER BY bank_transactions.entry_date DESC, bank_transactions.id DESC',
            $count ? 'COUNT(*)' : 'bank_transactions.*',
            implode(' AND ', $search_data_sql)
        );
    }
}
