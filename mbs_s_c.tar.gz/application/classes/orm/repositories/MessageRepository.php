<?php

declare(strict_types=1);

namespace Orm\Repositories;

use MessageModel;
use Model_Base;
use Model_Exception;
use Model_Set;
use Mollie_Database_Exception;
use Orm\ModelFactory;
use sql_db;

class MessageRepository
{
    /** @var ModelFactory */
    private $model_factory;

    /** @var sql_db */
    private $db;

    public function __construct(ModelFactory $model_factory, sql_db $db)
    {
        $this->model_factory = $model_factory;
        $this->db            = $db;
    }

    /**
     * @throws Model_Exception
     *
     * @return MessageModel[]|Model_Set
     */
    public function findUnreadByType(string $type, int $limit = 5): Model_Set
    {
        return $this->model_factory->findAll(MessageModel::class, [
            'message_type' => $type,
            'read_at'      => null,
        ], sprintf('ORDER BY created_at DESC LIMIT %d', $limit));
    }

    /**
     * @throws Model_Exception
     * @throws Mollie_Database_Exception
     * @throws \Orm\Exceptions\InvalidModelClassException
     *
     * @return MessageModel[]|Model_Set
     */
    public function findAllPaginated(int $limit, int $offset, string $type, ?int &$found_rows): Model_Set
    {
        $model = $this->model_factory->create(MessageModel::class);

        $batches = $this->model_factory->findAllSql(
            MessageModel::class,
            sprintf("SELECT * 
             FROM ^2 
             WHERE `message_type` = '%s'
             ORDER BY `created_at` DESC 
             LIMIT ^3, ^4", $type),
            [
                '',
                $model->getTableName(),
                $offset,
                $limit,
            ]
        );

        $found_rows = (int)$this->db->sql_fetchone(sprintf("SELECT COUNT(*) FROM messages WHERE `message_type` = '%s'", $type));

        return $batches;
    }

    /**
     * @return MessageModel|null
     */
    public function findById(int $id): ?Model_Base
    {
        return $this->model_factory->loadById(MessageModel::class, $id);
    }
}
