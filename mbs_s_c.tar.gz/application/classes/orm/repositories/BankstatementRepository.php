<?php

declare(strict_types=1);

namespace Orm\Repositories;

use BankAccounts\BankAccount;
use DateTimeImmutable;
use DateTimeInterface;
use Helper\DateTime\Now;
use InvalidArgumentException;
use LengthException;
use Model_Bankstatement;
use Model_Base;
use Model_ORM;
use Model_Set;
use Orm\ModelFactory;
use OutOfBoundsException;

class BankstatementRepository
{
    use Now;

    /** @var ModelFactory */
    private $model_factory;

    public function __construct(ModelFactory $model_factory)
    {
        $this->model_factory = $model_factory;
    }

    public function findById(int $bank_statement_id): ?Model_Bankstatement
    {
        return $this->model_factory->loadById(Model_Bankstatement::class, $bank_statement_id);
    }

    public function getById(int $bank_statement_id): Model_Bankstatement
    {
        $statement = $this->findById($bank_statement_id);

        if ($statement === null) {
            throw new OutOfBoundsException(sprintf('No statements found with id %d', $bank_statement_id));
        }

        return $statement;
    }

    public function hasBeenImportedYet(
        BankAccount $bank_account,
        string $statement_reference,
        ?int $statement_number,
        ?int $sequence_number
    ) {
        return $this->model_factory->loadBy(
            Model_Bankstatement::class,
            [
                'bankaccount_id'      => $bank_account::getId(),
                'statement_reference' => $statement_reference,
                'statement_number'    => $statement_number,
                'sequence_number'     => $sequence_number,
            ]
        ) !== null;
    }

    public function getLastByBankAccount(BankAccount $bank_account): Model_Bankstatement
    {
        $statement = $this->model_factory->loadBy(
            Model_Bankstatement::class,
            [
                'bankaccount_id' => $bank_account::getId(),
            ],
            [
                'ORDER BY' => 'id ASC',
                'LIMIT'    => '1',
            ]
        );

        if ($statement === null) {
            throw new LengthException(sprintf('No statements found for Bank Account %d', $bank_account::getId()));
        }

        return $statement;
    }

    public function getByBankAccountAndDate(BankAccount $bank_account, DateTimeImmutable $date_time): Model_Bankstatement
    {
        $statement = $this->model_factory->loadBy(
            Model_Bankstatement::class,
            [
                'bankaccount_id' => $bank_account::getId(),
                'statement_date' => ['BETWEEN', [
                    $date_time->format('Y-m-d'),
                    $date_time->modify('+ 3 days')->format('Y-m-d'), //account for weekend
                ]],
            ],
            [
                'ORDER BY' => 'statement_date ASC',
                'LIMIT'    => '1',
            ]
        );

        if ($statement === null) {
            throw new LengthException(sprintf(
                'No statement found for Bank Account %d and date %s.',
                $bank_account::getId(),
                $date_time->format('Y-m-d')
            ));
        }

        return $statement;
    }

    /**
     * @return Model_Bankstatement[]|Model_Set
     */
    public function getByBankAccountAndDates(
        BankAccount $bank_account,
        ?DateTimeImmutable $start_date,
        ?DateTimeImmutable $end_date
    ): Model_Set {
        return $this->model_factory->findAll(
            Model_Bankstatement::class,
            [
                'bankaccount_id' => $bank_account::getId(),
                'statement_date' => ['BETWEEN', [
                    ($start_date ?? self::getNow()->modify('- 1 month'))->format('Y-m-d'),
                    ($end_date ?? self::getNow())->format('Y-m-d'),
                ]],
            ],
            [
                'ORDER BY' => 'statement_date ASC',
            ]
        );
    }

    /**
     * @return iterable|Model_Bankstatement[]
     */
    public function getUnexportedByBankAccountIds(
        array $bank_account_ids,
        ?DateTimeImmutable $start_date = null,
        ?DateTimeImmutable $end_date = null
    ): iterable {
        if ($start_date === null xor $end_date === null) {
            throw new InvalidArgumentException('Neither or both $start_date and $end_date should be supplied.');
        }

        $criteria = [
            'bankaccount_id'     => ['IN', array_map('intval', $bank_account_ids)],
            'accountview_status' => Model_Bankstatement::ACCOUNTVIEW_STATUS_READY,
        ];

        if ($start_date && $end_date) {
            $criteria['statement_date'] = [
                'BETWEEN',
                [
                    $start_date->format(Model_ORM::DATE_ONLY_SQL),
                    $end_date->format(Model_ORM::DATE_ONLY_SQL),
                ],
            ];
        }

        return $this->model_factory->findAll(Model_Bankstatement::class, $criteria);
    }

    public function getLatestBankStatementBefore(BankAccount $bank, DateTimeInterface $date): ?Model_Bankstatement
    {
        return $this->model_factory->loadBy(
            Model_Bankstatement::class,
            [
                'statement_date' => [
                    '<',
                    $date->format(Model_ORM::DATE_ONLY_SQL),
                ],
                'bankaccount_id' => $bank::getId(),
            ],
            [
                'ORDER BY' => 'statement_date desc',
                'LIMIT'    => '1',
            ]
        );
    }

    /**
     * @return Model_Bankstatement[] [$bankaccount_id => Model_Bankstatement]
     */
    public function getLatestStatementPerBankAccount(): array
    {
        /** @var Model_Bankstatement[] $statements */
        $statements = $this->model_factory->findAllSql(
            Model_Bankstatement::class,
            'SELECT 
                bank_statement_imports.* 
            FROM
                bank_statement_imports
            INNER JOIN (
                SELECT 
                    bankaccount_id, MAX(statement_date) AS statement_date 
                FROM bank_statement_imports
                WHERE
                    statement_date > $1
                GROUP BY bankaccount_id
            ) AS latest_entries
            ON
              latest_entries.bankaccount_id = bank_statement_imports.bankaccount_id AND
              latest_entries.statement_date = bank_statement_imports.statement_date;',
            [self::getNow()->modify('-2 weeks')->format(Model_Base::DATE_ONLY_SQL)]
        );

        $sorted = [];

        foreach ($statements as $statement) {
            $sorted[$statement->getBankAccountId()] = $statement;
        }

        return $sorted;
    }

    public function getStatementsByAccountViewStatus(string $account_view_status): Model_Set
    {
        return $this->model_factory->findAll(
            Model_Bankstatement::class,
            [
                'accountview_status' => $account_view_status,
            ],
            [
                "ORDER BY" => 'statement_date DESC',
            ]
        );
    }

    private static function getPredicatesForProvisionalStatement(): array
    {
        return ['finalized_at_utc' => null];
    }

    public function findProvisionalStatement(
        BankAccount $bank_account,
        DateTimeImmutable $statement_date
    ): ?Model_Bankstatement {
        $criteria = [
            'bankaccount_id' => $bank_account::getId(),
            'statement_date' => $statement_date->format(Model_Base::DATE_ONLY_SQL),
        ];

        $criteria = array_merge($criteria, self::getPredicatesForProvisionalStatement());

        return $this->model_factory->loadBy(Model_Bankstatement::class, $criteria);
    }

    public function getSingleProvisionalStatement(
        BankAccount $bankAccount,
        DateTimeInterface $statementDate
    ): ?Model_Bankstatement {
        $criteria = [
            'bankaccount_id' => $bankAccount::getId(),
            'statement_date' => $statementDate->format(Model_ORM::DATE_ONLY_SQL),
        ];

        $criteria = array_merge($criteria, self::getPredicatesForProvisionalStatement());

        $statements = $this->model_factory->findAll(Model_Bankstatement::class, $criteria);

        if ($statements->count() > 1) {
            $exceptionMessage = sprintf(
                "There are more than one provisional statements for account ID: %d (%s), please fix this.",
                $bankAccount::getId(),
                $bankAccount::getDescription()
            );

            throw new \RuntimeException($exceptionMessage);
        }

        return $statements->first();
    }
}
