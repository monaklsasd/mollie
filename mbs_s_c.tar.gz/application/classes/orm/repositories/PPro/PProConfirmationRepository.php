<?php

namespace Orm\Repositories\PPro;

use Model_Ppro_Confirmation;
use Orm\ModelFactory;

class PProConfirmationRepository
{
    /** @var ModelFactory */
    private $model_factory;

    public function __construct(ModelFactory $model_factory)
    {
        $this->model_factory = $model_factory;
    }

    public function findByTransactionId(string $record_type_code, int $transaction_id): ?Model_Ppro_Confirmation
    {
        return $this->model_factory->loadBy(
            Model_Ppro_Confirmation::class,
            [
                "record_type"      => $record_type_code,
                "type_specific_id" => $transaction_id,
            ]
        );
    }
}
