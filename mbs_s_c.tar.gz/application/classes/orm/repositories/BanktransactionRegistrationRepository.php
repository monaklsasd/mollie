<?php

declare(strict_types=1);

namespace Orm\Repositories;

use Model_TransactionRegistration;
use Orm\ModelFactory;
use sql_db;

class BanktransactionRegistrationRepository
{
    /** @var ModelFactory */
    private $model_factory;

    /** @var sql_db */
    private $db;

    public function __construct(ModelFactory $model_factory, sql_db $db)
    {
        $this->model_factory = $model_factory;
        $this->db            = $db;
    }

    /**
     * @return int[]
     */
    public function getRegistrationCountPerType(): array
    {
        $tableName = $this->model_factory->create(Model_TransactionRegistration::class)->getTableName();

        $query_result = $this->db->sql_query('
            SELECT r.registration_type, COUNT(r.id) AS total FROM ' . $tableName . ' r
                INNER JOIN bank_transactions t ON (t.id = r.transaction_id)
                LEFT JOIN banktransaction_suspensions s ON (t.id = s.banktransaction_id AND s.deleted_at IS NULL)
                WHERE r.handled = 0 AND s.id IS NULL
                GROUP BY r.registration_type
        ');

        $result = [];

        while ($row = $this->db->sql_fetchrow($query_result)) {
            $result[$row['registration_type']] = $row['total'];
        }
        $this->db->sql_freeresult($query_result);

        return $result;
    }
}
