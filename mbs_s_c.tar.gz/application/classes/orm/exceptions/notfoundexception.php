<?php

namespace Orm\Exceptions;

use Exception;

class NotFoundException extends Exception
{
}
