<?php

namespace Orm\Exceptions;

use Exception;

class InvalidModelClassException extends Exception
{
}
