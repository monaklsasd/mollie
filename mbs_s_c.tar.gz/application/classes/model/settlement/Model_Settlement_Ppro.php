<?php

/**
 * Model_Settlement_Ppro
 *
 * ORM-model for m_ppro_settlements table
 *
 * @author    Mollie <info@mollie.nl> Nov 28, 2017
 * @copyright Copyright (C) Mollie B.V.
 *
 * @property int    $id              Maps to m_ppro_settlements.id
 * @property string $reference       Maps to m_ppro_settlements.reference
 * @property string $settlement_date Maps to m_ppro_settlements.settlement_date, YYYY-MM-DD
 * @property int    $created_at_utc  Maps to m_ppro_settlements.created_at_utc
 *
 * @method Model_Set|Model_Settlement_Ppro_Record[] records() records(array $where_fields = null, $options = NULL, array $config = [])
 * @method Model_Set|Model_Settlement_Ppro_File[]   files()   files(array $where_fields = null, $options = NULL, array $config = [])
 */
class Model_Settlement_Ppro extends Model_ORM
{
    protected $_model_name = __CLASS__;

    /** @var string */
    protected $_table_name = 'm_ppro_settlements';

    /** @var array */
    protected $_table_columns = [
        'id',
        'reference',
        'settlement_date',
        'created_at_utc',
    ];

    protected $_relationships = [
        'files' => [
            'type'  => Model_ORM::HAS_MANY,
            'model' => Model_Settlement_Ppro_File::class,
        ],
        'records' => [
            'type'  => Model_ORM::HAS_MANY,
            'model' => Model_Settlement_Ppro_Record::class,
        ],
    ];
}
