<?php

use Money\Currency;

/**
 * Model_Settlement_Ppro_Record
 *
 * ORM-model for m_ppro_settlement_records table
 *
 * @author    Mollie <info@mollie.nl> Nov 28, 2017
 * @copyright Copyright (C) Mollie B.V.
 *
 * @property int                                            $id                           Maps to m_ppro_settlement_records.id
 * @property int|null                                       $settlement_id                Maps to m_ppro_settlement_records.settlement_id
 * @property int|null                                       $settlement_file_id           Maps to m_ppro_settlement_records.settlement_file_id
 * @property string                                         $mollie_transaction_reference Maps to m_ppro_settlement_records.mollie_transaction_reference, contains Mollie payment tokens
 * @property string                                         $payment_method               Maps to m_ppro_settlement_records.payment_method
 * @property string                                         $record_type                  Maps to m_ppro_settlement_records.record_type
 * @property string                                         $event_type                   Maps to m_ppro_settlement_records.event_type
 * @property string                                         $event_timestamp              Maps to m_ppro_settlement_records.event_timestamp
 * @property int                                            $type_specific_id             Maps to m_ppro_settlement_records.type_specific_id
 * @property float                                          $amount                       Maps to m_ppro_settlement_records.amount
 * @property string                                         $currency                     Maps to m_ppro_settlement_records.currency
 * @property string                                         $country                      Maps to m_ppro_settlement_records.country
 * @property string|null                                    $fee_type                     Maps to m_ppro_settlement_records.record_type
 * @property Model_Settlement_Ppro_Record_Chargeback        $chargeback                   Chargeback component of the record
 * @property Model_Settlement_Ppro_Record_Payment_Reference $payment_reference            Payment reference component of the record
 */
class Model_Settlement_Ppro_Record extends Model_ORM
{
    public const RECORD_TYPE_CHARGEBACK  = 'CB';
    public const RECORD_TYPE_REFUND      = 'RF';
    public const RECORD_TYPE_TRANSACTION = 'TX';

    protected $_model_name = __CLASS__;

    /** @var string */
    protected $_table_name = 'm_ppro_settlement_records';

    /** @var array */
    protected $_table_columns = [
        'id', 'parent_id', 'settlement_id', 'settlement_file_id', 'mollie_transaction_reference', 'payment_method',
        'record_type', 'type_specific_id', 'event_type', 'event_timestamp', 'amount', 'currency', 'country', 'fee_type',
    ];

    protected $_relationships = [
        'settlement' => [
            'type'        => \Model_ORM::BELONGS_TO,
            'model'       => Model_Settlement_Ppro::class,
            'foreign_key' => 'settlement_id',
        ],
        'parent' => [
            'type'        => \Model_ORM::BELONGS_TO,
            'model'       => \Model_Settlement_Ppro_Record::class,
            'foreign_key' => 'parent_id',
        ],
        'payment_reference' => [
            'type'  => \Model_ORM::HAS_ONE,
            'model' => \Model_Settlement_Ppro_Record_Payment_Reference::class,
        ],
        'chargeback' => [
            'type'  => \Model_ORM::HAS_ONE,
            'model' => \Model_Settlement_Ppro_Record_Chargeback::class,
        ],
    ];

    public function refersToPayment()
    {
        return in_array($this->record_type, [self::RECORD_TYPE_REFUND, self::RECORD_TYPE_TRANSACTION]);
    }

    public function refersToChargeback()
    {
        return in_array($this->record_type, [self::RECORD_TYPE_CHARGEBACK]);
    }

    final public function getCurrency(): Currency
    {
        return new Currency($this->currency);
    }
}
