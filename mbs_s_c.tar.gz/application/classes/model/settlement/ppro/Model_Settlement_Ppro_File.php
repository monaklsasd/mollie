<?php

use Core\Time\Clock;
use Model\Settlement\Ppro\SettlementFileType;
use Supplier\PPro\Settlement\Checksum;

/**
 * Model_Settlement_PPro_File
 *
 * ORM-model for m_ppro_settlement_files table
 *
 * @copyright Copyright (C) Mollie B.V.
 *
 * @property int                   $id              Maps to m_settlements_ppro_files.id, int(11) unsigned
 * @property string                $filename        Maps to m_settlements_ppro_files.filename, varchar(255)
 * @property int                   $file_type_id    Maps to m_settlements_ppro_files.file_type_id, int(5)
 * @property int|null              $settlement_id   Maps to m_settlements_ppro_files.settlement_id, int(11)
 * @property string                $contents        Maps to m_settlements_ppro_files.contents, longtext
 * @property string                $created_at      Maps to m_settlements_ppro_files.created_at, datetime
 * @property string                $updated_at      Maps to m_settlements_ppro_files.updated_at, datetime
 * @property string|null           $processed_at    Maps to m_settlements_ppro_files.processed_at, datetime
 * @property int|null              $checksum_count  Maps to m_settlements_ppro_files.checksum_count, int
 * @property float|null            $checksum_amount Maps to m_settlements_ppro_files.checksum_amount, float(10,2)
 * @property Model_Settlement_Ppro $settlement      Maps to m_settlements_ppro_files.settlement_id, int
 */
class Model_Settlement_Ppro_File extends Model_ORM
{
    protected $_model_name = __CLASS__;

    /** @var string */
    protected $_table_name = 'm_ppro_settlement_files';

    /** @var array */
    protected $_table_columns = [
        'id',
        'filename',
        'file_type_id',
        'settlement_id',
        'contents',
        'created_at',
        'updated_at',
        'processed_at',
        'checksum_count',
        'checksum_amount',
    ];

    protected $_relationships = [
        'settlement' => [
            'type'        => \Model_ORM::BELONGS_TO,
            'model'       => \Model_Settlement_Ppro::class,
            'foreign_key' => 'settlement_id',
        ],
    ];

    public function hasChecksumValues()
    {
        return $this->checksum_amount !== null && $this->checksum_count !== null;
    }

    public function getChecksum(): ?Checksum
    {
        if (!$this->hasChecksumValues()) {
            return null;
        }

        return new Checksum($this->checksum_count, $this->checksum_amount);
    }

    public function setChecksum(Checksum $checksum)
    {
        $this->checksum_amount = $checksum->getAmount();
        $this->checksum_count  = $checksum->getCount();
    }

    public function setType(SettlementFileType $settlement_file_type): void
    {
        $this->file_type_id = $settlement_file_type->getValue();
    }

    public function isOfType(SettlementFileType $settlement_file_type): bool
    {
        return $this->file_type_id == $settlement_file_type->getValue();
    }

    public function isProcessed(): bool
    {
        if ($this->processed_at !== null) {
            return true;
        }

        return false;
    }

    public function markAsProcessed()
    {
        $this->processed_at = Clock::getFormattedUtcDate(static::DATE_SQL);
    }
}
