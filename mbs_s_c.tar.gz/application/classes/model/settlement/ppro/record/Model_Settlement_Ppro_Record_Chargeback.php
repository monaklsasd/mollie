<?php

/**
 * Model_Settlement_Ppro_Record_Chargeback
 *
 * ORM-model for m_ppro_settlement_record_chargebacks table
 *
 * @author    Mollie <info@mollie.nl> Nov 28, 2017
 * @copyright Copyright (C) Mollie B.V.
 *
 * @property string $reason_code        Maps to m_ppro_settlement_record_chargebacks.reason_code
 * @property string $reason_description Maps to m_ppro_settlement_record_chargebacks.reason_description
 */
class Model_Settlement_Ppro_Record_Chargeback extends Model_ORM
{
    protected $_model_name = __CLASS__;

    /** @var string */
    protected $_table_name = 'm_ppro_settlement_record_chargebacks';
    /** @var array */
    protected $_table_columns = [
        'id', 'settlement_record_id', 'reason_code', 'reason_description',
    ];

    protected $_relationships = [
        'record' => [
            'type'        => \Model_ORM::BELONGS_TO,
            'model'       => Model_Settlement_Ppro_Record::class,
            'foreign_key' => 'settlement_record_id',
        ],
    ];
}
