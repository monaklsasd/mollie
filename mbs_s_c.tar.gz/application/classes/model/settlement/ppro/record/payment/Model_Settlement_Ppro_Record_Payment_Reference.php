<?php

/**
 * Model_Settlement_Ppro_Record_Payment_Reference
 *
 * ORM-model for m_ppro_settlement_record_payment_references table
 *
 * @author    Mollie <info@mollie.nl> Nov 28, 2017
 * @copyright Copyright (C) Mollie B.V.
 *
 * @property int    $id                   Maps to m_settlements_ppro_record_payment_references.id
 * @property int    $settlement_record_id Maps to m_settlements_ppro_record_payment_references.settlement_id
 * @property string $payment_reference    Maps to m_settlements_ppro_record_payment_references.payment_reference
 */
class Model_Settlement_Ppro_Record_Payment_Reference extends Model_ORM
{
    protected $_model_name = __CLASS__;

    /** @var string */
    protected $_table_name = 'm_ppro_settlement_record_payment_references';
    /** @var array */
    protected $_table_columns = [
        'id', 'settlement_record_id', 'payment_reference',
    ];

    protected $_relationships = [
        'record' => [
            'type'        => \Model_ORM::BELONGS_TO,
            'model'       => Model_Settlement_Ppro_Record::class,
            'foreign_key' => 'settlement_record_id',
        ],
    ];
}
