<?php

namespace Model\Settlement\Ppro;

use MyCLabs\Enum\Enum;

/**
 * @method static self TRANSACTION_VOLUME()
 * @method static self REFUND_VOLUME()
 * @method static self CHARGEBACK_VOLUME()
 * @method static self TRANSACTION_FEE()
 * @method static self REFUND_FEE()
 * @method static self CHARGEBACK_FEE()
 * @method static self AGGREGATE()
 */
class SettlementFileType extends Enum
{
    private const TRANSACTION_VOLUME = 1;
    private const REFUND_VOLUME      = 2;
    private const CHARGEBACK_VOLUME  = 3;
    private const TRANSACTION_FEE    = 4;
    private const REFUND_FEE         = 5;
    private const CHARGEBACK_FEE     = 6;
    private const AGGREGATE          = 7;
}
