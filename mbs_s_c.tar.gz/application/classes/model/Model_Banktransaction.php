<?php

use App\Entity\User;
use App\Util\Sanitize;
use BankAccounts\BankAccount;
use BankAccounts\BankAccountRepository;
use Core\Money\Currencies;
use Core\Time\TimeZones;
use Ledger\Journal;
use Model\Transaction\HasTransactionClassification;
use Model\Transaction\HasTransactionTags;
use Model\Transaction\TransactionInterpretation;
use Model\Transaction\TransactionTags;
use Money\Currency;
use Money\Money;
use function Core\Money\money_from_string;
use function Core\Money\money_to_string;

/**
 * Model for bank_transactions.
 *
 * There are several dates involved:
 *
 * - entry_date (boekdatum). The date on which the transaction happened for our administration
 * - value_date (valutadatum). The date on which we will start / stop earning interest on the transaction
 * - customer_date. The date on which the money was removed from the contra account (
 *
 * @property int                              $id                 Maps to bank_transactions.id, int(10) unsigned
 * @property int|null                         $parent_id          Maps to bank_transactions.parent_id, int(10) unsigned
 * @property int                              $bankaccount_id     Maps to bank_transactions.bankaccount_id, int(10) unsigned
 * @property int                              $statementimport_id Maps to bank_transactions.statementimport_id, int(10) unsigned
 * @property int                              $bankreport_id      Maps to bank_transactions.bankreport_id, bigint(20) unsigned
 * @property string                           $entry_date         Maps to bank_transactions.entry_date, date
 * @property string|null                      $value_date         Maps to bank_transactions.value_date, date
 * @property string|null                      $customer_date      Maps to bank_transactions.customer_date, datetime
 * @property float                            $amount             Maps to bank_transactions.amount, decimal(10,2)
 * @property float|null                       $original_amount    Maps to bank_transactions.original_amount, decimal(10,2)
 * @property string|null                      $original_currency  Maps to bank_transactions.original_currency, char(3)
 * @property string                           $bankaccount_nr     Maps to bank_transactions.bankaccount_nr, varchar(100)
 * @property string|null                      $bic                Maps to bank_transactions.bic, varchar(11)
 * @property string|null                      $bankaccount_name   Maps to bank_transactions.bankaccount_name, varchar(255)
 * @property string|null                      $tags               Maps to bank_transactions.tags, varchar(50)
 * @property string|null                      $description        Maps to bank_transactions.description, text
 * @property string                           $handled_by_ledger  Maps to bank_transactions.handled_by_ledger, tinyint(1)
 * @property string|null                      $tag_data           Maps to bank_transactions.tag_data, text
 * @property string|null                      $mutation_code      Maps to bank_transactions.mutation_code, varchar(50)
 * @property string                           $created_at_utc     Maps to bank_transactions.created_at_utc, datetime
 * @property string                           $updated_at_utc     Maps to bank_transactions.updated_at_utc, datetime
 * @property Model_Banktransaction_Settlement $settlement         The Model_Banktransaction_Settlement for this transaction
 * @property Model_Bankstatement              $statement          The Model_Bankstatement referenced by $statementimport_id
 * @property Model_Banktransaction            $parent_transaction The Model_Banktransaction referenced by $parent_id
 *
 * @method Model_Set|Model_TransactionRegistration[] registrations()          registrations(array $where_fields = NULL, $options = NULL, array $config = [])
 * @method Model_Set|Model_TransactionComment[]      comments()               comments(array $where_fields = NULL, $options = NULL, array $config = [])
 * @method Model_Banktransaction[]|Model_Set         child_transactions()     child_transactions(array $where_fields = NULL, $options = NULL, array $config = [])
 */
class Model_Banktransaction extends Model_ORM implements TransactionTags
{
    use HasTransactionTags;
    use TransactionInterpretation;
    use HasTransactionClassification;

    protected $_model_name    = __CLASS__;
    protected $_table_name    = 'bank_transactions';
    protected $_table_columns = [
        'id', 'parent_id', 'bankaccount_id', 'statementimport_id', 'handled_by_ledger',
        'entry_date', 'value_date', 'customer_date',
        'amount', 'original_amount', 'original_currency', 'bankaccount_nr', 'bic',
        'bankaccount_name', 'tags', 'description', 'tag_data', 'mutation_code',
        'created_at_utc', 'updated_at_utc', 'bankreport_id',
    ];

    protected $_relationships = [
        'statement' => [
            'type'        => Model_ORM::BELONGS_TO,
            'model'       => Model_Bankstatement::class,
            'foreign_key' => 'statementimport_id',
        ],
        'settlement' => [
            'type'  => Model_ORM::HAS_ONE,
            'model' => Model_Banktransaction_Settlement::class,
        ],
        'registrations' => [
            'type'  => Model_ORM::HAS_MANY,
            'model' => Model_TransactionRegistration::class,
        ],
        'comments' => [
            'type'  => Model_ORM::HAS_MANY,
            'model' => Model_TransactionComment::class,
        ],
        'parent_transaction' => [
            'type'        => Model_ORM::BELONGS_TO,
            'model'       => Model_Banktransaction::class,
            'foreign_key' => 'parent_id',
        ],
        'child_transactions' => [
            'type'  => Model_ORM::HAS_MANY,
            'model' => Model_Banktransaction::class,
        ],
    ];

    public function setStatement(Model_Bankstatement $statement): void
    {
        $this->statement = $statement;
        $this->setBankAccount($statement->getBankAccount());
        $this->setEntryDate($statement->getStatementDate());
    }

    public function getStatement(): Model_Bankstatement
    {
        if ($this->statementimport_id !== '0') {
            return $this->statement;
        }

        // For older transaction the statement might not have been copied over from the parent. Get it from there.
        $statement           = null;
        $current_transaction = $this;

        while ($statement === null && $current_transaction = $current_transaction->getParentTransaction()) {
            if ($current_transaction->statementimport_id !== '0') {
                return $current_transaction->statement;
            }
        }

        throw new OutOfBoundsException('Statement could not be found.');
    }

    /**
     * Older transactions might not have a statement assigned, less old transaction might not have the value copied over from the parent.
     * This covers both cases.
     */
    public function hasStatement(): bool
    {
        if ($this->statementimport_id !== '0') {
            return true;
        }

        try {
            $this->getStatement();

            return true;
        } catch (OutOfBoundsException $e) {
            return false;
        }
    }

    public function hasParentTransaction(): bool
    {
        return $this->parent_id !== null && $this->parent_id !== '';
    }

    public function getParentTransaction(): ?Model_Banktransaction
    {
        return $this->parent_transaction;
    }

    public function setParentTransaction(Model_Banktransaction $parent): void
    {
        $this->parent_transaction = $parent;
        $this->setStatement($parent->getStatement());

        /*
         * I don't think the entry date of the statement can be different from the transaction,
         * but propagate from parent anyway.
         */
        $this->setEntryDate($parent->getEntryDate());

        $this->setValueDate($parent->getValueDate());
        $this->setLedgerTransactionFlag($parent->isLedgerTransaction());
    }

    /**
     * @return Model_Banktransaction[]|Model_Set
     */
    public function getChildTransactions(): Model_Set
    {
        return $this->findAll([
            'parent_id' => $this->getPrimaryKey(),
        ]);
    }

    public function countChildTransactions(): int
    {
        return $this->relationCount('child_transactions');
    }

    /**
     * @return Generator|Model_Banktransaction[]
     */
    public function yieldChildTransactions(): Generator
    {
        yield from $this->yieldAll([
            'parent_id' => $this->getPrimaryKey(),
        ]);
    }

    public function hasSettlement(): bool
    {
        return $this->settlement !== null;
    }

    public function getSettlement(): Model_Banktransaction_Settlement
    {
        return $this->settlement;
    }

    public function setSettlement(?Model_Banktransaction_Settlement $settlement): void
    {
        $this->settlement = $settlement;
    }

    /**
     * @codeCoverageIgnore ugly, but needed as separate function for tests. can be cleaned up with doctrine migration
     *
     * @internal
     */
    protected function createTransactionCommentModel(): Model_TransactionComment
    {
        return new Model_TransactionComment($this->_db);
    }

    public function addComment(string $comment_text, ?User $user = null): void
    {
        $comment = $this->createTransactionCommentModel();
        $comment->forTransaction($this, $comment_text, $user);

        $comment->saveOrDie();
    }

    /**
     * @return Model_Set|Model_TransactionComment[]
     */
    public function getComments(): Model_Set
    {
        return $this->comments();
    }

    public function countComments(): int
    {
        return $this->relationCount('comments');
    }

    /**
     * @return Model_Set|Model_TransactionRegistration[]
     */
    public function getRegistrations(): Model_Set
    {
        return $this->registrations();
    }

    public function countRegistrations(): int
    {
        return $this->relationCount('registrations');
    }

    public function getDescription(): ?string
    {
        return Sanitize::trimAndEmptyToNull($this->description);
    }

    public function setDescription(?string $description): void
    {
        $this->description = Sanitize::trimAndEmptyToNull($description);
    }

    public function getOffsetAccountNumber(): ?string
    {
        return Sanitize::trimAndEmptyToNull($this->bankaccount_nr);
    }

    public function setOffsetAccountNumber(?string $number): void
    {
        // can not be null in the db at the moment, should be migrated at a later time.
        $this->bankaccount_nr = trim((string)$number);
    }

    /**
     * Verkrijg de naam van de tegenrekeninghouder. In het geval van SEPA is deze bekend; in het geval van een gewone
     * transactie wordt deze uit de eerste regel van de omschrijving gehaald.
     */
    public function getOffsetAccountName(): ?string
    {
        return Sanitize::trimAndEmptyToNull($this->bankaccount_name);
    }

    public function setOffsetAccountName(?string $name): void
    {
        $this->bankaccount_name = Sanitize::trimAndEmptyToNull($name);
    }

    public function getOffsetAccountBic(): ?string
    {
        return Sanitize::trimAndEmptyToNull($this->bic);
    }

    public function setOffsetAccountBic(?string $bic): void
    {
        $this->bic = Sanitize::trimAndEmptyToNull($bic);
    }

    public function getCurrency(): Currency
    {
        return $this->getBankAccount()::getCurrency();
    }

    public function getAmount(): Money
    {
        return money_from_string((string)$this->amount, $this->getCurrency());
    }

    public function setAmount(Money $amount): void
    {
        if (!$this->getCurrency()->equals($amount->getCurrency())) {
            throw new InvalidArgumentException(sprintf(
                'This bankaccount only supports %s transactions, got %s.',
                Currencies::EUR()->getCode(),
                $amount->getCurrency()->getCode()
            ));
        }

        $this->amount = money_to_string($amount);
    }

    public function setOriginalAmount(Money $original_amount): void
    {
        $this->original_amount   = money_to_string($original_amount);
        $this->original_currency = $original_amount->getCurrency();
    }

    public function getOriginalAmount(): Money
    {
        return money_from_string((string)$this->original_amount, new Currency($this->original_currency));
    }

    /**
     * The date on which the transaction happened for our administration (dutch: boekdatum)
     *
     * Returns DateTimeObject with time set to midnight in BankAccount timezone.
     * Always Europe/Amsterdam at time of writing.
     */
    public function getEntryDate(): DateTimeImmutable
    {
        return DateTimeImmutable::createFromFormat('!' . Model_ORM::DATE_ONLY_SQL, $this->entry_date, TimeZones::amsterdam());
    }

    public function setEntryDate(DateTimeImmutable $entry_date): void
    {
        $this->entry_date = $entry_date->format(Model_ORM::DATE_ONLY_SQL);
    }

    /**
     * The date on which we will start / stop earning interest on the transaction (dutch: valutadatum)
     *
     * Returns DateTimeObject with time set to midnight in BankAccount timezone.
     * Always Europe/Amsterdam at time of writing.
     */
    public function getValueDate(): DateTimeImmutable
    {
        $value_date = DateTimeImmutable::createFromFormat('!' . Model_ORM::DATE_ONLY_SQL, $this->value_date, TimeZones::amsterdam()) ?: null;

        // For older transaction the value date might not have been copied over from the parent. Get it from there.
        $current_transaction = $this;

        while ($value_date === null && $current_transaction = $current_transaction->getParentTransaction()) {
            $value_date = $current_transaction->getValueDate();
        }

        /*
         * For very old transaction the value date might not have been set at all.
         * We'll use the entry date for these, as this is VERY likely correct (can only be wrong for the last 20-30 seconds of the day)
         */
        if ($value_date === null) {
            $value_date = $this->getEntryDate();
        }

        return $value_date;
    }

    public function setValueDate(DateTimeImmutable $value_date): void
    {
        $this->value_date = $value_date->format(Model_ORM::DATE_ONLY_SQL);
    }

    /**
     * The date on which the money was removed from the offset account
     *
     * Returns DateTimeObject with time set to midnight in BankAccount timezone.
     * Always Europe/Amsterdam at time of writing.
     */
    public function getCustomerDate(): ?DateTimeImmutable
    {
        return DateTimeImmutable::createFromFormat('!' . Model_ORM::DATE_SQL, $this->customer_date, TimeZones::amsterdam()) ?: null;
    }

    public function setCustomerDate(DateTimeImmutable $customer_date): void
    {
        $this->customer_date = $customer_date->setTimezone(TimeZones::amsterdam())->format(Model_ORM::DATE_SQL);
    }

    /**
     * Whether the transaction was added to the bank account.
     */
    public function isCredited(): bool
    {
        return $this->getAmount()->isPositive();
    }

    /**
     * Whether the transaction was deducted from the bank account.
     */
    public function isDebited(): bool
    {
        return !$this->isCredited();
    }

    public function isHandled(): bool
    {
        return count($this->registrations(['handled' => true])) > 0;
    }

    /**
     * @codeCoverageIgnore ugly, but needed as separate function for tests. can be cleaned up with doctrine migration
     *
     * @internal
     */
    protected function createTransactionRegistrationModel(): Model_TransactionRegistration
    {
        return new Model_TransactionRegistration($this->_db);
    }

    /**
     * Update the transaction, set it to tag unknown. Also create a transaction registration on this transaction.
     *
     * @param string $registration_type One of the Model_TransactionRegistration::REGISTRATION_* constants.
     */
    public function recordUnknown(array $tags, string $registration_type): ?Model_TransactionRegistration
    {
        $this->setTags($tags);
        $this->saveOrDie();

        if (!$this->getAmount()->isPositive()) {
            return null;
        }

        $registration = $this->createTransactionRegistrationModel();
        $registration->forTransaction($this, $registration_type);
        $registration->saveOrDie();

        return $registration;
    }

    /**
     * @return self[]
     */
    public function getInnermostChildTransactions(): Model_Set
    {
        $child_transactions = new Model_Set();

        foreach ($this->getChildTransactions() as $child_transaction) {
            if ($child_transaction->countChildTransactions() === 0) {
                $child_transactions->append($child_transaction);
            } else {
                $child_transactions->merge($child_transaction->getInnermostChildTransactions());
            }
        }

        return $child_transactions;
    }

    /**
     * @return self[]
     */
    public function getInnermostTransactions(): Model_Set
    {
        /**
         * SEPA transactions should not be expanded.
         */
        if ($this->isSepaTransaction()) {
            return new Model_Set([$this]);
        }

        $inner_children = $this->getInnermostChildTransactions();

        return $inner_children->count() === 0 ? new Model_Set([$this]) : $inner_children;
    }

    protected function setLedgerTransactionFlag(bool $isLedgerTransaction): void
    {
        $this->handled_by_ledger = $isLedgerTransaction ? '1' : '0';
    }

    public function setAsLedgerTransaction(): void
    {
        $this->setLedgerTransactionFlag(true);
    }

    public function setAsNonLedgerTransaction(): void
    {
        $this->setLedgerTransactionFlag(false);
    }

    public function isLedgerTransaction(): bool
    {
        return $this->handled_by_ledger === '1' || $this->isSepaRefundBatchForLedgerBoardedMerchants();
    }

    private function isSepaRefundBatchForLedgerBoardedMerchants(): bool
    {
        if (!$this->isSepaBatch()) {
            return false;
        }

        if ($this->getAmount()->isPositive()) {
            return false;
        }

        $total_child_count             = $this->countChildTransactions();
        $handled_by_ledger_child_count = $this->countChildTransactionsHandledByLedger();

        if ($total_child_count === 0) {
            return false;
        }

        if ($handled_by_ledger_child_count === 0) {
            return false;
        }

        if ($handled_by_ledger_child_count === $total_child_count) {
            return true;
        }

        if ($this->getCreatedAtUtc() < new DateTimeImmutable('2019-03-13 12:00:00')) {
            /*
             * This is a batch from before we started creating separate refund batches for ledger-boarded merchants
             * and legacy merchants. Don't throw for this so that regular processing/viewing of this batch can continue.
             */
            return false;
        }

        throw new DomainException(
            sprintf(
                "Cannot determine whether SEPA refund batch (transaction #%s) is for ledger-boarded merchants or" .
                " legacy merchants, as the batch contains a mix of refunds for ledger-boarded merchants (%sx) and" .
                " refunds for legacy merchants (%sx).",
                $this->getPrimaryKey(),
                $handled_by_ledger_child_count,
                $total_child_count - $handled_by_ledger_child_count
            )
        );
    }

    public function getCreatedAtUtc(): DateTimeImmutable
    {
        if ($this->created_at_utc === null) {
            throw new LogicException('Can\'t request created-at date if the object has not been loaded from the database.');
        }

        return DateTimeImmutable::createFromFormat('!' . Model_ORM::DATE_SQL, $this->created_at_utc, TimeZones::UTC());
    }

    public function getUpdatedAtUtc(): DateTimeImmutable
    {
        if ($this->updated_at_utc === null) {
            throw new LogicException('Can\'t request updated-at date if the object has not been loaded from the database.');
        }

        return DateTimeImmutable::createFromFormat('!' . Model_ORM::DATE_SQL, $this->updated_at_utc, TimeZones::UTC());
    }

    public function getBankAccountId(): int
    {
        return (int)$this->bankaccount_id;
    }

    public function getBankAccount(): BankAccount
    {
        return BankAccountRepository::getInstance()->getById($this->getBankAccountId());
    }

    public function setBankAccount(BankAccount $bank_account): void
    {
        $this->bankaccount_id = $bank_account::getId();
    }

    private function countChildTransactionsHandledByLedger()
    {
        return (int)$this->_db->sql_fetchone($this->_db->sql_build_safe_query(
            'SELECT COUNT(1) FROM bank_transactions WHERE parent_id = ^1 AND handled_by_ledger = 1',
            [$this->getPrimaryKey()]
        ));
    }

    public function setSupplierTransactionId($supplier_id): void
    {
        $this->addTagData(['transaction_id' => $supplier_id]);
    }

    public function getSupplierTransactionId(): ?string
    {
        $tag_data = $this->getTagData();

        if (!$tag_data || empty($tag_data['transaction_id'])) {
            return null;
        }

        return (string)$tag_data['transaction_id'];
    }

    public function getJournal(): Journal
    {
        return Journal::fromBankAccountId($this->getBankAccountId());
    }
}
