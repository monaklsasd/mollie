<?php

use BankAccounts\BankAccount;
use BankAccounts\BankAccountRepository;
use Core\Time\Clock;
use Core\Time\TimeZones;
use Helper\DateTime\Utc;
use Money\Currency;
use Money\Money;
use Webmozart\Assert\Assert;
use function Core\Money\money_from_string;
use function Core\Money\money_to_string;

/**
 * Model for bank_statements
 *
 * @property int    $id                  Id (maps to `bank_statement_imports`.`id`, which is a INT(10) UNSIGNED)
 * @property int    $bankaccount_id      Bankaccount_id (maps to `bank_statement_imports`.`bankaccount_id`, which is a INT(10) UNSIGNED)
 * @property int    $statement_number    Statement_number (maps to `bank_statement_imports`.`statement_number`, which is a INT(11))
 * @property string $statement_date      Statement_date (maps to `bank_statement_imports`.`statement_date`, which is a DATE)
 * @property string $statement_reference Statement_reference (maps to `bank_statement_imports`.`statement_reference`, which is a VARCHAR(50))
 * @property string $file_path           file_path (maps to `bank_statement_imports`.`file_path`, which is a varchar(255))
 * @property int    $sequence_number     Sequence_number (maps to `bank_statement_imports`.`sequence_number`, which is a INT(11))
 * @property string $accountview_status  Accountview_status (maps to `bank_statement_imports`.`accountview_status`, which is a ENUM('NEW','QUEUED','ERROR','EXPORTED','SKIPPED'))
 * @property string $opening_balance     Opening_balance (maps to `bank_statement_imports`.`opening_balance`, which is a DECIMAL(10,2))
 * @property string $closing_balance     Closing_balance (maps to `bank_statement_imports`.`closing_balance`, which is a DECIMAL(10,2))
 * @property string $created_at_utc      Maps to bank_statement_imports.created_at_utc, datetime
 * @property string $updated_at_utc      Maps to bank_statement_imports.updated_at_utc, datetime
 * @property string $finalized_at_utc    States when statement was finalized (if at all) and that it is not provisional anymore
 *
 * @method Model_Banktransaction[]|Model_Set transactions() transactions(array $where_fields = null, $options = NULL, array $config = [])
 */
class Model_Bankstatement extends Model_ORM
{
    use Utc;

    /** winfield, and is not ready to be exported. */
    public const ACCOUNTVIEW_STATUS_NEW = "new";

    /** winfield. */
    public const ACCOUNTVIEW_STATUS_READY = "ready";

    /** For this statement, an AccountView_Model_Queue object has been created and stored. */
    public const ACCOUNTVIEW_STATUS_QUEUED = "queued";

    /** This statement has been sent to AccountView, but unfortunately something went wrong. */
    public const ACCOUNTVIEW_STATUS_ERROR = "error";

    /** This statement has been sent to AccountView and all was well. */
    public const ACCOUNTVIEW_STATUS_EXPORTED = "exported";

    /** This statement will not be sent to AccountView, most likely because it did not have any transactions. */
    public const ACCOUNTVIEW_STATUS_SKIPPED = "skipped";

    protected $_model_name    = __CLASS__;
    protected $_table_name    = 'bank_statement_imports';
    protected $_table_columns = [
        'id',
        'bankaccount_id',
        'statement_number',
        'statement_date',
        'statement_reference',
        'file_path',
        'sequence_number',
        'accountview_status',
        'opening_balance',
        'closing_balance',
        'created_at_utc',
        'updated_at_utc',
        'finalized_at_utc',
    ];

    protected $_relationships = [
        'transactions' => [
            'type'  => Model_ORM::HAS_MANY,
            'model' => 'Model_Banktransaction',
        ],
    ];

    public static function getAccountViewStatuses(): array
    {
        return [
            self::ACCOUNTVIEW_STATUS_NEW,
            self::ACCOUNTVIEW_STATUS_READY,
            self::ACCOUNTVIEW_STATUS_QUEUED,
            self::ACCOUNTVIEW_STATUS_ERROR,
            self::ACCOUNTVIEW_STATUS_EXPORTED,
            self::ACCOUNTVIEW_STATUS_SKIPPED,
        ];
    }

    public function getStatementDate(): DateTimeImmutable
    {
        return self::toDateTime($this->statement_date, '!Y-m-d');
    }

    public function setStatementDate(DateTimeImmutable $statement_date): void
    {
        $this->statement_date = $statement_date->format('Y-m-d');
    }

    public function getStatementNumber(): int
    {
        return (int)$this->statement_number;
    }

    public function setStatementNumber(int $statement_number): void
    {
        $this->statement_number = $statement_number;
    }

    public function getSequenceNumber(): int
    {
        return (int)$this->sequence_number;
    }

    public function setSequenceNumber(int $sequence_number): void
    {
        $this->sequence_number = $sequence_number;
    }

    public function getStatementReference(): string
    {
        return $this->statement_reference;
    }

    public function setStatementReference(string $statement_reference): void
    {
        $this->statement_reference = $statement_reference;
    }

    public function getCurrency(): Currency
    {
        return $this->getBankAccount()::getCurrency();
    }

    public function getOpeningBalance(): Money
    {
        return money_from_string((string)$this->opening_balance, $this->getCurrency());
    }

    public function setOpeningBalance(Money $amount): void
    {
        $this->assertCorrectCurrency($amount->getCurrency());
        $this->opening_balance = money_to_string($amount);
    }

    public function getClosingBalance(): Money
    {
        return money_from_string((string)$this->closing_balance, $this->getCurrency());
    }

    public function setClosingBalance(Money $amount): void
    {
        $this->assertCorrectCurrency($amount->getCurrency());
        $this->closing_balance = money_to_string($amount);
    }

    public function getMutationAmount(): Money
    {
        return $this->getClosingBalance()->subtract($this->getOpeningBalance());
    }

    public function getBankAccountId(): int
    {
        return (int)$this->bankaccount_id;
    }

    public function setBankAccount(BankAccount $bank_account): void
    {
        $this->bankaccount_id = $bank_account::getId();
    }

    public function getBankAccount(): BankAccount
    {
        return BankAccountRepository::getInstance()->getById($this->getBankAccountId());
    }

    public function getAccountviewStatus(): string
    {
        return empty($this->accountview_status) ? self::ACCOUNTVIEW_STATUS_NEW : (string)$this->accountview_status;
    }

    public function setAccountviewStatus(string $accountview_status): void
    {
        if (!in_array($accountview_status, self::getAccountViewStatuses(), true)) {
            throw new InvalidArgumentException(sprintf(
                'Trying to set invalid accountview export status "%s" for statement #%d, should be one of: %s.',
                $accountview_status,
                $this->getPrimaryKey(),
                implode(', ', self::getAccountViewStatuses())
            ));
        }

        $this->accountview_status = $accountview_status;
    }

    public function getCreatedAtUtc(): DateTimeImmutable
    {
        if ($this->created_at_utc === null) {
            throw new LogicException('Can\'t request created-at date if the object has not been loaded from the database.');
        }

        return DateTimeImmutable::createFromFormat('!' . Model_ORM::DATE_SQL, $this->created_at_utc, TimeZones::UTC());
    }

    public function getUpdatedAtUtc(): DateTimeImmutable
    {
        if ($this->updated_at_utc === null) {
            throw new LogicException('Can\'t request updated-at date if the object has not been loaded from the database.');
        }

        return DateTimeImmutable::createFromFormat('!' . Model_ORM::DATE_SQL, $this->updated_at_utc, TimeZones::UTC());
    }

    /**
     * Verify that the bank account was not imported yet.
     *
     * @todo Fix that it only works for bankaccounts imported this year.
     *
     * @param $account_id int
     * @param $statement_number int
     * @param $sequence_number int
     *
     * @return bool
     */
    public function verifyNotImportedYet($account_id, $reference, $statement_number, $sequence_number)
    {
        $r_imported = $this->_db->sql_safe_query(
            "SELECT COUNT(1) AS number FROM {$this->_table_name} WHERE bankaccount_id = ^1 AND YEAR(statement_date) = YEAR(CONVERT_TZ(UTC_TIMESTAMP, 'UTC', 'Europe/Amsterdam')) AND statement_reference = $2 AND statement_number = $3 AND sequence_number = $4",
            $account_id,
            $reference,
            $statement_number,
            $sequence_number
        );

        $row = $this->_db->sql_fetchrow($r_imported);

        return $row && $row['number'] == 0;
    }

    private function assertCorrectCurrency(Currency $currency): void
    {
        if (!$currency->equals($this->getCurrency())) {
            throw new LogicException(sprintf(
                'Cannot set opening balance as %s for %s bank account (#%d).',
                $currency->getCode(),
                $this->getCurrency(),
                $this->getBankAccountId()
            ));
        }
    }

    public function getFilePath(): string
    {
        return $this->file_path;
    }

    public function setFilePath(string $file_path): void
    {
        $this->file_path = $file_path;
    }

    /**
     * For old statements the file path is not set, make sure you have a path before using it.
     */
    public function hasFilePath(): bool
    {
        return $this->file_path !== null;
    }

    public function isFinalized(): bool
    {
        return $this->finalized_at_utc !== null;
    }

    public function markAsFinalized(): void
    {
        Assert::isEmpty($this->finalized_at_utc, "Statement is already finalized at: " . $this->finalized_at_utc);

        $this->finalized_at_utc = Clock::getFormattedUtcDate(self::DATE_SQL);
    }
}
