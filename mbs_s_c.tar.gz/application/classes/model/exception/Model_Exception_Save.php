<?php

/**
 * Thrown by Model_Base when it failed to persist its changes.
 */
class Model_Exception_Save extends Model_Exception
{
}
