<?php

class Model_Exception_UnknownColumn extends Model_Exception
{
}
