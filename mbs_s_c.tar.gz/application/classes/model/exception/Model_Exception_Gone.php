<?php

/**
 * Throw this exception if the model you wanted to operate is suddenly gone, e.g. after a reload() call.
 *
 * @see Model_Base::reloadOrDie()
 */
class Model_Exception_Gone extends Model_Exception
{
}
