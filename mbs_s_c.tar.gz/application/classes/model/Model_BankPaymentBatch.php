<?php

use App\Crypto\BatchSigningKeyTag;
use App\Entity\User;
use App\Logger\LogCategory;
use BankAccounts\BankAccount;
use BankAccounts\BankAccountRepository;
use Core\Localization\Localizer;
use Core\Money\Currencies;
use Core\Time\Clock;
use Core\Time\TimeZones;
use Mollie\BankingFiles\Batch\BatchFile;
use Mollie\BankingFiles\Batch\ReaderBase;
use Mollie\BankingFiles\Batch\ReaderFactory;
use Mollie\BankingFiles\Batch\TransactionBatch;
use Money\Currency;
use Money\Money;
use Psr\Log\LoggerInterface;
use function Core\Money\money_from_string;
use function Core\Money\money_to_string;

/**
 * @property int                        $id               Maps to bank_payment_batches.id, int(10) unsigned
 * @property string|null                $type             Maps to bank_payment_batches.type, varchar(20)
 * @property string                     $currency         Maps to bank_payment_batches.currency, char(3)
 * @property int|null                   $created_by       Maps to bank_payment_batches.created_by, int(10) unsigned
 * @property string|null                $description      Maps to bank_payment_batches.description, varchar(255)
 * @property string|null                $contents         Maps to bank_payment_batches.contents, longtext
 * @property string|null                $contents_md5     Maps to bank_payment_batches.contents_md5, char(32)
 * @property string|null                $result_contents  Maps to bank_payment_batches.result_contents, text
 * @property int|null                   $num_transactions Maps to bank_payment_batches.num_transactions, int(10) unsigned
 * @property float|null                 $total_amount     Maps to bank_payment_batches.total_amount, decimal(10,2)
 * @property string                     $created_at       Maps to bank_payment_batches.created_at, datetime
 * @property string|null                $updated_at       Maps to bank_payment_batches.updated_at, datetime
 * @property int|null                   $completed        Maps to bank_payment_batches.completed, tinyint(1)
 * @property int|null                   $amount_warning   Maps to bank_payment_batches.amount_warning, tinyint(1)
 * @property int|null                   $transaction_id   Maps to bank_payment_batches.transaction_id, bigint(20)
 * @property string|null                $reference        Maps to bank_payment_batches.reference, varchar(50)
 * @property string|null                $reset_at         Maps to bank_payment_batches.reset_at, datetime
 * @property string|null                $submitted_at     Maps to bank_payment_batches.submitted_at, datetime
 * @property Model_Banktransaction|null $transaction      This batch as a transaction on our bankaccount.
 *
 * @method Model_BankPaymentBatchHistoryEntry[]|Model_Set history_entries()     history_entries(array $where_fields = NULL, $options = NULL, array $config = [])
 * @method int                                            countHistoryEntries() countHistoryEntries(array $where_fields = NULL, $options = NULL, array $config = [])
 */
class Model_BankPaymentBatch extends Model_ORM
{
    /** @deprecated Use \Mollie\BankingFiles\Batch\BatchFile::TYPE_CLIEOP instead. */
    public const BATCH_TYPE_CLIEOP03 = 'CLIEOP03';
    /** @deprecated Use \Mollie\BankingFiles\Batch\BatchFile::TYPE_PAIN001 instead. Note that the value of this new constant is different. */
    public const BATCH_TYPE_PAIN001 = 'SEPA';
    /** @deprecated Use \Mollie\BankingFiles\Batch\BatchFile::TYPE_PAIN008 instead. */
    public const BATCH_TYPE_PAIN008 = 'PAIN.008';

    public const PENDING             = 0;
    public const SENT_TO_BANK        = 1; // The upload process has completed successfully
    public const COMPLETED_PARTIALLY = 2;
    public const COMPLETED           = 3;
    public const FAILED              = 4;
    public const FAILED_NOREPLY      = 5;
    public const ABORTED             = 6;
    public const SENDING_TO_BANK     = 7; // The upload process has started
    public const RECONCILED          = 8; // Reported back to us in bank statement

    public const RESPONSE_THRESHOLD = 15;
    public const SYSTEM_USER        = 0;

    protected const AMOUNT_WARNING_THRESHOLD = [
        Currencies::EURO         => 1000000, // 10.000,00
        Currencies::POLISH_ZLOTY => 4000000, // 40.000,00
    ];

    /** @var string model classname */
    protected $_model_name    = __CLASS__;
    protected $_table_name    = 'bank_payment_batches';
    protected $_table_columns = [
        'id',
        'type',
        'currency',
        'created_by',
        'description',
        'contents',
        'contents_md5',
        'result_contents',
        'num_transactions',
        'total_amount',
        'created_at',
        'updated_at',
        'completed',
        'transaction_id',
        'amount_warning',
        'reference',
        'reset_at',
        'submitted_at',
    ];

    protected $_relationships = [
        'history_entries' => [
            'type'        => Model_ORM::HAS_MANY,
            'model'       => Model_BankPaymentBatchHistoryEntry::class,
            'foreign_key' => 'id',
        ],
        'transaction' => [
            'type'        => Model_ORM::BELONGS_TO,
            'model'       => Model_Banktransaction::class,
            'foreign_key' => 'transaction_id',
        ],
    ];

    protected $_validations = [
        'type'       => [true, FILTER_VALIDATE_REGEXP, 'Unknown payment type', ['regexp' => '~^(?:CLIEOP03|SEPA|PAIN\.008|PAIN\.001\.001\.03)$~']],
        'created_by' => [true, FILTER_VALIDATE_INT,    'Batch creator user id required'],
    ];

    protected $_valid_batch_content = true;

    public static function getStatusAsString(int $status): string
    {
        switch ($status) {
            case self::PENDING:
                return 'Pending';

            case self::SENDING_TO_BANK:
                return "Sending to bank";

            case self::SENT_TO_BANK:
                return 'Successfully sent to bank';

            case self::COMPLETED:
                return 'Completed';

            case self::COMPLETED_PARTIALLY:
                return 'Partially completed';

            case self::FAILED:
                return 'Failed';

            case self::FAILED_NOREPLY:
                return 'Failed (no reply)';

            case self::ABORTED:
                return 'Aborted';

            case self::RECONCILED:
                return 'Reconciled';

            default:
                return '[Unknown]';
        }
    }

    public function initFromBatchFile(BatchFile $batch_file, LoggerInterface $logger)
    {
        $batch_reader_factory = new ReaderFactory();
        $batch_reader         = $batch_reader_factory->createReaderFromFile($batch_file);

        return $this->initFromTypeAndContents($batch_reader, $batch_file->type, $batch_file->contents, $logger);
    }

    public function initFromTypeAndContents(ReaderBase $batch_reader, $type, $contents, LoggerInterface $logger)
    {
        if ($batch_reader->isValid() === true) {
            if ($type === BatchFile::TYPE_PAIN001) {
                $type = static::BATCH_TYPE_PAIN001; // Model stores "PAIN.001" type as "SEPA" legacy type.
            }

            parent::__set('type', $type);
            parent::__set('currency', $batch_reader->getCurrency()->getCode());
            parent::__set('contents', $contents);
            parent::__set('contents_md5', md5($contents));
            parent::__set('num_transactions', $batch_reader->getTransactionCount());
            parent::__set('total_amount', money_to_string($batch_reader->getTotalTransactionsAmount()));

            $higher_transaction_amount = $batch_reader->getHighestTransactionAmount();

            if ($higher_transaction_amount->greaterThan($this->getWarningThresholdAmount())) {
                $logger->info(
                    sprintf(
                        "High amount detected %s > %s",
                        Localizer::formatMoney($batch_reader->getHighestTransactionAmount()),
                        Localizer::formatMoney($this->getWarningThresholdAmount())
                    ),
                    [
                        'category' => LogCategory::IMPORTS(),
                    ]
                );

                parent::__set('amount_warning', true);
            }

            $this->_valid_batch_content = true;

            return true;
        }

        $this->_valid_batch_content = $batch_reader->getLastError();

        return false;
    }

    public function getBankAccount(): BankAccount
    {
        /** @var TransactionBatch $transactionBatch */
        foreach ($this->getReader()->getBatches() as $transactionBatch) {
            /*
             * Check both the debitor and creditor account numbers:
             *
             *  - In the case of a SCT the debitor account will be set.
             *  - In the case of a SDD the creditor account will be set.
             */
            $iban = $transactionBatch->getDebitorAccount() ?? $transactionBatch->getCreditorAccount();

            if ($iban === null) {
                continue;
            }

            return BankAccountRepository::getInstance()->getByIbanOrAccountNumber($iban);
        }

        throw new RuntimeException(sprintf(
            'Cannot determine bank account for batch %d',
            $this->getPrimaryKey()
        ));
    }

    public function getCurrency(): Currency
    {
        return new Currency($this->currency);
    }

    public function getTotalAmount(): Money
    {
        return money_from_string((string)$this->total_amount, $this->getCurrency());
    }

    public function getWarningThresholdAmount(): Money
    {
        return new Money(
            Model_BankPaymentBatch::AMOUNT_WARNING_THRESHOLD[$this->getCurrency()->getCode()],
            $this->getCurrency()
        );
    }

    public function getCreatedAt(): DateTimeImmutable
    {
        return DateTimeImmutable::createFromFormat('!' . Model_ORM::DATE_SQL, $this->created_at, TimeZones::amsterdam());
    }

    public function getReader(): ReaderBase
    {
        /**
         * We no longer support dates of signature from before 1900. However, some older batches still have contents
         * with signature dates of the year '-0001-11-30'. These older batches are used when expanding a batch
         * transaction in smaller transactions. Replace these signature dates temporarily with something more sane. This
         * code can be removed once we received all batches with invalid dates (in a week or so).
         */
        $contents = $this->contents;

        if ($this->created_at !== null && $this->getCreatedAt()->format('Ym') <= 201701) {
            $contents = str_replace('-0001-11-30', '2000-01-01', $contents);
        }

        return (new ReaderFactory())->createReaderFromType($this->type, $contents);
    }

    public function __set(string $name, $value): void
    {
        switch (strtolower($name)) {
            case 'type':
            case 'num_transactions':
            case 'total_amount':
            case 'contents':
                throw new Model_Exception("Use initFromTypeAndContents or initFromBatchFile to set the '{$name}' field");
        }

        parent::__set($name, $value);
    }

    /**
     * Create a unique reference for the batch, and then saves the batch.
     */
    public function createReference(): void
    {
        if (!empty($this->reference)) {
            // We already have a reference.
            return;
        }

        $this->reference = 'MOLLIE.' . $this->type . '.' . $this->id;

        $sepa_types = [
            BatchFile::TYPE_LEGACY_SEPA,
            BatchFile::TYPE_PAIN008,
            BatchFile::TYPE_PAIN001_V03,
        ];

        if (in_array($this->type, $sepa_types, true)) {
            $doc               = new DOMDocument();
            $doc->formatOutput = false;
            $doc->loadXML($this->contents);
            $doc->getElementsByTagName("MsgId")->item(0)->nodeValue = $this->reference;

            parent::__set("contents", $doc->saveXML());
        }

        $this->saveOrDie();
    }

    /**
     * Get the filename for this batch.
     */
    public function getFilename(): string
    {
        return sprintf(
            "%s-batch-%s.%s",
            strtolower($this->type),
            $this->getPrimaryKey(),
            ($this->type == Model_BankPaymentBatch::BATCH_TYPE_CLIEOP03) ? "txt" : "xml"
        );
    }

    /**
     * Has this batch been sent to the bank? Returns true if the batch was was sent to the bank successfully.
     */
    public function isSentToBank(): bool
    {
        return $this->matchesStatus(self::SENT_TO_BANK) || $this->hasBankResponse();
    }

    /**
     * If there has been an attempt to upload this batch to the bank (regardless of whether it failed or succeeded)
     * this method returns true.
     */
    public function anAttemptWasMadeToSendToBank(): bool
    {
        if ($this->matchesStatus(self::SENDING_TO_BANK, self::SENT_TO_BANK)) {
            return true;
        }

        if ($this->hasBankResponse()) {
            return true;
        }

        return false;
    }

    /**
     * Has the bank given us a response on the status of the batch? Might be completed or partially completed or even
     * failed.
     */
    public function hasBankResponse(): bool
    {
        return $this->matchesStatus(self::COMPLETED, self::COMPLETED_PARTIALLY, self::FAILED);
    }

    public function validate(): bool
    {
        if ($this->_valid_batch_content !== true) {
            $this->setValidationError('contents', $this->_valid_batch_content);

            return false;
        }

        if (!parent::validate()) {
            return false;
        }

        return true;
    }

    protected function _save($force = false)
    {
        return parent::save($force);
    }

    public function save($force = false)
    {
        if (isset($this->_object_changes['completed'])) {
            throw new Model_Exception("Cannot save batch status directly. Use updateToStatus method.");
        }

        return $this->_save($force);
    }

    public function statusAsString(): string
    {
        return self::getStatusAsString($this->completed);
    }

    public function wasSubmitted(): bool
    {
        return !$this->matchesStatus(self::PENDING);
    }

    /**
     * A batch may only be executed if it is in the PENDING state
     */
    public function mayBeExecuted(): bool
    {
        return $this->matchesStatus(self::PENDING);
    }

    /**
     * A batch may only be reset if: it hasn't been reset before and if it's just
     * been sent to the bank or has been marked as a failed payment (due to no-reply from the bank)
     */
    public function mayBeReset(): bool
    {
        if (!$this->matchesStatus(self::SENT_TO_BANK, self::FAILED_NOREPLY)) {
            return false;
        }

        if ($this->wasReset()) {
            return false;
        }

        return true;
    }

    /**
     * A batch may only be aborted if it hasn't been marked as complete
     */
    public function mayBeAborted(): bool
    {
        return $this->matchesStatus(self::PENDING);
    }

    public function wasReset(): bool
    {
        return $this->reset_at !== null;
    }

    public function markAsSending(User $user, BatchSigningKeyTag $tag): void
    {
        $this->updateToStatus(self::SENDING_TO_BANK, $user);
        $this->storeHistoryEntry(sprintf(
            "Payment batch will be sent to bank '%s' with reference: '%s'.",
            $tag->getValue(),
            $this->reference
        ), $user);
    }

    public function markAsSent(User $user, BatchSigningKeyTag $tag): void
    {
        $this->submitted_at = Clock::getFormattedDate(Model_ORM::DATE_SQL);
        $this->updateToStatus(self::SENT_TO_BANK, $user);
        $this->storeHistoryEntry(sprintf(
            "Payment batch has been sent to bank '%s' with reference: '%s'.",
            $tag->getValue(),
            $this->reference
        ), $user);
    }

    public function markAsReconciled(Model_Banktransaction $transaction): void
    {
        $this->storeHistoryEntry(sprintf('Reconciled in transaction #%d.', $transaction->getPrimaryKey()));
        $this->updateToStatus(Model_BankPaymentBatch::RECONCILED);
        $this->transaction = $transaction;
        $this->saveOrDie();
    }

    /**
     * Try and update this batch to a certain state. Different states have different rules about whether
     * the status may be updated.
     */
    public function updateToStatus(int $status, ?User $user = null): bool
    {
        // Only work on existing records
        if (!$this->stored()) {
            return false;
        }

        switch ($status) {
            case self::PENDING:
                if (!$this->mayBeReset()) {
                    return false;
                }

                $this->submitted_at = null;
                $this->reference    = null;
                $this->reset_at     = Clock::getFormattedDate(Model_ORM::DATE_SQL);

                break;

            case self::SENDING_TO_BANK:
                if (!$this->matchesStatus(self::PENDING)) {
                    return false;
                }

                break;

            case self::SENT_TO_BANK:
                if (!$this->matchesStatus(self::SENDING_TO_BANK)) {
                    return false;
                }

                break;

            case self::COMPLETED:
                if (!$this->matchesStatus(self::PENDING, self::SENT_TO_BANK)) {
                    return false;
                }

                break;

            case self::COMPLETED_PARTIALLY:
                if (!$this->matchesStatus(self::PENDING, self::SENDING_TO_BANK, self::SENT_TO_BANK, self::COMPLETED)) {
                    return false;
                }

                break;

            case self::RECONCILED:
                if (!$this->matchesStatus(self::COMPLETED, self::COMPLETED_PARTIALLY)) {
                    return false;
                }

                break;

            case self::FAILED:
                if (!$this->matchesStatus(self::PENDING, self::SENDING_TO_BANK, self::SENT_TO_BANK)) {
                    return false;
                }

                break;

            case self::FAILED_NOREPLY:
                if (!$this->matchesStatus(self::PENDING, self::SENDING_TO_BANK, self::SENT_TO_BANK)) {
                    return false;
                }

                /*
                 * Probably a connection error. Allow to be retried multiple times.
                 */
                $this->reset_at = null;

                break;

            case self::ABORTED:
                if (!$this->mayBeAborted()) {
                    return false;
                }

                break;

            default:
                throw new InvalidArgumentException("Unknown status");
        }

        $this->completed = $status;
        $this->storeHistoryEntry("Status of payment batch changed to: '{$this->statusAsString()}'", $user);

        return $this->_save();
    }

    public function matchesStatus(int ...$statuses): bool
    {
        return in_array($this->getStatus(), $statuses, true);
    }

    public function getStatus(): int
    {
        return (int)$this->completed;
    }

    /**
     * Mark batches that have been sent to the bank longer than 15 minutes ago
     */
    public function markExpiredBatches()
    {
        $items = $this->findAllSql(
            "SELECT * FROM bank_payment_batches " .
            " WHERE completed = " . self::SENT_TO_BANK . " AND updated_at < DATE_SUB(CONVERT_TZ(UTC_TIMESTAMP, 'UTC', 'Europe/Amsterdam'), INTERVAL " . self::RESPONSE_THRESHOLD . " MINUTE)"
        );

        if (!$items) {
            return false;
        }

        foreach ($items as $item) {
            $item->completed = self::FAILED_NOREPLY;
            $item->_save();

            $item->storeHistoryEntry("The bank did not respond within " . self::RESPONSE_THRESHOLD . " minutes. Status updated.");
        }

        return true;
    }

    public function storeHistoryEntry(string $message, ?User $user = null): void
    {
        if (!$this->stored()) {
            throw new LogicException("Cannot create history item for unsaved batch");
        }

        $item                   = new Model_BankPaymentBatchHistoryEntry($this->_db);
        $item->payment_batch_id = $this->id;
        $item->user_id          = $user !== null ? $user->getId() : null;
        $item->message          = $message;

        $item->save();
    }
}
