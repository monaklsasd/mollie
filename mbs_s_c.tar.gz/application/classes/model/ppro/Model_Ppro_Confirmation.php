<?php

/**
 * Model_Ppro_Confirmation
 *
 * ORM-model for m_ppro_confirmed_transactions table
 *
 * @property int                        $id
 * @property string                     $payment_method
 * @property string                     $record_type
 * @property int                        $type_specific_id
 * @property string                     $event_timestamp
 * @property int                        $amount                       Amount in cents.
 * @property string                     $currency
 * @property string                     $mollie_transaction_reference tr_XXXXX code.
 * @property string                     $bankaccount_name
 * @property string                     $bic
 * @property string                     $bankaccount_nr
 * @property Model_Ppro_Processing_File $file
 */
class Model_Ppro_Confirmation extends Model_ORM
{
    protected $_model_name = __CLASS__;

    /** @var string */
    protected $_table_name = 'm_ppro_confirmed_transactions';

    /** @var array */
    protected $_table_columns = [
        'id',
        'processing_file_id',
        'payment_method',
        'record_type',
        'type_specific_id',
        'event_timestamp',
        'amount',
        'currency',
        'mollie_transaction_reference',
        'bankaccount_name',
        'bic',
        'bankaccount_nr',
    ];

    protected $_relationships = [
        'file' => [
            'type'        => \Model_ORM::BELONGS_TO,
            'model'       => \Model_Ppro_Processing_File::class,
            'foreign_key' => 'processing_file_id',
        ],
    ];
}
