<?php

use Core\Time\Clock;

/**
 * Model_Ppro_Processing_File
 *
 * ORM-model for m_ppro_processing_files table
 *
 * @property int    $id         Maps to m_ppro_processing_files.id, int(11) unsigned
 * @property string $filename   Maps to m_ppro_processing_files.filename, varchar(255)
 * @property string $contents   Maps to m_ppro_processing_files.contents, longtext
 * @property string $entry_date Maps to m_ppro_processing_files.entry_date, date
 * @property string $created_at Maps to m_ppro_processing_files.created_at, datetime
 */
class Model_Ppro_Processing_File extends Model_ORM
{
    protected $_model_name = __CLASS__;

    /** @var string */
    protected $_table_name = 'm_ppro_processing_files';

    /** @var array */
    protected $_table_columns = [
        'id',
        'filename',
        'contents',
        'entry_date',
        'created_at',
        'parsed_at',
    ];

    public function markAsParsed(): void
    {
        $this->parsed_at = Clock::getFormattedUtcDate(static::DATE_SQL);
    }
}
