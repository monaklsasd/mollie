<?php

use Core\Strings;
use Orm\ModelFactory;

/**
 * Een baseclass voor ORM-modellen (met relaties)
 *
 * @author Rick Wong <wong@mollie.nl>
 * @author Mathieu Kooiman <mathieu@mollie.nl>
 * @copyright Copyright (C) 2010, Mollie B.V.
 *
 * @SuppressWarnings(PHPMD.NumberOfChildren)
 */
abstract class Model_ORM extends Model_Base
{
    public const HAS_ONE      = 1;
    public const HAS_MANY     = 2;
    public const BELONGS_TO   = 3;
    protected $_relationships = []; // array('accessor' => array('type'        => self::HAS_ONE,
    //                           'model'       => 'Model_Name',
    //                          ['foreign_key' => 'foreign_key_name']); // alleen bij BELONGS_TO
    protected $_includes = [];

    /** @var Model_ORM[]|Model_ORM[][]|Model_Set[]|null[] */
    protected $_relations = [];

    /**
     * @deprecated Use DI! If unavailable, use CrappyStaticDi::getInstance()
     *
     * @codeCoverageIgnore
     */
    public function getModelFactory(): ModelFactory
    {
        return new ModelFactory($this->_db);
    }

    public function __isset(string $accessor): bool
    {
        if ($this->hasFoundRelation($accessor)) {
            return true;
        }

        return parent::__isset($accessor);
    }

    /**
     * @param $accessor
     */
    public function __unset(string $accessor): void
    {
        if ($this->hasDefinedRelation($accessor)) {
            if ($this->hasQueriedRelation($accessor)) {
                $this->unsetRelation($accessor);
            }

            return;
        }

        parent::__unset($accessor);
    }

    /**
     * Reset model by erasing all data
     */
    public function reset()
    {
        // Invalidate all relations
        $this->invalidateForeignData();

        parent::reset();
    }

    /**
     * Magic method that returns a column on the table or an instance of an related object (found by primary key)
     *
     * @param string $accessor the column or relation to return the value for
     *
     * @throws Model_Exception
     */
    public function __get(string $accessor)
    {
        if (!$this->hasDefinedRelation($accessor)) {
            return parent::__get($accessor);
        }

        if ($this->hasQueriedRelation($accessor)) {
            return $this->getRelation($accessor);
        }

        $relationship = $this->getRelationDefinition($accessor);

        if ($relationship['type'] === self::HAS_ONE) {
            if ($this->getPrimaryKey() === null) {
                return null;
            }

            /* If base_type is set in the relationship, we assume this is supposed to be a polymorphic
             * relationship. For those relationships, the concreate class implementing Model_ORM should
             * overload _determineRelationshipModel with which the class can determine which model should
             * be used to load the child. */
            if (isset($relationship['base_type'])) {
                $model_name  = $this->_determineRelationshipModel($accessor);
                $child_model = new $model_name($this->_db);

                if (!$child_model instanceof $relationship['base_type']) {
                    throw new Model_Exception("Given model should be of class {$relationship['base_type']}, but isn't");
                }
            } else {
                /** @var self $child_model */
                $child_model = new $relationship['model']($this->_db);
            }

            $where = $child_model->getForeignKeyName($this) . ' = ' . $this->getPrimaryKey();

            $where_fields = $relationship['where'] ?? null;

            if (is_array($where_fields)) {
                $where .= ' AND ' . implode(' AND ', $this->_db->sql_columns_from_array_for_where($where_fields));
            } elseif (is_string($where_fields)) {
                $where .= ' AND ' . $where_fields;
            }

            /** @var self $child */
            $child = $child_model->findAll($where, 1)->first();

            // Set the found object preemptively, since $child->$accessor = $this will cause another $this->$accessor = $child.
            $this->setRelation($accessor, $child);

            if ($child && $child instanceof self) {
                $backward_accessor = $child->getAccessorFor(self::BELONGS_TO, $this);

                if (!empty($backward_accessor)) {
                    $child->setRelation($backward_accessor, $this);
                }
            }

            return $child;
        }

        if ($relationship['type'] === self::BELONGS_TO) {
            if (empty($this->{$relationship['foreign_key']})) {
                return null;
            }

            /** @var self $parent */
            $parent = new $relationship['model']($this->_db);

            if (!$parent->load($this->{$relationship['foreign_key']})) {
                return null;
            }

            // Set the found object preemptively, since $parent->$accessor = $this will cause another $this->$accessor = $parent.
            $this->setRelation($accessor, $parent);

            if ($parent && $parent instanceof self) {
                $backward_accessor = $parent->getAccessorFor(self::HAS_ONE, $this);

                if (!empty($backward_accessor)) {
                    $parent->setRelation($backward_accessor, $this);
                }
            }

            return $parent;
        }

        throw new Model_Exception("Cannot get {$accessor} as variable, try calling it as a method().");
    }

    /**
     * Used to implement support for polymorphic relationships: for instance, a payment may have various payment detail objects
     * linked to it (iDEAL payments, Creditcard payments, etc).
     *
     * @param string $accessor the accessor to determine the proper model class for
     *
     * @throws Model_Exception
     *
     * @return string classname
     */
    protected function _determineRelationshipModel($accessor)
    {
        throw new Model_Exception("Implement _determineRelationshipModel in '" . get_class($this) . "' if you have a polymorphic relationship");
    }

    /**
     * Magic method to set a column on the current object. The value may be a simple scalar but also an instance of a different ORM object:
     *
     * @param string $accessor The column or relationship to change the value of.
     * @param mixed  $value    Value to set the column or relationship to.
     *
     * @throws Model_Exception
     *
     * Sample usage:
     *   $customer = new Model_Customer;
     *   $company  = new Model_Company($db, 1); // Mollie;
     *
     *   $customer->naam = 'Mathieu Kooiman';
     *   $customer->company = $company; // This sets the company -relationship- and will modify $customer->company_id (but the caller doesn't need to know)
     *
     * @return mixed the value set
     */
    public function __set(string $accessor, $value): void
    {
        if ($this->hasDefinedRelation($accessor)) {
            $relationship = $this->getRelationDefinition($accessor);

            /*
             * Sanity check.
             */
            if (!is_object($value) && $value !== null) {
                throw new Model_Exception("Value assigned to {$accessor} relationship should be instance of " . $relationship['model'] . " not " . gettype($value));
            }

            if ($relationship['type'] === self::HAS_ONE or $relationship['type'] === self::BELONGS_TO) {
                if ($value === null) {
                    // Explicitly set the relationship to NULL, so we don't query again next time.
                    $this->setRelation($accessor, null);

                    return;
                }

                /** @var self $value */
                if (isset($relationship['base_type']) && !($value instanceof $relationship['base_type'])) {
                    throw new Model_Exception("Cannot set {$accessor} to object of " . get_class($value) . " (should be instance of: " . $relationship['base_type'] . ")");
                }

                if (isset($relationship['model']) && !($value instanceof $relationship['model'])) {
                    throw new Model_Exception("Cannot set {$accessor} to object of {$value->getModelName()} (should be instance of: {$relationship['model']})");
                }

                if ($relationship['type'] === self::HAS_ONE) {
                    $value->setForeignKey($this);
                } elseif ($relationship['type'] === self::BELONGS_TO) {
                    if ($this->_primary_key === $relationship['foreign_key']) {
                        /*
                         * Set this directly on the object data, using setPrimaryKey() has the side effect of marking
                         * the object as stored, making it impossible to actually persist it to disk (since the object
                         * will then use UPDATE instead of INSERT).
                         */
                        $this->_object_data[$relationship['foreign_key']] = $value->getPrimaryKey();
                    } else {
                        /*
                         * Update the foreign key, make sure the changes are tracked.
                         */
                        $this->{$relationship['foreign_key']} = $value->getPrimaryKey();
                    }
                }

                // Set the relation in current object first...
                $this->setRelation($accessor, $value);

                // ...Then set the relation in the other object
                if ($value && $value instanceof self) {
                    $backward_type     = ($relationship['type'] == self::HAS_ONE ? self::BELONGS_TO : self::HAS_ONE);
                    $backward_accessor = $value->getAccessorFor($backward_type, $this);

                    if (!empty($backward_accessor) && !isset($value->{$backward_accessor})) {
                        $value->setRelation($backward_accessor, $this);
                    }
                }

                return;
            }

            $this->invalidateForeignData($accessor);
        }

        /*
         * So one of the simple columns is being changed. This could be a foreign key that references another model in
         * this object. If the model is loaded, we must invalidate it.
         */
        foreach ($this->_relationships as $relation_accessor => $relationship) {
            if ($relationship['type'] == self::HAS_ONE || $relationship['type'] == self::BELONGS_TO) {
                if (isset($relationship['foreign_key']) && $relationship['foreign_key'] == $accessor) {
                    /*
                     * Don't invalidate it if it is the same object, else you cannot set the object at all.
                     */
                    if ($this->hasFoundRelation($relation_accessor) && $this->getRelation($relation_accessor)->getPrimaryKey() != $value) {
                        $this->invalidateForeignData($relation_accessor);

                        break;
                    }
                }
            }
        }

        parent::__set($accessor, $value);
    }

    /**
     * Count how many items are in a collection for a given relation filtered on provided $where_fields and $options
     *
     * @param string     $accessor
     * @param array|null $where_fields
     * @param array|null $options
     * @param array      $config
     *
     * @throws Model_Exception
     *
     * @return int
     */
    public function relationCount($accessor, $where_fields = null, $options = null, $config = [])
    {
        if (!$this->hasDefinedRelation($accessor)) {
            throw new Model_Exception("Relationship " . get_class($this) . "::\"{$accessor}\"() is not defined!");
        }

        $relationship = $this->getRelationDefinition($accessor);

        if ($relationship['type'] !== self::HAS_MANY) {
            throw new Model_Exception("Cannot relationCount on {$accessor}, only HAS_MANY relations supported.");
        }

        if ($this->hasQueriedRelation($accessor)) {
            $relation = $this->getRelation($accessor);

            if (!$relation) {
                return 0;
            }

            return $relation->count();
        }

        if (!$this->stored()) {
            return 0;
        }

        /** @var self $child_model */
        $child_model = new $relationship['model']($this->_db);

        if (isset($relationship['query'])) {
            $query = $relationship['query'];

            // Manually replace the primary key NAME and primary key VALUE
            $query = strtr(
                $query,
                [
                    '[PK_NAME]'  => $child_model->getForeignKeyName($this),
                    '[PK_VALUE]' => $this->_db->value_to_sql_field($this->getPrimaryKey()), ]
            );

            // Rewrite query to SELECT COUNT(1) ....
            $query = self::rewriteCountQuery($query);

            $parameters = is_array($where_fields) ? $where_fields : [];

            $result = $this->_db->sql_safe_query($query, ...$parameters);
            $count  = $this->_db->sql_fetchfield(0, 0, $result);
            $this->_db->sql_freeresult($result);

            return (int)$count;
        }
        // Predefined foreign relation accessor
        if (isset($relationship['accessor'])) {
            $foreign_key_name = $child_model->getForeignKeyName($this, $relationship['accessor']);
        } else {
            $foreign_key_name = $child_model->getForeignKeyName($this);
        }

        $where = $foreign_key_name . ' = ' . $this->_db->value_to_sql_field($this->getPrimaryKey());

        if (is_array($where_fields) && !empty($where_fields)) {
            $where .= ' AND ' . implode(' AND ', $this->_db->sql_columns_from_array_for_where($where_fields));
        } elseif (!empty($where_fields)) {
            $where .= ' AND ' . $where_fields;
        }

        if (isset($relationship['where'])) {
            if (is_array($relationship['where'])) {
                $where .= ' AND ' . implode(' AND ', $this->_db->sql_columns_from_array_for_where($relationship['where']));
            } else {
                $where .= ' AND ' . $relationship['where'];
            }
        }

        return $child_model->countAll($where, $options, $config);
    }

    /**
     * self::HAS_MANY relationships can be called as methods on the Model_ORM instances. Callers can
     * supply three arguments. The signature is as follows:
     *
     * public function relationshipName ( where_fields = NULL, $options = NULL, $config = array() )
     *
     * Known configuration options are:
     *  - callback: Call callback for each row returned
     *  - fetch_all_relations: Efficiently prefetch the relationship data, prevent a n+n number of queries
     *  - key: Return Model_Set indexed by this model property
     *
     * @param string $accessor
     *
     * @throws Model_Exception
     */
    public function __call($accessor, array $arguments) // has_many
    {
        /** @var array|string|null $where_fields */
        $where_fields = empty($arguments[0]) ? [] : $arguments[0];
        $options      = empty($arguments[1]) ? null : $arguments[1];
        $config       = isset($arguments[2]) && is_array($arguments[2]) ? $arguments[2] : [];

        // $customer->countProfileChangesets() => relation = profile_changesets
        if (strings::startsWith($accessor, "count") && preg_match('!^count(\w+)!', $accessor, $matches)) {
            $accessor = strtolower(preg_replace('/(?<!^)[A-Z]/', '_$0', $matches[1]));

            return $this->relationCount($accessor, $where_fields, $options, $config);
        }

        if (!$this->hasDefinedRelation($accessor)) {
            throw new Model_Exception("Relationship " . get_class($this) . "::\"{$accessor}\"() is not defined!");
        }

        $relationship = $this->getRelationDefinition($accessor);

        if ($relationship['type'] !== self::HAS_MANY) {
            throw new Model_Exception("Cannot call {$accessor} as method(), try getting it as a variable.");
        }

        if ($this->hasQueriedRelation($accessor)) {
            $relation = $this->getRelation($accessor);

            if (!empty($config['key']) && $relation instanceof Model_Set) {
                /*
                 * Make sure the set is indexed by the specified key even if the relation is set manually and is not loaded from the database by \Model_Base::findAllSql
                 *
                 * Example:
                 * $authorization->setRelation('granted_scopes', $all_scopes_set);
                 * $authorization->granted_scopes(NULL, NULL, ['key' => 'scope_tag']); // will return $all_scopes_set indexed by scope_tag
                 */
                $relation = $relation->indexBy($config['key']);
            }

            return $relation;
        }

        if (!$this->stored()) {
            return new Model_Set();
        }

        /** @var Model_Base|Model_ORM $child_model */
        $child_model = new $relationship['model']($this->_db);

        /* There are two ways of specifying a named relationship. One is by defining columns
         * to be added to the query. The second is by defining a complete query which allows
         * you to do more complex query to determine valid children */
        if (isset($relationship['query'])) {
            $query = $relationship['query'];

            if (is_numeric($options) && !preg_match('/\s+LIMIT\s+\d+/i', $query)) {
                $query .= " LIMIT {$options}";
            }

            // Manually replace the primary key NAME and primary key VALUE
            $query = strtr(
                $query,
                [
                    '[PK_NAME]'  => $child_model->getForeignKeyName($this),
                    '[PK_VALUE]' => $this->_db->value_to_sql_field($this->getPrimaryKey()), ]
            );

            $parameters = is_array($where_fields) ? $where_fields : [];

            return $child_model->findAllSql($query, $parameters, $config);
        }

        // Predefined foreign relation accessor
        if (isset($relationship['accessor'])) {
            $foreign_key_name = $child_model->getForeignKeyName($this, $relationship['accessor']);
        } else {
            $foreign_key_name = $child_model->getForeignKeyName($this);
        }

        $should_downgrade_to_where_string = !is_array($where_fields) || (isset($relationship['where']) && !is_array($relationship['where']));

        if ($should_downgrade_to_where_string) {
            /*
             * We need to use strings, because the argument to this method is a
             * string or the relationship includes a string value instead of an
             * array.
             */
            $where = $foreign_key_name . ' = ' . $this->_db->value_to_sql_field($this->getPrimaryKey());

            if (is_array($where_fields) && !empty($where_fields)) {
                $where .= ' AND ' . implode(' AND ', $this->_db->sql_columns_from_array_for_where($where_fields));
            } elseif (!empty($where_fields)) {
                $where .= ' AND ' . $where_fields;
            }

            if (isset($relationship['where'])) {
                if (is_array($relationship['where'])) {
                    $where .= ' AND ' . implode(' AND ', $this->_db->sql_columns_from_array_for_where($relationship['where']));
                } else {
                    $where .= ' AND ' . $relationship['where'];
                }
            }
        } else {
            /*
             * We can use arrays. This is prefered and enables more nice magic stuff.
             */
            $where                    = $where_fields;
            $where[$foreign_key_name] = $this->getPrimaryKey();

            if (isset($relationship['where'])) {
                /* It's an array, else we'd have been downgraded. */
                $where = array_merge($where, $relationship['where']);
            }
        }

        $post_process_function = function (Model_ORM $child): void {
        };

        if ($child_model instanceof self) {
            /*
             * We have retrieved all the children. Now see if there is a backwards relationship, and set the relationship
             * in our children to this object.
             */
            $backward_accessor = $child_model->getAccessorFor(self::BELONGS_TO, $this);

            if (!empty($backward_accessor)) {
                $post_process_function = function (Model_ORM $child) use ($backward_accessor): void {
                    /*
                     * Use direct setRelation() so that we don't have any reverse lookups, this is faster and saves us
                     * memory.
                     */
                    $child->setRelation($backward_accessor, $this);
                };
            }
        }

        if (!empty($config["callback"])) {
            /*
             * If we use a callback, we will pre-process the callback and add our backwards
             * relationship function to it.
             */
            $old_callback       = $config["callback"];
            $config["callback"] = function (Model_Base $child) use ($post_process_function, $old_callback) {
                $post_process_function($child);

                return $old_callback($child);
            };
        }

        /** @var array|Model_Base[]|Model_Set $children */
        $children = $child_model->findAll($where, $options, $config);

        if ($children instanceof Model_Set) {
            /*
             * Note that $children can also be an array if a callback is used. In that case the return
             * value will be an array instead of a Model_Set.
             */
            $children->walk($post_process_function);
        }

        return $children;
    }

    /**
     * Save this record and any HAS_ONE relationships defined
     *
     * @param bool $force_save If set to true, will try to save relationships to the DB - even if the main record failed
     *
     * @return bool
     *
     * @deprecated Use saveOrDie() instead.
     * @see saveOrDie
     */
    public function save($force_save = false)
    {
        $save_result = parent::save($force_save);

        if ($save_result !== true && !$force_save) {
            return $save_result;
        }

        foreach ($this->_relationships as $accessor => $relationship) {
            if (!$this->hasFoundRelation($accessor)) {
                continue;
            }

            if ($relationship['type'] === self::HAS_ONE) {
                $child = $this->getRelation($accessor);
                $child->setForeignKey($this);

                if (!$child->stored() || $child->changed()) {
                    $child_save_result = $child->save($force_save);

                    if ($child_save_result !== true) {
                        return $child_save_result;
                    }
                }
            } elseif ($relationship['type'] === self::HAS_MANY) {
                /** @var self[] $children */
                $children = $this->getRelation($accessor);

                foreach ($children as $child) {
                    $child->setForeignKey($this);

                    if (!$child->stored() || $child->changed()) {
                        $child_save_result = $child->save();

                        if ($child_save_result !== true) {
                            return $child_save_result;
                        }
                    }
                }
            }
        }

        return true;
    }

    /**
     * Save the model. Throw an exception if saving fails.
     *
     * @param bool $force_save
     *
     * @throws Model_Exception_Save
     */
    public function saveOrDie($force_save = false)
    {
        try {
            parent::saveOrDie($force_save);
        } catch (Model_Exception_Save $e) {
            $validation_errors = $this->getValidationErrors(false);

            foreach ($this->_relationships as $accessor => $relationship) {
                if (!$this->hasFoundRelation($accessor)) {
                    continue;
                }

                if ($relationship['type'] === self::HAS_ONE) {
                    $child = $this->getRelation($accessor);

                    if (!$child->valid()) {
                        $validation_errors = array_merge($validation_errors, [$accessor => $child->getValidationErrors(false)]);
                    }
                } elseif ($relationship['type'] === self::HAS_MANY) {
                    /** @var self[] $children */
                    $children = $this->getRelation($accessor);

                    foreach ($children as $index => $child) {
                        if (!$child->valid()) {
                            $validation_errors = array_merge($validation_errors, ["{$accessor}#{$index}" => $child->getValidationErrors(false)]);
                        }
                    }
                }
            }

            throw new Model_Exception_Save("Unable to save {$this->getIdentity()}: " . var_export($validation_errors, true));
        }
    }

    /**
     * Returns a collection of instances of the current model that were found in
     * the database by searching using the search options defined in $where.
     *
     * @param array|string $where   Array of columns and values or a complete SQL string to use for searching
     * @param mixed        $options Allows you to specify ORDER BY / LIMIT / HAVING clauses
     * @param mixed        $config  Extra options changing behaviour, see below.
     *
     * @throws Model_Exception
     *
     * Example usage:
     *    $customer->findAll(array('id' => 288075)); // WHERE id = 288075
     *    $customer->findAll('id = 288075'); // WHERE id = 288075
     *    $customer->findAll('id = 1234', 10); // WHERE id = 10 LIMIT 10
     *    $customer->findAll('id = 1234', array('ORDER BY' => 'id DESC')); // WHERE id = 1234 ORDER BY id DESC
     *
     * Configuration options alter behaviour:
     *  - Option 'callback' allows you to specify a callback to be called for each row found, instead of loading
     *    each row into a large array. Usefull when dealing with large datasets:
     *
     *    $customer->findAll('id = 1234', NULL, array('callback' => array($myobject, 'mymethod'))); // calls $myobject->mymethod($model_instance_of_current_row) for each row found.
     *
     *    In that case, the return value will be an array of the results of the callback function for each model.
     *
     *  - Option 'fetch_includes' allows you to only fetch the columns that were specified in the $_includes property
     *    of the object.
     *
     *    $customer->_includes = array ( 'id', 'name' ); // for illustration purposes, $_includes is defined protected on the class
     *    $customer->findAll(NULL, NULL, array('fetch_includes' => TRUE)); // uses 'SELECT id, name FROM m_klanten' instead of 'SELECT * FROM m_klanten'
     *
     * @return int|Model_Set|self[]
     */
    public function findAll($where = '1', $options = null, $config = [])
    {
        $base_query = null;

        if (is_array($where) && empty($where)) {
            $where = 1;
        }

        if (isset($config['fetch_includes']) && $config['fetch_includes']) {
            $base_query = "SELECT /*COLUMNS*/ FROM %s t0/*JOINS*/ WHERE %s%s";
        }

        $query = $this->_createSqlQuery($where, $options, $base_query);

        return $this->findAllSql($query, [], $config);
    }

    /**
     * @param array|string     $where
     * @param array|int|string $options    If int or numeric, interpreted as LIMIT.
     * @param string|null      $base_query
     *
     * @return string
     */
    protected function _createSqlQuery($where, $options, $base_query = null)
    {
        if (is_array($where)) {
            // Replace ["customer" => $customer] by ["customer_id" => $customer->id].
            foreach ($where as $field => $value) {
                if (!$value instanceof Model_Base || !$this->hasDefinedRelation($field)) {
                    continue;
                }

                $primary_key = $value->getPrimaryKey();

                // No support for multi-column primary keys.
                if (is_array($primary_key)) {
                    continue;
                }

                $relation = $this->getRelationDefinition($field);

                if (!isset($relation["type"], $relation["foreign_key"]) || $relation["type"] !== static::BELONGS_TO) {
                    continue;
                }

                // Add the new argument.
                $where[$relation["foreign_key"]] = $primary_key;

                // Remove the old argument.
                unset($where[$field]);
            }
        }

        return parent::_createSqlQuery($where, $options, $base_query);
    }

    /**
     * Uses the given query to create models of the current type. This method should mostly be used from specific
     * finders defined on the current object.
     *
     * @see self::findAll for explanation on $config parameter
     *
     * @param string $query     Valid SQL query to find database rows for the current model
     * @param array  $arguments Any values that might have to be replaced in $query ($query is passed to sql_db::sql_safe_query()).
     * @param array  $config    See self::findAll for explanation on $config parameter
     *
     * @throws Model_Exception
     *
     * Example usage:
     *    $this->findAllSql("SELECT * FROM m_klanten WHERE id = $1", array(288075)); // WHERE id = 288075
     *
     * @return array|Model_Iterator|Model_Set|self[]
     */
    public function findAllSql($query, $arguments = [], $config = null)
    {
        if (isset($config['fetch_includes']) && $config['fetch_includes']) {
            // determine what keys to look out for
            $foreign_keys  = [];
            $joins         = [];
            $table_aliases = [];
            $table_models  = [];
            $table_index   = 0;
            $columns       = [];

            $table_aliases[$this->_table_name] = 't' . $table_index;
            $table_models['t' . $table_index]  = $this->getModelName();
            $table_index++;

            foreach ($this->_table_columns as $column) {
                $alias     = $table_aliases[$this->_table_name];
                $columns[] = "{$alias}.{$column} AS {$alias}_{$column}";
            }

            foreach ($this->_includes as $accessor) {
                $details = $this->getRelationDefinition($accessor);

                if (isset($details['base_type'])) {
                    continue;
                }

                /** @var self $model */
                $model = new $details['model']($this->_db);

                if ($details['type'] == self::HAS_ONE) {
                    $foreign_keys[$accessor]                 = $details;
                    $foreign_keys[$accessor]['foreign_key']  = $this->_primary_key;
                    $foreign_keys[$accessor]['value_column'] = $details['foreign_key'];
                } elseif ($details['type'] == self::HAS_MANY) {
                    $foreign_keys[$accessor]                = $details;
                    $foreign_keys[$accessor]['foreign_key'] = $details['foreign_key'];
                } elseif ($details['type'] == self::BELONGS_TO) {
                    $foreign_keys[$accessor]                 = $details;
                    $foreign_keys[$accessor]['foreign_key']  = $model->getPrimaryKeyName();
                    $foreign_keys[$accessor]['value_column'] = $details['foreign_key'];
                }

                if (!isset($table_aliases[$model->getTableName()])) {
                    $table_aliases[$model->getTableName()] = 't' . $table_index;
                    $table_models['t' . $table_index]      = ['model' => $model->getModelName(), 'accessor' => $accessor];
                    $table_index++;
                }

                if ($details['type'] != self::HAS_MANY) {
                    $joins[] = sprintf(
                        "LEFT OUTER JOIN %s %s ON (%s.%s = %s.%s)",
                        $model->getTableName(),
                        $table_aliases[$model->getTableName()],
                        $table_aliases[$this->getTableName()],
                        $foreign_keys[$accessor]['value_column'],
                        $table_aliases[$model->getTableName()],
                        $foreign_keys[$accessor]['foreign_key']
                    );

                    foreach ($model->getColumns() as $column) {
                        $alias     = $table_aliases[$model->getTableName()];
                        $columns[] = "{$alias}.{$column} AS {$alias}_{$column}";
                    }
                }
            }

            $query = str_replace('/*COLUMNS*/', implode(',', $columns), $query);
            $query = str_replace('/*JOINS*/', ' ' . implode(' ', $joins), $query);

            return new Model_Iterator($this->_db, $query, $this->getModelName(), $table_models);
        }

        return parent::findAllSql($query, $arguments, $config);
    }

    /**
     * Get accessor for a BELONGS_TO or HAS_ONE relationship
     *
     * @param int  $relationship_type Either BELONGS_TO or HAS_ONE, the relationship to look for
     * @param self $model             The model for which to get the accessor
     *
     * @return string|null Returns the accessor for the relationship
     */
    public function getAccessorFor($relationship_type, self $model)
    {
        $model_name = $model->getModelName();

        $possible_matches = [];

        foreach ($this->_relationships as $accessor => $relationship) {
            if ($relationship['type'] !== $relationship_type) {
                continue;
            }

            if (isset($relationship['model']) && strcasecmp($relationship['model'], $model_name) === 0) {
                $possible_matches[] = $accessor;
            } elseif (isset($relationship['base_type']) && $model instanceof $relationship['base_type']) {
                $possible_matches[] = $accessor;
            }
        }

        if (count($possible_matches) === 1) {
            return $possible_matches[0];
        }

        /*
         * There are multiple matches, do not return any because we don't want to mix them up and we cannot
         * distinguish between the many. E.g. this can happen when one object has multiple types of the same child
         * object (e.g. Model_Payment_Profile::$api_key_test and ::$api_key_live.
         */
        return null;
    }

    /**
     * Get foreign key name
     *
     * @param Model_ORM   $model
     * @param string|null $accessor
     *
     * @return string|null
     */
    public function getForeignKeyName(self $model, $accessor = null)
    {
        $model_name = $model->getModelName();

        if ($this->hasDefinedRelation($accessor)) {
            $relationship = $this->getRelationDefinition($accessor);

            if ($relationship['type'] === self::BELONGS_TO && strcasecmp($relationship['model'], $model_name) === 0) {
                return $this->getRelationDefinition($accessor)['foreign_key'];
            }
        }

        foreach ($this->_relationships as $relationship) {
            if ($relationship['type'] === self::BELONGS_TO && strcasecmp($relationship['model'], $model_name) === 0) {
                return $relationship['foreign_key'];
            }
        }

        return null;
    }

    /**
     * Set the foreign key for relationship with $model to $id
     *
     * @param self $model Object to set the value for. A BELONGS_TO relationship for this model should exist.
     */
    private function setForeignKey(self $model): void
    {
        $id = $model->getPrimaryKey();

        foreach ($this->_relationships as $accessor => $relationship) {
            if ($relationship['type'] === self::BELONGS_TO && is_a($model, $relationship["model"])) {
                if ($relationship['foreign_key'] === $this->_primary_key) {
                    $this->_object_data[$relationship['foreign_key']] = $id;
                } else {
                    $this->{$relationship['foreign_key']} = $id;
                }

                return;
            }
        }
    }

    /**
     * Remove any relationship values for relationship defined by $accessor_to_look_for on this object
     *
     * @param string|null $accessor (Optional) String identifying the relationship accessor
     */
    public function invalidateForeignData(?string $accessor = null): bool
    {
        // Remove all relations
        if ($accessor === null) {
            foreach ($this->_relations as $accessor => $relation) {
                $this->invalidateForeignData($accessor);
            }

            /*
             * Don't do any garbarge collection here. gc_collect_cycles() is
             * not cheap and especially when called often when handling huge
             * record sets (e.g. for exports or workers) it is better to let
             * the memory management by done by PHP itself:
             *
             * "When the garbage collector is turned on, the cycle-finding
             * algorithm as described above is executed whenever the root
             * buffer runs full."
             *
             * @link https://secure.php.net/manual/en/features.gc.collecting-cycles.php
             */
            return true;
        }

        // Remove a specific relation
        if (!$this->hasDefinedRelation($accessor)) {
            return false;
        }

        $relationship = $this->getRelationDefinition($accessor);

        if ($this->hasQueriedRelation($accessor) && $this->getRelation($accessor) instanceof self) {
            if ($relationship['type'] === self::BELONGS_TO || $relationship['type'] === self::HAS_ONE) {
                $backward_accessor = $this->getRelation($accessor)->getAccessorFor(
                    $relationship['type'] === self::BELONGS_TO ? self::HAS_ONE : self::BELONGS_TO,
                    $this
                );

                if (!empty($backward_accessor)) {
                    $this->{$accessor}->unsetRelation($backward_accessor);
                }
            }
        }

        $this->unsetRelation($accessor);

        return true;
    }

    /**
     * Check if a related model has been queried. If it has been queried but not found, this will return TRUE, but hasFoundRelation will return FALSE.
     *
     * @param string $accessor
     *
     * @return bool
     */
    protected function hasQueriedRelation($accessor)
    {
        return isset($this->_relations[$accessor]) || array_key_exists($accessor, $this->_relations);
    }

    /**
     * Get a loaded relationship.
     *
     * @param $accessor
     *
     * @return Model_ORM|Model_ORM[]|Model_Set|null
     */
    protected function getRelation($accessor)
    {
        if (empty($this->getRelationDefinition($accessor))) {
            throw new Model_Exception(sprintf('Unknown relationship %s.', $accessor));
        }

        return $this->_relations[$accessor];
    }

    /**
     * Get a relationship's properties.
     *
     * @param $accessor
     *
     * @return array
     */
    protected function getRelationDefinition($accessor)
    {
        return $this->_relationships[$accessor];
    }

    /**
     * Check if a related model is loaded in memory.
     *
     * @param string $accessor
     *
     * @return bool
     */
    protected function hasFoundRelation($accessor)
    {
        return $this->hasQueriedRelation($accessor) && $this->getRelation($accessor) !== null;
    }

    /**
     * Checks wether a specific relationship was defined on this object.
     *
     * @param string $accessor
     *
     * @return bool
     */
    public function hasDefinedRelation($accessor)
    {
        return isset($this->_relationships[$accessor]);
    }

    /**
     * Keep a related model in memory.
     *
     * @param string                               $accessor String identifying the relationship
     * @param Model_ORM|Model_ORM[]|Model_Set|null $value    ORM object the relationship should be set to. This should be a Model_ORM, or a collection of Model_ORM objects in case of setting a self::HAS_MANY type of
     *                                                       relationship. If an array is passed, it will be converted to a Model_Set. If NULL is passed, the relationship is explicitly defined as 'not found'.
     *
     * @throws Model_Exception_UnknownColumn
     */
    public function setRelation(string $accessor, $value): void
    {
        if (!$this->hasDefinedRelation($accessor)) {
            throw new Model_Exception_UnknownColumn("Unknown relationship \"{$accessor}\".");
        }

        if (is_array($value)) {
            $value = new Model_Set($value);
        }

        $this->_relations[$accessor] = $value;
    }

    /**
     * Remove a related model from memory.
     */
    public function unsetRelation(string $accessor): void
    {
        unset($this->_relations[$accessor]);
    }
}
