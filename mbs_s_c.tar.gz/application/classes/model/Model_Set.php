<?php

/**
 * Een ArrayObject-extensie voor een set van belongs_to-objecten
 *
 * @method bool                   stored() stored()
 * @method bool                   validate() validate()
 * @method bool                   save() save($force_save = FALSE)
 * @method void                   saveOrDie() saveOrDie($force_save = FALSE)
 * @method bool                   delete() delete()
 * @method bool                   changed() changed()
 * @method string[][]             getValidationErrors() getValidationErrors($htmlspecialchars = true)
 * @method array[]                toArray() toArray()
 * @method Model_Base[]|Model_Set reload() reload()
 * @method void                   reloadOrDie()
 */
class Model_Set extends ArrayObject
{
    /**
     * Note: the constructor is overridden here because I always fuck up in writing tests and put in a Model
     * directly without array, we don't want to have a set of all publicly accessible properties of the model now do
     * we?
     */
    public function __construct(array $input = [])
    {
        parent::__construct($input);
    }

    /**
     * {@inheritdoc}
     *
     * @throws Model_Exception
     */
    public function offsetGet($index)
    {
        if ($index === null) {
            throw new Model_Exception("Attempting to access a key by NULL.");
        }

        return parent::offsetGet($index);
    }

    public function __call($method_name, array $arguments)
    {
        $default_true_methods  = ["stored", "validate", "save", "delete"];
        $default_false_methods = ["changed"];
        $return_array_methods  = ["getValidationErrors", "toArray"];
        $return_set_methods    = ["reload"];
        $void_methods          = ["saveOrDie", "reloadOrDie"];

        if (in_array($method_name, $default_true_methods)) {
            foreach ($this as $model) {
                if (!$model->{$method_name}(...$arguments)) {
                    return false;
                }
            }

            return true;
        }

        if (in_array($method_name, $default_false_methods)) {
            foreach ($this as $model) {
                if ($model->{$method_name}(...$arguments)) {
                    return true;
                }
            }

            return false;
        }

        if (in_array($method_name, $return_array_methods) || in_array($method_name, $return_set_methods)) {
            $arr = [];

            /** @var Model_Base[] $this */
            foreach ($this as $model) {
                $arr[] = $model->{$method_name}(...$arguments);
            }

            if (in_array($method_name, $return_set_methods)) {
                return new self($arr);
            }

            return $arr;
        }

        if (in_array($method_name, $void_methods)) {
            foreach ($this as $model) {
                $model->{$method_name}(...$arguments);
            }

            return;
        }

        throw new BadMethodCallException("Unknown method" . __CLASS__ . "::{$method_name}()");
    }

    /**
     * Set column to value on all items at once
     *
     * @param string $column
     *
     * @throws Model_Exception if column does not exist on an item
     */
    public function __set($column, $value)
    {
        foreach ($this as $item) {
            $item->{$column} = $value;
        }
    }

    /**
     * Returns all values of a specific column as an array.
     *
     * @param string $column
     *
     * @throws Model_Exception
     *
     * @return array
     */
    public function __get($column)
    {
        $result = [];

        foreach ($this->getIterator() as $index => $component) {
            $component = (object)$component;

            if (!property_exists($component, $column) && !method_exists($component, '__get')) {
                throw new Model_Exception("Trying to get \${$column} property from non-object at #{$index}");
            }

            $result[$index] = $component->{$column};
        }

        return $result;
    }

    /**
     * Get the first entry in the set, or NULL if the set is empty.
     *
     * @return Model_Base|null
     */
    public function first()
    {
        /* Fast route to get the first one without creating copies */
        foreach ($this as $object) {
            return $object;
        }

        return null;
    }

    /**
     * @param $index
     *
     * @return Model_Base|Model_ORM|null
     */
    public function at($index)
    {
        if ($index === 0) {
            return $this->first();
        }

        if (count($this) >= $index) {
            $array = array_values($this->getArrayCopy());

            if (isset($array[$index])) {
                return $array[$index];
            }
        }

        return null;
    }

    /**
     * Get the last object from the set.
     *
     * @return Model_Base|null
     */
    public function end()
    {
        return $this->at(count($this) - 1);
    }

    /**
     * Returns unique values of a specific column.
     *
     * @param string $column
     *
     * @return array
     */
    public function distinct($column)
    {
        return array_values(array_unique($this->{$column}));
    }

    /**
     * Slice a piece of the set, returns a new set with the new slice.
     *
     * @param $offset
     * @param $length
     *
     * @return Model_Set
     */
    public function slice($offset, $length)
    {
        return new self(array_slice(
            $this->getArrayCopy(),
            $offset,
            $length,
            true
        ));
    }

    /**
     * Preload a certain accessor, will retrieve all from the database in a single go.
     *
     * @param $relation
     *
     * @throws Model_Exception
     *
     * @return Model_ORM[]|self
     */
    public function preload($relation)
    {
        if (count($this) <= 1) {
            /*
             * Nothing to preload. Skip preloading.
             */
            return $this;
        }

        $class_name = null;

        foreach ($this as $model) {
            if ($class_name === null) {
                $class_name = get_class($model);
            }

            if (get_class($model) != $class_name || !($model instanceof Model_ORM)) {
                throw new Model_Exception("preload() can only be used on Model_Sets with a single class of Model_ORM objects.");
            }
        }

        /*
         * Get the first object, use it to retrieve relationship data.
         */
        /** @var Model_ORM $first */
        $first = $this->first();

        if (!$first->hasDefinedRelation($relation)) {
            throw new Model_Exception(get_class($first) . " does not have a relationship {$relation}.");
        }

        $relationships = $this->getRelationship($first);

        /** @var array[] $relationships */
        $relationship = $relationships[$relation];

        /* Get copy of sql_db */
        $db = $this->getDatabase($first);

        /** @var Model_ORM $mapper */
        $mapper = new $relationship["model"]($db);

        /** @var Model_ORM[]|self $this */
        if ($relationship["type"] == Model_ORM::HAS_MANY) {
            $relationships = array_values(array_filter($this->getRelationship($mapper), function (array $relation) use ($class_name) {
                return $relation["model"] == $class_name;
            }));

            $foreign_key_name = $relationships[0]['foreign_key'];

            $primary_keys = array_keys($this->getArrayCopy());

            $all = $mapper->findAll([
                $foreign_key_name => ["IN", $primary_keys],
            ]);

            $buckets = $all->bucket($foreign_key_name);

            foreach ($this as $primary_key => $object) {
                $object->setRelation($relation, $buckets[$primary_key] ?? new self());
            }
        } else {
            /*
             * Filter to remove any NULLs (e.g. if no relation is configured).
             */
            $objects = $mapper->loadByIds(array_filter($this->distinct($relationship["foreign_key"])));

            foreach ($this as $object) {
                if ($object->{$relationship["foreign_key"]}) {
                    $object->setRelation($relation, $objects[$object->{$relationship["foreign_key"]}]);
                }
            }
        }

        return $this;
    }

    /**
     * Put the objects in this Model_Set in different buckets according to some column name. E.g. all objects with
     * the same value for $column_name will be put in the same bucket. Returns an array of Model_Sets, the key of
     * the array is the value of the bucket.
     *
     * @param callable|string $filter A column name, or a closure that takes a full object and returns a bucket key.
     *
     * @return Model_Set[]
     */
    public function bucket($filter)
    {
        if (is_string($filter)) {
            $closure = function (Model_Base $model) use ($filter) {
                return $model->{$filter};
            };
        } else {
            $closure = $filter;
        }

        $return = [];

        /** @var Model_Base[]|self $this */
        foreach ($this as $each) {
            $bucket = $closure($each);

            if (!isset($return[$bucket])) {
                $return[$bucket] = new self();
            }

            $return[$bucket][$each->getPrimaryKey()] = $each;
        }

        return $return;
    }

    /**
     * Sort the Model_Set by some sorting function. This function will receive each model in the set and must return
     * -1, 0 or 1.
     *
     * @see strcmp()
     * @see usort()
     *
     * @return Model_Base[]|self
     */
    public function sort(callable $sorting_function)
    {
        $this->uasort($sorting_function);

        return $this;
    }

    /**
     * Limit the object to a list of $limit length.
     *
     * @param int $limit
     *
     * @return Model_Base[]|self
     */
    public function limit($limit)
    {
        $chunk = array_slice($this->getArrayCopy(), 0, $limit, true);
        $this->exchangeArray($chunk);

        return $this;
    }

    /**
     * Merge two Model_Set's.
     *
     * @return Model_Base[]|self
     */
    public function merge(self $set)
    {
        if (count($set) > 0) {
            $this->exchangeArray(array_merge($this->getArrayCopy(), $set->getArrayCopy()));
        }

        return $this;
    }

    /**
     * Filter the set with a callback function.
     *
     * @return Model_Base[]|Model_Set
     */
    public function filter(callable $filter_function)
    {
        if (count($this) > 0) {
            $this->exchangeArray(array_filter($this->getArrayCopy(), $filter_function));
        }

        return $this;
    }

    /**
     * @return Model_Set
     */
    public function getClone()
    {
        return clone $this;
    }

    /**
     * Remove duplicate models from this set (by primary key comparison).
     *
     * @return Model_Base[]|self
     */
    public function unique()
    {
        $primary_keys = [];

        return $this->filter(function (Model_Base $model) use (&$primary_keys) {
            if (in_array($model->getPrimaryKey(), $primary_keys)) {
                return false;
            }

            $primary_keys[] = $model->getPrimaryKey();

            return true;
        });
    }

    /**
     * Run a method over each object in the set, return an array.
     *
     * @return array
     */
    public function map(callable $map_function)
    {
        return array_map($map_function, $this->getArrayCopy());
    }

    /**
     * Apply a user supplied function to each object in the set.
     */
    public function walk(callable $walk_function)
    {
        $array_copy = $this->getArrayCopy();

        array_walk($array_copy, $walk_function);
    }

    /**
     * @param $initial
     */
    public function reduce(callable $reduce_function, $initial = null)
    {
        return array_reduce($this->getArrayCopy(), $reduce_function, $initial);
    }

    /**
     * Check if a given model is present in this set.
     *
     * @return bool
     */
    public function contains(Model_Base $model)
    {
        foreach ($this as $set_model) {
            if ($set_model->equals($model)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Get the relationship info from a model.
     *
     * @return array
     */
    protected function getRelationship(Model_Base $model)
    {
        return $this->_getProtectedPropertyFrom($model, "_relationships");
    }

    /**
     * Get the database from a Model_Base.
     *
     * @return sql_db
     */
    protected function getDatabase(Model_Base $model)
    {
        return $this->_getProtectedPropertyFrom($model, "_db");
    }

    /**
     * Get a property that is not accessible from an object, use with care.
     *
     * @param $property
     */
    private function _getProtectedPropertyFrom(Model_Base $model, $property)
    {
        $property = new ReflectionProperty(get_class($model), $property);
        $property->setAccessible(true);

        return $property->getValue($model);
    }

    public static function empty(): self
    {
        return new self([]);
    }
}
