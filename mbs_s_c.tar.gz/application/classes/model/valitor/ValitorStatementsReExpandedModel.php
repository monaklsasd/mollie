<?php

use App\Util\DateTime\Now;
use App\Util\DateTime\Utc;

/**
 * This is a temporary model and table to be used for re-expanding all the Valitor statements that were incorrectly
 * expanded.
 *
 * Once all statements are successfully re-expanded this class along with any related code should be deleted.
 *
 * @see https://mollie.atlassian.net/browse/FFS-1990
 *
 * @property int                 $id                          Maps to bank_transactions.id, int(10) unsigned
 * @property int                 $statementimport_id          Maps to bank_transactions.statementimport_id, int(10)
 *                                                            unsigned
 * @property string|null         $finished_reexpanding_at_utc Maps to bank_transactions.updated_at, datetime
 * @property string              $created_at_utc              Maps to bank_transactions.created_at, datetime
 * @property Model_Bankstatement $statement                   The Model_Bankstatement referenced by $statementimport_id
 */
class ValitorStatementsReExpandedModel extends Model_ORM
{
    use Utc;
    use Now;

    /** @var string */
    protected $_model_name = __CLASS__;

    /** @var string */
    protected $_table_name = 'valitor_statements_re_expanded';

    /** @var string[] */
    protected $_table_columns = [
        'id',
        'statementimport_id',
        'finished_reexpanding_at_utc',
        'created_at_utc',
    ];

    protected $_relationships = [
        'statement' => [
            'type'        => Model_ORM::BELONGS_TO,
            'model'       => Model_Bankstatement::class,
            'foreign_key' => 'statementimport_id',
        ],
    ];

    public function markAsFinishedReExpandingAtUtc(): void
    {
        $this->finished_reexpanding_at_utc = self::getNow()->format(Model_Base::DATE_SQL);
    }
}
