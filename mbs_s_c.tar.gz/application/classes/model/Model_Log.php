<?php

/**
 * Model for logs
 *
 * @property int         $id         Maps to logs.id, int(10) unsigned
 * @property string      $created_at Maps to logs.created_at, datetime
 * @property string      $updated_at Maps to logs.updated_at, datetime
 * @property int|null    $user_id    Maps to logs.user_id, int(10) unsigned
 * @property string|null $category   Maps to logs.category, varchar(20)
 * @property string|null $title      Maps to logs.title, varchar(255)
 * @property string|null $message    Maps to logs.message, text
 * @property string|null $ip_address Maps to logs.ip_address, varchar(50)
 * @property mixed       $type       Maps to logs.type, enum('info','debug','warning','error')
 * @property string|null $request_id Maps to logs.request_id, varchar(30)
 */
class Model_Log extends Model_ORM
{
    public const TYPE_ERROR  = 'error';
    public const TYPE_INFO   = 'info';
    public const TYPE_WARN   = 'warning';
    public const TYPE_DEBUG  = 'debug';
    public const KNOWN_TYPES = [
        Model_Log::TYPE_DEBUG,
        Model_Log::TYPE_ERROR,
        Model_Log::TYPE_INFO,
        Model_Log::TYPE_WARN,
    ];

    protected $_model_name = __CLASS__;

    protected $_table_name = 'logs';

    protected $_table_columns = [
        'id',
        'created_at',
        'updated_at',
        'user_id',
        'category',
        'title',
        'message',
        'ip_address',
        'type',
        'request_id',
    ];
}
