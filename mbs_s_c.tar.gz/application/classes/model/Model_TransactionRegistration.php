<?php

use Core\Time\TimeZones;

/**
 * Model for bank_accounts
 *
 * @property int                   $id                Maps to bank_transaction_registrations.id, int(10) unsigned
 * @property string                $registration_type Maps to bank_transaction_registrations.registration_type, varchar(25)
 * @property int                   $transaction_id    Maps to bank_transaction_registrations.transaction_id, int(10) unsigned
 * @property int|null              $handled           Maps to bank_transaction_registrations.handled, tinyint(1)
 * @property int                   $registered_id     Maps to bank_transaction_registrations.registered_id, int(10) unsigned
 * @property string|null           $created_at_utc    Maps to bank_transaction_registrations.created_at_utc, datetime
 * @property string|null           $updated_at_utc    Maps to bank_transaction_registrations.updated_at_utc, datetime
 * @property Model_Banktransaction $banktransaction   The Model_Banktransaction referenced by $transaction_id
 */
class Model_TransactionRegistration extends Model_ORM
{
    /**
     * This transaction was transferred to our bank account by our acquiring bank, but is was not known as as successful
     * transaction at the Mollie application.
     */
    public const REGISTRATION_UNKNOWN_IDEAL = "unknownideal";

    /**
     * A transaction was made on the iDEAL account, however something was wrong with the transaction
     * (e.g. invalid amount, not paid in Mollie, double settled)
     */
    public const REGISTRATION_FAILURE_IDEAL = "nonideal";

    /**
     * When a banktransfer comes in with a different amount than the Mollie settlement, it is split.
     * If the customer overpaid more than a certain treshold (see BanktransferSettlementSplitter),
     * the overpaid amount will be refunded, and get this registration.
     */
    public const REGISTRATION_OVERPAID_BANKTRANSFER = "overpaidbanktransfer";

    /**
     * This transaction was transferred to our SEPA Bank Transfer account by consumers, but is was not known as as successful
     * transaction at the Mollie application.
     */
    public const REGISTRATION_UNKNOWN_BANKTRANSFER = "unknownbanktransfer";

    /**
     * A transaction was made on the SOFORT Banking account, however it did not belong to a SOFORT Banking transaction
     * (e.g. no SOFORT transaction id or not found by Mollie).
     */
    public const REGISTRATION_UNKNOWN_SOFORT = "unknownsofort";

    /**
     * A transaction was made on the Mister Cash account, however it did not belong to a Mister Cash transaction
     * (e.g. no Mister Cash transaction id or not found by Mollie). This should not really happen as the Mister Cash
     * bank account is not visible on consumers' bank statements.
     */
    public const REGISTRATION_UNKNOWN_MISTERCASH = "unknownmistercash";

    /**
     * A transaction was made on the Belfius Direct Net account, however it did not belong to a Belfius Direct Net transaction
     * (e.g. no Belfius Direct Net transaction id or not found by Mollie).
     */
    public const REGISTRATION_UNKNOWN_BELFIUS = "unknownbelfius";

    /** A transaction was made on the Bitcoin account, however it did not belong to a Bitcoin transaction */
    public const REGISTRATION_UNKNOWN_BITCOIN = "unknownbitcoin";

    /**
     * A transaction was made on the Home'Pay account, however it did not belong to a Home'Pay transaction
     * (e.g. no Home'Pay transaction id or not found by Mollie).
     */
    public const REGISTRATION_UNKNOWN_INGHOMEPAY = "unknowning_homepay";

    /**
     * A transaction was made on the KBC account, however it did not belong to a KBC transaction
     * (e.g. no KBC transaction id or not found by Mollie).
     */
    public const REGISTRATION_UNKNOWN_KBC = "unknownkbc";

    /**
     * A transaction was made on the Klarna account, however it did not belong to a Klarna transaction
     * (e.g. no Klarna transaction id or not found by Mollie).
     */
    public const REGISTRATION_UNKNOWN_KLARNA = "unknownklarna";

    /**
     * A transaction was made on the Direct Debit account, however it did not belong to a Direct Debit transaction
     * (e.g. no Direct Debit transaction id or not found by Mollie).
     */
    public const REGISTRATION_UNKNOWN_DIRECTDEBIT = "unknowndirectdebit";

    /** A transaction was made on the creditcard account, however it did not belong to a creditcard transaction. */
    public const REGISTRATION_UNKNOWN_CREDITCARD = "unknowncreditcard";

    /** A transaction was made on the PPRO account, however it did not belong to a transaction. */
    public const REGISTRATION_UNKNOWN_PPRO = "unknownppro";

    /** A transaction was made on the amex account, however it did not belong to an amex transaction. */
    public const REGISTRATION_UNKNOWN_AMEX = "unknownamex";

    /** An unknown transaction on the refund account. */
    public const REGISTRATION_UNKNOWN_REFUND = "unknownrefund";

    /** An unknown transaction on the outpayment account. */
    public const REGISTRATION_UNKNOWN_OUTPAYMENT = "unknownoutpayment";

    /**
     * A transaction was made on the SOFORT Banking account, however something was wrong with the transaction
     * (e.g. invalid amount, not paid in Mollie, double settled)
     */
    public const REGISTRATION_FAILURE_SOFORT = "failuresofort";

    /**
     * A transaction was made on the Mister Cash account, however something was wrong with the transaction
     * (e.g. invalid amount, not paid in Mollie, double settled)
     */
    public const REGISTRATION_FAILURE_MISTERCASH = "failuremistercash";

    /**
     * A transaction was made on the Belfius Direct Net account, however something was wrong with the transaction
     * (e.g. invalid amount, not paid in Mollie, double settled)
     */
    public const REGISTRATION_FAILURE_BELFIUS = "failurebelfius";

    /**
     * A transaction was made on the KBC account, however something was wrong with the transaction
     * (e.g. invalid amount, not paid in Mollie, double settled)
     */
    public const REGISTRATION_FAILURE_KBC = "failurekbc";

    /**
     * A transaction was made on the Klarna account, however something was wrong with the transaction
     * (e.g. invalid amount, not paid in Mollie, double settled)
     */
    public const REGISTRATION_FAILURE_KLARNA = "failureklarna";

    /**
     * A transaction was made on the Home'Pay account, however something was wrong with the transaction
     * (e.g. invalid amount, not paid in Mollie, double settled)
     */
    public const REGISTRATION_FAILURE_INGHOMEPAY = "failureing_homepay";

    /**
     * A transaction was made on the Direct Debit account, however something was wrong with the transaction
     * (e.g. invalid amount, not paid in Mollie, double settled)
     */
    public const REGISTRATION_FAILURE_DIRECTDEBIT = "failuredirectdebit";

    /** A transaction was made on the creditcard account, however something was wrong with the transaction. */
    public const REGISTRATION_FAILURE_CREDITCARD = "failurecreditcard";

    /** A transaction was made on the PPRO account, however something was wrong with the transaction. */
    public const REGISTRATION_FAILURE_PPRO = "failureppro";

    /** A transaction was made on the AMEX account, however something was wrong with the transaction. */
    public const REGISTRATION_FAILURE_AMEX = "failureamex";

    /** A returned refund */
    public const REGISTRATION_FAILURE_REFUND = "failedrefund";

    /** A returned outpayment */
    public const REGISTRATION_FAILURE_OUTPAYMENT = "failedoutpayment";

    protected $_model_name    = __CLASS__;
    protected $_table_name    = 'bank_transaction_registrations';
    protected $_table_columns = [
        'id', 'registration_type', 'transaction_id', 'handled', 'registered_id',
        'created_at_utc', 'updated_at_utc',
    ];

    protected $_primary_key = 'id';

    protected $_relationships = [
        'banktransaction' => [
            'type'        => Model_ORM::BELONGS_TO,
            'model'       => 'Model_Banktransaction',
            'foreign_key' => 'transaction_id',
        ],
    ];

    /**
     * @return array
     */
    public static function getAllRegistrationTypes()
    {
        return [
            self::REGISTRATION_UNKNOWN_IDEAL         => "Unknown iDEAL payments",
            self::REGISTRATION_FAILURE_IDEAL         => "Failed iDEAL payments",
            self::REGISTRATION_UNKNOWN_BANKTRANSFER  => "Unknown bank transfer payments",
            self::REGISTRATION_OVERPAID_BANKTRANSFER => "Overpaid bank transfer payments",
            self::REGISTRATION_UNKNOWN_SOFORT        => "Unknown SOFORT Banking payments",
            self::REGISTRATION_FAILURE_SOFORT        => "Failed SOFORT Banking payments",
            self::REGISTRATION_UNKNOWN_MISTERCASH    => "Unknown Bancontact/Mister Cash payments",
            self::REGISTRATION_FAILURE_MISTERCASH    => "Failed Bancontact/Mister Cash payments",
            self::REGISTRATION_UNKNOWN_BELFIUS       => "Unknown Belfius Direct Net payments",
            self::REGISTRATION_FAILURE_BELFIUS       => "Failed Belfius Direct Net payments",
            self::REGISTRATION_UNKNOWN_BITCOIN       => "Unknown Bitcoin payments",
            self::REGISTRATION_UNKNOWN_KBC           => "Unknown KBC payments",
            self::REGISTRATION_FAILURE_KBC           => "Failed KBC payments",
            self::REGISTRATION_UNKNOWN_KLARNA        => "Unknown Klarna payments",
            self::REGISTRATION_FAILURE_KLARNA        => "Failed Klarna payments",
            self::REGISTRATION_UNKNOWN_DIRECTDEBIT   => "Unknown SEPA Incasso payments",
            self::REGISTRATION_FAILURE_DIRECTDEBIT   => "Failed SEPA Incasso payments",
            self::REGISTRATION_UNKNOWN_CREDITCARD    => "Unknown creditcard payments",
            self::REGISTRATION_FAILURE_CREDITCARD    => "Failed creditcard payments",
            self::REGISTRATION_UNKNOWN_AMEX          => "Unknown AMEX payments",
            self::REGISTRATION_FAILURE_AMEX          => "Failed AMEX payments",
            self::REGISTRATION_UNKNOWN_PPRO          => "Unknown PPRO payments",
            self::REGISTRATION_FAILURE_PPRO          => "Failed PPRO payments",
            self::REGISTRATION_UNKNOWN_INGHOMEPAY    => "Unknown ING Home'Pay payments",
            self::REGISTRATION_FAILURE_INGHOMEPAY    => "Failed ING Home'Pay payments",
            self::REGISTRATION_UNKNOWN_REFUND        => "Unknown refunds",
            self::REGISTRATION_FAILURE_REFUND        => "Failed refunds",
            self::REGISTRATION_UNKNOWN_OUTPAYMENT    => "Unknown outpayment",
            self::REGISTRATION_FAILURE_OUTPAYMENT    => "Failed outpayment",
        ];
    }

    public function forTransaction(Model_Banktransaction $transaction, string $registration_type): void
    {
        if (!array_key_exists($registration_type, self::getAllRegistrationTypes())) {
            throw new InvalidArgumentException(sprintf('"%s" is not a valid registration type.', $registration_type));
        }

        $this->banktransaction   = $transaction;
        $this->registration_type = $registration_type;
        $this->handled           = 0;
        $this->registered_id     = 0;
    }

    public function getTransaction(): Model_Banktransaction
    {
        return $this->banktransaction;
    }

    public function getRegistrationType(): string
    {
        return $this->registration_type;
    }

    public function markAsHandledInBatch(Model_BankPaymentBatch $batch): void
    {
        $this->registered_id = $batch->getPrimaryKey();
        $this->handled       = 1;
    }

    public function getHandledInBatchId(): int
    {
        if (!$this->isHandled() || (int)$this->registered_id === 0) {
            throw new LogicException(sprintf('This registration #%d has not been handled yet.', $this->getPrimaryKey()));
        }

        return (int)$this->registered_id;
    }

    public function isHandled(): bool
    {
        return (bool)$this->handled;
    }

    public function getCreatedAtUtc(): DateTimeImmutable
    {
        if ($this->created_at_utc === null) {
            throw new LogicException('Can\'t request created-at date if the object has not been loaded from the database.');
        }

        return DateTimeImmutable::createFromFormat('!' . Model_ORM::DATE_SQL, $this->created_at_utc, TimeZones::UTC());
    }

    public function getUpdatedAtUtc(): DateTimeImmutable
    {
        if ($this->updated_at_utc === null) {
            throw new LogicException('Can\'t request updated-at date if the object has not been loaded from the database.');
        }

        return DateTimeImmutable::createFromFormat('!' . Model_ORM::DATE_SQL, $this->updated_at_utc, TimeZones::UTC());
    }
}
