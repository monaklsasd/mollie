<?php

/**
 * Model for bank_payment_batches_history
 *
 * @property int                    $id                 Maps to bank_payment_batches_history.id, int(10) unsigned
 * @property int                    $payment_batch_id   Maps to bank_payment_batches_history.payment_batch_id, int(10) unsigned
 * @property int|null               $user_id            Maps to bank_payment_batches_history.user_id, int(10) unsigned
 * @property string|null            $message            Maps to bank_payment_batches_history.message, varchar(255)
 * @property string                 $created_at         Maps to bank_payment_batches_history.created_at, datetime
 * @property Model_BankPaymentBatch $bank_payment_batch The Model_BankPaymentBatch referenced by $payment_batch_id
 */
class Model_BankPaymentBatchHistoryEntry extends Model_ORM
{
    protected $_model_name    = __CLASS__;
    protected $_table_name    = 'bank_payment_batches_history';
    protected $_table_columns = [
        'id', 'payment_batch_id', 'user_id', 'message', 'created_at',
    ];

    protected $_relationships = [
        'bank_payment_batch' => [
            'type'        => Model_ORM::BELONGS_TO,
            'model'       => 'Model_BankPaymentBatch',
            'foreign_key' => 'payment_batch_id',
        ],
    ];
}
