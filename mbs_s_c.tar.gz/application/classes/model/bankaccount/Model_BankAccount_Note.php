<?php

use Core\Time\TimeZones;

/**
 * Class Model_BankAccount_Note
 *
 * @property int         $id              Maps to bank_account_notes.id, bigint(20) unsigned
 * @property int         $bank_account_id Maps to bank_account_notes.bank_account_id, bigint(20) unsigned
 * @property string|null $description     Maps to bank_account_notes.description, text
 * @property string      $updated_at_utc  Maps to bank_account_notes.updated_at_utc, datetime
 */
class Model_BankAccount_Note extends Model_ORM
{
    /** @var string */
    protected $_table_name = 'bank_account_notes';

    /** @var string[] */
    protected $_table_columns = [
        'id',
        'bank_account_id',
        'description',
        'updated_at_utc',
    ];

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function getUpdatedAtUtc(): ?DateTimeImmutable
    {
        if (empty($this->updated_at_utc)) {
            return null;
        }

        return new \DateTimeImmutable($this->updated_at_utc, TimeZones::UTC());
    }
}
