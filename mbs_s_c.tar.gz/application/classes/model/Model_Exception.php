<?php

class Model_Exception extends Exception
{
}
