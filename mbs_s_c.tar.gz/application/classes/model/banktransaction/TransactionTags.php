<?php

declare(strict_types=1);

namespace Model\Transaction;

use Supplier\PPro\Settlement\Record\TransactionTransformer;

interface TransactionTags
{
    /** Separator when multiple tags are set. */
    public const TAG_SEPARATOR = ',';

    /*#@+
     * Different value for tags column.
     *
     * Note that if it is a payment method, the tag name must match the payment type in Mollie Platform or there be
     * dragons.
     */
    public const TAG_BANKTRANSFER           = "banktransfer";
    public const TAG_BELFIUS                = "belfius";
    public const TAG_BITCOIN                = "bitcoin";
    public const TAG_CREDITCARD             = "creditcard";
    public const TAG_EPS                    = "eps";
    public const TAG_DIRECTDEBIT            = "directdebit";
    public const TAG_GIROPAY                = "giropay";
    public const TAG_IDEAL                  = "ideal";
    public const TAG_INGHOMEPAY             = "inghomepay";
    public const TAG_INTERNAL               = "internal";
    public const TAG_INTRA_COMPANY          = "intra_company";
    public const TAG_KBC                    = "kbc";
    public const TAG_KLARNA                 = "klarna";
    public const TAG_KLARNA_PAYLATER        = "klarnapaylater";
    public const TAG_KLARNA_SLICEIT         = "klarnasliceit";
    public const KLARNA_SUBTYPE_TAGS        = [self::TAG_KLARNA_PAYLATER, self::TAG_KLARNA_SLICEIT];
    public const TAG_MISTERCASH             = "mistercash";
    public const TAG_MYBANK                 = "mybank";
    public const TAG_PRZELEWY24             = "przelewy24";
    public const TAG_REFUNDS                = "refunds";
    public const TAG_OUTPAYMENT             = "outpayment";
    public const TAG_SOFORT                 = "sofort";
    public const TAG_TRANSFER               = "transfer";
    public const TAG_LEDGER_INVOICE_PAYMENT = "ledger_invoice_payment";
    /*#@-*/

    /**
     * Prepayment settlements are a specific type of intra-company bank transaction where funds are being moved
     * either between the Mollie BV and the Stichting Mollie Payments account, or vice-versa.
     */
    public const TAG_PREPAYMENT_SETTLEMENT_SENT     = "prepayment_settlement_sent";
    public const TAG_PREPAYMENT_SETTLEMENT_RECEIVED = "prepayment_settlement_received";
    public const TAG_FAILURE_PREPAYMENT_SETTLEMENT  = "failure_prepayment_settlement";

    /**
     * A transaction was made on the iDEAL bank account, however it was not an iDEAL transaction but rather a manual
     * transaction.
     */
    public const TAG_UNKNOWNIDEAL = "unknown";

    /**
     * A transaction was made on the iDEAL bank account, but the transaction was not known at the Mollie Application as
     * a successful transaction.
     */
    public const TAG_FAILUREIDEAL = "failure";

    /**
     * A transaction was made on the banktransfer account, however it couldn't be linked to an unpaid payment. Eg. the
     * reference is incorrect or the customer cancelled the payment.
     */
    public const TAG_UNKNOWNBANKTRANSFER = "unknownbanktransfer";

    /**
     * When a banktransfer comes in with a different amount than the Mollie settlement, it is split.
     * The transaction with the 'rest' amount gets this tag.
     */
    public const TAG_BANKTRANSFER_DIFFERENCE = "banktransfer_difference";

    /**
     * A transaction was made on the SOFORT Banking account, however it did not belong to a SOFORT Banking transaction
     * (e.g. no SOFORT transaction id or not found by Mollie).
     */
    public const TAG_UNKNOWNSOFORT = "unknownsofort";

    /**
     * A transaction was made on the SOFORT Banking account, however something was wrong with the transaction
     * (e.g. invalid amount, not paid in Mollie, double settled)
     */
    public const TAG_FAILURESOFORT = "failuresofort";

    /**
     * A transaction was made on the Mister Cash account, however it did not belong to a Mister Cash transaction
     * (e.g. no Mister Cash transaction id or not found by Mollie).
     */
    public const TAG_UNKNOWNMISTERCASH = "unknownmistercash";
    public const TAG_UNKNOWNEPS        = "unknowneps";
    public const TAG_UNKNOWNGIROPAY    = "unknowngiropay";
    public const TAG_UNKNOWNMYBANK     = "unknownmybank";
    public const TAG_UNKNOWNPRZELEWY24 = "unknownprzelewy24";

    /**
     * A transaction was made on the Mister Cash Banking account, however something was wrong with the transaction
     * (e.g. invalid amount, not paid in Mollie, double settled)
     */
    public const TAG_FAILUREMISTERCASH = "failuremistercash";
    public const TAG_FAILUREEPS        = "failureeps";
    public const TAG_FAILUREGIROPAY    = "failuregiropay";
    public const TAG_FAILUREMYBANK     = "failuremybank";
    public const TAG_FAILUREPRZELEWY24 = "failureprzelewy24";

    /**
     * A transaction was made on the Belfius Direct Net account, however it did not belong to a Belfius Direct Net
     * transaction (e.g. no Belfius Direct Net transaction id or not found by Mollie).
     */
    public const TAG_UNKNOWNBELFIUS = "unknownbelfius";

    /**
     * A transaction was made on the bitcoin account, however it couldn't be linked to an unpaid payment. Eg. the
     * reference is incorrect or the customer cancelled the payment.
     */
    public const TAG_UNKNOWNBITCOIN = "unknownbitcoin";

    /**
     * A transaction was made on the KBC account, however it did not belong to a KBC
     * transaction (e.g. no KBC transaction id or not found by Mollie).
     */
    public const TAG_UNKNOWNKBC = "unknownkbc";

    /** A transaction was made on the Klarna account, however it did not belong to an Klarna transaction. */
    public const TAG_UNKNOWNKLARNA = "unknownklarna";

    /** A transaction was made on the Klarna account, however something was wrong with the transaction. */
    public const TAG_FAILUREKLARNA = "failureklarna";

    /**
     * A transaction was made on the Belfius Direct Net account, however something was wrong with the transaction
     * (e.g. invalid amount, not paid in Mollie, double settled)
     */
    public const TAG_FAILUREBELFIUS = "failurebelfius";

    /**
     * A transaction was made on the KBC account, however something was wrong with the transaction
     * (e.g. invalid amount, not paid in Mollie, double settled)
     */
    public const TAG_FAILUREKBC = "failurekbc";

    /**
     * A transaction was made on the Home'Pay account, however it did not belong to a Home'Pay
     * transaction (e.g. no Home'Pay transaction id or not found by Mollie).
     */
    public const TAG_UNKNOWNINGHOMEPAY = "unknowning_homepay";

    /**
     * A transaction was made on the Home'Pay account, however something was wrong with the transaction
     * (e.g. invalid amount, not paid in Mollie, double settled)
     */
    public const TAG_FAILUREINGHOMEPAY = "failureing_homepay";

    /**
     * A transaction was made on the Direct Debit account, however it did not belong to a Direct Debit transaction
     * (e.g. no Direct Debit transaction id or not found by Mollie).
     */
    public const TAG_UNKNOWNDIRECTDEBIT = "unknowndirectdebit";

    /** Unknown transaction on the refund account */
    public const TAG_UNKNOWNREFUND = "unknownrefund";

    /** Unknown transaction on the outpayments account */
    public const TAG_UNKNOWNOUTPAYMENT = "unknownoutpayment";

    /**
     * A transaction was made on the Direct Debit account, however something was wrong with the transaction
     * (e.g. invalid amount, not paid in Mollie, double settled)
     */
    public const TAG_FAILUREDIRECTDEBIT = "failuredirectdebit";

    /** A storno on a Direct Debit transaction */
    public const TAG_STORNODIRECTDEBIT = "stornodirectdebit";

    /** Additional fees charged by the bank of the SDD debtor, in case of a mischarge. */
    public const TAG_STORNODIRECTDEBIT_COSTSEU = "stornodirectdebit_costsEU";

    /** A transaction was made on the creditcard account, however it did not belong to a creditcard transaction. */
    public const TAG_UNKNOWNCREDITCARD = "unknowncreditcard";

    /** A transaction was made on the creditcard account, however something was wrong with the transaction. */
    public const TAG_FAILURECREDITCARD = "failurecreditcard";

    /** A transaction was made on the Amex account, however it did not belong to an Amex transaction. */
    public const TAG_UNKNOWNAMEX = "unknownamex";

    /** A transaction was made on the Amex account, however something was wrong with the transaction. */
    public const TAG_FAILUREAMEX = "failureamex";

    /** Returned Refunds. */
    public const TAG_FAILUREREFUND = "failedrefund";

    /** Returned Outpayments. */
    public const TAG_FAILUREOUTPAYMENT = "failedoutpayment";

    /** Returned Transfer Payout. */
    public const TAG_FAILURETRANSFER = "failuretransfer";

    /** A merchant credit transfer either debited or credited (amount returned). */
    public const TAG_CREDITTRANSFERS = "credittransfers";

    /**
     * The transaction is a Valitor settlement, and the details have been retrieved from MCCS.
     *
     * Has a typing error, don't fuck / unfuck this up.
     */
    public const TAG_VALITOR_SETTLEMENT = "valitor_setttlement";

    /** Chargebacks and refunds done via Valitor will have the corresponding one of following tags; */
    public const TAG_CREDITCARD_REFUND  = "refunds_creditcard";
    public const TAG_VALITOR_CHARGEBACK = "valitor_chargeback";

    /**
     * The transaction is a Valitor settlement, and the details have not yet been retrieved from MCCS.
     *
     * Has a typing error, don't fuck / unfuck this up.
     */
    public const TAG_VALITOR_SETTLEMENT_UNSPECIFIED = "valitor_setttlement_unspecified";

    /**
     * The transaction covers one non-payment line from a Valitor specification. Each detail covers
     * multiple transactions. For example, a set of refunds or chargebacks.
     */
    public const TAG_VALITOR_DETAIL = "valitor_detail";

    /** unexpanded. */
    public const TAG_AMEX_SETTLEMENT_NEW = "amex_settlement_new";

    /** The transaction is an AMEX settlement and has been expanded. */
    public const TAG_AMEX_SETTLEMENT_EXPANDED = "amex_settlement_expanded";

    /** Tag to be used for batch transactions that represent PPro settlements. */
    public const TAG_PPRO_SETTLEMENT = 'ppro_settlement';

    /** The transaction is a PPRO settlement and has been expanded. */
    public const TAG_PPRO_SETTLEMENT_EXPANDED = "ppro_settlement_expanded";

    /** Tag to be used for batch transactions that represent Klarna settlements. */
    public const TAG_KLARNA_SETTLEMENT = 'klarna_settlement';

    /** The transaction is a Klarna settlement and has been expanded. */
    public const TAG_KLARNA_SETTLEMENT_EXPANDED = "klarna_settlement_expanded";

    /** The transaction is an AMEX-related one */
    public const TAG_AMEX_PAYMENT      = "amex_payment";
    public const TAG_AMEX_REFUND       = "amex_refund";
    public const TAG_AMEX_CHARGEBACK   = "amex_chargeback";
    public const TAG_AMEX_FEE_VARIABLE = "amex_fee_variable";
    public const TAG_AMEX_COSTS        = "amex_costs";

    /** The transaction is an PPRO-related one */
    public const TAG_PPRO_BALANCE      = "ppro_balance";
    public const TAG_PPRO_PAYMENT      = "ppro_payment";
    public const TAG_PPRO_REFUND       = "ppro_refund";
    public const TAG_PPRO_CHARGEBACK   = "ppro_chargeback";
    public const TAG_PPRO_FEE_VARIABLE = "ppro_fee_variable";
    public const TAG_PPRO_COSTS        = "ppro_costs";

    /** The transaction is an Klarna-related one */
    public const TAG_KLARNA_REFUND          = "klarna_refund";
    public const TAG_KLARNA_CHARGEBACK      = "klarna_chargeback";
    public const TAG_KLARNA_CORRECTION      = "klarna_correction";
    public const TAG_KLARNA_FEE             = "klarna_fee";
    public const TAG_KLARNA_FEE_DIFFERENCE  = "klarna_fee_difference"; // the difference with the expected fee
    public const TAG_KLARNA_FEE_DELAYED     = "klarna_fee_delayed"; // a fee that came in later than the
    public const TAG_KLARNA_ROLLING_RESERVE = "klarna_rolling_reserve"; // rolling reserve (holdback & release, repay)

    /** Payment method specific PPRO fees */
    public const TAG_PPRO_FEE_VARIABLE_BANCONTACT = "ppro_fee_variable_bancontact";
    public const TAG_PPRO_FEE_VARIABLE_EPS        = "ppro_fee_variable_eps";
    public const TAG_PPRO_FEE_VARIABLE_GIROPAY    = "ppro_fee_variable_giropay";
    public const TAG_PPRO_FEE_VARIABLE_IDEAL      = "ppro_fee_variable_ideal";
    public const TAG_PPRO_FEE_VARIABLE_MYBANK     = "ppro_fee_variable_mybank";
    public const TAG_PPRO_FEE_VARIABLE_PRZELEWY24 = "ppro_fee_variable_przelewy24";
    public const PPRO_VARIABLE_FEE_TAGS           = TransactionTransformer::PAYMENT_METHOD_FEE_TAG_MAP;

    /** Multi-currency transaction tags. */
    public const TAG_MC_FX_MARGIN                = "mc_fx_margin"; // Foreign currency exchange margin
    public const TAG_MC_EXCHANGE_RATE_DIFFERENCE = "mc_fx_rate_diff";
    public const TAG_MC_CHILD_TRANSACTION        = "mc_child";
    public const TAG_BANK                        = "bank";
    public const TAG_BANK_PPRO                   = "bankppro";
    public const TAG_ADYEN                       = "adyencc";

    /** Tag for recognized SEPA transactions. */
    public const TAG_SEPA = "sepa";

    /**
     * Tag for transactions that are handled and checked manually. All Mollie (not SMP) accounts
     * are checked manually for invoicing etc. This tag is used to explicitly indicate this agreed
     * upon behaviour. They do not need a registration to be seen by the finance team.
     */
    public const TAG_MANUAL_HANDLING = "manual";

    /** Tag for small bankaccount verification transactions. */
    public const TAG_BOARDING            = "boarding";
    public const MUTATIECODE_MAANDKOSTEN = "526";

    /** Seems to be used exclusively for iDEAL transactions via SEPA OVERBOEKING. */
    public const MUTATIECODE_IDEAL = "944";

    public const POSSIBLE_BANKACCOUNT_VERIFICATION_TAGS = [
        self::TAG_IDEAL,
        self::TAG_SOFORT,
        self::TAG_BANKTRANSFER,
        self::TAG_BELFIUS,
        self::TAG_KBC,
        self::TAG_INGHOMEPAY,
        self::TAG_MYBANK,
    ];

    public const SETTLEMENT_TAGS = [
        self::TAG_BANKTRANSFER,
        self::TAG_BELFIUS,
        self::TAG_BITCOIN,
        self::TAG_DIRECTDEBIT,
        self::TAG_EPS,
        self::TAG_GIROPAY,
        self::TAG_IDEAL,
        self::TAG_INGHOMEPAY,
        self::TAG_KBC,
        self::TAG_MISTERCASH,
        self::TAG_MYBANK,
        self::TAG_PRZELEWY24,
        self::TAG_REFUNDS,
        self::TAG_OUTPAYMENT,
        self::TAG_SOFORT,

        self::TAG_AMEX_PAYMENT,
        self::TAG_AMEX_REFUND,
        self::TAG_AMEX_CHARGEBACK,

        self::TAG_CREDITCARD,
        self::TAG_CREDITCARD_REFUND,
        self::TAG_VALITOR_CHARGEBACK,

        self::TAG_KLARNA,
        self::TAG_KLARNA_REFUND,
        self::TAG_KLARNA_CHARGEBACK,

        self::TAG_PPRO_PAYMENT,
        self::TAG_PPRO_REFUND,
        self::TAG_PPRO_CHARGEBACK,
    ];

    public const FAILED_SETTLEMENT_TAGS = [
        self::TAG_AMEX_PAYMENT => self::TAG_FAILUREAMEX,
        // no banktransfer
        self::TAG_BELFIUS => self::TAG_FAILUREBELFIUS,
        // no bitcoin
        self::TAG_CREDITCARD  => self::TAG_FAILURECREDITCARD,
        self::TAG_DIRECTDEBIT => self::TAG_FAILUREDIRECTDEBIT,
        self::TAG_EPS         => self::TAG_FAILUREEPS,
        self::TAG_GIROPAY     => self::TAG_FAILUREGIROPAY,
        self::TAG_IDEAL       => self::TAG_FAILUREIDEAL,
        self::TAG_INGHOMEPAY  => self::TAG_FAILUREINGHOMEPAY,
        self::TAG_KBC         => self::TAG_FAILUREKBC,
        self::TAG_KLARNA      => self::TAG_FAILUREKLARNA,
        self::TAG_MISTERCASH  => self::TAG_FAILUREMISTERCASH,
        self::TAG_MYBANK      => self::TAG_FAILUREMYBANK,
        self::TAG_OUTPAYMENT  => self::TAG_FAILUREOUTPAYMENT,
        self::TAG_PRZELEWY24  => self::TAG_FAILUREPRZELEWY24,
        self::TAG_REFUNDS     => self::TAG_FAILUREREFUND,
        self::TAG_SOFORT      => self::TAG_FAILURESOFORT,
    ];

    public const UNKNOWN_SETTLEMENT_TAGS = [
        self::TAG_AMEX_PAYMENT => self::TAG_UNKNOWNAMEX,
        self::TAG_BANKTRANSFER => self::TAG_UNKNOWNBANKTRANSFER,
        self::TAG_BELFIUS      => self::TAG_UNKNOWNBELFIUS,
        self::TAG_BITCOIN      => self::TAG_UNKNOWNBITCOIN,
        self::TAG_CREDITCARD   => self::TAG_UNKNOWNCREDITCARD,
        self::TAG_DIRECTDEBIT  => self::TAG_UNKNOWNDIRECTDEBIT,
        self::TAG_EPS          => self::TAG_UNKNOWNEPS,
        self::TAG_GIROPAY      => self::TAG_UNKNOWNGIROPAY,
        self::TAG_IDEAL        => self::TAG_UNKNOWNIDEAL,
        self::TAG_INGHOMEPAY   => self::TAG_UNKNOWNINGHOMEPAY,
        self::TAG_KBC          => self::TAG_UNKNOWNKBC,
        self::TAG_KLARNA       => self::TAG_UNKNOWNKLARNA,
        self::TAG_MISTERCASH   => self::TAG_UNKNOWNMISTERCASH,
        self::TAG_MYBANK       => self::TAG_UNKNOWNMYBANK,
        self::TAG_OUTPAYMENT   => self::TAG_UNKNOWNOUTPAYMENT,
        self::TAG_PRZELEWY24   => self::TAG_UNKNOWNPRZELEWY24,
        self::TAG_REFUNDS      => self::TAG_UNKNOWNREFUND,
        self::TAG_SOFORT       => self::TAG_UNKNOWNSOFORT,
    ];

    public const BANK_FEE_TAGS = [
        self::TAG_VALITOR_DETAIL,
        self::TAG_AMEX_FEE_VARIABLE,
        self::TAG_AMEX_COSTS,
        self::TAG_PPRO_FEE_VARIABLE,
        self::TAG_PPRO_FEE_VARIABLE_BANCONTACT,
        self::TAG_PPRO_FEE_VARIABLE_EPS,
        self::TAG_PPRO_FEE_VARIABLE_GIROPAY,
        self::TAG_PPRO_FEE_VARIABLE_MYBANK,
        self::TAG_PPRO_FEE_VARIABLE_PRZELEWY24,
        self::TAG_KLARNA_FEE,
        self::TAG_KLARNA_FEE_DIFFERENCE,
        self::TAG_KLARNA_FEE_DELAYED,
        self::TAG_PPRO_COSTS,
        self::TAG_BANK,
        self::TAG_BANK_PPRO,
        self::TAG_ADYEN,
    ];

    /**
     * @return string[]
     */
    public function getTags(): array;

    /**
     * @return string[]
     */
    public static function getAllTags(): array;

    /**
     * @param string[] $tags
     */
    public function setTags(array $tags): void;

    public function addTag(string ...$newTags): void;

    public function removeTag(string $tagToRemove): void;

    public function hasTag(string $tag): bool;

    public function hasAnyOfTags(array $tags): bool;

    /**
     * @return string[]
     */
    public function getTagData(): array;

    /**
     * @param string[] $tagData
     */
    public function setTagData(array $tagData = []): void;

    /**
     * @param string[] $tagData
     */
    public function addTagData(array $tagData = []): void;
}
