<?php

use Core\Time\TimeZones;

/**
 * Model_Banktransaction_Settlement
 *
 * ORM-model for bank_transactions_settlement table
 *
 * @author    Mollie <info@mollie.nl> Jul 22, 2014
 * @copyright Copyright (C) Mollie B.V.
 *
 * @property int                   $id                 Maps to bank_transactions_settlement.id, bigint(19) unsigned
 * @property int                   $banktransaction_id Maps to bank_transactions_settlement.banktransaction_id, bigint(19) unsigned
 * @property string                $transaction_id     Maps to bank_transactions_settlement.transaction_id, varchar(50)
 * @property string                $payment_method     Maps to bank_transactions_settlement.payment_method, varchar(30)
 * @property int                   $mollie_payment_id  Maps to bank_transactions_settlement.mollie_payment_id, bigint(19) unsigned
 * @property string|null           $created_at_utc     Maps to bank_transactions_settlement.created_at_utc, datetime
 * @property string|null           $updated_at_utc     Maps to bank_transactions_settlement.updated_at_utc, datetime
 * @property Model_Banktransaction $banktransaction    The Model_Banktransaction referenced by $banktransaction_id
 */
class Model_Banktransaction_Settlement extends Model_ORM
{
    protected $_model_name = __CLASS__;

    /** @var string */
    protected $_table_name = 'bank_transactions_settlement';
    /** @var array */
    protected $_table_columns = [
        'id', 'banktransaction_id', 'transaction_id', 'payment_method',
        'mollie_payment_id', 'created_at_utc', 'updated_at_utc',
    ];
    /** @var array */
    protected $_validations = [
        'banktransaction_id' => [true, FILTER_VALIDATE_INT, 'Settlement banktransaction required'],
        'transaction_id'     => [true, FILTER_DEFAULT,      'Settlement transaction_id required'],
        'mollie_payment_id'  => [true, FILTER_VALIDATE_INT, 'Settlement mollie_payment_id required'],
    ];
    /** @var array */
    protected $_relationships = [
        'banktransaction' => [
            'type'        => Model_ORM::BELONGS_TO,
            'model'       => 'Model_Banktransaction',
            'foreign_key' => 'banktransaction_id',
        ],
    ];

    /**
     * @param string $transaction_id
     * @param string $payment_method
     *
     * @throws Model_Exception
     *
     * @return self
     */
    public function fromTransaction(Model_Banktransaction $transaction, $transaction_id, $payment_method)
    {
        $this->banktransaction = $transaction;
        $this->payment_method  = $payment_method;
        $this->transaction_id  = $transaction_id;

        return $this;
    }

    public function getTransaction(): Model_Banktransaction
    {
        return $this->banktransaction;
    }

    public function getPaymentMethod(): string
    {
        return $this->payment_method;
    }

    public function getSupplierTransactionId(): string
    {
        return $this->transaction_id;
    }

    public function setMolliePaymentId(int $mollie_payment_id): void
    {
        $this->mollie_payment_id = $mollie_payment_id;
    }

    public function hasMolliePaymentId(): bool
    {
        return $this->mollie_payment_id !== null && $this->mollie_payment_id !== '' && ctype_digit($this->mollie_payment_id);
    }

    public function getMolliePaymentId(): int
    {
        if (!$this->hasMolliePaymentId()) {
            throw new LogicException('MolliePaymentId not set yet.');
        }

        return (int)$this->mollie_payment_id;
    }

    public function getCreatedAtUtc(): DateTimeImmutable
    {
        if ($this->created_at_utc === null) {
            throw new LogicException('Can\'t request created-at date if the object has not been loaded from the database.');
        }

        return DateTimeImmutable::createFromFormat('!' . Model_ORM::DATE_SQL, $this->created_at_utc, TimeZones::UTC());
    }

    public function getUpdatedAtUtc(): DateTimeImmutable
    {
        if ($this->updated_at_utc === null) {
            throw new LogicException('Can\'t request updated-at date if the object has not been loaded from the database.');
        }

        return DateTimeImmutable::createFromFormat('!' . Model_ORM::DATE_SQL, $this->updated_at_utc, TimeZones::UTC());
    }

    /**
     * {@inheritdoc}
     *
     * @param bool $force_save
     *
     * @return bool
     */
    public function save($force_save = false)
    {
        try {
            return parent::save($force_save);
        } catch (Mollie_Database_Exception_Query $e) {
            $mapper = new self($this->_db);

            if ($mapper->loadBy([
                "banktransaction_id" => $this->banktransaction_id,
                "transaction_id" => $this->transaction_id,
                "payment_method" => $this->payment_method,
                "mollie_payment_id" => $this->mollie_payment_id,
            ])) {
                apm_log_exception(new RuntimeException(sprintf(
                    'Had to reload settlement of transaction #%d because of concurrency issue. ' .
                        'This might have been happening before, we are logging this to see if it is still needed.',
                    $this->banktransaction_id
                )));

                /*
                 * In some cases, one chunck of transactions can succeed whilst at the second there is an exception.
                 * We need to be resilient in that case, check if the data is correct and then continue on.
                 */
                $this->setPrimaryKey($mapper->getPrimaryKey());
                $this->_object_changes = [];

                return true;
            }

            throw $e;
        }
    }
}
