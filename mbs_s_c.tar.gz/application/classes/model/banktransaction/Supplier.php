<?php

declare(strict_types=1);

namespace Model\Transaction;

use MyCLabs\Enum\Enum;

/**
 * @method static self ABN()
 * @method static self ADYEN()
 * @method static self AMEX()
 * @method static self BANCONTACT()
 * @method static self BELFIUS()
 * @method static self BITONIC()
 * @method static self DEUTSCHEBANK()
 * @method static self ING()
 * @method static self KBC()
 * @method static self KLARNA()
 * @method static self PPRO ()
 * @method static self RABOBANK()
 * @method static self SOFORT()
 * @method static self VALITOR()
 */
final class Supplier extends Enum
{
    private const ABN          = 'abn';
    private const ADYEN        = 'adyen';
    private const AMEX         = 'amex';
    private const BANCONTACT   = 'bancontact';
    private const BELFIUS      = 'belfius';
    private const BITONIC      = 'bitonic';
    private const DEUTSCHEBANK = 'deutschebank';
    private const ING          = 'ing';
    private const KBC          = 'kbc';
    private const KLARNA       = 'klarna';
    private const PPRO         = 'ppro';
    private const RABOBANK     = 'rabobank';
    private const SOFORT       = 'sofort';
    private const VALITOR      = 'valitor';
}
