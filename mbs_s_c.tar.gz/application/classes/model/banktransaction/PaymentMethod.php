<?php

declare(strict_types=1);

namespace Model\Transaction;

use MyCLabs\Enum\Enum;

/**
 * @method static self AMEX()
 * @method static self BANCONTACT()
 * @method static self BANK_TRANSFER()
 * @method static self BELFIUS ()
 * @method static self BITCOIN()
 * @method static self CREDITCARD()
 * @method static self DIRECT_DEBIT()
 * @method static self EPS()
 * @method static self GIROPAY()
 * @method static self IDEAL()
 * @method static self INGHOMEPAY()
 * @method static self KBC()
 * @method static self KLARNA_PAY_LATER()
 * @method static self KLARNA_SLICE_IT()
 * @method static self MYBANK()
 * @method static self P24()
 * @method static self SOFORT()
 */
final class PaymentMethod extends Enum
{
    protected const AMEX             = 'amex';
    protected const BANCONTACT       = 'bancontact';
    protected const BANK_TRANSFER    = 'banktransfer';
    protected const BELFIUS          = 'belfius';
    protected const BITCOIN          = 'bitcoin';
    protected const CREDITCARD       = 'creditcard';
    protected const DIRECT_DEBIT     = 'directdebit';
    protected const EPS              = 'eps';
    protected const GIROPAY          = 'giropay';
    protected const IDEAL            = 'ideal';
    protected const INGHOMEPAY       = 'inghomepay';
    protected const KBC              = 'kbc';
    protected const KLARNA_PAY_LATER = 'klarnapaylater';
    protected const KLARNA_SLICE_IT  = 'klarnasliceit';
    protected const MYBANK           = 'mybank';
    protected const P24              = 'przelewy24';
    protected const SOFORT           = 'sofort';

    /**
     * @return self[]
     */
    public static function getKlarnaTypes(): array
    {
        return [
            self::KLARNA_PAY_LATER(),
            self::KLARNA_SLICE_IT(),
        ];
    }

    public static function isKlarnaType(self $type): bool
    {
        foreach (self::getKlarnaTypes() as $listed_type) {
            if ($type->equals($listed_type)) {
                return true;
            }
        }

        return false;
    }
}
