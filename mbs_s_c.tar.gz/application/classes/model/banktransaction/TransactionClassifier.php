<?php

declare(strict_types=1);

namespace Model\Transaction;

use BankAccounts\BankAccount;
use BankAccounts\BankAccountRepository;
use Model\Transaction\PaymentMethod as Method;
use Model\Transaction\TransactionClassification as Classification;
use Model\Transaction\TransactionStatus as Status;
use Model\Transaction\TransactionTags as Tags;
use Model\Transaction\TransactionType as Type;
use Model_Banktransaction as Trx;
use Supplier\Mccs\Valitor\Settlement\Detail as ValitorSettlementDetail;
use function array_key_exists;
use function strtoupper;

class TransactionClassifier
{
    /** @var array|null */
    private static $simpleSettlementsTagMapping;

    /** @var Method[]|null */
    private static $simpleSettlementsFailureTagMapping;

    /**
     * @return Method[]
     */
    private static function getSimpleSettlementTagMapping(): array
    {
        return self::$simpleSettlementsTagMapping ?? self::$simpleSettlementsTagMapping = [
            Tags::TAG_AMEX_PAYMENT    => Method::AMEX(),
            Tags::TAG_BANKTRANSFER    => Method::BANK_TRANSFER(),
            Tags::TAG_BELFIUS         => Method::BELFIUS(),
            Tags::TAG_BITCOIN         => Method::BITCOIN(),
            Tags::TAG_CREDITCARD      => Method::CREDITCARD(),
            Tags::TAG_DIRECTDEBIT     => Method::DIRECT_DEBIT(),
            Tags::TAG_EPS             => Method::EPS(),
            Tags::TAG_GIROPAY         => Method::GIROPAY(),
            Tags::TAG_IDEAL           => Method::IDEAL(),
            Tags::TAG_INGHOMEPAY      => Method::INGHOMEPAY(),
            Tags::TAG_KBC             => Method::KBC(),
            Tags::TAG_KLARNA_PAYLATER => Method::KLARNA_PAY_LATER(),
            Tags::TAG_KLARNA_SLICEIT  => Method::KLARNA_SLICE_IT(),
            Tags::TAG_MISTERCASH      => Method::BANCONTACT(),
            Tags::TAG_MYBANK          => Method::MYBANK(),
            Tags::TAG_PRZELEWY24      => Method::P24(),
            Tags::TAG_SOFORT          => Method::SOFORT(),
        ];
    }

    private static function getSimpleSettlementFailureTagMapping(): array
    {
        return self::$simpleSettlementsFailureTagMapping ?? self::$simpleSettlementsFailureTagMapping = [
            Tags::TAG_FAILUREAMEX        => Method::AMEX(),
            Tags::TAG_FAILUREBELFIUS     => Method::BELFIUS(),
            Tags::TAG_FAILURECREDITCARD  => Method::CREDITCARD(),
            Tags::TAG_FAILUREDIRECTDEBIT => Method::DIRECT_DEBIT(),
            Tags::TAG_FAILUREEPS         => Method::EPS(),
            Tags::TAG_FAILUREGIROPAY     => Method::GIROPAY(),
            Tags::TAG_FAILUREIDEAL       => Method::IDEAL(),
            Tags::TAG_FAILUREINGHOMEPAY  => Method::INGHOMEPAY(),
            Tags::TAG_FAILUREKBC         => Method::KBC(),
            Tags::TAG_FAILUREMISTERCASH  => Method::BANCONTACT(),
            Tags::TAG_FAILUREMYBANK      => Method::MYBANK(),
            Tags::TAG_FAILUREPRZELEWY24  => Method::P24(),
            Tags::TAG_FAILURESOFORT      => Method::SOFORT(),
        ];
    }

    public static function classify(Trx $trx): Classification
    {
        if ($classification = self::getClassificationForSettlements($trx)) {
            return $classification;
        }

        if ($classification = self::getClassificationForFailedSettlements($trx)) {
            return $classification;
        }

        if ($classification = self::getClassificationForStornos($trx)) {
            return $classification;
        }

        if ($classification = self::getClassificationForRefunds($trx)) {
            return $classification;
        }

        if ($classification = self::getClassificationForChargebacks($trx)) {
            return $classification;
        }

        if ($classification = self::getClassificationForGeneralTypes($trx)) {
            return $classification;
        }

        if ($classification = self::getClassificationForFeesAndRollingReserve($trx)) {
            return $classification;
        }

        if ($classification = self::getClassificationForCurrencyConversion($trx)) {
            return $classification;
        }

        if ($classification = self::getClassificationForDifferences($trx)) {
            return $classification;
        }

        if ($classification = self::getClassificationForTransfersAndPrepayments($trx)) {
            return $classification;
        }

        if ($classification = self::getClassificationForBatches($trx)) {
            return $classification;
        }

        if ($classification = self::getClassificationForUnknownTransactions($trx)) {
            return $classification;
        }

        if ($classification = self::getClassificationFromChildTransactions($trx)) {
            return $classification;
        }

        return new Classification(null, null, null, null);
    }

    private static function getClassificationForSettlements(Trx $trx): ?Classification
    {
        if ($trx->isDebited()) {
            return null;
        }

        if ($trx->hasAnyOfTags([
            Tags::TAG_KLARNA_FEE,
            Tags::TAG_KLARNA_FEE_DIFFERENCE,
            Tags::TAG_KLARNA_FEE_DELAYED,
            Tags::TAG_FAILUREKLARNA,
        ])) {
            return null;
        }

        $type                     = $trx->hasTag(Tags::TAG_BOARDING) ? Type::VERIFICATION() : Type::SETTLEMENT();
        $settlementSuccessMapping = self::getSimpleSettlementTagMapping();

        $method = null;

        foreach ($trx->getTags() as $tag) {
            if (array_key_exists($tag, $settlementSuccessMapping)) {
                $method = $settlementSuccessMapping[$tag];

                return new Classification(
                    $type,
                    $method,
                    Status::OK(),
                    self::getSupplierForMethodAndBankAccount($method, $trx->getBankAccount())
                );
            }
        }

        return null;
    }

    private static function getClassificationForFailedSettlements(Trx $trx): ?Classification
    {
        if ($trx->isDebited()) {
            return null;
        }

        $settlementFailureMapping = self::getSimpleSettlementFailureTagMapping();

        if ($trx->hasAnyOfTags(array_keys($settlementFailureMapping))) {
            $method = $settlementFailureMapping[$trx->getTags()[0]];

            return new Classification(
                Type::SETTLEMENT(),
                $method,
                Status::FAILED(),
                self::getSupplierForMethodAndBankAccount($method, $trx->getBankAccount())
            );
        }

        if ($trx->hasTag(Tags::TAG_FAILUREKLARNA)) {
            $method = self::getMethodForKlarnaSubtype($trx);

            return new Classification(
                Type::SETTLEMENT(),
                $method,
                Status::FAILED(),
                Supplier::KLARNA()
            );
        }

        return null;
    }

    private static function getClassificationForStornos(Trx $trx): ?Classification
    {
        if ($trx->isCredited()) {
            return null;
        }

        if ($trx->hasTag(Tags::TAG_STORNODIRECTDEBIT)) {
            if (in_array(
                strtoupper($trx->getTagData()['reason_code'] ?? ''),
                ['MD06', 'MS02'] // maybe add 'MD01', 'SL01' ?
            )) {
                return new Classification(
                    Type::CHARGEBACK(),
                    Method::DIRECT_DEBIT(),
                    Status::OK(),
                    self::getSupplierForBankAccount($trx->getBankAccount())
                );
            }

            return new Classification(
                Type::SETTLEMENT(),
                Method::DIRECT_DEBIT(),
                Status::FAILED(),
                self::getSupplierForBankAccount($trx->getBankAccount())
            );
        }

        return null;
    }

    private static function getClassificationForRefunds(Trx $trx): ?Classification
    {
        if ($trx->hasTag(Tags::TAG_REFUNDS) && !$trx->hasTag(Tags::TAG_SEPA)) {
            return new Classification(
                Type::REFUND(),
                null,
                // Yes, failure ideal: \TransactionHandlers\Reporting\ReturnedRefundReporter
                $trx->hasTag(Tags::TAG_FAILUREIDEAL) ? Status::FAILED() : Status::OK(),
                self::getSupplierForBankAccount($trx->getBankAccount())
            );
        }

        if ($trx->hasTag(Tags::TAG_FAILUREREFUND)) {
            return new Classification(
                Type::REFUND(),
                null,
                Status::FAILED(),
                self::getSupplierForBankAccount($trx->getBankAccount())
            );
        }

        if ($trx->hasTag(Tags::TAG_PPRO_REFUND) && $trx->hasTag(Tags::TAG_PRZELEWY24)) {
            return new Classification(
                Type::REFUND(),
                Method::P24(),
                Status::OK(),
                Supplier::PPRO()
            );
        }

        if ($trx->hasTag(Tags::TAG_CREDITCARD_REFUND)) {
            return new Classification(
                Type::REFUND(),
                Method::CREDITCARD(),
                Status::OK(),
                Supplier::VALITOR()
            );
        }

        if ($trx->hasTag(Tags::TAG_AMEX_REFUND)) {
            return new Classification(
                Type::REFUND(),
                Method::AMEX(),
                Status::OK(),
                Supplier::AMEX()
            );
        }

        if ($trx->hasTag(Tags::TAG_KLARNA_REFUND)) {
            $subtype = self::getMethodForKlarnaSubtype($trx);

            return new Classification(
                Type::REFUND(),
                $subtype,
                $subtype === null ? Status::PENDING() : Status::OK(),
                Supplier::KLARNA()
            );
        }

        return null;
    }

    private static function getClassificationForChargebacks(Trx $trx): ?Classification
    {
        if ($trx->hasTag(Tags::TAG_VALITOR_CHARGEBACK)) {
            return new Classification(
                Type::CHARGEBACK(),
                Method::CREDITCARD(),
                Status::OK(),
                Supplier::VALITOR()
            );
        }

        if ($trx->hasTag(Tags::TAG_AMEX_CHARGEBACK)) {
            return new Classification(
                Type::CHARGEBACK(),
                Method::AMEX(),
                Status::OK(),
                Supplier::AMEX()
            );
        }

        if ($trx->hasTag(Tags::TAG_KLARNA_CHARGEBACK)) {
            $subtype = self::getMethodForKlarnaSubtype($trx);

            return new Classification(
                Type::CHARGEBACK(),
                $subtype,
                $subtype === null ? Status::PENDING() : Status::OK(),
                Supplier::KLARNA()
            );
        }

        return null;
    }

    private static function getClassificationForGeneralTypes(Trx $trx): ?Classification
    {
        if (BankAccountRepository::getInstance()->isOutpaymentBankAccount($trx->getBankAccountId())
            && $trx->getOutpaymentReference() !== null
        ) {
            return new Classification(
                Type::OUTPAYMENT(),
                null,
                $trx->isDebited() ? Status::OK() : Status::FAILED(),
                null
            );
        }

        if ($trx->getInvoiceNumber()) {
            return new Classification(
                Type::INVOICE(),
                null,
                Status::OK(),
                null
            );
        }

        if ($trx->getLedgerInvoiceNumber()) {
            $tag_data            = $trx->getTagData();
            $is_payment_accepted = $tag_data['is_payment_accepted'] ?? null;

            $status = Status::PENDING();

            if ($is_payment_accepted === true) {
                $status = Status::OK();
            } elseif ($is_payment_accepted === false) {
                $status = Status::FAILED();
            }

            return new Classification(
                Type::INVOICE(),
                null,
                $status,
                null
            );
        }

        if ($trx->hasTag(Tags::TAG_INTERNAL)) {
            return new Classification(
                Type::INTERNAL(),
                null,
                Status::OK(),
                null
            );
        }

        if ($trx->hasTag(Tags::TAG_INTRA_COMPANY)) {
            return new Classification(
                Type::INTRA_COMPANY(),
                null,
                Status::OK(),
                null
            );
        }

        if ($trx->isTransferSmpToBv()) {
            return new Classification(
                Type::PREPAYMENT(),
                null,
                Status::OK(),
                null
            );
        }

        if ($trx->hasTag(Tags::TAG_ADYEN)) {
            return new Classification(
                Type::BATCH(),
                Method::CREDITCARD(),
                Status::OK(),
                Supplier::ADYEN()
            );
        }

        if ($trx->hasTag(Tags::TAG_MANUAL_HANDLING)) {
            return new Classification(
                Type::MANUAL(),
                null,
                Status::OK(),
                null
            );
        }

        return null;
    }

    private static function getClassificationForFeesAndRollingReserve(Trx $trx): ?Classification
    {
        if ($trx->hasTag(Tags::TAG_PPRO_FEE_VARIABLE_EPS)) {
            return new Classification(
                Type::TRANSACTION_FEE(),
                Method::EPS(),
                Status::OK(),
                Supplier::PPRO()
            );
        }

        if ($trx->hasTag(Tags::TAG_PPRO_FEE_VARIABLE_BANCONTACT)) {
            return new Classification(
                Type::TRANSACTION_FEE(),
                Method::BANCONTACT(),
                Status::OK(),
                Supplier::PPRO()
            );
        }

        if ($trx->hasTag(Tags::TAG_PPRO_FEE_VARIABLE_GIROPAY)) {
            return new Classification(
                Type::TRANSACTION_FEE(),
                Method::GIROPAY(),
                Status::OK(),
                Supplier::PPRO()
            );
        }

        if ($trx->hasTag(Tags::TAG_PPRO_FEE_VARIABLE_MYBANK)) {
            return new Classification(
                Type::TRANSACTION_FEE(),
                Method::MYBANK(),
                Status::OK(),
                Supplier::PPRO()
            );
        }

        if ($trx->hasTag(Tags::TAG_PPRO_FEE_VARIABLE_PRZELEWY24)) {
            return new Classification(
                Type::TRANSACTION_FEE(),
                Method::P24(),
                Status::OK(),
                Supplier::PPRO()
            );
        }

        if ($trx->hasTag(Tags::TAG_BANK_PPRO)) {
            return new Classification(
                Type::SUPPLIER_FEE(),
                null,
                Status::OK(),
                Supplier::PPRO()
            );
        }

        if ($trx->hasTag(Tags::TAG_PPRO_FEE_VARIABLE)) {
            return new Classification(
                Type::TRANSACTION_FEE(),
                null,
                Status::OK(),
                Supplier::PPRO()
            );
        }

        if ($trx->hasTag(Tags::TAG_VALITOR_DETAIL)) {
            switch ($trx->getTagData()['settlement_key'] ?? null) {
                case ValitorSettlementDetail::DETAIL_KEY_ROLLING_RELEASE:
                case ValitorSettlementDetail::DETAIL_KEY_ROLLING_RESERVE:
                    return new Classification(
                        Type::ROLLING_RESERVE(),
                        null,
                        Status::OK(),
                        Supplier::VALITOR()
                    );

                case ValitorSettlementDetail::DETAIL_KEY_REFUND:
                    return new Classification(
                        Type::REFUND(),
                        Method::CREDITCARD(),
                        Status::OK(),
                        Supplier::VALITOR()
                    );

                case ValitorSettlementDetail::DETAIL_KEY_CHARGEBACK:
                case ValitorSettlementDetail::DETAIL_KEY_RE_PRESENTMENTS:
                case ValitorSettlementDetail::DETAIL_KEY_REVERSALS:
                    return new Classification(
                        Type::CHARGEBACK(),
                        Method::CREDITCARD(),
                        Status::OK(),
                        Supplier::VALITOR()
                    );

                case ValitorSettlementDetail::DETAIL_KEY_MERCHANT_SERVICE_CHARGES:
                case ValitorSettlementDetail::DETAIL_KEY_COMMISSION_HIGH_RISK:
                case ValitorSettlementDetail::DETAIL_KEY_COMMISSION_LOW_RISK:
                case ValitorSettlementDetail::DETAIL_KEY_COMMISSION_MEDIUM_RISK:
                case ValitorSettlementDetail::DETAIL_KEY_COMMISSION_LOW_AMOUNTS:
                case ValitorSettlementDetail::DETAIL_KEY_CHARGEBACK_FEE_AGENT:
                case ValitorSettlementDetail::DETAIL_KEY_CHARGEBACK_FEE_VALITOR:
                case ValitorSettlementDetail::DETAIL_KEY_TRANSACTION_FEE_SETTLED:
                case ValitorSettlementDetail::DETAIL_KEY_TRANSACTION_FEE_UNSETTLED:
                    return new Classification(
                        Type::TRANSACTION_FEE(),
                        Method::CREDITCARD(),
                        Status::OK(),
                        Supplier::VALITOR()
                    );

                case ValitorSettlementDetail::DETAIL_KEY_REGISTRATION_FEE:
                case ValitorSettlementDetail::DETAIL_KEY_SWIFT_FEE:
                case ValitorSettlementDetail::DETAIL_KEY_SCHEME_FEE:
                    return new Classification(
                        Type::SUPPLIER_FEE(),
                        Method::CREDITCARD(),
                        Status::OK(),
                        Supplier::VALITOR()
                    );

                default:
                    return new Classification(
                        Type::UNKNOWN(),
                        null,
                        Status::OK(),
                        Supplier::VALITOR()
                    );
            }
        }

        if ($trx->hasTag(Tags::TAG_STORNODIRECTDEBIT_COSTSEU)) {
            return new Classification(
                Type::TRANSACTION_FEE(),
                Method::DIRECT_DEBIT(),
                Status::OK(),
                self::getSupplierForMethodAndBankAccount(Method::DIRECT_DEBIT(), $trx->getBankAccount())
            );
        }

        if ($trx->hasTag(Tags::TAG_AMEX_FEE_VARIABLE)) {
            return new Classification(
                Type::TRANSACTION_FEE(),
                Method::AMEX(),
                Status::OK(),
                Supplier::AMEX()
            );
        }

        if ($trx->hasTag(Tags::TAG_AMEX_COSTS)) {
            return new Classification(
                Type::SUPPLIER_FEE(),
                Method::AMEX(),
                Status::OK(),
                Supplier::AMEX()
            );
        }

        if ($trx->hasTag(Tags::TAG_KLARNA_FEE)) {
            $subtype = self::getMethodForKlarnaSubtype($trx);

            return new Classification(
                Type::TRANSACTION_FEE(),
                $subtype,
                Status::OK(),
                Supplier::KLARNA()
            );
        }

        if ($trx->hasTag(Tags::TAG_KLARNA_FEE_DELAYED)) {
            return new Classification(
                Type::TRANSACTION_FEE(),
                null,
                Status::OK(),
                Supplier::KLARNA()
            );
        }

        if ($trx->hasTag(Tags::TAG_KLARNA_ROLLING_RESERVE)) {
            return new Classification(
                Type::ROLLING_RESERVE(),
                null,
                Status::OK(),
                Supplier::KLARNA()
            );
        }

        // and the more general one
        if ($trx->isBankingFee()) {
            return new Classification(
                Type::SUPPLIER_FEE(),
                null,
                Status::OK(),
                self::getSupplierForBankAccount($trx->getBankAccount())
            );
        }

        return null;
    }

    private static function getClassificationForCurrencyConversion(Trx $trx): ?Classification
    {
        if (!$trx->hasAnyOfTags([Tags::TAG_MC_FX_MARGIN, Tags::TAG_MC_EXCHANGE_RATE_DIFFERENCE])) {
            return null;
        }

        $method = null;

        if ($trx->hasParentTransaction()) {
            foreach ($trx->getParentTransaction()->getChildTransactions() as $child) {
                if ($child->hasType()
                    && (
                        $child->getType()->equals(Type::SETTLEMENT())
                        || $child->getType()->equals(Type::REFUND())
                    )
                ) {
                    $method = $child->getPaymentMethod();

                    break;
                }
            }
        }

        if ($trx->hasTag(Tags::TAG_MC_FX_MARGIN)) {
            return new Classification(
                Type::FX_MARGIN(),
                $method,
                Status::OK(),
                self::getSupplierForMethodAndBankAccount($method, $trx->getBankAccount())
            );
        }

        if ($trx->hasTag(Tags::TAG_MC_EXCHANGE_RATE_DIFFERENCE)) {
            return new Classification(
                Type::FX_DIFFERENCE(),
                $method,
                Status::OK(),
                self::getSupplierForMethodAndBankAccount($method, $trx->getBankAccount())
            );
        }

        return null;
    }

    private static function getClassificationForDifferences(Trx $trx): ?Classification
    {
        // Differences that are too large we mark as unknown and return to the consumer.
        if ($trx->hasTag(Tags::TAG_BANKTRANSFER_DIFFERENCE) && !$trx->hasTag(Tags::TAG_UNKNOWNBANKTRANSFER)) {
            return new Classification(
                Type::SETTLEMENT_DIFFERENCE(),
                Method::BANK_TRANSFER(),
                Status::OK(),
                null
            );
        }

        if ($trx->hasTag(Tags::TAG_KLARNA_FEE_DIFFERENCE)) {
            $method = null;

            foreach ($trx->getParentTransaction()->getChildTransactions() as $child) {
                if ($child->hasType() && $child->getType()->equals(Type::TRANSACTION_FEE())) {
                    $method = $child->getPaymentMethod();

                    break;
                }
            }

            return new Classification(
                Type::FEE_DIFFERENCE(),
                $method,
                Status::OK(),
                Supplier::KLARNA()
            );
        }

        return null;
    }

    private static function getClassificationForTransfersAndPrepayments(Trx $trx): ?Classification
    {
        if ($trx->hasTag(Tags::TAG_TRANSFER)) {
            return new Classification(
                Type::TRANSFER(),
                null,
                Status::OK(),
                null
            );
        }

        if ($trx->hasTag(Tags::TAG_FAILURETRANSFER)) {
            return new Classification(
                Type::TRANSFER(),
                null,
                Status::FAILED(),
                null
            );
        }

        if ($trx->hasAnyOfTags([
            Tags::TAG_PREPAYMENT_SETTLEMENT_SENT,
            Tags::TAG_PREPAYMENT_SETTLEMENT_RECEIVED,
        ])) {
            return new Classification(
                Type::PREPAYMENT(),
                null,
                Status::OK(),
                null
            );
        }

        if ($trx->hasTag(Tags::TAG_FAILURE_PREPAYMENT_SETTLEMENT)) {
            return new Classification(
                Type::PREPAYMENT(),
                null,
                Status::FAILED(),
                null
            );
        }

        return null;
    }

    private static function getClassificationForBatches(Trx $trx): ?Classification
    {
        if ($trx->hasTag(Tags::TAG_AMEX_SETTLEMENT_NEW)) {
            return new Classification(
                Type::BATCH(),
                Method::AMEX(),
                Status::PENDING(),
                Supplier::AMEX()
            );
        }

        if ($trx->hasTag(Tags::TAG_AMEX_SETTLEMENT_EXPANDED)) {
            return new Classification(
                Type::BATCH(),
                Method::AMEX(),
                Status::SPLIT(),
                Supplier::AMEX()
            );
        }

        if ($trx->hasTag(Tags::TAG_KLARNA_SETTLEMENT)) {
            return new Classification(
                Type::BATCH(),
                null,
                Status::PENDING(),
                Supplier::KLARNA()
            );
        }

        if ($trx->hasTag(Tags::TAG_KLARNA_SETTLEMENT_EXPANDED)) {
            return new Classification(
                Type::BATCH(),
                null,
                Status::SPLIT(),
                Supplier::KLARNA()
            );
        }

        if ($trx->hasTag(Tags::TAG_PPRO_SETTLEMENT)) {
            return new Classification(
                Type::BATCH(),
                null,
                Status::PENDING(),
                Supplier::PPRO()
            );
        }

        if ($trx->hasTag(Tags::TAG_PPRO_SETTLEMENT_EXPANDED)) {
            return new Classification(
                Type::BATCH(),
                null,
                Status::SPLIT(),
                Supplier::PPRO()
            );
        }

        if ($trx->hasTag(Tags::TAG_SEPA)) {
            return new Classification(
                Type::BATCH(),
                null,
                $trx->countChildTransactions() === 0 ? Status::PENDING() : Status::SPLIT(),
                self::getSupplierForMethodAndBankAccount(null, $trx->getBankAccount())
            );
        }

        if ($trx->hasTag(Tags::TAG_VALITOR_SETTLEMENT_UNSPECIFIED)) {
            return new Classification(
                Type::BATCH(),
                Method::CREDITCARD(),
                Status::PENDING(),
                Supplier::VALITOR()
            );
        }

        if ($trx->hasTag(Tags::TAG_VALITOR_SETTLEMENT)) {
            return new Classification(
                Type::BATCH(),
                Method::CREDITCARD(),
                Status::SPLIT(),
                Supplier::VALITOR()
            );
        }

        return null;
    }

    private static function getClassificationForUnknownTransactions(Trx $trx): ?Classification
    {
        if ($trx->hasAnyOfTags(Tags::UNKNOWN_SETTLEMENT_TAGS)) {
            $status = Status::PENDING();

            foreach ($trx->getRegistrations() as $registration) {
                if ($registration->isHandled()) {
                    $status = Status::OK();

                    break;
                }
            }

            return new Classification(Type::UNKNOWN(), null, $status, null);
        }

        return null;
    }

    private static function getClassificationFromChildTransactions(Trx $trx): ?Classification
    {
        if ($trx->getTags() === [] && $trx->countChildTransactions() > 0) {
            foreach ($trx->getChildTransactions() as $child) {
                if ($child->hasType()
                    && (
                        $child->getType()->equals(Type::SETTLEMENT())
                        || $child->getType()->equals(Type::REFUND())
                        || $child->getType()->equals(Type::TRANSACTION_FEE())
                    )
                ) {
                    return new Classification(
                        $child->getType(),
                        $child->hasPaymentMethod() ? $child->getPaymentMethod() : null,
                        Status::SPLIT(),
                        $child->hasSupplier() ? $child->getSupplier() : null
                    );
                }
            }
        }

        return null;
    }

    private static function getSupplierForMethodAndBankAccount(?Method $method, BankAccount $account): ?Supplier
    {
        switch ($method === null ? null : $method->getValue()) {
            case Method::AMEX()->getValue():
                return Supplier::AMEX();

            case Method::BANCONTACT()->getValue():
            case Method::EPS()->getValue():
            case Method::GIROPAY()->getValue():
            case Method::MYBANK()->getValue():
            case Method::P24()->getValue():
                return Supplier::PPRO();

            case Method::BANK_TRANSFER()->getValue():
                return null;

            case Method::BELFIUS()->getValue():
                return Supplier::BELFIUS();

            case Method::BITCOIN()->getValue():
                return Supplier::BITONIC();

            case Method::CREDITCARD()->getValue():
                return Supplier::VALITOR();

            case Method::INGHOMEPAY()->getValue():
                return Supplier::ING();

            case Method::KBC()->getValue():
                return Supplier::KBC();

            case Method::KLARNA_PAY_LATER()->getValue():
            case Method::KLARNA_SLICE_IT()->getValue():
                return Supplier::KLARNA();

            case Method::SOFORT()->getValue():
                return Supplier::SOFORT();

            case Method::DIRECT_DEBIT()->getValue():
            case Method::IDEAL()->getValue():
            default:
                return self::getSupplierForBankAccount($account);
        }
    }

    private static function getSupplierForBankAccount(BankAccount $account): ?Supplier
    {
        switch ($account::getBankBic()) {
            case 'ABNANL2A':
                return Supplier::ABN();

            case 'RABONL2U':
                return Supplier::RABOBANK();

            case 'INGBNL2A':
                return Supplier::ING();

            case 'DEUTNL2A':
            case 'DEUTFRPP':
            case 'DEUTPLPX':
            case 'DEUTBEBE':
            case 'DEUTDEFF':
                return Supplier::DEUTSCHEBANK();
        }

        return null;
    }

    private static function getMethodForKlarnaSubtype(Trx $trx): ?Method
    {
        if ($trx->hasTag(Tags::TAG_KLARNA_PAYLATER)) {
            return Method::KLARNA_PAY_LATER();
        }

        if ($trx->hasTag(Tags::TAG_KLARNA_SLICEIT)) {
            return Method::KLARNA_SLICE_IT();
        }

        return null;
    }
}
