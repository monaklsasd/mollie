<?php

declare(strict_types=1);

namespace Model\Transaction;

use MyCLabs\Enum\Enum;

/**
 * @method static self UNKNOWN()
 * @method static self INTERNAL()
 * @method static self INTRA_COMPANY()
 * @method static self MANUAL ()
 * @method static self BATCH()
 * @method static self SETTLEMENT()
 * @method static self REFUND()
 * @method static self CHARGEBACK()
 * @method static self INVOICE()
 * @method static self OUTPAYMENT()
 * @method static self PREPAYMENT()
 * @method static self TRANSFER()
 * @method static self VERIFICATION()
 * @method static self SUPPLIER_FEE()
 * @method static self TRANSACTION_FEE()
 * @method static self ROLLING_RESERVE()
 * @method static self FX_MARGIN()
 * @method static self SETTLEMENT_DIFFERENCE()
 * @method static self FEE_DIFFERENCE()
 * @method static self FX_DIFFERENCE()
 */
final class TransactionType extends Enum
{
    /*
     * General types
     */
    protected const UNKNOWN       = 'unknown';
    protected const INTERNAL      = 'internal';
    protected const INTRA_COMPANY = 'intracompany';
    protected const MANUAL        = 'manual';
    protected const BATCH         = 'batch';

    /*
     * Settlement types
     */
    protected const SETTLEMENT = 'settlement';
    protected const REFUND     = 'refund';
    protected const CHARGEBACK = 'chargeback';

    /*
     * Merchant types
     */
    protected const INVOICE      = 'invoice';
    protected const OUTPAYMENT   = 'outpayment';
    protected const PREPAYMENT   = 'prepayment';
    protected const TRANSFER     = 'transfer';
    protected const VERIFICATION = 'verification';

    /*
     * Supplier types
     */
    protected const SUPPLIER_FEE    = 'supplierfee';
    protected const TRANSACTION_FEE = 'transactionfee';
    protected const ROLLING_RESERVE = 'rollingreserve';

    /*
     * Currency conversion types
     */
    protected const FX_MARGIN = 'fxmargin';

    /*
     * Difference types
     */
    protected const SETTLEMENT_DIFFERENCE = 'settlementdifference';
    protected const FEE_DIFFERENCE        = 'feedifference';
    protected const FX_DIFFERENCE         = 'fxdifference';

    /**
     * @return self[]
     */
    public static function getGeneralTypes(): array
    {
        return [
            self::UNKNOWN(),
            self::INTERNAL(),
            self::INTRA_COMPANY(),
            self::MANUAL(),
            self::BATCH(),
        ];
    }

    /**
     * @return self[]
     */
    public static function getSettlementTypes(): array
    {
        return [
            self::SETTLEMENT(),
            self::REFUND(),
            self::CHARGEBACK(),
        ];
    }

    public static function getMerchantTypes(): array
    {
        return [
            self::INVOICE(),
            self::OUTPAYMENT(),
            self::PREPAYMENT(),
            self::TRANSFER(),
            self::VERIFICATION(),
        ];
    }

    /**
     * @return self[]
     */
    public static function getSupplierTypes(): array
    {
        return [
            self::SUPPLIER_FEE(),
            self::TRANSACTION_FEE(),
            self::ROLLING_RESERVE(),
        ];
    }

    /**
     * @return self[]
     */
    public static function getCurrencyConversionTypes(): array
    {
        return [
            self::FX_MARGIN(),
        ];
    }

    /**
     * @return self[]
     */
    public static function getDifferenceTypes(): array
    {
        return [
            self::SETTLEMENT_DIFFERENCE(),
            self::FEE_DIFFERENCE(),
            self::FX_DIFFERENCE(),
        ];
    }

    public static function isGeneralType(self $type): bool
    {
        foreach (self::getGeneralTypes() as $listed_type) {
            if ($type->equals($listed_type)) {
                return true;
            }
        }

        return false;
    }

    public static function isSettlementType(self $type): bool
    {
        foreach (self::getSettlementTypes() as $listed_type) {
            if ($type->equals($listed_type)) {
                return true;
            }
        }

        return false;
    }

    public static function isMerchantType(self $type): bool
    {
        foreach (self::getMerchantTypes() as $listed_type) {
            if ($type->equals($listed_type)) {
                return true;
            }
        }

        return false;
    }

    public static function isSupplierType(self $type): bool
    {
        foreach (self::getSupplierTypes() as $listed_type) {
            if ($type->equals($listed_type)) {
                return true;
            }
        }

        return false;
    }

    public static function isCurrencyConversionType(self $type): bool
    {
        foreach (self::getCurrencyConversionTypes() as $listed_type) {
            if ($type->equals($listed_type)) {
                return true;
            }
        }

        return false;
    }

    public static function isDifferenceType(self $type): bool
    {
        foreach (self::getDifferenceTypes() as $listed_type) {
            if ($type->equals($listed_type)) {
                return true;
            }
        }

        return false;
    }
}
