<?php

declare(strict_types=1);

namespace Model\Transaction;

use Core\Php\Reflection;
use InvalidArgumentException;
use Model_Exception;
use function array_search;
use function in_array;
use function is_array;

/**
 * @property string|null $tags
 * @property string|null $tag_data
 */
trait HasTransactionTags
{
    /**
     * With the move to transaction properties tags are being read from A LOT more
     * cache them to prevent excessive expensive operations.
     *
     * @var string[]|null
     */
    private $tags_cache;

    abstract public function getPrimaryKey();

    abstract protected function reclassify(): void;

    public function getTags(): array
    {
        if ($this->tags_cache === null) {
            if ($this->tags === null) {
                $this->tags_cache = [];
            } else {
                $this->tags_cache = array_filter(explode(TransactionTags::TAG_SEPARATOR, $this->tags));
            }
        }

        return $this->tags_cache;
    }

    public static function getAllTags(): array
    {
        $tags = Reflection::getClassConstantsWithPrefix(__CLASS__, 'TAG_');
        unset($tags[array_search(TransactionTags::TAG_SEPARATOR, $tags, true)]);

        asort($tags);

        return $tags;
    }

    public function setTags(array $tags): void
    {
        foreach ($tags as $tag) {
            if (strpos($tag, TransactionTags::TAG_SEPARATOR) !== false) {
                throw new InvalidArgumentException(sprintf(
                    'Tags can not contain the separator character (%s); got tag %s.',
                    ', ',
                    $tag
                ));
            }
        }

        $this->tags_cache = array_unique($tags);
        $this->tags       = implode(TransactionTags::TAG_SEPARATOR, $this->tags_cache);
        $this->reclassify();
    }

    public function addTag(string ...$newTags): void
    {
        $tags = $this->getTags();

        foreach ($newTags as $tag) {
            $tags[] = $tag;
        }

        $this->setTags($tags);
    }

    public function removeTag(string $tagToRemove): void
    {
        $new_tags = array_filter($this->getTags(), static function (string $tag) use ($tagToRemove) {
            return $tag !== $tagToRemove;
        });

        $this->setTags($new_tags);
    }

    public function hasTag(string $tag): bool
    {
        return in_array($tag, $this->getTags(), true);
    }

    public function hasAnyOfTags(array $tags): bool
    {
        $intersection = array_intersect($tags, $this->getTags());

        return count($intersection) > 0;
    }

    public function getTagData(): array
    {
        if ($this->tag_data === null || $this->tag_data === '') {
            return [];
        }

        $tagData = @unserialize($this->tag_data, ['allowed_classes' => []]);

        if (!is_array($tagData)) {
            // Legacy, sepa batch references were stored directly on the property.
            if (preg_match('/[0-9a-f]{32,}/i', $this->tag_data)) {
                $this->setTagData(['sepa_batch_reference' => mb_strtolower($this->tag_data)]);

                return $this->getTagData();
            }

            throw new Model_Exception("Failed to unserialize tag data for transaction #{$this->getPrimaryKey()}. Tag data was: {$this->tag_data}");
        }

        return $tagData;
    }

    public function setTagData(array $tagData = []): void
    {
        if (!empty($tagData) && $serialized_tag_data = serialize($tagData)) {
            $this->tag_data = $serialized_tag_data;
        } else {
            $this->tag_data = null;
        }
    }

    public function addTagData(array $tagData = []): void
    {
        $this->setTagData(array_merge($this->getTagData(), $tagData));
    }
}
