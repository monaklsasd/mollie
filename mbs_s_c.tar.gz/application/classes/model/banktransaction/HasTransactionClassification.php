<?php

declare(strict_types=1);

namespace Model\Transaction;

use Model_Banktransaction;

trait HasTransactionClassification
{
    /** @var TransactionClassification|null */
    private $classificationCache;

    /**
     * @deprecated Not actually deprecated, but still experimental.
     */
    public function hasType(): bool
    {
        return $this->getClassification()->getType() !== null;
    }

    /**
     * @deprecated Not actually deprecated, but still experimental.
     */
    public function getType(): TransactionType
    {
        return $this->getClassification()->getType();
    }

    /**
     * @deprecated Not actually deprecated, but still experimental.
     */
    public function hasPaymentMethod(): bool
    {
        return $this->getClassification()->getPaymentMethod() !== null;
    }

    /**
     * @deprecated Not actually deprecated, but still experimental.
     */
    public function getPaymentMethod(): ?PaymentMethod
    {
        return $this->getClassification()->getPaymentMethod();
    }

    /**
     * @deprecated Not actually deprecated, but still experimental.
     */
    public function hasStatus(): bool
    {
        return $this->getClassification()->getStatus() !== null;
    }

    /**
     * @deprecated Not actually deprecated, but still experimental.
     */
    public function getStatus(): TransactionStatus
    {
        return $this->getClassification()->getStatus();
    }

    /**
     * @deprecated Not actually deprecated, but still experimental.
     */
    public function hasSupplier(): bool
    {
        return $this->getClassification()->getSupplier() !== null;
    }

    /**
     * @deprecated Not actually deprecated, but still experimental.
     */
    public function getSupplier(): Supplier
    {
        return $this->getClassification()->getSupplier();
    }

    private function getClassification(): TransactionClassification
    {
        if ($this->classificationCache === null && $this instanceof Model_Banktransaction) {
            $this->classificationCache = TransactionClassifier::classify($this);
        }

        return $this->classificationCache;
    }

    /**
     * Clear classification cache. This needs to be used after changing the tags, registrations, and related transactions.
     *
     * When the classification are actual properties this can be removed.
     */
    public function reclassify(): void
    {
        $this->classificationCache = null;
    }
}
