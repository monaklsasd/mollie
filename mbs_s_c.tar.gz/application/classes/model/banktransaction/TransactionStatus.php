<?php

declare(strict_types=1);

namespace Model\Transaction;

use MyCLabs\Enum\Enum;

/**
 * @method static self OK()
 * @method static self FAILED()
 * @method static self PENDING()
 * @method static self SPLIT()
 */
final class TransactionStatus extends Enum
{
    /** General statuses */
    protected const OK      = 'ok';
    protected const FAILED  = 'failed';
    protected const PENDING = 'pending';
    protected const SPLIT   = 'split';
}
