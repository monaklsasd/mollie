<?php

declare(strict_types=1);

namespace Model\Transaction;

class TransactionClassification
{
    /** @var TransactionType|null */
    private $type;

    /** @var PaymentMethod|null */
    private $paymentMethod;

    /** @var TransactionStatus|null */
    private $status;

    /** @var Supplier|null */
    private $supplier;

    public function __construct(
        ?TransactionType $type,
        ?PaymentMethod $paymentMethod,
        ?TransactionStatus $status,
        ?Supplier $supplier
    ) {
        $this->type          = $type;
        $this->paymentMethod = $paymentMethod;
        $this->status        = $status;
        $this->supplier      = $supplier;
    }

    public function getType(): ?TransactionType
    {
        return $this->type;
    }

    public function getPaymentMethod(): ?PaymentMethod
    {
        return $this->paymentMethod;
    }

    public function getStatus(): ?TransactionStatus
    {
        return $this->status;
    }

    public function getSupplier(): ?Supplier
    {
        return $this->supplier;
    }
}
