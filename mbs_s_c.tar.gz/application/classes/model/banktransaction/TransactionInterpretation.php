<?php

declare(strict_types=1);

namespace Model\Transaction;

use BankAccounts\Mollie\CheckingAccount;
use BankAccounts\Smp\AbnAmroOutpaymentsAccount;
use BankAccounts\Smp\BancontactAccount;
use BankAccounts\Smp\DeutscheBankDutchDirectDebitAccount;
use BankAccounts\Smp\DeutscheBankGermanDirectDebitAccount;
use BankAccounts\Smp\DirectDebitAbnAccount;
use BankAccounts\Smp\DirectDebitRabobankAccount;
use BankAccounts\Smp\FrenchBankTransferAccount;
use BankAccounts\Smp\GermanBankTransferAccount;
use BankAccounts\Smp\IdealIngAccount;
use BankAccounts\Smp\KbcAccount;
use BankAccounts\Smp\OldBancontactAccount;
use BankAccounts\Smp\OldDirectDebitAccount;
use BankAccounts\Smp\RabobankOutpaymentsAccount;
use Core\Strings;
use Helper_Banktransaction_Matching;
use Model_Banktransaction;
use function in_array;
use function strlen;

trait TransactionInterpretation
{
    abstract public function getBankAccountId(): int;

    abstract public function getParentTransaction(): ?Model_Banktransaction;

    abstract public function countChildTransactions(): int;

    abstract public function getDescription(): ?string;

    abstract public function getOffsetAccountNumber(): ?string;

    abstract public function getOffsetAccountName(): ?string;

    abstract public function isCredited(): bool;

    abstract public function isDebited(): bool;

    abstract public function hasTag(string $tag): bool;

    abstract public function hasAnyOfTags(array $tags): bool;

    /**
     * @return string|string[]
     */
    abstract public function getTagData(): array;

    abstract public function setTagData(array $tagData = []): void;

    /**
     * Get the invoice number referenced in this transaction. If no invoice number is found, this method will return
     * NULL.
     */
    public function getInvoiceNumber(): ?string
    {
        /*
         * Invoices always get paid to our checking account. No need to search the description if the transaction
         * did not happen on this account.
         */
        if ($this->getBankAccountId() !== CheckingAccount::getId()) {
            return null;
        }

        /*
         * Either the customer paid us, or
         */
        if ($this->isDebited() && stripos((string)$this->getDescription(), 'CREDITNOTA') === false) {
            return null;
        }

        /*
         * Replace any iDEAL transaction numbers, they fuck everything up.
         *
         * "003000" + 10 digits (16 digits).
         */
        $description = preg_replace('!003000\d{10}!', '', (string)$this->getDescription());

        /*
         * First check if there is a real invoice number.
         *
         * Specs: must be yyyy.nnnnn where n >= 10000
         */
        if (preg_match('!(20[12]\d\.[1-9]\d{4,})!', $description, $matches)) {
            // OK customer can type in a invoice no.
            return (string)$matches[1];
        }

        /*
         * Then check if there is a real invoice number sans dot
         *
         * Specs: must be yyyynnnnn where yyyy <= current year and n >= 10000
         */
        if (preg_match('!(20[12]\d)([1-9]\d{4,})!', $description, $matches)) {
            if (strlen($matches[2]) <= 7 && $matches[1] <= date('Y')) {
                // Well okay, dots are hard to type in admittedly.
                return sprintf('%s.%s', $matches[1], $matches[2]);
            }
        }

        return null;
    }

    public function getLedgerInvoiceNumber(): ?string
    {
        if ($this->getDescription() === null) {
            return null;
        }

        /*
         * Invoice payments can only happen on our checking account
         */
        if ($this->getBankAccountId() !== CheckingAccount::getId()) {
            return null;
        }

        /*
         * The customer needs to have paid us
         */
        if ($this->isDebited()) {
            return null;
        }

        if (!preg_match('!MOL([RS]{1})(2[0-9]{3}).?([0-9]{10})!', strtoupper($this->getDescription()), $matches)) {
            return null;
        }

        return sprintf(
            'MOL%1s%4d.%010d',
            $matches[1],
            $matches[2],
            $matches[3]
        );
    }

    /**
     * Is this transaction a banking fee?
     */
    public function isBankingFee(): bool
    {
        if ($this->isCredited()) {
            return false;
        }

        if ($this->getOffsetAccountNumber() === 'BE05719400071075') {
            /* BE05719400071075 is the ABN AMRO bank account where the banking costs go */
            return true;
        }

        if ($this->getOffsetAccountNumber() !== null) {
            return false;
        }

        if ($this->getDescription() !== null) {
            if (stripos($this->getDescription(), 'BTW BE 0403.201.185') !== false) {
                /*
                 * Belfius banking fee
                 */
                return true;
            }

            if (stripos($this->getDescription(), 'MAANDBIJDRAGE ABNAMRO') !== false) {
                return true;
            }

            if (stripos($this->getDescription(), 'ABN AMRO BANK N.V.') !== false) {
                return true;
            }

            if (preg_match('~^KOSTEN\s+[A-Z]{2}[0-9A-Z]+~i', $this->getDescription())) {
                return true;
            }

            if (preg_match('~^ONZE REF\s+[A-Z]{2}[0-9A-Z]\s+.*?ONTV AAB~i', $this->getDescription())) {
                return true;
            }

            if (preg_match('~^\s*PRODUCTEN EN DIENSTEN Hebt u internetbankieren~i', $this->getDescription())) {
                return true;
            }

            if ($this->getBankAccountId() === KbcAccount::getId()) {
                return stripos($this->getDescription(), 'FACTURATIE GEBRUIK KBC/CBC') !== false;
            }

            if ($this->getBankAccountId() === GermanBankTransferAccount::getId()) {
                return stripos($this->getDescription(), 'Periodic Booking Fee Payments Peri') !== false
                    || stripos($this->getDescription(), 'TOTAL CURRENT ACCOUNT CHARGES')      !== false;
            }

            if ($this->getBankAccountId() === FrenchBankTransferAccount::getId()) {
                return stripos($this->getDescription(), 'EFF.DEBETPERCENTAGE') !== false
                    || stripos($this->getDescription(), 'MUTATIEPROVISIE')     !== false;
            }

            if ($this->getBankAccountId() === IdealIngAccount::getId()) {
                return stripos($this->getDescription(), 'CREDITRENTE TOT AFREKENING') !== false;
            }
        }

        if ($this->hasAnyOfTags([TransactionTags::TAG_BANK, TransactionTags::TAG_AMEX_COSTS])) {
            return true;
        }

        return false;
    }

    public function isReceivedMisterCash(): bool
    {
        if ($this->hasTag(TransactionTags::TAG_MISTERCASH)) {
            /*
             * Already tagged or collapsed transaction.
             */
            return true;
        }

        if ($this->isDebited()) {
            return false;
        }

        if (in_array($this->getOffsetAccountNumber(), ['666000000382', 'BE25666000000382'], true)) {
            return true;
        }

        if ($this->getDescription() === null) {
            return false;
        }

        if (!in_array($this->getBankAccountId(), [BancontactAccount::getId(), OldBancontactAccount::getId()], true)) {
            return false;
        }

        return Helper_Banktransaction_Matching::get_paybox_reference($this->getDescription()) !== null;
    }

    public function isReceivedBankaccountVerification(): bool
    {
        return $this->isCredited() && $this->hasTag(TransactionTags::TAG_BOARDING);
    }

    public function isReceivedIdeal(): bool
    {
        return $this->isCredited() && $this->hasTag(TransactionTags::TAG_IDEAL);
    }

    public function isReceivedBankTransfer(): bool
    {
        return $this->isCredited() && $this->hasTag(TransactionTags::TAG_BANKTRANSFER);
    }

    public function isAdyenOutpayment(): bool
    {
        return $this->hasTag(TransactionTags::TAG_ADYEN);
    }

    public function isReceivedBitcoin(): bool
    {
        return $this->isCredited() && (
            stripos((string)$this->getDescription(), 'BITONIC.NL') === 0
                || stripos((string)$this->getDescription(), 'BITMERCHANT UITBETALING') === 0
        );
    }

    public function isReceivedSofortBanking(): bool
    {
        return $this->isCredited() && $this->hasTag(TransactionTags::TAG_SOFORT);
    }

    public function isReceivedBelfiusDirectNet(): bool
    {
        return $this->hasTag(TransactionTags::TAG_BELFIUS);
    }

    public function isReceivedKbc(): bool
    {
        return $this->hasTag(TransactionTags::TAG_KBC);
    }

    public function isReceivedIngHomePay(): bool
    {
        return $this->hasTag(TransactionTags::TAG_INGHOMEPAY);
    }

    public function isReceivedGiropay(): bool
    {
        return $this->hasTag(TransactionTags::TAG_GIROPAY);
    }

    public function isReceivedEps(): bool
    {
        return $this->hasTag(TransactionTags::TAG_EPS);
    }

    public function isReceivedPrzelewy24(): bool
    {
        return $this->hasTag(TransactionTags::TAG_PRZELEWY24);
    }

    public function isReceivedPrzelewy24Refund(): bool
    {
        return $this->hasTag(TransactionTags::TAG_PRZELEWY24) && $this->hasTag(TransactionTags::TAG_PPRO_REFUND);
    }

    public function isReceivedMyBank(): bool
    {
        return $this->hasTag(TransactionTags::TAG_MYBANK);
    }

    public function isReceivedKlarnaPayLater(): bool
    {
        return $this->hasTag(TransactionTags::TAG_KLARNA_PAYLATER) && $this->hasTag(TransactionTags::TAG_KLARNA);
    }

    public function isReceivedKlarnaSliceIt(): bool
    {
        return $this->hasTag(TransactionTags::TAG_KLARNA_SLICEIT) && $this->hasTag(TransactionTags::TAG_KLARNA);
    }

    public function isReceivedKlarnaRefund(): bool
    {
        return $this->hasTag(TransactionTags::TAG_KLARNA_REFUND);
    }

    public function isReceivedKlarnaChargeback(): bool
    {
        return $this->hasTag(TransactionTags::TAG_KLARNA_CHARGEBACK);
    }

    public function isReceivedSepaDirectDebit(): bool
    {
        // Must have tag 'direct debit'
        if (!$this->hasTag(TransactionTags::TAG_DIRECTDEBIT)) {
            return false;
        }

        // Must have positive amount
        if ($this->isDebited()) {
            return false;
        }

        // Must be on SDD account
        if (!in_array(
            $this->getBankAccountId(),
            [
                DirectDebitAbnAccount::getId(),
                OldDirectDebitAccount::getId(),
                DirectDebitRabobankAccount::getId(),
                DeutscheBankDutchDirectDebitAccount::getId(),
                DeutscheBankGermanDirectDebitAccount::getId(),
            ],
            true
        )) {
            return false;
        }

        return true;
    }

    public function isReceivedStornoDirectDebit(): bool
    {
        return $this->isDebited() && $this->hasTag(TransactionTags::TAG_STORNODIRECTDEBIT);
    }

    public function isReceivedCreditcard(): bool
    {
        return $this->isCredited() && $this->hasTag(TransactionTags::TAG_CREDITCARD);
    }

    /**
     * Is this a transaction that is a Valitor settlement?
     */
    public function isReceivedValitorSettlement(): bool
    {
        if ($this->hasAnyOfTags([TransactionTags::TAG_VALITOR_SETTLEMENT, TransactionTags::TAG_VALITOR_SETTLEMENT_UNSPECIFIED])) {
            return true;
        }

        if ($this->isDebited()) {
            return false;
        }

        if (!in_array(
            $this->getOffsetAccountNumber(),
            ['DE48501108006161609331', 'IE38CITI99005127433030', 'GB16CITI18500817579721', '17579721', '6161609331'],
            true
        )) { // Check Valitor account number.
            return false;
        }

        if (count(Helper_Banktransaction_Matching::get_valitor_settlement_numbers($this->getDescription())) === 0) {
            return false;
        }

        return true;
    }

    /**
     * Is this a transaction that is a AMEX settlement?
     */
    public function isReceivedAmexSettlement(): bool
    {
        if ($this->hasTag(TransactionTags::TAG_AMEX_SETTLEMENT_NEW)
            || $this->hasTag(TransactionTags::TAG_AMEX_SETTLEMENT_EXPANDED)
        ) {
            return true;
        }

        if ($this->isDebited()) {
            return false;
        }

        /**
         * Starting May, 22, we're receiving transactions from a new IBAN: GB26CHAS60924241402968.
         *
         * @see   https://mollie.atlassian.net/browse/PAY-227
         * @issue PAY-227
         */
        if (!in_array(
            $this->getOffsetAccountNumber(),
            ['NL55HSBC0737422807', 'GB26CHAS60924241402968'],
            true
        )) { // Check AMEX account numbers.
            return false;
        }

        // Amex settlements always have the same description - our Amex account number followed by their business name.
        return preg_match("!\\d+ American Express Europe Ltd!i", $this->getDescription()) === 1;
    }

    /**
     * Is this an earlier transaction that has been returned to us by our bank because of some banking problem?
     */
    public function isReturnedTransaction(): bool
    {
        return $this->isCredited()
            && preg_match(
                '!REKENINGNUMMER GEBLOKKEERD|(?:REKENINGNUMMER )?ONBEKEND|REKNR BEGUNSTIGDE VERVALLEN|OPGEHEVEN|IS ONJUIST|SEPA TERUGBOEKING|SEPA CORRECTIEBOEKING|RETOUR|IBAN IS NIET IN GEBRUIK!i',
                (string)$this->getDescription()
            );
    }

    /**
     * Since 2018-07-19 tagdata 'outpayment_reference' is added so the matching only has to be done once (in the
     * handlers). For backward compatibility (rerun handlers) this method is added.
     */
    public function getOutpaymentReference(): ?string
    {
        if (!in_array($this->getBankAccountId(), [AbnAmroOutpaymentsAccount::getId(), RabobankOutpaymentsAccount::getId()], true)) {
            return null;
        }

        $stored_reference = $this->getTagData()['outpayment_reference'] ?? null;

        if ($stored_reference !== null) {
            return $stored_reference;
        }

        return Helper_Banktransaction_Matching::getOutpaymentReference($this->getDescription());
    }

    /**
     * Get the batch reference. This points to a batch we uploaded to this bank, via our automatic link or via an online
     * banking environment.
     *
     * @see \DefaultStatementHandler::processForBatchTransactions()
     */
    public function getSepaBatchReference(): ?string
    {
        // Get the payment info id
        if (isset($this->getTagData()['sepa_batch_reference'])) {
            return $this->getTagData()['sepa_batch_reference'];
        }

        // Unfortunately older SEPA tranactions haven't been updated with tag_data yet. (They do have the 'sepa' tag though)
        // Find the payment info id manually by looking at the description
        if (preg_match(
            '~^(?:SEPA\s+batch|BATCH REFERENCE|SEPA INCASSO BATCH:)\s+([0-9a-f]{32,})~i',
            (string)$this->getDescription(),
            $matches
        )) {
            $this->setTagData(array_replace(
                $this->getTagData(),
                ['sepa_batch_reference' => mb_strtolower($matches[1])]
            ));

            return $this->getTagData()['sepa_batch_reference'];
        }

        // Match batches on the KbcAccount
        if (preg_match(
            "!GEZAMENLIJKE OVERSCHRIJVINGSOPDRACHT\r?\nREFERENTIE ([0-9a-f]{32,})\r?\nDOORGEGEVEN!i",
            (string)$this->getDescription(),
            $matches
        )) {
            $this->setTagData(array_replace(
                $this->getTagData(),
                ['sepa_batch_reference' => mb_strtolower($matches[1])]
            ));

            return $this->getTagData()['sepa_batch_reference'];
        }

        return null;
    }

    public function isSepaBatch(): bool
    {
        return $this->getSepaBatchReference() !== null;
    }

    public function isSepaTransaction(): bool
    {
        return $this->getOffsetAccountNumber() === null && $this->hasTag(TransactionTags::TAG_SEPA);
    }

    public function isBatchTransaction(): bool
    {
        return $this->getParentTransaction() === null && $this->countChildTransactions() > 0;
    }

    public function isReceivedPProSettlement(): bool
    {
        if ($this->hasTag(TransactionTags::TAG_PPRO_SETTLEMENT)) {
            return true;
        }

        return false;
    }

    /**
     * Transfer of withheld fees (from merchant outpayments) from SMP to BV account.
     */
    public function isTransferSmpToBv(): bool
    {
        return Strings::startsWith((string)$this->getDescription(), 'Withheld fees from');
    }
}
