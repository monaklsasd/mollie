<?php

use Core\Time\Clock;

/**
 * Een baseclass voor modellen
 *
 * @author Mathieu Kooiman <mathieu@mollie.nl>
 * @author Rick Wong <wong@mollie.nl>
 * @copyright Copyright (C) 2010, Mollie B.V.
 * http://www.mollie.nl/
 */
abstract class Model_Base
{
    /** Formatter for dates in SQL. */
    public const DATE_SQL      = "Y-m-d H:i:s";
    public const DATE_ONLY_SQL = "Y-m-d";

    /** @var sql_db */
    protected $_db;

    /** @var array|string */
    protected $_primary_key   = 'id';
    protected $_table_name    = '!@(#&)*';
    protected $_table_columns = [];
    protected $_input_columns = [];

    protected $_object_stored = false;
    protected $_object_data   = [];

    /**
     * This array contains all the change applied to this object. The key is the name of the column that was changed
     * and the value if the previous value of the column.
     *
     * @var array
     */
    protected $_object_changes = [];

    protected $_validation_errors = [];

    protected $_validations = [];

    /**
     * The model's own perception of the current time. Private because getTimestamp() must be used.
     *
     * @var int
     */
    private $_timestamp;

    /**
     * "Cache", do not use directly!
     *
     * @see getModelName()
     *
     * @var string
     */
    private $model_name;

    /**
     * @param int|string|null $id
     */
    public function __construct(sql_db $db, $id = null)
    {
        $this->_db = $db;

        if ($id !== null) {
            $this->load($id);
        }
    }

    /**
     * This method is triggered by calling isset() or empty() on model properties.
     *
     * @param $column
     */
    public function __isset(string $column): bool
    {
        return isset($this->_object_data[$column]);
    }

    /**
     * This method is invoked when unset() is used on model properties.
     *
     * @param $column
     */
    public function __unset(string $column): void
    {
        $this->{$column} = null;
    }

    /**
     * Get a property of the object, magic style.
     *
     * First, check if we have the data (in that case, we have the column). This is the happy path. If the data is
     * not present, then check if we have the column. This is a performance optimization. I have also tried using
     * array_key_exists() instead of isset(), but that is slower.
     *
     * @throws Model_Exception
     * @throws Model_Exception_UnknownColumn
     *
     * @return float|int|string|null
     */
    public function __get(string $column)
    {
        if (isset($this->_object_data[$column])) {
            return $this->_object_data[$column];
        }

        if ($this->hasColumn($column)) {
            return null;
        }

        throw new Model_Exception_UnknownColumn("Unknown column \"{$column}\" on class \"{$this->getModelName()}\".");
    }

    /**
     * This method is run when writing data to model properties.
     *
     * @throws Model_Exception
     * @throws Model_Exception_UnknownColumn
     */
    public function __set(string $column, $value)
    {
        if (!$this->hasColumn($column)) {
            throw new Model_Exception_UnknownColumn("Unknown column \"{$column}\" on class \"{$this->getModelName()}\".");
        }

        if ($column === $this->_primary_key && is_string($this->_primary_key)) {
            throw new Model_Exception("Cannot set primary key directly: {$column}");
        }

        if ($value === true) {
            $value = 1;
        } elseif ($value === false) {
            $value = 0;
        }

        if (is_object($value) && method_exists($value, "__toString")) {
            $value = $value->__toString();
        }

        $current_value = isset($this->_object_data[$column]) ? $this->_object_data[$column] : null;

        if ($current_value !== $value) {
            if (!array_key_exists($column, $this->_object_changes) && (array_key_exists($column, $this->_object_data) || $value !== null)) {
                $this->_object_changes[$column] = ["old" => $current_value, "new" => $value];
            } elseif ($value !== null) {
                $this->_object_changes[$column] = ["old" => null, "new" => $value];
            }
        }

        $this->_object_data[$column] = $value;
    }

    /**
     * Reset model by erasing all data.
     */
    public function reset()
    {
        $this->_object_stored     = false;
        $this->_object_data       = [];
        $this->_object_changes    = [];
        $this->_validation_errors = [];

        /* Note: $timestamp is not data, should not be reset. */
    }

    /**
     * Check if this model references the same database record as another model.
     *
     * Accepts null as a convenience so you can throw in results from the Model_Factory directly.
     */
    public function equals(?Model_Base $model): bool
    {
        if ($model === null) {
            return false;
        }

        if ($model === $this) {
            return true;
        }

        if ($this->getModelName() != $model->getModelName()) {
            return false;
        }

        if (!$this->stored() || !$model->stored()) {
            return false;
        }

        return $this->getPrimaryKey() == $model->getPrimaryKey();
    }

    /**
     * Check if this model has a column, if the column does not exists a Model_Exception is thrown, else TRUE is
     * returned.
     */
    public function hasColumn(string $column): bool
    {
        return isset($this->_object_data[$column]) || in_array($column, $this->_table_columns, true);
    }

    /**
     * @return string[]
     */
    final public function getColumns(): array
    {
        return $this->_table_columns;
    }

    public function stored(): bool
    {
        return $this->_object_stored;
    }

    /**
     * Has this object changed since is was retrieved from the database? If a column is indicated, it will return if
     * the column has changed.
     *
     * @param string|null $column
     *
     * @throws Model_Exception_UnknownColumn
     *
     * @return bool
     */
    public function changed($column = null)
    {
        if ($column === null) {
            return !empty($this->getChanges());
        }

        if (!$this->hasColumn($column)) {
            throw new Model_Exception_UnknownColumn("Unknown column \"{$column}\" on class \"{$this->getModelName()}\".");
        }

        return isset($this->_object_changes[$column]);
    }

    /**
     * Get all changes to this object, in a $column => $old_value way. Get the new value from the object yourself.
     */
    public function getChanges(): array
    {
        return $this->_object_changes;
    }

    /**
     * @return bool Retuns TRUE if there are no collected validation errors
     */
    public function valid(): bool
    {
        return empty($this->_validation_errors);
    }

    /**
     * Load a model by its primary key.
     *
     * @param array|int|string $id The primary key to use.
     *
     * @return bool|static
     */
    public function load($id)
    {
        if ($id === null) {
            $this->reset();

            return false;
        }

        if (is_array($id)) {
            // Filter valid primary keys
            $where = array_intersect_key($id, array_combine($this->_primary_key, $this->_primary_key));
        } else {
            $where = [$this->_primary_key => $id];
        }

        if ($this->loadBy($where)) {
            return $this;
        }

        return false;
    }

    /**
     * Load a number of objects by their primary key (only single column keys supported for now). Will always return
     * an array.
     *
     * @return Model_Set|self[]
     */
    public function loadByIds(array $ids)
    {
        if (count($ids) === 0) {
            return new Model_Set();
        }

        return $this->findAll([$this->_primary_key => ["IN", array_unique($ids)]]);
    }

    /**
     * @deprecated
     * @see Model_Base::reloadOrDie()
     *
     * @return bool|self|null
     */
    public function reload()
    {
        if (!$this->stored()) {
            return null;
        }

        return $this->load($this->getPrimaryKey());
    }

    /**
     * Reload, or throw an exception if this fails for some reason.
     *
     * @throws Model_Exception      The model cannot be reloaded, because it was never loaded.
     * @throws Model_Exception_Gone The model cannot be reloaded, because it was deleted between its first load and the reload call.
     */
    public function reloadOrDie()
    {
        if (!$this->stored()) {
            throw new Model_Exception("Cannot reload a never loaded object.");
        }

        $primary_key = $this->getPrimaryKey();

        if ($this->reload() === false) {
            throw new Model_Exception_Gone("{$this->getModelName()} #{$primary_key} has already been deleted, cannot reload.");
        }
    }

    /**
     * Uses the given query to create models of the current type. This method should mostly be used from specific
     * finders defined on the current object.
     *
     * Will return a Model_Set of all models in default mode.
     *
     * If a callback is passed, an array of the return value of the callback is returned.
     *
     * @see self::findAll for explanation on $config parameter
     *
     * @param string $query     Valid SQL query to find database rows for the current model
     * @param array  $arguments Any values that might have to be replaced in $query ($query is passed to sql_db::sql_safe_query()).
     * @param array  $config    See self::findAll for explanation on $config parameter
     *
     * @throws Model_Exception
     *
     * Example usage:
     *    $this->findAllSql("SELECT * FROM m_klanten WHERE actief LIKE 1");
     *
     * @return array|Model_Set|self[]
     */
    public function findAllSql($query, $arguments = [], $config = null)
    {
        if (isset($config['callback'])) {
            $callback = $config['callback'];

            if (!is_callable($callback)) {
                $method = is_array($callback) ? sprintf("%s::%s()", get_class($callback[0]), $callback[1]) : $callback;

                throw new Model_Exception("Cannot call callback because it's not callable: " . $method);
            }

            $result = $this->_db->sql_safe_query($query, ...$arguments);

            $return_values = [];

            $model = $this->getNewInstance();

            try {
                while ($row = $this->_db->sql_fetchrow($result)) {
                    $return_values[] = $callback($model->fromArray($row, false));

                    /* Model is no longer needed */
                    $model->reset();
                }
            } finally {
                $this->_db->sql_freeresult($result);
            }

            return $return_values;
        }

        $result = $this->_db->sql_safe_query($query, ...$arguments);

        $all = new Model_Set();

        while ($row = $this->_db->sql_fetchrow($result)) {
            $model = $this->getNewInstance();
            $model->fromArray($row, false);

            $key = isset($config['key']) ? $model->toArray((array)$config['key']) : $model->getPrimaryKey();

            if (is_array($key)) {
                $key = implode('-', $key);
            }

            $all[$key] = $model;
        }

        $this->_db->sql_freeresult($result);

        return $all;
    }

    /**
     * Build a SQL query from an array of parameters and yield the resulting models
     * one by one, in a memory saving fashion.
     *
     * @param mixed[]|string $where
     * @param mixed|mixed[]  $options
     *
     * @return Generator|static[]
     */
    public function yieldAll($where = "1", $options = null)
    {
        $query = $this->_createSqlQuery($where, $options);

        return $this->yieldAllSql($query);
    }

    /**
     * Run a SQL query and yield the resulting models one by one, in a memory saving
     * fashion.
     *
     * @param string  $query
     * @param mixed[] $arguments
     *
     * @throws Model_Exception
     *
     * @return Generator|static[]
     */
    public function yieldAllSql($query, array $arguments = [])
    {
        $result = $this->_db->sql_safe_query($query, ...$arguments);

        try {
            while ($row = $this->_db->sql_fetchrow($result)) {
                $model = $this->getNewInstance();
                $model->fromArray($row, false);

                yield $model;
            }

            yield from [];
        } finally {
            // This is executed when the generator is cleaned up by the garbage collector as well.
            // See also: https://wiki.php.net/rfc/generators#closing_a_generator
            $this->_db->sql_freeresult($result);
        }
    }

    /**
     * Load a single record of this model.
     *
     * @param array|string $where
     * @param int          $options
     */
    public function loadBy($where, $options = 1): bool
    {
        $this->reset();

        $query  = $this->_createSqlQuery($where, $options);
        $result = $this->_db->sql_fetchquery($query);

        if ($result) {
            foreach ($result as $row) {
                $this->fromArray($row, false);

                return true;
            }
        }

        return false;
    }

    /**
     * @param $where string|array
     * @param $options int|array|string If int or numeric, interpreted as LIMIT.
     * @param string|null $base_query String must contain 3 placeholders for sprintf(). 1st is table name. Second is WHERE. Third is ORDER BY / LIMIT.
     *
     * @return string
     */
    protected function _createSqlQuery($where, $options, $base_query = null)
    {
        if ($base_query === null) {
            $base_query = "SELECT * FROM %s WHERE %s%s";
        }

        if (is_array($where) && !empty($where)) {
            $wheres = $this->_db->sql_columns_from_array_for_where($where);
            $where  = empty($wheres) ? '' : implode(' AND ', $wheres);
        } elseif (!is_string($where)) {
            $where = '1';
        }

        if (is_numeric($options)) {
            $options = " LIMIT {$options}";
        } elseif (is_array($options)) {
            $options_string = '';

            foreach ($options as $key => $val) {
                $options_string .= " {$key} {$val}";
            }

            $options = $options_string;
        } elseif (is_string($options)) {
            $options = " {$options}";
        }

        return sprintf(
            $base_query,
            $this->_table_name,
            $where,
            $options
        );
    }

    /**
     * Returns a collection of instances of the current model that were found in
     * the database by searching using the search options defined in $where.
     *
     * @param array|string $where   Array of columns and values or a complete SQL string to use for searching
     * @param mixed        $options Allows you to specify ORDER BY / LIMIT / HAVING clauses
     * @param mixed        $config  Extra options changing behaviour, see below.
     *
     * @throws Model_Exception
     *
     * Example usage:
     *    $customer->findAll(array('id' => 288075)); // WHERE id = 288075
     *    $customer->findAll('id = 288075'); // WHERE id = 288075
     *    $customer->findAll('id = 1234', 10); // WHERE id = 10 LIMIT 10
     *    $customer->findAll('id = 1234', array('ORDER BY' => 'id DESC')); // WHERE id = 1234 ORDER BY id DESC
     *
     * Configuration options alter behaviour:
     *  - Option 'callback' allows you to specify a callback to be called for each row found, instead of loading
     *    each row into a large array. Usefull when dealing with large datasets:
     *
     *    $customer->findAll('id = 1234', NULL, array('callback' => array($myobject, 'mymethod'))); // calls $myobject->mymethod($model_instance_of_current_row) for each row found.
     *
     *    In that case, the return value will be an array of the results of the callback function for each model.
     *
     * @return int|Model_Set|self[]
     */
    public function findAll($where = '1', $options = null, $config = [])
    {
        $query = $this->_createSqlQuery($where, $options);

        return $this->findAllSql($query, [], $config);
    }

    public function countAll($where = '1', $options = null, $config = [])
    {
        $base_query = "SELECT COUNT(1) AS `total` FROM %s WHERE %s%s";

        return (int)($this->_db->sql_fetchone($this->_createSqlQuery($where, $options, $base_query)));
    }

    public function countDistinct($where = '1', $columns = [])
    {
        $columns_sql = implode(',', $columns);
        $base_query  = "SELECT COUNT(*) AS count,{$columns_sql} FROM %s WHERE %s GROUP BY {$columns_sql}%s";

        $query = $this->_createSqlQuery($where, '', $base_query);

        return $this->_db->sql_fetchquery($query, [], $columns[0]);
    }

    public function validate()
    {
        foreach ($this->_validations as $field => $validate_config) {
            unset($this->_validation_errors[$field]);

            [$required, $filter, $error_message] = $validate_config;
            $value                               = $this->{$field};

            if ($value === null || $value === "") {
                if ($required) {
                    $this->setValidationError($field, $error_message);
                }

                continue;
            }

            $options = null;

            if (isset($validate_config[3])) {
                $options = $validate_config[3];
            }

            if (is_array($options) and !isset($options['options']) and !isset($options['flags'])) {
                $options = ['options' => $options, 'flags' => FILTER_NULL_ON_FAILURE];
            } elseif (is_array($options)) {
                $options['flags'] = ($options['flags'] ?? 0) | FILTER_NULL_ON_FAILURE;
            } else {
                $options |= FILTER_NULL_ON_FAILURE;
            }

            if (($filter & FILTER_VALIDATE_URL) == FILTER_VALIDATE_URL) { // http://bugs.php.net/bug.php?id=51192
                $filter_result = filter_var(str_replace('-', '', $value), $filter, $options);
            } // TODO FIXME
            else {
                $filter_result = filter_var($value, $filter, $options);
            }

            if ($filter_result === null || (($filter & FILTER_CALLBACK) == FILTER_CALLBACK && $filter_result === false)) {
                $this->setValidationError($field, $error_message);
            }
        }

        return $this->valid();
    }

    /**
     * Inform the object that there is a validation error with a column, usually used with validate().
     *
     * @see validate()
     *
     * @param string $column
     * @param string $error
     *
     * @throws Model_Exception_UnknownColumn
     */
    public function setValidationError($column, $error)
    {
        if (!$this->hasColumn($column)) {
            throw new Model_Exception_UnknownColumn("Unknown column \"{$column}\" on class \"{$this->getModelName()}\".");
        }

        $this->_validation_errors[$column] = $error;
    }

    /**
     * @param string $column
     *
     * @throws Model_Exception_UnknownColumn
     */
    public function removeValidationError($column)
    {
        if (!$this->hasColumn($column)) {
            throw new Model_Exception_UnknownColumn("Unknown column \"{$column}\" on class \"{$this->getModelName()}\".");
        }

        unset($this->_validation_errors[$column]);
    }

    public function getValidationErrors($escape_html = true)
    {
        if ($escape_html && function_exists('h')) {
            return array_map('h', $this->_validation_errors);
        }

        return $this->_validation_errors;
    }

    /**
     * Increment a column by a specific amount. Will return the new value.
     *
     * @param     $column
     * @param int $amount
     *
     * @throws Model_Exception_UnknownColumn
     *
     * @return bool|string
     */
    public function increment($column, $amount = 1)
    {
        if (!$this->hasColumn($column)) {
            throw new Model_Exception_UnknownColumn("Unknown column \"{$column}\" on class \"{$this->getModelName()}\".");
        }

        if ($this->stored()) {
            $extra = "";

            if ($this->hasColumn("updated_at")) {
                $extra = ", updated_at = CONVERT_TZ(UTC_TIMESTAMP, 'UTC', 'Europe/Amsterdam')";
            }

            $this->_db->sql_safe_query("UPDATE `{$this->getTableName()}` SET `{$column}` = (@cur_value := `{$column}` + ^1){$extra} WHERE `{$this->_primary_key}` = ^2", $amount, $this->getPrimaryKey());

            // Retrieve just updated value
            $value = $this->_db->sql_fetchone("SELECT @cur_value");

            $this->{$column} = $value;

            // This column is now in sync with the database.
            unset($this->_object_changes[$column]);

            return $value;
        }
        $this->{$column} += $amount;

        return $this->{$column};
    }

    /**
     * Decrement a column by a specific amount, will return the new value.
     *
     * @param     $column
     * @param int $amount
     *
     * @return bool|string
     */
    public function decrement($column, $amount = 1)
    {
        return $this->increment($column, -$amount);
    }

    /**
     * @param bool $force_save
     *
     * @throws Mollie_Database_Exception
     *
     * @return bool
     *
     * @deprecated Use saveOrDie() instead.
     * @see saveOrDie
     */
    public function save($force_save = false)
    {
        if (!$force_save && ($validate_result = $this->validate()) !== true) {
            return $validate_result;
        }

        if ($this->stored() && !$this->changed()) {
            return true;
        }

        $sql_fields = $this->_db->sql_columns_from_array($this->_object_data);

        if (!$this->stored()) {
            if ($this->hasColumn("created_at") && empty($this->_object_data['created_at'])) {
                $this->created_at = $this->getDatetime();

                $sql_fields['created_at'] = 'created_at = "' .
                    $this->_db->sql_escapestring($this->created_at) . '"';
            }

            if ($this->hasColumn("created_at_utc") && empty($this->_object_data["created_at_utc"])) {
                $this->created_at_utc = Clock::getFormattedUtcDate(self::DATE_SQL);

                $sql_fields['created_at_utc'] = 'created_at_utc = "' .
                    $this->_db->sql_escapestring($this->created_at_utc) . '"';
            }
        }

        if ($this->hasColumn("updated_at")) {
            $this->updated_at = $this->getDatetime();

            $sql_fields['updated_at'] = 'updated_at = "' . $this->_db->sql_escapestring($this->updated_at) . '"';
        }

        if ($this->hasColumn("updated_at_utc")) {
            $this->updated_at_utc = Clock::getFormattedUtcDate(self::DATE_SQL);

            $sql_fields['updated_at_utc'] = 'updated_at_utc = "' .
                $this->_db->sql_escapestring($this->updated_at_utc) . '"';
        }

        if ($this->stored()) {
            $changed_columns    = array_keys($this->getChanges());
            $changed_sql_fields = [];

            foreach ($changed_columns as $column) {
                $changed_sql_fields[$column] = $sql_fields[$column];
            }

            if (empty($changed_sql_fields)) {
                return false;
            }

            $set = implode(', ', $changed_sql_fields);

            $pk_columns = is_array($this->_primary_key) ? $this->_primary_key : [$this->_primary_key];
            $pk_where   = [];

            foreach ($pk_columns as $pk_column) {
                // The new PK values are in $set.
                // Use old PK values for this WHERE statement.
                $value = isset($this->_object_changes[$pk_column]['old']) ?
                    $this->_object_changes[$pk_column]['old'] :
                    $this->_object_data[$pk_column];

                $pk_where[] = "{$pk_column} = " . $this->_db->value_to_sql_field($value);
            }

            $q_update_row = sprintf(
                'UPDATE %s SET %s WHERE %s LIMIT 1',
                $this->_table_name,
                $set,
                implode(' AND ', $pk_where)
            );

            $res = $this->_db->sql_query($q_update_row);

            if (!$res) {
                return false;
            }
        } else {
            if (empty($sql_fields)) {
                $set = "{$this->_primary_key} = NULL";
            } else {
                $set = implode(', ', $sql_fields);
            }

            $q_insert_row = sprintf(
                "INSERT INTO %s SET %s",
                $this->_table_name,
                $set
            );

            $res = $this->_db->sql_query($q_insert_row);

            if (!$res) {
                return false;
            }

            if (!$this->getPrimaryKey()) {
                if (is_string($this->_primary_key)) {
                    $this->setPrimaryKey($this->_db->sql_nextid());
                }

                if (is_array($this->_primary_key)) {
                    $pk = [];

                    foreach ($this->_primary_key as $column) {
                        $pk[$column] = $this->_object_data[$column];
                    }
                    $this->setPrimaryKey($pk);
                }
            } else {
                // save succeeded, so the object is stored.
                $this->_object_stored = true;
            }
        }

        $this->_object_changes = [];

        return true;
    }

    /**
     * Create a legible description of the current model. Should be used for debugging, error messages etc.
     *
     * @return string
     */
    final protected function getIdentity()
    {
        if (!$this->stored()) {
            return "new {$this->getModelName()}";
        }

        $primary_key = $this->getPrimaryKey();

        if (is_array($primary_key)) {
            $primary_key = implode("/", $primary_key);
        }

        return "{$this->getModelName()} #{$primary_key}";
    }

    /**
     * Save the model. Throw an exception if saving fails.
     *
     * @param bool $force_save
     *
     * @throws Model_Exception_Save
     */
    public function saveOrDie($force_save = false)
    {
        if (!$this->save($force_save)) {
            if (!$this->valid()) {
                throw new Model_Exception_Save("Unable to save {$this->getIdentity()}: " . var_export($this->getValidationErrors(false), true));
            }

            /* Problem is with one of the child models. Model_ORM has extra logic to handle this. */
            throw new Model_Exception_Save("Unable to save {$this->getIdentity()}.");
        }
    }

    public function deleteOrDie($force_delete = false): void
    {
        if (!$this->delete($force_delete)) {
            throw new Model_Exception_Save("Unable to delete {$this->getIdentity()}.");
        }
    }

    public function delete($force_delete = false)
    {
        if (!$this->stored()) {
            return false;
        }

        if ($this->hasColumn("deleted") && !$force_delete) {
            if (!empty($this->_object_data['deleted'])) {
                return false;
            }

            $this->deleted = true;

            if ($this->hasColumn("deleted_at")) {
                $this->deleted_at = date(self::DATE_SQL);
            }

            if ($this->hasColumn("deleted_at_utc")) {
                $this->deleted_at_utc = Clock::getFormattedUtcDate(self::DATE_SQL);
            }

            if (!$this->save(true)) {
                return false;
            }
        } else {
            if (is_string($this->_primary_key)) {
                $delete_row = $this->_db->sql_safe_query(
                    "DELETE FROM {$this->_table_name} WHERE {$this->_primary_key} = $1 LIMIT 1",
                    $this->getPrimaryKey()
                );
            } elseif (is_array($this->_primary_key)) {
                $query = "DELETE FROM {$this->_table_name} WHERE";

                $index = 0;

                foreach ($this->getPrimaryKey() as $column => $value) {
                    $index++;

                    if ($index > 1) {
                        $query .= " AND";
                    }
                    $query .= " {$column} = \${$index}";
                }

                $delete_row = $this->_db->sql_safe_query($query, ...array_values($this->getPrimaryKey()));
            }

            if (!$delete_row || !$this->_db->sql_affectedrows()) {
                return false;
            }

            $this->_object_stored = false;
        }

        return true;
    }

    /**
     * Undelete a model that has been deleted before, obviously only possible on stuff that can be softdeleted.
     *
     * @throws Model_Exception
     *
     * @return bool
     */
    public function undelete()
    {
        if (!$this->stored()) {
            return false;
        }

        if (!$this->hasColumn("deleted")) {
            throw new Model_Exception("Cannot undelete {$this->getModelName()}, it cannot be softdeleted");
        }

        $this->deleted = false;

        if ($this->hasColumn('deleted_at')) {
            $this->deleted_at = null;
        }

        if ($this->hasColumn('deleted_at_utc')) {
            $this->deleted_at_utc = null;
        }

        return $this->save(true);
    }

    /**
     * Get the name of the model (AKA the class name).
     *
     * Will return the parents class name if this is a mock object, else relationships won't work with mocked
     * models.
     */
    final public function getModelName(): string
    {
        if ($this->model_name === null) {
            $this->model_name = \Core\Php\Reflection::getClass($this);
        }

        return $this->model_name;
    }

    /**
     * @return self|static
     */
    public function getNewInstance()
    {
        $model_name = $this->getModelName();

        return new $model_name($this->_db);
    }

    /**
     * @return string
     */
    public function getTableName()
    {
        return $this->_table_name;
    }

    /**
     * @return string|string[]
     */
    final public function getPrimaryKeyName()
    {
        return $this->_primary_key;
    }

    /**
     * @return array|int|string|null
     */
    public function getPrimaryKey()
    {
        if (is_string($this->_primary_key)) {
            if (isset($this->_object_data[$this->_primary_key])) {
                return $this->_object_data[$this->_primary_key];
            }

            return null;
        }

        if (is_array($this->_primary_key)) {
            $pk = [];

            foreach ($this->_primary_key as $field) {
                $pk[$field] = $this->{$field};
            }

            return $pk;
        }
    }

    public function setPrimaryKey($id, $stored = true)
    {
        $this->_object_stored = ($stored && $id !== null);

        if (is_string($this->_primary_key)) {
            return $this->_object_data[$this->_primary_key] = $id;
        }

        if (is_array($this->_primary_key)) {
            foreach ($id as $column => $value) {
                if (in_array($column, $this->_primary_key)) {
                    $this->_object_data[$column] = $value;
                }
            }
        }
    }

    /**
     * @param bool $track_changes
     *
     * @return self
     */
    public function fromArray(array $data, $track_changes = true)
    {
        foreach ($this->_table_columns as $column) {
            // Continue if column is not set. NULL-values are treated as set though.
            if (!isset($data[$column]) && !array_key_exists($column, $data)) {
                continue;
            }

            // With the new PDO library data isn't stringly typed anymore. since all existing code expects this, keep things stringly.
            $new_value = $data[$column] === null ? null : (string)$data[$column];

            if ($this->_primary_key === $column) {
                $this->setPrimaryKey($new_value);
            } elseif (is_array($this->_primary_key) && in_array($column, $this->_primary_key, true)) {
                /*
                 * If the primary key is a multi column key, and this column is part of that, and is has not yet
                 * been set before, set the primary key now.
                 */
                $pk = [];

                foreach ($this->_primary_key as $pk_column) {
                    $pk[$pk_column] = $data[$pk_column];
                }

                $this->setPrimaryKey($pk);
            } elseif (!$track_changes) {
                if ($new_value === null) {
                    /*
                     * Don't store null values, remove key from array.
                     */
                    unset($this->_object_data[$column]);
                } else {
                    $this->_object_data[$column] = $new_value;
                }
                unset($this->_object_changes[$column]);
            } else {
                $this->{$column} = $new_value;
            }
        }

        return $this;
    }

    /**
     * A more secure way to inject user input into a Model object.
     *
     * @throws Model_Exception Throws exception to abort immediately when Bad Programming is detected.
     *
     * @return mixed|self
     */
    public function fromUserInput(array $data)
    {
        $allowed_columns = array_flip($this->_table_columns);
        $allowed_data    = array_intersect_key($data, $allowed_columns);
        $input_columns   = array_keys($allowed_data);

        /*
         * Forbid these columns to be set from user input (* is wildcard):
         *   id
         *   *_id
         *   *_at
         *   deleted
         *   *admin*
         */
        if (preg_grep('/(^id$|_id$|_at$|^deleted$|admin)/i', $input_columns)) {
            throw new Model_Exception("Not allowed to set important columns directly from user input.");
        }

        /*
         * The model can be given a whitelist of acceptable user input columns.
         */
        if (count($this->_input_columns) && count($rejected_columns = array_diff($input_columns, $this->_input_columns))) {
            throw new Model_Exception("Not allowed to set columns that are not on the whitelist: " . implode(', ', $rejected_columns));
        }

        return $this->fromArray($allowed_data);
    }

    /**
     * Exports model data as an array
     *
     * @param array $only_these_columns (Optional) List of columns to export
     * @param bool  $filter_null        (Optional) Don't return NULL columns
     *
     * @return array
     */
    public function toArray(array $only_these_columns = [], $filter_null = false)
    {
        // If no columns specified then export all table columns
        if (!count($only_these_columns)) {
            $only_these_columns = $this->_table_columns;
        } else {
            $only_these_columns = array_intersect($this->_table_columns, $only_these_columns);
        }

        // Export
        $arr = [];

        foreach ($only_these_columns as $column) {
            $arr[$column] = $this->_object_data[$column] ?? null;
        }

        if ($filter_null) {
            return array_filter($arr, function ($t) {
                return $t !== null;
            });
        }

        return $arr;
    }

    public function toArrayExcept(array $all_columns_except_these = [], $filter_null = false)
    {
        return $this->toArray(
            array_diff($this->_table_columns, $all_columns_except_these),
            $filter_null
        );
    }

    /**
     * @param int $timestamp
     *
     * @return int
     * @codeCoverageIgnore
     */
    public function setTimestamp($timestamp)
    {
        return $this->_timestamp = $timestamp;
    }

    /**
     * @return int
     * @codeCoverageIgnore
     */
    public function getTimestamp()
    {
        if ($this->_timestamp !== null) {
            return $this->_timestamp;
        }

        return $this->setTimestamp(Clock::getTimestamp());
    }

    /**
     * @param int $timestamp (Optional)
     *
     * @return string
     */
    public function getDatetime($timestamp = null)
    {
        return date(static::DATE_SQL, $timestamp !== null ? $timestamp : $this->getTimestamp());
    }

    /**
     * Helper method - Rewrite the query into a "SELECT COUNT(1)" query.
     *
     * @param string $sql query
     *
     * @return string rewritten query OR false if the query can't be rewritten
     */
    public static function rewriteCountQuery($sql)
    {
        if (preg_match('/^\s*SELECT\s+\bDISTINCT\b/is', $sql)
            || preg_match('/\s+GROUP\s+BY\s+/is', $sql)
            || preg_match('/\s+UNION\s+/is', $sql)
        ) {
            return false;
        }
        $open_parenthesis   = '(?:\()';
        $close_parenthesis  = '(?:\))';
        $subquery_in_select = $open_parenthesis . '.*\bFROM\b.*' . $close_parenthesis;
        $pattern            = '/(?:.*' . $subquery_in_select . '.*)\bFROM\b\s+/Uims';

        if (preg_match($pattern, $sql)) {
            return false;
        }
        $subquery_with_limit_order = $open_parenthesis . '.*\b(LIMIT|ORDER)\b.*' . $close_parenthesis;
        $pattern                   = '/.*\bFROM\b.*(?:.*' . $subquery_with_limit_order . '.*).*/Uims';

        if (preg_match($pattern, $sql)) {
            return false;
        }
        $queryCount     = preg_replace('/(?:.*)\bFROM\b\s+/Uims', 'SELECT COUNT(1) FROM ', $sql, 1);
        [$queryCount, ] = preg_split('/\s+ORDER\s+BY\s+/is', $queryCount);
        [$queryCount, ] = preg_split('/\bLIMIT\b/is', $queryCount);

        return trim($queryCount);
    }

    /**
     * @param string $storage
     *
     * @return bool
     */
    public function storeExternalEntity($storage, $external_reference = null)
    {
        $entity = new Model_External_Entity($this->_db);
        $entity->configureFromModel($this);
        $entity->storage      = $storage;
        $entity->external_ref = $external_reference;
        $entity->status       = $external_reference ? Model_External_Entity::STATUS_SUCCESS : Model_External_Entity::STATUS_OPEN;

        return $entity->save();
    }

    /**
     * @param string $storage
     *
     * @return Model_External_Entity|null
     */
    public function findExternalEntity($storage)
    {
        $entity = new Model_External_Entity($this->_db);
        $entity->loadBy(
            [
                'storage'        => $storage,
                'internal_model' => $this->getModelName(),
                'internal_id'    => $this->getPrimaryKey(),
            ]
        );

        return $entity->stored() ? $entity : null;
    }
}
