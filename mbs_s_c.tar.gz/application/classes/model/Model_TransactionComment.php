<?php

use App\Entity\User;
use Core\Time\TimeZones;

/**
 * Model for bank_transaction_comments
 *
 * @property int                   $id             Maps to bank_transaction_comments.id, int(10) unsigned
 * @property string|null           $created_at_utc Maps to bank_transaction_comments.created_at_utc, datetime
 * @property string|null           $updated_at_utc Maps to bank_transaction_comments.updated_at_utc, datetime
 * @property int                   $transaction_id Maps to bank_transaction_comments.transaction_id, int(10) unsigned
 * @property int                   $user_id        Maps to bank_transaction_comments.user_id, int(10) unsigned
 * @property string|null           $comment        Maps to bank_transaction_comments.comment, text
 * @property Model_Banktransaction $transaction    The Model_Banktransaction referenced by $transaction_id
 */
class Model_TransactionComment extends Model_ORM
{
    protected $_model_name    = __CLASS__;
    protected $_table_name    = 'bank_transaction_comments';
    protected $_table_columns = [
        'id', 'created_at_utc', 'updated_at_utc', 'transaction_id', 'user_id',
        'comment', ];

    protected $_relationships = [
        'transaction' => [
            'type'        => Model_ORM::BELONGS_TO,
            'model'       => 'Model_Banktransaction',
            'foreign_key' => 'transaction_id',
        ],
    ];

    public function forTransaction(Model_Banktransaction $transaction, string $comment, ?User $user): void
    {
        $this->transaction = $transaction;
        $this->comment     = $comment;

        if ($user === null) {
            $user = User::getSystemUser();
        }
        $this->user_id = $user->getId();
    }

    public function getTransaction(): Model_Banktransaction
    {
        return $this->transaction;
    }

    public function getComment(): string
    {
        return $this->comment;
    }

    public function getUserId(): ?int
    {
        return in_array($this->user_id, [null, '', '0', 0], true) ? null : (int)$this->user_id;
    }

    public function getCreatedAtUtc(): DateTimeImmutable
    {
        if ($this->created_at_utc === null) {
            throw new LogicException('Can\'t request created-at date if the object has not been loaded from the database.');
        }

        return DateTimeImmutable::createFromFormat('!' . Model_ORM::DATE_SQL, $this->created_at_utc, TimeZones::UTC());
    }

    public function getUpdatedAtUtc(): DateTimeImmutable
    {
        if ($this->updated_at_utc === null) {
            throw new LogicException('Can\'t request updated-at date if the object has not been loaded from the database.');
        }

        return DateTimeImmutable::createFromFormat('!' . Model_ORM::DATE_SQL, $this->updated_at_utc, TimeZones::UTC());
    }

    /**
     * Parse the custom serialization format of transaction comments. Format remains undocumented to this date.
     *
     * @return string
     */
    public function commentAsHtml()
    {
        return preg_replace('~"(.*?)": ?([\S]+)~iu', '<a href="$2">$1</a>', html_entity_decode($this->comment, ENT_COMPAT, "UTF-8"));
    }
}
