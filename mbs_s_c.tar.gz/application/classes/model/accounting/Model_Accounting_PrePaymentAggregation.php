<?php

use Core\InvoiceNumber;
use Core\Numbers;

/**
 * @property int                                            $id                    Maps to accounting_merchant_pre_payment_aggregation.id, bigint(20) unsigned
 * @property string                                         $debtor_number         Maps to accounting_merchant_pre_payment_aggregation.debtor_number, varchar(20)
 * @property string                                         $invoice_number        Maps to accounting_merchant_pre_payment_aggregation.invoice_number, varchar(32)
 * @property float                                          $amount                Maps to accounting_merchant_pre_payment_aggregation.amount, decimal(18,2)
 * @property string                                         $date                  Maps to accounting_merchant_pre_payment_aggregation.date, date
 * @property Model_Accounting_Twinfield_PrePaymentReference $pre_payment_reference The Model_Accounting_Twinfield_PrePaymentReference which belongs to this object
 */
class Model_Accounting_PrePaymentAggregation extends Model_ORM
{
    /** @var string */
    protected $_model_name = __CLASS__;

    /** @var string */
    protected $_table_name = 'accounting_merchant_pre_payment_aggregation';

    /** @var string[] */
    protected $_table_columns = [
        'id', 'debtor_number', 'invoice_number', 'amount', 'date',
    ];

    protected $_relationships = [
        'pre_payment_reference' => [
            'type'  => Model_ORM::HAS_ONE,
            'model' => Model_Accounting_Twinfield_PrePaymentReference::class,
        ],
    ];

    public function setInvoiceNumber(InvoiceNumber $invoice_number): void
    {
        $this->invoice_number = $invoice_number->toString();
    }

    public function setDebtorNumber(string $debtor_number): void
    {
        $this->debtor_number = $debtor_number;
    }

    public function setAmount(string $amount): void
    {
        Numbers::assertNoHigherPrecisionThan($amount, 2);

        $this->amount = $amount;
    }

    public function setDate(DateTimeInterface $date): void
    {
        $this->date = $date->format('Y-m-d');
    }

    public function addAmount(string $amount): void
    {
        Numbers::assertNoHigherPrecisionThan($amount, 2);

        $this->amount = bcadd($this->amount, $amount, 2);
    }

    public function getDebtorNumber(): string
    {
        return $this->debtor_number;
    }

    public function getInvoiceNumber(): InvoiceNumber
    {
        return InvoiceNumber::fromString($this->invoice_number);
    }

    public function getAmount(): string
    {
        return $this->amount;
    }

    public function getDate(): DateTimeImmutable
    {
        return \DateTimeImmutable::createFromFormat('Y-m-d H:i:s', $this->date . '00:00:00');
    }
}
