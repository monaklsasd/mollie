<?php

use Core\Time\TimeZones;
use PhpTwinfield\MatchReferenceInterface;
use PhpTwinfield\Office;

/**
 * @property int                                  $id                      Maps to accounting_twinfield_references.id, bigint(20) unsigned
 * @property string                               $office                  Maps to accounting_twinfield_references.office, varchar(20)
 * @property string                               $transaction_code        Maps to accounting_twinfield_references.transaction_code, varchar(16)
 * @property int                                  $transaction_number      Maps to accounting_twinfield_references.transaction_number, int(11) unsigned
 * @property int                                  $transaction_line_number Maps to accounting_twinfield_references.transaction_line_number, smallint(11) unsigned
 * @property string|null                          $created_at_utc          Maps to accounting_twinfield_references.created_at_utc, datetime
 * @property Model_Accounting_Twinfield_Reference $pre_payment_reference   The Model_Accounting_Twinfield_Reference which belongs to this object
 */
class Model_Accounting_Twinfield_Reference extends Model_ORM implements MatchReferenceInterface
{
    /** @var string */
    protected $_model_name = __CLASS__;

    /** @var string */
    protected $_table_name = 'accounting_twinfield_references';

    /** @var string[] */
    protected $_table_columns = [
        'id',
        'office',
        'transaction_code',
        'transaction_number',
        'transaction_line_number',
        'created_at_utc',
    ];

    protected $_relationships = [
        'pre_payment_reference' => [
            'type'  => Model_ORM::HAS_ONE,
            'model' => Model_Accounting_Twinfield_Reference::class,
        ],
    ];

    public function setOffice(Office $office): void
    {
        $this->office = $office->getCode();
    }

    public function setCode(string $code): void
    {
        $this->transaction_code = $code;
    }

    public function setNumber(int $number): void
    {
        $this->transaction_number = $number;
    }

    public function setLineId(int $line_id): void
    {
        $this->transaction_line_number = $line_id;
    }

    public function getCreatedAtUtc(): DateTimeImmutable
    {
        return new DateTimeImmutable($this->created_at_utc, TimeZones::UTC());
    }

    /**
     * {@inheritdoc}
     */
    public function getOffice(): Office
    {
        return Office::fromCode($this->office);
    }

    /**
     * {@inheritdoc}
     */
    public function getCode(): string
    {
        return $this->transaction_code;
    }

    /**
     * {@inheritdoc}
     */
    public function getNumber(): int
    {
        return $this->transaction_number;
    }

    /**
     * {@inheritdoc}
     */
    public function getLineId(): int
    {
        return $this->transaction_line_number;
    }
}
