<?php

use Core\Time\TimeZones;

/**
 * @property int                                    $id                        Maps to accounting_twinfield_pre_payment_references.id, bigint(20) unsigned
 * @property int                                    $pre_payment_id            Maps to accounting_twinfield_pre_payment_references.pre_payment_id, bigint(20) unsigned
 * @property int                                    $twinfield_reference_id    Maps to accounting_twinfield_pre_payment_references.twinfield_reference_id, bigint(20) unsigned
 * @property string|null                            $reported_to_mollie_at_utc Maps to accounting_twinfield_pre_payment_references.reported_to_mollie_at_utc, datetime
 * @property string|null                            $created_at_utc            Maps to accounting_twinfield_pre_payment_references.created_at_utc, datetime
 * @property Model_Accounting_Twinfield_Reference   $reference                 The Model_Accounting_Twinfield_Reference referenced by $twinfield_reference_id
 * @property Model_Accounting_PrePaymentAggregation $pre_payment               The Model_Accounting_PrePaymentAggregation referenced by $pre_payment_id
 */
class Model_Accounting_Twinfield_PrePaymentReference extends Model_ORM
{
    /** @var string */
    protected $_model_name = __CLASS__;

    /** @var string */
    protected $_table_name = 'accounting_twinfield_pre_payment_references';

    /** @var string[] */
    protected $_table_columns = [
        'id',
        'pre_payment_id',
        'twinfield_reference_id',
        'reported_to_mollie_at_utc',
        'created_at_utc',
    ];

    protected $_relationships = [
        'reference' => [
            'type'        => Model_ORM::BELONGS_TO,
            'model'       => Model_Accounting_Twinfield_Reference::class,
            'foreign_key' => 'twinfield_reference_id',
        ],
        'pre_payment' => [
            'type'        => Model_ORM::BELONGS_TO,
            'model'       => Model_Accounting_PrePaymentAggregation::class,
            'foreign_key' => 'pre_payment_id',
        ],
    ];

    public function getCreatedAtUtc(): DateTimeImmutable
    {
        return new DateTimeImmutable($this->created_at_utc, TimeZones::UTC());
    }

    public function getReportedToMollieAtUtc(): ?DateTimeImmutable
    {
        if (empty($this->reported_to_mollie_at_utc)) {
            return null;
        }

        return new DateTimeImmutable($this->reported_to_mollie_at_utc, TimeZones::UTC());
    }
}
