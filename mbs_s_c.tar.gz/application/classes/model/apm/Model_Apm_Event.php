<?php
/**
 * Model_Apm_Event
 *
 * ORM-model for event table in the mollie_errors database for APM
 *
 * @author    Mollie <info@mollie.nl> Jul 3, 2013
 * @copyright Copyright (C) Mollie B.V.
 *
 * @property-read int $id Id (maps to `event`.`id`, which is a INT(10) UNSIGNED)
 * @property int|null          $request_id Request_id (maps to `event`.`request_id`, which is a INT(10) UNSIGNED)
 * @property int               $ts         Ts (maps to `event`.`ts`, which is a TIMESTAMP)
 * @property int               $type       Type (maps to `event`.`type`, which is a TINYINT(3) UNSIGNED)
 * @property string            $file       File (maps to `event`.`file`, which is a TEXT)
 * @property int               $line       Line (maps to `event`.`line`, which is a MEDIUMINT(8) UNSIGNED)
 * @property string            $message    Message (maps to `event`.`message`, which is a TEXT)
 * @property mixed             $backtrace  Backtrace (maps to `event`.`backtrace`, which is a BLOB)
 * @property int               $emailed    Emailed (maps to `event`.`emailed`, which is a TINYINT(4))
 * @property Model_Apm_Request $request    The Model_Apm_Request which belongs to this object
 */
class Model_Apm_Event extends Model_ORM
{
    /** @var string */
    protected $_table_name = 'event';
    /** @var array */
    protected $_table_columns = [
        'id', 'request_id', 'ts', 'type', 'file', 'line', 'message', 'backtrace', 'emailed',
    ];

    /** @var array */
    protected $_relationships = [
        'request' => [
            'type'        => Model_ORM::BELONGS_TO,
            'model'       => 'Model_Apm_Request',
            'foreign_key' => 'request_id',
        ],
    ];

    /**
     * Get where for query
     *
     * @param string     $type       (optional)
     * @param int|string $term       (option)
     * @param string     $term_space (optional)
     * @param string     $term_exact (optional)
     * @param int        $year       (optional)
     * @param int        $month      (optional)
     * @param int        $day        (optional)
     * @param int        $hour       (optional)
     * @param int        $minute     (optional)
     *
     * @return string
     */
    protected function _getWhere($type = null, $term = null, $term_space = null, $term_exact = null, $year = null, $month = null, $day = null, $hour = null, $minute = null)
    {
        $where       = [];
        $whereGroups = [];

        $logtime_low = $logtime_high = null;

        if (!empty($day) and !empty($month) and !empty($year) and $hour !== null and $minute !== null) {
            $logtime_low  = strtotime("{$day}-{$month}-{$year} {$hour}:{$minute}");
            $logtime_high = strtotime("{$day}-{$month}-{$year} {$hour}:{$minute} + 1 minute");
        } elseif (!empty($day) and !empty($month) and !empty($year) and $hour !== null) {
            $logtime_low  = strtotime("{$day}-{$month}-{$year} {$hour}:00");
            $logtime_high = strtotime("+1 hour", $logtime_low);
        } elseif (!empty($day) and !empty($month) and !empty($year)) {
            $logtime_low  = strtotime("{$day}-{$month}-{$year}");
            $logtime_high = strtotime("+1 day", $logtime_low);
        } elseif (!empty($month) and !empty($year)) {
            $logtime_low  = strtotime("01-{$month}-{$year}");
            $logtime_high = strtotime("+1 month", $logtime_low);
        }

        if ($logtime_low and $logtime_high) {
            $sql_logtime_low  = date('Y-m-d H:i:00', $logtime_low);
            $sql_logtime_high = date('Y-m-d H:i:00', $logtime_high);

            $where['event.ts'] = ['BETWEEN', [$sql_logtime_low, $sql_logtime_high]];
        }

        // Type
        if ($type) {
            $where['type'] = (int)$type;
        }

        if (!empty($term)) {
            $term_spaces = ['file', 'message', 'backtrace', 'uri'];

            // filter by all term fields
            if (!empty($term_space) and $term_space == 'all') {
                $sub_search = [];

                foreach ($term_spaces as $field) {
                    if ($term_exact && $term_exact == 'true') {
                        $sub_search[$field] = $term;
                    } else {
                        $sub_search[$field] = ['LIKE', sprintf('%%%s%%', $term)];
                    }
                }

                $sub_search    = implode(' OR ', $this->_db->sql_columns_from_array_for_where($sub_search));
                $whereGroups[] = "({$sub_search})";
            }
            // filter by specific field
            elseif (!empty($term_space) and in_array($term_space, $term_spaces)) {
                if ($term_exact && $term_exact == 'true') {
                    $where[$term_space] = $term;
                } else {
                    $where[$term_space] = ['LIKE', sprintf('%%%s%%', $term)];
                }
            }
        }

        $whereStr = '';

        if (count($where)) {
            $whereStr .= implode(' AND ', $this->_db->sql_columns_from_array_for_where($where));
        }

        if (count($whereGroups)) {
            if (!empty($whereStr)) {
                $whereStr .= ' AND ';
            }

            $whereStr .= implode(' AND ', $whereGroups);
        }

        return $whereStr;
    }

    /**
     * Get all error events
     *
     * @param string     $type       (optional)
     * @param int|string $term       (option)
     * @param string     $term_space (optional)
     * @param string     $term_exact (optional)
     * @param int        $year       (optional)
     * @param int        $month      (optional)
     * @param int        $day        (optional)
     * @param int        $hour       (optional)
     * @param int        $minute     (optional)
     * @param int        $offset     (optional, default 0) Offset
     * @param int        $limit      (optional, default 25) Limit
     *
     * @return array|array[]
     */
    public function getAll(
        $type = null,
        $term = null,
        $term_space = null,
        $term_exact = null,
        $year = null,
        $month = null,
        $day = null,
        $hour = null,
        $minute = null,
        $offset = 0,
        $limit = 25
    ) {
        // Start of query
        $query = "SELECT e.*, r.*, e.id AS id, e.ts AS ts FROM {$this->_table_name} e LEFT JOIN request r ON (r.id = e.request_id)";

        // Create where
        $where = $this->_getWhere($type, $term, $term_space, $term_exact, $year, $month, $day, $hour, $minute);

        // Add where stuff
        if ($where) {
            $query .= ' WHERE ' . $where;
        }

        // End of query
        $query .= " ORDER BY e.ts DESC, e.id DESC LIMIT {$offset}, {$limit}";

        // Query database
        return $this->_db->sql_fetchquery($query);
    }

    /**
     * Get error events count
     *
     * @param string     $type       (optional)
     * @param int|string $term       (option)
     * @param string     $term_space (optional)
     * @param string     $term_exact (optional)
     * @param int        $year       (optional)
     * @param int        $month      (optional)
     * @param int        $day        (optional)
     * @param int        $hour       (optional)
     * @param int        $minute     (optional)
     *
     * @return int
     */
    public function getLogCount(
        $type = null,
        $term = null,
        $term_space = null,
        $term_exact = null,
        $year = null,
        $month = null,
        $day = null,
        $hour = null,
        $minute = null
    ) {
        // Create where
        $where = $this->_getWhere($type, $term, $term_space, $term_exact, $year, $month, $day, $hour, $minute);

        if (empty($where)) {
            $where = '1';
        }

        return $this->findCount('SELECT COUNT(1) FROM event INNER JOIN request ON (request.id = event.request_id) WHERE ' . $where);
    }
}
