<?php
/**
 * Model_Request
 *
 * ORM-model for request table
 *
 * @author    Mollie <info@mollie.nl> Oct 10, 2013
 * @copyright Copyright (C) Mollie B.V.
 *
 * @property-read int $id Id (maps to `request`.`id`, which is a INT(10) UNSIGNED)
 * @property string|null     $application Application (maps to `event`.`application`, which is a VARCHAR(255))
 * @property int             $ts          Ts (maps to `request`.`ts`, which is a TIMESTAMP)
 * @property string          $script      Script (maps to `request`.`script`, which is a TEXT)
 * @property string          $uri         Uri (maps to `request`.`uri`, which is a TEXT)
 * @property string          $host        Host (maps to `request`.`host`, which is a TEXT)
 * @property int             $ip          Ip (maps to `request`.`ip`, which is a INT(10) UNSIGNED)
 * @property string          $cookies     Cookies (maps to `request`.`cookies`, which is a TEXT)
 * @property string          $post_vars   Post_vars (maps to `request`.`post_vars`, which is a TEXT)
 * @property string          $referer     Referer (maps to `request`.`referer`, which is a TEXT)
 * @property Model_Apm_Event $event       The Model_Apm_Event referenced by $request_id
 */
class Model_Apm_Request extends Model_ORM
{
    /** @var string */
    protected $_table_name = 'request';
    /** @var array */
    protected $_table_columns = [
        'id', 'application', 'ts', 'script', 'uri', 'host',
        'ip', 'cookies', 'post_vars', 'referer',
    ];

    /** @var array */
    protected $_relationships = [
        'event' => [
            'type'  => Model_ORM::HAS_ONE,
            'model' => 'Model_Apm_Event',
        ],
    ];
}
