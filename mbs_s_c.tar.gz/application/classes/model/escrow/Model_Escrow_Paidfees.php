<?php

use Money\Currency;
use Money\Money;

/**
 * A fee that has been paid by the escrow but should be paid by the B.V.
 *
 * @author    Mollie <info@mollie.nl> Nov 28, 2017
 * @copyright Copyright (C) Mollie B.V.
 *
 * @property int                   $id                        Maps to escrow_paidfees.id, int(11) unsigned
 * @property string                $entry_date                Maps to escrow_paidfees.entry_date, date
 * @property string                $currency                  Maps to escrow_paidfees.currency, char(3)
 * @property float                 $amount                    Maps to escrow_paidfees.amount, decimal(10,2)
 * @property int                   $source_banktransaction_id Maps to escrow_paidfees.source_banktransaction_id, int(10) unsigned
 * @property string                $source_tags               Maps to escrow_paidfees.source_tags, varchar(50)
 * @property int                   $bankpaymentbatch_id       Maps to escrow_paidfees.bankpaymentbatch_id, int(11) unsigned
 * @property Model_Banktransaction $source_banktransaction    The Model_Banktransaction which belongs to this object
 */
class Model_Escrow_Paidfees extends Model_ORM
{
    /** @var string */
    protected $_table_name = 'escrow_paidfees';

    /** @var array */
    protected $_table_columns = [
        'id',
        'entry_date',
        'currency',
        'amount',
        'source_banktransaction_id',
        'source_tags',
        'bankpaymentbatch_id',
    ];

    protected $_relationships = [
        'source_banktransaction' => [
            'type'        => Model_ORM::BELONGS_TO,
            'model'       => Model_Banktransaction::class,
            'foreign_key' => 'source_banktransaction_id',
        ],
        'target_paymentorders' => [
            'type'        => Model_ORM::BELONGS_TO,
            'model'       => Model_BankPaymentBatch::class,
            'foreign_key' => 'bankpaymentbatch_id',
        ],
    ];

    protected $_model_name = __CLASS__;

    final public function getAmount(): Money
    {
        return \Core\Money\money_from_string($this->amount, new Currency($this->currency));
    }

    /**
     * @param int $found_rows
     *
     * @return Model_Set|self[]
     */
    public function findAllPaginated(int $limit, int $offset, &$found_rows)
    {
        $all = $this->findAllSql("SELECT SQL_CALC_FOUND_ROWS * FROM ^1 ORDER BY id DESC LIMIT ^2, ^3", [
            $this->getTableName(),
            $offset,
            $limit,
        ]);

        $found_rows = $this->_db->sql_fetchquery('SELECT FOUND_ROWS()');
        $found_rows = (int)current($found_rows[0]);

        return $all;
    }
}
