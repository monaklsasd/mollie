<?php

use Messages\MessageType;

class MessageModel extends Model_ORM
{
    /** @var string */
    protected $_model_name = __CLASS__;

    /** @var string */
    protected $_table_name = 'messages';

    /** @var string[] */
    protected $_table_columns = [
        'id', 'body', 'message_type', 'read_at', 'created_at', 'updated_at',
    ];

    public function getId(): int
    {
        return $this->id;
    }

    public function getBody(): string
    {
        return $this->body;
    }

    public function setBody(string $body): void
    {
        $this->body = $body;
    }

    public function getMessageType(): MessageType
    {
        return new MessageType($this->message_type);
    }

    public function setMessageType(string $message_type): void
    {
        $this->message_type = $message_type;
    }

    public function setReadAt(DateTimeImmutable $date): void
    {
        $this->read_at = $date->format('Y-m-d H:i:s');
    }

    /**
     * @throws Exception
     */
    public function getCreatedAt(): DateTimeImmutable
    {
        return new \DateTimeImmutable($this->created_at);
    }

    /**
     * @throws Exception
     */
    public function getUpdatedAt(): DateTimeImmutable
    {
        return new \DateTimeImmutable($this->updated_at);
    }

    public function isRead(): bool
    {
        return $this->read_at !== null;
    }
}
