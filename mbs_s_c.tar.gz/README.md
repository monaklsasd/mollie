# Mollie Banking System

To run this application locally, in your VM for example, make sure you run 'make install' first.

## Setup

```
$ cd /var/www/mbs/
$ make install
```

