<?php

namespace PHPSTORM_META
{
    // Methods

    override(\CrappyStaticDi::getInstance(0), map(['' => '@']));

    override(\Orm\ModelFactory::create(0), map(['' => '@']));
    override(\Orm\ModelFactory::findAll(0), map(['' => '@[]']));
    override(\Orm\ModelFactory::findAllSql(0), map(['' => '@[]']));
    override(\Orm\ModelFactory::loadBy(0), map(['' => '@']));
    override(\Orm\ModelFactory::loadById(0), map(['' => '@']));
    override(\Orm\ModelFactory::loadBySql(0), map(['' => '@']));
    override(\Orm\ModelFactory::loadBySql(0), map(['' => '@']));
    override(\Orm\ModelFactory::loadByToken(0), map(['' => '@']));
    override(\Orm\ModelFactory::yieldAllSql(0), map(['' => '@[]']));

    override(\PHPUnit\Framework\TestCase::createMock(0), map(['' => '@|PHPUnit\Framework\MockObject\MockObject']));
    override(\PHPUnit\Framework\TestCase::createPartialMock(0), map(['' => '@|PHPUnit\Framework\MockObject\MockObject']));
    override(\PHPUnit\Framework\TestCase::getMock(0), map(['' => '@|PHPUnit\Framework\MockObject\MockObject']));
    override(\PHPUnit\Framework\TestCase::getMockForAbstractClass(0), map(['' => '@|PHPUnit\Framework\MockObject\MockObject']));

    override(\Phake::makeVisible(0), map(['' => '@|Phake_IMock']));
    override(\Phake::mock(0), map(['' => '@|Phake_IMock']));
    override(\Phake::partialMock(0), map(['' => '@|Phake_IMock']));
    override(\Phake::verify(0), map(['' => '@|Phake_Proxies_VerifierProxy']));
    override(\Phake::when(0), map(['' => '@|Phake_Proxies_StubberProxy']));
}
